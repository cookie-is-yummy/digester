# pin progress
- step 0: worktree made at pin_tree on brain-cells-local from f22d04f
- orientation done: verify.py == mvp22 verify_c1 minus switches; C1 attack sentence = attack_V05 (calc_rows,
  "gaming rose 42.5 points (0% to 42%)"); planted line base 332/332, 78/78; attack source counts 169 false in json
  (166 attack F + 3?) to check; skeptic 48F/20T; record_check v2 51F(44N+7RT)/25T (7 dup).
- plan: MODE in verify (full|cells, env MVP_BRAIN_CHECK), CELLS_OFF pinned; class labels file for planted false.
- step 1 code: verify.py has CheckMode (full|cells, env MVP_BRAIN_CHECK), add() gate with emitters, _fix_rules walk-past,
  insight first-reason filter, D1b loosenings, cross-row move rule (cells only). Full differential: 1173 forms x3, 0 diff
  (pin/diff_full.py). D1b/a and D1b/d rows reproduced exactly (pin/tally.py). Attack 169 rows = 166 + 3 B cases split.
- labels frozen (pin/labels.sha256) BEFORE leave-one-out: planted 146 cell/315 framing/40 policy; skeptic 6 cell; rc 3 cell.
- step 2 done (pin/loo.py, out/loo.json): direction@sign/calc/from_to ON, @compare OFF, @insight ON (masking: D01);
  uncited_claim@nomarker ON, bare/compare/all_from OFF; limits OFF (policy f_limits out); unnamed_owner ON;
  bound_global OFF; repeat OFF (policy r_repeat out). median_of_window, shorts_as_long reclassified CELL (insight binding
  rules); weekday kept on (FRAMING_KEPT, Q01, 0 true cost); insight_rewrite off (10 true). New cells-only cell rules:
  _cross_row_move (V05 = C1, closed), _mixed_move (v5_112). Only cell leak left: skeptic K37 (arguable; full lets it out too).
- step 3: loosenings in, let no cell case out (cells+noloose: 0 leaks change, -5 true).
- step 4: fallback/answer/loop/eval_brain threaded; code templates checked in full; answers differential 0 diff.
- step 5 partial: planted --check cells (exit 1 on cell leak) OK: cell all handled, 78/78. extra fixture eval/brain_cells_extra.json.
- step 6: rubric convention + attack PRIVATE_ROW_CONVENTION written.
- step 7: pin/replay_heldout.txt (cells: L1 false out 5/8, lost 18/126, lead 44/53, rep 11; L2 5/9, 14/128, 49/53, 5).
- next: tests/test_brain_cells.py, suite shards, selftest, README, DESIGN 24, commit.
- commits 8395692 (wip), 2464c0d (pinned + tests). test_brain_cells.py 31 pass. probes: 2 of 22 holes (p16, p19) pinned.
- demo 10/10, dry selftest 164/164 $0 on 2464c0d. Suite shards running (pin/suite.txt). Next: DESIGN 24, README count, commit.
- DONE: suite 6030 passed 2 skipped (4 shards on 2464c0d), brain files 345 passed, demo 10, selftest 164/164 $0.
  DESIGN 24 + README committed: tip de0284a on brain-cells-local. Not pushed.
