"""Step 1 (no model call): where the reader's seconds and output tokens go, from mvp23/reader/calls.jsonl and runs/.
Output tokens split into: the tool-call JSON (rebuilt from the saved verdicts: scaffold per row + the reasons) and
the rest (thinking), using a token-per-character rate fitted on the thinking-off runs. Seconds: least squares of
request seconds on output tokens (and on input tokens), per setting."""
import json, os, statistics as st, collections
R = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp23/reader"
calls = [json.loads(x) for x in open(os.path.join(R, "calls.jsonl")) if x.strip()]
units = {u["uid"]: u for u in json.load(open(os.path.join(R, "units.json")))}
units.update({u["uid"]: u for u in json.load(open(os.path.join(R, "units_skeptic.json")))})

def load(run):
    out = {}
    p = os.path.join(R, "runs", run + ".jsonl")
    for x in open(p):
        if x.strip():
            r = json.loads(x)
            out[r["uid"]] = r
    return out

def jtext(row):
    ss = [{"n": s["n"], "verdict": s["verdict"], "class": s["class"], "reason": s["reason"]} for s in row["sentences"]]
    full = json.dumps({"sentences": ss}, ensure_ascii=False)
    reasons = sum(len(s["reason"] or "") for s in ss)
    return full, reasons, len(ss), sum(s["verdict"] == "problem" for s in ss)

def ols(xs, ys):
    mx, my = st.mean(xs), st.mean(ys)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    return my - b * mx, b

def ols2(x1, x2, ys):
    import numpy as np
    A = np.column_stack([np.ones(len(ys)), x1, x2])
    c, *_ = np.linalg.lstsq(A, np.array(ys), rcond=None)
    pred = A @ c
    ss_res = float(((np.array(ys) - pred) ** 2).sum()); ss_tot = float(((np.array(ys) - np.mean(ys)) ** 2).sum())
    return c, 1 - ss_res / ss_tot

lines = []
# 1. chars -> tokens on thinking-off runs (output = the tool JSON only)
rate_pts = []
for run in ("dev_off_v1", "dev_off_v2"):
    rows = load(run)
    for c in calls:
        if c["run"] == run and c["uid"] in rows and c["attempt"] == 0:
            full, rch, n, nf = jtext(rows[c["uid"]])
            rate_pts.append((len(full), c["usage"]["output_tokens"]))
a0, k = ols([p[0] for p in rate_pts], [p[1] for p in rate_pts])
lines.append(f"Thinking-off runs (dev_off_v1, dev_off_v2; {len(rate_pts)} calls): output tokens = {a0:.1f} + {k:.4f} x "
             f"characters of the rebuilt tool JSON (about {1/k:.2f} characters a token).")
# 2. split per run
for run in ("dev_off_v2", "dev_ad_v2", "test_r1", "test_r2"):
    rows = load(run)
    cs = [c for c in calls if c["run"] == run and c["uid"] in rows and c["attempt"] == 0]
    for kind in ("look", "planted"):
        sel = [c for c in cs if units[c["uid"]]["kind"] == kind]
        if not sel:
            continue
        out = [c["usage"]["output_tokens"] for c in sel]
        js, rs, sc, nrow, nflag = [], [], [], [], []
        for c in sel:
            full, rch, n, nf = jtext(rows[c["uid"]])
            jt = a0 + k * len(full)
            js.append(jt); rs.append(k * rch); sc.append(jt - k * rch); nrow.append(n); nflag.append(nf)
        think = [o - j for o, j in zip(out, js)]
        lines.append(f"{run} {kind} ({len(sel)} calls): output median {st.median(out):.0f}, mean {st.mean(out):.0f}; "
                     f"of the mean: tool JSON {st.mean(js):.0f} (reasons {st.mean(rs):.0f}, row scaffold "
                     f"{st.mean(sc):.0f}), the rest (thinking) {st.mean(think):.0f}; rows a reply {st.mean(nrow):.1f}, "
                     f"flagged rows {st.mean(nflag):.2f}; reason characters a row {st.mean(rs)/k/st.mean(nrow) if st.mean(nrow) else 0:.0f}")
# 3. seconds vs tokens
by = collections.defaultdict(list)
for c in calls:
    if c["run"].startswith(("dev_", "test_r")) and c["attempt"] == 0 and c.get("retries", 0) == 0:
        by[c["setting"]].append(c)
for s, cs in sorted(by.items()):
    sec = [c["seconds"] for c in cs]; out = [c["usage"]["output_tokens"] for c in cs]
    inp = [c["usage"]["input_tokens"] for c in cs]
    a, b = ols(out, sec)
    (c0, c1, c2), r2 = ols2(out, inp, sec)
    lines.append(f"setting {s} ({len(cs)} calls): seconds = {a:.2f} + {b*1000:.2f} ms x output tokens "
                 f"({1/b:.0f} tokens a second); with input too: {c0:.2f} + {c1*1000:.2f} ms/out token + "
                 f"{c2*1e6:.1f} us/in token (R2 {r2:.2f}); median seconds {st.median(sec):.2f}, median output "
                 f"{st.median(out):.0f}, median input {st.median(inp):.0f}")
allc = [c for v in by.values() for c in v]
a, b = ols([c["usage"]["output_tokens"] for c in allc], [c["seconds"] for c in allc])
lines.append(f"pooled ({len(allc)} calls): seconds = {a:.2f} + {b*1000:.2f} ms x output tokens. The intercept is the "
             f"fixed part (network, queue, reading the input, the first token); a streaming probe measures it directly.")
open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "step1_where.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
