"""Step 3 tallies (no model call): the 40 units, d on the saved results (runs 1 and 2) against d on today's results.
A flag's cause is read from its reason by word: friends; private/sensitive/hidden; other. Labels: the recount's,
which already follow the private-row convention (a sentence is not false because of hidden private rows)."""
import json, re, collections
uids = json.load(open("step3_uids.json"))
units = {u["uid"]: u for u in json.load(open("units.json")) if u["uid"] in set(uids)}
def load(run):
    return {json.loads(x)["uid"]: json.loads(x) for x in open(f"runs/{run}.jsonl")}
def cause(reason):
    r = (reason or "").lower()
    if "friend" in r: return "friends"
    if re.search(r"private|sensitive|hidden|left out", r): return "private_or_hidden"
    return "other"
out = []
res = {}
for run in ("d_r1", "d_r2", "d_new_r1"):
    R = load(run)
    tf, fc, ft, tt, causes, wall = 0, 0, 0, 0, collections.Counter(), []
    flagged_ids = set()
    for uid in uids:
        sv = {s["sid"]: s for s in R[uid]["sentences"]}
        for s in units[uid]["sentences"]:
            if not s["target"] or not s["cells_c1a"]: continue
            f = sv[s["sid"]]["verdict"] == "problem"
            if s["label"] == "true":
                tt += 1; tf += f
                if f: causes[cause(sv[s["sid"]]["reason"])] += 1; flagged_ids.add(s["sid"])
            else:
                ft += 1; fc += f
    res[run] = flagged_ids
    out.append(f"{run:9s}: true kept flagged {tf}/{tt} (by cause in the reason: {dict(causes)}); false through flagged {fc}/{ft}")
both_old = res["d_r1"] & res["d_r2"]
out.append(f"true sentences flagged in both saved-result runs: {len(both_old)}; of them flagged on today's results: {len(both_old & res['d_new_r1'])}")
out.append(f"flagged in either saved-result run: {len(res['d_r1'] | res['d_r2'])}; on today's results: {len(res['d_new_r1'])} (new ones not flagged before: {len(res['d_new_r1'] - (res['d_r1'] | res['d_r2']))})")
out.append(f"run-to-run noise on the saved results: run 1 and run 2 differ on {len(res['d_r1'] ^ res['d_r2'])} true sentences")
# meta.hidden.friends on the 40, old and new
diff = json.load(open("rebuild_diff.json"))
c = collections.Counter()
for uid in uids:
    for o, n in zip(diff[uid]["friends_old"], diff[uid]["friends_new"]): c[(o, n)] += 1
out.append(f"meta.hidden.friends per result on the 40 (saved -> today): {dict(c)}")
# details of every flagged true sentence
for run in ("d_r1", "d_r2", "d_new_r1"):
    R = load(run)
    for uid in uids:
        sv = {s["sid"]: s for s in R[uid]["sentences"]}
        for s in units[uid]["sentences"]:
            if s["target"] and s["cells_c1a"] and s["label"] == "true" and sv[s["sid"]]["verdict"] == "problem":
                out.append(f"  [{run}] {s['sid']}: {s['text'][:110]} || {sv[s['sid']]['class']}: {sv[s['sid']]['reason']}")
open("step3_table.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out))
