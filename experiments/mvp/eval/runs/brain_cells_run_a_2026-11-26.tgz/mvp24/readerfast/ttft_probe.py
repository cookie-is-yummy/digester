"""Time to first token, measured: the same request bodies as rf_reader.py, sent streamed through the repo's client
(ai.anthropic_client(), the Claude cap checked with ai._guard, every request logged with ai.log_batch, purpose
brain_reader_eval). Records the time to the first event of each kind. Made-up data only.
    python3 ttft_probe.py VARIANT UID[,UID...]"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import rf_reader as RF  # noqa: E402


def stream_one(prov, system, unit):
    ai = prov.ai
    msgs = [{"role": "user", "content": RF.layout(unit, prov.var)}]
    body = prov.body(system, [RF.VARIANTS[prov.var]["tool"]], msgs)
    est_in = len(json.dumps([system, body["tools"], msgs], default=str)) / 3.5
    with ai._pending_lock:
        p = ai._guard("anthropic", prov.model, est_in, body["max_tokens"], pending=ai._pending["usd"])
    client = ai.anthropic_client()
    t0 = time.time()
    first = {}
    with client.beta.messages.stream(**body, timeout=90.0) as s:
        for ev in s:
            k = ev.type
            if k == "content_block_start":
                k = "start_" + getattr(ev.content_block, "type", "?")
            elif k == "content_block_delta":
                k = "delta_" + getattr(ev.delta, "type", "?")
            first.setdefault(k, round(time.time() - t0, 3))
        r = s.get_final_message()
    secs = round(time.time() - t0, 2)
    cost, _a, _s = ai.claude_cost(prov.model, r.usage)
    u = RF.PV._usage_of(r.usage)
    ai.log_batch("anthropic", prov.model, prov.purpose, 1, u["input_tokens"] + u["cache_read_input_tokens"] +
                 u["cache_creation_input_tokens"], u["output_tokens"], cost, secs,
                 prompt_version=prov.prompt_version + "+stream")
    row = {"run": "ttft_" + prov.var, "uid": unit["uid"], "variant": prov.var, "attempt": 0, "seconds": secs,
           "cost_usd": cost, "usage": u, "stop": r.stop_reason, "retries": 0, "setting": prov.setting,
           "cache_system": RF.CACHE_SYSTEM, "fail": None, "first": first, "stream": True}
    with open(os.path.join(HERE, "calls.jsonl"), "a") as f:
        f.write(json.dumps(row) + "\n")
    return row


if __name__ == "__main__":
    var, uids = sys.argv[1], sys.argv[2].split(",")
    units = {u["uid"]: u for u in RF.load_units("units.json,units_skeptic.json,units_audit_lead.json")}
    prov = RF.Prov(var)
    system = open(os.path.join(HERE, RF.VARIANTS[var]["prompt"]), encoding="utf-8").read()
    for uid in uids:
        if RF.spent() >= RF.SPEND_CAP - 0.03:
            print("spend cap")
            break
        r = stream_one(prov, system, units[uid])
        print(var, uid, r["seconds"], r["usage"]["output_tokens"], r["first"])
