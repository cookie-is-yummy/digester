"""The step-2 table (no model call). NOT fresh: every unit was used before (look 1 and dev material wrote v2; the
writer of a-e read the frozen run's misses and false alarms). Same 357 units for every variant (e: 174)."""
import collections, json, statistics as st, sys
sys.path.insert(0, ".")
import rf_score as SC
units = SC.all_units()
kind_of = {u["uid"]: u["kind"] for u in units}
keep = {u["uid"] for u in units if SC.set_of(u) in SC.SETS}
V = [("v2 frozen (rows+reasons, adaptive)", "mvp23:dev_ad_v2+mvp23:test_r1+mvp23:auditlead_r1"),
     ("a flags only, adaptive", "a_r1"), ("b flags only, thinking off", "b_r1"),
     ("c flags only, off, cut rows", "c_r1"), ("e terse rows, off (3 sets only)", "e_r1"),
     ("d = a + 2 edits, run 1", "d_r1"), ("d run 2 (look 1, look 2 only)", "d_r2")]
L = ["STEP 2: same units as the frozen run; NOT fresh. Cells = cells-only C1a. 'x/y' = flagged / sentences.",
     "Columns per set: false let through by cells, flagged | true kept by cells, flagged.",
     f"{'variant':38s} " + " ".join(f"{s:>16s}" for s in SC.SETS) + "   total"]
for name, spec in V:
    run, rs, per, tot = SC.summary(spec, units)
    cells = []
    for s in SC.SETS:
        p = per[s]
        cells.append(f"{p['caught']:>3}/{p['false_through']:<3}|{p['true_flag']:>3}/{p['true_kept']:<4}" if p["false_through"] + p["true_kept"] else f"{'-':>16s}")
    L.append(f"{name:38s} " + " ".join(f"{c:>16s}" for c in cells) +
             f"   {tot['caught']}/{tot['false_through']} | {tot['true_flag']}/{tot['true_kept']}; failed {tot['failed_units']}")
L.append("")
L.append("SECONDS, TOKENS, COST per request (look = whole answers; planted = 1-2 sentence units)")
for name, spec in V:
    cs = [c for c in SC.calls_of(spec) if c["uid"] in keep]
    for k in ("look", "planted"):
        c = SC.call_stats(cs, kind_of, k)
        if c:
            L.append(f"  {name:38s} {k:7s} n {c['n']:3d}: s median {c['sec_med']:.2f}, p90 {c['sec_p90']:.2f}, max "
                     f"{c['sec_max']:.2f}; out tokens median {c['out_med']:.0f} (p90 {c['out_p90']}); in median "
                     f"{c['in_med']:.0f}; cost/request ${c['cost_mean']:.5f}; second attempts {c['second_attempts']}; "
                     f"reply faults {c['fails'] or 'none'}")
L.append("")
L.append("CATCHES BY OUR CLASS (false let through by cells; all five sets): flagged/total")
for name, spec in V[:6]:
    run, rs, per, tot = SC.summary(spec, units)
    F = [r for r in rs if r["target"] and r["label"] == "false" and r["cells_c1a"] and r["set"] in SC.SETS]
    by = collections.defaultdict(lambda: [0, 0])
    for r in F:
        by[r["cls"]][1] += 1; by[r["cls"]][0] += r["flag"]
    L.append(f"  {name:38s} " + ", ".join(f"{k} {a}/{b}" for k, (a, b) in sorted(by.items())))
L.append("")
a = SC.rows(units, SC.load_run("d_r1")); b = SC.rows(units, SC.load_run("d_r2"))
look = lambda rs: [r for r in rs if r["kind"] == "look"]
same, n, sf, nf, stt, nt = SC.agreement(look(a), look(b))
L.append(f"AGREEMENT d run 1 / run 2 on look 1 + look 2 (scored sentences cells-only keeps): {same}/{n}; false {sf}/{nf}; true {stt}/{nt}")
fa1 = {r['sid'] for r in look(a) if r['target'] and r['label']=='true' and r['cells_c1a'] and r['flag']}
fa2 = {r['sid'] for r in look(b) if r['target'] and r['label']=='true' and r['cells_c1a'] and r['flag']}
L.append(f"  true sentences flagged: run 1 {len(fa1)}, run 2 {len(fa2)}, both {len(fa1 & fa2)}")
a2 = SC.rows(units, SC.load_run("mvp23:test_r1")); b2 = SC.rows(units, SC.load_run("mvp23:test_r2"))
same, n, sf, nf, stt, nt = SC.agreement(look(a2), look(b2))
L.append(f"  beside it, v2 frozen test_r1 / test_r2 on look 2 only: {same}/{n}; false {sf}/{nf}; true {stt}/{nt}")
same, n, sf, nf, stt, nt = SC.agreement([r for r in look(a) if r['set']=='look2'], [r for r in look(b) if r['set']=='look2'])
L.append(f"  d on look 2 only: {same}/{n}; false {sf}/{nf}; true {stt}/{nt}")
L.append("")
L.append("THE LEAST-ORDER DEFECT (v2's line; fixed in d): the attack cases it was seen on")
for uid in ("attack_W03", "attack_W05", "attack_t21", "attack_W01", "attack_W07"):
    u = next((x for x in units if x["uid"] == uid), None)
    if not u: continue
    s = next(x for x in u["sentences"] if x["target"])
    marks = []
    for name, spec in (("v2 r1", "mvp23:test_r1"), ("v2 r2", "mvp23:test_r2"), ("a", "a_r1"), ("d", "d_r1")):
        run = SC.load_run(spec)
        if uid in run:
            e = {x["sid"]: x for x in run[uid]["sentences"]}.get(s["sid"], {})
            marks.append(f"{name} {'FLAG' if e.get('verdict') == 'problem' else 'ok'}")
    L.append(f"  {uid} [{s['label']}, cells {'keeps' if s['cells_c1a'] else 'drops'}] {s['text'][:80]}: " + ", ".join(marks))
L.append("  NOTE: d_r2 ran with the system block cached (RF_CACHE=1): its 'in median' counts uncached tokens only and its")
L.append("  cost is the cached price; the reply is not changed by caching.")
open("table.txt", "w").write("\n".join(L) + "\n")
print("\n".join(L))
