"""Step 4 tallies (no model call). reader_check batch 1 and 2 with their slices (as in their score_new.py), d run 1
beside their frozen-v2 runs 1 and 2; record_check's v2 set (37 false, 21 true) by cells-only base a."""
import json, re, collections
RC = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp23/reader_check/runs"
def load(p):
    out = {}
    for x in open(p):
        r = json.loads(x)
        if r.get("ok") or r["uid"] not in out: out[r["uid"]] = r
    return {s["sid"]: s for r in out.values() for s in r["sentences"]}, out
L = []
for name, ufile, theirs, mine in (("batch 1", "units_new.json", ("new_r1", "new_r2"), "u4_rc_r1"),
                                   ("batch 2", "units_new2.json", ("new2_r1", "new2_r2"), "u4_rc_r1")):
    U = json.load(open(ufile))
    runs = {"v2 run1": load(f"{RC}/{theirs[0]}.jsonl")[0], "v2 run2": load(f"{RC}/{theirs[1]}.jsonl")[0],
            "d run1": load(f"runs/{mine}.jsonl")[0]}
    rows = [dict(s, layout=u.get("layout"), uid=u["uid"]) for u in U for s in u["sentences"]]
    def line(lbl, sel):
        F = [r for r in sel if r["label"] == "false"]; T = [r for r in sel if r["label"] == "true"]
        parts = []
        for k, v in runs.items():
            parts.append(f"{k}: false {sum(v[r['sid']]['verdict'] == 'problem' for r in F)}/{len(F)}, true "
                         f"{sum(v[r['sid']]['verdict'] == 'problem' for r in T)}/{len(T)}")
        return f"  {lbl:<44} " + "; ".join(parts)
    T = [r for r in rows if r["target"]]
    if name == "batch 1":
        S = [r for r in T if r["layout"] == "short"]
        L.append(name)
        L.append(line("HEADLINE short, firm, cells-only keeps", [r for r in S if r.get("tier") == "firm" and r["cells_c1a"]]))
        L.append(line("short, firm, subtle, word not in lists", [r for r in S if r.get("tier") == "firm" and r["cells_c1a"] and ((r.get("diff") == "subtle" and r.get("listword") == "n") or r["label"] == "true")]))
        L.append(line("short, firm, all (cells or not)", [r for r in S if r.get("tier") == "firm"]))
        L.append(line("short, borderline tier", [r for r in S if r.get("tier") == "borderline"]))
        L.append(line("long layout (same targets, 3-4 sentences)", [r for r in T if r["layout"] == "long"]))
    else:
        L.append(name)
        L.append(line("cells-only keeps", [r for r in T if r["cells_c1a"]]))
        L.append(line("all", T))
    car = [r for r in rows if not r["target"]]
    L.append("  carriers (true, not scored) flagged: " + "; ".join(f"{k} {sum(v[r['sid']]['verdict'] == 'problem' for r in car)}/{len(car)}" for k, v in runs.items()))
    # flagged true targets, d run1, with reason
    dv = runs["d run1"]
    for r in T:
        if r["label"] == "true" and dv[r["sid"]]["verdict"] == "problem":
            L.append(f"    d flags true {r['sid']} [cells {'keeps' if r['cells_c1a'] else 'drops'}]: {r['text'][:90]} || {dv[r['sid']]['reason']}")
    for r in T:
        if r["label"] == "false" and r["cells_c1a"] and dv[r["sid"]]["verdict"] != "problem":
            L.append(f"    d misses false {r['sid']} (tier {r.get('tier')}): {r['text'][:110]}")
    fr = [r for r in rows if dv[r["sid"]]["verdict"] == "problem" and "friend" in (dv[r["sid"]]["reason"] or "").lower()]
    L.append(f"  d flags whose reason cites friends: {len(fr)}; v2 run1: {sum(1 for r in rows if runs['v2 run1'][r['sid']]['verdict']=='problem' and 'friend' in (runs['v2 run1'][r['sid']]['reason'] or '').lower())}")
# record_check
U = json.load(open("units_record.json"))
dv, _ = load("runs/u4_rec_r1.jsonl")
rows = [dict(u["sentences"][0], uid=u["uid"], rt=u["rt"]) for u in U]
def rec_line(lbl, sel):
    F = [r for r in sel if r["label"] == "false"]; T = [r for r in sel if r["label"] == "true"]
    return (f"  {lbl:<44} false flagged {sum(dv[r['sid']]['verdict']=='problem' for r in F)}/{len(F)}; true flagged "
            f"{sum(dv[r['sid']]['verdict']=='problem' for r in T)}/{len(T)}")
L.append("record_check v2 set (lone lead), d run 1")
L.append(rec_line("all 58", rows))
L.append(rec_line("cells-only (base a) keeps", [r for r in rows if r["cells_c1a"]]))
L.append(rec_line("cells keeps, without the 7 RT near-copies", [r for r in rows if r["cells_c1a"] and not r["rt"]]))
n03 = next(r for r in rows if r["sid"] == "rec_N03:lead0")
L.append(f"  N03 (false only if hidden private rows count; private-row convention: not false): cells {'keeps' if n03['cells_c1a'] else 'drops'}, d {'flags' if dv[n03['sid']]['verdict']=='problem' else 'does not flag'} it")
for r in rows:
    v = dv[r["sid"]]
    if r["label"] == "true" and v["verdict"] == "problem":
        L.append(f"    d flags true {r['sid']} [cells {'keeps' if r['cells_c1a'] else 'drops'}]: {r['text'][:90]} || {v['reason']}")
    if r["label"] == "false" and r["cells_c1a"] and v["verdict"] != "problem":
        L.append(f"    d misses false {r['sid']}: {r['text'][:110]} || recount: {str(r['fault'])[:90]}")
open("step4_table.txt", "w").write("\n".join(L) + "\n")
print("\n".join(L))
