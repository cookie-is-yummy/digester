"""Score reader runs on the step-2 units (no model call). Sets: look1, look2, attack (odd half), audit_wl (audit
with a lead: the 13 audit units that have one + the 48 audit_lead units), skeptic.
    python3 rf_score.py NAME=RUN[+RUN...] [NAME=...]   (a RUN is a file in runs/ here or 'mvp23:' + a frozen run)
Catch = false sentence cells-only (C1a) lets through, flagged. True flag = true sentence cells-only keeps, flagged.
Failed replies (no usable tool call after the retry) are counted apart, never as 'not flagged'."""
import collections
import json
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
R23 = os.path.join(os.path.dirname(os.path.dirname(HERE)), "mvp23", "reader")
sys.path.insert(0, HERE)
import classes as CL  # noqa: E402

SETS = ["look1", "look2", "attack", "audit_wl", "skeptic"]


def all_units():
    u = []
    for f in ("units.json", "units_skeptic.json", "units_audit_lead.json"):
        u += json.load(open(os.path.join(HERE, f)))
    return u


def set_of(u):
    if u["set"] == "audit_lead":
        return "audit_wl"
    if u["set"] == "audit":
        return "audit_wl" if any(s["where"] == "lead" for s in u["sentences"]) else None
    if u["set"] == "attack":
        return "attack" if u["split"] == "test" else "attack_even"
    return u["set"]


def path_of(run):
    if run.startswith("mvp23:"):
        return os.path.join(R23, "runs", run[6:] + ".jsonl")
    return os.path.join(HERE, "runs", run + ".jsonl")


def load_run(spec):
    out = {}
    for run in spec.split("+"):
        for x in open(path_of(run)):
            if x.strip():
                r = json.loads(x)
                if r.get("ok") or r["uid"] not in out:
                    out[r["uid"]] = r
    return out


def calls_of(spec):
    rows = []
    for run in spec.split("+"):
        p = os.path.join(R23, "calls.jsonl") if run.startswith("mvp23:") else os.path.join(HERE, "calls.jsonl")
        name = run[6:] if run.startswith("mvp23:") else run
        rows += [json.loads(x) for x in open(p) if x.strip() and json.loads(x)["run"] == name]
    return rows


def rows(units, run):
    out = []
    for u in units:
        st_ = set_of(u)
        if st_ is None or u["uid"] not in run:
            continue
        r = run[u["uid"]]
        vs = {s["sid"]: s for s in r.get("sentences") or []}
        for s in u["sentences"]:
            e = vs.get(s["sid"]) or {"verdict": "missing"}
            out.append(dict(s, set=st_, uid=u["uid"], kind=u["kind"], ok=bool(r.get("ok")),
                            flag=e["verdict"] == "problem", rclass=e.get("class"), reason=e.get("reason"),
                            cls=CL.klass(u, s), attack_class=u.get("attack_class")))
    return out


def tally(rs):
    t = [r for r in rs if r["target"]]
    F = [r for r in t if r["label"] == "false" and r["cells_c1a"]]
    T = [r for r in t if r["label"] == "true" and r["cells_c1a"]]
    failed = len({r["uid"] for r in rs if not r["ok"]})
    return {"false_through": len(F), "caught": sum(r["flag"] for r in F), "true_kept": len(T),
            "true_flag": sum(r["flag"] for r in T), "failed_units": failed,
            "carrier_flags": sum(r["flag"] for r in rs if not r["target"] and r["kind"] == "planted"),
            "carriers": sum(1 for r in rs if not r["target"] and r["kind"] == "planted"),
            "by_class": dict(sorted(collections.Counter((r["cls"], r["flag"]) for r in F).items(), key=str))}


def p90(xs):
    xs = sorted(xs)
    return xs[int(0.9 * (len(xs) - 1))] if xs else float("nan")


def call_stats(cs, kind_of, kind=None):
    cs = [c for c in cs if kind is None or kind_of.get(c["uid"]) == kind]
    if not cs:
        return None
    sec = [c["seconds"] for c in cs]
    out = [c["usage"]["output_tokens"] for c in cs]
    inp = [c["usage"]["input_tokens"] for c in cs]
    return {"n": len(cs), "sec_med": st.median(sec), "sec_p90": p90(sec), "sec_max": max(sec),
            "out_med": st.median(out), "out_p90": p90(out), "in_med": st.median(inp),
            "cost_mean": st.mean(c["cost_usd"] for c in cs), "cost_sum": sum(c["cost_usd"] for c in cs),
            "second_attempts": sum(1 for c in cs if c.get("attempt", 0) > 0),
            "fails": dict(collections.Counter(c.get("fail") for c in cs if c.get("fail")))}


def agreement(ra, rb):
    a = {r["sid"]: r for r in ra if r["target"] and r["cells_c1a"] and r["ok"]}
    b = {r["sid"]: r for r in rb if r["target"] and r["cells_c1a"] and r["ok"]}
    common = [k for k in a if k in b]
    same = sum(a[k]["flag"] == b[k]["flag"] for k in common)
    f = [k for k in common if a[k]["label"] == "false"]
    t = [k for k in common if a[k]["label"] == "true"]
    return same, len(common), sum(a[k]["flag"] == b[k]["flag"] for k in f), len(f), \
        sum(a[k]["flag"] == b[k]["flag"] for k in t), len(t)


def summary(spec, units):
    run = load_run(spec)
    rs = rows(units, run)
    per = {s: tally([r for r in rs if r["set"] == s]) for s in SETS}
    tot = {k: sum(per[s][k] for s in SETS) for k in ("false_through", "caught", "true_kept", "true_flag",
                                                    "failed_units")}
    return run, rs, per, tot


if __name__ == "__main__":
    units = all_units()
    kind_of = {u["uid"]: u["kind"] for u in units}
    for arg in sys.argv[1:]:
        name, spec = arg.split("=", 1)
        run, rs, per, tot = summary(spec, units)
        print(f"== {name} ({spec})")
        for s in SETS:
            p = per[s]
            print(f"  {s:9s} false through cells flagged {p['caught']}/{p['false_through']}; true kept flagged "
                  f"{p['true_flag']}/{p['true_kept']}; failed units {p['failed_units']}; carriers flagged "
                  f"{p['carrier_flags']}/{p['carriers']}")
        print(f"  total    caught {tot['caught']}/{tot['false_through']}; true flagged {tot['true_flag']}/"
              f"{tot['true_kept']}; failed {tot['failed_units']}")
        keep = {u["uid"] for u in units if set_of(u) in SETS}
        cs = [c for c in calls_of(spec) if c["uid"] in keep]
        for k in ("look", "planted"):
            c = call_stats(cs, kind_of, k)
            if c:
                print(f"  calls {k}: {c}")
