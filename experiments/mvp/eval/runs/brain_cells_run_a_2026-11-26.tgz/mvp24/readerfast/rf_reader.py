"""Faster reader variants (mvp24 readerfast). Built from mvp23/reader/reader.py (copied ideas, that file unchanged).
One request per unit, through the repo's own route (mvp.brain.provider.AnthropicProvider -> mvp.llm.ai: the key by
name, the Claude cap, ai.log_batch to the ledger, purpose "brain_reader_eval"). Only made-up data is sent.

    python3 rf_reader.py RUN VARIANT [--units FILE,...] [--sets s1,s2] [--splits ...] [--uids ...] [--limit N]
VARIANT: v2ctl (the frozen v2 prompt and tool, adaptive: a timing control), a (flags only, adaptive), b (flags only,
thinking off, tool forced), c (b with the results cut to the cited rows + meta), d (set in VARIANTS once picked).
Every call row (calls.jsonl) keeps the raw tool input, any text, the stop reason and a failure kind.
"""
import argparse
import json
import os
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/home/user/digester/experiments")
os.environ.setdefault("MVP_CLAUDE_CAP_USD", "25")
os.environ.setdefault("MVP_LEDGER_HOME", "/home/user/digester/data/mvp")

from mvp.brain import provider as PV  # noqa: E402

PURPOSE = "brain_reader_eval"
CLASSES = ["period", "base", "scope", "rank_or_tie", "list_completeness", "only_or_all", "direction", "other"]
CACHE_SYSTEM = os.environ.get("RF_CACHE") == "1"
SPEND_CAP = 1.22          # all calls of this folder together (the task's hard cap is $1.25)
MAX_TOKENS = 4000
LOCK = threading.Lock()

TOOL_V2 = {
    "name": "report_sentences",
    "description": "Your verdict on every numbered sentence of the answer: ok, or a problem with its class and a "
                   "short reason.",
    "input_schema": {
        "type": "object", "additionalProperties": False, "required": ["sentences"],
        "properties": {"sentences": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["n", "verdict", "class", "reason"],
            "properties": {"n": {"type": "integer"}, "verdict": {"type": "string", "enum": ["ok", "problem"]},
                           "class": {"type": "string", "enum": ["none"] + CLASSES},
                           "reason": {"type": "string"}}}}}},
}
TOOL_FLAGS = {
    "name": "report_problems",
    "description": "Only the numbered sentences that have a problem, each with its class and a short reason; an "
                   "empty list when every sentence is fine.",
    "input_schema": {
        "type": "object", "additionalProperties": False, "required": ["problems"],
        "properties": {"problems": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["n", "class", "reason"],
            "properties": {"n": {"type": "integer"}, "class": {"type": "string", "enum": CLASSES},
                           "reason": {"type": "string"}}}}}},
}

VARIANTS = {
    "v2ctl": {"prompt": "reader_prompt_v2.md", "tool": TOOL_V2, "setting": "adaptive", "cut": False},
    "a": {"prompt": "prompt_a.md", "tool": TOOL_FLAGS, "setting": "adaptive", "cut": False},
    "b": {"prompt": "prompt_a.md", "tool": TOOL_FLAGS, "setting": "off", "cut": False},
    "c": {"prompt": "prompt_c.md", "tool": TOOL_FLAGS, "setting": "off", "cut": True},
    "e": {"prompt": "prompt_e.md", "tool": TOOL_V2, "setting": "off", "cut": False},
}
if os.path.exists(os.path.join(HERE, "variant_d.json")):
    _d = json.load(open(os.path.join(HERE, "variant_d.json")))
    VARIANTS["d"] = {"prompt": _d["prompt"], "tool": TOOL_V2 if _d.get("tool") == "rows" else TOOL_FLAGS, "setting": _d["setting"], "cut": _d["cut"]}

PATH_RE = re.compile(r"\br\d+(?:\.[A-Za-z_][A-Za-z0-9_]*|\[\d+\])+")
SEG_RE = re.compile(r"\.([A-Za-z_][A-Za-z0-9_]*)|\[(\d+)\]")


def row_path(p):
    """The row a marker path points into: up to its first list index; with no index, the leaf's parent object."""
    rid = re.match(r"r\d+", p).group(0)
    segs = [(m.group(1), m.group(2)) for m in SEG_RE.finditer(p[len(rid):])]
    out = []
    for k, i in segs:
        out.append((k, i))
        if i is not None:
            return rid, out
    if len(out) >= 2:
        out = out[:-1]
    return rid, out


def fmt(rid, segs):
    return rid + "".join(f".{k}" if k is not None else f"[{i}]" for k, i in segs)


def resolve(d, segs):
    cur = d
    for k, i in segs:
        if k is not None:
            if not isinstance(cur, dict) or k not in cur:
                return KeyError
            cur = cur[k]
        else:
            if not isinstance(cur, list) or int(i) >= len(cur):
                return KeyError
            cur = cur[int(i)]
    return cur


def cut_results(unit):
    """Each result: rid, tool, meta, its scalar fields, and only the rows the sentences cite ("cited_rows")."""
    want = {}
    for s in unit["sentences"]:
        for p in PATH_RE.findall(s["text"]):
            rid, segs = row_path(p)
            want.setdefault(rid, {})[fmt(rid, segs)] = segs
    out = []
    for r in unit["results"]:
        d = json.loads(r)
        if not isinstance(d, dict) or "meta" not in d:
            out.append(r)
            continue
        rid = d.get("rid")
        keep = {k: v for k, v in d.items() if k in ("rid", "tool", "meta") or not isinstance(v, (dict, list))}
        rows = {}
        for path, segs in sorted((want.get(rid) or {}).items()):
            v = resolve(d, segs)
            if v is KeyError and isinstance(d.get("sheet"), dict):
                v = resolve(d["sheet"], segs)
            if v is not KeyError:
                rows[path] = v
        keep["cited_rows"] = rows
        out.append(json.dumps(keep, ensure_ascii=False))
    return out


def layout(unit, var):
    tool = VARIANTS[var]["tool"]["name"]
    results = cut_results(unit) if VARIANTS[var]["cut"] else unit["results"]
    parts = ["<person>", unit["user"], "</person>", "<results>"]
    for r in results:
        parts += ["<result>", r, "</result>"]
    parts.append("</results>")
    parts.append("<answer>")
    for i, s in enumerate(unit["sentences"], 1):
        parts.append(f"{i}. ({'first sentence' if s['where'] == 'lead' and s['index'] == 0 else s['where']}) "
                     f"{s['text']}")
    parts.append("</answer>")
    parts.append(f"Check each of the {len(unit['sentences'])} sentences and call {tool} once.")
    return "\n".join(parts)


class Prov(PV.AnthropicProvider):
    def __init__(self, var, **kw):
        self.var = var
        cfg = VARIANTS[var]
        self.setting = cfg["setting"]
        self.tool_name = cfg["tool"]["name"]
        super().__init__(thinking="disabled" if self.setting == "off" else "adaptive", effort="low",
                         max_tokens=MAX_TOKENS, prompt_version=f"readerfast_{var}+{self.setting}", purpose=PURPOSE,
                         strict=True, loose=(), cache=False, timeout=90.0, **kw)

    def body(self, system, tools, messages, max_tokens=None):
        b = super().body(system, tools, messages, max_tokens)
        if self.setting == "off":
            b["tool_choice"] = {"type": "tool", "name": self.tool_name}
        if CACHE_SYSTEM:   # cost only: the tools + system prefix is read from the cache (the reply is not changed)
            b["system"][0]["cache_control"] = {"type": "ephemeral"}
        return b


def spent():
    p = os.path.join(HERE, "calls.jsonl")
    if not os.path.exists(p):
        return 0.0
    return sum(json.loads(x).get("cost_usd") or 0 for x in open(p) if x.strip())


def parse(reply, var, n_sent):
    """-> (flags {n: {class, reason}}, failure kind or None, raw tool input)."""
    name = VARIANTS[var]["tool"]["name"]
    uses = [b for b in reply.blocks if b.get("type") == "tool_use" and b.get("name") == name]
    if not uses:
        return None, "no_tool", None
    inp = uses[0].get("input") or {}
    key = "sentences" if name == "report_sentences" else "problems"
    ss = inp.get(key)
    if isinstance(ss, str):
        try:
            ss = json.loads(ss)
        except ValueError:
            return None, "bad_shape", inp
    if not isinstance(ss, list) or not all(isinstance(e, dict) and "n" in e for e in ss):
        return None, "bad_shape", inp
    flags, fail = {}, None
    seen = set()
    for e in ss:
        try:
            n = int(e["n"])
        except (TypeError, ValueError):
            fail = "bad_n"
            continue
        if n < 1 or n > n_sent:
            fail = fail or "bad_n"
            continue
        if n in seen:
            fail = fail or "dup_n"
        seen.add(n)
        if key == "sentences":
            if e.get("verdict") == "problem":
                flags[n] = {"class": e.get("class"), "reason": e.get("reason")}
        else:
            flags[n] = {"class": e.get("class"), "reason": e.get("reason")}
    if key == "sentences" and len(seen) < n_sent:
        fail = fail or "missing_rows"
    return flags, fail, inp


def read_unit(prov, unit, run, system):
    if spent() >= SPEND_CAP - 0.03:
        return {"uid": unit["uid"], "run": run, "ok": False, "error": "spend cap", "sentences": []}
    msgs = [{"role": "user", "content": layout(unit, prov.var)}]
    out, attempts, fail_final = None, [], None
    for attempt in range(2):
        try:
            r = prov.send(system, [VARIANTS[prov.var]["tool"]], msgs)
        except PV.ProviderError as e:
            attempts.append({"error": e.kind})
            fail_final = "provider_error"
            continue
        flags, fail, inp = parse(r, prov.var, len(unit["sentences"]))
        if r.stop_reason == "max_tokens":
            fail = "max_tokens"
        text = "".join(b.get("text") or "" for b in r.blocks if b.get("type") == "text")
        thinking = sum(1 for b in r.blocks if b.get("type") in ("thinking", "redacted_thinking"))
        row = {"run": run, "uid": unit["uid"], "variant": prov.var, "attempt": attempt, "seconds": r.seconds,
               "cost_usd": r.cost_usd, "usage": r.usage, "stop": r.stop_reason, "retries": r.retries,
               "thinking_blocks": thinking, "setting": prov.setting, "cache_system": CACHE_SYSTEM, "fail": fail, "tool_input": inp,
               "text": text[:2000], "n_sentences": len(unit["sentences"])}
        with LOCK:
            with open(os.path.join(HERE, "calls.jsonl"), "a") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
        attempts.append({"seconds": r.seconds, "fail": fail})
        fail_final = fail
        if flags is not None and fail not in ("max_tokens", "no_tool", "bad_shape"):
            out = flags
            break
    sents = []
    for i, s in enumerate(unit["sentences"], 1):
        e = (out or {}).get(i)
        sents.append({"sid": s["sid"], "n": i, "verdict": ("problem" if e else "ok") if out is not None else "missing",
                      "class": e["class"] if e else None, "reason": e["reason"] if e else None})
    return {"uid": unit["uid"], "run": run, "variant": prov.var, "attempts": attempts, "ok": out is not None,
            "fail": fail_final, "sentences": sents}


def load_units(files):
    us = []
    for f in files.split(","):
        us += json.load(open(os.path.join(HERE, f)))
    return us


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("variant", choices=sorted(VARIANTS))
    ap.add_argument("--units", default="units.json,units_skeptic.json,units_audit_lead.json")
    ap.add_argument("--sets", default="")
    ap.add_argument("--splits", default="")
    ap.add_argument("--uids", default="")
    ap.add_argument("--uidfile", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--parallel", type=int, default=4)
    a = ap.parse_args(argv)
    units = load_units(a.units)
    if a.sets:
        units = [u for u in units if u["set"] in set(a.sets.split(","))]
    if a.splits:
        units = [u for u in units if u["split"] in set(a.splits.split(","))]
    if a.uids:
        units = [u for u in units if u["uid"] in set(a.uids.split(","))]
    if a.uidfile:
        want = set(json.load(open(os.path.join(HERE, a.uidfile))))
        units = [u for u in units if u["uid"] in want]
    if a.limit:
        units = units[:a.limit]
    os.makedirs(os.path.join(HERE, "runs"), exist_ok=True)
    outp = os.path.join(HERE, "runs", a.run + ".jsonl")
    done = set()
    if os.path.exists(outp):
        done = {json.loads(x)["uid"] for x in open(outp) if x.strip() and json.loads(x).get("ok")}
    units = [u for u in units if u["uid"] not in done]
    system = open(os.path.join(HERE, VARIANTS[a.variant]["prompt"]), encoding="utf-8").read()
    prov = Prov(a.variant)
    print(f"{a.run}: {len(units)} units, variant {a.variant}, spent before ${spent():.4f}", flush=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.parallel) as ex:
        for res in ex.map(lambda u: read_unit(prov, u, a.run, system), units):
            with LOCK:
                with open(outp, "a") as f:
                    f.write(json.dumps(res, ensure_ascii=False) + "\n")
    print(f"{a.run}: done in {time.time() - t0:.1f} s; requests {prov.requests}; this run ${prov.spent:.4f}; "
          f"total ${spent():.4f}", flush=True)


if __name__ == "__main__":
    main()
