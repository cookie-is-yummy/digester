"""Step 4 (no model call): the record checker's v2 set as reader units. Each sentence is the answer's lone lead (its
v2 placement) on the saved tool results of its look record (the same results as units.json). Kept: the 37 false
(non-control, not near-copies; RT6 'not shown' and N34 'cannot prove' left out per its CORRECTIONS; N03 kept and
reported both ways) and the 21 true (not near-copies). Cells-only mark: its base a (C1a) verdict, cells_a."""
import json, os
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
rows = json.load(open(os.path.join(S, "mvp23/record_check/cases_v2_out.json")))
looks = {u["uid"]: u for u in json.load(open("units.json")) if u["kind"] == "look"}
out = []
for r in rows:
    if r["dup"] or "control" in r["class"] or r["id"] in ("RT6", "N34"):
        continue
    base = looks[f"{r['look']}:{r['key']}"]
    lab = "false" if r["truth"] == "F" else "true"
    s = {"sid": f"rec_{r['id']}:lead0", "where": "lead", "index": 0, "text": r["text"], "label": lab, "truth": r["truth"],
         "borderline": None, "fault": r["recount"], "cells_c1a": bool(r["cells_a"][0]), "cells_c1d": bool(r["cells_d"][0]),
         "c1a_reasons": r["cells_a"][1], "target": True}
    out.append({"uid": "rec_" + r["id"], "set": "record", "split": "unseen", "kind": "planted", "user": base["user"],
                "results": base["results"], "sentences": [s], "attack_class": r["class"], "rt": r["id"].startswith("RT")})
json.dump(out, open("units_record.json", "w"), indent=0, ensure_ascii=False)
import collections
print(len(out), collections.Counter((u["sentences"][0]["label"], u["sentences"][0]["cells_c1a"]) for u in out))
