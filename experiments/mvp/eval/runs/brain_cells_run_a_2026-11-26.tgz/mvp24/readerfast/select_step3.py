"""Step 3 sample (no model call): of the 106 rebuilt look units, those with no error result and no cited cell changed
(every marker path resolves to the same value in the saved and the rebuilt results). Of them: every unit where run 1
or run 2 of d flagged a true sentence cells-only keeps (the false alarms in question), then a seeded random fill to 40.
Writes step3_uids.json and step3_select.txt."""
import json, random, re, sys
sys.path.insert(0, ".")
import rf_reader as RF
old = {u["uid"]: u for u in json.load(open("units.json")) if u["kind"] == "look"}
new = {u["uid"]: u for u in json.load(open("rebuilt_units.json"))}
def val(results, path):
    rid = re.match(r"r\d+", path).group(0)
    segs = [(m.group(1), m.group(2)) for m in RF.SEG_RE.finditer(path[len(rid):])]
    for r in results:
        d = json.loads(r)
        if d.get("rid") == rid:
            v = RF.resolve(d, segs)
            return "MISSING" if v is RF.resolve.__defaults__ else v
    return "NO_RESULT"
ok, why = [], {}
for uid, u in old.items():
    n = new[uid]
    if any(json.loads(r).get("is_error") for r in n["results"]) and not any(json.loads(r).get("is_error") for r in u["results"]):
        why[uid] = "an error result now"; continue
    ch = []
    for s in u["sentences"]:
        for p in RF.PATH_RE.findall(s["text"]):
            a, b = val(u["results"], p), val(n["results"], p)
            if json.dumps(a, sort_keys=True, default=str) != json.dumps(b, sort_keys=True, default=str):
                ch.append(p)
    if ch:
        why[uid] = "cited cell changed: " + ", ".join(sorted(set(ch))[:4]); continue
    ok.append(uid)
def flagged_true(run):
    out = set()
    for x in open(f"runs/{run}.jsonl"):
        r = json.loads(x)
        sv = {s["sid"]: s for s in r["sentences"]}
        u = old.get(r["uid"])
        if not u: continue
        for s in u["sentences"]:
            if s["label"] == "true" and s["cells_c1a"] and sv.get(s["sid"], {}).get("verdict") == "problem":
                out.add(r["uid"])
    return out
fa = (flagged_true("d_r1") | flagged_true("d_r2")) & set(ok)
rest = sorted(set(ok) - fa)
random.Random(24).shuffle(rest)
pick = sorted(fa) + rest[:40 - len(fa)]
json.dump(pick, open("step3_uids.json", "w"))
lines = [f"rebuildable with no cited cell changed: {len(ok)} of {len(old)}",
         f"units with a d false alarm (run 1 or 2) among them: {len(fa)}; random fill (seed 24): {40 - len(fa)}",
         "set apart:"] + [f"  {k}: {v}" for k, v in sorted(why.items())]
open("step3_select.txt", "w").write("\n".join(lines) + "\n")
print("\n".join(lines[:3])); print(len(why), "set apart")
