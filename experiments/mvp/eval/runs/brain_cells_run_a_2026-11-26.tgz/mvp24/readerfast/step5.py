"""Step 5 (no model call): what each way of running the reader would need, from the look answers (look 1 and look 2
first forms, 106 answers; planted units are left out). Reader runs: d_r1, d_r2 (and v2 frozen for the line beside).
Per-answer seconds as mvp23/reader/timing.py: the recorded turn (as run) with its recorded repairs swapped for one
reword round (the median recorded repair request) when a sentence fails cells-only or is flagged, plus the reader."""
import json, os, statistics as st, sys
sys.path.insert(0, ".")
import rf_score as SC
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
units = SC.all_units()
U = {u["uid"]: u for u in units if u["kind"] == "look"}
recs = {}
for look, d in LOOKS.items():
    for p in sorted(os.listdir(d)):
        if p.endswith(".json") and p != "summary.json":
            r = json.load(open(os.path.join(d, p)))
            if r.get("forms"):
                recs[f"{look}:{r['key']}"] = r
ga = lambda q: any(isinstance(b, dict) and b.get("name") == "give_answer" for b in q.get("blocks") or [])
rep = [q["seconds"] for r in recs.values() for q in [q for q in r["requests"] if ga(q)][1:]]
REWORD = st.median(rep)
def p90(xs): xs = sorted(xs); return xs[int(0.9 * (len(xs) - 1))]
L = [f"reword round = median recorded repair request {REWORD:.2f} s ({len(rep)} repairs)"]
for name, spec in (("d run 1", "d_r1"), ("d run 2", "d_r2"), ("b run 1 (thinking off)", "b_r1"), ("a run 1", "a_r1"), ("v2 frozen run 1", "mvp23:dev_ad_v2+mvp23:test_r1"),
                   ("v2 frozen run 2 (look 2 only)", "mvp23:test_r2")):
    run = SC.load_run(spec)
    rs = [r for r in SC.rows(units, run) if r["kind"] == "look"]
    sec = {c["uid"]: c["seconds"] for c in SC.calls_of(spec) if c["uid"] in U}
    uids = sorted({r["uid"] for r in rs})
    fl_ans = [u for u in uids if any(r["flag"] for r in rs if r["uid"] == u)]
    flags = [r for r in rs if r["flag"]]
    lab = [r for r in flags if r["label"] in ("true", "false")]
    right = [r for r in lab if r["label"] == "false"]
    kept = [r for r in lab if r["cells_c1a"]]
    kright = [r for r in kept if r["label"] == "false"]
    fth = [r for r in rs if r["label"] == "false" and r["cells_c1a"]]
    ans_f = sorted({r["uid"] for r in fth})
    L.append(f"{name}: {len(uids)} answers; answers with at least one flag {len(fl_ans)} ({len(fl_ans)/len(uids):.0%}); "
             f"flags {len(flags)} ({len(flags)-len(lab)} on no-claim / cannot-prove sentences); of the {len(lab)} on "
             f"labelled sentences, right (on a false sentence) {len(right)} ({len(right)/max(1,len(lab)):.0%}); on "
             f"sentences cells-only keeps: {len(kright)} right of {len(kept)} ({len(kright)/max(1,len(kept)):.0%})")
    L.append(f"   answers holding a false sentence cells-only lets through: {len(ans_f)}; of them flagged on that "
             f"sentence: {sum(1 for u in ans_f if any(r['flag'] for r in fth if r['uid'] == u))}")
    base, inline, inline2, need_n = [], [], [], 0
    for u in uids:
        if u not in sec: continue
        r = recs[u]; g = [q for q in r["requests"] if ga(q)]
        rec_rep = sum(q["seconds"] for q in g[1:])
        sents = [x for x in rs if x["uid"] == u]
        need = any((not x["cells_c1a"]) or x["flag"] for x in sents)
        need_cells = any(not x["cells_c1a"] for x in sents)
        need_n += need
        t0 = r["seconds"] - rec_rep + (REWORD if need_cells else 0.0)   # cells only, no reader
        base.append(t0)
        t = r["seconds"] - rec_rep + sec[u] + (REWORD if need else 0.0)
        inline.append(t); inline2.append(t + (sec[u] if need else 0.0))
    rsec = [sec[u] for u in uids if u in sec]
    L.append(f"   reader seconds per answer: median {st.median(rsec):.2f}, p90 {p90(rsec):.2f}, max {max(rsec):.2f}")
    L.append(f"   cells only (no reader, reword when cells drop): median {st.median(base):.2f} s, p90 {p90(base):.2f}")
    L.append(f"   reader inline (before sending) + one reword when needed ({need_n} of {len(base)}): median "
             f"{st.median(inline):.2f} s, p90 {p90(inline):.2f}; with a second reader call on the reword: median "
             f"{st.median(inline2):.2f}, p90 {p90(inline2):.2f}")
    L.append(f"   reader after sending (test tool / log only): the answer's seconds are the cells-only line; the "
             f"reader's {st.median(rsec):.2f} s median runs after it")
open("step5.txt", "w").write("\n".join(L) + "\n")
print("\n".join(L))
