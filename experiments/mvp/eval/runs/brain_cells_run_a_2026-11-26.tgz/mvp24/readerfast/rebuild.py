"""Step 3 (no model call): re-run every saved tool call of the 106 held-out first forms (look 1 and look 2) on TODAY's
read tools over the made-up library (eval_brain.Harness.scratch under this folder, the same turn as the live run:
message, screen "", the fake search engine and learned backend), and compare each result with the saved one.
Writes rebuilt_units.json (the units with today's results; sentences unchanged) and rebuild_diff.json / .txt."""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, "/home/user/digester/experiments")
LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}

from mvp import eval_brain as EB  # noqa: E402

H = EB.Harness.scratch(base=os.path.join(HERE, "rebuild_lib"))
from mvp.brain import loop as BL, tools as TL  # noqa: E402
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned  # noqa: E402


def present(env):
    env = {k: v for k, v in env.items() if k not in ("cost_usd", "took_ms")}
    return BL.present(env)


def diff(a, b, path=""):
    out = []
    if isinstance(a, dict) and isinstance(b, dict):
        for k in sorted(set(a) | set(b)):
            if k not in a or k not in b:
                out.append(f"{path}.{k}: {'added' if k not in a else 'removed'}")
            else:
                out += diff(a[k], b[k], f"{path}.{k}")
    elif isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            out.append(f"{path}: {len(a)} rows -> {len(b)}")
        for i, (x, y) in enumerate(zip(a, b)):
            out += diff(x, y, f"{path}[{i}]")
    elif a != b:
        out.append(f"{path}: {json.dumps(a, ensure_ascii=False)[:80]} -> {json.dumps(b, ensure_ascii=False)[:80]}")
    return out


units = {u["uid"]: u for u in json.load(open(os.path.join(HERE, "units.json"))) if u["kind"] == "look"}
new_units, report = [], {}
for look, d in LOOKS.items():
    for p in sorted(os.listdir(d)):
        if not p.endswith(".json") or p == "summary.json":
            continue
        rec = json.load(open(os.path.join(d, p)))
        if not rec.get("forms"):
            continue
        uid = f"{look}:{rec['key']}"
        last = None
        plan = ((rec.get("screen") or {}).get("last_answer") or {}).get("plan") or []
        if plan:   # the last window as the live run had it: the previous answer's first counted result, re-run
            t0 = H.turn("", screen="", search=FakeEngine(), learned=fake_learned)
            for c in plan:
                r0 = TL.call(t0, c["tool"], c["args"])
                if isinstance(r0, dict) and r0.get("rid") in t0.windows:
                    last = t0.windows[r0["rid"]]
                    break
        t = H.turn(rec["message"], screen="", last_window=last, search=FakeEngine(), learned=fake_learned)
        old, new, notes = [], [], []
        for c in rec["calls"]:
            r = TL.call(t, c["name"], c["args"])
            if not c.get("result"):
                continue
            old.append(present(c["result"]))
            new.append(present(r) if isinstance(r, dict) and "sheet" in r else json.dumps(r, ensure_ascii=False,
                                                                                         sort_keys=True))
            if r.get("rid") != c["result"].get("rid"):
                notes.append(f"rid {c['result'].get('rid')} -> {r.get('rid')}")
        ds = []
        for o, n in zip(old, new):
            ds += diff(json.loads(o), json.loads(n), json.loads(o).get("rid") or "?")
        fr = [(json.loads(o).get("meta") or {}).get("hidden", {}).get("friends") for o in old]
        fn = [(json.loads(n).get("meta") or {}).get("hidden", {}).get("friends") for n in new]
        report[uid] = {"diffs": ds, "notes": notes, "friends_old": fr, "friends_new": fn}
        new_units.append(dict(units[uid], results=new))
json.dump(new_units, open(os.path.join(HERE, "rebuilt_units.json"), "w"), indent=0, ensure_ascii=False)
json.dump(report, open(os.path.join(HERE, "rebuild_diff.json"), "w"), indent=1, ensure_ascii=False)
print(len(new_units), "units rebuilt")
