# runa progress
- step 0: read brief and eval_brain run mode. Options match the task (--set fresh --half a --check cells --out --parallel --max-usd --limit). Ledger: MVP_LEDGER_HOME=/home/user/digester/data/mvp, MVP_CLAUDE_CAP_USD=25. Prompt default brain_v3 (MVP_BRAIN_PROMPT unset).
- next: smoke run (--limit 3) into runa/smoke, then full run into runa/run1.
- step 1: smoke run done (3 messages, check=cells in records and settings, $0.0084, all model leads). Full run starting into runa/run1.
- step 2: full run done, exit 0, 65 records + summary. Copied to run1_raw before audit.
- step 3: audit (no change), read, analysis done; summary.txt written. Spend $0.1078.
- step 4: summary.txt corrected (drop-reason classes, time-up refusals, N049 wording). Done.
