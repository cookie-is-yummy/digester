# recounta progress
- step 0: read brief; copied mvp22/raw tools (lib, rc, jcore, assemble, tally) into recounta/.
- step 1: dumped run1 (look_dump.txt), read every record, recounted the open facts from the rows (first/last items, hours, weekdays, saves, private rows, shorts). Next: write j_a.py judgments, assemble, answers, tally.
- step 2: wrote j_a.py (judgments), assemble_a.py -> sentences.json (204 rows: 171 first, 29 repair, 4 code; 152 sent), a_a.py -> answers.json (65), tally_a.py -> numbers.txt, sent_faults.txt. pin_tree status clean. Next: advisor check, then report.
- step 3: advisor fixes done (computed 716 and 651, three-way origin from tool results, strict-cause labels, scope/private line read, headline). Files final.
