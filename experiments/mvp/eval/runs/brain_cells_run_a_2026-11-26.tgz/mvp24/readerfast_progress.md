# readerfast progress (mvp24)
Evidence: S/mvp24/readerfast/. Spend: $1.1862 (1952 requests), cap $1.25. No repo change.
- [x] 1 step1_where.py/.txt; ttft_probe.py (9 streamed calls); ctl_v2 timing control (14)
- [x] 2 a_r1, b_r1, c_r1 (357 units), e_r1 (174, stage 1 by rule), d_r1 (357), d_r2 (106 looks, cached). pick_rule.txt, freeze_d.txt, table.txt
- [x] 3 rebuild.py -> rebuilt_units.json, rebuild_diff.json; select_step3.py; d_new_r1 (40); step3_table.txt; friends cases step3_friends_rc.txt
- [x] 4 u4_rc_r1 (94 reader_check units), u4_rec_r1 (58 record_check units); step4_table.txt
- [x] 5 step5.py/.txt
- [x] report.txt written
Read before freezing d: brief, DECISIONS last 3 sections, mvp23 reader table/scoring/prompt, reader_check/report.txt (whole), record_check/report.txt (to line 140). Case files opened only after freeze_d.txt.
