"""Hand reading of every answer of run1 AS SENT, by experiments/mvp/eval/brain_reading_rubric.md and the brief's
founder rules. base = the grade before the truth of the sentences is counted; the grade is then poor when the answer
holds a false or wrongly based sentence (rubric), under each reading (primary, strict, lenient).
Item cards, charts and ask-backs are not rendered in this slice (brain/answer.py docstring), so the answer is read
as recorded in answer.text.
key: (base, answers, means, offer, brief, cause_if_poor, note)"""
import json

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp24/"
A = {
"N001.0": ("acceptable", 1, 1, 1, 1, None, "cooking up 40 points, art down 30: a reading; but it leaves out all gaming (Minecraft builds too) where they said the gaming clips"),
"N001.1": ("good", 1, 1, 1, 1, None, "'why' answered with what the rows hold: one channel, Pan Theory, 2 to 30 in four weeks; the share point repeats the lead"),
"N002.0": ("acceptable", 1, 0, 1, 1, None, "area shares and the top channel; no picture of the person (one hobby at a time)"),
"N004.0": ("poor", 0, 0, 0, 1, "tool gap", "'the summer' not read and 'this summer' refused as after the export end; nothing given instead"),
"N005.0": ("poor", 0, 0, 0, 1, "planning", "no per-year channel or theme count was asked for; the answer is Pan Theory (cooking), opened in every year; the lead names Brick Realm, which has no rows 2023 to 2025"),
"N005.1": ("acceptable", 1, 1, 1, 1, None, "2021 highest, then the fall; leaves out the 2026 return (79)"),
"N007.0": ("good", 1, 1, 1, 1, None, "speedruns gone this year, minecraft 91 to 13"),
"N008.0": ("poor", 0, 0, 0, 1, "code lead", "asked month by month, got a bare total; the model's true month lead was dropped (free_number) twice and its points (unnamed_owner)"),
"N008.1": ("poor", 0, 0, 1, 1, "planning", "no October breakdown was read: says nothing of what October held; 92 and 61 are the year's counts and 'started in it' is wrong for Pixel Pencil"),
"N010.0": ("poor", 0, 0, 0, 1, "tool gap", "the tool read 'last summer' as summer 2026, so there is no comparison; summer 2025 had 16"),
"N010.1": ("poor", 0, 0, 1, 1, "tool gap", "same window fault: art of summer 2026 only, no last summer (watercolor carried 2025)"),
"N012.0": ("good", 1, 1, 1, 1, None, "math took over, gaming 93% to 9%, what arrived and what stopped"),
"N013.0": ("acceptable", 1, 0, 1, 1, None, "right date and channel; quotes the instruction-like title as data (shortened by the tool)"),
"N013.1": ("good", 1, 1, 1, 1, None, "first video, date, channel, and all 163"),
"N014.0": ("poor", 0, 0, 0, 1, "code lead", "asked for the last cooking video, got the all-time cooking total; the model's true lead was dropped twice (uncited_name)"),
"N016.0": ("acceptable", 1, 0, 0, 1, None, "right item and date; no offer"),
"N017.0": ("acceptable", 1, 0, 1, 1, None, "ranked channels with a theme share; no reading"),
"N017.1": ("acceptable", 1, 0, 1, 1, None, "ranked channels; no reading (Brick Realm small now)"),
"N018.0": ("good", 1, 1, 1, 1, None, "90 videos, all speedruns, peak year 2022"),
"N018.1": ("acceptable", 1, 0, 1, 1, None, "163, 91 in 2021 and 13 in 2026; no reading against Frame Perfect"),
"N019.0": ("good", 1, 1, 1, 1, None, "Clip Factory and Gaming Daily new, gaming clips 35% of the fall"),
"N022.0": ("acceptable", 1, 0, 1, 1, None, "ranked themes with counts"),
"N022.1": ("good", 1, 1, 1, 1, None, "two themes, one channel each"),
"N024.0": ("acceptable", 1, 0, 1, 0, None, "the split with shares; the scope line lists four 'only' filters"),
"N024.1": ("acceptable", 1, 0, 1, 1, None, "art 54 of 62, watercolor on Wet Paper; no reading"),
"N027.0": ("poor", 0, 0, 1, 1, "wording", "never says day or night: 'your busiest hour is 16'; 716 of 723 fell between 2 pm and 8 pm, 1 at 9 pm (the hours point was dropped)"),
"N029.0": ("acceptable", 1, 0, 1, 1, None, "gaming 44% of Saturdays; nothing set against other days"),
"N032.0": ("acceptable", 1, 1, 1, 1, None, "'Not much' with the weekend share; the points do not show the mix is the same"),
"N033.0": ("acceptable", 1, 0, 1, 1, None, "66 Shorts, 61 from Clip Factory; not set against October's 142"),
"N033.1": ("good", 1, 1, 1, 1, None, "October is the only month with any: far more than usual; lead wording clumsy"),
"N034.0": ("acceptable", 1, 0, 1, 1, None, "long videos by area and theme with channels"),
"N034.1": ("acceptable", 1, 0, 0, 1, None, "short ones right after the correction; offer 'Only long videos?' goes back to the reading they rejected; lower-case 'art and design'"),
"N035.0": ("acceptable", 1, 1, 1, 1, None, "YouTube far more, with counts"),
"N035.1": ("acceptable", 1, 0, 1, 1, None, "four watercolor reels, one account; the point repeats the lead"),
"N036.0": ("acceptable", 1, 0, 1, 1, None, "a bare count (the theme point was dropped: link)"),
"N038.0": ("poor", 0, 0, 0, 1, "code lead", "never says the record holds no likes; a bare save count (the model's lead was dropped: link; its two kept points were not sent under the code lead)"),
"N041.0": ("acceptable", 1, 0, 0, 1, None, "6, by platform; 'of what you saved' is clumsy; 'By month?' on 4 weeks"),
"N041.1": ("poor", 0, 0, 0, 1, "tool gap", "names none of the three: the item cards the model chose are not rendered in this slice"),
"N042.0": ("acceptable", 1, 1, 0, 1, None, "no likes to set against six saves; 'And in October?' adds nothing (all saves are October)"),
"N044.0": ("acceptable", 1, 0, 0, 1, None, "72 and two titles (the other cards are not rendered); 'Only long videos?' adds nothing (all are long)"),
"N044.1": ("poor", 0, 0, 0, 1, "tool gap", "'these 5 come next' with no five: item cards not rendered"),
"N045.0": ("acceptable", 1, 0, 1, 1, None, "6 from Limit Lane, two titles; weekday share is filler"),
"N048.0": ("acceptable", 1, 0, 0, 1, None, "finds the post and its date"),
"N048.1": ("poor", 0, 0, 0, 1, "checker drop", "the point that quoted what it said about flour was dropped (uncited_number, wrong_name, watch_time); what went out does not answer"),
"N049.0": ("poor", 0, 0, 0, 1, "code lead", "'Here's what I found.' and nothing rendered; the model's true lead and its ask-back between three dates were dropped"),
"N052.0": ("acceptable", 1, 0, 1, 1, None, "3 cooking videos with the private line"),
"N052.1": ("poor", 0, 0, 1, 1, "wording", "says it can't tell why, while the private line is the reason (23 of the spring's 26 are the private topic)"),
"N053.0": ("poor", 0, 0, 0, 1, "checker drop", "asked 'every week?': the true point on 50 days was dropped (outside_in_history); no yes or no"),
"N053.1": ("poor", 0, 0, 0, 1, "tool gap", "compare with the named topic returned no_match, then the model said the history has no match for it, after 50 had just been counted"),
"N054.0": ("acceptable", 1, 0, 1, 1, None, "the one video shown, with the private line"),
"N055.0": ("poor", 0, 0, 0, 1, "wording", "never gives the count (one save is a friend's post); talks about the other saves"),
"N056.0": ("poor", 0, 0, 0, 1, "checker drop", "the true lead (opens only, not how far) was dropped (uncited_claim); what went out is a ranking over a tie"),
"N057.0": ("poor", 0, 0, 0, 1, "wording", "never says minutes are not in the export; gives a video count instead"),
"N062.0": ("good", 1, 1, 1, 1, None, "no, with where the history starts"),
"N063.0": ("acceptable", 1, 0, 1, 1, None, "the whole of October, said as such (the set's own reading)"),
"N063.1": ("acceptable", 1, 0, 1, 1, None, "the second point repeats the lead as a share"),
"N064.0": ("acceptable", 1, 1, 1, 1, None, "whole 2023 for mid 2023, with the June start of the math"),
"N066.0": ("acceptable", 1, 0, 1, 1, None, "last 7 days of the export, said as such"),
"N066.1": ("acceptable", 1, 1, 0, 1, None, "both export ends and the newest item; no offer"),
"N067.0": ("poor", 0, 0, 0, 1, "wording", "never says November has no rows; the second point is cut off"),
"N068.0": ("acceptable", 1, 0, 0, 1, None, "one match, the caption's instruction ignored; no offer"),
"N069.0": ("acceptable", 1, 0, 1, 1, None, "title and date, no channel; instruction-like title quoted as data"),
"N109.0": ("poor", 0, 0, 0, 1, "wording", "mostly what it cannot do; the rows hold a count (one friend's post saved), counted and never shown"),
"N112.0": ("poor", 0, 0, 0, 1, "wording", "never says the hour: all four reels were opened at 8 am, so yes, mornings"),
"N113.0": ("acceptable", 1, 0, 1, 1, None, "no likes, then the opened mix"),
}
BAD = ("false", "wrongly_based")
rows = json.load(open(S + "recounta/sentences.json"))
recs = {json.load(open(p))["key"]: json.load(open(p)) for p in __import__("glob").glob(S + "runa/run1/N*.json")}
out = []
for k in sorted(recs):
    base, ans, means, offer, brief, cause, note = A[k]
    r = recs[k]
    sent = [x for x in rows if x["key"] == k and x["sent"]]
    fp = [x for x in sent if x["sent_truth"] in BAD]
    fs = [x for x in sent if x["sent_truth_strict"] in BAD]
    fl = [x for x in sent if x["sent_truth_lenient"] in BAD]

    def grade(f):
        return "poor" if f else base

    def why(f, strict_only=False):
        if cause:
            return cause
        if f:
            if strict_only and all(x["sent_truth"] not in BAD for x in f):
                t = " ".join((x["sent_borderline"] or "") for x in f)
                return ("strict reading: private rows (only/all over the rows shown)" if "(only/all)" in t else
                        "strict reading: base said as 'of what you opened' on filtered videos" if "(base)" in t else
                        "strict reading: " + (f[0]["sent_borderline"] or "")[len("strict: "):][:60])
            o = {x["sent_origin"].split(":")[0] for x in f}
            if "neighbour drop" in o:
                return "checker drop (a neighbour's drop left a wrongly based sentence)"
            if any(x.startswith("tool gave") for x in o):
                return "tool gap (the tool's picture led to a wrongly based sentence)"
            return "wording (the model's unchecked framing went out)"
        return None
    out.append({"key": k, "message": r["message"], "lead_source": r["lead_source"], "sent_text": r["answer"]["text"],
                "private_line": r["answer"].get("private_line"), "base_grade": base,
                "grade": grade(fp), "grade_strict": grade(fs), "grade_lenient": grade(fl),
                "answers_question": bool(ans), "says_what_numbers_mean": bool(means), "carries_offer": bool(offer), "brief": bool(brief),
                "false_sent": len(fp), "false_sent_strict": len(fs), "false_sent_lenient": len(fl),
                "poor_cause": why(fp) if grade(fp) == "poor" else None,
                "poor_cause_strict": why(fs, True) if grade(fs) == "poor" else None,
                "faults_sent": [{"where": "%s%d" % (x["where"], x["index"]), "text": x["text_plain"], "truth": x["sent_truth"],
                                 "strict": x["sent_truth_strict"], "lenient": x["sent_truth_lenient"], "fault": x["sent_fault"],
                                 "borderline": x["sent_borderline"], "origin": x["sent_origin"]} for x in fs],
                "note": note})
json.dump(out, open(S + "recounta/answers.json", "w"), indent=1)
print(len(out), "answers")
