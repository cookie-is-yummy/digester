"""Run cases.py through the tree's checker in cells and full mode, as a point under the carrier and alone as a lead."""
import json, os, sys
TREE = sys.argv[1]
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(TREE, "experiments"))
sys.path.insert(0, HERE)
from mvp.brain import verify as V
from mvp import eval_brain as E
import cases as C
h = E.Harness.scratch(base=os.path.join(S, "mvp24/pincheck/_lib_cases"))
built = {}
def turn_of(key):
    if key not in built:
        rec = json.load(open(os.path.join(S, "mvp20/tune/heldout", key + ".json")))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        built[key] = (results, V.Turn.of(t))
    return built[key]
def run(form, key, mode, where):
    results, vt = turn_of(key)
    v = V.check_answer(form, results, vt, mode=mode)
    o = next(o for o in v.outcomes if o.where == where and o.index == 0)
    lead_ok = v.lead_ok
    return {"kept": bool(o.kept), "reasons": list(o.reasons), "details": [str(d)[:140] for d in o.details][:3],
            "insight_off": (o.notes or {}).get("insight_off"), "insight": o.insight, "lead_ok": lead_ok,
            "private": v.private_line}
rows = []
carrier_check = {}
for key, lead in C.CARRIER.items():
    for mode in ("cells", "full"):
        r = run({"lead": lead, "points": []}, key, mode, "lead")
        carrier_check[(key, mode)] = r
for cid, key, truth, kind, s, note in C.CASES:
    row = {"id": cid, "rec": key, "truth": truth, "kind": kind, "text": s, "note": note}
    for mode in ("cells", "full"):
        row[f"P_{mode}"] = run({"lead": C.CARRIER[key], "points": [s]}, key, mode, "point")
        row[f"L_{mode}"] = run({"lead": s, "points": []}, key, mode, "lead")
    rows.append(row)
json.dump({"carriers": {f"{k}|{m}": v for (k, m), v in carrier_check.items()}, "rows": rows},
          open(os.path.join(S, "mvp24/pincheck/cases_out.json"), "w"), indent=1, ensure_ascii=False)
print("CARRIERS:")
for (k, m), r in carrier_check.items():
    print(f"  {k} {m}: kept={r['kept']} {r['reasons']}")
F = [r for r in rows if r["truth"] == "F"]; T = [r for r in rows if r["truth"] == "T"]
print(f"false {len(F)}, true {len(T)}")
for mode in ("cells", "full"):
    fo = [r for r in F if r[f"P_{mode}"]["kept"] or r[f"L_{mode}"]["kept"]]
    tl = [r for r in T if not (r[f"P_{mode}"]["kept"] and r[f"L_{mode}"]["kept"])]
    print(f"== {mode}: false out (as point or lead) {len(fo)}; true refused (as point or lead) {len(tl)}")
    for r in fo:
        print(f"   OUT {r['id']} {r['kind']}: P={'kept' if r[f'P_{mode}']['kept'] else r[f'P_{mode}']['reasons']} "
              f"L={'kept' if r[f'L_{mode}']['kept'] else r[f'L_{mode}']['reasons']} off={r[f'P_{mode}']['insight_off'] or r[f'L_{mode}']['insight_off']} | {r['text']}")
    for r in tl:
        print(f"   LOST {r['id']} {r['kind']}: P={'kept' if r[f'P_{mode}']['kept'] else r[f'P_{mode}']['reasons']} "
              f"L={'kept' if r[f'L_{mode}']['kept'] else r[f'L_{mode}']['reasons']} | {r['text']}")
