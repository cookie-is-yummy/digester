"""Every planted case form and every held-out record form (both looks) through check_answer of the tree given,
in the mode given ('none' = no mode argument), as canonical JSON lines."""
import glob, json, os, sys
from datetime import date
TREE, MODE, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, os.path.join(TREE, "experiments"))
os.environ.pop("MVP_BRAIN_CHECK", None)
if MODE == "env_full":
    os.environ["MVP_BRAIN_CHECK"] = "full"
from mvp.brain import verify as V, planted as P
from mvp import eval_brain as E
assert V.__file__.startswith(TREE), V.__file__
def ca(form, led, turn):
    if MODE in ("none", "env_full"):
        return V.check_answer(form, led, turn)
    return V.check_answer(form, led, turn, mode=MODE)
def canon(v):
    return {"outcomes": [[o.where, o.index, o.kept, list(o.reasons), list(o.details), o.sent, o.insight,
                          getattr(o, "hidden_rank", None)] for o in v.outcomes],
            "private": v.private_line, "repair": v.repair, "lead_ok": v.lead_ok, "items": v.items,
            "outside": v.outside, "form_error": v.form_error}
rows = []
data = P.load()
for c in data["cases"]:
    t = c.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    for i, f in enumerate(c.get("forms") or [c["form"]]):
        turn = V.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today, names=list(t.get("names") or []),
                      sensitive_names=list(t.get("sensitive_names") or []))
        rows.append({"k": f"planted:{c['id']}:{i}", "v": canon(ca(f, V.Ledger(data["ledgers"][c["ledger"]]), turn))})
h = E.Harness.scratch(base=os.path.join(S, "mvp24/pincheck/_lib_" + os.path.basename(TREE)))
for look in ("mvp20/tune/heldout", "mvp20/fix/heldout_run"):
    for p in sorted(glob.glob(os.path.join(S, look, "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        vt = V.Turn.of(t)
        for fi, form in enumerate(rec.get("forms") or []):
            rows.append({"k": f"{look}:{rec['key']}:{fi}", "v": canon(ca(form, results, vt))})
with open(OUT, "w") as f:
    for r in rows:
        f.write(json.dumps(r, sort_keys=True, default=str, ensure_ascii=False) + "\n")
print(len(rows))
