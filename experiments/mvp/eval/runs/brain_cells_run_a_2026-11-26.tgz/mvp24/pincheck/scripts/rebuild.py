"""Step 4: rebuild every saved held-out answer (both looks) in a mode with loop._finish, from the saved forms
(verdicts re-checked in that mode); report any code or plain lead that carries a point."""
import copy, glob, json, os, sys, types
TREE, MODE = sys.argv[1], sys.argv[2]
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import verify as V, loop as BL
from mvp import eval_brain as E
h = E.Harness.scratch(base=os.path.join(S, "mvp24/pincheck/_lib_rebuild_" + MODE))
cm = V.check_mode(MODE)
src, bad, n, model_pts_under_code, forms_n = {}, [], 0, 0, {}
lines = []
for look in ("mvp20/tune/heldout", "mvp20/fix/heldout_run"):
    for p in sorted(glob.glob(os.path.join(S, look, "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        vt = V.Turn.of(t)
        forms = rec.get("forms") or []
        # cells mode: the repair form exists only when the cells verdict of form 0 asks for a repair
        verdicts = []
        for fi, f in enumerate(forms):
            v = V.check_answer(f, results, vt, mode=cm)
            verdicts.append(v)
            if not v.repair:
                break
        r2 = {"forms": forms[:len(verdicts)]}
        BL._finish(r2, types.SimpleNamespace(results=results), vt, verdicts, cm)
        n += 1
        s = r2["lead_source"]
        src[s] = src.get(s, 0) + 1
        a = r2["answer"]
        lines.append(f"{look.split('/')[1]} {rec['key']} {s} pts={len(a['points'])} forms_used={len(verdicts)}/{len(forms)}"
                     f" | {a['text'][:300]!r}")
        if s in ("code", "plain") and a["points"]:
            bad.append((rec["key"], s, a["points"]))
        if s in ("code", "plain") and r2.get("code_lead") and r2["code_lead"].get("points"):
            model_pts_under_code += 1
print(json.dumps({"mode": MODE, "answers": n, "lead_source": src, "code_or_plain_lead_with_points": bad,
                  "code_dict_with_points": model_pts_under_code}, indent=1))
open(os.path.join(S, f"mvp24/pincheck/rebuild_{MODE}.txt"), "w").write("\n".join(lines) + "\n")
