"""Print one held-out record's results compactly: every leaf path = value (lists capped)."""
import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/tune/heldout/"
rec = json.load(open(S + sys.argv[1] + ".json"))
cap = int(sys.argv[2]) if len(sys.argv) > 2 else 6
print("MSG:", rec["message"]); print("SCREEN:", rec.get("screen"))
def walk(x, p):
    if isinstance(x, dict):
        for k, v in x.items():
            if k in ("ref",):
                continue
            walk(v, f"{p}.{k}")
    elif isinstance(x, list):
        for i, v in enumerate(x[:cap]):
            walk(v, f"{p}[{i}]")
        if len(x) > cap:
            print(f"{p}: ... {len(x)} rows")
    else:
        print(f"{p} = {x!r}"[:160])
for c in rec["calls"]:
    if not c.get("rid"):
        continue
    r = c["result"]
    print("== CALL", c["name"], json.dumps(c["args"])[:300])
    print("META", json.dumps({k: r["meta"].get(k) for k in ("window_said", "base", "filters_said", "order", "hidden", "rows_of")})[:400])
    walk(r.get("sheet"), c["rid"])
print("FORM0:", json.dumps((rec.get("forms") or [None])[0])[:1200])
