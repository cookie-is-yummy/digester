"""Dump every framing-class false planted case with its text, target, class string and its cells-mode outcome."""
import json, os, sys, re
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import planted as P, verify as V
data = P.load()
cls = P.classes()
out = []
for c in data["cases"]:
    if c["expect"] == "kept":
        continue
    k = cls.get(c["id"], {}).get("class")
    kept, reasons, v = P.outcome(c, data["ledgers"], "cells")
    form = c.get("form") or (c.get("forms") or [{}])[0]
    tgt = c.get("target") or "point:0"
    kind, _, n = tgt.partition(":")
    if kind == "lead":
        text = form.get("lead")
    elif kind == "point":
        text = (form.get("points") or [None] * 9)[int(n or 0)]
    else:
        text = json.dumps(form)[:300]
    out.append({"id": c["id"], "class": k, "src": c.get("source"), "pclass": c.get("class"), "target": tgt,
                "kept_cells": kept, "private": v.private_line, "reasons": reasons, "text": text,
                "lead": form.get("lead") if kind != "lead" else None, "ledger": c["ledger"]})
json.dump(out, open(sys.argv[2], "w"), indent=1, ensure_ascii=False)
