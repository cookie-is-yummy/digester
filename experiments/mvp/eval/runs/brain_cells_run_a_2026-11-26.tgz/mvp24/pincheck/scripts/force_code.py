"""Step 4, forced: every planted form and every held-out form, checked in cells mode, sent through fallback.answer and
answer.build in cells mode as if the lead had failed: no point may come out. Then the guard by hand and the mode sources."""
import glob, json, os, sys
from datetime import date
TREE = sys.argv[1]
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, os.path.join(TREE, "experiments"))
os.environ.pop("MVP_BRAIN_CHECK", None)
from mvp.brain import verify as V, planted as P, fallback as FB, answer as A
from mvp import eval_brain as E
n = with_kept_points = bad = 0
full_with_pts = 0
def one(form, led, turn):
    global n, with_kept_points, bad, full_with_pts
    if not isinstance(led, V.Ledger):
        led = V.Ledger(led)
    v = V.check_answer(form, led, turn, mode="cells")
    if any(o.where == "point" and o.kept for o in v.outcomes):
        with_kept_points += 1
    code = FB.answer(led, v, turn, mode="cells")
    out = A.build(led, code=code, mode="cells")
    n += 1
    if code.get("points") or out["points"]:
        bad += 1
    vf = V.check_answer(form, led, turn, mode="full")
    if FB.answer(led, vf, turn, mode="full").get("points"):
        full_with_pts += 1
data = P.load()
for c in data["cases"]:
    t = c.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    for f in c.get("forms") or [c["form"]]:
        one(f, data["ledgers"][c["ledger"]], V.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today,
                                                     names=list(t.get("names") or []),
                                                     sensitive_names=list(t.get("sensitive_names") or [])))
h = E.Harness.scratch(base=os.path.join(S, "mvp24/pincheck/_lib_force"))
for look in ("mvp20/tune/heldout", "mvp20/fix/heldout_run"):
    for p in sorted(glob.glob(os.path.join(S, look, "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        tt = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        for f in rec.get("forms") or []:
            one(f, results, V.Turn.of(tt))
print(f"forced code path: {n} forms ({with_kept_points} with a kept point in cells mode); code or built answer with a "
      f"point in cells: {bad}; full mode, code lead with model points: {full_with_pts}")
# the guard by hand
led = V.Ledger(data["ledgers"][data["cases"][0]["ledger"]])
fake = {"lead": "A code lead.", "how": "template", "rid": None, "items": [], "private_line": False, "points": ["P1."]}
print("build(code with a point, mode=cells):", A.build(led, code=fake, mode="cells")["points"])
print("build(code with a point, mode=full):", A.build(led, code=fake, mode="full")["points"])
os.environ["MVP_BRAIN_CHECK"] = "cells"
print("env cells, mode None:", A.build(led, code=fake)["points"], V.check_mode(None).name,
      "| env cells, mode full:", A.build(led, code=fake, mode="full")["points"])
os.environ["MVP_BRAIN_CHECK"] = "bogus"
try:
    V.check_mode(None); print("env bogus: accepted")
except ValueError as e:
    print("env bogus: ValueError")
