import json, os, sys
sys.argv = sys.argv[:2]
TREE = sys.argv[1]
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import verify as V
from mvp import eval_brain as E
h = E.Harness.scratch(base=os.path.join(S, "mvp24/pincheck/_lib_cases"))
rec = json.load(open(os.path.join(S, "mvp20/tune/heldout/D10.0.json")))
t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
res = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")}
lead = "In the 4 weeks up to 30 October 2026, gaming[r1.areas[0]] led what you opened, at 49%[r1.areas[0].share] of 130[r1.totals.items] videos."
for s in ["You opened long videos at 47%[r1.totals.shorts_share] of what you opened.",
          "You mostly opened long videos, at 47%[r1.totals.shorts_share].",
          "In 2019 you opened long videos at 47%[r1.totals.shorts_share] of what you opened.",
          "You opened Shorts at 47%[r1.totals.shorts_share] of what you opened.",
          "You mostly opened Shorts, at 47%[r1.totals.shorts_share]."]:
    for m in ("cells", "full"):
        v = V.check_answer({"lead": lead, "points": [s]}, res, V.Turn.of(t), mode=m)
        o = [o for o in v.outcomes if o.where == "point"][0]
        print(m, "KEPT" if o.kept else o.reasons, (o.notes or {}).get("insight_off"), "|", s)
