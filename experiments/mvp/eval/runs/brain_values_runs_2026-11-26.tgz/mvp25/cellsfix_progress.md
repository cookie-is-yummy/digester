# cellsfix progress
- step 0: started, reading
- step 0 done: read brief, reports. Harness S/mvp25/cellsfix/m.py (attack2 from repo json, run1 replay first+repair
  with recounta truth, looks via mvp24/pin/lib.py, planted score_cells, skeptic, rc2). Baseline m_base_cells.json
  reproduces mvp24: a2 out 24 / true lost 8; run1 lost 27/155 first, 38/180 all; lead first 54/65; L1 18/126 lead 44/53;
  L2 14/128 lead 49/53.
- step 2 (part): eval/brain_cells_attack2.json frozen (freeze_attack2.py; 177 cases, 8 ledgers + turns; scanned: made-up
  library only, handles @wetpaper.ig etc. from r12_library). Not committed yet.
- step 1 done: short_word, platform_all out of CELLS_LOOSE (verify.py). Closes e12, l07. Cost 4 true: attack2 q08,
  look1 D07.0.f0.point1, look1 F02.0.f0.lead0 (platform_all), look2 D08.0.f0.point0 (platform_all). m_s1.json = new ref.
- CheckMode.rules + CELLS_RULES added (full has none).
- step 3a: rules period_bind (_end_in_base under code other_period, guarded when window==window before) and
  period_named (_period_named: positional binding phrase->cell, disjoint or another known period). Both on: 0 true lost
  on every set vs s1; caught attack2 f08 f16 f21 f22 m02 n05 p04 p05 p07 + 23 planted/rc/skeptic framing-class.
- step 3b: rules free_date (_free_date: typed date must be a cited row's date / a known period / a bound said as an
  end / a one-day window) -> c09 c10 g05 + 2 planted, 0 true lost; weekday_typed (calendar weekday of a typed date) ->
  w01, 0 lost. m_s3a (after 3a), m_s3b (after 3b) refs.
- step 3c: insight.py gets skip=frozenset() through render/bind_check/_bind_more/_direction_check/_check_body/claims/
  _obs_more/check_sentence/_check (helper _go). verify.insight_check skip. Rule insight_walk: on an off first reason,
  rerun with skip; count later reason only if in WALK_ACCEPT (binding + name/word/link/quote). Full walk (any later
  reason) cost 5 true (date N066.1, count_as_share N013.1, percent audit_T11, weekday audit_T10, filler skeptic T05).
  With WALK_ACCEPT: 0 lost; p16 p19 closed; +attack_W01 v5_100. n09 NOT closed by walk (shorts_as_long needs 'long' in
  same clause) -> 3d. census: walk_census.py/json.
- diff25.py (base verify AND base insight of f22d04f; corpus + attack2 + run1): 0 differ after 3c.
- step 3d: rules item_fields (time of day vs item hour; length word vs item length; 'from <channel>' vs item channel)
  -> e09 e13 h01 h02 h03; length_cell (length cell said under other length word; 'all of them Shorts' vs row
  shorts_share) -> a19 n09 p06 (+3 planted); pairs_crossed -> p02. Each 0 true lost. All 24 attack2 false handled in
  cells; m_s3d.json = after all rules. NOTE renamed my _item_rows/_LEN_WORD (they collided; originals were later in
  file so had shadowed mine; no full change).
- step 5: loosenings own_fields (item channel / row area,theme as field slot; not when a tools' scope word),
  hour_word, handle (+ insight _check link guard via skip), month_alone, label_in_date (slotted), quoted_title (caps +
  _non_sheet). New rule date_owner (b09 had been caught only by 'link' on the handle). vs s3d: 30 true back, 0 lost;
  out: 4 planted framing-class (attack_L08 Q06 W01, audit_F85: were held only by '@' read as a link) + run1
  N056.0.f0.point1 (framing, rank over a tie; was held by uncited_name of the item's own channel). run1 lost first
  27->18 (all 38->21), lead first 54->57. m_s5c.json.
- step 4: step4.py/step4.txt/step4.json. Judged by hand: limits@words 5 drops (4 unwanted) OFF; limits@self 6 drops
  (1 arguable unwanted N109.0) ON; limits@insight 8 drops (5 unwanted) OFF; repeat@once 2 drops (1 unwanted L1 D08.0)
  OFF; repeat@insight 0 drops OFF. DOUBT_CODES limits split into 3 emitters. m_s4.json: run1 lead first 55/65, L1 43,
  L2 47 (wanted drops of self-talk leads); I02.0 false absence (L2) now dropped.
- NEXT: tests (attack2 pins, twins, probes p16/p19 now closed), planted.py attack2 line, re-hash pins, DESIGN 24.4,
  suite shards, commit.
- advisor round 2 applied: _direction_check deep returns guarded; insight reverse-diff vs f22d04f = empty
  (insight_reverse.diff); own_fields bound to the row cited before the name; handles from cited rows' fields;
  limits@self judged by code-lead evidence -> OFF (4 of 6 would leave a bare code lead); sibling twins: 5 holes found
  and closed (yearless day, 'starting in April', 'every one a Short', 'N Shorts', another item's quoted title), 'late
  January' true twin fixed. share_of_name classed cell. N27 re-pinned in brain_cells_extra.json.
- planted.py: score_attack2 / attack2_outcome / load_attack2; score_cells adds attack2, known_leaks, summary (in
  sample). attack2 json known_leaks {cells: {}, full: 5}. test_brain_cells.py: 84 pass, both settings.
- NEXT: brain tests, planted lines, shards, differential x3 + answers, DESIGN 24.4, commit.
- DESIGN 24.8 written + correction note at the top of 24. Long lines fixed (cosmetic) while shards ran -> rerun
  cells tests, brain tests, diff25 (both) and planted after shards. Then commit on brain-cells-local (no push).
- DONE. Commits cdbe6a6 + 614d61b on brain-cells-local (not pushed). Suite 6083 passed 2 skipped (4 shards);
  brain tests 398; insight-importing tests 941 + 2 skipped re-run on final; test_brain_cells 84 both settings;
  diff25 0 differ (4818 verdicts) + answers 0 differ (231); planted full 332/332 78/78; cells ok, 0 known leaks
  (in sample); leave-one-out of each rule: 0 true back; insight reverse diff empty. README count for merge agent:
  6083 passed, 2 skipped (+53 from 6030).
