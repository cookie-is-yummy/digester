"""The second attack (eval/brain_cells_attack2.json) on ledgers REBUILT with TREE's tools: each of the 8 records' saved
calls (mvp20/tune/heldout) re-run with their recorded arguments, keyed by saved rid by position. Each case runs as a
point under its carrier lead and alone as a lead, in cells and in full, on the frozen ledger and on the rebuilt one,
through TREE's checker. python3 -I a2_rebuild.py TREE ATTACK2_JSON"""
import json, os, sys, tempfile
from datetime import date
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE, A2 = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(TREE, "experiments"))
sys.dont_write_bytecode = True
from mvp import eval_brain as E  # noqa
from mvp.brain import verify as V, tools as TL, loop as BL  # noqa
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned  # noqa
RUN = os.path.join(S, "mvp20/tune/heldout")
base = tempfile.mkdtemp(prefix="a2rebuild_", dir=os.path.join(S, "mvp25/merge"))
H = E.Harness.scratch(base)
_done = {}


def replay(key):
    if key in _done:
        return _done[key]
    rec = json.load(open(os.path.join(RUN, key + ".json")))
    cid, n = key.rsplit(".", 1)
    last = carry = None
    pk = f"{cid}.{int(n) - 1}"
    if int(n) > 0 and os.path.exists(os.path.join(RUN, pk + ".json")):
        pt, prec = replay(pk)
        last = BL.last_window(pt, prec)
        ua = getattr(BL, "unlock_after", None)
        carry = ua(pt, prec) if ua else None
    kw = {"carried_unlock": carry} if "carried_unlock" in TL.Turn.__dataclass_fields__ else {}
    t = TL.Turn(H.bot, H.person, H.now, message=rec["message"], screen=json.dumps(rec.get("screen") or {}, sort_keys=True),
                last_window=last, search=FakeEngine(), learned=fake_learned, **kw)
    new = {"calls": []}
    for c in rec["calls"]:
        env = TL.call(t, c["name"], c["args"])
        new["calls"].append({"name": c["name"], "args": c["args"], "rid": env.get("rid"), "result": env})
    _done[key] = (t, new, rec)
    return t, new


d = json.load(open(A2))
strip = lambda e: json.dumps({k: v for k, v in e.items() if k != "took_ms"}, sort_keys=True, default=str)
rebuilt, same = {}, {}
for key in d["carriers"]:
    t, new = replay(key)
    rec = _done[key][2]
    led = {}
    for old, c in zip(rec["calls"], new["calls"]):
        if old.get("rid") and not (old.get("result") or {}).get("is_error") and not c["result"].get("is_error"):
            env = dict(c["result"]); env["rid"] = old["rid"]
            led[old["rid"]] = env
    rebuilt[key] = led
    fr = d["ledgers"][key]
    same[key] = sorted(r for r in fr if r in led and strip(fr[r]) == strip(led[r]))
    print(key, "rids", sorted(fr), "rebuilt", sorted(led), "identical to frozen:", same[key])


def turn(x):
    return V.Turn(message=x["message"], unlock=x["unlock"], screen=x["screen"],
                  today=date.fromisoformat(x["today"]) if x["today"] else None, names=list(x["names"]),
                  sensitive_names=list(x["sensitive_names"]))


def outcome(c, led, mode):
    tn, car = turn(d["turns"][c["record"]]), d["carriers"][c["record"]]
    vp = V.check_answer({"lead": car, "points": [c["text"]]}, led, tn, mode=mode)
    op = next(o for o in vp.outcomes if o.where == "point")
    vl = V.check_answer({"lead": c["text"], "points": []}, led, tn, mode=mode)
    ol = [o for o in vl.outcomes if o.where == "lead"]
    lk = bool(ol) and all(o.kept for o in ol)
    if c["truth"] == "F":
        return "out" if (op.kept or lk) else "handled"
    return "kept" if (op.kept and lk) else "lost"


changes = []
for mode in ("cells", "full"):
    tot = {"frozen": {}, "rebuilt": {}}
    for c in d["cases"]:
        a = outcome(c, d["ledgers"][c["record"]], mode)
        b = outcome(c, rebuilt[c["record"]], mode)
        tot["frozen"][a] = tot["frozen"].get(a, 0) + 1
        tot["rebuilt"][b] = tot["rebuilt"].get(b, 0) + 1
        if a != b:
            changes.append((mode, c["id"], c["truth"], c["family"], a, b, c["text"]))
    print(mode, "frozen", tot["frozen"], "rebuilt", tot["rebuilt"])
for x in changes:
    print("CHANGE", *x[:6], "|", x[6][:200])
print(len(changes), "cases change")
import shutil; shutil.rmtree(base, ignore_errors=True)
