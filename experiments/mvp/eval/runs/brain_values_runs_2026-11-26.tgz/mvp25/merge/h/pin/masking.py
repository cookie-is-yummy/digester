"""Every false case whose insight first reason is OFF in cells mode (insight stops at its first reason, so a later
insight reason is not reached): its class, the masked reason, and whether the case gets out. No model call."""
import json, os, sys
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L, loo as LO
V = L.V
out = []
d = L.planted_data()
for c in d["cases"]:
    if c["expect"] == "kept" or c.get("source") in ("attack_true", "audit_true"):
        continue
    for f in (c.get("forms") or [c["form"]]):
        v = V.check_answer(f, V.Ledger(d["ledgers"][c["ledger"]]), L._pturn(V, c), mode="cells")
        kept, _r = L._ptarget(v, c)
        offs = [o.notes.get("insight_off") for o in v.outcomes if o.notes.get("insight_off")]
        if offs:
            out.append(("planted", c["id"], LO.PL[c["id"]]["class"], offs[0], kept and not (c["expect"] == "private_line" and v.private_line)))
            break
for c, f, tgt, t in L.skeptic_inputs():
    if c[3] != "F":
        continue
    v = V.check_answer(f, t.results, V.Turn.of(t), mode="cells")
    o = next((o for o in v.outcomes if (o.where, o.index) == tgt), None)
    if o is not None and o.notes.get("insight_off"):
        out.append(("skeptic", c[0], LO.LB["skeptic"][c[0]]["class"], o.notes["insight_off"], o.kept))
for r in L.run_rc(V, "cells", 2):
    pass
print(f"{len(out)} false cases with an insight first reason off; by class and outcome:")
print(Counter((x[2], "OUT" if x[4] else "handled") for x in out))
for x in out:
    if x[2] == "cell":
        print("  CELL", x)
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "masking.json"), "w"), indent=0)
