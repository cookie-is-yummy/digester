"""mvp25 cellsfix: one measure of a checker setting on every set (made-up library; no model call).
Sets: attack2 (repo eval/brain_cells_attack2.json), run1 (mvp24/runa/run1 first + repair forms, truth
mvp24/recounta/sentences.json), look1/look2 (pin/lib.py, truth mvp22/raw), planted (score_cells), skeptic/rc (pin/lib)."""
import glob, json, os, sys
from collections import Counter
from datetime import date
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, os.path.join(S, "mvp25/merge/h/pin"))
import lib as L  # noqa: E402  (imports the worktree's mvp)
V = L.V
from mvp.brain import planted as P  # noqa: E402
REPO = os.path.join(S, "mvp25/merge_tree/experiments/mvp")
A2 = None


def a2():
    global A2
    if A2 is None:
        A2 = json.load(open(os.path.join(REPO, "eval/brain_cells_attack2.json")))
    return A2


def a2_turn(t):
    return V.Turn(message=t["message"], unlock=t["unlock"], screen=t["screen"],
                  today=date.fromisoformat(t["today"]) if t["today"] else None, names=list(t["names"]),
                  sensitive_names=list(t["sensitive_names"]))


def run_a2(mode):
    d = a2()
    rows = []
    for c in d["cases"]:
        led, turn, car = d["ledgers"][c["record"]], a2_turn(d["turns"][c["record"]]), d["carriers"][c["record"]]
        vp = V.check_answer({"lead": car, "points": [c["text"]]}, led, turn, mode=mode)
        op = next(o for o in vp.outcomes if o.where == "point")
        vl = V.check_answer({"lead": c["text"], "points": []}, led, turn, mode=mode)
        ol = [o for o in vl.outcomes if o.where == "lead"]
        lk = bool(ol) and all(o.kept for o in ol)
        rows.append({"set": "attack2", "id": c["id"], "truth": c["truth"], "family": c["family"], "P": op.kept,
                     "L": lk, "Pr": list(op.reasons), "Lr": sorted({r for o in ol for r in o.reasons}),
                     "out": c["truth"] == "F" and (op.kept or lk), "lost": c["truth"] == "T" and not (op.kept and lk),
                     "text": c["text"]})
    return rows


_R1 = None
R1LAB = {(r["key"], r["form_index"], r["where"], r["index"]): r
         for r in json.load(open(os.path.join(S, "mvp24/recounta/sentences.json"))) if r.get("form_index") is not None}


def run1_inputs():
    global _R1
    if _R1 is None:
        h = L.harness()
        out = []
        for p in sorted(glob.glob(os.path.join(S, "mvp24/runa/run1/N*.json"))):
            rec = json.load(open(p))
            t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                       and not c["result"].get("is_error")}
            out.append((rec, t, results))
        _R1 = out
    return _R1


def run_run1(mode, keep=False):
    rows = []
    for rec, t, results in run1_inputs():
        vt = V.Turn.of(t)
        for fi, form in enumerate(rec.get("forms") or []):
            v = V.check_answer(form, results, vt, mode=mode)
            for o in v.outcomes:
                lab = R1LAB.get((rec["key"], fi, o.where, o.index))
                tr = None if lab is None else {"true": "T", "wrongly_based": "F", "false": "F"}.get(lab["truth"],
                                                                                                 lab["truth"])
                r = {"set": "run1", "id": f"{rec['key']}.f{fi}.{o.where}{o.index}", "key": rec["key"],
                     "form_index": fi, "where": o.where, "index": o.index, "truth": tr, "kept": o.kept,
                     "reasons": list(o.reasons), "details": list(o.details), "text": o.text,
                     "lead_ok": v.lead_ok}
                if keep:
                    r["verdict"] = v
                rows.append(r)
    return rows


def lead_kept_first(rows, look):
    leads = {}
    for r in rows:
        if r["set"] == look and r["form_index"] == 0 and r["where"] == "lead":
            leads[r["key"]] = leads.get(r["key"], True) and bool(r["kept"])
    keys = {r["key"] for r in rows if r["set"] == look and r["form_index"] == 0}
    return sum(1 for k in keys if leads.get(k, False)), len(keys)


def lost(rows, look, fi=None):
    xs = [r for r in rows if r["set"] == look and r["truth"] == "T" and (fi is None or r["form_index"] == fi)]
    return [r for r in xs if not r["kept"]], len(xs)


def measure(mode, quiet=False):
    res = {}
    a = run_a2(mode)
    F = [r for r in a if r["truth"] == "F"]
    res["a2_out"] = [r["id"] for r in F if r["out"]]
    res["a2_out_family"] = dict(Counter(r["family"] for r in F if r["out"]))
    res["a2_true_lost"] = [r["id"] for r in a if r["lost"]]
    r1 = run_run1(mode)
    lk = L.run_looks(V, mode)
    for nm, rows in (("run1", r1), ("look1", lk), ("look2", lk)):
        l0, n0 = lost(rows, nm, 0)
        la, na = lost(rows, nm)
        res[f"{nm}_lost_first"] = (len(l0), n0)
        res[f"{nm}_lost_all"] = (len(la), na)
        res[f"{nm}_lost_ids"] = sorted(r["id"] for r in la)
        res[f"{nm}_lead_first"] = lead_kept_first(rows, nm)
        res[f"{nm}_false_kept_first"] = sum(1 for r in rows if r["set"] == nm and r["form_index"] == 0
                                            and r["truth"] == "F" and r["kept"])
    sc = P.score_cells(mode=mode) if V.check_mode(mode).cells else None
    if sc:
        res["planted_ok"] = sc["ok"]
        res["planted_cell_out"] = sc["cell_out"]
        res["planted_true"] = (sc["true_kept"], sc["true"])
        res["planted_attack_true"] = sc["by_source"]["attack_true"]["true_kept"]
        res["planted_audit_true"] = sc["by_source"]["audit_true"]["true_kept"]
        res["planted_out"] = {src: {k: x["out"] for k, x in b.items() if isinstance(x, dict) and "out" in x}
                              for src, b in sc["by_source"].items()}
    sk = L.run_skeptic(V, mode)
    res["skeptic_true_kept"] = sum(1 for r in sk if r["truth"] == "T" and r["kept"])
    res["skeptic_cell_out"] = [r["id"] for r in sk if r["truth"] == "F" and r["class"] == "cell" and r["kept"]]
    rc = L.run_rc(V, mode, 2)
    res["rc2_true_kept"] = sum(1 for r in rc if r["truth"] == "T" and r["kept"])
    res["rc2_cell_out"] = [r["id"] for r in rc if r["truth"] == "F" and r["class"] == "cell" and r["kept"]]
    return res, {"a2": a, "run1": r1, "looks": lk}


def mode_from(spec):
    """'full', 'cells', or 'cells' with modifiers: +r:NAME / -r:NAME (a cells rule), +l:NAME / -l:NAME (a loosening),
    +on:CODE (a code switched back on), +off:CODE. e.g. 'cells+r:period-l:title_quote'."""
    import re
    if spec == "full":
        return V.FULL
    assert spec.startswith("cells"), spec
    off, loose, rules = set(V.CELLS.off), set(V.CELLS.loose), set(V.CELLS.rules)
    for op, kind, name in re.findall(r"([+-])(r|l|on|off):([A-Za-z_@]+)", spec[5:]):
        tgt = {"r": rules, "l": loose}.get(kind)
        if kind == "on":
            off.discard(name)
        elif kind == "off":
            off.add(name)
        elif op == "+":
            tgt.add(name)
        else:
            tgt.discard(name)
    return V.CheckMode(spec, off=frozenset(off), loose=frozenset(loose), insight=V.CELLS.insight, cells=True,
                       rules=frozenset(rules))


def per_id(mode, rows):
    """{set:id -> (truth, kept)} for every set (kept: for a false case, True = out)."""
    out = {}
    for r in rows["a2"]:
        out[f"attack2:{r['id']}"] = (r["truth"], (r["P"] and r["L"]) if r["truth"] == "T" else r["out"])
    for r in rows["run1"] + rows["looks"]:
        if r["truth"] in ("T", "F"):
            out[f"{r['set']}:{r['id']}"] = (r["truth"], r["kept"])
    for r in L.run_planted(V, mode):
        out[f"planted:{r['src']}:{r['id']}"] = (r["truth"], r["kept"] and not (r["expect"] == "private_line"
                                                                          and r["private_line"]))
    for r in L.run_skeptic(V, mode):
        out[f"skeptic:{r['id']}"] = (r["truth"], r["kept"])
    for r in L.run_rc(V, mode, 2):
        out[f"rc2:{r['id']}"] = (r["truth"], r["kept"])
    ex = json.load(open(os.path.join(REPO, "eval/brain_cells_extra.json")))
    import importlib
    T = importlib.import_module("mvp.tests.test_brain_cells") if False else None
    for e in ex["cases"]:
        t = dict(e["turn"])
        t["today"] = date.fromisoformat(t["today"]) if t.get("today") else None
        v = V.check_answer(e["form"], ex["ledgers"][e["ledger"]], V.Turn(**t), mode=mode)
        os_ = [o for o in v.outcomes if o.where == "lead"] if e["where"] == "L" else \
            [o for o in v.outcomes if (o.where, o.index) == ("point", 0)]
        out[f"extra:{e['id']}"] = (e["truth"], bool(os_) and all(o.kept for o in os_))
    return out


def diff(a, b):
    """true kept in a, lost in b; false out in a, handled in b; and the reverse."""
    lost = sorted(k for k in a if k in b and a[k][0] == "T" and a[k][1] and not b[k][1])
    back = sorted(k for k in a if k in b and a[k][0] == "T" and not a[k][1] and b[k][1])
    caught = sorted(k for k in a if k in b and a[k][0] == "F" and a[k][1] and not b[k][1])
    leaked = sorted(k for k in a if k in b and a[k][0] == "F" and not a[k][1] and b[k][1])
    return {"true_lost": lost, "true_back": back, "false_caught": caught, "false_leaked": leaked}


if __name__ == "__main__":
    spec, tag = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else sys.argv[1])
    cm = mode_from(spec)
    res, rows = measure(cm)
    ids = per_id(cm, rows)
    json.dump({"res": res, "ids": ids}, open(os.path.join(S, "mvp25/merge/m", f"m_{tag}.json"), "w"), indent=0)
    for k, v in res.items():
        if k.endswith("_ids"):
            continue
        print(k, v)
    if len(sys.argv) > 3:
        rp = os.path.join(S, "mvp25/merge/m", f"m_{sys.argv[3]}.json")
        rp = rp if os.path.exists(rp) else os.path.join(S, "mvp25/cellsfix", f"m_{sys.argv[3]}.json")
        ref = json.load(open(rp))["ids"]
        dd = diff(ref, ids)
        for k, v in dd.items():
            print(f"vs {sys.argv[3]}: {k} {len(v)}: {v}")
