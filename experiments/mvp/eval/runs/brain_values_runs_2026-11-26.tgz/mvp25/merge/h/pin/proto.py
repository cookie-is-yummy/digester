from datetime import date
from mvp.brain import verify as V, planted as P
d=P.load(); cs={c['id']:c for c in d['cases']}
def P_turn(c):
    t=c.get('turn') or {}
    return V.Turn(message=t.get('message',''), unlock=t.get('unlock'), today=date.fromisoformat(t['today']) if t.get('today') else None, names=list(t.get('names') or []), sensitive_names=list(t.get('sensitive_names') or []))
def chk(cid, s, where='point'):
    c=cs[cid]; f=(c.get('forms') or [c['form']])[0]
    led=V.Ledger(d['ledgers'][c['ledger']])
    form={'lead': s} if where=='lead' else {'lead': f.get('lead') or '', 'points':[s]}
    out=[]
    for m in ('full','cells'):
        v=V.check_answer(form, led, P_turn(c), mode=m)
        os_=[o for o in v.outcomes if o.where==where]
        out.append((m, all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})))
    return out
sh=d['ledgers'][cs['attack_V05']['ledger']][0]['sheet']
a=sh['areas'][0]; print(a['name'], a['share'], a.get('previous_share'), cs['attack_V05']['forms'][0]['lead'])
pts=round((a['share']-a['previous_share'])*100)
for cid,s in [('attack_V05', f"Gaming[r1.areas[0]] rose {pts} points[=points(r1.areas[0].share, r1.areas[0].previous_share)] on last autumn."),
 ('attack_V05', cs['attack_V05']['forms'][0]['points'][0]),
 ('attack_Q01', 'Your first Clip Factory video was "Funniest gaming fail"[r1.items[0]].'),
 ('attack_Q01', 'You opened 1 video from Clip Factory[r1.items[0]] on 1 October 2026[r1.items[0].when].'),
 ('attack_Q01', 'You opened a short[r1.items[0]] on 1 October 2026[r1.items[0].when].'),
 ('v5_054', 'Your long videos ran about 23[r1.totals.long_median_min] minutes.'),
 ('v5_112', 'Speed runs[r1.themes[1]] climbed to 9%[r1.themes[1].share] from 3%[r1.themes[1].previous_share].'),
 ('attack_A01', cs['attack_A01']['forms'][0]['points'][0] if cs['attack_A01'].get('forms') else cs['attack_A01']['form']['points'][0]),
 ('attack_X02', cs['attack_X02']['forms'][0]['points'][0] if cs['attack_X02'].get('forms') else cs['attack_X02']['form']['points'][0]),
 ('attack_X02', 'Clip Factory[r1.channels[0]] went from 14[r1.channels[0].previous_items] videos the week before to 13[r1.channels[0].items] in the last 7 days.'),
 ]:
    print(cid, s[:70], chk(cid, s))
