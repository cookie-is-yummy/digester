import json, sys, os
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
rec = json.load(open(f"{RP.RUN}/N001.1.json"))
t, new = RP.replay("N001.1")
for old, c in zip(rec["calls"], new["calls"]):
    o, n = old["result"], c["result"]
    print(c["name"], json.dumps(c["args"])[:200], old.get("rid"), c.get("rid"), "err", o.get("is_error"), n.get("is_error"))
    if old.get("rid") == "r2":
        so, sn = o.get("sheet") or {}, n.get("sheet") or {}
        print(" keys old", sorted(so), "\n keys new", sorted(sn))
        po, pn = so.get("periods") or [], sn.get("periods") or []
        print(" periods", len(po), len(pn), po[-3:] if po else None, pn[-3:] if pn else None)
        print(" notes new", (n.get("meta") or {}).get("notes"))
        print(" meta diff keys", sorted(set(n.get("meta") or {}) ^ set(o.get("meta") or {})), (n.get("meta") or {}).get("truncated"), (o.get("meta") or {}).get("truncated"))
