"""Sentences the model would plausibly write on the new cells, through the checker in cells and in full, on the
replayed results of run1 records. Input file: KEY<TAB>lead or point<TAB>sentence."""
import json, sys, os
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
from mvp.brain import verify as V  # noqa
for line in open(sys.argv[2]):
    if not line.strip() or line.startswith("#"):
        continue
    key, where, sent = line.rstrip("\n").split("\t")
    t, new = RP.replay(key)
    vt = V.Turn.of(t)
    for mode in ("cells", "full"):
        if where == "lead":
            v = V.check_answer({"lead": sent, "points": []}, t.results, vt, mode=mode)
            o = v.lead[0]
        else:
            lead, pt = sent.split(" || ")
            v = V.check_answer({"lead": lead, "points": [pt]}, t.results, vt, mode=mode)
            o = [x for x in v.outcomes if x.where == "point"][0]
        print(f"{key} {mode:5} {'KEPT' if o.kept else 'DROP'} {o.reasons} | {sent[:170]}")
