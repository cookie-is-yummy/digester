"""The two cells-only cell rules (_cross_row_move, _mixed_move): what each catches and what true sentence it costs,
and the false cases whose insight first reason is off in cells mode (insight stops at its first reason)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L, tally as T, loo as LO
V = L.V
base = T.run("cells")
bl = {LO.key(r): r for r in base}
for name in ("_cross_row_move", "_mixed_move"):
    orig = getattr(V, name)
    setattr(V, name, lambda *a, **k: None)
    rows = T.run("cells")
    setattr(V, name, orig)
    caught = [LO.key(r) for r in rows if r["truth"] == "F" and r["kept"] and not bl[LO.key(r)]["kept"]]
    cost = [LO.key(r) for r in rows if r["truth"] == "T" and r["kept"] and not bl[LO.key(r)]["kept"]]
    print(f"{name}: catches {caught}; true sentences it refuses: {cost}")
# insight masking
lines = []
for r in LO.false_rows(base):
    if r["set"] in ("look1", "look2"):
        continue
    lines.append(r)
print("false cases whose insight first reason is off (cells mode):")
cnt = {}
for r in base:
    pass
