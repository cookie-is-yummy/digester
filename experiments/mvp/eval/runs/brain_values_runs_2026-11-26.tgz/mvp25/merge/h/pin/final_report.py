"""The final evidence of the pinned cells mode (made-up library; no model call): every set by class, the arguable
cases both ways, the framing cases false by arithmetic on two cited cells under a direction or comparison word, the
policy cases out, and the true sentences kept. Writes report.txt and out/final.json."""
import json
import os
import re
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402
import loo as LO  # noqa: E402
import tally as T  # noqa: E402

V = L.V
HERE = os.path.dirname(os.path.abspath(__file__))
DIRCMP = re.compile(r"\b(?:more|fewer|less|bigger|smaller|larger|higher|lower|ahead|behind|grew|grow|rose|rise|fell|"
                    r"fall|slowed|slow|dropped|up|down|climbed|gained|lost|than|against)\b", re.I)


def label(r):
    c, arg = LO.klass(r)
    return c, arg


def main():
    cells = T.run("cells")
    full = T.run("full")
    F = {LO.key(r): r for r in full}
    lines = []
    P = lines.append
    P("PINNED CELLS MODE: what it does on every set (made-up library; no model call; S = by code, J = class by hand)")
    P("off: " + ", ".join(sorted(V.CELLS.off)))
    P("")
    # by set and class
    groups = {}
    for r in LO.false_rows(cells):
        s = r["set"] if r["set"] != "planted" else ("attack" if r["src"] == "attack" else "builder")
        if s in ("look1", "look2"):
            continue
        c, _a = label(r)
        base = re.sub(r"_[LP]$", "", r["id"]) if s == "attack" else r["id"]
        g = groups.setdefault((s, c), {})
        g[base] = g.get(base, True) and T.handled(r)
    P(f"{'set':8s} {'class':8s} {'false':>5s} {'handled':>8s} {'out':>4s}")
    for (s, c), g in sorted(groups.items()):
        P(f"{s:8s} {c:8s} {len(g):5d} {sum(g.values()):8d} {len(g) - sum(g.values()):4d}")
    P("")
    # true sentences, cells against full
    P("true sentences kept (cells | full):")
    for s, test in (("builder", lambda r: r["set"] == "planted" and r["src"] in ("new", "insight_v5")),
                    ("attack_true", lambda r: r["set"] == "planted" and r["src"] == "attack_true"),
                    ("audit_true", lambda r: r["set"] == "planted" and r["src"] == "audit_true"),
                    ("skeptic", lambda r: r["set"] == "skeptic"), ("rc2", lambda r: r["set"] == "rc2" and not r["dup"]),
                    ("look1", lambda r: r["set"] == "look1" and r["form_index"] == 0),
                    ("look2", lambda r: r["set"] == "look2" and r["form_index"] == 0)):
        tr = [r for r in cells if r["truth"] == "T" and test(r)]
        P(f"  {s:12s} {sum(r['kept'] for r in tr):3d} | {sum(F[LO.key(r)]['kept'] for r in tr):3d} of {len(tr)}")
    P("")
    # arguable cases both ways
    P("ARGUABLE cases (the frozen class, the other reading, what cells mode does):")
    for r in LO.false_rows(cells):
        c, arg = label(r)
        if arg:
            P(f"  {r['set']:8s} {r['id']:14s} class {c:8s} or {arg:8s} cells: {'OUT' if not T.handled(r) else 'handled'}"
              f" | full: {'OUT' if not T.handled(F[LO.key(r)]) else 'handled'}")
    P("")
    # cell class out
    out_cell = [r for r in LO.false_rows(cells) if label(r)[0] == "cell" and not T.handled(r)]
    P("CELL-CLASS cases out: " + (", ".join(f"{r['set']}:{r['id']}" for r in out_cell) or "none"))
    out_pol = [r for r in LO.false_rows(cells) if label(r)[0] == "policy" and not T.handled(r)]
    P("POLICY-CLASS cases out: " + ", ".join(f"{r['set']}:{r['id']}" for r in out_pol))
    P("")
    # framing subclass: two value markers and a direction or comparison word
    sub = []
    for r in LO.false_rows(cells):
        if label(r)[0] != "framing" or T.handled(r) or r["set"] in ("look1", "look2"):
            continue
        txt = r.get("text") or ""
        if r["set"] == "planted":
            c = next(x for x in L.planted_data()["cases"] if x["id"] == r["id"])
            f0 = (c.get("forms") or [c["form"]])[0]
            tgt = (c.get("target") or "point:0").partition(":")
            txt = f0.get("lead") if tgt[0] == "lead" else (f0.get("points") or [""] * 9)[int(tgt[2] or 0)]
        vals = re.findall(r"\[(?:r\d|=)", txt or "")
        if len(vals) >= 2 and DIRCMP.search(V.strip_markers(txt or "")):
            sub.append((r["set"], r["id"], V.strip_markers(txt)[:120]))
    P(f"FRAMING cases out with two or more cited cells and a direction or comparison word ({len(sub)}; read by hand "
      "below which are false by arithmetic on the cited cells):")
    for x in sub:
        P(f"  {x[0]}:{x[1]}  {x[2]}")
    txt = "\n".join(lines) + "\n"
    open(os.path.join(HERE, "report.txt"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
