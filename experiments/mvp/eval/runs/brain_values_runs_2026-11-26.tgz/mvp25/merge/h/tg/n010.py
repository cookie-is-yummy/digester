import json, sys, os
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
from mvp.brain import verify as V  # noqa
t, new = RP.replay("N010.0")
r = t.results["r1"] if isinstance(t.results, dict) else None
print(json.dumps(r["meta"], default=str)[:1500])
print(json.dumps({k: v for k, v in r.items() if k not in ("meta",)}, default=str)[:800])
vt = V.Turn.of(t)
for s in sys.argv[2:]:
    v = V.check_answer({"lead": s, "points": []}, t.results, vt, mode="cells")
    o = v.lead[0]; print(o.kept, o.reasons, o.details, "|", s)
