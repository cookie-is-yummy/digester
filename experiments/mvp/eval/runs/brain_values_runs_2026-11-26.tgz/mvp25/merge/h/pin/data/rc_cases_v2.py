"""v2 of cases.py, written AFTER the v1 run (01:19Z freeze, v1 run right after). Two changes only:
(1) placement: every sentence is run as the answer's lone lead, because under the record's own first-form lead many
    hit the 'repeat' code (they re-cite the lead's cells): a harness artefact, not a catch;
(2) citation-only fixes where v1 was refused by a marker code alone (no change to the claim):
    N09 'Those five' -> no number word; N44 'top five' -> 'top 5[r1.items.count]'; T25 'five' -> '5[r1.channels.count]';
    RT1 'New this year: ...' (capital 'New' before a colon reads as an unknown name) -> '... are new this year';
    and one record completion: N06's careless record lacked the move record its word 'drop' asks for (added).
Everything else is cases.py as frozen."""
import rc_cases as C
from rc_cases import mv
OVR = {
    "N09": ("Clip Factory[r1.channels[0]], Pan Theory[r1.channels[1]], Pixel Pencil[r1.channels[2]], Brick Realm[r1.channels[3]] and Gaming Daily[r1.channels[4]] are every channel you opened in October.", None),
    "N44": ("Your top 5[r1.items.count] October videos were Cooking soup on the 30th[r1.items[0]], Digital art colour on the 30th[r1.items[1]], Gaming clip on the 30th[r1.items[2]], Digital drawing on the 30th[r1.items[3]] and Gaming clutch moment[r1.items[4]].", None),
    "T25": ("Your full list of the 5[r1.channels.count] quietest October channels runs from Wet Paper[r1.channels[0]] with 1[r1.channels[0].items] to Brick Realm[r1.channels[4]] with 6[r1.channels[4].items].", None),
    "RT1": ("Pixel Pencil[r3.new.channels[0]], Clip Factory[r3.new.channels[1]] and Gaming Daily[r3.new.channels[2]] are new this year, with Minecraft builds[r3.new.themes[2]] and Calculus lessons[r3.new.themes[3]] as new themes.", None),
    "N06": (None, "add_move"),
}
CASES = []
for c in C.CASES:
    cid, look, key, where, truth, cls, text, recount, rec = c
    if cid in OVR:
        t, r = OVR[cid]
        text = t or text
        if r == "add_move":
            rec = list(rec) + [mv("r1.channels[2].items", "r1.channels[2].previous_items", "down")]
    CASES.append((cid, look, key, "L", truth, cls, text, recount, rec))
