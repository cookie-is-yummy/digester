"""Scenarios: real brain/tools.py calls on tests/brain_library.py (scratch library under skeptic/_lib)."""
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

W = {"preset": None, "same_as": None, "words": None}
SC = {"exclude": [], "how": "opened", "length": "any", "only": [], "platforms": [], "weekday": None}


def win(**kw):
    return dict(W, **kw)


def sc(**kw):
    return dict(SC, **kw)


SCEN = {
    # key: (message, [(tool, args)], last_window)
    "LATELY": ("what have i been into lately", [("breakdown", {"by": "theme", "window": win(preset="lately"),
               "scope": sc(), "compare": "previous", "top": 6})], None),
    "OCT_CH": ("which channels did i watch most in october", [("breakdown", {"by": "channel",
               "window": win(words="in October"), "scope": sc(), "compare": "none", "top": 5})], None),
    "YEARS": ("how has my watching changed over the years", [("timeline", {"unit": "year", "window": win(preset="all"),
              "scope": sc()})], None),
    "Y2024": ("what was i into in 2024", [("breakdown", {"by": "theme", "window": win(words="in 2024"), "scope": sc(),
              "compare": "none"})], None),
    "Y2024U": ("did i watch a lot of dating advice in 2024", [("breakdown", {"by": "channel",
               "window": win(words="in 2024"), "scope": sc(), "compare": "none"})], None),
    "TWO": ("what did i watch in october and how does that compare with my whole history",
            [("breakdown", {"by": "area", "window": win(words="in October"), "scope": sc(), "compare": "none"}),
             ("breakdown", {"by": "area", "window": win(preset="all"), "scope": sc(), "compare": "none"})], None),
    "FOLLOW": ("and just the art ones?", [("breakdown", {"by": "channel", "window": win(same_as="last"),
               "scope": sc(only=["art"]), "compare": "previous"})], "lately"),
    "YTD_CH": ("my channels this year", [("breakdown", {"by": "channel", "window": win(preset="this_year"),
               "scope": sc(), "compare": "none", "top": 8})], None),
    "CHG": ("what changed this year", [("changes", {"against": "same_last_year", "level": "theme",
            "window": win(preset="this_year"), "scope": sc()})], None),
    "SAT": ("what do i watch on saturdays in october", [("breakdown", {"by": "area",
            "window": win(words="in October"), "scope": sc(weekday=5), "compare": "none"})], None),
    "MONTHS": ("my months this year", [("timeline", {"unit": "month", "window": win(preset="this_year"),
               "scope": sc()})], None),
    "SAVED": ("what did i save in october", [("items", {"window": win(words="in October"), "scope": sc(how="saved"),
              "order": "newest", "limit": 10})], None),
}

