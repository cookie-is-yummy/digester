"""Compound probes: a binding fault (a cell of another row, a period row called by another label, the window's median
said of a row, a Shorts share said as long, a weekday of a date) with a framing trigger added (a rank word, 'mostly',
a window word, a one-value move, 'only'). Insight stops at its first reason, so a framing reason that is off may hide
the binding reason. Each probe is false for its binding fault whatever its framing. No model call."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402

V = L.V
CS = {c["id"]: c for c in L.planted_data()["cases"]}
# (probe id, base case whose ledger and turn it uses, target sentence as a point under the base case's own lead)
PROBES = [
    ("p01", "f_under_other_name", "Pan Theory[r1.channels[1]] led with 56[r1.channels[0].items] videos."),
    ("p02", "f_under_other_name", "Mostly Pan Theory[r1.channels[1]], with 56[r1.channels[0].items] videos."),
    ("p03", "f_under_other_name", "Lately, Pan Theory[r1.channels[1]] made 56[r1.channels[0].items] videos, your top channel."),
    ("p04", "f_under_other_name", "Only Pan Theory[r1.channels[1]] came close, with 56[r1.channels[0].items] videos."),
    ("p05", "audit_F01", "Pan Theory[r1.channels[1]] came second, with 29[r1.channels[2].items] of the videos you opened."),
    ("p06", "audit_F03", "Gaming clips[r1.themes[0]] led, at 51%[r1.areas[0].share] of what you opened."),
    ("p07", "audit_F04", "Clip Factory[r1.channels[0]] made most of it, 66[r1.themes[0].items] of the videos you opened."),
    ("p08", "audit_F83c", "In 2022, your biggest year, you opened 134[r1.periods[0].items] videos."),
    ("p09", "audit_F83c", "In 2022 you opened 134[r1.periods[0].items] videos, more than ever."),
    ("p10", "audit_F84", "Lately, in October 2026, you opened 44[r1.periods[8].items] videos."),
    ("p11", "audit_F83", "In September 2026, your busiest month, you opened 142[r1.periods[9].items] videos."),
    ("p12", "v5_005", "home cooking[r1.themes[1]] led on 12[r1.themes[2].days] days."),
    ("p13", "v5_016", "Prime Number Club[r1.channels[1]] came on 140[r1.channels[0].days] days, the most of any channel."),
    ("p14", "v5_033", "gaming[r1.topics[0]] fell to 212[r1.topics[1].items] videos."),
    ("p15", "v5_037", "Mostly, Pixel Forge[r1.channels[1]] gave 13[r1.channels[0].items] videos."),
    ("p16", "v5_051", "gaming[r1.areas[0]] led at 22%[r1.areas[0].share], mostly Meme drops[r1.themes[0]]."),
    ("p17", "v5_054", "Speed runs[r1.themes[1]] led on 18[r1.themes[1].days] days, and its long videos ran about 23[r1.totals.long_median_min] minutes."),
    ("p18", "v5_054", "Lately Speed runs[r1.themes[1]] was your top theme; its long videos ran about 23[r1.totals.long_median_min] minutes."),
    ("p19", "v5_056", "Meme drops[r1.themes[0]] was mostly long-form at 69%[r1.themes[0].shorts_share]."),
    ("p20", "v5_056", "Meme drops[r1.themes[0]] led and leaned long-form at 69%[r1.themes[0].shorts_share]."),
    ("p21", "attack_Q01", "Your first and top Clip Factory video was Funniest gaming fail[r1.items[0]], on 1 October 2026[r1.items[0].when], a Sunday."),
    ("p22", "attack_P03", "Pan Theory[r1.channels[1]] and Pixel Pencil[r1.channels[2]] together led, at 43%[r1.channels[0].share] of what you opened."),
]


def run_probe(pid, base, sentence, mode):
    c = CS[base]
    f0 = (c.get("forms") or [c["form"]])[0]
    tgt = (c.get("target") or "point:0").split(":")[0]
    form = {"lead": sentence} if tgt == "lead" else {"lead": f0.get("lead") or "", "points": [sentence]}
    v = V.check_answer(form, V.Ledger(L.planted_data()["ledgers"][c["ledger"]]), L._pturn(V, c), mode=mode)
    os_ = [o for o in v.outcomes if o.where == "lead"] if tgt == "lead" else \
        [o for o in v.outcomes if (o.where, o.index) == ("point", 0)]
    kept = bool(os_) and all(o.kept for o in os_)
    return kept, sorted({r for o in os_ for r in o.reasons}), [o.notes.get("insight_off") for o in os_ if
                                                                o.notes.get("insight_off")]


def main():
    rows = []
    for pid, base, s in PROBES:
        kf, rf, _ = run_probe(pid, base, s, "full")
        kc, rc, off = run_probe(pid, base, s, "cells")
        rows.append({"id": pid, "base": base, "text": s, "full": [kf, rf], "cells": [kc, rc], "insight_off": off})
        print(f"{pid} {base:20s} full {'KEPT' if kf else 'drop'} {rf} | cells {'KEPT' if kc else 'drop'} {rc} "
              f"masked {off}")
    json.dump(rows, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "probes.json"), "w"),
              indent=1)
    print("kept in cells:", [r["id"] for r in rows if r["cells"][0]])


if __name__ == "__main__":
    main()
