"""Full-mode answer differential (base fallback/answer/verify/insight of f22d04f vs merge tree), differences by kind.
New keys of answer.build (cards, ask, limits) are set apart; every other difference is listed by kind."""
import os, sys
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diff25 as D  # noqa
M, L, VB = D.M, D.L, D.VB
FBb = D._load(os.path.join(D.HERE, "base", "fallback_base.py"), "mvp.brain.fallback_b25k", "mvp.brain"); FBb.V, FBb.I = VB, D.IB
Ab = D._load(os.path.join(D.HERE, "base", "answer_base.py"), "mvp.brain.answer_b25k", "mvp.brain"); Ab.V = VB
from mvp.brain import fallback as FB, answer as A  # noqa
NEW = ("cards", "ask", "limits")
kinds = Counter(); per = Counter(); n = 0; rows = []
ins = [(look, rec, t, r) for look, rec, t, r in L.look_inputs()] + [("run1", rec, t, r) for rec, t, r in M.run1_inputs()]
for look, rec, t, results in ins:
    for fi, f in enumerate(rec.get("forms") or []):
        n += 1
        vb = VB.check_answer(f, results, VB.Turn.of(t)); vr = M.V.check_answer(f, results, M.V.Turn.of(t), mode="full")
        cb = FBb.answer(VB.Ledger(results), vb, VB.Turn.of(t)); cr = FB.answer(M.V.Ledger(results), vr, M.V.Turn.of(t), mode="full")
        ab = Ab.build(VB.Ledger(results), verdict=None, code=cb, form=f, also=[vb])
        ar = A.build(M.V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode="full")
        mb = Ab.build(VB.Ledger(results), verdict=vb, form=f, also=[vb])
        mr = A.build(M.V.Ledger(results), verdict=vr, form=f, also=[vr], mode="full")
        k = []
        if repr(cb) != repr(cr):
            ck = sorted(x for x in set(cb) | set(cr) if repr(cb.get(x)) != repr(cr.get(x)))
            k.append("code_lead:" + ("lead_text" if cb.get("lead") != cr.get("lead") else "other(" + ",".join(ck) + ")"))
        for tag, x, y in (("code_build", ab, ar), ("model_build", mb, mr)):
            yo = {kk: v for kk, v in y.items() if kk not in NEW}
            if repr(x) != repr(yo):
                dk = sorted(z for z in set(x) | set(yo) if repr(x.get(z)) != repr(yo.get(z)))
                k.append(tag + ":changed(" + ",".join(dk) + ")")
            for z in NEW:
                if y.get(z):
                    k.append(tag + ":new_" + z)
        for kk in k:
            kinds[kk] += 1
        if not k:
            per["only_empty_new_keys"] += 1
        rows.append((look, rec["key"], fi, k, cb.get("lead"), cr.get("lead")))
print(f"{n} forms; forms whose only difference is the new empty keys: {per['only_empty_new_keys']}")
print("differences by kind (a form can have several):")
for kk, v in sorted(kinds.items()):
    print(f"  {kk}: {v}")
for r in rows:
    tg = {x.split(":")[0] for x in r[3] if "changed" in x}
    for t in tg:
        if not any(x.startswith(t + ":new_") for x in r[3]) and not (t == "code_build" and any(x.startswith("code_lead") for x in r[3])):
            print("  TEXT-ONLY", r[0], r[1], r[2], r[3])
    if any("points" in x for x in r[3]):
        print("  POINTS", r[0], r[1], r[2], r[3])
    if any(x.startswith("code_lead") for x in r[3]):
        print(" ", r[0], r[1], r[2], r[3]); print("     base:", r[4]); print("     now: ", r[5])
