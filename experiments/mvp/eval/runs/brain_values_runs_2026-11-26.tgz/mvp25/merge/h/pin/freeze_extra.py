"""Freeze the cell-class false cases of the skeptic's set (mvp22/skeptic) and the record checker's set
(mvp23/record_check, cases_v2) into the repo (eval/brain_cells_extra.json), each with the tool results it is checked
on (made-up library only), the verifier's turn, its class and what cells mode does with it today; plus a few
framing-class and true controls. tests/test_brain_cells.py reads it."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402
import loo as LO  # noqa: E402

V = L.V
OUT = os.path.join(L.PIN, "mvp", "eval", "brain_cells_extra.json")
SK = {"K03", "K30", "K37", "K39", "K45", "K46", "K26", "K27", "K36", "K38", "T03", "T06", "T12", "T15"}
RC = {"N24", "N25", "N33", "N30", "N31", "N27", "T06", "T07", "T09"}


def turn_json(vt):
    return {"message": vt.message, "unlock": vt.unlock, "today": vt.today.isoformat() if vt.today else None,
            "names": list(vt.names), "sensitive_names": list(vt.sensitive_names)}


def target(v, where):
    os_ = [o for o in v.outcomes if o.where == "lead"] if where == "L" else \
        [o for o in v.outcomes if (o.where, o.index) == ("point", 0)]
    return bool(os_) and all(o.kept for o in os_)


def main():
    cases = []
    for c, form, tgt, t in L.skeptic_inputs():
        if c[0] not in SK:
            continue
        vt = V.Turn.of(t)
        res = {rid: env for rid, env in t.results.items()} if isinstance(t.results, dict) else t.results
        e = {"set": "skeptic", "id": c[0], "truth": c[3], "where": c[2], "form": form, "results": res,
             "ledger": "skeptic:" + c[1], "turn": turn_json(vt), "why": c[6]}
        cases.append(e)
    import rc_cases_v2 as C2
    inp = {(look, rec["key"]): (rec, t, results) for look, rec, t, results in L.look_inputs()}
    for cid, look, key, where, truth, cls, text, recount, _r in C2.CASES:
        if cid not in RC:
            continue
        rec, t, results = inp[(look, key)]
        form = {"lead": text}
        cases.append({"set": "record", "id": cid, "truth": truth, "where": where, "form": form, "results": results,
                      "ledger": f"{look}:{key}", "turn": turn_json(V.Turn.of(t)), "why": recount})
    for e in cases:
        lab = (LO.LB["skeptic"] if e["set"] == "skeptic" else LO.LB["rc"]).get(e["id"]) if e["truth"] == "F" else None
        e["class"] = lab["class"] if lab else "true"
        if lab and lab.get("arguable"):
            e["arguable"] = lab["arguable"]
        for m in ("full", "cells"):
            v = V.check_answer(e["form"], e["results"] if "results" in e else None, V.Turn(**dict(e["turn"], today=None)) if not e["turn"]["today"]
                               else V.Turn(**dict(e["turn"], today=__import__("datetime").date.fromisoformat(
                                   e["turn"]["today"]))), mode=m)
            e["kept_" + m] = target(v, e["where"])
    ledgers = {}
    for e in cases:
        ledgers[e["ledger"]] = e.pop("results")
    doc = {"about": __doc__, "ledgers": ledgers, "cases": cases}
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, sort_keys=True, default=str)
        f.write("\n")
    for e in cases:
        print(e["set"], e["id"], e["truth"], e["class"], "full kept" if e["kept_full"] else "full drop",
              "cells kept" if e["kept_cells"] else "cells drop")
    print(os.path.getsize(OUT), "bytes")


if __name__ == "__main__":
    main()
