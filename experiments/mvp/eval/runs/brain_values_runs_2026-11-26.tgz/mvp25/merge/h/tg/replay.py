"""Replay the saved calls of run1 records through today's tools (the tree on sys.path) and print result parts.
python3 replay.py TREE KEY [KEY...]  -> per call: args, then error/meta/sheet bits; --diff: compare with saved."""
import json, os, sys, tempfile
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
RUN = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp24/runa/run1"
from mvp import eval_brain as E  # noqa
base = tempfile.mkdtemp(prefix="tg_replay_", dir="/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad")
H = E.Harness.scratch(base)
from mvp.brain import tools as TL, loop as BL  # noqa
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned  # noqa

_turns = {}

def turn_for(key):
    """The Turn of a record, its last_window (and carried unlock) from replaying the message before."""
    rec = json.load(open(f"{RUN}/{key}.json"))
    cid, n = key.rsplit(".", 1)
    last, carry = None, None
    if int(n) > 0:
        pt, prec = replay(f"{cid}.{int(n) - 1}")
        last = BL.last_window(pt, prec)
        carry = getattr(BL, "unlock_after", lambda t, r: None)(pt, prec)
    kw = {"carried_unlock": carry} if "carried_unlock" in TL.Turn.__dataclass_fields__ else {}
    t = TL.Turn(H.bot, H.person, H.now, message=rec["message"], screen=json.dumps(rec["screen"], sort_keys=True),
                last_window=last, search=FakeEngine(), learned=fake_learned, **kw)
    return t, rec

def replay(key):
    if key in _turns:
        return _turns[key]
    t, rec = turn_for(key)
    new = {"calls": []}
    for c in rec["calls"]:
        env = TL.call(t, c["name"], c["args"])
        new["calls"].append({"name": c["name"], "args": c["args"], "rid": env.get("rid"), "result": env})
    _turns[key] = (t, new)
    return t, new

if __name__ == "__main__":
    keys = [a for a in sys.argv[2:] if not a.startswith("--")]
    for k in keys:
        rec = json.load(open(f"{RUN}/{k}.json"))
        t, new = replay(k)
        print("=" * 80); print(k, rec["message"], "| unlock:", t.unlock)
        for old, c in zip(rec["calls"], new["calls"]):
            env = c["result"]
            strip = lambda e: {k: v for k, v in e.items() if k not in ("took_ms",)}
            same = json.dumps(strip(old["result"]), sort_keys=True, default=str) == json.dumps(strip(env), sort_keys=True, default=str)
            print("  CALL", c["name"], json.dumps(c["args"], separators=(",", ":"))[:300], "| same as saved:", same)
            if env.get("is_error"):
                print("    ERROR:", json.dumps(env, default=str)[:1500])
                continue
            m = env.get("meta") or {}
            print("    meta.window_said:", m.get("window_said"), "| window_dates:", m.get("window_dates"), "| windows:", m.get("windows"))
            for nn in m.get("notes") or []:
                print("    note:", nn[:300])
            for kk in ("export", "tie", "resolved"):
                if kk in m:
                    print("    meta." + kk + ":", json.dumps(m[kk], default=str)[:600])
            sh = env.get("sheet") or {}
            for kk in ("totals", "items", "when", "new"):
                if kk in sh:
                    print("    " + kk + ":", json.dumps(sh[kk], default=str)[:900])
