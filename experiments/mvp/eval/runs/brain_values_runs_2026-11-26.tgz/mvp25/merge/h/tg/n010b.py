import json, sys, os, importlib.util
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
spec = importlib.util.spec_from_file_location("mvp.brain.verify_pre", os.path.join(here, "verify_pre.py"))
V = importlib.util.module_from_spec(spec); V.__package__ = "mvp.brain"; sys.modules["mvp.brain.verify_pre"] = V; spec.loader.exec_module(V)
from mvp.brain import verify as VN  # noqa
t, new = RP.replay("N010.0")
for s in sys.argv[2:]:
    for nm, mod in (("pre", V), ("fix", VN)):
        v = mod.check_answer({"lead": s, "points": []}, t.results, mod.Turn.of(t), mode="cells")
        o = v.lead[0]; print(nm, o.kept, o.reasons, "|", s)
