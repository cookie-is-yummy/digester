"""Every false case of every set with its text, class and whether D1b_a / D1b_d / full let it out (for labelling)."""
import json, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L
def target_text(c):
    f = (c.get("forms") or [c["form"]])[0]
    kind, _, n = (c.get("target") or "point:0").partition(":")
    if kind == "lead":
        return f.get("lead")
    if kind == "point":
        return (f.get("points") or [None] * 9)[int(n or 0)]
    if kind == "outside":
        return json.dumps((f.get("outside") or [{}])[int(n or 0)])
    if kind == "item":
        return json.dumps((f.get("items") or [{}])[int(n or 0)])
cases = {c["id"]: c for c in L.planted_data()["cases"]}
R = {n: {(r["set"], r["id"]): r for r in json.load(open(f"out/{n}.json"))} for n in ("D1b_a", "D1b_d", "full")}
sel = sys.argv[1] if len(sys.argv) > 1 else "out_d"
for k, r in R["D1b_d"].items():
    if r["truth"] != "F" or r["set"] in ("look1", "look2"):
        continue
    if r["set"] == "planted" and r["src"] not in ("new", "audit", "insight_v5", "attack"):
        continue
    flags = "".join(x if R[n][k]["kept"] else "." for x, n in (("a", "D1b_a"), ("d", "D1b_d"), ("f", "full")))
    if sel == "out_d" and "d" not in flags:
        continue
    txt = target_text(cases[r["id"]]) if r["set"] == "planted" else r["text"]
    print(f"{flags} {r['set']}/{r.get('src','')} {r['id']} [{(r.get('class') or '')[:70]}] {txt}")
    if r["set"] != "planted":
        print("      why:", (r.get("why") or "")[:160])
