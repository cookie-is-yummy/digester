import re, json
from mvp.tests.test_mvp import env  # noqa
from mvp.tests.test_brain_tools import brain, built, call, no_real_keys, person, turn  # noqa
from mvp.tests.test_brain_toolgaps import S, W  # noqa

def test_dbg(brain):
    from mvp.brain import verify as V
    env_, t = call(brain, "compare", {"a": W("this summer"), "b": W("last summer"), "by": "area", "scope": S()}, "this summer vs last summer")
    vt = V.Turn.of(t)
    print("TODAY", vt.today, list(t.results), env_["sheet"]["totals"]["items"], env_["sheet"]["previous"]["items"])
    for patch in (False, True):
        old = V._LAST_BEFORE
        if patch:
            V._LAST_BEFORE = re.compile(r"(?!x)x")
        for s in ("This summer you opened 45[r1.totals.items] videos, up from 16[r1.previous.items] last summer.", "Last summer you opened 45[r1.totals.items] videos."):
            v = V.check_answer({"lead": s, "points": []}, V.Ledger(t.results), vt, mode="cells")
            print("PATCH" if patch else "FIX", [(o.kept, o.reasons) for o in v.lead], s[:60])
        V._LAST_BEFORE = old
