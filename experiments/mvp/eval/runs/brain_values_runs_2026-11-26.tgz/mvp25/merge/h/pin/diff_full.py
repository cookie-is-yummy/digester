"""The full-mode differential: every form of every set through the base checker (f22d04f) and the repo checker in
"full" mode (passed, and by MVP_BRAIN_CHECK unset / "full"); the whole verdict compared field by field."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402


def vdump(v):
    out = {"items": v.items, "outside": v.outside, "chart": v.chart, "form_error": v.form_error,
           "private_line": v.private_line, "repair": v.repair, "version": v.version, "lead_ok": v.lead_ok,
           "outcomes": []}
    for o in v.outcomes:
        out["outcomes"].append({k: getattr(o, k) for k in ("where", "index", "text", "reasons", "details", "notes",
                                                           "sent", "rid", "cells", "hidden_rank", "layer", "insight",
                                                           "kept")})
    return repr(out)


def forms():
    data = L.planted_data()
    for c in data["cases"]:
        for k, f in enumerate(c.get("forms") or [c["form"]]):
            yield (f"planted:{c['id']}:{k}", f, data["ledgers"][c["ledger"]], c, None)
    for look, rec, t, results in L.look_inputs():
        for fi, f in enumerate(rec.get("forms") or []):
            yield (f"{look}:{rec['key']}:{fi}", f, results, None, t)
    for c, f, _tgt, t in L.skeptic_inputs():
        yield (f"skeptic:{c[0]}", f, t.results, None, t)
    import rc_cases as C1
    import rc_cases_v2 as C2
    inp = {(look, rec["key"]): (rec, t, results) for look, rec, t, results in L.look_inputs()}
    for ver, cases in (("rc1", C1.CASES), ("rc2", C2.CASES)):
        for cid, look, key, where, truth, cls, text, recount, _r in cases:
            rec, t, results = inp[(look, key)]
            f = {"lead": text} if where == "L" else {"lead": rec["forms"][0].get("lead") or "", "points": [text]}
            yield (f"{ver}:{cid}", f, results, None, t)


def turn_of(mod, c, t):
    return L._pturn(mod, c) if c is not None else mod.Turn.of(t)


def main():
    n = bad = 0
    os.environ.pop("MVP_BRAIN_CHECK", None)
    for name, f, led, c, t in forms():
        b = vdump(L.VB.check_answer(f, L.VB.Ledger(led), turn_of(L.VB, c, t)))
        for how in ("arg", "env_unset", "env_full"):
            if how == "env_full":
                os.environ["MVP_BRAIN_CHECK"] = "full"
            mode = "full" if how == "arg" else None
            r = vdump(L.V.check_answer(f, L.V.Ledger(led), turn_of(L.V, c, t), mode=mode))
            os.environ.pop("MVP_BRAIN_CHECK", None)
            n += 1
            if r != b:
                bad += 1
                if bad <= 5:
                    print("DIFF", name, how)
    print(f"full-mode differential: {n} verdicts compared ({n // 3} forms x 3 ways), {bad} differ")
    return bad


if __name__ == "__main__" and "--answers" not in sys.argv:
    sys.exit(1 if main() else 0)


def answers():
    """fallback.answer and answer.build of every look record's verdicts: base modules (f22d04f, on the base checker)
    against the repo's in full mode."""
    FBb = L._load(os.path.join(L.HERE, "base", "fallback_base.py"), "fallback_base")
    FBb.V = L.VB
    Ab = L._load(os.path.join(L.HERE, "base", "answer_base.py"), "answer_base")
    Ab.V = L.VB
    from mvp.brain import fallback as FB, answer as A
    n = bad = 0
    for look, rec, t, results in L.look_inputs():
        for fi, f in enumerate(rec.get("forms") or []):
            vb = L.VB.check_answer(f, results, L.VB.Turn.of(t))
            vr = L.V.check_answer(f, results, L.V.Turn.of(t), mode="full")
            cb = FBb.answer(L.VB.Ledger(results), vb, L.VB.Turn.of(t))
            cr = FB.answer(L.V.Ledger(results), vr, L.V.Turn.of(t), mode="full")
            ab = Ab.build(L.VB.Ledger(results), verdict=None, code=cb, form=f, also=[vb])
            ar = A.build(L.V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode="full")
            mb = Ab.build(L.VB.Ledger(results), verdict=vb, form=f, also=[vb])
            mr = A.build(L.V.Ledger(results), verdict=vr, form=f, also=[vr], mode="full")
            n += 1
            if repr((cb, ab, mb)) != repr((cr, ar, mr)):
                bad += 1
                print("ANSWER DIFF", look, rec["key"], fi)
    print(f"full-mode answers: {n} forms, code lead + both builds compared, {bad} differ")
    return bad


if __name__ == "__main__" and "--answers" in sys.argv:
    sys.exit(1 if answers() else 0)
