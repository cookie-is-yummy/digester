"""Offline replay of run1 (mvp24/runa/run1): the checker of TREE in MODE over each record's saved FIRST form.
python3 -I run1_replay.py TREE MODE [--replay] [--all]
  default: the saved tool results (what the model saw when it wrote the form);
  --replay: the saved calls re-run with their recorded arguments through TREE's tools (results keyed by the SAVED rid,
            by position; rid shifts and calls that change error state are counted and listed).
Truth: mvp24/recounta/sentences.json (true = T; wrongly_based, false = F; others unlabelled). Made-up library; no model."""
import glob, json, os, sys, tempfile
from collections import Counter
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE, MODE = sys.argv[1], sys.argv[2]
REPLAY, ALL = "--replay" in sys.argv, "--all" in sys.argv
sys.path.insert(0, os.path.join(TREE, "experiments"))
sys.dont_write_bytecode = True
from mvp import eval_brain as E  # noqa
from mvp.brain import verify as V  # noqa
assert V.__file__.startswith(TREE), V.__file__
RUN = os.path.join(S, "mvp24/runa/run1")
LAB = {(r["key"], r["form_index"], r["where"], r["index"]): r
       for r in json.load(open(os.path.join(S, "mvp24/recounta/sentences.json"))) if r.get("form_index") is not None}
TR = {"true": "T", "wrongly_based": "F", "false": "F"}
base = tempfile.mkdtemp(prefix="r1replay_", dir=os.path.join(S, "mvp25/merge"))
H = E.Harness.scratch(base)
recs = {os.path.basename(p)[:-5]: json.load(open(p)) for p in sorted(glob.glob(os.path.join(RUN, "N*.json")))}
shifts, flips = [], []

if REPLAY:
    from mvp.brain import tools as TL, loop as BL  # noqa
    from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned  # noqa
    _done = {}

    def replay(key):
        if key in _done:
            return _done[key]
        rec = recs[key]
        cid, n = key.rsplit(".", 1)
        last = carry = None
        if int(n) > 0 and f"{cid}.{int(n) - 1}" in recs:
            pt, prec = replay(f"{cid}.{int(n) - 1}")
            last = BL.last_window(pt, prec)
            ua = getattr(BL, "unlock_after", None)
            carry = ua(pt, prec) if ua else None
        kw = {"carried_unlock": carry} if "carried_unlock" in TL.Turn.__dataclass_fields__ else {}
        t = TL.Turn(H.bot, H.person, H.now, message=rec["message"], screen=json.dumps(rec["screen"], sort_keys=True),
                    last_window=last, search=FakeEngine(), learned=fake_learned, **kw)
        new = {"calls": []}
        for c in rec["calls"]:
            env = TL.call(t, c["name"], c["args"])
            new["calls"].append({"name": c["name"], "args": c["args"], "rid": env.get("rid"), "result": env})
        _done[key] = (t, new)
        return t, new

rows = []
for key, rec in recs.items():
    if REPLAY:
        t, new = replay(key)
        results = {}
        for old, c in zip(rec["calls"], new["calls"]):
            oe = bool((old.get("result") or {}).get("is_error")) or not old.get("rid")
            ne = bool(c["result"].get("is_error"))
            if oe != ne:
                flips.append(f"{key} {c['name']} error {oe}->{ne}")
            if old.get("rid") and c.get("rid") and old["rid"] != c["rid"]:
                shifts.append(f"{key} {c['name']} {old['rid']}->{c['rid']}")
            if old.get("rid") and not oe and not ne:
                env = dict(c["result"]); env["rid"] = old["rid"]
                results[old["rid"]] = env
        vt = V.Turn.of(t)
    else:
        t = H.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        vt = V.Turn.of(t)
    forms = rec.get("forms") or []
    for fi, form in enumerate(forms if ALL else forms[:1]):
        v = V.check_answer(form, results, vt, mode=MODE)
        for o in v.outcomes:
            lab = LAB.get((key, fi, o.where, o.index))
            rows.append({"key": key, "fi": fi, "where": o.where, "index": o.index, "kept": bool(o.kept),
                         "truth": None if lab is None else TR.get(lab["truth"]), "reasons": list(o.reasons),
                         "text": o.text})
first = [r for r in rows if r["fi"] == 0]
c = Counter((r["truth"], r["kept"]) for r in first)
leads = {}
for r in first:
    if r["where"] == "lead":
        leads[r["key"]] = leads.get(r["key"], True) and r["kept"]
nrec = len({r["key"] for r in first})
print(f"tree {os.path.basename(TREE)} mode {MODE} results {'replayed through the tree' if REPLAY else 'as saved'}")
print(f"first forms: {nrec} records, {len(first)} sentences, kept {sum(r['kept'] for r in first)}")
print(f"  true kept {c[('T', True)]} of {c[('T', True)] + c[('T', False)]}; false kept {c[('F', True)]} of "
      f"{c[('F', True)] + c[('F', False)]}; unlabelled kept {c[(None, True)]} of {c[(None, True)] + c[(None, False)]}")
print(f"  model lead kept on the first pass: {sum(1 for k in leads.values() if k)} of {nrec}")
print("  true lost by reason:", dict(Counter(x for r in first if r["truth"] == "T" and not r["kept"] for x in r["reasons"])))
if REPLAY:
    print(f"  replay: {len(shifts)} rid shifts {shifts}; {len(flips)} calls changed error state: {flips}")
json.dump(rows, open(os.path.join(S, "mvp25/merge", f"run1_{os.path.basename(TREE)}_{MODE}_{'replay' if REPLAY else 'saved'}.json"), "w"), indent=0)
import shutil; shutil.rmtree(base, ignore_errors=True)
