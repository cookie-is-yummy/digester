"""The class of every false case of every set: cell, framing or policy. Written from the task's own words before any
leave-one-out run of the doubtful codes; hashed in labels.sha256 when written. The planted part (builder and attack) is
written into the repo (eval/brain_cells_classes.json) for `planted --check cells`; the rest stays here (labels.json).

THE RULE (applied case by case; the class string of a case decides only where the rule gives the same answer for
every case of that string):
  CELL: the fault shows in a value the sentence says, against the cell or row its marker cites, or in arithmetic
    between cited cells: a wrong number, number word ('half', 'twice', 'tripled', 'a third', a typed sign), name,
    title, date or time; a calculation; a marker grammar fault (no marker, a bad path, two results, a forged
    marker); a value bound to the wrong ROW (another row's cell, a period row called by another row's label, a
    totals cell said of a row, a row's cell said of the totals, a row placed in a group its row does not name) or to
    the wrong MEASURE (openings as videos, days as videos, a count as a share or a difference, points as a percent,
    the Shorts share as the long share, now and before swapped into 'from ... to', a share move from a count). A
    direction word bound to a marked change value ('rose 37 points', 'up 4 points', '45% fewer') gives that value's
    sign, so a wrong sign is a wrong number.
  FRAMING: you need something beyond the cited cells to see it: the window or period words, the base, the scope
    (length, platform, weekday, saved or opened, a topic filter), a rank, tie, order, first or last, list
    completeness, only/all, most/mostly, hidden private rows, or a direction or comparison word with no marked
    change value ('grew', 'slowed to 142 from 44', 'more than', 'held steady', 'a little').
  POLICY: outside knowledge, feelings and motives, outcomes, watch time, sensitive topics, limits talk, a weak match,
    repeating a fact already said.
  ARGUABLE: the case where the rule can be read both ways; reported both ways, never relabelled after a run."""
import hashlib
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_FILE = os.path.join(L.PIN, "mvp", "eval", "brain_cells_classes.json")

# ---------------------------------------------------------------- the builder's planted cases (new, audit, insight_v5)
B_BY_CLASS = [   # (regex on the class string, class); first match wins; per-id overrides below win over these
    (r"^3\.1 |^3\.2 |^3\.3 |^3\.4 |^3\.6 ", "cell"),
    (r"^3\.5 'up' under 3 points", "framing"),
    (r"^3\.5 ", "cell"),
    (r"^3\.7 |^3\.10 |^3\.11 |^watch time:", "policy"),
    (r"^3\.8 |^3\.12 |^3\.15 |^3\.9 ", "framing"),
    (r"^hand check: a value of one record under another's name|^hand check: a channel behind a theme|"
     r"^hand check: 'more' that counts re-opens|^hand check: openings said as videos|^hand check: a forged", "cell"),
    (r"^hand check: ", "framing"),
    (r"^4 a weak match", "policy"),
    (r"^4 a quoted title", "cell"),
    (r"^4 ", "framing"),
    (r"^(?:wrong_name|wrong_field|ratio|num_words|reopen|forged|calc_literal|unit|theme_place|two_results)\b", "cell"),
    (r"^(?:base|long_as_all|window|tie|trend|status|first_last|other_fact|hidden_rows|spread|close|find_rank|least|"
     r"scope|search|comparative|count_cut)\b", "framing"),
    (r"^(?:outside|watch_time|private)\b", "policy"),
    (r"^planted: (?:bound|difference|channel_not_in_theme|mixed_change)$", "cell"),
    (r"^planted: watch_time$", "policy"),
    (r"^planted: ", "framing"),
    (r"^true_rewritten$", "framing"),
]
B_IDS = {
    # 4.3 steps 2, 5, 6, 14 (form-level cases)
    "o_subscribers": ("policy", "outside line: a world claim"), "o_web": ("policy", "outside line from the web"),
    "o_you": ("policy", "outside line: a feeling"), "o_not_cited": ("cell", "outside line about a row not cited"),
    "o_other_name": ("cell", "outside line names another row"), "i_note_number": ("cell", "a number in an item note"),
    "i_not_item": ("cell", "an item ref that is no item"), "r_repeat": ("policy", "the same cells said again"),
    "l_too_long": ("cell", "a lead past its length (marker grammar)"), "l_window_missing": ("framing", "window"),
    # audit cases the class string does not decide
    "audit_F83": ("cell", "a period row (Oct 2026) called by another row's label (September 2026)"),
    "audit_F83c": ("cell", "periods[0] is 2021, said '2022'"),
    "audit_F83e": ("cell", "periods[0]'s count said of the 2022 row"),
    "audit_F84": ("cell", "periods[8] is September, said 'October 2026'"),
    "audit_F32c": ("cell", "a last date with no marker, and not the last item's day (20 October)"),
    "audit_F32d": ("cell", "a last date with no marker, and not the last item's day (20 October)"),
    "audit_F34": ("cell", "the date said is not the first_watched cell"),
    "audit_F87": ("cell", "the hour said (8 pm) is not the item's time (3 pm)"),
    "audit_F31c": ("framing", "a channel's first_watched said as the theme's first (order over a subset)", "cell"),
    "audit_F38c": ("framing", "'more than in 2023' with no marker: a comparison word"),
    "audit_F75b": ("cell", "an uncited name"),
    "audit_F59": ("framing", "Spanish: a window word"), "audit_F60": ("cell", "Spanish: an uncited number word"),
    "audit_F61": ("framing", "Spanish: a direction word with no change value"),
    "audit_F62": ("cell", "Spanish: an uncited ratio word"), "audit_F63": ("policy", "Spanish: watch time"),
    "audit_F64": ("policy", "Spanish: outside knowledge"), "audit_F64b": ("framing", "Spanish: 'most of'"),
    "audit_F64c": ("framing", "Spanish: 'almost as many'"),
    "audit_F43": ("policy", "a sensitive topic named"), "audit_F44": ("policy", "a sensitive topic named"),
    "audit_F44b": ("policy", "a sensitive topic named"),
    "audit_F80": ("framing", "'stopped' with no marker"),
    # insight_v5 cases the class string does not decide
    "v5_004": ("framing", "a channel's total said 'of your Blender 3D videos' (base)", "cell"),
    "v5_013": ("framing", "a theme's share said 'of your home cooking videos' (base)", "cell"),
    "v5_017": ("framing", "a channel's total said 'of your math explainers videos' (base)", "cell"),
    "v5_025": ("framing", "a channel's total said 'of your cozy gaming videos' (base)", "cell"),
    "v5_055": ("framing", "'Shorts made up 700 of your window': a count in share words", "cell"),
    "v5_062": ("cell", "'tripled' (a ratio word, x3) against 3% to 9%"),
    "v5_117": ("framing", "a change said with a clause code would have to add"),
    "v5_120": ("framing", "a count of 'only music' said without the topic (scope)"),
    "v5_121": ("framing", "a count of 'only music' said without the topic (scope)"),
    "v5_122": ("framing", "a count of 'only music' said without the topic (scope)"),
    "v5_115": ("framing", "saved-and-never-opened said as saved (scope)"),
    "v5_098": ("framing", "'close behind' (rank word) across two measures"),
}
# ---------------------------------------------------------------- the attack (eval/brain_attack_cases.py), by base id
A_BY_CLASS = {"number_word": "cell", "calc_rows": "cell", "owner": "cell", "measure": "cell",
              "title": "policy", "outside": "policy", "outside_theme": "policy", "motive": "policy"}
A_IDS = {
    "X01": ("cell", "from/to: the now cell in the 'from' slot"), "X02": ("cell", "from/to: the now cell in 'from'"),
    "X03": ("cell", "from/to: the now cell in the 'from' slot"),
    "C07": ("cell", "from/to: the to_share cell said 'from ... in 2021'"),
    "D01": ("cell", "periods[0] is 2021, said 'in 2022'"),
    "G02": ("cell", "'45% fewer[=pct_change]' of +45%: a typed direction on a marked change"),
    "P03": ("cell", "Clip Factory's share cell said of Pan Theory and Pixel Pencil together (bound to another row)"),
    "Q01": ("cell", "'1 October 2026[when], a Sunday': the weekday of the cited date is Thursday", "framing"),
    "Q07": ("framing", "'watched it the same day' of a row never opened (a status word)", "cell"),
    "X09": ("cell", "an uncited name and number"), "X10": ("cell", "days said as videos"),
    "C08": ("cell", "'tripled[=ratio]' of x2.1: a calculation"),
    "D05": ("cell", "'more than twice as many' with no marker: an uncited number word (254 / 157 = 1.6)"),
    "G04": ("cell", "the totals' pct_change said of Limit Lane (bound to another row)"),
    "G05": ("cell", "'nearly doubled[=ratio(before, now)]': a calculation"),
    "H04": ("cell", "'twice as busy' with no marker: an uncited number word (33 against 32)"),
    "Q02": ("cell", "'two weeks after' with no marker: an uncited number (6 days)"),
    "Q08": ("cell", "'two days before' between two cited dates of the same day: arithmetic between cited cells"),
    "Q11": ("cell", "'the night of 1 October 2026[when]': the cited time is 4 pm", "framing"),
}
# ---------------------------------------------------------------- the skeptic's set (mvp22/skeptic/cases.py)
SK_CELL = {"K03": "'half your year' (a number word) of 36%", "K30": "'doubled' (x2) of x15",
           "K37": "the long videos' median said of Shorts", "K39": "Gaming clips' Shorts share said of all you opened",
           "K45": "'twice over' against the cited months", "K46": "'five times' of 3.2"}
SK_ARGUABLE = {"K37": "framing", "K26": "cell", "K27": "cell"}
SK_POLICY = set()
# ---------------------------------------------------------------- the record checker's set (cases.py, cases_v2.py)
RC_CELL = {"N24": "Gaming clips' 'before' cell said as Digital drawing's 'from'",
           "N25": "from/to: the now cell in the 'from' slot",
           "N33": "periods[8] (September) called 'August 2026'"}
RC_NOT_FALSE = {"RT6": "literally true (record_check CORRECTIONS)"}


def b_class(c):
    if c["id"] in B_IDS:
        return B_IDS[c["id"]]
    k = re.sub(r"\s*\(the audit expected.*", "", c.get("class") or "")
    for rx, cl in B_BY_CLASS:
        if re.search(rx, k):
            return (cl, None)
    raise KeyError((c["id"], k))


def main():
    planted = {}
    for c in L.planted_data()["cases"]:
        if c["expect"] == "kept" or c.get("source") in ("attack_true", "audit_true"):
            continue
        if c.get("source") == "attack":
            base = re.sub(r"^attack_", "", c["id"])
            base = re.sub(r"_[LP]$", "", base)
            if base in A_IDS:
                v = A_IDS[base]
            else:
                v = (A_BY_CLASS.get((c.get("class") or "").split(":")[0], "framing"), None)
        else:
            v = b_class(c)
        e = {"class": v[0]}
        if len(v) > 1 and v[1]:
            e["why"] = v[1]
        if len(v) > 2:
            e["arguable"] = v[2]
        planted[c["id"]] = e
    import skeptic_cases as K
    import rc_cases as RC
    sk = {}
    for c in K.CASES:
        cid = c[0]
        cl = "cell" if cid in SK_CELL else ("policy" if cid in SK_POLICY else "framing")
        e = {"class": cl}
        if cid in SK_CELL:
            e["why"] = SK_CELL[cid]
        if cid in SK_ARGUABLE:
            e["arguable"] = SK_ARGUABLE[cid]
        sk[cid] = e
    rc = {}
    for c in RC.CASES:
        cid, truth = c[0], c[4]
        if truth != "F":
            continue
        if cid in RC_NOT_FALSE:
            rc[cid] = {"class": "not_false", "why": RC_NOT_FALSE[cid]}
            continue
        e = {"class": "cell" if cid in RC_CELL else "framing"}
        if cid in RC_CELL:
            e["why"] = RC_CELL[cid]
        rc[cid] = e
    looks = {"*": {"class": "framing", "why": "mvp22/raw: every false sentence of both looks is framing"}}
    doc = {"rule": __doc__.split("THE RULE")[1].strip(), "planted": planted}
    txt = json.dumps(doc, indent=1, sort_keys=True) + "\n"
    open(REPO_FILE, "w").write(txt)
    rest = json.dumps({"skeptic": sk, "rc": rc, "looks": looks}, indent=1, sort_keys=True) + "\n"
    open(os.path.join(HERE, "labels.json"), "w").write(rest)
    h1, h2 = hashlib.sha256(txt.encode()).hexdigest(), hashlib.sha256(rest.encode()).hexdigest()
    from collections import Counter
    print("planted", Counter(e["class"] for e in planted.values()), "skeptic", Counter(e["class"] for e in sk.values()),
          "rc", Counter(e["class"] for e in rc.values()))
    print(h1, "brain_cells_classes.json")
    print(h2, "labels.json")


if __name__ == "__main__":
    main()
