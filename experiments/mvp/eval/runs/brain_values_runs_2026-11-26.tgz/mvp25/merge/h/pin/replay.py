"""Step 7: the pinned cells mode replayed on the saved held-out records (look 1 = mvp20/tune/heldout, look 2 =
mvp20/fix/heldout_run; their first forms, as the model wrote them), with mvp22/raw/sentences.json as the truth.
Beside it: full mode (today) and the record table's D1b/d. No model call. The repair forms answer FULL-mode repair
messages, so what a repair would give in cells mode is not measured; only first-pass figures are."""
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402
import tally as T  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


def look_rows(name):
    cm, chain = T.mode_of(name)
    T.paper_chain(chain)
    try:
        return L.run_looks(L.V, cm)
    finally:
        T.paper_chain(False)


def stats(rows, look):
    c = T.looks(rows, look)
    first = [r for r in rows if r["set"] == look and r["form_index"] == 0]
    out = [f"{r['key']} {r['where']}{r['index']}" for r in first if r["truth"] == "F" and r["kept"]]
    lost = Counter(x.split(":")[0] for r in first if r["truth"] == "T" and not r["kept"] for x in r["reasons"])
    other = Counter(r["truth"] for r in first if r["truth"] not in ("T", "F"))
    return c, out, lost, other


def main():
    lines = ["STEP 7: CELLS MODE ON THE SAVED HELD-OUT FIRST FORMS (no model call; truth: mvp22/raw/sentences.json)",
             "look 1 = the first look (tree 4ce8a5a), look 2 = the second look (bee4b4e); 53 answers each.", ""]
    hdr = f"{'mode':8s} {'look':5s} {'false out':>10s} {'true lost':>14s} {'model lead kept 1st':>20s} {'repairs due':>12s}"
    lines.append(hdr)
    detail = []
    res = {}
    for name in ("full", "cells", "D1b_d"):
        rows = look_rows(name)
        for look in ("look1", "look2"):
            c, out, lost, other = stats(rows, look)
            res[(name, look)] = c
            lines.append(f"{name:8s} {look:5s} {c['bad_out']:>4d} of {c['bad']:<3d} {c['true_lost']:>5d} of {c['true']:<3d}"
                         f"({100 * c['true_lost'] / c['true']:>2.0f}%) {c['lead_kept']:>9d} of {c['answers']:<6d}"
                         f" {c['repair_due']:>8d}")
            detail.append(f"  {name} {look}: false out {out}; true lost by reason {dict(lost.most_common())}"
                          + (f"; not scored: {dict(other)}" if other else ""))
    lines += [""] + detail
    lines += ["", "Every false sentence of both looks is framing-class (mvp22/raw: no wrong number, name, date or",
              "calculation); in cells mode they are allowed out and counted. The repair forms were written against",
              "full-mode repair messages: what the model would write after a cells-mode repair is not measured."]
    txt = "\n".join(lines) + "\n"
    open(os.path.join(HERE, "replay_heldout.txt"), "w").write(txt)
    print(txt)


if __name__ == "__main__":
    main()
