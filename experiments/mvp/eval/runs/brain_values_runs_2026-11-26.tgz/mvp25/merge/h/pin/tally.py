"""Counts of one checker setting on every set (made-up library; no model call).
    python3 tally.py repro        the mvp23 record table's D1b/a and D1b/d rows, from the repo's switches
    python3 tally.py <name>       a named setting of SETTINGS (prints the line, writes out/<name>.json)"""
import json
import os
import sys
from collections import Counter

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402

V = L.V
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
os.makedirs(OUT, exist_ok=True)
TAX_FRAMING = frozenset({
    "wrong_window", "window_missing", "filter_dropped", "scope_broadened", "base", "base_missing", "no_base",
    "insight_rewrite", "rank", "not_top", "tie", "least", "spread", "mostly", "mix", "previous",
    "direction_unbound", "no_direction", "small_move", "vague", "one_value", "first_last", "private_total",
    "platform_word", "length_word", "shorts_left_out", "own_shorts_share", "shorts_as_long", "share_of_topic",
    "weekpart", "weekday", "year", "hour", "time_of_day", "not_close", "not_new", "not_stopped", "order",
    "gap_words", "median_of_window", "number_run"})   # mvp22 paper/taxonomy.py FRAMING, as frozen there
TAX_DOUBT = frozenset({"direction", "uncited_claim", "limits", "unnamed_owner", "bound_global"})
D1B = frozenset({"title_quote", "item_channel", "short_word", "platform_all"})

_ORIG_FIX = V._fix_rules


def paper_chain(on):
    """The paper copy's rule chain (stops at the first hit even when its code is off) when on; the repo's walk-past
    when off."""
    if on:
        V._fix_rules = lambda *a: _ORIG_FIX(*a[:-1], V.FULL)
    else:
        V._fix_rules = _ORIG_FIX


def mode_of(name):
    """(CheckMode, paper_chain) of a setting name."""
    if name == "D1b_a":
        return V.CheckMode("D1b_a", off=TAX_FRAMING, loose=D1B, insight="on"), True
    if name == "D1b_d":
        return V.CheckMode("D1b_d", off=TAX_FRAMING | TAX_DOUBT, loose=D1B, insight="off"), True
    if name == "full":
        return V.FULL, False
    if name == "cells":
        return V.CELLS, False
    # "cells+X,Y" / "cells-X,Y": the pinned cells mode with codes switched back on (+) or off (-)
    if name.startswith("cells") and len(name) > 5:
        op, codes = name[5], frozenset(name[6:].split(","))
        off = V.CELLS.off - codes if op == "+" else V.CELLS.off | codes
        loose = V.CELLS.loose
        if "noloose" in codes:
            loose = frozenset()
            off = off - {"noloose"}
        ins = V.CELLS.insight
        if "insight_off" in codes:
            ins = "off"
            off = off - {"insight_off"}
        return V.CheckMode(name, off=frozenset(off), loose=loose, insight=ins, cells=True), False
    raise KeyError(name)


def run(name):
    cm, chain = mode_of(name)
    paper_chain(chain)
    try:
        rows = L.run_all(V, cm)
    finally:
        paper_chain(False)
    return rows


def handled(r):
    """A false case is handled when it is dropped, or kept under code's private line where it asks for that line."""
    if not r["kept"]:
        return True
    return r.get("expect") == "private_line" and r["private_line"]


def looks(rows, look):
    c = Counter()
    sents, leads = {}, {}
    for r in rows:
        if r["set"] != look or r["form_index"] != 0:
            continue
        if r["truth"] == "F":
            c["bad"] += 1
            c["bad_out"] += r["kept"]
        elif r["truth"] == "T":
            c["true"] += 1
            c["true_lost"] += not r["kept"]
        if r["where"] in ("lead", "point"):
            sents.setdefault(r["key"], []).append(r)
            if r["where"] == "lead":
                leads[r["key"]] = leads.get(r["key"], True) and bool(r["kept"])
    c["answers"] = len(sents)
    c["lead_kept"] = sum(1 for k in sents if leads.get(k, False))
    c["repair_due"] = sum(1 for k, rs in sents.items() if not leads.get(k, False) or
                          sum(not x["kept"] for x in rs) * 2 > len(rs))
    return c


def line(rows):
    pl = [r for r in rows if r["set"] == "planted"]
    bF = [r for r in pl if r["src"] in ("new", "audit", "insight_v5") and r["truth"] == "F"]
    bT = [r for r in pl if r["src"] in ("new", "insight_v5") and r["truth"] == "T"]
    aF = [r for r in pl if r["src"] == "attack"]
    aT = [r for r in pl if r["src"] == "attack_true"]
    uT = [r for r in pl if r["src"] == "audit_true"]
    sk = [r for r in rows if r["set"] == "skeptic"]
    rc = [r for r in rows if r["set"] == "rc2" and not r["dup"]]
    l1, l2 = looks(rows, "look1"), looks(rows, "look2")
    return {
        "L1": f"bad {l1['bad_out']}/{l1['bad']} lost {l1['true_lost']}/{l1['true']} lead {l1['lead_kept']}/"
              f"{l1['answers']} rep {l1['repair_due']}",
        "L2": f"bad {l2['bad_out']}/{l2['bad']} lost {l2['true_lost']}/{l2['true']} lead {l2['lead_kept']}/"
              f"{l2['answers']} rep {l2['repair_due']}",
        "attack_out": f"{sum(not handled(r) for r in aF)}/{len(aF)} (kept {sum(r['kept'] for r in aF)})",
        "attack_true": f"{sum(r['kept'] for r in aT)}/{len(aT)}", "audit_true": f"{sum(r['kept'] for r in uT)}/{len(uT)}",
        "builder_F_out": f"{sum(not handled(r) for r in bF)}/{len(bF)}", "builder_T": f"{sum(r['kept'] for r in bT)}/{len(bT)}",
        "skeptic_F_out": f"{sum(r['kept'] for r in sk if r['truth'] == 'F')}/{sum(r['truth'] == 'F' for r in sk)}",
        "skeptic_T": f"{sum(r['kept'] for r in sk if r['truth'] == 'T')}/{sum(r['truth'] == 'T' for r in sk)}",
        "rc2_F_out": f"{sum(r['kept'] for r in rc if r['truth'] == 'F')}/{sum(r['truth'] == 'F' for r in rc)}",
        "rc2_T": f"{sum(r['kept'] for r in rc if r['truth'] == 'T')}/{sum(r['truth'] == 'T' for r in rc)}",
    }


def save(name, rows):
    with open(os.path.join(OUT, name.replace("/", "_") + ".json"), "w") as f:
        json.dump(rows, f, indent=0, default=str)


if __name__ == "__main__":
    names = sys.argv[1:]
    if names == ["repro"]:
        names = ["D1b_a", "D1b_d"]
    for n in names:
        rows = run(n)
        save(n, rows)
        print(n, json.dumps(line(rows)))
