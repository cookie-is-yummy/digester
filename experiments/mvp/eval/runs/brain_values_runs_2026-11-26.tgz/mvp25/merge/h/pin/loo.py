"""Leave one out: cells mode with every doubtful code ON, then each doubtful code (and each emitter of a code several
rules give) switched OFF alone. For each setting: the cell-class false cases let out (by the frozen labels), the true
sentences gained and lost against the all-on base, and the framing-class cases let out. No model call.
    python3 loo.py [extra setting names...]"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tally as T  # noqa: E402
import lib as L  # noqa: E402

V = L.V
HERE = os.path.dirname(os.path.abspath(__file__))
PL = json.load(open(os.path.join(L.PIN, "mvp", "eval", "brain_cells_classes.json")))["planted"]
LB = json.load(open(os.path.join(HERE, "labels.json")))


def klass(r):
    if r["set"] == "planted":
        e = PL.get(r["id"])
    elif r["set"] == "skeptic":
        e = LB["skeptic"].get(r["id"])
    elif r["set"] in ("rc1", "rc2"):
        e = LB["rc"].get(r["id"])
    else:
        e = {"class": "framing"}
    return (e or {}).get("class", "?"), (e or {}).get("arguable")


def false_rows(rows):
    out = []
    for r in rows:
        if r["truth"] != "F":
            continue
        if r["set"] == "planted" and r["src"] not in ("new", "audit", "insight_v5", "attack"):
            continue
        if r["set"] in ("look1", "look2") and r["form_index"] != 0:
            continue
        if r["set"] == "rc2" and r.get("dup"):
            continue
        out.append(r)
    return out


def key(r):
    return (r["set"], r["id"])


def summary(rows):
    leaks, framing_out, policy_out = [], [], []
    for r in false_rows(rows):
        if T.handled(r):
            continue
        c, arg = klass(r)
        if c == "cell":
            leaks.append(r)
        elif c == "framing":
            framing_out.append(r)
        elif c == "policy":
            policy_out.append(r)
    trues = {key(r): r["kept"] for r in rows if r["truth"] == "T" and not (r["set"] == "rc2" and r.get("dup"))
             and not (r["set"] in ("look1", "look2") and r["form_index"] != 0)}
    return leaks, framing_out, policy_out, trues


SETTINGS = ["cells-direction", "cells-direction@sign", "cells-direction@calc", "cells-direction@compare",
            "cells-direction@from_to", "cells-direction@insight",
            "cells-uncited_claim", "cells-uncited_claim@nomarker", "cells-uncited_claim@bare",
            "cells-uncited_claim@compare", "cells-uncited_claim@all_from",
            "cells-limits", "cells-limits@words", "cells-limits@self", "cells-limits@insight",
            "cells-unnamed_owner", "cells-bound_global", "cells-repeat", "cells-repeat@once", "cells-repeat@insight",
            "cells-insight_off", "cells+noloose"]


def main(names):
    base_rows = T.run("cells")
    T.save("cells_allon", base_rows)
    bl, bf, bp, bt = summary(base_rows)
    print(f"ALL ON (pinned candidate: {sorted(V.CELLS.off - T.TAX_FRAMING)} off beyond framing)")
    print(f"  cell leaks {len(bl)}: {[k for k in map(key, bl)]}")
    print(f"  framing out {len(bf)}, policy out {len(bp)}: {[key(r) for r in bp]}")
    print(f"  true kept {sum(bt.values())}/{len(bt)}")
    res = {}
    for n in names or SETTINGS:
        rows = T.run(n)
        lk, fo, po, tr = summary(rows)
        gained = [k for k in tr if tr[k] and not bt.get(k)]
        lost = [k for k in tr if not tr[k] and bt.get(k)]
        new_leaks = [key(r) for r in lk if key(r) not in {key(x) for x in bl}]
        new_pol = [key(r) for r in po if key(r) not in {key(x) for x in bp}]
        closed = [key(r) for r in bl if key(r) not in {key(x) for x in lk}]
        res[n] = {"new_cell_leaks": new_leaks, "true_gained": gained, "true_lost": lost,
                  "framing_out": len(fo), "new_policy_out": new_pol, "closed": closed}
        print(f"{n:30s} cell leaks +{len(new_leaks)} {new_leaks} | true +{len(gained)} -{len(lost)} | "
              f"framing out {len(fo)} | policy +{new_pol} | closed {closed}")
    json.dump(res, open(os.path.join(HERE, "out", "loo.json"), "w"), indent=1, default=str)


if __name__ == "__main__":
    main(sys.argv[1:])
