#!/bin/bash
# run mvp/tests in 4 parallel shards by file (sorted by size, round-robin)
cd /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/merge_tree/experiments
OUT=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/merge/suite_out
rm -rf $OUT; mkdir -p $OUT
files=$(ls -S mvp/tests/test_*.py)
i=0
for f in $files; do echo $f >> $OUT/list$((i%4)); i=$((i+1)); done
for k in 0 1 2 3; do
  python3 -m pytest -q -p no:cacheprovider $(cat $OUT/list$k) > $OUT/res$k 2>&1 &
done
wait
for k in 0 1 2 3; do tail -1 $OUT/res$k; done
grep -h -E '^(FAILED|ERROR)' $OUT/res* | head -40
