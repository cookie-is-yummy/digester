import json, os, sys
S = sys.argv[1]
old = json.load(open(os.path.join(S, "mvp24/recounta/answers.json")))
poor = [x for x in old if x["grade"] == "poor"]
out = ["mvp25 runa2: the 25 answers mvp24's reader (recounta/answers.json) marked poor, last round's answer beside this",
       "round's. Last round: mvp24/runa/run1 (4064f3e). This round: mvp25/runa2/run1 (brain-r25-local 0bd8720).",
       "No truth judgement here: the next agent recounts. 'last round's grade / cause' are mvp24's reader's marks.",
       ""]
for x in poor:
    r = json.load(open(os.path.join(S, "mvp25/runa2/run1", x["key"] + ".json")))
    a = r.get("answer") or {}
    out.append(f"==== {x['key']} | message: {x['message']}")
    out.append(f"LAST ROUND  | lead {x['lead_source']} | grade {x['grade']} (strict {x['grade_strict']}, lenient "
               f"{x['grade_lenient']}) | cause: {x['poor_cause']} | answers the question: {x['answers_question']} | "
               f"says what the numbers mean: {x['says_what_numbers_mean']}")
    for line in (x["sent_text"] or "(nothing)").split("\n"):
        out.append("  | " + line)
    se = r["sentences"]
    out.append(f"THIS ROUND  | lead {r['lead_source']} | {r['seconds']} s | requests {r['n_requests']} | sentences "
               f"written/first/sent {se['written']}/{se['kept_first_pass']}/{se['kept_sent']} | repair "
               f"{'yes' if r.get('repair_message') else 'no'} | events {r.get('events') or []} | error {r.get('error')}"
               f" | G2 {r['g2']['verdict']}")
    for line in (a.get("text") or "(nothing)").split("\n"):
        out.append("  | " + line)
    out.append("")
print("\n".join(out))
