"""Drop reasons by the pinned classes of verify.py; read calls the loop did not run; provider errors. No model call."""
import glob, json, os, sys
tree, run = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(tree, "experiments"))
from mvp.brain import verify as V
recs = []
for f in glob.glob(os.path.join(run, "N*.json")):
    recs.append(json.load(open(f, encoding="utf-8")))
recs.sort(key=lambda r: (r["key"].split(".")[0], int(r["key"].split(".")[1])))
off = V.CELLS.off
print(f"drop reasons by the pinned classes of verify.py (cells mode off-set has {len(off)} codes):")
cnt = {}
for r in recs:
    for d in r["dropped"]:
        for c in d["reasons"]:
            cnt[c] = cnt.get(c, 0) + 1
def cls(c):
    base = c.split(":")[0]
    if base in V.DOUBT_CODES or any(k.split("@")[0] == base for k in V.DOUBT_CODES):
        em = {k: v for k, v in V.DOUBT_CODES.items() if k.split("@")[0] == base}
        return "doubtful, decided per emitter: " + ", ".join(f"{k}={v}" for k, v in em.items())
    if base in V.CELL_CODES: return "cell"
    if base in V.POLICY_CODES: return "policy"
    if base in V.FRAMING_CODES: return "framing" + (" (kept on: FRAMING_KEPT)" if base in V.FRAMING_KEPT else "")
    return "UNCLASSED"
tot = {}
for c, n in sorted(cnt.items(), key=lambda x: -x[1]):
    k = cls(c); print(f"  {c}: {n} -> {k}" + ("  [IN OFF SET]" if c in off else ""))
    kk = k.split(",")[0].split(" ")[0]; tot[kk] = tot.get(kk, 0) + n
print(f"  totals by class: {tot}")
print()
print("read calls the loop did not run (tool_use blocks of a request with no matching call record):")
for r in recs:
    for i, q in enumerate(r["requests"]):
        want = [b.get("name") for b in q["blocks"] if b.get("type") == "tool_use" and b.get("name") != "give_answer"]
        got = [c["name"] for c in r["calls"] if c["round"] == i + 1]
        miss = list(want)
        for g in got:
            if g in miss: miss.remove(g)
        if miss:
            print(f"  {r['key']} request {i + 1}: not run: {miss} (events {r.get('events')})")
print()
print("turn errors / provider errors:")
for r in recs:
    if r.get("error") or "provider_error" in (r.get("events") or []):
        print(f"  {r['key']}: error {r.get('error')!r}, events {r.get('events')}, requests {r['n_requests']}, "
              f"lead {r['lead_source']}")
print()
print("halves in records:", sorted({r.get("half") for r in recs}), "records:", len(recs))
