import glob, json, os, sys
def load(run):
    rs = [json.load(open(f)) for f in glob.glob(os.path.join(run, "N*.json"))]
    rs.sort(key=lambda r: (r["key"].split(".")[0], int(r["key"].split(".")[1])))
    return rs
for run in sys.argv[1:]:
    rs = load(run)
    a0 = rs[0]["answer"]
    priv = sum(1 for r in rs if "Leaving out topics you keep private." in ((r.get("answer") or {}).get("text") or ""))
    nooff = sum(1 for r in rs if not (r.get("answer") or {}).get("offers") and not (r.get("answer") or {}).get("offer"))
    secs = [r["seconds"] for r in rs]
    code = [r["key"] for r in rs if r["lead_source"] not in ("model", "model_after_repair")]
    print(run, "answer keys", sorted(a0.keys()))
    print("  private line", priv, "no offer", nooff, "over 8s", sum(s > 8 for s in secs), "over 11s", sum(s > 11 for s in secs),
          "at/over 15s", sum(s >= 15 for s in secs))
    print("  kept_sent", sum(r["sentences"]["kept_sent"] for r in rs), "non-model leads", len(code), code)
    print("  over 11s:", [(r["key"], r["seconds"]) for r in rs if r["seconds"] > 11])
    print("  events:", {r["key"]: r["events"] for r in rs if r.get("events")})
