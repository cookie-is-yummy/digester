"""Figures of a saved run folder, read from the records and summary.json (no model call)."""
import glob
import json
import os
import sys

run = sys.argv[1]
files = [f for f in glob.glob(os.path.join(run, "*.json")) if not os.path.basename(f).startswith("summary")]
files.sort(key=lambda f: (os.path.basename(f).split(".")[0], int(os.path.basename(f).split(".")[1])))
recs = [json.load(open(f, encoding="utf-8")) for f in files]
s = json.load(open(os.path.join(run, "summary.json"), encoding="utf-8"))
out = []
p = out.append


def pct(xs, q):
    xs = sorted(xs)
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)


p(f"records: {len(recs)}; summary messages: {s['messages']}; skipped: {s['skipped']}; check: {s['check']}")
p(f"checks in records: {sorted({r.get('check') for r in recs})}; prompt: {s['settings'].get('prompt_version')}")
p(f"lead_source: {s['lead_source']}")
g4 = s["G4_sentences"]
p(f"sentences: written {g4['written']}, kept first pass {g4['kept_first_pass']}, kept sent {g4['kept_sent']}, "
  f"missing first pass {g4['missing_first_pass']}, missing after repair {g4['missing_after_repair']}")
p(f"repairs: {s['repairs']}; decomposition: " + json.dumps(s["decomposition"]))
g2 = s["G2_understood"]
p(f"G2: understood {g2['understood']}, other_plan {g2['other_plan']}, differs {g2['differs']}, "
  f"no_hand_plan {g2['no_hand_plan']}; share_strict_v1 {g2['share_strict_v1']} "
  f"(understood_strict_v1 {g2['understood_strict_v1']}); share (accepted readings) {g2['share']}; "
  f"share_gate_fields {g2['share_gate_fields']}")
p(f"  by_reading: {g2['by_reading']}; later_rounds_missed: {g2['later_rounds_missed']}")
p(f"  other_plan_list: {g2['other_plan_list']}")
p(f"  differs_list keys: {sorted(g2['differs_list'])}")
p(f"  reading_window_failed: {g2['reading_window_failed']}; reading_errors: {g2['reading_errors']}")
g5 = s["G5_seconds"]
secs = [r["seconds"] for r in recs]
p(f"seconds (parallel {s['settings'].get('parallel')}): median {g5['median']}, p90 {g5['p90']}, max {g5['max']}, "
  f"retries {g5['retries']}")
nreq = [r["n_requests"] for r in recs]
p(f"requests per message: mean {s['requests']['per_message_mean']}, median {pct(nreq, 0.5)}, max {max(nreq)}; "
  f"distribution {dict(sorted({n: nreq.count(n) for n in set(nreq)}.items()))}")
p(f"stop reasons: {s['requests']['stop_reasons']}")
p(f"tokens: in {s['requests']['input_tokens']}, out {s['requests']['output_tokens']}, cache read "
  f"{s['requests']['cache_read_input_tokens']}, cache write {s['requests']['cache_creation_input_tokens']}")
g6 = s["G6_cost"]
costs = [r["cost_usd"] for r in recs]
p(f"cost: total ${g6['total_usd']}, mean {g6['mean_cents']} cents per message, median "
  f"{pct([100 * c for c in costs], 0.5)} cents, max {round(100 * max(costs), 4)} cents")
p(f"ledger: {s.get('ledger')}")
p(f"events: {s['events']}")
p(f"dropped_reasons: {s['dropped_reasons']}")
p(f"auditor hints: {s['auditor_hints']['messages_with_hints']} messages, {s['auditor_hints']['hints']} hints")
p("")
p("turn errors (record 'error'): " + json.dumps({r["key"]: r["error"] for r in recs if r.get("error")}))
p("form errors in verdicts: " + json.dumps({r["key"]: [v.get("form_error") for v in r.get("verdicts") or []
                                                      if v.get("form_error")] for r in recs
                                           if any(v.get("form_error") for v in r.get("verdicts") or [])}))
p("tool errors (every read call whose result is_error):")
nerr = ncalls = 0
for r in recs:
    for c in r["calls"]:
        ncalls += 1
        res = c.get("result") or {}
        if res.get("is_error"):
            nerr += 1
            p(f"  {r['key']} round {c['round']} {c['name']} args={json.dumps(c['args'], ensure_ascii=False)}")
            p(f"     error: {json.dumps({k: v for k, v in res.items() if k != 'is_error'}, ensure_ascii=False)}")
p(f"  {nerr} of {ncalls} read calls")
tools = {}
for r in recs:
    for c in r["calls"]:
        tools[c["name"]] = tools.get(c["name"], 0) + 1
p(f"read calls by tool: {tools}")
p("")
p("per message: key | lead_source | seconds | requests | cents | written/first/sent | repair | g2 | hints | events")
for r in recs:
    se = r["sentences"]
    p(f"  {r['key']} | {r['lead_source']} | {r['seconds']} | {r['n_requests']} | {round(100 * r['cost_usd'], 3)} | "
      f"{se['written']}/{se['kept_first_pass']}/{se['kept_sent']} | {'yes' if r.get('repair_message') else 'no'} | "
      f"{r['g2']['verdict']} | {len(r['audit']['findings'])} | {','.join(r.get('events') or [])}")
p("")
p("dropped sentences (every one, as the records hold them):")
for r in recs:
    for d in r["dropped"]:
        p(f"  {r['key']}: {json.dumps(d, ensure_ascii=False)}")
p("")
p("auditor hints (the eval's own hints, not a truth count):")
for k, v in s["auditor_hints"]["by_message"].items():
    for h in v:
        p(f"  {k}: {json.dumps(h, ensure_ascii=False)}")
p("")
p("G2 differs (the scorer's diffs):")
for k, v in g2["differs_list"].items():
    p(f"  {k}: {json.dumps(v, ensure_ascii=False)}")
p("")
code = [r for r in recs if r["lead_source"] not in ("model", "model_after_repair")]
p(f"answers whose lead is not the model's ({len(code)}), in full:")
for r in code:
    a = r.get("answer") or {}
    p(f"==== {r['key']} | lead_source {r['lead_source']} | error {r.get('error')} | events {r.get('events')}")
    p(f"message: {r['message']}")
    p(f"sentences record: {r['sentences']}; points in answer: {len(a.get('points') or [])}; "
      f"model lead (first form): {json.dumps(((r.get('forms') or [{}])[0] or {}).get('lead'), ensure_ascii=False)}")
    p(f"code_lead: {json.dumps(r.get('code_lead'), ensure_ascii=False)}")
    for i, v in enumerate(r.get("verdicts") or []):
        p(f"verdict {i}: lead_ok {v.get('lead_ok')} form_error {v.get('form_error')} outcomes "
          + json.dumps([{k: o.get(k) for k in ('where', 'kept', 'reasons', 'text')} for o in v.get('outcomes', [])],
                       ensure_ascii=False))
    if r.get("repair_message"):
        p(f"repair message: {r['repair_message']}")
    p("sent:")
    for line in (a.get("text") or "(nothing)").split("\n"):
        p("  | " + line)
    p("")
p("the first 10 answers by id order (message, then the answer as sent):")
for r in recs[:10]:
    a = r.get("answer") or {}
    p(f"==== {r['key']} | lead {r['lead_source']}")
    p(f"message: {r['message']}")
    p("sent:")
    for line in (a.get("text") or "(nothing)").split("\n"):
        p("  | " + line)
    p("")
print("\n".join(out))
