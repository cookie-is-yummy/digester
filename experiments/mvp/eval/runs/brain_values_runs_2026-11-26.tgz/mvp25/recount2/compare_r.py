"""compare.txt: mvp24 recounta (last round) against mvp25 recount2 (this round), message by message.
Run after tally_r.py: PYTHONDONTWRITEBYTECODE=1 python3 compare_r.py"""
import json
from collections import Counter

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
oA = {a["key"]: a for a in json.load(open(S + "mvp24/recounta/answers.json"))}
nA = {a["key"]: a for a in json.load(open(S + "mvp25/recount2/answers.json"))}
oR = json.load(open(S + "mvp24/recounta/sentences.json"))
nR = json.load(open(S + "mvp25/recount2/sentences.json"))
BAD = ("false", "wrongly_based")
G = {"poor": 0, "acceptable": 1, "good": 2}
assert sorted(oA) == sorted(nA), "the two rounds must hold the same keys"
out = []
p = out.append

WHY = {  # last round's poor answers: why each moved or stayed (hand reading of this round's sent answer)
    "N004.0": "stayed poor, new cause: the tool now reads 'the summer' and turns 'the last few weeks' into the 4 weeks to 30 October, but the model call timed out (ClaudeTimeout) and code's bare two-total lead went out",
    "N005.0": "stayed poor, new cause: the model wrote the right answer (Pan Theory, the one channel in every year) but all four sentences were dropped as two_results with no time for a repair; code's 'Brick Realm led' went out",
    "N008.0": "now acceptable: the model's month lead was kept (254, October 142) with four more months; last round code's bare total went out",
    "N008.1": "stayed poor: time ran out again before October was read; this round it says so instead of the wrong 'started in it'",
    "N010.0": "now acceptable: 'last summer' is read as 2025 (45 against 16, watercolor 14 to 13); the Digital drawing point was dropped (outside_in_history), so it reads flat",
    "N010.1": "now acceptable: art 45 against 14 with Digital drawing 32 from Pixel Pencil",
    "N014.0": "now acceptable: the model's lead (last cooking video, 30 October) was kept; last round it was dropped and code's all-time total went out",
    "N027.0": "stayed poor, new cause: the model now wrote the day/night answer (evening 69%, afternoon 30%, night 1), all true, but every sentence was dropped in both forms; code's bare 723 went out",
    "N038.0": "now acceptable: the model's lead says the export holds no likes and gives the newest saves; kept",
    "N041.1": "now acceptable: the model names the three Instagram saves in its points (no cards)",
    "N044.0": "stayed poor, fault replaced: 'some of the most opened' (rank over a tie) is gone; 'Here are 5' now goes out over 4 cards",
    "N044.1": "now acceptable: the five cards now render",
    "N048.0": "now acceptable: 'saved on 5 October' (last round 'opened'); the card renders",
    "N048.1": "stayed poor, same cause: the true lead was dropped twice (uncited_number), code's 'Here's what I found.' went out over two cards",
    "N049.0": "stayed poor, new cause: the model's lead now goes out (first date, an ask-back), but its point lists 2 of the 20 other dates as if complete",
    "N052.1": "stayed poor, new cause: the model's forms read past the private line again and were dropped; code's bare totals went out (no fault sent)",
    "N053.0": "stayed poor, same cause: the true 'February to August' point was dropped (other_period); this round the drop also leaves 'lightest month' wrongly based",
    "N053.1": "now good: the named topic resolves in compare (50 against 0, first opened 1 February 2024); last round's false absence is gone",
    "N055.0": "stayed poor, same cause: never gives the count of the friend's save",
    "N056.0": "stayed poor, same cause: the true lead (opens only, not how far) was dropped twice (uncited_claim); code's count of long videos went out",
    "N057.0": "now acceptable: code's limits line says minutes are not in the export; the counts are kept",
    "N063.0": "now acceptable: 'late October' is read (21 to 30 October); points are areas, so no rank across levels",
    "N067.0": "stayed poor, same cause: never says November has no rows; the cut-off point is gone",
    "N109.0": "stayed poor, same cause: mostly what it cannot do, no count",
    "N112.0": "now acceptable: says all 4 Instagram opens fell in the morning",
}
WORSE = {
    "N001.1": "good to poor: the true point naming Pan Theory as the one channel (28 more, all Pan Theory) was dropped (outside_in_history, calc), so 'why' is not answered",
    "N019.0": "good to poor: the repaired lead says the two new channels as a complete list; @wetpaper.ig was also first opened in the fall (the result marked it new_in_window; its new.channels list needs 5 items)",
    "N033.1": "good to poor: the true lead (all 70 in October 2026) was dropped twice (other_period) and the plain 'couldn't check in time' went out",
    "N035.0": "acceptable to poor: the true lead (722 YouTube, 7 Instagram) was dropped twice (number) and code's bare 729 went out",
    "N069.0": "acceptable to poor: 'Its title is cut off in your history' went out (last round the same framing was written and dropped)",
    "N113.0": "acceptable to poor: answers with saves and no longer says the export holds no likes",
}
FAULT13 = {
    ("N005.0", "lead", 0): "gone as a primary fault. Code's 'Brick Realm led, ahead of Pixel Pencil and Wet Paper' replaced it: true as a rank, strict-only wrongly based as the answer to 'every year'",
    ("N008.1", "point", 0): "gone: no channels are named (time ran out; the point is system talk)",
    ("N044.0", "lead", 0): "gone, replaced: no rank word now; the new fault is 'Here are 5' over 4 cards",
    ("N048.0", "lead", 0): "gone: 'saved on 5 October 2026' (the tool's item now carries how=saved and a note to say the verb)",
    ("N048.1", "point", 1): "gone: the model's kept point says 'saved'; code's lead went out and the cards say 'saved'",
    ("N052.1", "lead", 0): "gone from what was sent; the model wrote the same kind again ('most of the gap is in 2023 and 2024'), the checker dropped it, and code's bare totals went out",
    ("N052.1", "point", 0): "gone from what was sent; the same kind (private-out months of 2024 against October 2026) was written twice and dropped",
    ("N053.1", "lead", 0): "gone: the topic resolves; 50 against 0",
    ("N053.1", "point", 0): "gone: no private-out totals compared",
    ("N056.0", "lead", 0): "gone: code's lead went out; the cards carry no rank word",
    ("N056.0", "point", 1): "gone: as above",
    ("N063.0", "point", 1): "gone: the points are areas of one list",
    ("N067.0", "point", 1): "gone: the points are areas of one list; nothing is cut off",
}

p("mvp24 recounta (last round) against mvp25 recount2 (this round): fresh half A, 65 messages, the same keys in both, cells-only checker, prompt v3.")
p("IN SAMPLE: this is the set the fixes of this round were made on, so every gain below is in sample. Each round is one live run;")
p("one message moving either way is not proof of a fix. Answer marks are one reader's, by the same rubric and the same tiers (j_r.py docstring).")
p("")
p("== Headline ==")
oS = [r for r in oR if r["sent"] and r["sent_truth"] != "no_claim"]
nS = [r for r in nR if r["sent"] and r["sent_truth"] != "no_claim"]
oF = [r for r in oR if r["form"] == "first" and r["truth"] != "no_claim"]
nF = [r for r in nR if r["form"] == "first" and r["truth"] != "no_claim"]


def cnt(R, f, kind):
    return sum(r[f] == kind for r in R) if kind != "bad" else sum(r[f] in BAD for r in R)


rows_ = [
    ("false written / sent (primary)", f"{cnt(oF, 'truth', 'false')} of {len(oF)} / {cnt(oS, 'sent_truth', 'false')}", f"{cnt(nF, 'truth', 'false')} of {len(nF)} / {cnt(nS, 'sent_truth', 'false')}"),
    ("wrongly based sent: firm / primary / strict", f"{cnt(oS, 'sent_truth_lenient', 'bad')} / {cnt(oS, 'sent_truth', 'bad')} / {cnt(oS, 'sent_truth_strict', 'bad')} of {len(oS)}",
     f"{cnt(nS, 'sent_truth_lenient', 'bad')} / {cnt(nS, 'sent_truth', 'bad')} / {cnt(nS, 'sent_truth_strict', 'bad')} of {len(nS)}"),
    ("answers with one: firm / primary / strict", "/".join(str(len({r['key'] for r in oS if r[f] in BAD})) for f in ("sent_truth_lenient", "sent_truth", "sent_truth_strict")),
     "/".join(str(len({r['key'] for r in nS if r[f] in BAD})) for f in ("sent_truth_lenient", "sent_truth", "sent_truth_strict"))),
    ("first-form wrongly based (primary)", f"{cnt(oF, 'truth', 'bad')} of {len(oF)}", f"{cnt(nF, 'truth', 'bad')} of {len(nF)}"),
    ("true first-form sentences the checker dropped", f"{sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in oR if r['form'] == 'first')} of {sum(r['truth'] == 'true' for r in oR if r['form'] == 'first')}",
     f"{sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in nR if r['form'] == 'first')} of {sum(r['truth'] == 'true' for r in nR if r['form'] == 'first')}"),
    ("true sentences dropped, all forms", str(sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in oR if r['form'] in ('first', 'repair'))),
     str(sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in nR if r['form'] in ('first', 'repair')))),
    ("answers good / acceptable / poor", "/".join(str(Counter(a['grade'] for a in oA.values())[g]) for g in ("good", "acceptable", "poor")),
     "/".join(str(Counter(a['grade'] for a in nA.values())[g]) for g in ("good", "acceptable", "poor"))),
    ("  strict", "/".join(str(Counter(a['grade_strict'] for a in oA.values())[g]) for g in ("good", "acceptable", "poor")),
     "/".join(str(Counter(a['grade_strict'] for a in nA.values())[g]) for g in ("good", "acceptable", "poor"))),
    ("  lenient", "/".join(str(Counter(a['grade_lenient'] for a in oA.values())[g]) for g in ("good", "acceptable", "poor")),
     "/".join(str(Counter(a['grade_lenient'] for a in nA.values())[g]) for g in ("good", "acceptable", "poor"))),
    ("poor before any truth count", str(sum(a['base_grade'] == 'poor' for a in oA.values())), str(sum(a['base_grade'] == 'poor' for a in nA.values()))),
    ("answers the question", str(sum(a['answers_question'] for a in oA.values())), str(sum(a['answers_question'] for a in nA.values()))),
    ("says what the numbers mean", str(sum(a['says_what_numbers_mean'] for a in oA.values())), str(sum(a['says_what_numbers_mean'] for a in nA.values()))),
    ("worthwhile offer", str(sum(a['carries_offer'] for a in oA.values())), str(sum(a['carries_offer'] for a in nA.values()))),
    ("brief", str(sum(a['brief'] for a in oA.values())), str(sum(a['brief'] for a in nA.values()))),
    ("code's lead or a plain line sent", str(sum(a['lead_source'] == 'code' for a in oA.values())), str(sum(a['lead_source'] in ('code', 'plain') for a in nA.values()))),
]
p(f"  {'':48s} {'last round':>22s}   {'this round':>22s}")
for a, b, c in rows_:
    p(f"  {a:48s} {b:>22s}   {c:>22s}")
p("  poor causes, last round: " + str(dict(Counter(a['poor_cause'] for a in oA.values() if a['grade'] == 'poor'))))
p("  poor causes, this round: " + str(dict(Counter(a['poor_cause'] for a in nA.values() if a['grade'] == 'poor'))))
p("")
p("== Message by message (last -> this; base grade before truth in brackets) ==")
for k in sorted(oA):
    o, n = oA[k], nA[k]
    mv = "same" if o["grade"] == n["grade"] else ("BETTER" if G[n["grade"]] > G[o["grade"]] else "WORSE")
    p(f"  {k:7s} {o['grade']:10s} -> {n['grade']:10s} [{n['base_grade']}] {mv:6s} src {o['lead_source'][:5]} -> {n['lead_source'][:5]}"
      + (f" | now poor: {n['poor_cause']}" if n["grade"] == "poor" else ""))
p("")
lp = [k for k in sorted(oA) if oA[k]["grade"] == "poor"]
up = [k for k in lp if nA[k]["grade"] != "poor"]
st = [k for k in lp if nA[k]["grade"] == "poor"]
p(f"== Last round's {len(lp)} poor answers: {len(up)} now acceptable or good, {len(st)} still poor ==")
p("  Now acceptable or good:")
for k in up:
    p(f"    {k} ({nA[k]['grade']}): {WHY[k]}")
p("  Still poor:")
for k in st:
    p(f"    {k}: {WHY[k]}")
wr = [k for k in sorted(oA) if G[nA[k]["grade"]] < G[oA[k]["grade"]]]
p("")
p(f"== Answers that got worse: {len(wr)} ({sum(nA[k]['grade'] == 'poor' for k in wr)} of them to poor) ==")
for k in wr:
    p(f"    {k}: {WORSE[k]}")
bt = [k for k in sorted(oA) if G[nA[k]["grade"]] > G[oA[k]["grade"]] and oA[k]["grade"] != "poor"]
p(f"  Better outside last round's poor list: {', '.join(bt)} (acceptable to good: N005.1 reads the 2026 return as Gaming clips; N064.0 reads 'mid 2023' as May to August)")
p("")
f13 = [r for r in oR if r["sent"] and r["sent_truth"] in BAD]
p(f"== Last round's {len(f13)} primary sent faults: gone, still there, or replaced ==")
for r in f13:
    p(f"  {r['key']} {r['where']} {r['index']}: \"{r['text_plain']}\"")
    p(f"     -> {FAULT13[(r['key'], r['where'], r['index'])]}")
p(f"  Summary: 13 of 13 gone from what was sent. Replaced in kind on the same message: N044.0 (another list fault) and, at the strict reading only, N005.0 (code's lead).")
p("  The same kind was written again and dropped by the checker: N052.1 (reads past the private line), twice.")
p("")
p("== This round's primary sent faults, and whether last round had them ==")
for r in [x for x in nR if x["sent"] and x["sent_truth"] in BAD]:
    o_same = [x for x in oR if x["key"] == r["key"] and x["truth"] in BAD]
    p(f"  {r['key']} {r['where']} {r['index']}: \"{r['text_plain']}\" ({r['sent_origin_class']})"
      + (f"; last round the model wrote {len(o_same)} fault(s) on this message, sent: {sum(x['sent'] for x in o_same)}" if o_same else "; new on this message"))
p("")
p("== Caveats ==")
for t in [
    "In sample: the fixes were made on these 65 messages. The held-out half B was not opened.",
    "One live run per round. Of the 6 answers that got worse, 3 turn on the model's wording this run (N019.0, N069.0, N113.0) and 3 on this round's checker dropping a true sentence (N001.1, N033.1, N035.0); the checker changed this round, so those 3 may be its cost, not run noise.",
    "Tiers are last round's for every recurring kind; four new kinds were filed this round (N044.0 count over cards, N019.0 complete list, N049.0 complete list, N053.0 neighbour drop). Section 7 of numbers.txt gives each other reading.",
    "Marks are one reader's. Where a sent answer is materially the same as last round's, last round's marks were held (numbers.txt section 7); 'says what the numbers mean' still fell, mostly where a true reading sentence was dropped or not written (N001.0, N001.1, N018.0, N033.1, N035.0, N066.1).",
    "The checker now drops more true sentences (see the headline): two answers that were good last round (N001.1, N033.1) and one that was acceptable (N035.0) are now poor because of drops.",
]:
    p("  - " + t)
p("")
p("== Three next changes this round's counts point to (drops per reason code are in numbers.txt section 2; catches counted against this recount) ==")
for t_ in [
    "Drop codes on true sentences, all forms, last round -> this round: two_results 1 -> 8, outside_in_history 4 -> 8, uncited_number 4 -> 13, other_period 0 -> 4, number 1 -> 3, percent 0 -> 2, wrong_measure 0 -> 2, bad_marker 0 -> 3; down: uncited_name 10 -> 1, unnamed_owner 5 -> 1, link 4 -> 0, wrong_name 4 -> 1 (the cellsfix loosenings). Catches are counted against this recount only; the attacker set's catch per code is in mvp25/cellsfix_progress.md where measured.",
    "1. Checker, two_results and outside_in_history: narrow to the true shapes seen. Cost here: 16 true sentences dropped; catch here: no primary fault, 2 strict-only ones (N049.0 'the closest match', N054.0's private-row count, which the convention passes). Catch on the attacker set: not in this round's notes, so measure it before changing. True shapes: a name from one result with counts from another result filtered to that same name (N005.0 four times, N005.1 three, N054.0 two); 'on YouTube', a first-opened date, 'all from <channel>', 'the top match is' (N001.1, N010.0, N010.1, N016.0, N048.0, N049.0). Would fix N005.0 (the model's right answer, Pan Theory in every year, went to code's 'Brick Realm led') and N001.1 (the 'why': all 28 more from Pan Theory), and save the repair rounds behind N005.1, N010.1, N016.0, N048.0, N049.0, N054.0, which bears on the 8 s / 11 s bars.",
    "2. Code: the limits line on every answer whose plan took a substitute after a tool error, and on 'how far / all the way through'. N004.0 got 'Your export ends on 30 October 2026, so 2 to 22 November 2026 is not in it' and N057.0 got the minutes line; N067.0 hit the same window error and got nothing, N113.0 hit the no-likes error and got nothing, and N056.0's true 'opens, not how far' lead was dropped twice (uncited_claim) with no line in its place. Code words the line, so the founder's rule holds and no checker rule is added. Would fix N067.0, N113.0 and N056.0 (all poor now); N109.0 and N055.0 could take the same kind of line for the friend's save count.",
    "3. Checker, other_period and the insight codes number, percent, wrong_measure, count_of_videos: narrow, keeping the catches. other_period carries this round's new period_bind and period_named rules (cellsfix step 3a: caught attack2 f08 f16 f21 f22 m02 n05 p04 p05 p07 and 23 planted cases, 0 true lost on the replay sets). In this live run it dropped 4 true sentences and caught 1 fault that other codes on the same sentence also caught (N052.1). The true shapes: a total over all history said with the one month that holds all of it (N033.1, twice, then the plain line went out) and a run named by its two end periods, both cited (N053.0 'February to August', whose drop also left 'lightest month' wrongly based; N010.1). The insight codes dropped 7 true sentences here and caught none: 'opens' and 'videos' are one count while every video is opened once (N027.0, every form), and a platform split (N035.0, twice). Would fix N033.1, N053.0, N027.0 and N035.0; re-run attack2 and the planted set to show the catches stay.",
    "Smaller: a check that a count said over cards equals the cards chosen (N044.0); the tool's new.channels list could carry channels first opened in the window under the 5-item rule, marked as such (N019.0); the search could say how many rows share an exact title (N049.0); the tool could say it shortens long titles (N069.0: the model wrote the same wrong framing in both rounds).",
]:
    p("  " + t_)
open(S + "mvp25/recount2/compare.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out[:30]))
