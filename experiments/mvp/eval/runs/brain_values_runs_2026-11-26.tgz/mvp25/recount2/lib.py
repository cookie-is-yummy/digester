"""Independent recount over the made-up rows of experiments/mvp/tests/brain_library.py ONLY.

Reads rows() and nothing else of the product (no facts.py, no eval_claims, no tool results).
Ground truth from the rows: theme = the row's theme key, area = the key's field, channel = YouTube channel or
'@' + Instagram handle, opened = a 'watch' event, dates in America/New_York, long = known length > 60 s.
"""
import sys
from collections import Counter
from datetime import date, datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/merge_tree/experiments")
from mvp.tests import brain_library as B  # noqa: E402

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships"}
SENSITIVE = {"da"}

EVENTS = []   # one dict per (row, event)
for r in B.rows():
    for kind, at in r["events"]:
        d = datetime.fromisoformat(at).astimezone(NY)
        EVENTS.append({
            "id": r["id"], "kind": kind, "day": d.date(), "hour": d.hour, "dt": d, "platform": r["platform"],
            "channel": r["channel"] if r["platform"] == "youtube" else "@" + r["handle"],
            "theme_key": r["theme"], "theme": THEME[r["theme"]], "area": AREA[r["theme"]],
            "length": r["length"], "friend": bool(r.get("friend")), "title": r["caption"],
        })

D = date
W = {
    "all": (D(2021, 1, 5), D(2026, 10, 30)),
    "lately": (D(2026, 10, 3), D(2026, 10, 30)),
    "prev4": (D(2026, 9, 5), D(2026, 10, 2)),
    "oct": (D(2026, 10, 1), D(2026, 10, 30)),
    "sep": (D(2026, 9, 1), D(2026, 9, 30)),
    "last7": (D(2026, 10, 24), D(2026, 10, 30)),
    "ytd": (D(2026, 1, 1), D(2026, 10, 30)),
    "2021": (D(2021, 1, 1), D(2021, 12, 31)),
    "2022": (D(2022, 1, 1), D(2022, 12, 31)),
    "2023": (D(2023, 1, 1), D(2023, 12, 31)),
    "2024": (D(2024, 1, 1), D(2024, 12, 31)),
    "2025": (D(2025, 1, 1), D(2025, 12, 31)),
    "2019": (D(2019, 1, 1), D(2019, 12, 31)),
    "oct30": (D(2026, 10, 30), D(2026, 10, 30)),
}


def ev(win="all", kind="watch", only=None, exclude=None, length="any", platform=None, weekday=None,
       unlock=False):
    """Events in a window. only/exclude: list of (field, value) with field in area/theme/channel.
    length: any | long (known length > 60 s) | short. weekday: Python weekday (6 = Sunday)."""
    a, b = W[win] if isinstance(win, str) else win
    out = []
    for e in EVENTS:
        if e["friend"] or (kind and e["kind"] != kind):
            continue
        if e["theme_key"] in SENSITIVE and not unlock:
            continue
        if not (a <= e["day"] <= b):
            continue
        if only and not any(e[f] == v for f, v in only):
            continue
        if exclude and any(e[f] == v for f, v in exclude):
            continue
        if length == "long" and not (e["length"] and e["length"] > 60):
            continue
        if length == "short" and not ((e["length"] and e["length"] <= 60) or e["platform"] == "instagram"):
            continue
        if platform and e["platform"] != platform:
            continue
        if weekday is not None and e["day"].weekday() != weekday:
            continue
        out.append(e)
    return out


def by(evs, field):
    return Counter(e[field] for e in evs).most_common()


def pct(n, d):
    return round(100.0 * n / d, 1) if d else None


# --- added for mvp22/raw: a YouTube Short is a YouTube row of known length 60 s or less (Instagram apart)
def ev2(win="all", shorts=None, **k):
    """ev() plus shorts: 'yt_short' (YouTube, known length <= 60 s), 'yt_long' (YouTube, known > 60 s),
    'yt' (any YouTube), 'ig' (Instagram)."""
    out = ev(win, **k)
    if shorts == "yt_short":
        out = [e for e in out if e["platform"] == "youtube" and e["length"] and e["length"] <= 60]
    elif shorts == "yt_long":
        out = [e for e in out if e["platform"] == "youtube" and e["length"] and e["length"] > 60]
    elif shorts == "yt":
        out = [e for e in out if e["platform"] == "youtube"]
    elif shorts == "ig":
        out = [e for e in out if e["platform"] == "instagram"]
    return out
