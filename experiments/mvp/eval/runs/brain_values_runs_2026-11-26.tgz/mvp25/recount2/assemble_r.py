"""Join every lead and point of every form of run1, and every code lead, with the verifier's outcome and the hand
judgment of j_a.py; mark what was sent; write sentences.json. Run: PYTHONDONTWRITEBYTECODE=1 python3 assemble_a.py"""
import glob
import json
import re

from j_r import J, SENT

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/"
RUN = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/runa2/run1/"
BAD = ("false", "wrongly_based")


def strict(t, b):
    return "wrongly_based" if t in ("true", "cannot_prove") and (b or "").startswith("strict") else t


def lenient(t, b):
    return "true" if t in BAD and (b or "").startswith("lenient") else t


def row(rec, form, fi, where, idx, text, o, jd, hid, sent, kept_not_sent):
    t, b = jd.get("truth"), jd.get("borderline")
    out = {"key": rec["key"], "form": form, "form_index": fi, "where": where, "index": idx,
           "text": text, "text_plain": (o.get("sent") if o else None) or re.sub(r"\[[^\[\]]*(?:\[[^\]]*\][^\[\]]*)*\]", "", text or "").strip(),
           "truth": t, "truth_strict": strict(t, b), "truth_lenient": lenient(t, b),
           "fault_class": jd.get("fault_class"), "fault": jd.get("fault"), "borderline": b, "note": jd.get("note"),
           "recount": jd.get("recount"), "recounted_by_rows": jd.get("by_rows"),
           "verifier_kept": o["kept"] if o else None, "verifier_reasons": o["reasons"] if o else [],
           "verifier_details": o["details"] if o else [],
           "private_base": any(hid.get(x, 0) > 0 for x in set(re.findall(r"\b(r\d+)\.", text or ""))),
           "sent": sent, "kept_not_sent_under_code_lead": kept_not_sent,
           "answer_private_line": rec["answer"].get("private_line")}
    if sent:
        ov = SENT.get((rec["key"], where, idx)) if form not in ("code", "plain") else None
        sj = dict(jd, **ov) if ov else jd
        out.update(sent_truth=sj.get("truth"), sent_truth_strict=strict(sj.get("truth"), sj.get("borderline")),
                   sent_truth_lenient=lenient(sj.get("truth"), sj.get("borderline")), sent_fault=sj.get("fault"),
                   sent_fault_class=sj.get("fault_class"), sent_borderline=sj.get("borderline"),
                   sent_origin=(ov or {}).get("origin") or ("code lead" if form in ("code", "plain") else "as the model wrote it"))
        out["sent_origin_class"] = out["sent_origin"].split(":")[0]
    return out


rows, missing = [], []
for p in sorted(glob.glob(RUN + "N*.json")):
    rec = json.load(open(p))
    hid = {c["rid"]: ((c.get("result") or {}).get("meta", {}).get("hidden") or {}).get("sensitive") or 0
           for c in rec["calls"] if c.get("rid")}
    code = rec["lead_source"] in ("code", "plain")
    last = len(rec["forms"]) - 1
    for fi, f in enumerate(rec["forms"]):
        v = rec["verdicts"][fi]
        sl = ([("lead", 0, f["lead"])] if f.get("lead") else []) + [("point", i, t) for i, t in enumerate(f.get("points") or [])]
        for where, idx, text in sl:
            os_ = [x for x in v["outcomes"] if x["where"] == where and (x["index"] == idx or where == "lead")]
            o = None
            if os_:
                o = dict(os_[0], kept=all(x["kept"] for x in os_), sent=" ".join(x.get("sent") or "" for x in os_).strip() or None,
                         reasons=[r for x in os_ for r in x["reasons"]], details=[d for x in os_ for d in x["details"]])
            jd = J.get((rec["key"], fi, where, idx))
            if jd is None:
                missing.append((rec["key"], fi, where, idx))
                jd = {}
            sent = (not code) and fi == last and bool(o and o["kept"])
            kns = code and fi == last and bool(o and o["kept"])
            rows.append(row(rec, "first" if fi == 0 else "repair", fi, where, idx, text, o, jd, hid, sent, kns))
    if code:
        cl = rec["code_lead"]
        jd = J.get((rec["key"], "code", "lead", 0))
        if jd is None:
            missing.append((rec["key"], "code", "lead", 0))
            jd = {}
        rows.append(row(rec, "code" if rec["lead_source"] == "code" else "plain", None, "lead", 0, cl.get("marked") or cl["lead"], {"sent": cl["lead"], "kept": True, "reasons": [], "details": []},
                        jd, hid, True, False))
    # check: sent rows equal the answer as sent
    sent_txt = [r["text_plain"] for r in rows if r["key"] == rec["key"] and r["sent"]]
    want = [rec["answer"]["lead"]] + rec["answer"]["points"]
    assert sent_txt == want, (rec["key"], sent_txt, want)
assert not missing, missing
strip = lambda t: re.sub(r"\[[^\[\]]*(?:\[[^\]]*\][^\[\]]*)*\]", "", t or "").strip()  # noqa: E731
first_txt = {(r["key"], strip(r["text"])) for r in rows if r["form"] == "first"}
for r in rows:
    r["repeat_of_first"] = r["form"] == "repair" and (r["key"], strip(r["text"])) in first_txt
print("rows", len(rows), "first", sum(r["form"] == "first" for r in rows), "repair", sum(r["form"] == "repair" for r in rows),
      "code", sum(r["form"] in ("code", "plain") for r in rows), "sent", sum(r["sent"] for r in rows), "missing", len(missing), missing[:8])
json.dump(rows, open(S + "recount2/sentences.json", "w"), indent=1, default=str)
