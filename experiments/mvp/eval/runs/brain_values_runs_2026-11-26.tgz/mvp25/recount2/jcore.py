"""Judgment store. j(key, form, where, idx, checks, ...): checks = [(what, said, counted)] made with rc.py.
Cell truth is computed from the checks; framing is a hand override (truth=, fc=, fault=)."""
from rc import match

J = {}


def j(key, form, where, idx, checks=(), truth=None, fc=None, fault=None, note=None, borderline=None, same_as=None):
    rec = [({"what": w[5:], "said": None, "counted": v, "ok": None, "context": True} if w.startswith("ctx: ")
            else {"what": w, "said": sd, "counted": v, "ok": bool(match(sd, v))}) for w, sd, v in checks]
    bad = [x for x in rec if x["ok"] is False]
    if truth is None:
        if bad:
            truth, fc = "false", fc or "cell"
            fault = fault or "; ".join(f"{x['what']}: said {x['said']}, counted {x['counted']}" for x in bad)
        else:
            truth = "true"
    J[(key, form, where, idx)] = dict(truth=truth, fault_class=fc, fault=fault, recount=rec, note=note,
                                      borderline=borderline, by_rows=any(not x.get("context") for x in rec))


def same(key, form, where, idx, src_form=0, src_where=None, src_idx=None):
    """repair sentence identical in meaning to a first-form one: copy its judgment."""
    s = J[(key, src_form, src_where or where, idx if src_idx is None else src_idx)]
    J[(key, form, where, idx)] = dict(s, note=(s.get("note") or "") + " [same claim as form %d]" % src_form)
