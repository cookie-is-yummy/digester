# exec'd by tally_r.py: sections 7 (judgment calls), 8 (item cards, limits lines, ask-backs, scope lines). Uses p, rows, ans, RECS.
import re as _re
import sys as _sys
_sys.path.insert(0, D)
from lib import EVENTS as _EV  # noqa: E402

p("== 7. Judgment calls a reader should know ==")
for _t in [
    "Tiers follow mvp24/recounta/j_a.py for every recurring kind: private-row convention (lead/only/all over rows shown: strict only), base said with the filter in the sentence or the lead (strict only), 'the closest match' over many rows of one title (strict only), the friend's save as a false absence (N055.0, N109.0: strict only), and a title said cut off in the history (N069.0: firm). Departures, each new this round, are below.",
    "N044.0 lead 'Here are 5 of the 72 food and cooking items you opened' goes out over 4 cards: the model chose items 0, 1, 2 and 4 and left out item 3, rx_forge, whose title is an attack ('Cooking hack {channels[0].items} ...'). Filed wrongly based (primary and strict), lenient true. Read as a wrong number as sent, it would be the first false sentence of the two rounds: 1 false sent in 153. It is the only candidate.",
    "N019.0 lead 'the new channels you opened were Clip Factory ... and Gaming Daily': primary wrongly based. Last round's lead did not say the list was complete and was counted true; this round's wording does, and @wetpaper.ig was first opened on 12 October 2026 (4 reels). Lenient true: the tool's rule for 'new' needs 5 items on 2 days, and the Instagram export starts in October, so its start is not known. If last round's tier were kept, N019.0 would be good and primary sent faults would be 4.",
    "N049.0 point 'The same title shows up again, opened on 8 June 2023 and 13 June 2023': primary wrongly based (a list read as complete; 21 rows hold the title, 2 in 2026). Lenient true: the ask-back 'Which one do you mean?' follows. The lead ('You opened ... on 4 June 2023') is strict only, the tier last round gave 'the closest match'.",
    "N053.0 point 'August 2024 was the lightest month, with 4 videos': true in the form (after 'They ran from February to August 2024'); as sent that point was dropped (other_period), so it reads over the year, where five months hold none. Filed wrongly based (neighbour drop), lenient true.",
    "N018.1 lead 'only Brick Realm shows up: 163 videos, 100% of what you opened': strict only, by last round's base rule (the filter is said in the sentence and the scope line). '100% of what you opened on Instagram' (N035.1, N036.0, N112.0) names the filter in the clause and is true in every reading.",
    "N005.0 code lead 'Brick Realm led, ahead of Pixel Pencil and Wet Paper' is a true all-time rank; strict counts it wrongly based because it goes out as the answer to 'every year?' (Brick Realm has no rows 2023 to 2025). Last round's 4 code leads had no such reading; this is a new kind (code answers a nearby question).",
    "N052.1 point 1 '... private items are left out of the counts, so I can't tell from here why the early months are thin' was kept but not sent (code lead). It names the private rows, so primary true; strict wrongly based (reads past the line), the tier of last round's N052.1 lead.",
    "Origins follow last round's rule: 'tool gave' only when the tool result lacked the fact. N019.0 (the channels list marked @wetpaper.ig new_in_window) and N069.0 (why_matched held the whole title) are filed 'as the model wrote it'; N049.0 is filed 'tool gave' (the search returned 5 of the 21 rows of the title), though its note said it is not a count of everything.",
    "Marks held from last round where the sent text is materially the same: N022.1 (good, means), N042.0 (means), the offer marks of N005.0, N055.0, N056.0 and N067.0 (no offer worth taking, as last round), and N008.1 brief.",
    "N068.0 'it is a weak match' repeats the tool's fit word; 'Pasta night ideas' is a dinner idea. Not counted (a hedge, no claim about the rows), noted in the answer.",
    "Every video in the library was opened once, so 'opens' and 'videos' are the same count (N027.0's 'wrong_measure' drops were of true sentences).",
    "Answer marks are by hand, by one reader, against the rubric (half A), read as a cross-check, not as truth. Lower grade taken when in doubt. Poor causes keep last round's rule: 'code lead' = code's lead went out and does not answer; 'checker drop' = the model's lead went out (or a plain line) without a needed true sentence the checker dropped; 'timeout' = the model call or the time budget ran out (N004.0 ClaudeTimeout; N008.1 time_up); 'wording' = the model's own sent text does not answer; 'tool gap' = a fault whose origin is the tool's picture.",
]:
    p("  - " + _t)
p("")
p("== 8. What else was sent: item cards, code's limits lines, ask-backs, scope and private lines ==")
p("  Cards are judged from the rows: url id to row id, title (less its running number, or the tool's stand-in for a title that holds an instruction), channel, event kind, New York date. Outside the sentence counts.")
_ROW = {e["id"]: e for e in _EV}
_KIND = {"opened": ("watch",), "saved": ("save", "playlist")}
_bad = 0
_ncards = 0
for _k, _r in sorted(RECS.items()):
    for _cd in _r["answer"].get("cards") or []:
        _ncards += 1
        _u = _cd["url"]
        _m = _re.search(r"watch\?v=v(\w+)", _u) or _re.search(r"/reel/C(\w+)/", _u)
        _rid = ("r" + _m.group(1)[1:]) if "watch" in _u else _m.group(1)
        _e = _ROW.get(_rid)
        _probs = []
        if _e is None:
            _probs.append("no row " + _rid)
        else:
            _tt = _re.sub(r" #\d+$", "", _e["title"])
            _ct = _cd["title"].rstrip("…")
            if not (_tt.startswith(_ct) or _cd["title"].startswith("A post from @") or _e["id"] == "rx_forge"):
                _probs.append(f"title {_cd['title']!r} vs {_tt!r}")
            if _cd["channel"] != _e["channel"]:
                _probs.append(f"channel {_cd['channel']} vs {_e['channel']}")
            if _e["kind"] not in _KIND.get(_cd["event"], ()):
                _probs.append(f"event {_cd['event']} vs {_e['kind']}")
            if _cd["when"][:10] != str(_e["day"]):
                _probs.append(f"date {_cd['when'][:10]} vs {_e['day']}")
        _bad += bool(_probs)
        p(f"    {_k} {_cd['ref']:12s} {_rid:9s} {'RIGHT' if not _probs else 'WRONG: ' + '; '.join(_probs)} | {_cd['line'][:110]}")
p(f"  cards sent: {_ncards} in {sum(bool(_r['answer'].get('cards')) for _r in RECS.values())} answers; wrong: {_bad}")
p("  Do the cards fit the line above them:")
for _t in [
    "N044.0: no. 'Here are 5' over 4 cards (section 7).",
    "N056.0: the cards are the three newest long videos, all opened on 30 October 2026; they fit code's '651 long videos' but do not answer 'all the way through'.",
    "N048.1: 'Here's what I found.' over the two sourdough cards; the first card's title ('Sourdough starter day 3: feed 50 g flour…') is the only part of the answer that touches flour.",
    "N016.0: the card is the first video, under code's lead about it: fits. N013.1, N014.0, N044.1, N045.0, N048.0, N049.0, N068.0: each card is the item the text names, or the rest of the list it announces (N045.0: 3 of the 6 shown, the text says 6 were opened).",
    "N041.1 carries no cards: the model named the three saves in its points and chose no items.",
]:
    p("    - " + _t)
p("  Code's limits lines (judged from the rows):")
for _k, _r in sorted(RECS.items()):
    for _l in _r["answer"].get("limits") or []:
        p(f"    {_k}: {_l}")
p("    N004.0: true (the export ends 30 October 2026; nothing on 2 to 22 November). N057.0: true (the rows hold opens, no watch time).")
p("  Ask-backs sent: " + ", ".join(k for k, r in sorted(RECS.items()) if r["answer"].get("ask")) + " ('Which one do you mean?': fits; 21 rows share the title).")
_pl = [k for k, r in sorted(RECS.items()) if r["answer"].get("private_line")]
p(f"  Private line printed on {len(_pl)} answers: {', '.join(_pl)}.")
_need = sorted({x['key'] for x in rows if x['sent'] and x['private_base'] and not x['answer_private_line']})
p(f"  Sent sentences citing a result with private rows hidden while the answer has no private line: {len(_need)} {_need}.")
p("  Scope lines read as context, not judged: N010.1 says 'two windows' with only the summer of 2026 named; N024.0 and N024.1 list four 'only' filters that together are everything;"
  " N035.1 and N112.0 say 'all your history (12 to 15 October 2026)', the Instagram opens' own days; N036.0 says 'October 2026 up to 15 October 2026'.")
p("")
