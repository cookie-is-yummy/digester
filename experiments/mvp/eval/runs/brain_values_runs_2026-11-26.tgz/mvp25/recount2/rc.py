"""Recount helpers over lib.py (rows of tests/brain_library.py only)."""
from lib import D, W, by, ev, ev2, pct, EVENTS  # noqa: F401


def n(win="all", **k):
    return len(ev2(win, **k))


def c(win, field, name, **k):
    return dict(by(ev2(win, **k), field)).get(name, 0)


def s(win, field, name, **k):
    """share in % (unrounded)"""
    t = n(win, **k)
    return 100.0 * c(win, field, name, **k) / t if t else None


def rank(win, field, i=0, **k):
    r = by(ev2(win, **k), field)
    return r[i][0] if len(r) > i else None


def ranks(win, field, **k):
    return by(ev2(win, **k), field)


def r(x):
    """round half up"""
    import math
    return int(math.floor(x + 0.5 + 1e-9)) if x is not None else None


def match(said, val):
    if isinstance(said, str) or isinstance(val, str) or isinstance(val, (list, tuple, set, bool)) or val is None:
        return said == val
    if isinstance(said, float) and not float(said).is_integer():
        return abs(said - val) < 0.051
    if isinstance(val, float):
        return said == r(val)
    return said == val


NG = dict(exclude=[("area", "gaming")])
G = dict(only=[("area", "gaming")])
