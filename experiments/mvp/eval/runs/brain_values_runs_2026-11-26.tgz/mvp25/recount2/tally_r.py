"""Rebuild: PYTHONDONTWRITEBYTECODE=1 python3 assemble_r.py && python3 a_r.py && python3 tally_r.py
Writes numbers.txt and sent_faults.txt from sentences.json and answers.json."""
import importlib.util
import json
from collections import Counter

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
D = S + "mvp25/recount2/"
RUN = S + "mvp25/runa2/run1/"
import glob as _g
RECS = {json.load(open(_p))["key"]: json.load(open(_p)) for _p in sorted(_g.glob(RUN + "N*.json"))}
NA = len(RECS)
spec = importlib.util.spec_from_file_location("taxonomy", S + "mvp22/paper/taxonomy.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
rows = json.load(open(D + "sentences.json"))
ans = json.load(open(D + "answers.json"))
BAD = ("false", "wrongly_based")
out = []
p = out.append


def cls(code):
    base = code.split(":")[0]
    if base in T.CELL or base == "name":
        return "cell"
    if base in T.POLICY:
        return "policy"
    if base in T.DOUBT:
        return "doubtful"
    if base in T.FRAMING:
        return "framing"
    return "other"


def pc(a, b):
    return f"{a}/{b} = {100.0 * a / b:.1f}%" if b else f"{a}/0"


def rate_block(R, label):
    claims = [r for r in R if r["truth"] != "no_claim"]
    nc = len(claims)
    tc = Counter(r["truth"] for r in R)
    bp = sum(r["truth"] in BAD for r in claims)
    bs = sum(r["truth_strict"] in BAD for r in claims)
    bl = sum(r["truth_lenient"] in BAD for r in claims)
    p(f"{label}: {len(R)} sentences; {dict(tc)}; with a claim {nc}")
    p(f"  false (wrong number, name, date or calculation): {tc['false']}")
    p(f"  wrongly based: primary {pc(bp - tc['false'], nc)}, strict {pc(bs, nc)}, lenient {pc(bl, nc)}")
    p(f"  cannot prove: {tc['cannot_prove']}; recounted from the rows: {sum(1 for r in R if r['recounted_by_rows'])}, by reading the rows' fields only: {sum(1 for r in R if not r['recounted_by_rows'])}")


p(f"mvp25 recount2: independent hand recount of runa2/run1 (fresh half A, cells-only checker, prompt v3, {NA} messages)")
p("Every sentence recounted from the rows of experiments/mvp/tests/brain_library.py (merge_tree 0bd8720, = the run's code; the library file is byte-identical to mvp24's) through lib.py;")
p("no tool result was used as a source. Judged by hand: framing, answers. Half B not opened. No model call, $0.")
p("Readings: primary = my judgment; strict = also counts the borderline framing cases; lenient = passes them.")
p("Private-row convention applied (DECISIONS 26 Nov 2026): with the line shown, all/only/rank/count over the rows")
p("shown is not counted; a false absence, or a sentence that reads past the line, is.")
p("")
p("== 0. Headline ==")
SN0 = [r for r in rows if r["sent"] and r["sent_truth"] != "no_claim"]
_F1 = [r for r in rows if r["form"] == "first"]
p(f"  False (a wrong number, name, date or calculation), primary: {sum(r['truth'] == 'false' for r in _F1)} written in {len(_F1)} first-form sentences, {sum(r['sent_truth'] == 'false' for r in SN0)} sent in {len(SN0)};"
  f" strict reading: {sum(r['truth_strict'] == 'false' for r in _F1)} written, {sum(r['sent_truth_strict'] == 'false' for r in SN0)} sent (see section 7 on N044.0).")
p(f"  Wrongly based sent: firm {sum(r['sent_truth_lenient'] in BAD for r in SN0)}, primary {sum(r['sent_truth'] in BAD for r in SN0)}, strict {sum(r['sent_truth_strict'] in BAD for r in SN0)} of {len(SN0)} sent sentences with a claim;"
  f" answers with one or more: firm {len({r['key'] for r in SN0 if r['sent_truth_lenient'] in BAD})}, primary {len({r['key'] for r in SN0 if r['sent_truth'] in BAD})}, strict {len({r['key'] for r in SN0 if r['sent_truth_strict'] in BAD})} of {NA}.")
p(f"  Answers: {dict(Counter(a['grade'] for a in ans))} (strict {dict(Counter(a['grade_strict'] for a in ans))}, lenient {dict(Counter(a['grade_lenient'] for a in ans))});"
  f" {sum(a['base_grade'] == 'poor' for a in ans)} are poor before any truth count.")
p("")
p("== 1. The model's raw rate (what it wrote, before the checker) ==")
F1 = [r for r in rows if r["form"] == "first"]
rate_block(F1, "first forms")
RP = [r for r in rows if r["form"] == "repair"]
rate_block(RP, f"repair forms ({len({r['key'] for r in RP})} repairs)")
rate_block([r for r in RP if not r["repeat_of_first"]], "repair forms, new text only")
fc = Counter(r["fault_class"] for r in F1 if r["truth"] in BAD)
KIND = [("'your longest run'", "rank/list: 'longest run' against 'every year'"), ("'the channels that started", "'new'/'started' (a first date)"),
        ("rank over a tie", "rank over a tie"), ("what is counted", "what is counted: saved said as opened"),
        ("reads past the private line", "private: reads past the line"), ("false absence", "private: false absence"),
        ("rank across levels", "rank across levels"), ("the title is not cut off", "a claim about the tool's match"),
        ("'too few", "a habit judgment (cannot prove; strict: window)"), ("wrongly based: 'is from", "save date read as the post's date (strict)"),
        ("wrongly based: friends'", "friends' posts 'not counted' (strict)"), ("wrongly based (reads as a false absence)", "friend's post: reads as a false absence (strict)"),
        ("wrongly based (window)", "a habit judgment (cannot prove; strict: window)"), ("wrongly based: the 4 opens", "a habit judgment (cannot prove; strict: window)"),
        ("'only' or 'all': the new channels", "only/all: a list said as complete (new channels)"), ("'only' or 'all': 'the same title", "only/all: a list said as complete (dates of a title)"),
        ("'Here are 5'", "count of the list against the cards shown"), ("'Its title is cut off", "a claim about the history's text (title cut)"),
        ("window and reads past", "private: reads past the line (window)"), ("reads past the private line", "private: reads past the line"),
        ("wrongly based (reads past the line)", "private: reads past the line (strict)"), ("wrongly based (base)", "base (strict)"),
        ("wrongly based: sent as the answer", "code lead answers a nearby question (strict)"), ("wrongly based: 'the closest match'", "one of many said as the one (strict)"),
        ("wrongly based: one of 21", "one of many said as the one (strict)"), ("wrongly based (reads as a false absence)", "friend's post: reads as a false absence (strict)")]


def kind(r):
    t = r["fault"] or r["borderline"] or ""
    t = t.split("strict: ", 1)[-1]
    for a, b in KIND:
        if t.startswith(a):
            return b
    if "(base)" in t:
        return "base (strict)"
    if "(only/all)" in t:
        return "private: only/all over rows shown (strict; the convention passes it)"
    if "(window)" in t:
        return "window (strict)"
    return t[:40]


for lab, f in (("primary", "truth"), ("strict", "truth_strict"), ("lenient", "truth_lenient")):
    p(f"  first-form faults by kind, {lab}: {dict(Counter(kind(r) for r in F1 if r[f] in BAD))}")
p("")
p("== 2. The checker against the truth (first forms; the sentence as the model wrote it) ==")
cl = [r for r in F1 if r["truth"] not in ("no_claim",)]
X = Counter((r["truth"], r["verifier_kept"]) for r in cl)
p(f"  true kept {X[('true', True)]}, true dropped {X[('true', False)]}; wrongly based kept {X[('wrongly_based', True)]}, dropped {X[('wrongly_based', False)]};"
  f" false kept {X[('false', True)]}, dropped {X[('false', False)]}; cannot prove kept {X[('cannot_prove', True)]}, dropped {X[('cannot_prove', False)]}")
for lab, R in (("first forms", F1), ("all forms (first + repair)", F1 + RP)):
    td = [r for r in R if r["truth"] == "true" and r["verifier_kept"] is False]
    p(f"  true sentences dropped, {lab}: {len(td)}")
    codes = Counter(c for r in td for c in set(r["verifier_reasons"]))
    p("    by reason code (a sentence can carry several): " + ", ".join(f"{k} {v} [{cls(k)}]" for k, v in codes.most_common()))
    cc = Counter(frozenset(cls(c) for c in r["verifier_reasons"]) for r in td)
    p("    by class set: " + ", ".join(f"{'+'.join(sorted(k))} {v}" for k, v in cc.most_common()))
p("  true sentences dropped, listed (all forms):")
for r in F1 + RP:
    if r["truth"] == "true" and r["verifier_kept"] is False:
        p(f"    {r['key']} {r['form']} {r['where']}{r['index']} {r['verifier_reasons']} | {r['text_plain']}")
p("  faults the checker dropped (all forms):")
for r in F1 + RP:
    if (r["truth_strict"] in BAD or r["truth"] == "cannot_prove") and r["verifier_kept"] is False:
        p(f"    {r['key']} {r['form']} {r['where']}{r['index']} {r['truth']} (strict {r['truth_strict']}) {r['verifier_reasons']} | {r['text_plain']}\n       fault: {r['fault'] or r['borderline']}")
for lab, f in (("primary", "truth"), ("strict", "truth_strict"), ("lenient", "truth_lenient")):
    b = [r for r in F1 if r[f] in BAD]
    p(f"  first-form faults, {lab}: {len(b)}, of them dropped by the checker {sum(r['verifier_kept'] is False for r in b)}, kept {sum(r['verifier_kept'] is True for r in b)}")
kn = [r for r in rows if r["kept_not_sent_under_code_lead"]]
p(f"  kept by the checker but not sent because code's lead replaced the model's: {len(kn)} ({', '.join(sorted({r['key'] for r in kn}))}), all true: {all(r['truth'] == 'true' for r in kn)}")
p("")
p("== 3. What was SENT ==")
SN = [r for r in rows if r["sent"]]
p(f"  sentences sent: {len(SN)} (model {sum(r['form'] not in ('code', 'plain') for r in SN)}, code leads and plain lines {sum(r['form'] in ('code', 'plain') for r in SN)}); {dict(Counter(r['sent_truth'] for r in SN))}")
scl = [r for r in SN if r["sent_truth"] != "no_claim"]
for lab, f in (("primary", "sent_truth"), ("strict", "sent_truth_strict"), ("lenient", "sent_truth_lenient")):
    b = [r for r in scl if r[f] in BAD]
    p(f"  false or wrongly based sent, {lab}: {pc(len(b), len(scl))} of sent sentences with a claim (false {sum(r[f] == 'false' for r in b)}, wrongly based {sum(r[f] == 'wrongly_based' for r in b)});"
      f" answers with at least one: {len({r['key'] for r in b})} of {NA}")
for lab, f in (("firm", "sent_truth_lenient"), ("primary", "sent_truth"), ("strict", "sent_truth_strict")):
    p(f"  by origin ({lab}): " + str(dict(Counter(r["sent_origin_class"] for r in scl if r[f] in BAD))))
p("  code leads and plain lines sent, recounted: " + str([(r["key"], r["form"], r["sent_truth"], r["sent_truth_strict"]) for r in SN if r["form"] in ("code", "plain")]))
pb = [r for r in SN if r["private_base"] and not r["answer_private_line"]]
p(f"  sent sentences citing a result with private rows hidden while the answer has no private line: {len(pb)} {[r['key'] for r in pb]}")
pl = [r for r in SN if r["private_base"]]
p(f"  sent sentences citing a result with private rows hidden: {len(pl)}, in {len({r['key'] for r in pl})} answers; true only by the convention: "
  f"{sum(1 for r in pl if (r['note'] or '').startswith('true only by the private-row convention'))}")
p("")
p("== 4. Answers as sent, read by the rubric and the founder's rules ==")
for g in ("base_grade", "grade", "grade_strict", "grade_lenient"):
    p(f"  {g:14s}: {dict(Counter(a[g] for a in ans))}")
p(f"  answers the question: {sum(a['answers_question'] for a in ans)}/{NA}; says what the numbers mean: {sum(a['says_what_numbers_mean'] for a in ans)}/{NA};"
  f" carries an offer worth taking: {sum(a['carries_offer'] for a in ans)}/{NA}; brief: {sum(a['brief'] for a in ans)}/{NA}")
p("  poor causes (primary): " + str(dict(Counter(a["poor_cause"] for a in ans if a["grade"] == "poor"))))
p("  poor causes (strict):  " + str(dict(Counter(a["poor_cause_strict"] for a in ans if a["grade_strict"] == "poor"))))
p(f"  by lead source: " + str({ls: dict(Counter(a['grade'] for a in ans if a['lead_source'] == ls)) for ls in ('model', 'model_after_repair', 'code', 'plain')}))
p("  every poor answer (primary), one line each:")
for a in ans:
    if a["grade"] == "poor" or a["grade_strict"] == "poor":
        p(f"    {a['key']} [{a['grade']}/{a['grade_strict']}/{a['grade_lenient']} primary/strict/lenient] {a['poor_cause'] or a['poor_cause_strict']}: {a['note']}"
          + (f"; faults sent: {a['false_sent']} (strict {a['false_sent_strict']}, lenient {a['false_sent_lenient']})" if a["false_sent_strict"] else ""))
p("")
p("== 5. Per answer ==")
p("  key     src   grade/strict/lenient  ans means offer brief  sent faults p/s/l")
for a in ans:
    p(f"  {a['key']:7s} {a['lead_source'][:5]:5s} {a['grade'][:4]:4s}/{a['grade_strict'][:4]:4s}/{a['grade_lenient'][:4]:4s}         {'yn'[not a['answers_question']]}   {'yn'[not a['says_what_numbers_mean']]}     {'yn'[not a['carries_offer']]}     {'yn'[not a['brief']]}      {a['false_sent']}/{a['false_sent_strict']}/{a['false_sent_lenient']}")
p("")
p("== 6. Borderline sentences (the strict and lenient readings differ) ==")
for r in rows:
    if r.get("borderline"):
        p(f"  {r['key']} {r['form']} {r['where']}{r['index']} {r['truth']} sent={r['sent']} | {r['borderline']}")
p("")
exec(open(D + "notes_r.py").read())
open(D + "numbers.txt", "w").write("\n".join(out) + "\n")

# sent_faults.txt
o = []
o.append("Every false or wrongly based sentence SENT in mvp25/runa2/run1 (fresh half A, cells-only checker, prompt v3), by the independent recount (recount2).")
o.append("Tier 1: firm (every reading). Tier 2: primary, passed by the lenient reading. Tier 3: strict only.")
o.append("Origin: 'as the model wrote it' (the model's unchecked framing went out); 'tool gave a wrong/incomplete picture' (the tool result led the model there;")
o.append("read from the tool result as evidence of origin only, never of truth); 'neighbour drop' (the checker's drop of another sentence made it wrong).")
o.append("False (a wrong number, name, date or calculation) sent: %d in every reading." % sum(r["sent_truth"] == "false" for r in SN))
o.append("")
tiers = [("Tier 1: firm", lambda r: r["sent_truth_lenient"] in BAD),
         ("Tier 2: primary, lenient passes", lambda r: r["sent_truth"] in BAD and r["sent_truth_lenient"] not in BAD),
         ("Tier 3: strict only", lambda r: r["sent_truth_strict"] in BAD and r["sent_truth"] not in BAD)]
msg = {a["key"]: a["message"] for a in ans}
for lab, f in tiers:
    R = [r for r in SN if f(r)]
    o.append(f"== {lab}: {len(R)} sentences in {len({r['key'] for r in R})} answers ==")
    for r in R:
        o.append(f"{r['key']}  message: \"{msg[r['key']]}\"")
        o.append(f"  sent ({r['where']} {r['index']}, {r['form']} form): \"{r['text_plain']}\"")
        o.append(f"  origin: {r['sent_origin']}")
        o.append(f"  verdict: {r['sent_truth']} (strict {r['sent_truth_strict']}, lenient {r['sent_truth_lenient']}); fault: {r['sent_fault'] or r['sent_borderline']}")
        if r.get("sent_borderline") and r["sent_fault"]:
            o.append(f"  other reading: {r['sent_borderline']}")
        o.append(f"  private line on the answer: {'yes' if r['answer_private_line'] else 'no'}")
    o.append("")
open(D + "sent_faults.txt", "w").write("\n".join(o) + "\n")
print("\n".join(out[:80]))
