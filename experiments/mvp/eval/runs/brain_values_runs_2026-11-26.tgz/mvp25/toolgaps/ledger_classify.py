import json, re, sys
from collections import Counter
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/toolgaps"
a = json.load(open(S + "/ledger_diff.before.json")); b = json.load(open("mvp/eval/brain_toolfix_ledger_diff.json"))
print("ledgers pinned before", len(a), "after", len(b), "| entries before", sum(map(len, a.values())), "after", sum(map(len, b.values())))
new = Counter(); ex = {}; led = Counter()
for k in sorted(set(a) | set(b)):
    oa = {json.dumps(e, sort_keys=True) for e in a.get(k, [])}; ob = {json.dumps(e, sort_keys=True) for e in b.get(k, [])}
    for tag, s_ in (("new", ob - oa), ("gone", oa - ob)):
        for e in s_:
            e = json.loads(e); key = (tag, e[0], re.sub(r"\[\d+\]", "[]", e[1])); new[key] += 1; ex.setdefault(key, (k, e)); led[k] += 1
for key, n in sorted(new.items(), key=lambda x: -x[1]):
    print(n, key, json.dumps(ex[key][1][2:], default=str)[:150])
print("ledgers whose pinned diff changed:", len(led))
