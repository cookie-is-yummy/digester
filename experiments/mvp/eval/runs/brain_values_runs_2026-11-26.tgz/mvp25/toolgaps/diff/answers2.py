"""The full-mode answer differential of mvp24 (diff_full.py --answers) with this round's intended changes named: the
new keys of answer.build (cards, ask, limits) are set apart, and every other difference is listed by kind."""
import os, sys, json
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa
FBb = L._load(os.path.join(L.HERE, "base", "fallback_base.py"), "fallback_base"); FBb.V = L.VB
Ab = L._load(os.path.join(L.HERE, "base", "answer_base.py"), "answer_base"); Ab.V = L.VB
from mvp.brain import fallback as FB, answer as A  # noqa
NEW = ("cards", "ask", "limits")
kinds = Counter(); n = 0; rows = []
for look, rec, t, results in L.look_inputs():
    for fi, f in enumerate(rec.get("forms") or []):
        n += 1
        vb = L.VB.check_answer(f, results, L.VB.Turn.of(t)); vr = L.V.check_answer(f, results, L.V.Turn.of(t), mode="full")
        cb = FBb.answer(L.VB.Ledger(results), vb, L.VB.Turn.of(t)); cr = FB.answer(L.V.Ledger(results), vr, L.V.Turn.of(t), mode="full")
        ab = Ab.build(L.VB.Ledger(results), verdict=None, code=cb, form=f, also=[vb])
        ar = A.build(L.V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode="full")
        mb = Ab.build(L.VB.Ledger(results), verdict=vb, form=f, also=[vb])
        mr = A.build(L.V.Ledger(results), verdict=vr, form=f, also=[vr], mode="full")
        k = []
        if repr(cb) != repr(cr):
            k.append("code_lead:" + ("lead_text" if cb.get("lead") != cr.get("lead") else "other"))
        for tag, x, y in (("code_build", ab, ar), ("model_build", mb, mr)):
            xo = {kk: v for kk, v in x.items()}; yo = {kk: v for kk, v in y.items() if kk not in NEW}
            if repr(xo) != repr(yo):
                k.append(tag + ":" + ("text" if xo.get("text") != yo.get("text") else "other"))
            if y.get("cards"):
                k.append(tag + ":cards")
            if y.get("limits"):
                k.append(tag + ":limits")
        for kk in k:
            kinds[kk] += 1
        if any(x.startswith("code_lead") or x.endswith(":other") for x in k):
            rows.append((look, rec["key"], fi, k, cb.get("lead"), cr.get("lead")))
print(f"{n} forms; differences by kind (a form can have several): {dict(sorted(kinds.items()))}")
for r in rows:
    print(" ", r[0], r[1], r[2], r[3]); print("     base:", r[4]); print("     now: ", r[5])
