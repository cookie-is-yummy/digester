import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa
FBb = L._load(os.path.join(L.HERE, "base", "fallback_base.py"), "fallback_base"); FBb.V = L.VB
from mvp.brain import fallback as FB  # noqa
from collections import Counter
c = Counter()
for look, rec, t, results in L.look_inputs():
    for fi, f in enumerate(rec.get("forms") or []):
        vb = L.VB.check_answer(f, results, L.VB.Turn.of(t)); vr = L.V.check_answer(f, results, L.V.Turn.of(t), mode="full")
        cb = FBb.answer(L.VB.Ledger(results), vb, L.VB.Turn.of(t)); cr = FB.answer(L.V.Ledger(results), vr, L.V.Turn.of(t), mode="full")
        if repr(cb) != repr(cr) and cb.get("lead") == cr.get("lead"):
            keys = tuple(sorted(k for k in set(cb) | set(cr) if cb.get(k) != cr.get(k)))
            tool = (results.get(cr.get("rid")) or {}).get("tool")
            c[(keys, tool)] += 1
print(c)
