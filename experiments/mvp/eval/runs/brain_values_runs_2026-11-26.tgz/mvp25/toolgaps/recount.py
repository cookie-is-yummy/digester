"""Hand recount from the made-up library's own rows (tests/brain_library.rows), with no tool, facts or history code:
the figures each fixed tool result shows. Local time is America/New_York. Friends' posts are left out (rule 5); the
private topic is theme 'da' (dating), left out unless a turn unlocked it."""
import sys, os
from collections import Counter
from datetime import datetime, date
from zoneinfo import ZoneInfo
sys.path.insert(0, os.path.join(sys.argv[1], "experiments"))
from mvp.tests import brain_library as B
NY = ZoneInfo("America/New_York")
rows = [r for r in B.rows() if not r.get("friend")]
def local(at):
    return datetime.fromisoformat(at).astimezone(NY)
def opens(pred=lambda r: True, a=None, b=None, private=False):
    out = []
    for r in rows:
        if r["theme"] == "da" and not private:
            continue
        if not pred(r):
            continue
        for k, at in r["events"]:
            if k != "watch":
                continue
            d = local(at)
            if (a is None or d.date() >= a) and (b is None or d.date() <= b):
                out.append((r, d))
    return out
P = print
P("== 1 windows")
P("summer 2026 opened:", len(opens(a=date(2026, 6, 1), b=date(2026, 8, 31))))
P("summer 2025 opened:", len(opens(a=date(2025, 6, 1), b=date(2025, 8, 31))))
s25 = opens(a=date(2025, 6, 1), b=date(2025, 8, 31))
P("  summer 2025 by theme:", Counter(r["theme"] for r, _ in s25), "art (dd+wc):", sum(1 for r, _ in s25 if r["theme"] in ("dd", "wc")))
lo = opens(a=date(2026, 10, 21), b=date(2026, 10, 31))
P("late October 2026 (21-31) opened:", len(lo), "days:", len({d.date() for _, d in lo}), "by theme:", Counter(r["theme"] for r, _ in lo))
P("  late Oct shorts (length<=60, youtube):", sum(1 for r, _ in lo if (r.get("length") or 999) <= 60))
mid = opens(a=date(2023, 5, 1), b=date(2023, 8, 31))
P("mid 2023 (May-Aug) opened:", len(mid), "by theme:", Counter(r["theme"] for r, _ in mid))
P("last event day overall:", max(local(at).date() for r in rows for k, at in r["events"]))
P("== 2 export holds")
P("event kinds:", Counter(k for r in rows for k, _ in r["events"]))
for plat in ("youtube", "instagram"):
    ds = [local(at).date() for r in rows if r["platform"] == plat for k, at in r["events"]]
    P(" ", plat, min(ds), "to", max(ds))
P("== 4 events of search hits")
for iid in ("rx_sour1", "rx_sour2"):
    r = next(x for x in rows if x["id"] == iid)
    P(" ", iid, [(k, local(at).date().isoformat()) for k, at in r["events"]])
P("== 5 dating (private topic)")
for y in (2023, 2024):
    P("  dating opened", y, len(opens(lambda r: r["theme"] == "da", date(y, 1, 1), date(y, 12, 31), private=True)),
      "| all opened with it:", len(opens(a=date(y, 1, 1), b=date(y, 12, 31), private=True)),
      "| without it:", len(opens(a=date(y, 1, 1), b=date(y, 12, 31))))
P("== 6 parts of day, all history (opens, private left out)")
al = opens()
h = Counter(d.hour for _, d in al)
parts = {"morning": range(5, 12), "afternoon": range(12, 17), "evening": range(17, 21), "night": list(range(21, 24)) + list(range(0, 5))}
P("  total", len(al), {k: sum(h[x] for x in v) for k, v in parts.items()}, "2pm-8pm:", sum(h[x] for x in range(14, 20)))
P("  busiest hours:", h.most_common(3))
ig = [(r, d) for r, d in al if r["platform"] == "instagram"]
P("  instagram opens:", len(ig), "hours:", Counter(d.hour for _, d in ig))
P("  this year by part:", {k: sum(1 for _, d in opens(a=date(2026,1,1)) if d.hour in v) for k, v in parts.items()})
P("== 6 first dates")
for ch in ("Pixel Pencil", "Clip Factory", "Gaming Daily"):
    ds = [d.date() for r, d in al if r.get("channel") == ch]
    P(" ", ch, min(ds) if ds else None, len(ds))
for th in ("dd", "cl", "mc", "ca"):
    ds = [d.date() for r, d in al if r["theme"] == th]
    P("  theme", th, min(ds))
P("== 6 ties: max opens of one item, all history (private left out)")
c = Counter(r["id"] for r, _ in al)
P("  max opens of one item:", max(c.values()), "| cooking items opened:", sum(1 for r, _ in al if r["theme"] == "co"),
  "| long items:", sum(1 for r, _ in al if r["platform"] == "youtube" and (r.get("length") or 0) > 60))
P("== 8 timeline this year")
m = Counter(d.month for _, d in opens(a=date(2026, 1, 1)))
P("  by month:", sorted(m.items()))
P("  newest cooking opened:", max(((d, r["caption"]) for r, d in al if r["theme"] == "co")))
P("  last minecraft opened:", max(((d, r["caption"]) for r, d in al if r["theme"] == "mc")))
