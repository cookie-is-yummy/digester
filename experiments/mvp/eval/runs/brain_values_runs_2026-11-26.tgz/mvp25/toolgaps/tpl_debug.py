import json, sys, os
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
from mvp.brain import fallback as FB, verify as V  # noqa
for k in sys.argv[2:]:
    t, new = RP.replay(k)
    vt = V.Turn.of(t); led = V.Ledger(t.results)
    for res in led.by_rid.values():
        for tp in FB.templates(res):
            v = V.check_answer({"lead": tp, "points": []}, led, vt, mode="full")
            print(k, res.rid, "OK " if v.lead_ok else "BAD", tp[:200], [ (o.reasons, o.details) for o in v.lead if not o.kept])
