"""Write evalset/brain_fresh.jsonl with half A rebuilt and half B kept as stored, when the only problem left is a
lapsed half B refusal listed by id in tests/test_brain_fresh.LAPSED_B (the builder itself refuses to write)."""
import sys, os, re
sys.path.insert(0, os.getcwd())
from mvp.eval import build_brain_fresh as BF
from mvp.tests import test_brain_fresh as TF
convs, problems, findings = BF.build()
p2, _near = BF.check_set(convs)
problems += p2
left = [p for p in problems if not (p.split(".")[0] in TF.LAPSED_B and "must be refused was not" in p)]
print("problems:", len(problems), "left after LAPSED_B:", left)
ls, b_differs = BF.keep_half_b(BF.lines(convs), BF.stored_lines())
sha = BF.half_b_sha(ls)
print("half B sha256:", sha, "pinned:", TF.HALF_B_SHA256, "same:", sha == TF.HALF_B_SHA256)
if left or sha != TF.HALF_B_SHA256:
    sys.exit("not written")
with open(BF.OUT, "w", encoding="utf-8") as f:
    f.write("".join(ln + "\n" for ln in ls))
print("wrote", BF.OUT)
