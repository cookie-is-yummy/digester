#!/bin/bash
# runtests.sh NAME file1 file2 ... : each test file in parallel (up to 4 at a time), results in toolgaps/NAME/
T=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/tools_tree/experiments
O=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp25/toolgaps/$1
shift
mkdir -p "$O"
find "$O" -name '*.txt' -delete
cd "$T"
for f in "$@"; do
  while [ "$(jobs -r | wc -l)" -ge 4 ]; do sleep 1; done
  python3 -m pytest -q -p no:cacheprovider "mvp/tests/$f.py" > "$O/$f.txt" 2>&1 &
done
wait
for f in "$O"/*.txt; do echo "$(basename "$f"): $(tail -1 "$f")"; done
grep -h "^FAILED\|^ERROR" "$O"/*.txt | head -40
