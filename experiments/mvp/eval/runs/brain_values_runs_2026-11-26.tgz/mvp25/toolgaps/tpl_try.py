import json, sys, os
here = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, here)
import replay as RP  # noqa
from mvp.brain import verify as V  # noqa
k = sys.argv[2]
t, new = RP.replay(k)
vt = V.Turn.of(t); led = V.Ledger(t.results)
for line in open(sys.argv[3]):
    line = line.strip()
    if not line: continue
    for mode in ("full", "cells"):
        v = V.check_answer({"lead": line, "points": []}, led, vt, mode=mode)
        print(mode, "OK " if v.lead_ok else "BAD", line[:150], [(o.reasons, o.details) for o in v.lead if not o.kept])
