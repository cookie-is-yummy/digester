"""The code lead of the four run1 code-lead messages (and other keys) on today's tools: replayed results, the form the
model wrote (its first and repair forms), FB.answer in cells mode, then A.build."""
import json, sys, os
sys.argv = [sys.argv[0], sys.argv[1]] + sys.argv[2:]
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import replay as RP  # noqa
from mvp.brain import fallback as FB, verify as V, answer as A, loop as BL  # noqa
for k in sys.argv[2:]:
    t, new = RP.replay(k)
    rec = json.load(open(f"{RP.RUN}/{k}.json"))
    vt = V.Turn.of(t)
    form = rec["forms"][-1] if rec["forms"] else {}
    v = V.check_answer(form, t.results, vt, mode="cells") if form else None
    code = FB.answer(V.Ledger(t.results), v, vt, mode="cells")
    print("=" * 70); print(k, rec["message"]); print("  code:", json.dumps({x: code.get(x) for x in ("how", "lead", "items", "marked")})[:600])
    kw = {}
    import inspect
    if "links" in inspect.signature(A.build).parameters:
        kw["links"] = lambda iid: getattr(t.lib.view.items.get(iid), "url", None)
        kw["limits"] = list(t.limits)
    out = A.build(V.Ledger(t.results), verdict=None, code=code, form=form, also=[v] if v else [], mode="cells", **kw)
    print("  TEXT:\n    " + out["text"].replace("\n", "\n    "))
    if v is not None and v.lead_ok:
        out2 = A.build(V.Ledger(t.results), verdict=v, form=form, also=[v], mode="cells", **kw)
        print("  MODEL TEXT (form as saved, re-checked):\n    " + out2["text"].replace("\n", "\n    "))
