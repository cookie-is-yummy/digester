import json, sys, glob
run = sys.argv[1]
keys = sys.argv[2:]
for k in keys:
    r = json.load(open(f"{run}/{k}.json"))
    print("=" * 90)
    print(k, "|", r["message"], "| screen:", json.dumps(r.get("screen"))[:300])
    for c in r["calls"]:
        a = {kk: v for kk, v in c["args"].items()}
        res = c.get("result") or {}
        print("  CALL", c["round"], c["name"], json.dumps(a, separators=(",", ":"))[:400])
        if res.get("is_error") or res.get("error"):
            print("     ERR:", res.get("error"), {kk: v for kk, v in res.items() if kk not in ("error", "is_error", "meta")})
        m = res.get("meta") or {}
        if m:
            print("     meta:", json.dumps({kk: m.get(kk) for kk in ("window_said", "filters_said", "resolved", "order", "notes", "hidden", "windows")}, separators=(",", ":"))[:700])
        sh = res.get("sheet")
        if isinstance(sh, dict):
            print("     sheet keys:", list(sh.keys()))
            for kk in ("items", "totals", "periods", "names"):
                if kk in sh:
                    print("     ", kk, json.dumps(sh[kk], separators=(",", ":"))[:900])
    print("  events:", r.get("events"), "lead:", r["lead_source"])
    for f in r["forms"]:
        print("  FORM lead:", f.get("lead"), "| points:", f.get("points"), "| items:", f.get("items"), "| ask_back:", f.get("ask_back"))
    print("  SENT:", (r.get("answer") or {}).get("text"))
