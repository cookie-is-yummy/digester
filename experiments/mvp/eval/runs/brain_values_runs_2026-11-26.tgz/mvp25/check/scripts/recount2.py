"""Second pass of the independent recount: windows from a hand table (DESIGN 25.1's convention, today 22 Nov 2026),
order and completeness of lists, first/last picks, ties, and how many leaves of the sheets the two passes cover."""
import json, re, sys
from datetime import date
from collections import Counter
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp25/check/scripts")
import recount as RC
D = date.fromisoformat
# key -> (start, end) the words name by the convention, BEFORE any cut at the export's end; then the cut expected
YT, IG = D("2026-10-30"), D("2026-10-15")
WIN = {
 "T01:0": ("2026-06-01", "2026-08-31"), "T01:1": ("2026-06-01", "2026-08-31"), "T01:2": ("2025-06-01", "2025-08-31"),
 "T01:3": ("2026-06-01", "2026-08-31"),
 "T02:0": ("2026-10-21", "2026-10-31"), "T02:1": ("2026-10-21", "2026-10-31"), "T02:2": ("2026-10-21", "2026-10-31"),
 "T02:3": ("2026-10-11", "2026-10-20"), "T02:4": ("2026-10-21", "2026-10-31"),
 "T03:0": ("2023-05-01", "2023-08-31"), "T03:1": ("2023-01-01", "2023-04-30"), "T03:2": ("2023-07-01", "2023-12-31"),
 "T03:3": ("2023-09-01", "2023-12-31"), "T03:4": ("2023-05-01", "2023-08-31"),
 "T04:0": ("2023-08-01", "2023-08-31"), "T04:1": ("2026-01-01", "2026-01-31"), "T04:2": ("2026-09-01", "2026-09-30"),
 "T04:3": ("2026-05-01", "2026-05-31"), "T04:4": ("2026-08-01", "2026-08-31"), "T04:5": ("2025-01-01", "2025-04-30"),
 "T04:6": ("2024-12-01", "2025-02-28"), "T04:7": ("2026-09-01", "2026-11-30"),
 "T05:0": ("2026-11-01", "2026-11-22"), "T05:1": ("2026-11-09", "2026-11-15"), "T05:2": ("2026-11-09", "2026-11-22"),
 "T05:4": ("2026-11-01", "2026-11-10"), "T05:6": ("2026-10-21", "2026-10-31"),
 "T06:1": ("2026-01-01", "2026-11-22"), "T06:2": (None, None),
 "T08:1": ("2026-10-01", "2026-10-10"),
 "T09:1": ("2024-01-01", "2024-12-31"), "T09:2": ("2024-01-01", "2024-12-31"), "T10:0": ("2024-01-01", "2024-12-31"),
 "T10:1": ("2024-01-01", "2024-12-31"), "T10:3": ("2024-01-01", "2024-12-31"), "T10:4": ("2024-01-01", "2024-12-31"),
 "T11:2": ("2026-01-01", "2026-11-22"), "T11:4": ("2023-01-01", "2023-12-31"),
 "T12:0": ("2026-10-01", "2026-10-31"), "T12:1": ("2021-01-01", "2021-12-31"),
 "T13:0": ("2026-01-01", "2026-11-22"), "T13:1": ("2026-09-01", "2026-11-30"), "T13:2": ("2023-01-01", "2023-12-31"),
 "T13:3": ("2025-01-01", "2025-12-31"), "T14:0": ("2021-01-01", "2021-12-31"), "T14:1": ("2021-01-01", "2021-12-31"),
 "T15:0": ("2023-01-01", "2023-12-31"), "T15:2": ("2026-01-01", "2026-11-22"),
}
COMPARE_B = {"T01:0": ("2025-06-01", "2025-08-31"), "T01:1": ("2025-06-01", "2025-08-31"),
             "T03:4": ("2023-01-01", "2023-04-30"), "T10:0": ("2023-01-01", "2023-12-31"), "T10:4": ("2023-01-01", "2023-12-31")}
SEASON_OF = {12: "winter", 1: "winter", 2: "winter", 3: "spring", 4: "spring", 5: "spring", 6: "summer", 7: "summer",
             8: "summer", 9: "fall", 10: "fall", 11: "fall"}
F = []
def f(kind, key, what, tool, want):
    F.append((kind, key, what, tool, want))

def main():
    R = json.load(open(S + "/mvp25/check/results.json"))
    leaves = Counter(); checked_paths = set()
    for r in R:
        for k, c in enumerate(r["calls"]):
            key = f"{r['tid']}:{k}"; env = c["result"]
            if env.get("is_error") or "sheet" not in env:
                continue
            sh, m, a = env["sheet"], env["meta"], c["args"]
            wd = m.get("window_dates")
            # ---- windows
            if key in WIN and WIN[key][0]:
                s0, e0 = D(WIN[key][0]), D(WIN[key][1])
                plats = (a.get("scope") or {}).get("platforms") or ["youtube", "instagram"]
                end_cut = min(e0, max(YT if "youtube" in plats else D("2000-01-01"), IG if "instagram" in plats else D("2000-01-01")), D("2026-11-22"))
                if s0 > end_cut:
                    f("window_after_end", key, "words " + json.dumps(a.get("window") or a.get("a")), f"{wd['start']}..{wd['end']} said {m.get('window_said')!r}", f"asked {s0}..{e0}: after the export's end (cannot_see={sh.get('cannot_see')})")
                elif (D(wd["start"]), D(wd["end"])) != (s0, end_cut):
                    f("window", key, "window_dates", f"{wd['start']}..{wd['end']}", f"{s0}..{end_cut}")
                if wd and wd.get("days") != (D(wd["end"]) - D(wd["start"])).days + 1:
                    f("window", key, "window_dates.days", wd.get("days"), (D(wd["end"]) - D(wd["start"])).days + 1)
            if key in COMPARE_B:
                b = m["window_dates_b"]
                if (b["start"], b["end"]) != COMPARE_B[key]:
                    f("window", key, "window_dates_b", (b["start"], b["end"]), COMPARE_B[key])
            # ---- the window before: its label against its dates
            pw = (sh.get("previous") or {}).get("words") or ""
            got = RC.parse_said(pw)
            if got and c["name"] != "compare":
                ps, pe = got
                mm = re.search(r"the (spring|summer|fall|autumn|winter) before", pw)
                if mm:
                    name = mm.group(1).replace("autumn", "fall")
                    first_month = {"winter": 12, "spring": 3, "summer": 6, "fall": 9}[name]
                    if ps.month != first_month or (pe.month - ps.month) % 12 != 2:
                        f("prev_label", key, "previous.words", pw, f"{ps}..{pe} is not a {name} (a {name} runs from month {first_month} for 3 months)")
                mm = re.search(r"the (\d+) months before", pw)
                if mm:
                    n = int(mm.group(1))
                    months = (pe.year - ps.year) * 12 + pe.month - ps.month + 1
                    whole = ps.day == 1 and (pe.month != (pe.replace(day=28)).month or True)
                    import calendar
                    full_end = pe.day == calendar.monthrange(pe.year, pe.month)[1]
                    if months != n or not full_end:
                        f("prev_label", key, "previous.words", pw, f"{ps}..{pe} is {(pe-ps).days+1} days, not {n} whole months")
                if wd:
                    wl = (D(wd["end"]) - D(wd["start"])).days + 1; pl = (pe - ps).days + 1
                    if abs(wl - pl) > 3 and not any("not the same length" in n_ for n_ in m.get("notes") or []):
                        f("prev_length", key, "previous vs window", f"previous {pl} days ({pw})", f"window {wl} days ({wd['said']}); no note says they differ; previous_items/new/stopped set against it")
            # ---- ties and order of items
            items = sh.get("items") or []
            if c["name"] == "items":
                order = a.get("order", "most_opened")
                scope = a.get("scope") or {}
                ws, we = D(wd["start"]), D(wd["end"])
                evs = RC.sel(ws, we, how=scope.get("how", "opened"), platforms=tuple(scope.get("platforms") or ()),
                             only=RC.only_fn(scope.get("only") or []) if scope.get("only") else None)
                last = {}
                for e in evs:
                    last[e["id"]] = max(last.get(e["id"], e["t"]), e["t"])
                if order in ("newest", "oldest"):
                    want = sorted(last, key=lambda i: last[i], reverse=(order == "newest"))[a.get("offset", 0):][:a.get("limit", 5)]
                    got_ids = [x["item_id"] for x in items]
                    if got_ids != want:
                        f("order", key, f"items order {order}", got_ids, want)
                else:
                    opens = Counter(e["id"] for e in evs)
                    mx = max(opens.values()) if opens else 0
                    allone = mx <= 1
                    tie = m.get("tie")
                    if allone and tie != "all":
                        f("tie", key, "meta.tie", tie, "all (no item opened twice)")
                    if not allone and tie == "all":
                        f("tie", key, "meta.tie", tie, f"max opens {mx}")
                if (sh.get("totals") or {}).get("items") is not None:
                    RC.cmp(key, "totals.items", sh["totals"]["items"], len(last))
            if c["name"] == "first_last" and items:
                scope = a.get("scope") or {}
                evs = RC.sel(how=scope.get("how", "opened"), platforms=tuple(scope.get("platforms") or ()),
                             length=scope.get("length", "any"), only=RC.only_fn([a["subject"]]),
                             private=a["subject"].lower() == "dating" or r["unlock"] == "relationships")
                pick = (min if a["which"] == "first" else max)(evs, key=lambda e: e["t"])
                if items[0]["item_id"] != pick["id"]:
                    f("first_last", key, "items[0]", items[0]["item_id"], pick["id"])
            # ---- completeness of the ranked lists
            ro = m.get("rows_of") or {}
            if ro and wd and c["name"] in ("breakdown", "compare"):
                scope = a.get("scope") or {}
                evs = RC.sel(D(wd["start"]), D(wd["end"]), how=scope.get("how", "opened"), platforms=tuple(scope.get("platforms") or ()),
                             length=scope.get("length", "any"), weekday=scope.get("weekday"),
                             only=RC.only_fn(scope.get("only") or []) if scope.get("only") else None,
                             private="dating" in [x.lower() for x in scope.get("only") or []])
                for lst, kk in (("areas", "area"), ("themes", "theme"), ("channels", "channel")):
                    if lst in ro:
                        n = len({e[kk] for e in evs})
                        if ro[lst] != n:
                            f("rows_of", key, f"meta.rows_of.{lst}", ro[lst], n)
                        shown = [x["items"] for x in sh.get(lst) or []]
                        if shown != sorted(shown, reverse=(a.get("order", "most") == "most")):
                            f("order", key, f"{lst} order", shown, "sorted")
            # ---- leaves
            for p, v in RC_flat(sh):
                if isinstance(v, bool) or v is None:
                    continue
                pat = re.sub(r"\[\d+\]", "[]", p)
                if pat.split(".")[0] in ("question", "filters", "window", "kind", "periods_unit", "query", "how"):
                    continue
                leaves[pat] += 1
    print("WINDOW, ORDER, TIE, FIRST/LAST, ROWS_OF findings:", len(F))
    for x in F:
        print(" ", x[0], x[1], x[2], "| tool:", x[3], "| want:", x[4])
    return leaves

def RC_flat(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "ref":
                continue
            yield from RC_flat(v, f"{p}.{k}" if p else k)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from RC_flat(v, f"{p}[{i}]")
    else:
        yield p, o

if __name__ == "__main__":
    RC.main()
    leaves = main()
    # which leaf patterns the recount reads
    COVERED = re.compile(r"^((totals|previous)\.(items|days_active|shorts|long|reels|shorts_share|long_median_min|by_platform\.\w+)|themes\[\]\.field|(themes|areas)\[\]\.change_vs_previous|areas\[\]\.themes\[\]\.(name|share)|fields\[\]\.share|when\.weekend_share|items\[\]\.platform|periods\[\]\.(themes|areas)\[\]\.(name|share)|"
                         r"(themes|channels|areas)\[\]\.(name|items|share|days|previous_items|previous_share|change_pts|shorts_share|first_watched|theme|area)|"
                         r"themes\[\]\.channels\[\]\.(name|items)|fields\[\]\.(name|items)|when\.(busiest_hours\[\]\.(hour|share)|weekday_share|events|busiest_weekday|parts_of_day\[\]\.(part|events|share))|"
                         r"items\[\]\.(item_id|title|channel|times_opened|length|when|how)|periods\[\]\.(label|items)|"
                         r"(new|stopped)\.(themes|channels)\[\]\.(name|items|previous_items|first_watched)|library\.saved_not_opened\[\]\.(theme|n|youtube))$")
    tot = sum(leaves.values()); cov = sum(v for p, v in leaves.items() if COVERED.match(p))
    print(f"leaves (numbers, dates, names) in the sheets: {tot}; read by the recount: {cov}; not read: {tot - cov}")
    for p, v in sorted(leaves.items(), key=lambda x: -x[1]):
        if not COVERED.match(p):
            print(f"   not read: {p} x{v}")
