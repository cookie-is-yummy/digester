from cases import CARRIER
CASES = [
 ("p1", "T10", "F", "free_date", "Heart Notes[r1.channels[0]] started on 1 February 2022.", "year not held by a result"),
 ("p2", "T10", "F", "free_date", "Heart Notes[r1.channels[0]] started on 1 February 2023.", "2023 held"),
 ("p3", "T13", "F", "free_date", "Clip Factory[r1.channels[1]] began in August 2026.", "Aug: not a held period?"),
 ("p4", "T02", "F", "tod", "You opened Cooking soup on the 30th[r2.items[0]] in the afternoon.", "9 pm"),
]
