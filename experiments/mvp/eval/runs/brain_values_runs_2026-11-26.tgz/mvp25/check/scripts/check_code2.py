"""Ask-back cards, limit lines under code and model leads, card date lines against the recount."""
import os, sys, re
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp25/check_tree/experiments"); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import check_code as CC     # runs (1)-(3) again, then:
from mvp.brain import verify as V
from datetime import date
import recount as RC
print("(4) ask-back")
for tid, lead, ask in (("T16", "I found a few: 5[r3.totals.items] videos on 25 October 2026.", ["r3.items[0]", "r3.items[4]"]),
                       ("T16", "Which one do you mean?", ["r3.items[0]", "r3.items[4]"]),
                       ("T08", "You saved 6[r1.totals.items] items.", ["r2.items[0]", "r2.items[1]"]),
                       ("T08", "Which one?", ["r4.items[3]"])):
    for between in (ask, []):
        form = {"lead": lead, "points": [], "ask_back": {"between": between}}
        r2, v = CC.finish(tid, form)
        a = r2["answer"]
        print(f"   {tid} lead={lead[:45]!r} between={between} -> source={r2['lead_source']} ask={a['ask']} cards={[c['ref'] for c in a['cards']]}")
print("(5) limit lines: code lead against model lead")
for tid, good, bad in (("T05", "In October 2026, you opened 142[r1.totals.items] videos.", "This month you opened 142[r1.totals.items] videos."),
                       ("T06", "This year you saved 6[r1.totals.items] items.", "This year you liked 6[r1.totals.items] items, all of them on Instagram."),
                       ("T17", "In October 2026, you opened 142[r1.totals.items] videos.", "In October you watched for 142[r1.totals.items] hours.")):
    for lead in (good, bad):
        r2, v = CC.finish(tid, {"lead": lead, "points": []})
        a = r2["answer"]
        print(f"   {tid} source={r2['lead_source']:6s} limits={a['limits']} | text={a['text'][:220]!r}")
print("(6) card lines: the date words against the recount's local date")
bad = 0; n = 0
for tid, (t, rec) in CC.done.items():
    for c in rec["calls"]:
        env = c["result"]
        if env.get("is_error") or not (env.get("sheet") or {}).get("items"): continue
        rid = env["rid"]
        for k, row in enumerate(env["sheet"]["items"]):
            r2, v = CC.finish(tid, {"lead": "Here they are.", "points": [], "items": [{"ref": f"{rid}.items[{k}]"}]})
            for cd in r2["answer"]["cards"]:
                n += 1
                ch, day, how = CC.row_truth(row)
                d = date.fromisoformat(day)
                want = f"{how} on {d.day} {d.strftime('%B')} {d.year}"
                if not cd["line"].endswith(want) or f"[{ch}]" not in cd["line"]:
                    bad += 1; print("   BAD", tid, cd["line"], "| want", want, ch)
print(f"   card lines checked: {n}; wrong: {bad}")
