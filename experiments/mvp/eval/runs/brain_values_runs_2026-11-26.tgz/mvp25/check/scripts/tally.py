import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
D = json.load(open(S + "/mvp25/check/cases_out.json"))
rows = D["rows"]
F = [r for r in rows if r["truth"] == "F"]; T = [r for r in rows if r["truth"] == "T"]
print(f"false {len(F)}, true {len(T)}")
def v(x): return "kept" if x["kept"] else ",".join(x["reasons"])
for mode in ("cells", "full"):
    fo = [r for r in F if r[f"P_{mode}"]["kept"] or r[f"L_{mode}"]["kept"]]
    tl = [r for r in T if not (r[f"P_{mode}"]["kept"] and r[f"L_{mode}"]["kept"])]
    print(f"== {mode}: false out (as point or lead) {len(fo)} of {len(F)}; true refused (as point or lead) {len(tl)} of {len(T)}")
    if mode == "cells" or "-v" in sys.argv:
        for r in fo:
            print(f"   OUT  {r['id']} {r['family']:14s} P={v(r[f'P_{mode}'])[:40]} L={v(r[f'L_{mode}'])[:40]} | {r['text']}  [{r['note']}]")
        for r in tl:
            print(f"   LOST {r['id']} {r['family']:14s} P={v(r[f'P_{mode}'])[:40]} L={v(r[f'L_{mode}'])[:40]} | {r['text']}")
# caught: reasons of false caught in cells
print("== cells: what caught each false sentence (point position)")
for r in F:
    if not (r["P_cells"]["kept"] or r["L_cells"]["kept"]):
        print(f"   {r['id']} {r['family']:14s} P={v(r['P_cells'])[:60]} L={v(r['L_cells'])[:60]}")
