"""Call the read tools of the check tree on the made-up library; save every result to check/results.json."""
import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = S + "/mvp25/check_tree"
sys.path.insert(0, TREE + "/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL, loop as BL
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
W = lambda w: {"words": w}
P = lambda p: {"preset": p}
TURNS = [
 ("T01", "how was this summer vs last summer?", None, [
   ("compare", {"a": W("this summer"), "b": W("last summer"), "by": "channel"}),
   ("compare", {"a": W("this summer"), "b": W("last summer"), "by": "theme"}),
   ("breakdown", {"by": "area", "window": W("last summer")}),
   ("breakdown", {"by": "channel", "window": W("the summer")}),
 ]),
 ("T02", "what did I watch in late October, and mid October?", None, [
   ("breakdown", {"by": "channel", "window": W("late October")}),
   ("items", {"window": W("late October"), "order": "newest", "limit": 6}),
   ("breakdown", {"by": "none", "window": W("late October")}),
   ("breakdown", {"by": "theme", "window": W("mid October")}),
   ("breakdown", {"by": "channel", "window": W("late October"), "scope": {"platforms": ["instagram"]}}),
 ]),
 ("T03", "how did mid 2023 compare to early 2023, and the second half of 2023 and the end of 2023?", None, [
   ("breakdown", {"by": "theme", "window": W("mid 2023")}),
   ("breakdown", {"by": "theme", "window": W("early 2023")}),
   ("breakdown", {"by": "channel", "window": W("the second half of 2023")}),
   ("breakdown", {"by": "area", "window": W("the end of 2023")}),
   ("compare", {"a": W("mid 2023"), "b": W("early 2023"), "by": "area"}),
 ]),
 ("T04", "and the seasons: late summer of 2023, mid winter, early autumn, late spring, the end of the summer, the start of 2025", None, [
   ("breakdown", {"by": "theme", "window": W("late summer of 2023")}),
   ("breakdown", {"by": "channel", "window": W("mid winter")}),
   ("breakdown", {"by": "channel", "window": W("early autumn")}),
   ("breakdown", {"by": "theme", "window": W("late spring")}),
   ("breakdown", {"by": "channel", "window": W("the end of the summer")}),
   ("breakdown", {"by": "theme", "window": W("the start of 2025")}),
   ("breakdown", {"by": "theme", "window": W("last winter")}),
   ("breakdown", {"by": "theme", "window": W("this autumn")}),
 ]),
 ("T05", "what about this month, last week, the last 2 weeks, November, early November and the first week of October?", None, [
   ("breakdown", {"by": "channel", "window": P("this_month")}),
   ("breakdown", {"by": "channel", "window": P("last_week")}),
   ("breakdown", {"by": "none", "window": W("the last 2 weeks")}),
   ("compare", {"a": W("November"), "b": W("October")}),
   ("breakdown", {"by": "theme", "window": W("early November")}),
   ("breakdown", {"by": "theme", "window": W("the first week of October")}),
   ("items", {"window": W("late October"), "scope": {"platforms": ["instagram"]}, "order": "newest"}),
 ]),
 ("T06", "what did I like this year, and what did I save?", None, [
   ("breakdown", {"by": "channel", "window": P("this_year"), "scope": {"how": "liked"}}),
   ("breakdown", {"by": "channel", "window": P("this_year"), "scope": {"how": "saved"}}),
   ("breakdown", {"by": "theme", "window": P("all"), "scope": {"how": "any"}}),
   ("items", {"window": P("this_year"), "scope": {"how": "liked"}, "order": "newest"}),
 ]),
 ("T07", "when did I first watch watercolor on instagram, last cooking video, first Pan Theory save, first gaming clip from Gaming Daily?", None, [
   ("first_last", {"subject": "watercolor", "which": "first", "scope": {"platforms": ["instagram"]}}),
   ("first_last", {"subject": "cooking", "which": "last", "scope": {"only": ["cooking"]}}),
   ("first_last", {"subject": "Pan Theory", "which": "first", "scope": {"how": "saved"}}),
   ("first_last", {"subject": "gaming clips", "which": "first", "scope": {"only": ["Gaming Daily"]}}),
   ("first_last", {"subject": "Brick Realm", "which": "last", "scope": {"length": "short"}}),
   ("first_last", {"subject": "cooking", "which": "first", "scope": {"how": "any"}}),
   ("first_last", {"subject": "watercolor", "which": "last", "scope": {"how": "saved"}}),
 ]),
 ("T08", "show me what I saved and opened in early October", None, [
   ("items", {"window": P("all"), "scope": {"how": "saved"}, "order": "newest", "limit": 8}),
   ("items", {"window": W("early October"), "scope": {"how": "any"}, "order": "oldest", "limit": 10}),
   ("search", {"query": "sourdough bread", "how": "saved"}),
   ("search", {"query": "watercolor portrait", "how": "any"}),
   ("first_last", {"subject": "sourdough", "which": "last", "scope": {"how": "any"}}),
 ]),
 ("T09", "was I watching dating videos in 2024?", None, [
   ("find", {"names": ["dating"]}),
   ("breakdown", {"by": "theme", "window": W("2024"), "scope": {"only": ["dating"]}}),
   ("timeline", {"unit": "month", "window": W("2024"), "scope": {"only": ["dating"]}}),
 ]),
 ("T10", "and how did that compare to 2023 and what else did I watch in 2024?", "T09", [
   ("compare", {"a": W("2024"), "b": W("2023"), "scope": {"only": ["dating"]}}),
   ("breakdown", {"by": "theme", "window": W("2024")}),
   ("first_last", {"subject": "dating", "which": "first"}),
   ("items", {"window": W("2024"), "order": "oldest", "limit": 4}),
   ("compare", {"a": W("2024"), "b": W("2023"), "by": "theme"}),
 ]),
 ("T11", "what time of day do I watch, and on saturdays, and my shorts, and in 2023?", None, [
   ("breakdown", {"by": "none", "window": P("all")}),
   ("breakdown", {"by": "none", "window": P("all"), "scope": {"platforms": ["instagram"]}}),
   ("breakdown", {"by": "none", "window": P("this_year"), "scope": {"length": "short"}}),
   ("breakdown", {"by": "none", "window": P("all"), "scope": {"weekday": 5}}),
   ("breakdown", {"by": "none", "window": W("2023")}),
 ]),
 ("T12", "what did I watch the most in October, and in 2021?", None, [
   ("items", {"window": W("October"), "order": "most_opened", "limit": 5}),
   ("items", {"window": W("2021"), "order": "most_opened", "limit": 3}),
   ("items", {"window": P("all"), "order": "most_opened", "limit": 5, "scope": {"only": ["Wet Paper"]}}),
 ]),
 ("T13", "what's new this year compared to last year, and what changed this autumn and in 2023 and 2025?", None, [
   ("changes", {"level": "channel", "window": P("this_year"), "against": "same_last_year"}),
   ("changes", {"level": "theme", "window": W("this autumn")}),
   ("changes", {"level": "area", "window": W("2023"), "against": "previous"}),
   ("changes", {"level": "theme", "window": W("2025"), "against": "previous"}),
 ]),
 ("T14", "rank my channels, areas and themes in 2021 and least watched overall", None, [
   ("breakdown", {"by": "channel", "window": W("2021")}),
   ("breakdown", {"by": "area", "window": W("2021")}),
   ("breakdown", {"by": "theme", "window": P("all"), "order": "least"}),
   ("breakdown", {"by": "channel", "window": P("all"), "top": 12}),
 ]),
 ("T16", "what was my last Brick Realm and Wet Paper video, and what did I watch on 25 October and 20 October, and that cooking hack?", None, [
   ("first_last", {"subject": "Brick Realm", "which": "last"}),
   ("first_last", {"subject": "Wet Paper", "which": "last"}),
   ("items", {"window": W("25 October"), "order": "newest", "limit": 6}),
   ("search", {"query": "cooking hack", "how": "opened"}),
   ("items", {"window": W("20 October"), "order": "newest", "limit": 3, "scope": {"only": ["Brick Realm"]}}),
 ]),
 ("T17", "how many hours did I spend watching in October, and how long were my videos this year?", None, [
   ("breakdown", {"by": "none", "window": W("October")}),
   ("breakdown", {"by": "channel", "window": P("this_year"), "scope": {"length": "long"}}),
 ]),
 ("T15", "month by month in 2023, and watercolor by year, and instagram this year", None, [
   ("timeline", {"unit": "month", "window": W("2023")}),
   ("timeline", {"unit": "year", "window": P("all"), "scope": {"only": ["watercolor"]}}),
   ("timeline", {"unit": "month", "window": P("this_year"), "scope": {"platforms": ["instagram"]}}),
 ]),
]
def run(h):
    out = []
    done = {}
    for tid, msg, prev, calls in TURNS:
        carry = BL.unlock_after(*done[prev]) if prev else None
        t = h.turn(msg, search=FakeEngine(), learned=fake_learned, carried_unlock=carry)
        rec = {"tid": tid, "message": msg, "carried_unlock": carry, "unlock": t.unlock, "calls": []}
        for name, args in calls:
            env = TL.call(t, name, args)
            env = json.loads(json.dumps(env, default=str))
            env.pop("took_ms", None)
            rec["calls"].append({"name": name, "args": args, "rid": env.get("rid"), "result": env})
        rec["limits"] = list(t.limits)
        done[tid] = (t, rec)
        out.append(rec)
    return out, done

if __name__ == "__main__":
    h = E.Harness.scratch(base=S + "/mvp25/check/_lib")
    out, done = run(h)
    json.dump(out, open(S + "/mvp25/check/results.json", "w"), indent=1, ensure_ascii=False)
    n = sum(len(r["calls"]) for r in out)
    errs = [(r["tid"], c["name"], c["args"], c["result"].get("error")) for r in out for c in r["calls"] if c["result"].get("is_error")]
    print("calls", n, "errors", len(errs))
    for e in errs: print(" ERR", e[0], e[1], json.dumps(e[2])[:120], "|", str(e[3])[:200])
