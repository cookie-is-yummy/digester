"""Run check/scripts/cases.py through the check tree's checker, cells and full, as a point under the turn's carrier
lead and alone as a lead. python3 run_cases.py [ids...]"""
import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, S + "/mvp25/check_tree/experiments"); sys.path.insert(0, HERE)
from mvp import eval_brain as E
from mvp.brain import verify as V
import probes as PR
import importlib
C = importlib.import_module(os.environ.get("CASES", "cases"))
h = E.Harness.scratch(base=S + "/mvp25/check/_lib_cases")
out, done = PR.run(h)
TURN = {}
for tid, (t, rec) in done.items():
    results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and not c["result"].get("is_error")}
    TURN[tid] = (results, V.Turn.of(t), t, rec)

def run(form, tid, mode, where):
    results, vt, _t, _r = TURN[tid]
    v = V.check_answer(form, results, vt, mode=mode)
    o = next(o for o in v.outcomes if o.where == where and o.index == 0)
    return {"kept": bool(o.kept), "reasons": list(o.reasons), "details": [str(d)[:160] for d in o.details][:3]}

if __name__ == "__main__":
    want = set(sys.argv[1:])
    carriers = {}
    for tid, lead in C.CARRIER.items():
        for mode in ("cells", "full"):
            carriers[f"{tid}|{mode}"] = run({"lead": lead, "points": []}, tid, mode, "lead")
    bad = [k for k, v in carriers.items() if not v["kept"]]
    print("carriers not kept:", bad, [carriers[k]["reasons"] for k in bad])
    rows = []
    for cid, tid, truth, fam, s, note in C.CASES:
        if want and cid not in want:
            continue
        row = {"id": cid, "tid": tid, "truth": truth, "family": fam, "text": s, "note": note}
        for mode in ("cells", "full"):
            row[f"P_{mode}"] = run({"lead": C.CARRIER[tid], "points": [s]}, tid, mode, "point")
            row[f"L_{mode}"] = run({"lead": s, "points": []}, tid, mode, "lead")
        rows.append(row)
    json.dump({"carriers": carriers, "rows": rows}, open(S + "/mvp25/check/cases_out.json", "w"), indent=1, ensure_ascii=False)
    for r in rows:
        def v(x):
            return "kept" if x["kept"] else ",".join(x["reasons"])
        print(f"{r['id']:5s} {r['truth']} {r['family']:14s} cells P={v(r['P_cells']):22.22s} L={v(r['L_cells']):22.22s} | full P={v(r['P_full']):18.18s} L={v(r['L_full']):18.18s} | {r['text'][:110]}")
