CARRIER = {"T01": "This summer you opened 45[r1.totals.items] videos, up from 16[r1.previous.items] last summer."}
CASES = [
 ("k1", "T01", "F", "cal", "This summer you opened 16[r1.previous.items] videos.", "known leak 25.14"),
 ("k2", "T01", "F", "cal", "Last summer you opened 45[r1.totals.items] videos.", "closed by seam fix"),
 ("k3", "T01", "T", "cal", "Pixel Pencil[r1.channels[0]] made 32[r1.channels[0].items] of them.", ""),
]
