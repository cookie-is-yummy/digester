import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
R = json.load(open(S + "/mvp25/check/results.json"))
for r in R:
    if sys.argv[1:] and r["tid"] not in sys.argv[1:]: continue
    print("#####", r["tid"], r["message"])
    for c in r["calls"]:
        env = c["result"]; rid = env.get("rid")
        if env.get("is_error") or "sheet" not in env: continue
        sh = env["sheet"]; m = env["meta"]; T = sh.get("totals") or {}; P = sh.get("previous") or {}
        print(f"== {rid} {c['name']} said={m.get('window_said')!r} dates={(m.get('window_dates') or {}).get('said')}")
        print(f"   totals items={T.get('items')} shorts={T.get('shorts')} long={T.get('long')} reels={T.get('reels')} yt={T.get('by_platform',{}).get('youtube')} ig={T.get('by_platform',{}).get('instagram')} days={T.get('days_active')} ss={T.get('shorts_share')}")
        if P: print(f"   previous {P.get('words')!r} items={P.get('items')} shorts={P.get('shorts')} long={P.get('long')}")
        for lst in ("areas", "themes", "channels"):
            if sh.get(lst): print(f"   {lst}: " + "; ".join(f"[{i}]{x['name']} {x.get('items')} {x.get('share')} prev={x.get('previous_items')} fw={x.get('first_watched')}" for i, x in enumerate(sh[lst][:6])))
        w = sh.get("when") or {}
        if w.get("parts_of_day"): print("   parts: " + "; ".join(f"[{i}]{p['part']} {p['events']} {p['share']}" for i, p in enumerate(w['parts_of_day'])))
        if w.get("busiest_hours"): print("   hours: " + "; ".join(f"[{i}]{p['hour']} {p['share']}" for i, p in enumerate(w['busiest_hours'])) + f" wk={w.get('weekday_share')} bw={w.get('busiest_weekday')}")
        for i, it in enumerate(sh.get("items") or []): print(f"   items[{i}] {it['title']!r} | {it['channel']} | {it.get('when')} | {it.get('how')} | {it.get('length')}")
        for i, p in enumerate(sh.get("periods") or []): print(f"   periods[{i}] {p['label']} {p['items']}", end="")
        if sh.get("periods"): print()
        for lst in ("new", "stopped"):
            for kk in ("themes", "channels"):
                if (sh.get(lst) or {}).get(kk): print(f"   {lst}.{kk}: " + "; ".join(f"[{i}]{x['name']} {x.get('items')} prev={x.get('previous_items')} fw={x.get('first_watched')}" for i, x in enumerate(sh[lst][kk])))
        if sh.get("library"): print("   library:", sh["library"])
