import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = S + "/mvp25/check_tree"
sys.path.insert(0, TREE + "/experiments")
from mvp import eval_brain as E
h = E.Harness.scratch(base=S + "/mvp25/check/_lib")
from mvp.brain import tools as TL
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
t = h.turn("how was this summer vs last summer?", search=FakeEngine(), learned=fake_learned)
r = TL.call(t, "compare", {"a": {"words": "this summer"}, "b": {"words": "last summer"}, "by": "channel"})
print(json.dumps(r, indent=1, default=str)[:6000])
