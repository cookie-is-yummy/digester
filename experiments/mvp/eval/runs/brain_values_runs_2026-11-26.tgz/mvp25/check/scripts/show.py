"""Compact view of results.json: python3 show.py [TID[:k]] ..."""
import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
R = json.load(open(S + "/mvp25/check/results.json"))
def flat(o, p=""):
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "ref": continue
            yield from flat(v, f"{p}.{k}" if p else k)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            yield from flat(v, f"{p}[{i}]")
    else:
        yield p, o
want = sys.argv[1:]
for r in R:
    for k, c in enumerate(r["calls"]):
        key = f"{r['tid']}:{k}"
        if want and r["tid"] not in want and key not in want: continue
        env = c["result"]
        print("=" * 30, key, env.get("rid"), c["name"], json.dumps(c["args"]))
        if env.get("is_error"):
            print(json.dumps(env, ensure_ascii=False)[:2500]); continue
        m = env.get("meta") or {}
        print("  said:", m.get("window_said"), "| dates:", m.get("window_dates"), "| b:", m.get("window_dates_b"), "| tie:", m.get("tie"), "| resolved:", m.get("resolved"), "| hidden:", m.get("hidden"))
        for n in m.get("notes") or []: print("  note:", n)
        sh = env.get("sheet") or {}
        for p, v in flat({k2: v2 for k2, v2 in sh.items() if k2 not in ("question", "filters", "window")}):
            print("   ", p, "=", v)
