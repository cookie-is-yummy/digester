"""The three extra checks: (1) a code lead never carries a model point in cells mode; (2) cards show only the items the
answer cited, with the right channel, date and event (against recount.py's rows); (3) nothing in a card or a code lead
is built from text in a title."""
import json, os, sys, re
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, S + "/mvp25/check_tree/experiments"); sys.path.insert(0, HERE)
from mvp import eval_brain as E
from mvp.brain import verify as V, loop as BL, fallback as FB, answer as A
import probes as PR, cases as C, recount as RC
h = E.Harness.scratch(base=S + "/mvp25/check/_lib_code")
out, done = PR.run(h)
CM = V.check_mode("cells")
def finish(tid, form, mode=CM):
    t, rec = done[tid]
    results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and not c["result"].get("is_error")}
    t.results = results
    vt = V.Turn.of(t)
    v = V.check_answer(form, results, vt, mode=mode)
    r2 = {"forms": [form]}
    BL._finish(r2, t, vt, [v], mode)
    return r2, v
# ---------------- (1) code lead and model points
bad, n, code_n = [], 0, 0
F_by = {}; T_by = {}
for cid, tid, truth, fam, s, note in C.CASES:
    (F_by if truth == "F" else T_by if truth == "T" else {}).setdefault(tid, []).append(s)
for tid in F_by:
    trues = T_by.get(tid, [])[:3]
    for s in F_by[tid] + ["Here is what I found."]:
        for pts in (trues, trues[:1], []):
            for mode in ("cells", "full"):
                r2, v = finish(tid, {"lead": s, "points": pts}, V.check_mode(mode))
                n += 1
                a = r2["answer"]
                if r2["lead_source"] in ("code", "plain"):
                    code_n += mode == "cells"
                    if mode == "cells" and (a["points"] or any(p in a["text"] for p in pts if p)):
                        bad.append((tid, s, pts, a["text"]))
print(f"(1) answers built: {n}; cells answers under a code or plain lead: {code_n}; of them carrying a model point: {len(bad)}")
for b in bad[:5]:
    print("   BAD", b)
# ---------------- (2) cards
def row_truth(row):
    it = RC.ITEM[row["item_id"]]
    day = row["when"][:10]
    kinds = sorted({e["kind"] for e in RC.EV if e["id"] == row["item_id"] and e["d"].isoformat() == day})
    return it["channel"], day, " and ".join(kinds)
card_bad, card_n, extra = [], 0, []
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        env = c["result"]
        if env.get("is_error") or not (env.get("sheet") or {}).get("items"):
            continue
        rid = env["rid"]; rows = env["sheet"]["items"]
        picks = [f"{rid}.items[{k}]" for k in range(0, len(rows), 2)]   # every other row
        lead = f"Here are some of them."
        form = {"lead": lead, "points": [], "items": [{"ref": p} for p in picks]}
        for mode in ("cells", "full"):
            r2, v = finish(tid, form, V.check_mode(mode))
            a = r2["answer"]
            got = [cd["ref"] for cd in a["cards"]]
            card_n += len(a["cards"])
            src = r2["lead_source"]
            want = picks if src.startswith("model") else [x for x in (r2["code_lead"] or {}).get("items") or []]
            if got != want[:len(got)] or (src.startswith("model") and set(got) - set(picks)):
                extra.append((tid, rid, mode, src, got, picks))
            for cd in a["cards"]:
                rr, k = re.match(r"(r\d+)\.items\[(\d+)\]", cd["ref"]).groups()
                allrows = {cc["result"]["rid"]: cc["result"]["sheet"].get("items") or [] for cc in rec["calls"]
                           if cc["result"].get("rid") and "sheet" in cc["result"]}
                row = allrows[rr][int(k)]
                ch, day, how = row_truth(row)
                prob = []
                if cd["channel"] != ch: prob.append(f"channel {cd['channel']} != {ch}")
                if (cd["when"] or "")[:10] != day: prob.append(f"date {cd['when']} != {day}")
                if cd["event"] != how: prob.append(f"event {cd['event']} != {how}")
                if not cd["url"] or RC.ITEM[row['item_id']]['platform'] not in cd["url"]: prob.append(f"link {cd['url']}")
                if prob:
                    card_bad.append((tid, rid, cd["ref"], cd["line"], prob))
print(f"(2) cards rendered: {card_n}; cards not among the cited items: {len(extra)}; cards with a wrong channel, date, event or link: {len(card_bad)}")
for x in extra[:6]: print("   EXTRA", x)
for x in card_bad[:10]: print("   BADCARD", x)
# ---------------- (3) titles are data: code leads and cards on the planted titles (T16, T08, T12)
TOK = re.compile(r"\{|\}|\[r\d|channels\(|999|rule|email|love|instruction", re.I)
print("(3) code leads and cards on turns whose rows hold planted titles:")
for tid in ("T16", "T08", "T12"):
    t, rec = done[tid]
    for c in rec["calls"]:
        env = c["result"]
        if env.get("is_error") or "sheet" not in env:
            continue
        rid = env["rid"]
        r2, v = finish(tid, {"lead": "Here is what I found in your history, all of it.", "points": []})   # a lead that fails
        r2, v = finish(tid, {"lead": f"zz[{rid}.totals.items]", "points": []})
        a = r2["answer"]; code = r2["code_lead"] or {}
        lead = code.get("lead") or ""
        hit_lead = TOK.findall(lead)
        cards = [cd["line"] for cd in a["cards"]]
        hit_cards = [ln for ln in cards if TOK.search(ln)]
        print(f"   {tid} {rid} {c['name']}: source={r2['lead_source']} lead={lead[:150]!r} tokens_in_lead={hit_lead}")
        for ln in hit_cards:
            print(f"      card with title text: {ln!r}")
# the model's own picks of the planted rows, rendered
for tid, ref in (("T16", "r1.items[0]"), ("T16", "r2.items[0]"), ("T16", "r3.items[4]"), ("T16", "r4.items[0]"), ("T08", "r1.items[0]")):
    r2, v = finish(tid, {"lead": "Here are the ones you asked about.", "points": [], "items": [{"ref": ref, "note": "999 views[r1.totals.items]"}]})
    a = r2["answer"]
    print(f"   pick {tid} {ref}: source={r2['lead_source']} cards={[cd['line'] for cd in a['cards']]} note_kept={[i.get('note') for i in v.items]}")
    print("      text:", a["text"].replace("\n", " / ")[:400])
