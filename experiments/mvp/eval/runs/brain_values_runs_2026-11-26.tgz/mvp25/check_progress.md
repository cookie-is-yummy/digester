# check progress
- step 0: brief read; worktree check_tree (brain-r25-check-local from brain-r25-local 0bd8720). Read DESIGN 24.8, 25.
- step 1: check/scripts/probes.py: 72 calls in 15 turns on the made-up library (results.json, deterministic). 5 refusals
  (Nov compare, first week of Oct, 2 liked, first_last other name in only) + 1 no_match (first_last sourdough).
- step 2: check/scripts/recount.py (imports only tests/brain_library rows): 66 results, 4539 fields recounted, 0 count
  differences. Structural findings: season-part previous windows mislabeled ("late summer of 2023" prev "the spring
  before (1 May to 31 July 2023)"; mid winter prev "the fall before (1 Oct-31 Dec)"; late spring prev "winter before (Feb-Apr)";
  end of summer prev "spring before (May-Jul)"); month-part prev "the 3 months before (1 July to 20 October)" = 112 d;
  part windows' previous of unequal length with no note; new themes without first_watched AND without the note on
  ranked sheets (this autumn, October, this year changes); busiest_weekday names one day of a tie (16 results);
  "early November" -> 21-30 Oct silently (cannot_see present); saved-only YouTube lengths "unknown" (enricher reads
  watched only); first_last 'sourdough' no_match with options [] and no pointer to search.
- NEXT: cases (claim 1) on these results.
- step 3: T16 (planted titles) added; 77 calls, 5 refusals, 1 no_match; recount 71 results, 5659 fields, 0 count diffs;
  recount2: windows = convention on every call (but the after-end substitutions); 28 window-before label/length findings.
- step 4: cases.py 104 false / 62 true (+1 excluded by the private convention). cells: 43 false out, 10 true refused;
  full: 7 false out, 42 true refused. Known families among the 43: g05 h02 (saved said opened, 25.12), a04 d23 ("this
  <season>", 25.14). 6 catches are accidental (twin true dropped by the same code).
- step 5: check_code.py: 0 of 183 cells code/plain leads carry a model point; 98 cards, 0 extra, 0 wrong; titles never
  expanded/read, but code leads quote titles unquoted; scope line falls back to the first result when the lead cites none.
- NEXT: report.txt, advisor, cleanup.
- step 6 (after advisor): masking twins m01-m07 (2 of 7 out), f07/f08 liked-on-saved (out in cells), T17 watch time;
  ask-back renders the cited (or first) result's cards, `between` unread (wrong result when the lead cites none);
  row-level note only on breakdowns; limit lines only under code leads, none for breakdown cuts. Classes by 24.3:
  31 cell (29 new, 3 tool-fed), 4 arguable, 12 framing. Final: 113 F / 69 T; cells 47 out, 10 refused; full 8 out, 43 refused.
  Recount 73 results, 7281 of 7811 leaves, 0 count differences. report.txt final. Scratch libs removed. DONE.
