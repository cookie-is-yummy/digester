"""How many true and false sentences of every set each cells rule engaged on (its inputs present), and how many it
dropped. In sample. Engaged: period_named a phrase bound to a cell; free_date a typed date beside a row with dates;
weekday_typed a weekday with a date; item_fields an item with a time, length or 'from <channel>' word; length_cell a
length cell or an 'all of them Shorts'; pairs_crossed two rows and two cells joined by 'and'."""
import os, re, sys
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V = M.V
eng = defaultdict(set)
cur = {"text": None}
real_cs = V.check_sentence


def wrap(name, fn, engaged):
    def w(*a, **k):
        if engaged(*a):
            eng[name].add(" ".join(str(cur["text"]).split()))
        return fn(*a, **k)
    return w


def cs(sentence, *a, **k):
    cur["text"] = sentence
    return real_cs(sentence, *a, **k)


def pn_eng(raw, markers, res, ledger, turn):
    if res is None or not res.is_sheet:
        return False
    c = V._cell_anchors(markers, res)
    return bool(c) and bool(V._PHRASE.search(V.strip_markers(raw)) or V._SAME_PART.search(raw))


def fd_eng(raw, markers, res, ledger):
    return res is not None and res.is_sheet and bool(V._row_days(res, markers)) and bool(V._typed_dates(raw, markers, res))


def it_eng(raw, markers, res):
    if res is None or not res.is_sheet or not V._cited_items(markers, res):
        return False
    low = V.strip_markers(raw).lower()
    return any(w in V.I._TIME_WORD for w in re.findall(r"[a-z]+", low)) or bool(V._LENGTH_SAID.search(low)) or \
        bool(re.search(r"\b(?:from|by)\s+[A-Z@]", V.strip_markers(raw)))


def lc_eng(raw, markers, res):
    return res is not None and res.is_sheet and (any(mk.kind == "value" and V._segs(mk.rest)[-1][0] in V._SHORTS_KEYS + V._LONG_KEYS for mk in markers) or bool(V._ALL_LEN.search(raw)))


def pc_eng(raw, markers):
    return len([m for m in markers if m.kind == "row"]) == 2 and len([m for m in markers if m.kind == "value"]) == 2 and " and " in raw


V.check_sentence = cs
V._period_named = wrap("period_named", V._period_named, pn_eng)
V._free_date = wrap("free_date", V._free_date, fd_eng)
V._typed_weekday = wrap("weekday_typed", V._typed_weekday, lambda raw: bool(V._WD_DATE.search(V.strip_markers(raw))))
V._item_fields = wrap("item_fields", V._item_fields, it_eng)
V._length_cell = wrap("length_cell", V._length_cell, lc_eng)
V._pairs_crossed = wrap("pairs_crossed", V._pairs_crossed, pc_eng)
cm = M.mode_from("cells")
res, rows = M.measure(cm)
V.check_sentence = real_cs
truth = defaultdict(set)
for r in rows["run1"] + rows["looks"]:
    if r["truth"] in ("T", "F"):
        truth[" ".join(r["text"].split())].add((r["set"], r["truth"]))
for r in rows["a2"]:
    truth[" ".join(r["text"].split())].add(("attack2", r["truth"]))
data = M.P.load()
for c in data["cases"]:
    for f in c.get("forms") or [c["form"]]:
        for s in [f.get("lead") or ""] + list(f.get("points") or []):
            pass
    tg = c.get("target") or "point:0"
    for f in c.get("forms") or [c["form"]]:
        if tg.startswith("lead"):
            txt = f.get("lead") or ""
        elif tg.startswith("point"):
            pts = f.get("points") or []
            k = int(tg.split(":")[1] or 0)
            txt = pts[k] if k < len(pts) else ""
        else:
            txt = ""
        for s_ in re.split(r"(?<=[.!?])\s+(?=[A-Z])", txt) if txt else []:
            truth[" ".join(s_.split())].add(("planted", "T" if c["expect"] == "kept" else "F"))
for name, texts in eng.items():
    c = Counter()
    for t in texts:
        for st, tr in truth.get(t, {("unlabelled", "?")}):
            c[(st, tr)] += 1
    print(name, dict(sorted(c.items())))
