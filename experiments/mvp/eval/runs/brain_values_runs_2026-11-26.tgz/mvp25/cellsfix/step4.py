"""Step 4: what limits and repeat would drop in cells mode on run1 and the two looks (every form). For each variant,
the sentences kept by today's cells mode and dropped with the code on, by set, with the answer's question."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V = M.V
VARIANTS = {"limits@words": "cells+on:limits+off:limits@self+off:limits@insight",
            "limits@self": "cells+on:limits+off:limits@words+off:limits@insight",
            "limits@insight": "cells+on:limits+off:limits@words+off:limits@self",
            "repeat@once": "cells+on:repeat+off:repeat@insight",
            "repeat@insight": "cells+on:repeat+off:repeat@once"}


def rows(mode):
    return {f"{r['set']}:{r['id']}": r for r in M.run_run1(mode) + M.L.run_looks(V, mode)}


base = rows(M.mode_from("cells"))
msgs = {}
for rec, t, res in M.run1_inputs():
    msgs[("run1", rec["key"])] = rec["message"]
for look, rec, t, res in M.L.look_inputs():
    msgs[(look, rec["key"])] = rec["message"]
out = {}
for name, spec in VARIANTS.items():
    cm = M.mode_from(spec)
    got = rows(cm)
    new = []
    for k, r in got.items():
        b = base.get(k)
        if b and b["kept"] and not r["kept"]:
            new.append({"id": k, "set": r["set"], "key": r["key"], "form": r["form_index"], "where": r["where"],
                        "truth": r["truth"], "reasons": r["reasons"], "text": V.strip_markers(r["text"]),
                        "question": msgs.get((r["set"], r["key"]))})
    out[name] = new
    print(f"== {name}: {len(new)} newly dropped")
    for x in new:
        print(f"  {x['id']} [{x['truth']}] {x['reasons']} Q: {x['question']!r}\n      | {x['text']}")
json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "step4.json"), "w"), indent=1)
