"""For every sentence of every set in cells mode whose first insight reason is off: the reason the walk reaches."""
import sys, os, json
from collections import Counter, defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V = M.V
cm = M.mode_from("cells-r:insight_walk")  # the census reruns the walk itself
skip = V._insight_skip(V.CELLS)
seen = {}
real = V.insight_check


def spy(raw, markers, plain_names, cited_names, res, where, unlock=None, skip=frozenset(), loose=frozenset()):
    a = real(raw, markers, plain_names, cited_names, res, where, unlock, loose=loose)
    if a and V.CELLS.is_off(a[0], "insight") and not skip:
        b = real(raw, markers, plain_names, cited_names, res, where, unlock, skip=V._insight_skip(V.CELLS), loose=loose)
        seen[" ".join(raw.split())] = (a[0], b[0] if b else None)
    return a


V.insight_check = spy
res, rows = M.measure(cm)
ids = M.per_id(cm, rows)
V.insight_check = real
# truth by text
truth = defaultdict(set)
for r in rows["run1"] + rows["looks"]:
    if r["truth"] in ("T", "F"):
        truth[" ".join(r["text"].split())].add(r["truth"])
for r in rows["a2"]:
    truth[" ".join(r["text"].split())].add(r["truth"])
data = M.P.load()
for c in data["cases"]:
    for f in c.get("forms") or [c["form"]]:
        tg = c.get("target") or "point:0"
        txt = f.get("lead") if tg.startswith("lead") else (f.get("points") or [""])[int(tg.split(":")[1] or 0)] if tg.startswith("point") else ""
        if txt:
            truth[" ".join(txt.split())].add("T" if c["expect"] == "kept" else "F")
cnt = Counter()
for txt, (a, b) in seen.items():
    t = "/".join(sorted(truth.get(txt, {"?"})))
    cnt[(b, t)] += 1
for (b, t), n in sorted(cnt.items(), key=lambda x: (str(x[0][0]), x[0][1])):
    print(f"{str(b):24s} {t:4s} {n}")
json.dump({k: v for k, v in seen.items()}, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "walk_census.json"), "w"), indent=0)
