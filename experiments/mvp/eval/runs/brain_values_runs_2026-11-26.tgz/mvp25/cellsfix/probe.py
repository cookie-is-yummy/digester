"""probe.py MODE id [id...] : each attack2 case as point and lead, reasons and details. MODE full|cells."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V = M.V
mode = sys.argv[1]
d = M.a2()
by = {c["id"]: c for c in d["cases"]}
for cid in sys.argv[2:]:
    c = by[cid]
    led, turn, car = d["ledgers"][c["record"]], M.a2_turn(d["turns"][c["record"]]), d["carriers"][c["record"]]
    print(f"== {cid} {c['truth']} {c['family']} [{c['record']}] {c['text']}  ({c['note']})")
    for where, form in (("P", {"lead": car, "points": [c["text"]]}), ("L", {"lead": c["text"], "points": []})):
        v = V.check_answer(form, led, turn, mode=mode)
        for o in v.outcomes:
            if (where == "P") == (o.where == "point"):
                print(f"   {where} kept={o.kept} {o.reasons} {[x[:150] for x in o.details][:3]} notes={ {k: str(v)[:80] for k, v in (o.notes or {}).items()} }")
