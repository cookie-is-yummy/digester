"""twin.py MODE REC 'sentence' ...: each sentence as a point under REC's carrier and alone as a lead (attack2 ledgers)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V = M.V
mode = M.mode_from(sys.argv[1])
rec = sys.argv[2]
d = M.a2()
led, turn, car = d["ledgers"][rec], M.a2_turn(d["turns"][rec]), d["carriers"][rec]
for s in sys.argv[3:]:
    vp = V.check_answer({"lead": car, "points": [s]}, led, turn, mode=mode)
    op = next(o for o in vp.outcomes if o.where == "point")
    vl = V.check_answer({"lead": s, "points": []}, led, turn, mode=mode)
    ol = [o for o in vl.outcomes if o.where == "lead"]
    print(f"P {op.kept} {op.reasons} | L {all(o.kept for o in ol)} {sorted({r for o in ol for r in o.reasons})} | {s}")
