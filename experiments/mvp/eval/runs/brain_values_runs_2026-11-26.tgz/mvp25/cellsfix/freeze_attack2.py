"""Freeze the mvp24 pincheck attack (131 false, 46 true new sentences) into experiments/mvp/eval/brain_cells_attack2.json:
each case with its carrier lead, its record's results (the ledger) and the verifier's turn fields. Made-up library only."""
import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = os.path.join(S, "mvp24/pin_tree")
sys.path.insert(0, os.path.join(TREE, "experiments"))
sys.path.insert(0, os.path.join(S, "mvp24/pincheck/scripts"))
from mvp.brain import verify as V
from mvp import eval_brain as E
import cases as C
h = E.Harness.scratch(base=os.path.join(S, "mvp25/cellsfix/_lib_freeze"))
ledgers, turns = {}, {}
for key in C.CARRIER:
    rec = json.load(open(os.path.join(S, "mvp20/tune/heldout", key + ".json")))
    t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
    ledgers[key] = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                    and not c["result"].get("is_error")}
    vt = V.Turn.of(t)
    turns[key] = {"message": vt.message, "unlock": vt.unlock, "screen": vt.screen,
                  "today": vt.today.isoformat() if vt.today else None, "names": vt.names,
                  "sensitive_names": vt.sensitive_names}
out = json.load(open(os.path.join(S, "mvp24/pincheck/cases_out.json")))
by = {r["id"]: r for r in out["rows"]}
cases = []
for cid, key, truth, kind, s, note in C.CASES:
    r = by[cid]
    assert r["text"] == s and r["truth"] == truth
    cases.append({"id": cid, "record": key, "truth": truth, "family": kind, "text": s, "note": note,
                  "mvp24_cells": {"point_kept": r["P_cells"]["kept"], "lead_kept": r["L_cells"]["kept"]},
                  "mvp24_full": {"point_kept": r["P_full"]["kept"], "lead_kept": r["L_full"]["kept"]}})
doc = {"about": ("mvp24 pincheck: an independent attacker's new sentences on 8 saved held-out tool results of the made-up "
                 "library (tests/brain_library.py). Each sentence runs as a point under its record's true carrier lead "
                 "and alone as a lead; a false case is handled when it is dropped both ways, a true case kept when kept "
                 "both ways. 'family' is the attacker's kind. 'mvp24_cells' / 'mvp24_full': what the checker did at "
                 "4064f3e (the attacker's run). Frozen by mvp25 cellsfix; the known leaks are pinned in "
                 "tests/test_brain_cells.py and listed in 'known_leaks'."),
       "carriers": C.CARRIER, "turns": turns, "ledgers": ledgers, "cases": cases, "known_leaks": {}}
p = os.path.join(TREE, "experiments/mvp/eval/brain_cells_attack2.json")
json.dump(doc, open(p, "w", encoding="utf-8"), indent=1, ensure_ascii=False, sort_keys=False)
print(p, len(cases), sum(c["truth"] == "F" for c in cases), sum(c["truth"] == "T" for c in cases), os.path.getsize(p))
