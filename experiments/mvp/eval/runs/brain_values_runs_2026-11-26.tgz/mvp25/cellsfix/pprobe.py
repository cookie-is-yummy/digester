"""pprobe.py MODE id...: a planted case, every form, the target's outcome with details."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import m as M
V, P = M.V, M.P
mode = M.mode_from(sys.argv[1])
data = P.load()
by = {c["id"]: c for c in data["cases"]}
for cid in sys.argv[2:]:
    c = by[cid]
    print(f"== {cid} {c.get('source')} {c['expect']} target={c.get('target')} ledger={c['ledger']}")
    for f in c.get("forms") or [c["form"]]:
        print("   form:", json.dumps(f)[:400])
        kept, reasons, v = P.outcome(dict(c, form=f, forms=None), data["ledgers"], mode)
        print("   kept", kept, reasons, [ (o.where, o.index, o.kept, o.reasons, [d[:120] for d in o.details][:2], o.notes.get('insight_off')) for o in v.outcomes])
