"""mvp24 (DESIGN.md section 24): the pinned cells-only checker mode of brain/verify.py.

"cells" checks the cells only (numbers, names, dates, calculations, what each number is bound to), the policy lines
and the marker grammar; every framing rule is off at the source. "full" (the default) is today's checker. The mode is
chosen by an argument or by MVP_BRAIN_CHECK. Made-up library and planted ledgers only; no model call.
"""
import hashlib
import json
import os
import sys
from datetime import date

import pytest

HERE = os.path.dirname(os.path.abspath(__file__))
MVP = os.path.dirname(HERE)
sys.path.insert(0, os.path.dirname(MVP))
from mvp.brain import answer as A  # noqa: E402
from mvp.brain import fallback as FB  # noqa: E402
from mvp.brain import planted as P  # noqa: E402
from mvp.brain import verify as V  # noqa: E402
from mvp.tests.test_mvp import env  # noqa: E402,F401  (env is a fixture)
from mvp.tests.test_brain_tools import NOW, brain, built, no_real_keys, person  # noqa: E402,F401  (fixtures)
from mvp.tests.test_brain_slice import (  # noqa: E402,F401  (fixture and helpers)
    FALSE_LEAD, TRUE_LEAD, TRUE_POINT, bd, ga, harness, no_marker, run)


def _h(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest()


# ================================================================ the pin
# The codes OFF in cells mode, the codes ON, the loosenings, the framing-listed rule kept on, the doubtful codes'
# decisions and the frozen class of every planted false case. Changing any of them is a decision: DESIGN 24.2.
PIN_OFF = "024c3b0fc661c7851f035a17b79d9e5605e00aeaea79a53b0e9319e46f2e63d6"
PIN_ON = "9b27936068d4d1af941a7aeb10ced10147e1054aef9e2d009f04cab0f440b657"
PIN_LOOSE = "33ff046231e307ec2fe02bf64c47e4e1dd066caf409f99012d0cf9586cee406a"
PIN_KEPT = "22d78bacbfac1875b7de193d0ecf3a841a596fc0569e58bf01d1268aafc6d97b"
PIN_DOUBT = "ad70810d9ee3cb624d19b23ec1f48e5326701f220eeb7f950c2ebd75a349a97b"
PIN_CLASSES = "34bdceae77eb6ae451e1a640c9ae1d9ba46f0278b82a918e16ec30e9441760b1"
ON_CODES = [
    "about_not_cited", "bad_marker", "bad_path", "bad_ref", "bad_value", "bound", "bound_to_other", "calc",
    "channel_not_in_theme", "count_as_share", "count_of_videos", "date", "direction@calc", "direction@from_to",
    "direction@insight", "direction@sign", "empty", "filler", "fraction", "free_number", "garbled", "generic_claim",
    "insight_error", "language", "link", "made_up_difference", "marker", "median_of_window", "month", "name",
    "not_item", "number", "number_word", "other_name", "outcome", "outside_in_history", "point_text", "psych",
    "quote", "ratio", "second_person", "sensitive", "shorts_as_long", "source", "too_long", "too_many",
    "two_results", "typed_name", "uncited_claim@nomarker", "uncited_name", "uncited_number", "unknown_name",
    "unnamed_owner", "watch_time", "weak_fit", "weekday", "word", "wrong_area", "wrong_group", "wrong_measure",
    "wrong_name", "wrong_value"]


def _known():
    return V.CELL_CODES | V.POLICY_CODES | V.FRAMING_CODES | set(V.DOUBT_CODES)


def test_the_codes_on_and_off_in_cells_mode_are_pinned():
    on = sorted(c for c in _known() if not V.CELLS.is_off(c))
    assert on == ON_CODES
    assert _h(on) == PIN_ON
    assert _h(sorted(V.CELLS.off)) == PIN_OFF
    assert _h(sorted(V.CELLS.loose)) == PIN_LOOSE
    assert _h(sorted(V.FRAMING_KEPT)) == PIN_KEPT
    assert _h(V.DOUBT_CODES) == PIN_DOUBT
    with open(os.path.join(MVP, "eval", "brain_cells_classes.json"), "rb") as f:
        assert hashlib.sha256(f.read()).hexdigest() == PIN_CLASSES


def test_the_code_lists_are_disjoint_and_every_framing_code_but_the_kept_one_is_off():
    assert not (V.CELL_CODES & V.POLICY_CODES) and not (V.CELL_CODES & V.FRAMING_CODES)
    assert not (V.POLICY_CODES & V.FRAMING_CODES)
    for c in V.FRAMING_CODES - set(V.FRAMING_KEPT):
        assert V.CELLS.is_off(c), c
    for c in V.CELL_CODES | V.POLICY_CODES:
        assert not V.CELLS.is_off(c), c
    assert set(V.FRAMING_KEPT) == {"weekday"} and V.CELLS.loose == {"title_quote", "item_channel", "short_word",
                                                                    "platform_all"}
    assert not V.FULL.off and not V.FULL.loose and not V.FULL.cells


# ================================================================ choosing the mode
def test_the_mode_comes_from_the_argument_then_the_environment_then_full(monkeypatch):
    monkeypatch.delenv(V.CHECK_ENV, raising=False)
    assert V.check_mode() is V.FULL and V.check_mode("cells") is V.CELLS and V.check_mode(" Full ") is V.FULL
    monkeypatch.setenv(V.CHECK_ENV, "cells")
    assert V.check_mode() is V.CELLS and V.check_mode("full") is V.FULL
    monkeypatch.setenv(V.CHECK_ENV, "loose")
    with pytest.raises(ValueError):
        V.check_mode()
    with pytest.raises(ValueError):
        V.check_mode("framing")


# ================================================================ the planted lines
def _cases():
    return {c["id"]: c for c in P.load()["cases"]}


def _turn(c):
    t = c.get("turn") or {}
    return V.Turn(message=t.get("message", ""), unlock=t.get("unlock"),
                  today=date.fromisoformat(t["today"]) if t.get("today") else None, names=list(t.get("names") or []),
                  sensitive_names=list(t.get("sensitive_names") or []))


def test_full_mode_keeps_todays_planted_line(monkeypatch):
    monkeypatch.delenv(V.CHECK_ENV, raising=False)
    s = P.score()
    assert (s["false"], s["false_dropped"], s["false_dropped_expected"], s["true"], s["true_kept"]) == \
        (332, 332, 332, 78, 78)
    b = s["by_source"]
    assert (b["attack"]["false"], b["attack"]["false_dropped"]) == (169, 169)
    assert b["attack_true"]["true_kept"] == 41 and b["audit_true"]["true_kept"] == 49


def test_the_cells_planted_line_handles_every_cell_class_case_and_keeps_every_true_one():
    s = P.score_cells(mode="cells")
    assert s["ok"] and s["cell_out"] == [] and (s["true"], s["true_kept"]) == (78, 78)
    got = {src: {k: (x["false"], x["handled"], x["kept_under_private_line"], x["out"])
                 for k, x in b.items() if isinstance(x, dict)} for src, b in s["by_source"].items()}
    assert got["new"] == {"cell": (42, 42, 0, 0), "policy": (14, 12, 0, 2), "framing": (36, 6, 0, 30)}
    assert got["audit"] == {"cell": (54, 54, 0, 0), "policy": (14, 13, 0, 1), "framing": (69, 14, 2, 55)}
    assert got["insight_v5"] == {"cell": (19, 19, 0, 0), "policy": (1, 1, 0, 0), "framing": (83, 19, 0, 64)}
    # the attack counted by case (a case placed both as a lead and as a point is one case)
    assert got["attack"] == {"cell": (30, 30, 0, 0), "policy": (11, 11, 0, 0), "framing": (125, 29, 8, 96)}
    assert s["by_source"]["attack_true"]["true_kept"] == 52 and s["by_source"]["audit_true"]["true_kept"] == 56


def test_the_planted_command_takes_the_mode_and_fails_on_a_cell_class_case(monkeypatch, capsys):
    assert P.main(["--check", "cells"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["check"] == "cells" and out["ok"]
    real = P.classes()
    monkeypatch.setattr(P, "classes", lambda path=None: dict(real, attack_A01={"class": "cell"}))
    assert P.main(["--check", "cells"]) == 1   # attack_A01 (a framing case cells mode lets out) read as cell
    assert json.loads(capsys.readouterr().out)["cell_out"] == ["attack_A01"]


def test_no_code_that_is_off_reaches_a_cells_mode_outcome():
    data = P.load()
    seen = set()
    for c in data["cases"]:
        for f in c.get("forms") or [c["form"]]:
            v = V.check_answer(f, V.Ledger(data["ledgers"][c["ledger"]]), _turn(c), mode="cells")
            for o in v.outcomes:
                seen |= set(o.reasons)
                assert not any(V.CELLS.is_off(r) for r in o.reasons), (c["id"], o.reasons)
            for it in v.items:
                assert not any(V.CELLS.is_off(r) for r in it["reasons"]), (c["id"], it["reasons"])
    unknown = {r.split(":")[0] for r in seen} - {k.split("@")[0] for k in _known()}
    assert not unknown, unknown


def test_every_code_full_mode_gives_on_the_planted_set_has_a_class():
    data = P.load()
    seen = set()
    for c in data["cases"]:
        for f in c.get("forms") or [c["form"]]:
            v = V.check_answer(f, V.Ledger(data["ledgers"][c["ledger"]]), _turn(c), mode="full")
            seen |= {r.split(":")[0] for o in v.outcomes for r in o.reasons}
    assert not seen - {k.split("@")[0] for k in _known()}, seen - {k.split("@")[0] for k in _known()}


# ================================================================ what cells mode does, sentence by sentence
def _point(cid, sentence, mode):
    c = _cases()[cid]
    f0 = (c.get("forms") or [c["form"]])[0]
    data = P.load()
    v = V.check_answer({"lead": f0.get("lead") or "", "points": [sentence]}, V.Ledger(data["ledgers"][c["ledger"]]),
                       _turn(c), mode=mode)
    o = [o for o in v.outcomes if o.where == "point"][0]
    return o.kept, o.reasons


def test_c1_a_change_of_one_row_now_against_another_row_before_is_a_cell_fault():
    # the attack's V05, the one cell-class sentence the record table showed getting out of cells only ("C1")
    bad = ("Gaming[r1.areas[0]] rose 29 points[=points(r1.areas[0].share, r1.areas[2].previous_share)] on last "
           "autumn, more than food and cooking[r1.areas[2]].")
    assert _point("attack_V05", bad, "cells") == (False, ["calc"])
    assert not _point("attack_V05", bad, "full")[0]
    twin = "Gaming[r1.areas[0]] rose 42 points[=points(r1.areas[0].share, r1.areas[0].previous_share)] on last autumn."
    assert _point("attack_V05", twin, "cells") == (True, [])


def test_a_row_said_now_in_one_measure_and_before_in_another_is_refused():
    bad = ("Speed runs[r1.themes[1]] climbed to 9%[r1.themes[1].share] from 27[r1.themes[1].previous_items] videos "
           "before.")
    assert _point("v5_112", bad, "cells") == (False, ["wrong_measure"])
    twin = "Speed runs[r1.themes[1]] climbed to 9%[r1.themes[1].share] from 3%[r1.themes[1].previous_share]."
    assert _point("v5_112", twin, "cells") == (True, [])
    # the window's own totals and previous cells may be said apart
    apart = "You opened 1000[r1.totals.items] videos; Shorts were 68%[r1.previous.shorts_share] of them before."
    assert _point("v5_112", apart, "cells")[0]


def test_the_windows_median_said_of_a_row_is_refused_whatever_insight_says_first():
    bad = ("Speed runs[r1.themes[1]] led on 18[r1.themes[1].days] days, and its long videos ran about "
           "23[r1.totals.long_median_min] minutes.")
    assert _point("v5_054", bad, "cells") == (False, ["median_of_window"])
    assert _point("v5_054", "Your long videos ran about 23[r1.totals.long_median_min] minutes.", "cells") == (True, [])


def test_now_in_the_from_slot_a_typed_sign_and_a_wrong_weekday_of_a_date_stay_refused():
    swapped = ("Clip Factory[r1.channels[0]] went from 13[r1.channels[0].items] videos the week before to "
               "14[r1.channels[0].previous_items] in the last 7 days.")
    assert _point("attack_X02", swapped, "cells") == (False, ["direction"])
    right = ("Clip Factory[r1.channels[0]] went from 14[r1.channels[0].previous_items] videos the week before to "
             "13[r1.channels[0].items] in the last 7 days.")
    assert _point("attack_X02", right, "cells") == (True, [])
    assert not _point("f_sign", _cases()["f_sign"]["form"]["points"][0], "cells")[0]
    sunday = ("Your first Clip Factory video was Funniest gaming fail[r1.items[0]], on 1 October 2026[r1.items[0].when], "
              "a Sunday.")
    assert _point("attack_Q01", sunday, "cells") == (False, ["weekday"])


def test_a_framing_fault_goes_out_in_cells_mode_and_not_in_full():
    s = "Clip Factory[r1.channels[0]] made 61[r1.channels[0].items] of your long videos."
    assert _point("attack_A01", s, "full") == (False, ["length_word"])
    assert _point("attack_A01", s, "cells") == (True, [])


def test_the_loosenings_let_a_title_in_quotes_and_a_short_stand_before_an_items_marker():
    quoted = 'Your first Clip Factory video was "Funniest gaming fail"[r1.items[0]].'
    assert not _point("attack_Q01", quoted, "full")[0] and _point("attack_Q01", quoted, "cells") == (True, [])
    short = "You opened a short[r1.items[0]] on 1 October 2026[r1.items[0].when]."
    assert not _point("attack_Q01", short, "full")[0] and _point("attack_Q01", short, "cells") == (True, [])


# compound probes: a binding fault with a framing word added. Insight stops at its first reason, so a framing reason
# that is off can hide its binding reason; p16 and p19 are the two holes that shows (DESIGN 24.3), pinned as holes
PROBES = [
    ("f_under_other_name", "Pan Theory[r1.channels[1]] led with 56[r1.channels[0].items] videos.", False),
    ("f_under_other_name", "Mostly Pan Theory[r1.channels[1]], with 56[r1.channels[0].items] videos.", False),
    ("audit_F03", "Gaming clips[r1.themes[0]] led, at 51%[r1.areas[0].share] of what you opened.", False),
    ("audit_F83c", "In 2022, your biggest year, you opened 134[r1.periods[0].items] videos.", False),
    ("audit_F84", "Lately, in October 2026, you opened 44[r1.periods[8].items] videos.", False),
    ("v5_016", "Prime Number Club[r1.channels[1]] came on 140[r1.channels[0].days] days, the most of any channel.",
     False),
    ("v5_054", "Lately Speed runs[r1.themes[1]] was your top theme; its long videos ran about "
               "23[r1.totals.long_median_min] minutes.", False),
    ("v5_056", "Meme drops[r1.themes[0]] led and leaned long-form at 69%[r1.themes[0].shorts_share].", False),
    ("attack_P03", "Pan Theory[r1.channels[1]] and Pixel Pencil[r1.channels[2]] together led, at "
                   "43%[r1.channels[0].share] of what you opened.", False),
    # the holes: kept in cells mode (full mode drops them, by the framing reason)
    ("v5_051", "gaming[r1.areas[0]] led at 22%[r1.areas[0].share], mostly Meme drops[r1.themes[0]].", True),
    ("v5_056", "Meme drops[r1.themes[0]] was mostly long-form at 69%[r1.themes[0].shorts_share].", True),
]


@pytest.mark.parametrize("cid,sentence,hole", PROBES)
def test_compound_probes_of_a_binding_fault(cid, sentence, hole):
    assert not _point(cid, sentence, "full")[0]
    assert _point(cid, sentence, "cells")[0] is hole


# ================================================================ the skeptic's and the record checker's cases
def _extra():
    with open(os.path.join(MVP, "eval", "brain_cells_extra.json"), encoding="utf-8") as f:
        return json.load(f)


def _extra_kept(e, ledgers, mode):
    t = dict(e["turn"])
    t["today"] = date.fromisoformat(t["today"]) if t.get("today") else None
    v = V.check_answer(e["form"], ledgers[e["ledger"]], V.Turn(**t), mode=mode)
    os_ = [o for o in v.outcomes if o.where == "lead"] if e["where"] == "L" else \
        [o for o in v.outcomes if (o.where, o.index) == ("point", 0)]
    return bool(os_) and all(o.kept for o in os_)


def test_the_skeptics_and_the_record_checkers_cell_class_cases():
    d = _extra()
    for e in d["cases"]:
        assert _extra_kept(e, d["ledgers"], "full") is e["kept_full"], e["id"]
        assert _extra_kept(e, d["ledgers"], "cells") is e["kept_cells"], e["id"]
        if e["class"] == "cell" and e["id"] != "K37":
            assert not e["kept_cells"], e["id"]
    k37 = next(e for e in d["cases"] if e["id"] == "K37")
    # the one cell-class case of the four sets cells mode does not handle (arguable: a length scope), and full mode
    # does not handle it either: "Your Shorts ran 10[r1.totals.long_median_min] minutes at the median"
    assert k37["kept_cells"] and k37["kept_full"] and k37["arguable"] == "framing"
    cells = {e["id"] for e in d["cases"] if e["class"] == "cell"}
    assert cells == {"K03", "K30", "K37", "K39", "K45", "K46", "N24", "N25", "N33"}


# ================================================================ the answer: a code lead carries no model point
def _code_lead_case(harness):
    from mvp.brain import verify as V_
    rec, _p, t = run(harness, [[bd()], [ga(FALSE_LEAD, [TRUE_POINT])], [ga(FALSE_LEAD, [TRUE_POINT])]], check="cells")
    return rec, t, V_


def test_in_cells_mode_a_code_lead_goes_out_with_no_point_of_the_models(harness):
    rec, t, _v = _code_lead_case(harness)
    assert rec["check"] == "cells" and rec["lead_source"] == "code"
    want = FB.code_lead(t.results, turn=V.Turn.of(t))
    assert rec["answer"]["lead"] == want["lead"] and rec["answer"]["points"] == []
    assert rec["sentences"]["kept_sent"] == 0 and no_marker(rec["answer"]["text"])
    assert all(v["outcomes"] is not None for v in rec["verdicts"])
    # full mode, the same script: the point that passed rides on the code lead, as today
    rec2, _p, _t = run(harness, [[bd()], [ga(FALSE_LEAD, [TRUE_POINT])], [ga(FALSE_LEAD, [TRUE_POINT])]], check="full")
    assert rec2["check"] == "full" and rec2["answer"]["points"] == ["Pan Theory came next with 32 videos."]


def test_the_turn_reads_the_environment_once_and_writes_its_mode(harness, monkeypatch):
    monkeypatch.setenv(V.CHECK_ENV, "cells")
    rec, _p, _t = run(harness, [[bd()], [ga(TRUE_LEAD, [TRUE_POINT])]])
    assert rec["check"] == "cells" and rec["lead_source"] == "model"
    monkeypatch.delenv(V.CHECK_ENV)
    rec, _p, _t = run(harness, [[bd()], [ga(TRUE_LEAD, [TRUE_POINT])]])
    assert rec["check"] == "full"


def test_answer_build_and_fallback_answer_drop_the_models_points_in_cells_mode(harness):
    rec, t, _v = _code_lead_case(harness)
    led = V.Ledger(t.results)
    vt = V.Turn.of(t)
    v1 = V.check_answer({"lead": FALSE_LEAD, "points": [TRUE_POINT]}, led, vt, mode="cells")
    assert not v1.lead_ok and [o.kept for o in v1.outcomes if o.where == "point"] == [True]
    assert FB.answer(led, v1, vt, mode="cells")["points"] == []
    assert FB.answer(led, v1, vt, mode="full")["points"] == ["Pan Theory came next with 32 videos."]
    code = dict(FB.code_lead(led, v1, vt), points=["Pan Theory came next with 32 videos."])
    assert A.build(led, code=code, mode="cells")["points"] == []
    assert A.build(led, code=code, mode="full")["points"] == ["Pan Theory came next with 32 videos."]


def test_codes_own_template_lead_is_checked_with_every_rule(harness, monkeypatch):
    rec, t, _v = _code_lead_case(harness)
    seen = []
    real = V.check_answer

    def spy(form, ledger, turn=None, mode=None):
        seen.append(mode)
        return real(form, ledger, turn, mode=mode)
    monkeypatch.setattr(V, "check_answer", spy)
    monkeypatch.setattr(FB, "_from_code_form", lambda res: None)   # the template path (code_form has no check)
    lead = FB.code_lead(t.results, turn=V.Turn.of(t))
    assert lead["how"] == "template" and seen and set(seen) == {"full"}


# ================================================================ the eval: the mode in every record and summary
def test_the_eval_summary_says_the_mode(harness):
    from mvp import eval_brain as E
    recs = []
    for check in ("cells", "cells"):
        rec, _p, _t = run(harness, [[bd()], [ga(TRUE_LEAD, [TRUE_POINT])]], check=check)
        rec.update(id="X", n=len(recs), key=f"X.{len(recs)}", g2={"verdict": "understood"},
                   audit={"findings": [], "checked": 0}, reading_errors=[], reading_window_failed=[],
                   dropped=E.dropped_of(rec))
        recs.append(rec)
    assert E.summarize(recs, {"check": "cells"})["check"] == "cells"
    assert E.summarize(recs)["check"] == "cells"
    recs[1]["check"] = "full"
    assert E.summarize(recs)["check"] == ["cells", "full"]
