# runs3 (mvp26) progress
- worktree: S/mvp26/runs3_tree, branch brain-values-run-local at brain-values-local 16cd906. No code change, no commit.
- evidence: S/mvp26/runs3/
- step 0: brief read; worktree made.
- step 1 smoke: next (S/mvp26/runs3/smoke, --limit 3, --max-usd 0.05)
- step 1 smoke DONE: S/mvp26/runs3/smoke, 3 msgs (N001.0, N001.1, N002.0), check=values in records/settings, flags logged, leads model x3, 10/10 kept, $0.007805.
- step 2 run A: launching (background, log runs3/runA.log, exit code runs3/runA.exit)
- step 2 run A DONE (exit 0). Next: copy to runA_raw, then run B (uptime first).
- step 2 run B DONE; raw copies runA_raw, runB_raw. Next: audit/read/count, summary.
- step 4 a_vs_b.txt written (avb.py proxy + hand_tally.py). Next: summary.txt
- step 3 summary.txt written. Next: advisor check, final report.
- DONE: summary.txt, a_vs_b.txt, rewords.txt, kept_with_refuse_names.txt, analysis_run{A,B,2}.txt, table.txt.
  Spend $0.186863 (smoke 0.007805 + A 0.092596 + B 0.086462). Worktree runs3_tree removed (branch brain-values-run-local
  kept at 16cd906, nothing committed). Scripts take TREE = S/mvp26/values_tree (same commit).
