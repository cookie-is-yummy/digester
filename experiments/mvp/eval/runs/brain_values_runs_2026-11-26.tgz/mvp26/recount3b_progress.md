# recount3b (mvp26) progress
- key recount3b: independent hand recount of S/mvp26/runs3/runB (values mode). Read-only, $0.
- step 0: brief read; scripts copied from mvp25/recount2 to S/mvp26/recount3b/. Library at 16cd906 byte-identical to mvp25 merge_tree (sha1 5845335...).
- step 1: dumped run B (dumpB.txt, with flags), read all 65 answers, computed facts from rows. Writing j_b.py (judgments). Key finds so far: N038.0 point 0 FALSE sent (newest save named lesson 3; it is the pasta post, 10 Oct); N053.0 lead wrongly based (every week Feb-mid Aug had an open); N005.0 lead wrongly based (Brick Realm absent 2023-25); N049.0 'part 6 of the series'; N052.1 reads past the line.
- step 2: j_b.py (174 rows: 170 first incl. N062.0 two-sentence lead as 1 row, 2 repair, 2 code), a_b.py marks (drift held: N013.0 offer, N022.1, N112.0 means). Next: N038.0 values hole, tally/notes/compare.
- step 3: tally_b (numbers.txt, sent_faults.txt), notes_b (sections 7, 8), compare_b (compare.txt) written. Next: advisor check, final report.
- DONE: numbers.txt, sentences.json, answers.json, sent_faults.txt, compare.txt in S/mvp26/recount3b (scripts assemble_b, a_b, tally_b, notes_b, compare_b, j_b). Spend $0, no model call, no code changed. Final: false sent 1 (N038.0), primary faults sent 5 in 4 answers, grades 20/33/12.
