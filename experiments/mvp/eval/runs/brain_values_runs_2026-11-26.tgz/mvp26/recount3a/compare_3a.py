"""compare.txt: mvp25 recount2 (run 2: cells checker) against mvp26 recount3a (run A: values checker), message by message.
Run after tally_3a.py: PYTHONDONTWRITEBYTECODE=1 python3 -I compare_3a.py
Written after sentences.json and answers.json of recount3a were frozen; run 2's files were opened only here."""
import json
from collections import Counter

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
oA = {a["key"]: a for a in json.load(open(S + "mvp25/recount2/answers.json"))}
nA = {a["key"]: a for a in json.load(open(S + "mvp26/recount3a/answers.json"))}
oR = json.load(open(S + "mvp25/recount2/sentences.json"))
nR = json.load(open(S + "mvp26/recount3a/sentences.json"))
BAD = ("false", "wrongly_based")
G = {"poor": 0, "acceptable": 1, "good": 2}
assert sorted(oA) == sorted(nA), "the two runs must hold the same keys"
out = []
p = out.append

# why each of run 2's poor answers moved or stayed. 'run' = the sent text changed materially; 'reader' = the text is
# about the same and the move is a difference between readers; 'checker' = values mode let out a sentence cells mode
# refuses (its cells flag is logged on it in run A).
WHY = {
    "N001.1": ("good", "run+checker", "the Pan Theory point went out ('Pan Theory made 30 of those videos, against 2'; cells would refuse it: unnamed_owner) with 'first opened on 1 February 2021': the 'why' is one old channel's return"),
    "N004.0": ("good", "run", "no timeout this time: the model's lead (gaming 0% to 49% against the summer, art 100% to 25%) went out; run 2 sent code's two bare totals after a ClaudeTimeout"),
    "N005.0": ("good", "run", "the model's right answer went out (Home cooking, the one theme in every year, all Pan Theory); it was written so that no check flags it at cells level; run 2 refused four true sentences (two_results) and sent code's 'Brick Realm led'"),
    "N008.1": ("acceptable", "run", "no time-up: October's contents went out (gaming 51%, Gaming clips 66, Clip Factory 61); run 2 said it could not get the breakdown in time"),
    "N027.0": ("good", "checker", "the model's day/night answer went out (evening 69%, afternoon 30%, night 1, busiest hour 4 to 5 pm); cells would refuse all three (number, wrong_measure, uncited_number); run 2 sent code's bare 723"),
    "N033.1": ("good", "checker", "values mode refused the first lead on a marker (wrong_value) and the reword went out true ('all 70 ... are in one period, Oct 2026'); run 2 refused both forms (other_period) and sent the plain 'couldn't check in time'"),
    "N035.0": ("good", "checker", "the model's lead (722 YouTube against 7 Instagram) went out; cells would refuse it (number); run 2 sent code's bare 729"),
    "N044.0": ("acceptable", "run", "no count over cards now ('Here are some ... newest first' with three named points); strict reading still poor (the 25 October pasta skipped)"),
    "N049.0": ("acceptable", "run+reader", "the point now numbers the two others (#6, #18), which reads as a series, not as all of them: strict only here; run 2's 'shows up again, opened on 8 June and 13 June' was primary. Close to a reader's call"),
    "N052.1": ("acceptable", "checker", "the model's answer went out with the reason ('Private items were left out of this history, so some of what you watched is not counted here'; cells would refuse it: unknown_name, uncited_claim); run 2 sent code's bare totals. Strict reading: poor (the lead's 'only 8' and 'that year stands out' read past the line on their own)"),
    "N053.0": ("acceptable", "checker", "'They ran from Feb 2024 to Aug 2024' went out (cells: other_period) with 'steady ... rather than a few bursts' (cells: uncited_number, free_number, uncited_claim), both true; run 2 dropped the span and left 'August the lightest month' wrongly based"),
    "N069.0": ("acceptable", "run", "'Its title is cut off in your history' was not written this time; values mode refused the first lead on a quote that added ')' and the reword went out true (cells would refuse the reword too: wrong_name)"),
    "N019.0": ("poor", "run", "the same fault again, now as a count: '2 channels were new to you' (the rows hold 3 first opened in the fall). Cells would refuse it (wrong_value) as it did in run 2's first form, but run 2's reword sent the same fault, so the old checker did not stop it either"),
    "N048.1": ("poor", "checker", "the true quote of the post ('feed 50 g flour and 50 g water, then wait 12 hours') was refused again, now by values mode (unfound_number: figures in third-party text are not counted as found, by design); the lead 'One saved item mentions flour' and the card went out, better than run 2's 'Here's what I found.', still no answer to 'what did it say'"),
    "N055.0": ("poor", "run", "never gives the friend's count again; this time it says 'all from the creators you follow, with no friend posts in that count' (wrongly based: no follows in the history, and reads as none saved)"),
    "N056.0": ("poor", "checker+run", "the true lead now goes out (cells would refuse it: uncited_claim; run 2 dropped it twice and sent code's 651), but the point says the long videos are 'the longest' (firm fault; flagged only at full: first_last)"),
    "N067.0": ("poor", "run", "never says November has no rows, as in run 2"),
    "N109.0": ("poor", "run", "mostly what it cannot find, no count, as in run 2"),
    "N113.0": ("poor", "run", "answers with saves and never says the export holds no likes, as in run 2"),
}
WORSE = {
    "N012.0": ("run+reader", "good to acceptable: the lead is now two bare totals (157 against 108; run 2 led with 'math took over') and two points start in lower case; the content is the same"),
    "N013.1": ("run", "good to acceptable: no card and no total this time (run 2 had the card and 'all 163')"),
    "N022.1": ("run+reader", "good to acceptable: four points now (the all-history point added); marked not brief"),
    "N033.0": ("run", "acceptable to poor: a new point 'All of them fell under Gaming clips, 66 items' after the 70 short videos (4 are watercolor reels); flagged only at full (direction_unbound), so cells mode would have sent it too"),
    "N038.0": ("run", "acceptable to poor: no longer says the export holds no likes; '6 items, listed below' over 3 cards; no flag on the sentence"),
    "N041.1": ("run", "acceptable to poor: the three Instagram saves are given by date only; run 2 named two by topic"),
    "N042.0": ("run", "acceptable to poor: no longer says the export holds no likes"),
    "N053.1": ("run+checker", "good to acceptable: a true but useless point went out ('The 2024 window has 366 days and 2023 has 365, so the counts are not on the same length'; cells would refuse it: free_number, uncited_number) in place of run 2's 'first opened on 1 February 2024'"),
    "N066.0": ("run", "acceptable to poor: 'Pixel Pencil came next' after a theme lead (rank across levels); flagged only at full (rank), so cells mode would have sent it too"),
}
BETTER_ELSE = {
    "N008.0": "reader+run: the lead now says October is the most of any month and 'no month from January to July went above 5', with a chart; run 2 listed five months",
    "N010.0": "checker: the Digital drawing point went out (32 from Pixel Pencil, new on 1 August; cells flags outside_in_history), so the rise is explained",
    "N010.1": "run: the watercolor comparison and Pixel Pencil's first day went out (no cells flag this time)",
    "N018.1": "run+checker: no 'only Brick Realm shows up ... 100%' (run 2's strict base fault); the by-year course and '67% in the evening' (cells: percent) went out",
    "N032.0": "checker: the Saturday-against-overall points went out (cells: two_results, three sentences) and the lead says the mix is the same",
    "N112.0": "reader: about the same text as run 2 ('all 4 in the morning'); this reader marks it good",
}

p("mvp25 recount2 (run 2: CELLS checker, code 0bd8720) against mvp26 recount3a (run A: VALUES checker, code 16cd906): fresh half A, 65 messages, same keys.")
p("IN SAMPLE: half A is the set the checker was built and tuned on; run A is one live run. One message moving either way is not proof.")
p("Each move is labelled: 'run' = the sent text changed materially (the model wrote differently, or a timeout went away); 'checker' = values")
p("mode let out a sentence the cells check refuses (its cells flag is logged on it in run A); 'reader' = the sent text is about the same, so the")
p("move is a difference between run 2's reader and this one. The two recounts are by different readers with the same method and tiers.")
p("")
p("== Headline (run 2 beside run A) ==")
oS = [r for r in oR if r["sent"] and r["sent_truth"] != "no_claim"]
nS = [r for r in nR if r["sent"] and r["sent_truth"] != "no_claim"]
oF = [r for r in oR if r["form"] == "first" and r["truth"] != "no_claim"]
nF = [r for r in nR if r["form"] == "first" and r["truth"] != "no_claim"]


def cnt(R, f, kind):
    return sum(r[f] == kind for r in R) if kind != "bad" else sum(r[f] in BAD for r in R)


def gstr(A, f):
    c = Counter(a[f] for a in A.values())
    return "/".join(str(c[g]) for g in ("good", "acceptable", "poor"))


rows_ = [
    ("false written / sent (primary)", f"{cnt(oF, 'truth', 'false')} of {len(oF)} / {cnt(oS, 'sent_truth', 'false')}", f"{cnt(nF, 'truth', 'false')} of {len(nF)} / {cnt(nS, 'sent_truth', 'false')} (1 if N019.0 is a count)"),
    ("wrongly based sent: firm / primary / strict", f"{cnt(oS, 'sent_truth_lenient', 'bad')} / {cnt(oS, 'sent_truth', 'bad')} / {cnt(oS, 'sent_truth_strict', 'bad')} of {len(oS)}",
     f"{cnt(nS, 'sent_truth_lenient', 'bad')} / {cnt(nS, 'sent_truth', 'bad')} / {cnt(nS, 'sent_truth_strict', 'bad')} of {len(nS)}"),
    ("answers with one: firm / primary / strict", "/".join(str(len({r['key'] for r in oS if r[f] in BAD})) for f in ("sent_truth_lenient", "sent_truth", "sent_truth_strict")),
     "/".join(str(len({r['key'] for r in nS if r[f] in BAD})) for f in ("sent_truth_lenient", "sent_truth", "sent_truth_strict"))),
    ("first-form wrongly based (primary)", f"{cnt(oF, 'truth', 'bad')} of {len(oF)}", f"{cnt(nF, 'truth', 'bad')} of {len(nF)}"),
    ("first-form wrongly based (strict)", f"{cnt(oF, 'truth_strict', 'bad')} of {len(oF)}", f"{cnt(nF, 'truth_strict', 'bad')} of {len(nF)}"),
    ("true first-form sentences refused", f"{sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in oR if r['form'] == 'first')} of {sum(r['truth'] == 'true' for r in oR if r['form'] == 'first')}",
     f"{sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in nR if r['form'] == 'first')} of {sum(r['truth'] == 'true' for r in nR if r['form'] == 'first')}"),
    ("true sentences refused, all forms", str(sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in oR if r['form'] in ('first', 'repair'))),
     str(sum(r['truth'] == 'true' and r['verifier_kept'] is False for r in nR if r['form'] in ('first', 'repair')))),
    ("faults refused (strict, all forms)", str(sum(r['truth_strict'] in BAD and r['verifier_kept'] is False for r in oR if r['form'] in ('first', 'repair'))),
     str(sum(r['truth_strict'] in BAD and r['verifier_kept'] is False for r in nR if r['form'] in ('first', 'repair')))),
    ("rewords (repair forms)", str(len({r['key'] for r in oR if r['form'] == 'repair'})), str(len({r['key'] for r in nR if r['form'] == 'repair'}))),
    ("code's lead or a plain line sent", str(sum(a['lead_source'] in ('code', 'plain') for a in oA.values())), str(sum(a['lead_source'] in ('code', 'plain') for a in nA.values()))),
    ("answers good / acceptable / poor", gstr(oA, "grade"), gstr(nA, "grade")),
    ("  strict", gstr(oA, "grade_strict"), gstr(nA, "grade_strict")),
    ("  lenient", gstr(oA, "grade_lenient"), gstr(nA, "grade_lenient")),
    ("poor before any truth count", str(sum(a['base_grade'] == 'poor' for a in oA.values())), str(sum(a['base_grade'] == 'poor' for a in nA.values()))),
    ("answers the question", str(sum(a['answers_question'] for a in oA.values())), str(sum(a['answers_question'] for a in nA.values()))),
    ("says what the numbers mean", str(sum(a['says_what_numbers_mean'] for a in oA.values())), str(sum(a['says_what_numbers_mean'] for a in nA.values()))),
    ("worthwhile offer", str(sum(a['carries_offer'] for a in oA.values())), str(sum(a['carries_offer'] for a in nA.values()))),
    ("brief", str(sum(a['brief'] for a in oA.values())), str(sum(a['brief'] for a in nA.values()))),
]
p(f"  {'':48s} {'run 2 (cells)':>24s}   {'run A (values)':>32s}")
for a, b, c in rows_:
    p(f"  {a:48s} {b:>24s}   {c:>32s}")
p("  poor causes, run 2: " + str(dict(Counter(a['poor_cause'] for a in oA.values() if a['grade'] == 'poor'))))
p("  poor causes, run A: " + str(dict(Counter(a['poor_cause'] for a in nA.values() if a['grade'] == 'poor'))))
import difflib  # noqa: E402


def _body(t):
    return t.split("\n\n")[0]


_rat = {k: difflib.SequenceMatcher(None, _body(oA[k]["sent_text"]), _body(nA[k]["sent_text"])).ratio() for k in oA}
_near = [k for k in oA if _rat[k] >= 0.8]
_d = {f: [k for k in _near if oA[k][f] != nA[k][f]] for f in ("base_grade", "answers_question", "says_what_numbers_mean", "carries_offer", "brief")}
_mu = [k for k in oA if not oA[k]["says_what_numbers_mean"] and nA[k]["says_what_numbers_mean"]]
_md = [k for k in oA if oA[k]["says_what_numbers_mean"] and not nA[k]["says_what_numbers_mean"]]
p(f"  Reader floor: only {len(_near)} of 65 answers kept near the same text (difflib ratio of the sent text >= 0.8: {', '.join(_near)}). On them the two readers"
  f" differ on base grade {len(_d['base_grade'])}, answers {len(_d['answers_question'])}, means {len(_d['says_what_numbers_mean'])}, offer {len(_d['carries_offer'])} ({', '.join(_d['carries_offer'])}), brief {len(_d['brief'])} ({', '.join(_d['brief'])}).")
p(f"  'Means' moved up on {len(_mu)} and down on {len(_md)} answers; every one of them sits on changed text (ratio {min(_rat[k] for k in _mu + _md):.2f} to {max(_rat[k] for k in _mu + _md):.2f}),"
  " though by hand N112.0 says the same thing in both runs, so 1 of the +11 is a reader difference. Text ratio is a weak test: the model rewords the same content every run.")
p("  Run A, from its records (not a recount): median 6.9 s, 6 of 65 over 11 s (slowest 14.5 s), 0 timeouts, 0 time-ups, 3 rewords, $0.0926.")
p("")
p("== Message by message (run 2 -> run A; base grade before truth in brackets) ==")
for k in sorted(oA):
    o, n = oA[k], nA[k]
    mv = "same" if o["grade"] == n["grade"] else ("BETTER" if G[n["grade"]] > G[o["grade"]] else "WORSE")
    lab = (WHY.get(k) or (None, None))[1] if o["grade"] == "poor" else (WORSE.get(k) or (None,))[0] if mv == "WORSE" else BETTER_ELSE.get(k, "").split(":")[0] if mv == "BETTER" else ""
    p(f"  {k:7s} {o['grade']:10s} -> {n['grade']:10s} [{n['base_grade']}] {mv:6s} src {o['lead_source'][:5]} -> {n['lead_source'][:5]}"
      + (f" ({lab})" if lab else "") + (f" | now poor: {n['poor_cause']}" if n["grade"] == "poor" else ""))
p("")
lp = [k for k in sorted(oA) if oA[k]["grade"] == "poor"]
up = [k for k in lp if nA[k]["grade"] != "poor"]
st = [k for k in lp if nA[k]["grade"] == "poor"]
for k in lp:
    assert WHY[k][0] == nA[k]["grade"], (k, WHY[k][0], nA[k]["grade"])
p(f"== Run 2's {len(lp)} poor answers: {len(up)} now acceptable or good ({sum(nA[k]['grade'] == 'good' for k in up)} good), {len(st)} still poor, 0 worse (none can be) ==")
p("  Now acceptable or good:")
for k in up:
    p(f"    {k} ({nA[k]['grade']}; {WHY[k][1]}): {WHY[k][2]}")
p("  By label: " + str(dict(Counter(WHY[k][1] for k in up))))
p("  Still poor:")
for k in st:
    p(f"    {k} ({WHY[k][1]}): {WHY[k][2]}")
p("  Run 2's 9 poor answers caused by the checker (5 checker drop, 4 code lead): N001.1, N005.0, N027.0, N033.1, N035.0, N048.1, N052.1, N053.0, N056.0.")
p("  In run A, 7 of them are acceptable or good; N048.1 is still poor from a checker refusal (now values mode's unfound_number); N056.0 is poor from a new framing fault.")
wr = [k for k in sorted(oA) if G[nA[k]["grade"]] < G[oA[k]["grade"]]]
for k in wr:
    assert k in WORSE, k
p("")
p(f"== Answers that got worse: {len(wr)} ({sum(nA[k]['grade'] == 'poor' for k in wr)} of them to poor) ==")
for k in wr:
    p(f"    {k} ({WORSE[k][0]}): {WORSE[k][1]}")
p("  Of the 5 that fell to poor, none is the checker's doing: N033.0 and N066.0 are new framing faults that cells mode would also have sent (flags at full only);")
p("  N038.0, N041.1 and N042.0 are the model's wording this run (the 'no likes' line written in run 2 and not here; dates in place of names).")
bt = [k for k in sorted(oA) if G[nA[k]["grade"]] > G[oA[k]["grade"]] and oA[k]["grade"] != "poor"]
p(f"  Better outside run 2's poor list: {len(bt)}")
for k in bt:
    p(f"    {k} ({oA[k]['grade']} -> {nA[k]['grade']}): {BETTER_ELSE[k]}")
p("")
p("== What the old checker would have refused and values mode let out: true or faulty, sentence by sentence ==")
p("  Two views. (1) In run A itself: every sentence values mode kept that carries a cells flag (cells mode refuses it with that code).")
let = [r for r in nR if r["verifier_kept"] and any(m == "cells" for _, m in r["flags"])]
p(f"  {len(let)} sentences, {len({r['key'] for r in let})} answers: true {sum(r['truth'] == 'true' for r in let)}, wrongly based primary {sum(r['truth'] in BAD for r in let)}"
  f" (N019.0 lead, lenient true), strict {sum(r['truth_strict'] in BAD for r in let)} (adds N049.0 lead and point, N054.0 lead: strict-only kinds); false 0. All were sent.")
for r in let:
    p(f"    {r['key']} {r['where']}{r['index']} cells:{','.join(c for c, m in r['flags'] if m == 'cells')} -> {r['truth']}"
      + (f" (strict {r['truth_strict']})" if r['truth_strict'] != r['truth'] else "") + f" | {r['text_plain']}")
p("  (2) Run 2's true sentences its checker refused (48, all forms), by message, and what run A sent on the same message:")
od = [r for r in oR if r["truth"] == "true" and r["verifier_kept"] is False and r["form"] in ("first", "repair")]
by_k = Counter(r["key"] for r in od)
for k in sorted(by_k):
    nsent = [r for r in nR if r["key"] == k and r["sent"]]
    nflag = [r for r in nsent if any(m == "cells" for _, m in r["flags"])]
    p(f"    {k}: run 2 refused {by_k[k]} true ({', '.join(sorted({c for r in od if r['key'] == k for c in r['verifier_reasons']}))});"
      f" run A sent {len(nsent)}, of them {len(nflag)} cells-flagged, faults sent {sum(r['sent_truth'] in BAD for r in nsent)} (strict {sum(r['sent_truth_strict'] in BAD for r in nsent)}); grade {oA[k]['grade']} -> {nA[k]['grade']}")
p("  Run 2's checker refused 9 fault rows (strict, all forms), 6 of them primary: N019.0 first lead; N044.0 first lead; N052.1 first lead and point, and both again in the repair;")
p("  strict-only: N049.0, N052.0 and N054.0 first leads (their repairs went out with the same strict-only kind).")
p("  In run A: N019.0's fault was written and sent (values mode let it out; it carries wrong_value@cells, so cells mode would refuse it, and in run 2 the")
p("  reword brought the same fault back out). N044.0 and N052.1 were written differently and hold no primary fault. N049.0, N052.0, N054.0: strict-only, sent in both runs.")
p("")
p("== Run 2's primary sent faults (5) and run A's (6) ==")
for r in [x for x in oR if x["sent"] and x["sent_truth"] in BAD]:
    n_ = [x for x in nR if x["key"] == r["key"] and x["sent"] and x["sent_truth"] in BAD]
    p(f"  run 2 {r['key']} {r['where']}{r['index']}: \"{r['text_plain']}\" -> run A: " + (f"{len(n_)} primary fault sent: \"{n_[0]['text_plain']}\"" if n_ else "none sent on this message"))
for r in [x for x in nR if x["sent"] and x["sent_truth"] in BAD]:
    o_ = [x for x in oR if x["key"] == r["key"] and x["truth"] in BAD]
    p(f"  run A {r['key']} {r['where']}{r['index']}: \"{r['text_plain']}\" ({r['sent_origin_class']}; flags {[c + '@' + m for c, m in r['flags']] or 'none'})"
      + (f"; run 2 wrote {len(o_)} fault(s) on this message, sent {sum(x['sent'] for x in o_)}" if o_ else "; new on this message"))
p("  Every run A fault sent is the model's own framing. 1 of 6 carries a cells flag (N019.0); 4 carry only full-mode flags; 1 (N038.0) carries none.")
p("")
p("== Caveats ==")
for t in [
    "In sample: half A. Half B and run B were not opened. One live run; the noise floor between two runs of the same code is run B's job.",
    "Different readers. Of the 27 grade moves (18 better, 9 worse), N049.0, N012.0, N022.1, N008.0 and N112.0 are partly or wholly reader differences (labels above). Four new fault kinds were filed here (N055.0 follows, N056.0 'the longest', N033.0 'all of them', N066.0 rank across levels); section 7 of numbers.txt gives each other reading.",
    "Run A had no timeouts or time-ups; run 2 had 2 (N004.0, N008.1). Those two moves are speed, not the checker.",
    "The cells flags in run A are the cells check's codes on run A's sentences. They say what cells mode would refuse sentence by sentence, not what a cells run would have sent: a refused lead asks for a reword, and the model writes differently each run.",
]:
    p("  - " + t)
p("")
p("== Three most useful next changes this recount points to (in sample; measure before and after) ==")
for t_ in [
    "1. Code's limits line on every answer whose plan took a substitute after a tool error (no likes, no November). Run A: N042.0, N113.0 (likes) and N067.0 (November) are poor only because the answer never says the export lacks it, and N038.0 (likes) is poor for that and for a count over cards; the tool's error said so each time. In run 2 the model wrote the line on N038.0 and N042.0 and not on N113.0 or N067.0: it comes and goes with the run. Code words the line (as N057.0's minutes line), so no checker rule and no model sentence is touched. Would lift 3 of the 12 poor and half of N038.0; it also stops the swing between runs.",
    "2. Keep values mode, and narrow its two refusals that cost true sentences here, both on how a value is found, not on words: (a) a figure or quote that stands in the row's own third-party text (why_matched/title) may be found there when the sentence cites that row and reports the post's text (N048.1: 'It says to feed 50 g flour and 50 g water, then wait 12 hours', refused in two runs, and the only answer still poor from a checker refusal); keep the planted forged-title cases refused (a figure from a title said as a count). (b) wrong_value on a date or month marker that points at a count cell, and a quote that differs from the cut title by a closing bracket, are marker slips: let the reword name the cell to use (N033.1, N066.1, N069.0 each cost a reword; N066.1 lost its Instagram half). All 4 refusals in run A were true; none caught a fault.",
    "3. No flag earns its power back on this run, with one exception to name. The 45 sentences with a cells flag (41 kept, 4 refused) hold 1 primary fault (N019.0) and 44 true. The exception: wrong_value@cells flagged 1 kept sentence and it was the fault (N019.0); offline, that rule is 'r1.new.channels.count is a list cut to fit: say the top', a demand for words on a list the tool marks as cut, not a value check, and in run 2 the reword brought the same fault back past it. Other than that, the full-mode codes that touched faults (direction_unbound 2 of 3, rank 1 of 2, first_last 1 of 1, uncited_claim 1 of 10) are one or two cases each. The faults that went out are framing the model writes: a list or count said as complete (N019.0, N033.0, N038.0), a filter said as a superlative (N056.0), a rank across levels (N066.0), a claim about the person (N055.0). Point those at the tool side rather than at a word rule: the tool's new.channels could carry every channel first opened in the window with its count (N019.0), and items could say 'newest first among videos over 60 s' with each item's length so 'the longest' has a cell to fail on (N056.0); then a values check refuses them with no reading of words.",
]:
    p("  " + t_)
open(S + "mvp26/recount3a/compare.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out[:40]))
