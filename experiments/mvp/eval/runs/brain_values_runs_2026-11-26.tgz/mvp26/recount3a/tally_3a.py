"""Rebuild: PYTHONDONTWRITEBYTECODE=1 python3 -I assemble_3a.py && python3 -I a_3a.py && python3 -I tally_3a.py
Writes numbers.txt and sent_faults.txt from sentences.json and answers.json (mvp26 recount3a: run A, values checker)."""
import importlib.util
import json
from collections import Counter, defaultdict

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
D = S + "mvp26/recount3a/"
RUN = S + "mvp26/runs3/runA/"
import glob as _g
RECS = {json.load(open(_p))["key"]: json.load(open(_p)) for _p in sorted(_g.glob(RUN + "N*.json"))}
NA = len(RECS)
spec = importlib.util.spec_from_file_location("taxonomy", S + "mvp22/paper/taxonomy.py")
T = importlib.util.module_from_spec(spec)
spec.loader.exec_module(T)
rows = json.load(open(D + "sentences.json"))
ans = json.load(open(D + "answers.json"))
BAD = ("false", "wrongly_based")
VALUES = {"wrong_value", "wrong_name", "wrong_measure", "bad_ref", "calc", "empty", "garbled", "unfound_number",
          "unfound_date", "unfound_time", "unfound_name"}
SAFETY = {"sensitive", "psych", "outcome", "language", "link", "watch_time", "not_item"}
out = []
p = out.append


def cls(code):
    base = code.split(":")[0]
    if base in VALUES:
        return "values"
    if base in SAFETY:
        return "safety"
    return "other"


def tcls(code):
    """last round's taxonomy class of a flag code (for the flag table)"""
    if code in T.CELL or code == "name":
        return "cell"
    if code in T.POLICY:
        return "policy"
    if code in T.DOUBT:
        return "doubtful"
    if code in T.FRAMING:
        return "framing"
    return "other"


def pc(a, b):
    return f"{a}/{b} = {100.0 * a / b:.1f}%" if b else f"{a}/0"


def rate_block(R, label):
    claims = [r for r in R if r["truth"] != "no_claim"]
    nc = len(claims)
    tc = Counter(r["truth"] for r in R)
    bp = sum(r["truth"] in BAD for r in claims)
    bs = sum(r["truth_strict"] in BAD for r in claims)
    bl = sum(r["truth_lenient"] in BAD for r in claims)
    p(f"{label}: {len(R)} sentences; {dict(tc)}; with a claim {nc}")
    p(f"  false (wrong number, name, date or calculation): {tc['false']}")
    p(f"  wrongly based: primary {pc(bp - tc['false'], nc)}, strict {pc(bs, nc)}, lenient {pc(bl, nc)}")
    p(f"  cannot prove: {tc['cannot_prove']}; recounted from the rows: {sum(1 for r in R if r['recounted_by_rows'])}, by reading the rows' fields only: {sum(1 for r in R if not r['recounted_by_rows'])}")


KIND = [("'only' or 'all': '2 channels", "only/all: a list said as complete (new channels)"),
        ("'only' or 'all': 'All of them", "only/all: 'all of them' over a larger set"),
        ("count of the list against the cards", "count of the list against the cards shown"),
        ("'all from the creators you follow", "a claim about the person not in the rows (follows) + friend's save as absent"),
        ("'The longest videos", "a filter said as a superlative ('long' as 'the longest')"),
        ("rank across levels", "rank across levels"),
        ("wrongly based: 'Clip Factory led", "ambiguous attribution of a total (strict)"),
        ("wrongly based: 'newest first'", "a list read as the newest (an item skipped) (strict)"),
        ("wrongly based: 'the closest'", "one of many said as the one (strict)"),
        ("wrongly based: two of the 20", "only/all: two of many said as the others (strict)"),
        ("wrongly based (only/all): 'only 8'", "private: only over rows shown (strict; the convention passes it)"),
        ("wrongly based (reads past the line)", "private: reads past the line (strict)"),
        ("wrongly based (reads as a false absence)", "friend's post: reads as a false absence (strict)")]


def kind(r):
    t = r["fault"] if r["truth"] in BAD else (r["borderline"] or "")
    t = t.split("strict: ", 1)[-1]
    for a, b in KIND:
        if t.startswith(a):
            return b
    if "(only/all)" in t:
        return "private: only/all over rows shown (strict; the convention passes it)"
    return t[:40]


p(f"mvp26 recount3a: independent hand recount of runs3/runA (fresh half A, VALUES checker, prompt v3, code 16cd906, {NA} messages)")
p("Every sentence recounted from the rows of experiments/mvp/tests/brain_library.py (byte-identical at 16cd906 and 0bd8720; read through lib.py)")
p("by checks in j_3a.py; no tool result was used as a source of truth (only to name a fault's origin). Judged by hand: framing, answers.")
p("Judged afresh: last round's numbers.txt was read for the method and the tiers before judging; no verdict of an earlier round was opened")
p("before sentences.json and answers.json were written. Run B and its recount were not opened. Half B not opened. No model call, $0.")
p("Readings: primary = my judgment; strict = also counts the borderline framing cases; lenient = passes them.")
p("Private-row convention applied (DECISIONS 26 Nov 2026): with the line shown, all/only/rank/count over the rows shown is not counted;")
p("a false absence, or a sentence that reads past the line, is.")
p("")
p("== 0. Headline ==")
SN0 = [r for r in rows if r["sent"] and r["sent_truth"] != "no_claim"]
_F1 = [r for r in rows if r["form"] == "first"]
p(f"  False (a wrong number, name, date or calculation): 0 written in {len(_F1)} first-form sentences, {sum(r['sent_truth'] == 'false' for r in SN0)} sent in {len(SN0)} with a claim, in every reading.")
p("    One candidate (section 7): N019.0 '2 channels were new to you' while the rows hold 3 channels first opened in the fall. Filed wrongly based")
p("    (the tool's 5-item rule for 'new'); read as a count it is 1 false sentence sent in 182.")
p(f"  Wrongly based sent: firm {sum(r['sent_truth_lenient'] in BAD for r in SN0)}, primary {sum(r['sent_truth'] in BAD for r in SN0)}, strict {sum(r['sent_truth_strict'] in BAD for r in SN0)} of {len(SN0)} sent sentences with a claim;"
  f" answers with one or more: firm {len({r['key'] for r in SN0 if r['sent_truth_lenient'] in BAD})}, primary {len({r['key'] for r in SN0 if r['sent_truth'] in BAD})}, strict {len({r['key'] for r in SN0 if r['sent_truth_strict'] in BAD})} of {NA}.")
p(f"  Values-mode refusals: {sum(1 for r in rows if r['verifier_kept'] is False)} sentences refused (all forms), all true by this recount; no fault was refused.")
p(f"  Answers: {dict(Counter(a['grade'] for a in ans))} (strict {dict(Counter(a['grade_strict'] for a in ans))}, lenient {dict(Counter(a['grade_lenient'] for a in ans))});"
  f" {sum(a['base_grade'] == 'poor' for a in ans)} are poor before any truth count.")
p("  Answer marks are one reader's, not run 2's reader: compare.txt gives the reader floor and labels each grade move run / checker / reader.")
w1 = sum(r_["sentences"]["written"] for r_ in RECS.values())
p(f"  Denominator: the run's own 'written' for first forms is {w1} sentences; here a lead of 2 or 3 sentences is one row (N032.0 2, N062.0 3), so first forms are {len(_F1)} rows.")
p("")
p("== 1. The model's raw rate (what it wrote, before the checker) ==")
F1 = [r for r in rows if r["form"] == "first"]
rate_block(F1, "first forms")
RP = [r for r in rows if r["form"] == "repair"]
rate_block(RP, f"repair forms ({len({r['key'] for r in RP})} repairs)")
rate_block([r for r in RP if not r["repeat_of_first"]], "repair forms, new text only")
for lab, f in (("primary", "truth"), ("strict", "truth_strict"), ("lenient", "truth_lenient")):
    p(f"  first-form faults by kind, {lab}: {dict(Counter(kind(r) for r in F1 if r[f] in BAD))}")
p("")
p("== 2. The checker (values mode) against the truth ==")
cl = [r for r in F1 if r["truth"] not in ("no_claim",)]
X = Counter((r["truth"], r["verifier_kept"]) for r in cl)
p(f"  first forms: true kept {X[('true', True)]}, true refused {X[('true', False)]}; wrongly based kept {X[('wrongly_based', True)]}, refused {X[('wrongly_based', False)]};"
  f" false kept {X[('false', True)]}, refused {X[('false', False)]}; cannot prove kept {X[('cannot_prove', True)]}, refused {X[('cannot_prove', False)]}")
for lab, R in (("first forms", F1), ("all forms (first + repair)", F1 + RP)):
    td = [r for r in R if r["truth"] == "true" and r["verifier_kept"] is False]
    p(f"  true sentences refused, {lab}: {len(td)}; by reason code: " + ", ".join(f"{k} {v} [{cls(k)}]" for k, v in Counter(c for r in td for c in set(r["verifier_reasons"])).most_common()))
p("  privacy and safety refusals: " + str(sum(1 for r in F1 + RP for c in r["verifier_reasons"] if c in SAFETY)) + " (none)")
p("  every refusal, with its marked sentence, the reason and the truth:")
for r in F1 + RP:
    if r["verifier_kept"] is False:
        p(f"    {r['key']} {r['form']} {r['where']}{r['index']} {r['verifier_reasons']} -> {r['truth']}")
        p(f"       marked: {r['text']}")
        p(f"       detail: {'; '.join(r['verifier_details'])}")
        p(f"       why it is true: {r['note']}")
for lab, f in (("primary", "truth"), ("strict", "truth_strict"), ("lenient", "truth_lenient")):
    b = [r for r in F1 if r[f] in BAD]
    p(f"  first-form faults, {lab}: {len(b)}, of them refused by the checker {sum(r['verifier_kept'] is False for r in b)}, kept {sum(r['verifier_kept'] is True for r in b)}")
p("  repairs: 3 (N033.1, N066.1, N069.0), each asked because the lead was refused; each repaired lead is true and went out; the repair forms hold 0 faults.")
p("")
p("== 2b. FLAGS: for every flag code logged, how many flagged sentences were true and how many faulty ==")
p("  A flag is {code, mode}: the code today's cells or full check gives the same sentence (verify.py _values_flags); 'values' is too_long only.")
p("  Counted over every sentence of every form (188 rows; a merged lead carries the union of its sentences' flags). faulty = false or wrongly based.")
p("  The flag 'deserves its power back' only if it catches faults and few true sentences; cells-mode codes are what run 2's checker refused on.")
tab = defaultdict(lambda: Counter())
for r in rows:
    for c_, m_ in r["flags"]:
        k = f"{c_}@{m_}"
        tab[k]["n"] += 1
        tab[k]["true_p"] += r["truth"] not in BAD and r["truth"] != "no_claim"
        tab[k]["bad_p"] += r["truth"] in BAD
        tab[k]["bad_s"] += r["truth_strict"] in BAD
        tab[k]["bad_l"] += r["truth_lenient"] in BAD
        tab[k]["sent"] += r["sent"]
p(f"  {'code@mode':28s} {'class':9s} {'flagged':>7s} {'true':>5s} {'faulty p/s/l':>13s}  faulty sentences (primary or strict)")
for k in sorted(tab, key=lambda k: (-tab[k]["n"], k)):
    t = tab[k]
    who = [f"{r['key']} {r['where']}{r['index']}" + ("" if r["truth"] in BAD else "(s)") for r in rows
           if k in {f"{c}@{m}" for c, m in r["flags"]} and r["truth_strict"] in BAD]
    p(f"  {k:28s} {tcls(k.split('@')[0]):9s} {t['n']:7d} {t['true_p']:5d} {t['bad_p']:4d}/{t['bad_s']}/{t['bad_l']:<6d}  {', '.join(who)}")
cells_n = sum(1 for r in rows if any(m == "cells" for _, m in r["flags"]))
cells_bad = [r for r in rows if any(m == "cells" for _, m in r["flags"]) and r["truth"] in BAD]
cells_bad_s = [r for r in rows if any(m == "cells" for _, m in r["flags"]) and r["truth_strict"] in BAD]
p(f"  any cells flag: {cells_n} sentences, faulty primary {len(cells_bad)} ({', '.join(r['key'] + ' ' + r['where'] + str(r['index']) for r in cells_bad)}), strict {len(cells_bad_s)}")
full_n = sum(1 for r in rows if any(m == "full" for _, m in r["flags"]))
p(f"  any full flag: {full_n} sentences, faulty primary {sum(1 for r in rows if any(m == 'full' for _, m in r['flags']) and r['truth'] in BAD)}")
p(f"  no flag at all: {sum(1 for r in rows if not r['flags'])} sentences, faulty primary {sum(1 for r in rows if not r['flags'] and r['truth'] in BAD)}, strict {sum(1 for r in rows if not r['flags'] and r['truth_strict'] in BAD)}")
p("  Kept sentences only (a flag on a sentence values mode refused anyway says nothing about giving it power back):")
ktab = defaultdict(Counter)
for r in rows:
    if not r["verifier_kept"]:
        continue
    for c_, m_ in r["flags"]:
        k = f"{c_}@{m_}"
        ktab[k]["n"] += 1
        ktab[k]["bad_p"] += r["truth"] in BAD
        ktab[k]["bad_s"] += r["truth_strict"] in BAD
hit = sorted((k for k in ktab if ktab[k]["bad_s"]), key=lambda k: (-ktab[k]["bad_p"], -ktab[k]["bad_s"], ktab[k]["n"]))
p("    codes that touched a fault (kept rows): " + "; ".join(f"{k} {ktab[k]['n']} flagged, faulty {ktab[k]['bad_p']} (strict {ktab[k]['bad_s']})" for k in hit))
p("    every other code flagged only true sentences among kept rows.")
p("  wrong_value@cells, kept rows only: 1 flagged, 1 faulty (N019.0 lead). The two other wrong_value@cells rows (N033.1 and N066.1 first leads) were refused by")
p("    values mode too, and both are true. Run offline (verify.check_answer, mode CELLS, on N019.0's own ledger), the cells rule says: 'r1.new.channels.count is")
p("    a list cut to fit: say \'the top\''. So it is not a value comparison: the count cell is right (2), and the rule asks for the words 'the top' because the")
p("    tool marks that list as cut. Values mode's own wrong_value has no such clause, so it gave nothing. In run 2 the same rule refused the first form and the")
p("    reword sent the fault anyway.")
VR = {"wrong_value", "wrong_name", "wrong_measure", "bad_ref", "calc", "unfound_number", "unfound_date", "unfound_time", "unfound_name"}
vk = [r for r in rows if r["verifier_kept"] and any(c in VR for c, m in r["flags"] if m == "cells")]
p(f"  Kept sentences carrying a cells flag whose code is on VALUES_REFUSE (what the values narrowing freed or let out): {len(vk)}")
for r in vk:
    p(f"    {r['key']} {r['form']} {r['where']}{r['index']} cells:{[c for c, m in r['flags'] if m == 'cells' and c in VR]} -> {r['truth']} | {r['text_plain']}")
vf = [r for r in rows if r["verifier_kept"] and any(c in VR for c, m in r["flags"] if m == "full")]
p(f"  ... and with a full flag on VALUES_REFUSE: {len(vf)} sentences, faulty primary {sum(r['truth'] in BAD for r in vf)} ({', '.join(r['key'] + ' ' + r['where'] + str(r['index']) for r in vf if r['truth'] in BAD)}), strict {sum(r['truth_strict'] in BAD for r in vf)}")
p("  The reverse view: each faulty sentence (strict reading) and the flags it carried:")
for r in rows:
    if r["truth_strict"] in BAD:
        p(f"    {r['key']} {r['form']} {r['where']}{r['index']} [{r['truth']}/{r['truth_strict']}/{r['truth_lenient']}] sent={r['sent']} flags={[f'{c}@{m}' for c, m in r['flags']] or 'none'} | {kind(r)}")
p("")
p("== 2c. What the old checker (cells mode, run 2's) would have refused, and values mode let out ==")
p("  A sentence kept by values mode that carries a cells flag: cells mode gives it that refusal code. (In a cells run a refused lead would")
p("  have asked for a reword and could have changed the rest; this is per sentence, as written here.)")
let = [r for r in rows if r["verifier_kept"] and any(m == "cells" for _, m in r["flags"])]
p(f"  {len(let)} sentences: true {sum(r['truth'] == 'true' for r in let)}, wrongly based (primary) {sum(r['truth'] in BAD for r in let)}, strict {sum(r['truth_strict'] in BAD for r in let)}; sent {sum(r['sent'] for r in let)}")
for r in let:
    p(f"    {r['key']} {r['form']} {r['where']}{r['index']} cells:{[c for c, m in r['flags'] if m == 'cells']} -> {r['truth']}"
      + (f" (strict {r['truth_strict']})" if r['truth_strict'] != r['truth'] else "") + f" | {r['text_plain']}")
p("")
p("== 3. What was SENT ==")
SN = [r for r in rows if r["sent"]]
p(f"  sentences sent (rows): {len(SN)} (model {sum(r['form'] not in ('code', 'plain') for r in SN)}, code leads and plain lines {sum(r['form'] in ('code', 'plain') for r in SN)}); {dict(Counter(r['sent_truth'] for r in SN))}")
scl = [r for r in SN if r["sent_truth"] != "no_claim"]
for lab, f in (("primary", "sent_truth"), ("strict", "sent_truth_strict"), ("lenient", "sent_truth_lenient")):
    b = [r for r in scl if r[f] in BAD]
    p(f"  false or wrongly based sent, {lab}: {pc(len(b), len(scl))} of sent sentences with a claim (false {sum(r[f] == 'false' for r in b)}, wrongly based {sum(r[f] == 'wrongly_based' for r in b)});"
      f" answers with at least one: {len({r['key'] for r in b})} of {NA}")
for lab, f in (("firm", "sent_truth_lenient"), ("primary", "sent_truth"), ("strict", "sent_truth_strict")):
    p(f"  by origin ({lab}): " + str(dict(Counter(r["sent_origin_class"] for r in scl if r[f] in BAD))))
p("  code leads and plain lines sent: none (lead sources: " + str(dict(Counter(r["lead_source"] for r in RECS.values()))) + ")")
pb = [r for r in SN if r["private_base"] and not r["answer_private_line"]]
p(f"  sent sentences citing a result with private rows hidden while the answer has no private line: {len(pb)} {[r['key'] for r in pb]}")
pl = [r for r in SN if r["private_base"]]
p(f"  sent sentences citing a result with private rows hidden: {len(pl)}, in {len({r['key'] for r in pl})} answers; true only by the convention: "
  f"{sum(1 for r in pl if (r['note'] or '').startswith('true only by the private-row convention'))}")
p("")
p("== 4. Answers as sent, read by the rubric and the founder's rules ==")
for g in ("base_grade", "grade", "grade_strict", "grade_lenient"):
    p(f"  {g:14s}: {dict(Counter(a[g] for a in ans))}")
p(f"  answers the question: {sum(a['answers_question'] for a in ans)}/{NA}; says what the numbers mean: {sum(a['says_what_numbers_mean'] for a in ans)}/{NA};"
  f" carries an offer worth taking: {sum(a['carries_offer'] for a in ans)}/{NA}; brief: {sum(a['brief'] for a in ans)}/{NA}")
p("  poor causes (primary): " + str(dict(Counter(a["poor_cause"] for a in ans if a["grade"] == "poor"))))
p("  poor causes (strict):  " + str(dict(Counter(a["poor_cause_strict"] for a in ans if a["grade_strict"] == "poor"))))
p(f"  by lead source: " + str({ls: dict(Counter(a['grade'] for a in ans if a['lead_source'] == ls)) for ls in ('model', 'model_after_repair', 'code', 'plain')}))
p("  every poor answer (primary or strict), one line each:")
for a in ans:
    if a["grade"] == "poor" or a["grade_strict"] == "poor":
        p(f"    {a['key']} [{a['grade']}/{a['grade_strict']}/{a['grade_lenient']} primary/strict/lenient] {a['poor_cause'] or a['poor_cause_strict']}: {a['note']}"
          + (f"; faults sent: {a['false_sent']} (strict {a['false_sent_strict']}, lenient {a['false_sent_lenient']})" if a["false_sent_strict"] else ""))
p("")
p("== 5. Per answer ==")
p("  key     src   grade/strict/lenient  ans means offer brief  sent faults p/s/l")
for a in ans:
    p(f"  {a['key']:7s} {a['lead_source'][:5]:5s} {a['grade'][:4]:4s}/{a['grade_strict'][:4]:4s}/{a['grade_lenient'][:4]:4s}         {'yn'[not a['answers_question']]}   {'yn'[not a['says_what_numbers_mean']]}     {'yn'[not a['carries_offer']]}     {'yn'[not a['brief']]}      {a['false_sent']}/{a['false_sent_strict']}/{a['false_sent_lenient']}")
p("")
p("== 6. Borderline sentences (the strict and lenient readings differ) ==")
for r in rows:
    if r.get("borderline"):
        p(f"  {r['key']} {r['form']} {r['where']}{r['index']} {r['truth']} sent={r['sent']} | {r['borderline']}")
p("")
exec(open(D + "notes_3a.py").read())
open(D + "numbers.txt", "w").write("\n".join(out) + "\n")

# sent_faults.txt
o = []
o.append("Every false or wrongly based sentence SENT in mvp26/runs3/runA (fresh half A, values checker, prompt v3), by the independent recount (recount3a).")
o.append("Tier 1: firm (every reading). Tier 2: primary, passed by the lenient reading. Tier 3: strict only.")
o.append("Origin: 'as the model wrote it' (the model's framing went out; values mode reads no words); 'tool gave a wrong/incomplete picture' (the tool")
o.append("result led the model there; read from the tool result as evidence of origin only, never of truth); 'neighbour drop' (a refusal of another")
o.append("sentence made it wrong). Flags: the codes the cells and full checks gave the sentence (they refused nothing in this run).")
o.append("False (a wrong number, name, date or calculation) sent: %d in every reading (N019.0 is the one candidate; see numbers.txt section 7)." % sum(r["sent_truth"] == "false" for r in SN))
o.append("")
tiers = [("Tier 1: firm", lambda r: r["sent_truth_lenient"] in BAD),
         ("Tier 2: primary, lenient passes", lambda r: r["sent_truth"] in BAD and r["sent_truth_lenient"] not in BAD),
         ("Tier 3: strict only", lambda r: r["sent_truth_strict"] in BAD and r["sent_truth"] not in BAD)]
msg = {a["key"]: a["message"] for a in ans}
for lab, f in tiers:
    R = [r for r in SN if f(r)]
    o.append(f"== {lab}: {len(R)} sentences in {len({r['key'] for r in R})} answers ==")
    for r in R:
        o.append(f"{r['key']}  message: \"{msg[r['key']]}\"")
        o.append(f"  sent ({r['where']} {r['index']}, {r['form']} form): \"{r['text_plain']}\"")
        o.append(f"  origin: {r['sent_origin']}")
        o.append(f"  verdict: {r['sent_truth']} (strict {r['sent_truth_strict']}, lenient {r['sent_truth_lenient']}); fault: {r['sent_fault'] or r['sent_borderline']}")
        if r.get("sent_borderline") and r["sent_fault"]:
            o.append(f"  other reading: {r['sent_borderline']}")
        o.append(f"  flags carried: {[f'{c}@{m}' for c, m in r['flags']] or 'none'}")
        o.append(f"  private line on the answer: {'yes' if r['answer_private_line'] else 'no'}")
    o.append("")
open(D + "sent_faults.txt", "w").write("\n".join(o) + "\n")
print("\n".join(out[:40]))
