# values (mvp26) progress
- worktree: S/mvp26/values_tree, branch brain-values-local (from d7ba2ef). Evidence: S/mvp26/values/.
- step 0: read brief, DESIGN 24/24.8/25.14/25.15, DECISIONS last 3. Base copies of verify at 4064f3e and tip in values/base/.
- step 1 (attribution): in progress
- step 1 DONE: values/attribution.txt (attrib.py, attrib_txt.py, repro.py). 48 = 43 old rule on new shapes, 4 period_named, 1 free_date, 0 season, 0 insight_walk. Harness lib26.py reproduces run2 verdicts 86/86.
- step 2 (values mode): next
- step 1 addendum: attribution_side.txt: 4064f3e cells drops 27/155 (run1) and 40/165 (run2) first forms; the rise is the old rules on new shapes (uncited_number 3->12, two_results 1->8). Brief's "watch_time 3 in run 2" not reproduced (1).

## step 2 design, written BEFORE the first values measurement (2026-11-26)
Wrapper: values check_answer runs today's full and today's cells check_answer (unchanged code) for the FLAGS (code, mode),
then refuses only on its own value rules + privacy predicates called directly.
"Found" (rule d), per kind; the pool is this turn's result envelopes (sheet + meta, every key, notes included) and the
user's message. NOT turn.names (the library index) and not the screen.
- figure (digits, no marker): equal to a numeric value anywhere in the envelopes or a list's length; or, for a float in
  [0,1], its x100 within 0.5 (1.5 after a hedge word); or rounding a float to the typed decimals gives it; or the same
  number appears inside a string value of the envelopes, or in the message. "N%" the same.
- clock time ("5pm", "3:00 pm"): an 'hour' value equal to it, or a date-time value with that hour (and minute when
  typed), or the time text inside a string value, or the message.
- date parts: full date: a date value with that day; "D Month": a date value with that month and day; "Month YYYY": a
  date value in that month; year: a date value in that year, or the year in a string value, or the message; month
  alone: a date value in that month. A date value = any string starting YYYY-MM-DD, anywhere. Also found if the same
  date text appears inside a string value.
- name (no marker): detector = capitalised word runs (not a sentence-initial single word followed by a lower-case
  word; not the opener/allowed-caps/month/weekday words today's unknown_name skips), '@handles', quoted strings, and
  the library index names (ledger.all_names() + turn.names; lower-case names too). Found = the run (case-insensitive,
  whole words) occurs inside some string value of the envelopes, or in the message. A quoted string is found if it
  (less a trailing '...' and a trailing '#n') occurs inside a string value.
- number words (two..twenty, half, a third, a quarter): variant "nw_refuse": a value like a figure (half/third/
  quarter: a share within 5 points of 50/33.3/25), refused when not found; variant "nw_flag": never refused, flagged.
- marked values (rule a): check_value's wrong_value, wrong_name (value-name cells), wrong_measure of a typed unit
  against the cell's kind (a count typed as a share, a share typed with no %), a typed +/- sign against a points
  cell; row markers: refused only when the words right before name another row (a known name that is not the row's)
  or a quoted title that is not the row's (title_quote loosening); hour cells; date cells (_date_ok). A fraction word
  before a marker: compared under the variant.
- rule (b): parse's bad_ref (a bracket that is no path of this turn, braces).
- rule (c): calc arithmetic recomputed from the two cells (any results), |typed| against |value| within today's
  tolerances, a typed sign, ratio words in today's bands; a division by 0.
Privacy and safety kept (predicates called directly): sensitive (_sensitive), psych (PSYCH; _MOTIVE judged separately),
outcome, language, link (insight's _LINK on the plain text minus the handles the cited rows hold), watch_time only when
a marker cites a length total (no word reading). outside lines (check_outside) unchanged.
Changes after the first measurement are logged below with the sentence that prompted each.
- CHANGE 1 (after the first values run on the live sets): a month is also found when a string of the results holds it as
  "<Mon> YYYY" (a period's label "Jul 2026") or "YYYY-MM", and a day/month written in a result string ("5 January 2021").
  Prompted by look1/look2 F11.0 "September 2026", run1 N008.0 "July"/"September", run2 N001.1, N008.0, N053.0 (8 true
  sentences refused unfound_date only because period rows hold labels, not ISO dates).
- CHANGE 2 (attack sets, first run): figures, dates and times are read only from code's own strings (window words,
  labels, notes), never from third-party text (title, text, why_matched, caption, name, channel, handle). Prompted by the
  planted f_forged_title2, audit F50b, F50c (a title's '999' counted as found). Cost: run1 N048.1 p0, run2 N048.1 lead and
  p0 (a saved post's own '50 g', '12 hours', 'day 3' typed with no quotes) now refused: 3 true sentences.
- CHANGE 3: the sentence-initial exemption read the text after names were blanked ("Brickstorm Gaming": 'Gaming' blanked,
  so 'Brickstorm' looked like a capital before a lower-case word). Now: a sentence-initial single capital is exempt only
  when the next word in the raw sentence is not a capital. Prompted by planted f_invented_start; then run1 N027.0 "Hour 18".
- CHANGE 4: "5 September to 2 October 2026": a day and month with no year take the year that closes the range.
- CHANGE 5: a row marker after a capitalised name that is not the row's and that no result holds ("Any% speedrun
  guide[r1.items[1]]", "Anime clips[r1.themes[0]]") is unfound_name; a weekday written beside a full date must be that
  date's (verify._typed_weekday, calendar arithmetic). Prompted by attack2 c04, b02, q09, w01 (read after the first
  values run). Cost on live sets: 0 (N068.0's "an Instagram post about pasta night ideas" fixed by requiring a capital).
- CHANGE 6: a ratio calc with its words a little before the marker ("twice as many[=ratio(...)]") is compared; under the
  number-word variant "refuse", an unmarked ratio word (twice, tripled, three times) is a value no cell holds.
  Prompted by audit F24, F25, skeptic K30, K45, K46, attack2 a27, f23, k06, k12. Cost: attack2's true k07 ("nearly three
  times as many", unmarked) refused.
- DECISION number words: "refuse" (the measure: made-up out 5 against 32 with "flag"; true cost +1 live repair-form
  sentence (N048.1 f1 "day three", a title's number) and attack2 k07).
- DECISION psych keeps both emitters (PSYCH and _MOTIVE): 0 live hits, 0 true hits on any set, 3 false hits.
- CHANGE 7: a typed percent is found only as a share (x100), a percent-keyed value or "N%" in code's text (attacker2
  l06 "a share of 114%" matched the count 114); the rows' own labels and parts ("2021", "evening") count as other rows'
  names before a row marker (attack2 p01 "In 2022[r3.periods[0]]", attacker2 j07, l04). Live cost 0.
- step 3 measured (measure3.py -> step3_live.txt; attack_vals.py -> attack_counts.txt; classify.py -> classes.json,
  classes_table.txt). Next: final table with hand overrides (final_split.py), tests, DESIGN 26, suite, commit.
- step 3 DONE: step3_live.txt, split_final.txt (157 made-up: 10 out; 643 misattached: 626 out; 40 policy: 25 out).
- step 4: tests/test_brain_values.py 39 passed; test_brain_cells.py re-pinned (percent) 84 passed; brain tests 475 passed;
  diff26: 9910 verdicts 0 differ, 634 answer form-modes 0 differ; planted full 332/332 78/78 and cells byte-identical to tip.
  DESIGN 26 written. Suite in 4 shards running (values/shard.sh -> values/suite_out). Then commit.
- COMMITTED 591bcd0 on brain-values-local (not pushed). Suite 6160 passed 2 skipped. suite_out and _lib removed.
