# promptdraft progress

- step 0: started, brief read. Read-only, no model call.
- step 1 DONE: read brain_v3.md, tools/provider/loop tool text, rubric, DECISIONS last section, values_progress (values check
  refuses 4 of 574 first-form sentences, so the next run sends roughly the model's first forms). Dumped all 130 answers:
  promptdraft/work/dump.txt (dump.py).
- step 2 DONE: hand labels promptdraft/work/labels.py, tally promptdraft/cause_counts.txt (tally.py). 18 good, 36 excluded
  (25 checker, 9 tool gap, 2 timeout), 76 prompt-side: M 68, T 28, O 25, A 13, P 12, W 10, H 9, L1 6, L2 4, R 4, K 3.
- finding: breakdown compare "none" in 88 of 93 breakdown calls (the prompt never says; strict schema makes it required).
- step 3 (good answers) and 4 (candidates): next.
- step 3 DONE (notes): 12 distinct good messages, 7 ask for a change/compare/yes-no; plain ones good by concentration
  (all from X, alone, almost all at 98%) or shape (peaked; by year). Kept shapes listed in work/shapes.txt.
  Noise: 20 of 65 grades and 8 of 65 means marks changed run 1 to run 2; 6 good in both; 47 means=n in both.
  compare: 90 of 93 breakdowns "none"; 38 over all history; 21 messages reach for a window-before change.
- step 4: writing 3 candidates with build.py (v3 + one diff each), checking new example sentences offline in
  full/cells/values on the prompt fixture ledgers (work/pt, imports values_tree read-only, no bytecode, no model).
- step 4 DONE: brain_v4_meaning.md (+81 tok), brain_v4_before.md (+63), brain_v4_limits.md (+58), each with a .diff;
  new example shapes checked offline: kept in cells and values (and full, except the limits leads, refused "limits").
  work/example_checks.txt. targets.txt holds the message lists and read-outs. Repo and values_tree untouched.
- step 5: findings on thin-answer rules and cuts: in the final report. Next: advisor check, then report.
- advisor fixes DONE: meaning keeps a point ("Kettle Craft came next with 32 videos, all in Tea rituals", kept in all
  three modes) instead of dropping it, "how it moved" only when the result holds the window before, fragments use the
  main example's ledger; limits keeps v3's silent list and drops "a friend's post"; T on first forms (23); targets.txt
  corrected (21 / 20 / 4 messages). Tokens: meaning +112, before +63, limits +98.
