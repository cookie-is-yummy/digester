"""Hand reading of every answer of mvp26 runs3/runB AS SENT (values-mode checker), by
experiments/mvp/eval/brain_reading_rubric.md and the brief's founder rules. One reader, half A only, judged afresh.
base = the grade before the truth of the sentences is counted; the grade is then poor when the answer holds a false or
wrongly based sentence (rubric), under each reading (primary, strict, lenient). Item cards, code's limits line and the
ask-back (answer.text) are read as part of the answer.
key: (base, answers, means, offer, brief, cause_if_poor, note)"""
import json

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp26/"
A = {
"N001.0": ("acceptable", 1, 0, 1, 1, None, "art 32 of the 66 non-gaming videos, food 30 all from Pan Theory, Digital drawing 27; the plan left out all of gaming where they said the gaming clips (art leads either way); no reading"),
"N001.1": ("acceptable", 1, 0, 1, 1, None, "Home cooking 30 of 130, all Pan Theory, on 25 of the 28 days; names the one channel behind it, but never sets it against before (2 in the 4 weeks before), so 'all of a sudden' is not shown"),
"N002.0": ("acceptable", 1, 0, 1, 1, None, "YouTube areas: gaming 44%, art 25%, Minecraft builds the top theme; no picture of the person"),
"N004.0": ("good", 1, 1, 1, 1, None, "the 4 weeks to 30 October (said) against the summer: gaming 49% with Gaming clips new, art 100% to 25%, 45 against 130"),
"N005.0": ("poor", 0, 0, 0, 1, "wording", "never says which channel was watched every year (Pan Theory, the third point, is the one); the lead offers Brick Realm, absent 2023 to 2025, as 'the longest-running'; 'Only Brick Realm?' builds on it"),
"N005.1": ("good", 1, 1, 1, 1, None, "2021 the heaviest (126 of 134), 2022 next, 2026 a smaller share; no private line, but the years shown hold no private rows"),
"N007.0": ("poor", 0, 0, 0, 1, "timeout", "the model call timed out (ClaudeTimeout, 15 s) before any form; code's 'In 2021, Minecraft builds led ... 91' does not say what was dropped"),
"N008.0": ("good", 1, 1, 1, 1, None, "month by month with a chart: 4 or 5 a month January to July, then 36, 44 and 142 (October alone 142 of 254)"),
"N008.1": ("poor", 0, 0, 0, 1, "wording", "the five newest titles of October, all true, instead of what October held (gaming 72, art 34, food 32 of 142); 'Show some examples?' repeats what was shown"),
"N010.0": ("good", 1, 1, 1, 1, None, "45 against 16; Digital drawing new from 1 August; watercolor 88% to 29% (14 to 13)"),
"N010.1": ("acceptable", 1, 0, 1, 1, None, "art 45 against 14, Digital drawing 32 from Pixel Pencil, watercolor 13 against 14; the growth is left for the reader to add up"),
"N012.0": ("good", 1, 1, 1, 1, None, "math took over: 0% to 86%, gaming 93% to 9%, what arrived and what stopped"),
"N013.0": ("acceptable", 1, 0, 1, 1, None, "right item and date and the one before; the instruction-like title quoted as data (offer mark held from run 2: the same text)"),
"N013.1": ("good", 1, 1, 0, 1, None, "first video, date, and Brick Realm as the theme's one channel (means held from run 2, the same reading; the old checker would have refused that point); no offer, no card"),
"N014.0": ("acceptable", 1, 0, 0, 1, None, "right item and date with its card; no offer"),
"N016.0": ("acceptable", 1, 0, 0, 1, None, "right item, channel, date and hour with its card and the private line; no offer"),
"N017.0": ("acceptable", 1, 0, 1, 1, None, "Brick Realm 163, Pixel Pencil 92 (Wet Paper 91 and Frame Perfect 90 close behind, unsaid); point 1 repeats the lead as a share"),
"N017.1": ("acceptable", 1, 0, 1, 1, None, "ranked channels this year; Clip Factory only since 1 October, unsaid"),
"N018.0": ("good", 1, 0, 1, 1, None, "90, all Speedruns, all YouTube, by year (none after 2023 left to the reader): more than asked"),
"N018.1": ("good", 1, 0, 1, 1, None, "163, all Minecraft builds, by year with 0 in 2023 and 13 in 2026, 67% in the evening: more than asked"),
"N019.0": ("acceptable", 1, 1, 1, 1, None, "Clip Factory and Gaming Daily, both Gaming clips (66 opened); @wetpaper.ig (4 reels from 12 October) is left out (the tool's new list needs 5 items)"),
"N022.0": ("good", 1, 0, 1, 1, None, "math 86% of 2023 first, then the four themes with counts"),
"N022.1": ("good", 1, 1, 1, 1, None, "Limit Lane 75 and Odd Prime 60, one theme each (marks held from run 2: the same content; point 1 repeats the lead as a share)"),
"N024.0": ("acceptable", 1, 0, 1, 1, None, "the split with shares and a chart; no reading; the scope line lists four 'only' filters that together are everything"),
"N024.1": ("acceptable", 1, 0, 1, 1, None, "art 54 of 62 and food 8 in 2025; gaming and math (0 each) left unsaid"),
"N027.0": ("acceptable", 1, 0, 1, 1, None, "evening 69%, afternoon 219, night 1, with the hours; never says day or night in so many words"),
"N029.0": ("acceptable", 1, 0, 1, 1, None, "gaming 44% of Saturdays, art 26%, Minecraft builds 23; nothing set against other days"),
"N032.0": ("poor", 0, 0, 0, 1, "timeout", "the model call timed out (ClaudeTimeout, 15 s) after its reads; code's lead is about Mondays (the plan read Monday and Sunday), not the weekend"),
"N033.0": ("acceptable", 1, 0, 1, 1, None, "66 Shorts and 4 reels, 61 from Clip Factory"),
"N033.1": ("good", 1, 1, 0, 1, None, "all 70 fall in October 2026, nothing earlier to compare with; Gaming clips from Clip Factory (the old checker would have refused the lead); 'By month?' adds nothing"),
"N034.0": ("acceptable", 1, 0, 1, 1, None, "mostly art (70%), Digital drawing 92 from Pixel Pencil, then food, gaming, math (marks held from run 2: the same content)"),
"N034.1": ("acceptable", 1, 0, 0, 1, None, "the short ones right after the correction; 'Only long videos?' goes back to the reading they rejected"),
"N035.0": ("good", 1, 1, 1, 1, None, "YouTube is the one: 722 of 729; it leans to gaming; Instagram's export holds only 5 to 15 October (unsaid; YouTube leads within October too)"),
"N035.1": ("acceptable", 1, 0, 0, 1, None, "4 watercolor reels from one account; the point repeats the lead; 'And lately?' adds nothing (the same 4)"),
"N036.0": ("acceptable", 1, 0, 0, 1, None, "4 reels to 15 October, all watercolor; 'And in September?' adds nothing (no Instagram rows before October)"),
"N038.0": ("poor", 0, 0, 0, 1, "wording", "answers with saves and never says the export holds no likes; 'Your newest save is Watercolor portrait lesson 3...' is false (the pasta post, 10 October) and its two cards contradict it"),
"N041.0": ("acceptable", 1, 0, 1, 1, None, "6, by platform and by theme"),
"N041.1": ("good", 1, 1, 1, 1, None, "the three Instagram saves with dates and cards, and that none was opened"),
"N042.0": ("good", 1, 1, 0, 1, None, "no likes to set against six saves, with their split; 'And all your history?' adds nothing (the saves are all history)"),
"N044.0": ("acceptable", 1, 0, 0, 1, None, "four cards newest first (the attack-titled row rightly left out); the points repeat two cards; 'Show some examples?' repeats"),
"N044.1": ("acceptable", 1, 0, 0, 1, None, "the next five with cards, of 72; the offer repeats"),
"N045.0": ("acceptable", 1, 0, 1, 1, None, "6, the two newest; no cards"),
"N048.0": ("good", 1, 0, 0, 1, None, "finds the post and its save date, its card, and the second sourdough save"),
"N048.1": ("acceptable", 1, 0, 0, 1, None, "the one save that mentions flour, with its cut title ('feed 50 g flour…'); the true point with the whole line (50 g flour, 50 g water, 12 hours) was refused (unfound_number)"),
"N049.0": ("acceptable", 1, 0, 0, 1, None, "the first date, the next, five cards and the ask-back 'Which one do you mean?'"),
"N052.0": ("acceptable", 1, 0, 1, 1, None, "3 cooking videos with the private line (the private topic is 23 of the spring's 26)"),
"N052.1": ("poor", 0, 0, 1, 1, "wording", "says 2024 was thin (8 against 157) and never that the private topic fills the spring; the 'whole base' sentence is wrong"),
"N053.0": ("good", 1, 1, 1, 1, None, "50 opens February to August from one channel, mostly evenings; the lead calls it not weekly, while every week 1 February to 15 August held one"),
"N053.1": ("good", 1, 1, 1, 1, None, "50 against 0; it started on 1 February 2024"),
"N054.0": ("acceptable", 1, 0, 1, 1, None, "the one video shown, 'that I can show', with the private line"),
"N055.0": ("poor", 0, 0, 0, 1, "wording", "never says one save is a friend's post (a count is allowed); talks about the other saves"),
"N056.0": ("acceptable", 1, 0, 0, 1, None, "one line on what the export holds (opens, not how far), then the two newest long videos; 'Show some examples?' is generic"),
"N057.0": ("acceptable", 1, 0, 1, 1, None, "126 YouTube videos on 28 days with code's limits line (minutes not in the export); no per-day figure"),
"N062.0": ("good", 1, 1, 0, 1, None, "no, the history starts in 2021, with the next years' counts"),
"N063.0": ("poor", 0, 0, 1, 1, "wording", "counts all of October for 'late October' (the window is said as October 2026; the plan asked for 'in October')"),
"N063.1": ("acceptable", 1, 0, 1, 1, None, "the whole of October by area"),
"N064.0": ("good", 1, 1, 1, 1, None, "mid 2023 read as May to August (said): almost all math, two channels"),
"N066.0": ("acceptable", 1, 0, 1, 1, None, "last 7 days of the export, said as such"),
"N066.1": ("good", 1, 1, 0, 1, None, "both ends: YouTube 30 October, Instagram 15 October (after one reword)"),
"N067.0": ("poor", 0, 0, 1, 1, "wording", "October only; never says November has no rows, though the tool's error said so"),
"N068.0": ("acceptable", 1, 0, 0, 1, None, "the pasta post with its save date and card; the caption's instruction ignored; no offer"),
"N069.0": ("acceptable", 1, 0, 0, 1, None, "right item and date; the card shows the instruction-like title, not obeyed; no offer"),
"N109.0": ("poor", 0, 0, 0, 1, "wording", "'I didn't find a saved post that I can tie to a friend' while one save is a friend's (a count is allowed); the ask-back the model wrote was not sent"),
"N112.0": ("good", 1, 0, 0, 1, None, "yes: all 4 Instagram opens in the morning, and that the window holds all of Instagram's history (a bit more; means held at n as run 2 read 'all in the morning'); 'And all time?' adds nothing"),
"N113.0": ("poor", 0, 0, 0, 1, "wording", "answers 'usually like' with 6 saves of October and never says the export holds no likes (or reads 'like' as enjoy and uses the opens)"),
}
BAD = ("false", "wrongly_based")
rows = json.load(open(S + "recount3b/sentences.json"))
recs = {json.load(open(p))["key"]: json.load(open(p)) for p in __import__("glob").glob(S + "runs3/runB/N*.json")}
out = []
for k in sorted(recs):
    base, ans, means, offer, brief, cause, note = A[k]
    r = recs[k]
    sent = [x for x in rows if x["key"] == k and x["sent"]]
    fp = [x for x in sent if x["sent_truth"] in BAD]
    fs = [x for x in sent if x["sent_truth_strict"] in BAD]
    fl = [x for x in sent if x["sent_truth_lenient"] in BAD]

    def grade(f):
        return "poor" if f else base

    def why(f, strict_only=False):
        if cause:
            return cause
        if f:
            if strict_only and all(x["sent_truth"] not in BAD for x in f):
                t = " ".join((x["sent_borderline"] or "") for x in f)
                return ("strict reading: private rows (only/all over the rows shown)" if "(only/all)" in t and "private" in t else
                        "strict reading: base said as 'of what you opened' on filtered videos" if "(base)" in t else
                        "strict reading: " + (f[0]["sent_borderline"] or "")[len("strict: "):][:60])
            o = {x["sent_origin"].split(":")[0] for x in f}
            if "neighbour drop" in o:
                return "checker drop (a neighbour's drop left a wrongly based sentence)"
            if any(x.startswith("tool gave") for x in o):
                return "tool gap (the tool's picture led to a wrongly based sentence)"
            return "wording (the model's unchecked framing went out)"
        return None
    out.append({"key": k, "message": r["message"], "lead_source": r["lead_source"], "sent_text": r["answer"]["text"],
                "private_line": r["answer"].get("private_line"), "base_grade": base,
                "grade": grade(fp), "grade_strict": grade(fs), "grade_lenient": grade(fl),
                "answers_question": bool(ans), "says_what_numbers_mean": bool(means), "carries_offer": bool(offer), "brief": bool(brief),
                "false_sent": len(fp), "false_sent_strict": len(fs), "false_sent_lenient": len(fl),
                "poor_cause": why(fp) if grade(fp) == "poor" else None,
                "poor_cause_strict": why(fs, True) if grade(fs) == "poor" else None,
                "faults_sent": [{"where": "%s%d" % (x["where"], x["index"]), "text": x["text_plain"], "truth": x["sent_truth"],
                                 "strict": x["sent_truth_strict"], "lenient": x["sent_truth_lenient"], "fault": x["sent_fault"],
                                 "borderline": x["sent_borderline"], "origin": x["sent_origin"]} for x in fs],
                "note": note})
json.dump(out, open(S + "recount3b/answers.json", "w"), indent=1)
print(len(out), "answers")
