"""compare.txt: mvp25 recount2 (run 2, cells-only checker) against mvp26 recount3b (run B, values-mode checker),
message by message. Both are fresh half A, the same 65 keys, prompt v3. Run after tally_b.py:
PYTHONDONTWRITEBYTECODE=1 python3 compare_b.py"""
import json
from collections import Counter

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
oA = {a["key"]: a for a in json.load(open(S + "mvp25/recount2/answers.json"))}
nA = {a["key"]: a for a in json.load(open(S + "mvp26/recount3b/answers.json"))}
oR = json.load(open(S + "mvp25/recount2/sentences.json"))
nR = json.load(open(S + "mvp26/recount3b/sentences.json"))
BAD = ("false", "wrongly_based")
G = {"poor": 0, "acceptable": 1, "good": 2}
assert sorted(oA) == sorted(nA), "the two rounds must hold the same keys"
out = []
p = out.append

WHY = {  # run 2's poor answers: why each moved or stayed (hand reading of run B's sent answer)
    "N001.1": "now acceptable: the lead names Pan Theory as the one channel (30 of 130, on 25 of 28 days); run 2's drop of that point is gone. It still never sets October against before (2 in the 4 weeks before)",
    "N004.0": "now good: the model answered in time (run 2 timed out): the 4 weeks to 30 October against the summer, Gaming clips new, art 100% to 25%",
    "N005.0": "stayed poor, new cause: run 2's true lead (Pan Theory in every year) was refused (two_results) and code's 'Brick Realm led' went out; this time the model led with Brick Realm as 'the longest-running one' (absent 2023 to 2025; wrongly based) and never said Pan Theory is in every year",
    "N008.1": "stayed poor, new cause: run 2 ran out of time; this time it answered with the five newest titles of October instead of what October held",
    "N019.0": "now acceptable: no closing 'the new channels you opened were' list; 'Both are gaming channels' is strict only; @wetpaper.ig still left out (the tool's list)",
    "N027.0": "now acceptable: the same true day/night sentences run 2 refused in both forms (uncited_number, unknown_name, number) went out",
    "N033.1": "now good: the true lead (all 70 in October 2026) run 2 refused twice (other_period) went out",
    "N035.0": "now good: the true lead (722 YouTube, 7 Instagram) run 2 refused twice (number) went out",
    "N044.0": "now acceptable: 'Here are a few ... newest first' over the same four cards; run 2's 'Here are 5' over 4 is gone",
    "N048.1": "now acceptable: the lead (the one save that mentions flour, its cut title) went out; the point with the whole line was still refused (unfound_number, values mode)",
    "N049.0": "now acceptable: the first date, the next, five cards and the ask-back; run 2's 'shows up again on 8 and 13 June' as a complete list is gone; 'part 6 of the series' is cannot prove (strict)",
    "N052.1": "stayed poor, new cause: run 2's forms were refused and code's bare totals went out; this time the model's 'the gap is 2024' (reads past the private line) and a wrong 'whole base' went out",
    "N053.0": "stayed poor, new cause: run 2 refused the true 'February to August' point; it went out this time, but the lead's 'not a steady weekly habit' is wrongly based (every week 1 February to 15 August held one). Lenient: good",
    "N055.0": "stayed poor, same cause: never says one save is a friend's post",
    "N056.0": "now acceptable: the true lead (the history records opens, not how far) run 2 refused twice (uncited_claim) went out, then the two newest long videos",
    "N067.0": "stayed poor, same cause: never says November has no rows",
    "N069.0": "now acceptable: no claim that the title is cut off in the history; the item, date and channel",
    "N109.0": "stayed poor, same cause: mostly what it cannot find; no count of the friend's save; the ask-back was not sent",
    "N113.0": "stayed poor, same cause: answers with saves and never says the export holds no likes",
}
WORSE = {
    "N007.0": "good to poor: the model call timed out (ClaudeTimeout at 15 s, after one read) and code's true 'Minecraft builds led 2021' went out; run 2's model answer (Minecraft builds 68% to 5%, Speedruns to 0%) was good. Not the checker",
    "N032.0": "acceptable to poor: the model call timed out (ClaudeTimeout at 15 s) after reading Monday, Sunday and all; code led with Mondays. Not the checker",
    "N038.0": "acceptable to poor: a FALSE sentence went out ('Your newest save is Watercolor portrait lesson 3...'; it is the pasta post); the cells checker would have refused it (wrong_name@cells); values mode's row-name rule misses an unquoted title of another row. And the answer no longer says the export holds no likes",
    "N063.0": "acceptable to poor: the plan asked for 'in October' and counted all of October for 'late October' (run 2 read 21 to 30 October). Not the checker",
}


def heads(A, R):
    sn = [r for r in R if r["sent"] and r.get("sent_truth") != "no_claim"]
    f1 = [r for r in R if r["form"] == "first"]
    tr = [r for r in R if r["form"] not in ("code", "plain")]
    return {
        "first-form sentence rows written": len(f1),
        "false written (first forms)": sum(r["truth"] == "false" for r in f1),
        "wrongly based written, primary (first forms)": sum(r["truth"] == "wrongly_based" for r in f1),
        "true sentences refused, first forms": sum(r["truth"] == "true" and r["verifier_kept"] is False for r in f1),
        "true sentences refused, all forms": sum(r["truth"] == "true" and r["verifier_kept"] is False for r in tr),
        "repair forms": len({r["key"] for r in R if r["form"] == "repair"}),
        "sent sentences with a claim": len(sn),
        "false sent": sum(r["sent_truth"] == "false" for r in sn),
        "false or wrongly based sent, firm": sum(r["sent_truth_lenient"] in BAD for r in sn),
        "false or wrongly based sent, primary": sum(r["sent_truth"] in BAD for r in sn),
        "false or wrongly based sent, strict": sum(r["sent_truth_strict"] in BAD for r in sn),
        "answers with one, firm": len({r["key"] for r in sn if r["sent_truth_lenient"] in BAD}),
        "answers with one, primary": len({r["key"] for r in sn if r["sent_truth"] in BAD}),
        "answers with one, strict": len({r["key"] for r in sn if r["sent_truth_strict"] in BAD}),
        "good / acceptable / poor": "%d / %d / %d" % tuple(sum(a["grade"] == g for a in A.values()) for g in ("good", "acceptable", "poor")),
        "  strict": "%d / %d / %d" % tuple(sum(a["grade_strict"] == g for a in A.values()) for g in ("good", "acceptable", "poor")),
        "  lenient": "%d / %d / %d" % tuple(sum(a["grade_lenient"] == g for a in A.values()) for g in ("good", "acceptable", "poor")),
        "poor before any truth count": sum(a["base_grade"] == "poor" for a in A.values()),
        "answers the question": sum(a["answers_question"] for a in A.values()),
        "says what the numbers mean": sum(a["says_what_numbers_mean"] for a in A.values()),
        "offer worth taking": sum(a["carries_offer"] for a in A.values()),
        "brief": sum(a["brief"] for a in A.values()),
        "lead from code or a plain line": sum(a["lead_source"] in ("code", "plain") for a in A.values()),
        "poor causes": dict(Counter((a["poor_cause"] or "").split(" (")[0] for a in A.values() if a["grade"] == "poor")),
    }


p("mvp25 recount2 (run 2: cells-only checker) against mvp26 recount3b (run B: values-mode checker): fresh half A, 65 messages, the same keys, prompt v3.")
p("Both are hand recounts from the rows of tests/brain_library.py by different readers, with the same method and tiers; marks held where the sent text is the same (notes section 7).")
p("Run B is one live run; the noise floor (run A against run B, the same code) is another agent's recount and was not opened here.")
p("The grade, means and offer rows compare readers as well as runs: marks were held only where the sent text is the same (N013.0 offer, N013.1 means, N022.1, N034.0, N112.0 means);")
p("where the text differs, the mark is this reader's. N053.0 both ways: with the earlier habit tier (cannot prove, strict only) run B has 4 primary faults sent in 3 answers and 11 poor.")
p("")
p("== 1. Headline ==")
h2, hb = heads(oA, oR), heads(nA, nR)
p("  %-48s %18s %18s" % ("", "run 2 (cells)", "run B (values)"))
for k in h2:
    p("  %-48s %18s %18s" % (k, h2[k], hb[k]) if not isinstance(h2[k], dict) else f"  {k:48s} run 2 {h2[k]}\n  {'':48s} run B {hb[k]}")
p("")
p("== 2. Message by message (grade primary; lead source) ==")
moves = Counter()
for k in sorted(nA):
    a, b = oA[k], nA[k]
    d = G[b["grade"]] - G[a["grade"]]
    mv = "better" if d > 0 else "worse" if d < 0 else "same"
    moves[mv] += 1
    p(f"  {k:7s} {a['grade']:10s} -> {b['grade']:10s} {mv:6s}  lead {a['lead_source']:18s} -> {b['lead_source']}")
p(f"  moves: {dict(moves)}")
p("")
p("== 3. Run 2's 19 poor answers ==")
P2 = [k for k in sorted(oA) if oA[k]["grade"] == "poor"]
assert len(P2) == 19, len(P2)
for lab, f in (("now good", lambda k: nA[k]["grade"] == "good"), ("now acceptable", lambda k: nA[k]["grade"] == "acceptable"),
               ("still poor", lambda k: nA[k]["grade"] == "poor")):
    K = [k for k in P2 if f(k)]
    p(f"  {lab}: {len(K)} {K}")
for k in P2:
    p(f"    {k} [{oA[k]['grade']} ({oA[k]['poor_cause']}) -> {nA[k]['grade']}/{nA[k]['grade_strict']}/{nA[k]['grade_lenient']}] {WHY[k]}")
p("  Of run 2's 9 poor answers caused by the checker (a refused true sentence or the code lead that replaced one): " +
  ", ".join(f"{k} -> {nA[k]['grade']}" for k in P2 if (oA[k]["poor_cause"] or "").split(" (")[0] in ("checker drop", "code lead")))
p("")
p("== 4. Answers that got worse ==")
for k in sorted(nA):
    if G[nA[k]["grade"]] < G[oA[k]["grade"]]:
        p(f"  {k} [{oA[k]['grade']} -> {nA[k]['grade']}] {WORSE[k]}")
p("")
p("== 5. What the old (cells) checker would have refused but values mode let out, sentence by sentence ==")
p("  A sentence of run B carries code@cells when run 2's checker gives it that code. Sent sentences only; truth primary/strict/lenient.")
L5 = [r for r in nR if r["sent"] and r["form"] not in ("code", "plain") and any(f.endswith("@cells") for f in r["flags"])]
tally = Counter("faulty" if r["sent_truth"] in BAD else "cannot prove" if r["sent_truth"] == "cannot_prove" else
                "strict only" if r["sent_truth_strict"] in BAD else "true" for r in L5)
p(f"  {len(L5)} sent sentences in {len({r['key'] for r in L5})} answers: {dict(tally)}")
for r in L5:
    v = r["sent_truth"] + "/" + r["sent_truth_strict"] + "/" + r["sent_truth_lenient"]
    p(f"    {r['key']} {r['where']}{r['index']} {v:38s} [{', '.join(f[:-6] for f in r['flags'] if f.endswith('@cells'))}] {r['text_plain']}")
p("  The faulty ones: N038.0 point 0 is false and wrong_name is already a values code (a hole in values mode, not a flag to restore);")
p("  N005.0 lead (word:running), N052.1 lead (filler) and N052.1 point 1 (uncited_number, free_number) are wrongly based, each caught by a word or number rule that also flags many true sentences (table in numbers.txt section 9).")
p("  Faulty sentences that carried no @cells flag at all: N053.0 lead (only unsupported@full). Faults with no flag of any mode: none of the 5 primary faults; 2 strict-only ones (N005.0 point 0, N052.0 point 0).")
p("")
p("== 6. Sent faults of run 2 against run B, by kind ==")
for lab, R in (("run 2", oR), ("run B", nR)):
    sn = [r for r in R if r["sent"] and r["sent_truth"] in BAD]
    p(f"  {lab} primary: " + "; ".join(f"{r['key']} {r['where']}{r['index']} {r['sent_truth']}: {(r['sent_fault'] or '')[:90]}" for r in sn))
open(S + "mvp26/recount3b/compare.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out[:40]))
