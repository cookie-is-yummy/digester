import json, glob, sys
d = sys.argv[1]
for p in sorted(glob.glob(d + '/N*.json')):
    r = json.load(open(p))
    print('=' * 100)
    print(r['key'], '|', r['message'], '| screen:', r.get('screen'))
    for c in r['calls']:
        a = dict(c['args'])
        res = c.get('result') or {}
        m = res.get('meta', {})
        print('  CALL', c.get('rid'), c['name'], json.dumps(a)[:500])
        print('     window:', m.get('window_said'), '| base:', m.get('base'), '| filters:', m.get('filters_said'), '| hidden:', m.get('hidden'), '| complete:', m.get('complete'), '| err:', res.get('error') or (res if res.get('is_error') else None))
    for fi, (f, v) in enumerate(zip(r['forms'], r['verdicts'])):
        print('  FORM', fi, 'understood:', f.get('understood'), '| private_line:', v.get('private_line'), '| form_error:', v.get('form_error'))
        for o in v['outcomes']:
            print('    [%s %d] kept=%s %s %s' % (o['where'], o['index'], o['kept'], o['reasons'], o['details']))
            print('       ', o['text'])
            print('        flags:', [f['code']+'@'+f['mode'] for f in o.get('flags') or []])
            print('        cells:', o['cells'])
        print('    offers:', [(x['kind'], x.get('ref'), x.get('window_words')) for x in f.get('offers') or []], 'items:', f.get('items'), 'outside:', f.get('outside'), 'ask_back:', f.get('ask_back'), 'hand_back:', f.get('hand_back'), 'setup:', f.get('setup'), 'chart:', bool(f.get('chart')))
    print('  lead_source:', r['lead_source'], '| code_lead:', json.dumps(r.get('code_lead'))[:600])
    print('  SENT:', (r.get('answer') or {}).get('text'))
