"""Three columns: run 2 (cells), run A (values), run B (values). Same definitions for all three. usage:
python3 table3.py RUN2 RUNA RUNB"""
import glob
import json
import os
import sys


def pct(xs, q):
    xs = sorted(xs)
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)


def fig(run):
    recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(run, "N*.json"))]
    s = json.load(open(os.path.join(run, "summary.json"), encoding="utf-8"))
    f = {}
    ls = s["lead_source"]
    f["lead: model"] = ls.get("model", 0)
    f["lead: model_after_repair"] = ls.get("model_after_repair", 0)
    f["lead: code"] = ls.get("code", 0)
    f["lead: plain"] = ls.get("plain", 0)
    g4 = s["G4_sentences"]
    f["sentences written (first form)"] = g4["written"]
    f["kept first pass"] = g4["kept_first_pass"]
    f["kept after reword (G4 kept_sent)"] = g4["kept_sent"]
    f["model lead + points in the answers sent"] = sum(len(((r.get("answer") or {}).get("points") or []))
                                                      + (1 if r["lead_source"].startswith("model") else 0) for r in recs)
    f["missing first pass"] = g4["missing_first_pass"]
    f["missing after reword"] = g4["missing_after_repair"]
    f["rewords asked"] = s["repairs"]
    f["sentences refused (all forms)"] = sum(1 for r in recs for v in r.get("verdicts") or []
                                             for o in v.get("outcomes") or [] if not o.get("kept"))
    f["sentences refused (first form)"] = sum(1 for r in recs for v in (r.get("verdicts") or [])[:1]
                                              for o in v.get("outcomes") or [] if not o.get("kept"))
    fl = [x for r in recs for x in r.get("flags") or []]
    f["flags logged (code@mode rows)"] = len(fl) if s.get("check") == "values" else "n/a (cells)"
    g2 = s["G2_understood"]
    f["understood share_strict_v1"] = f"{g2['understood_strict_v1']}/{s['messages']} = {g2['share_strict_v1']}"
    f["understood share (accepted)"] = f"{g2['understood']}/{s['messages']} = {g2['share']}"
    f["understood share_gate_fields"] = g2["share_gate_fields"]
    f["G2 verdicts u/o/d"] = f"{g2['understood']}/{g2['other_plan']}/{g2['differs']}"
    g5 = s["G5_seconds"]
    secs = [r["seconds"] for r in recs]
    f["seconds median"] = g5["median"]
    f["seconds p90"] = g5["p90"]
    f["seconds max"] = g5["max"]
    f["over 8 s / over 11 s"] = f"{sum(x > 8 for x in secs)} / {sum(x > 11 for x in secs)}"
    ev = s["events"]
    f["time_up / no_time_for_repair"] = f"{ev.get('time_up', 0)} / {ev.get('no_time_for_repair', 0)}"
    f["provider errors (timeouts)"] = f"{ev.get('provider_error', 0)} " + str({r['key']: r['error'] for r in recs
                                                                               if r.get('error')})
    nreq = [r["n_requests"] for r in recs]
    f["requests total"] = sum(nreq)
    f["requests per message mean/median/max"] = f"{s['requests']['per_message_mean']} / {pct(nreq, .5)} / {max(nreq)}"
    g6 = s["G6_cost"]
    costs = [100 * r["cost_usd"] for r in recs]
    f["cost per message mean/median/max (cents)"] = f"{g6['mean_cents']} / {pct(costs, .5)} / {round(max(costs), 3)}"
    f["cost total by records ($)"] = g6["total_usd"]
    led = s.get("ledger") or {}
    f["cost by ledger ($), rows"] = f"{led.get('brain_eval_usd')}, {led.get('rows_added')}"
    q = s["requests"]
    f["tokens out / cache read / cache write"] = (f"{q['output_tokens']} / {q['cache_read_input_tokens']} / "
                                                  f"{q['cache_creation_input_tokens']}")
    calls = [c for r in recs for c in r["calls"]]
    f["tool errors / read calls"] = f"{sum(1 for c in calls if (c.get('result') or {}).get('is_error'))} / {len(calls)}"
    f["private line / no offer"] = (f"{sum(1 for r in recs if (r.get('answer') or {}).get('private_line'))} / "
                                    f"{sum(1 for r in recs if not (r.get('answer') or {}).get('offers'))}")
    f["auditor hints (messages, hints)"] = f"{s['auditor_hints']['messages_with_hints']}, {s['auditor_hints']['hints']}"
    return f


cols = [fig(x) for x in sys.argv[1:4]]
w = max(len(k) for k in cols[0])
print(f"{'':{w}}  {'run 2 (cells)':>26}  {'run A (values)':>26}  {'run B (values)':>26}")
for k in cols[0]:
    print(f"{k:{w}}  " + "  ".join(f"{str(c.get(k)):>26}" for c in cols))
