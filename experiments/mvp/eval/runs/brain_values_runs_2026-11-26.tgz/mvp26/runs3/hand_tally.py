# hand read of the proxy-listed sentences: S = a claim the other run's answer does not make;
# F = the same claim with a figure added or dropped. Proxy hits judged as wording only are left out.
H = {
"N001.0": ("F1", "S1"), "N001.1": ("S3", "S3"), "N002.0": ("F1", "F1"), "N004.0": ("F1", ""),
"N005.0": ("S2", "S3"), "N005.1": ("S1", "S2"), "N007.0": ("S2 F1", ""), "N008.0": ("", "F1"),
"N008.1": ("S3", "S2"), "N010.0": ("", "F1"), "N012.0": ("F1", "S1 F1"), "N013.0": ("S1", "F1"),
"N016.0": ("", "F1"), "N017.0": ("S1", "F1"), "N017.1": ("S1", ""), "N019.0": ("S1 F1", ""),
"N022.0": ("", "S1 F1"), "N022.1": ("S1", ""), "N024.0": ("F1", "F1"), "N024.1": ("S3", "S1"),
"N027.0": ("S1 F2", ""), "N029.0": ("F1", ""), "N032.0": ("S4", "S1"), "N033.0": ("S1", "F1"),
"N034.0": ("S1", "S2"), "N034.1": ("F2", "S1"), "N035.0": ("S1", "S1"), "N038.0": ("S1 F1", "S1 F1"),
"N044.0": ("S1 F1", ""), "N044.1": ("S2", ""), "N045.0": ("S1 F1", "S1"), "N048.1": ("", "S1"),
"N049.0": ("S1", "S1"), "N052.0": ("F1", ""), "N052.1": ("S3", "S1"), "N053.0": ("S1", "S1"),
"N053.1": ("S1", ""), "N055.0": ("F1", ""), "N056.0": ("", "S1"), "N057.0": ("S2", "S1"),
"N062.0": ("S1 F1", "S1"), "N063.0": ("S3", "S3"), "N063.1": ("S1 F1", "S1 F2"), "N064.0": ("F1", ""),
"N066.0": ("S1", "S1 F1"), "N066.1": ("", "S1"), "N067.0": ("", "F1"), "N109.0": ("S1", ""),
"N112.0": ("S1", "F1"), "N113.0": ("", "F1"),
# added on reading the 15 messages the proxy left alone (lower-case topics and words the proxy cannot see):
"N018.0": ("S1", "S1"), "N042.0": ("", "S2"), "N068.0": ("S1", ""),
}
def n(s, c):
    return sum(int(x[1:]) for x in s.split() if x[0] == c)
for side, i in (("A", 0), ("B", 1)):
    print(side, "S", sum(n(v[i], "S") for v in H.values()), "F", sum(n(v[i], "F") for v in H.values()))
print("messages with any S or F:", len(H), "; with an S on either side:", sum(1 for v in H.values() if "S" in v[0] + v[1]))
print("messages with the same substance throughout: ", 65 - len(H))
