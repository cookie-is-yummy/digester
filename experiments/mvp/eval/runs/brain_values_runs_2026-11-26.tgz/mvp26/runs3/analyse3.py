"""Figures of one saved run folder (records + summary.json), no model call. Same definitions as mvp25 analyse.py,
plus flags (code@mode), refusals by code, and a check that every refusal is in VALUES_REFUSE.
usage: python3 analyse3.py TREE RUN"""
import glob
import json
import os
import sys

tree, run = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(tree, "experiments"))
from mvp.brain import verify as V  # noqa: E402

files = [f for f in glob.glob(os.path.join(run, "N*.json"))]
recs = [json.load(open(f, encoding="utf-8")) for f in files]
recs.sort(key=lambda r: (r["key"].split(".")[0], int(r["key"].split(".")[1])))
s = json.load(open(os.path.join(run, "summary.json"), encoding="utf-8"))
out = []
p = out.append


def pct(xs, q):
    xs = sorted(xs)
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)


def sent_lines(r):
    a = r.get("answer") or {}
    return (a.get("text") or "(nothing)").split("\n")


p(f"records: {len(recs)}; summary messages: {s['messages']}; skipped: {s['skipped']}; check: {s['check']}")
p(f"checks in records: {sorted({r.get('check') for r in recs})}; halves: {sorted({r.get('half') for r in recs})}; "
  f"prompt: {s['settings'].get('prompt_version')}")
p(f"lead_source: {s['lead_source']}")
g4 = s["G4_sentences"]
p(f"sentences: written {g4['written']}, kept first pass {g4['kept_first_pass']}, kept sent {g4['kept_sent']}, "
  f"missing first pass {g4['missing_first_pass']}, missing after repair {g4['missing_after_repair']}")
p(f"repairs: {s['repairs']}; decomposition: " + json.dumps(s["decomposition"]))
rep = [r for r in recs if r.get("repair_message")]
end = {}
for r in rep:
    end[r["lead_source"]] = end.get(r["lead_source"], 0) + 1
p(f"repairs by how the answer ended: {end}; messages: {[r['key'] for r in rep]}")
g2 = s["G2_understood"]
p(f"G2: understood {g2['understood']}, other_plan {g2['other_plan']}, differs {g2['differs']}, "
  f"no_hand_plan {g2['no_hand_plan']}; share_strict_v1 {g2['share_strict_v1']} "
  f"(understood_strict_v1 {g2['understood_strict_v1']}); share (accepted readings) {g2['share']}; "
  f"share_gate_fields {g2['share_gate_fields']}")
g5 = s["G5_seconds"]
secs = [r["seconds"] for r in recs]
p(f"seconds (parallel {s['settings'].get('parallel')}): median {g5['median']}, p90 {g5['p90']}, max {g5['max']}, "
  f"retries {g5['retries']}; over 8 s {sum(x > 8 for x in secs)}, over 11 s {sum(x > 11 for x in secs)}, "
  f"at/over 15 s {sum(x >= 15 for x in secs)}")
p(f"events: {s['events']}; by message: " + json.dumps({r['key']: r['events'] for r in recs if r.get('events')}))
p("turn errors (record 'error'): " + json.dumps({r["key"]: r["error"] for r in recs if r.get("error")}))
nreq = [r["n_requests"] for r in recs]
p(f"requests per message: mean {s['requests']['per_message_mean']}, median {pct(nreq, 0.5)}, max {max(nreq)}; "
  f"distribution {dict(sorted({n: nreq.count(n) for n in set(nreq)}.items()))}; total {sum(nreq)}")
p(f"stop reasons: {s['requests']['stop_reasons']}")
p(f"tokens: in {s['requests']['input_tokens']}, out {s['requests']['output_tokens']}, cache read "
  f"{s['requests']['cache_read_input_tokens']}, cache write {s['requests']['cache_creation_input_tokens']}")
g6 = s["G6_cost"]
costs = [r["cost_usd"] for r in recs]
p(f"cost: total ${g6['total_usd']}, mean {g6['mean_cents']} cents per message, median "
  f"{pct([100 * c for c in costs], 0.5)} cents, max {round(100 * max(costs), 4)} cents "
  f"({max(recs, key=lambda r: r['cost_usd'])['key']})")
p(f"ledger: {s.get('ledger')}")
p(f"auditor hints: {s['auditor_hints']['messages_with_hints']} messages, {s['auditor_hints']['hints']} hints")
priv = sum(1 for r in recs if (r.get("answer") or {}).get("private_line"))
nooff = sum(1 for r in recs if not (r.get("answer") or {}).get("offers"))
p(f"private line shown on {priv} answers; no offer on {nooff} answers")
p("")

# flags
p("FLAGS LOGGED (refuse nothing). Counted per (sentence, code, mode); form 0 = first form, form 1 = repair form.")
fl = {}
fl_form = {0: {}, 1: {}}
sent_flagged = {0: set(), 1: set()}
base_codes = {}
for r in recs:
    for f in r.get("flags") or []:
        k = f"{f['code']}@{f['mode']}"
        fl[k] = fl.get(k, 0) + 1
        fo = f.get("form", 0)
        fl_form.setdefault(fo, {})
        fl_form[fo][k] = fl_form[fo].get(k, 0) + 1
        sent_flagged.setdefault(fo, set()).add((r["key"], f["where"], f["index"]))
        base_codes.setdefault(f["code"], set()).add((r["key"], fo, f["where"], f["index"]))
p(f"  summary flag_codes: {json.dumps(s.get('flag_codes'), sort_keys=True)}")
p(f"  flags in records: {sum(fl.values())}; distinct sentences flagged: first form {len(sent_flagged[0])}, "
  f"repair form {len(sent_flagged.get(1, set()))}")
for k, n in sorted(fl.items(), key=lambda x: (-x[1], x[0])):
    p(f"    {k}: {n} (first form {fl_form[0].get(k, 0)}, repair form {fl_form.get(1, {}).get(k, 0)})")
p("  by code, either mode (distinct sentences): " + ", ".join(
    f"{c} {len(v)}" for c, v in sorted(base_codes.items(), key=lambda x: (-len(x[1]), x[0]))))
p("")

# refusals
p("REFUSALS (sentences not kept, by verdict; verdict 0 = first form, 1 = repair form)")
ref = {}
ref_rows = []
outside = []
for r in recs:
    for vi, v in enumerate(r.get("verdicts") or []):
        for o in v.get("outcomes") or []:
            if not o.get("kept"):
                for c in o.get("reasons") or ["(no reason)"]:
                    ref[c] = ref.get(c, 0) + 1
                    if c.split(":")[0] not in V.VALUES_REFUSE:
                        outside.append((r["key"], vi, o["where"], o["index"], c))
                ref_rows.append((r["key"], vi, o["where"], o["index"], o.get("reasons"), o.get("details"),
                                 o.get("text")))
        if v.get("form_error"):
            p(f"  form error {r['key']} verdict {vi}: {v['form_error']}")
p(f"  summary dropped_reasons: {json.dumps(s.get('dropped_reasons'), sort_keys=True)}")
p(f"  by code (all verdicts): {json.dumps(ref, sort_keys=True)}")
p(f"  refusal reasons outside VALUES_REFUSE: {outside if outside else 'none'}")
for row in ref_rows:
    p(f"  {row[0]} form {row[1]} {row[2]} {row[3]}: {row[4]} details {json.dumps(row[5], ensure_ascii=False)}")
    p(f"      {row[6]}")
psy = [row for row in ref_rows if any(str(c).startswith("psych") for c in row[4] or [])]
p(f"  psych refusals: {len(psy)}")
p("")

# tool errors
p("TOOL ERRORS (every read call whose result is_error):")
nerr = ncalls = 0
tools = {}
for r in recs:
    for c in r["calls"]:
        ncalls += 1
        tools[c["name"]] = tools.get(c["name"], 0) + 1
        res = c.get("result") or {}
        if res.get("is_error"):
            nerr += 1
            p(f"  {r['key']} round {c['round']} {c['name']} args={json.dumps(c['args'], ensure_ascii=False)}")
            p(f"     error: {json.dumps({k: v for k, v in res.items() if k != 'is_error'}, ensure_ascii=False)}")
p(f"  {nerr} of {ncalls} read calls")
p(f"read calls by tool: {tools}")
p("read calls the loop did not run (tool_use with no call record):")
for r in recs:
    for i, q in enumerate(r["requests"]):
        want = [b.get("name") for b in q.get("blocks") or [] if b.get("type") == "tool_use"
                and b.get("name") != "give_answer"]
        got = [c["name"] for c in r["calls"] if c["round"] == i + 1]
        miss = list(want)
        for g in got:
            if g in miss:
                miss.remove(g)
        if miss:
            p(f"  {r['key']} request {i + 1}: not run: {miss} (events {r.get('events')})")
p("")

p("per message: key | lead_source | seconds | requests | cents | written/first/sent | repair | g2 | hints | events")
for r in recs:
    se = r["sentences"]
    p(f"  {r['key']} | {r['lead_source']} | {r['seconds']} | {r['n_requests']} | {round(100 * r['cost_usd'], 3)} | "
      f"{se['written']}/{se['kept_first_pass']}/{se['kept_sent']} | {'yes' if r.get('repair_message') else 'no'} | "
      f"{r['g2']['verdict']} | {len(r['audit']['findings'])} | {','.join(r.get('events') or [])}")
p("")
code = [r for r in recs if r["lead_source"] not in ("model", "model_after_repair")]
p(f"ANSWERS WHOSE LEAD IS NOT THE MODEL'S ({len(code)}), in full:")
for r in code:
    a = r.get("answer") or {}
    p(f"==== {r['key']} | lead_source {r['lead_source']} | error {r.get('error')} | events {r.get('events')}")
    p(f"message: {r['message']}")
    p(f"sentences record: {r['sentences']}; points in answer: {len(a.get('points') or [])}; "
      f"model lead (first form): {json.dumps(((r.get('forms') or [{}])[0] or {}).get('lead'), ensure_ascii=False)}")
    p(f"code_lead: {json.dumps(r.get('code_lead'), ensure_ascii=False)}")
    for i, v in enumerate(r.get("verdicts") or []):
        p(f"verdict {i}: lead_ok {v.get('lead_ok')} form_error {v.get('form_error')} outcomes "
          + json.dumps([{k: o.get(k) for k in ('where', 'kept', 'reasons', 'text')} for o in v.get('outcomes', [])],
                       ensure_ascii=False))
    if r.get("repair_message"):
        p(f"repair message: {r['repair_message']}")
    p("sent:")
    for line in sent_lines(r):
        p("  | " + line)
    p("")
p("FIRST 8 ANSWERS BY ID ORDER (message, then the answer as sent):")
for r in recs[:8]:
    p(f"==== {r['key']} | lead {r['lead_source']}")
    p(f"message: {r['message']}")
    p("sent:")
    for line in sent_lines(r):
        p("  | " + line)
    p("")
print("\n".join(out))
