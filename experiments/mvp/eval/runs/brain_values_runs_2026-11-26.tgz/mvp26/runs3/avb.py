"""Run A against run B, message by message (no model call). usage: python3 avb.py RUN_A RUN_B
Rules (measured, by code):
- lead source: the record's lead_source, equal or not.
- tools, two counts: (1) the read tools' names in call order equal; (2) names and args equal in call order.
- substance of a sent sentence: its signature = the sorted figures (digit runs, with % kept) and the sorted capitalised
  word runs (names) in the sentence as sent, less the first word of the sentence when it is a common opener, less
  month and weekday words (they are dated by the figures beside them). Two sentences of one message match when the
  facts differ: a sentence of A is 'unmatched' when it holds a figure or name (outside window spans) found
  nowhere in the text of B's sent answer (names case-blind),
  and the other way. This is a proxy: the unmatched sentences are listed in full for a hand read.
Sentences compared are the model's sentences as sent (lead + points) or the code/plain lead when that went out."""
import glob
import json
import os
import re
import sys

MONTHS = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
          "November", "December", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
OPENERS = {"In", "Your", "You", "The", "That", "This", "These", "Those", "Lately", "Across", "Over", "From", "Since",
           "Most", "Of", "On", "At", "By", "With", "It", "Its", "There", "Every", "Each", "All", "After", "Before",
           "During", "Then", "Next", "Recently", "Back", "Only", "Both", "A", "An", "And", "But", "So", "No", "Not",
           "Nothing", "None", "Among", "Behind", "About", "Up", "Out", "Here", "What", "When", "Where", "Which",
           "Who", "Why", "How", "Yes", "Compared", "Leaving", "Without", "Within", "Between", "Outside", "Overall",
           "Since", "Last", "This", "First", "Second", "Third", "Together", "Mostly", "Gaming", "Art", "Food"}


def load(run):
    rs = {}
    for f in glob.glob(os.path.join(run, "N*.json")):
        r = json.load(open(f, encoding="utf-8"))
        rs[r["key"]] = r
    return rs


def keyord(k):
    a, b = k.split(".")
    return (a, int(b))


def sents(r):
    a = r.get("answer") or {}
    out = []
    if a.get("lead"):
        out.append(a["lead"])
    out += [x for x in a.get("points") or [] if x]
    return out


def sig(t):
    figs = sorted(re.findall(r"\d[\d,.:]*%?", t))
    figs = [f.rstrip(".,:") for f in figs]
    words = re.findall(r"[A-Z][\w'&+-]*(?:\s+[A-Z][\w'&+-]*)*", t)
    names = []
    for i, w in enumerate(words):
        parts = [x for x in w.split() if x not in MONTHS]
        if parts and t.startswith(w) and parts[0] in OPENERS:
            parts = parts[1:]
        if parts:
            names.append(" ".join(parts))
    return (tuple(sorted(figs)), tuple(sorted(n.lower() for n in names)))


def tools(r, args=False):
    return [(c["name"], json.dumps(c["args"], sort_keys=True)) if args else c["name"] for c in r["calls"]]


A, B = load(sys.argv[1]), load(sys.argv[2])
keys = sorted(set(A) | set(B), key=keyord)
rows = []
n_lead_diff = n_tool_names = n_tool_args = 0
tot_un_a = tot_un_b = 0
msgs_sub_diff = 0
detail = []
for k in keys:
    ra, rb = A.get(k), B.get(k)
    if not ra or not rb:
        rows.append(f"{k}: missing in {'A' if not ra else 'B'}")
        continue
    la, lb = ra["lead_source"], rb["lead_source"]
    same_lead = la == lb
    ta, tb = tools(ra), tools(rb)
    taa, tba = tools(ra, True), tools(rb, True)
    same_t = ta == tb
    same_ta = taa == tba
    n_lead_diff += not same_lead
    n_tool_names += not same_t
    n_tool_args += not same_ta
    sa, sb = sents(ra), sents(rb)
    # fact-level rule: a sentence differs in substance when it holds a figure or name that the other run's whole
    # answer (all its sent sentences) does not hold. Same facts in other words or another order = same substance.
    def strip(x):
        # window framing is not counted as substance: date spans in brackets and 'up to <date>'
        x = re.sub(r"\([^)]*\d{4}[^)]*\)", " ", x)
        x = re.sub(r"up to \d{1,2} \w+ \d{4}", " ", x)
        return x
    def facts(x):
        g = sig(strip(x))
        out = {("f", f.replace(",", "")) for f in g[0]}
        for n in g[1]:
            n = re.sub(r"'s$", "", n)
            if n not in ("i", "youtube", "instagram", "shorts", "reels"):
                out.add(("n", n))
        return out
    def found(fact, text):
        kind, v = fact
        if kind == "f":
            return v in [w.rstrip(".:") for w in re.findall(r"\d[\d.:]*%?", text.replace(",", ""))]
        return v in text.lower()
    ta_txt, tb_txt = " ".join(sa), " ".join(sb)
    def new_of(x, other):
        return sorted(v for k, v in facts(x) if not found((k, v), other))
    una = [x + "   <new: " + ", ".join(new_of(x, tb_txt)) + ">" for x in sa if new_of(x, tb_txt)]
    unb = [x + "   <new: " + ", ".join(new_of(x, ta_txt)) + ">" for x in sb if new_of(x, ta_txt)]
    tot_un_a += len(una)
    tot_un_b += len(unb)
    if una or unb:
        msgs_sub_diff += 1
    rows.append(f"{k} | lead {la} / {lb} {'same' if same_lead else 'DIFF'} | tools names "
                f"{'same' if same_t else 'DIFF'}, args {'same' if same_ta else 'DIFF'} | sent sentences {len(sa)}/{len(sb)}"
                f" | unmatched A {len(una)}, B {len(unb)} | reqs {ra['n_requests']}/{rb['n_requests']} | s "
                f"{ra['seconds']}/{rb['seconds']}")
    if not same_t or not same_ta or una or unb or not same_lead:
        d = [f"==== {k}: {ra['message']}"]
        d.append(f"  lead A {la} | B {lb}")
        d.append(f"  tools A: {json.dumps(taa, ensure_ascii=False)}")
        if not same_ta:
            d.append(f"  tools B: {json.dumps(tba, ensure_ascii=False)}")
        for x in una:
            d.append(f"  A only: {x}")
        for x in unb:
            d.append(f"  B only: {x}")
        detail.append("\n".join(d))
print(f"messages compared: {len(keys)}")
print(f"lead source differs: {n_lead_diff}")
print(f"tools differ by name/order: {n_tool_names}; by name, order or args: {n_tool_args}")
print(f"messages with at least one sent sentence unmatched (proxy): {msgs_sub_diff}; unmatched sentences A {tot_un_a}, "
      f"B {tot_un_b} (of {sum(len(sents(A[k])) for k in keys if k in A)} and {sum(len(sents(B[k])) for k in keys if k in B)})")
print()
print("\n".join(rows))
print()
print("DETAIL (messages with any difference)")
print("\n\n".join(detail))
