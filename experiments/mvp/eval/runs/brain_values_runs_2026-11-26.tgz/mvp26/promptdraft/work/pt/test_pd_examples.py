"""Each new example sentence of the candidates, checked by the repo's own verifier (values_tree: full and cells as
pinned, plus values) on the prompt's fixture ledgers. Offline, no model. Writes the table to PD_OUT."""
import os, sys, json
EXP = os.environ["PD_EXP"]
sys.path.insert(0, EXP)
from mvp.tests.test_mvp import env  # noqa: F401
from mvp.tests.test_brain_tools import NOW, TODAY, brain, built, no_real_keys, person  # noqa: F401
import pytest

S = [  # (candidate, ledger index, where, sentence)
 ("meaning", 0, "point", "Moss Garden[r1.channels[0]] alone made 61[r1.channels[0].items] of 142[r1.totals.items] videos you opened."),
 ("meaning", 0, "point", "Gardening[r1.areas[0]] rose to 51%[r1.areas[0].share] of what you opened, up from 16%[r1.areas[0].previous_share] in September 2026."),
 ("meaning", 0, "point", "Gardening[r1.areas[0]] was 51%[r1.areas[0].share] of what you opened, up 35 points[r1.areas[0].change_pts] on September 2026."),
 ("meaning", 1, "point", "Star charts[r1.themes[3]] had 4[r1.themes[3].items] videos, all from Quiet Orbit[r1.channels[2]]."),
 ("meaning", 1, "point", "Without gardening, Star charts[r1.themes[3]] had 4[r1.themes[3].items] videos, all from Quiet Orbit[r1.channels[2]]."),
 ("meaning", 0, "point", "Kettle Craft[r1.channels[1]] came next with 32[r1.channels[1].items] videos, all in Tea rituals[r1.themes[1]]."),
 ("meaning", 0, "point", "Kettle Craft[r1.channels[1]] came next with 32[r1.channels[1].items] videos, 100%[r1.channels[1].theme_share] of them in Tea rituals[r1.themes[1]]."),
 ("meaning", 0, "point", "Moss Garden[r1.channels[0]] made nearly twice[=ratio(r1.channels[0].items, r1.channels[1].items)] as many as Kettle Craft[r1.channels[1]]."),
 ("limits", 0, "lead", "Your export holds no likes, so here is what you opened most: in October 2026, Moss Garden[r1.channels[0]] led with 61[r1.channels[0].items] of 142[r1.totals.items] videos."),
 ("limits", 0, "lead", "Your export ends on 30 October 2026, so here is the last month it holds: in October 2026, Moss Garden[r1.channels[0]] led with 61[r1.channels[0].items] of 142[r1.totals.items] videos."),
 ("v3", 0, "point", "Kettle Craft[r1.channels[1]] came next with 32[r1.channels[1].items] videos."),
]

@pytest.fixture()
def harness(brain):
    from mvp import eval_brain as E
    return E.Harness(brain["bot"], str(brain["lib"]), os.environ["MVP_DERIVED_HOME"], handle=person(brain)["handle"], now=NOW)

def test_examples(harness):
    from mvp.tests import brain_prompt_fixture as PF
    from mvp.brain import verify as V
    L = PF.ledgers(harness)
    vt = V.Turn(message="x", today=TODAY)
    rows = []
    for cand, li, where, s in S:
        r = {"candidate": cand, "ledger": li, "where": where, "sentence": s}
        for mode in ("full", "cells", "values"):
            o = V.check_sentence(s, V.Ledger(L[li]), vt, where, mode=mode)
            r[mode] = "kept" if o.kept else "refused " + ",".join(o.reasons)
        rows.append(r)
    with open(os.environ["PD_OUT"], "w") as f:
        for r in rows:
            f.write(f"{r['candidate']:8} L{r['ledger']} {r['where']:5} full={r['full']} | cells={r['cells']} | values={r['values']}\n   {r['sentence']}\n")
