# Hand labels by promptdraft (mvp26), from the hand marks and notes of recounta (run 1) and recount2 (run 2).
# X = the main reason is not the prompt: tool gap, checker drop (incl. a code lead after a drop), timeout.
# Hand codes: P planning; L1 says what it cannot do / system talk; L2 never says the one limit the question needs;
#   H the answer needed a hidden count (meta.hidden: friends or private) the prompt never explains; K means=y but the
#   key fact of the rows left out; R a point repeats the lead; W a framing fault or heavy wording sent.
# A (did not answer), M (no meaning), O (offer) come from the marks; T (no theme named) is computed.
X = {
 ("R1","N001.1"):0,("R2","N001.1"):"checker", ("R1","N004.0"):"tool gap",("R2","N004.0"):"timeout",
 ("R2","N005.0"):"checker", ("R1","N008.0"):"checker", ("R2","N008.1"):"timeout", ("R1","N010.0"):"tool gap",
 ("R2","N010.0"):"checker", ("R1","N010.1"):"tool gap", ("R2","N010.1"):"checker", ("R1","N014.0"):"checker",
 ("R2","N016.0"):"checker", ("R2","N027.0"):"checker", ("R2","N032.0"):"checker", ("R2","N033.1"):"checker",
 ("R2","N035.0"):"checker", ("R1","N036.0"):"checker", ("R1","N038.0"):"checker", ("R1","N041.1"):"tool gap",
 ("R2","N042.0"):"checker", ("R1","N044.1"):"tool gap", ("R1","N048.0"):"tool gap", ("R1","N048.1"):"checker",
 ("R2","N048.1"):"checker", ("R1","N049.0"):"checker", ("R2","N049.0"):"tool gap", ("R2","N052.1"):"checker",
 ("R1","N053.0"):"checker", ("R2","N053.0"):"checker", ("R1","N053.1"):"tool gap", ("R1","N056.0"):"checker",
 ("R2","N056.0"):"checker", ("R1","N063.0"):"checker", ("R1","N064.0"):"tool gap", ("R2","N066.1"):"checker",
 ("R1","N069.0"):"checker",
}
X = {k: v for k, v in X.items() if v}
HAND = {
 ("R1","N001.0"):"P", ("R2","N001.0"):"P",            # 'the gaming clips' read as the whole gaming area; R2 also no window before
 ("R1","N002.0"):"P", ("R2","N002.0"):"P",            # one all-time breakdown for 'what does it say about me': no eras
 ("R1","N005.0"):"P",                                  # no per-channel per-year count for 'every year'
 ("R2","N005.1"):"", ("R1","N005.1"):"K",              # leaves out the 2026 return
 ("R2","N008.0"):"K",                                  # lists months, not the shape
 ("R1","N008.1"):"P",                                  # no October breakdown read
 ("R1","N013.0"):"", ("R2","N013.0"):"",
 ("R1","N016.0"):"",
 ("R2","N018.1"):"W",                                  # 'only Brick Realm shows up ... 100%': the filter said as a finding
 ("R2","N019.0"):"W",                                  # new channels said as a complete list
 ("R1","N027.0"):"",                                   # 'busiest hour is 16': never day or night (A from marks)
 ("R1","N029.0"):"P", ("R2","N029.0"):"P",            # Saturdays not set against all days
 ("R1","N032.0"):"K",
 ("R1","N033.0"):"P", ("R2","N033.0"):"P",            # Shorts not set against October's total
 ("R1","N034.1"):"", ("R2","N034.1"):"",              # offer goes back to the rejected reading (O from marks)
 ("R1","N035.0"):"W",                                  # 'too few to add up to a regular habit' cannot be proved
 ("R1","N035.1"):"R", ("R2","N035.1"):"R",
 ("R1","N041.0"):"W",                                  # 'of what you saved' clumsy
 ("R1","N044.0"):"W", ("R2","N044.0"):"W",            # rank over a tie / 'Here are 5' over 4 cards
 ("R1","N045.0"):"P",                                  # weekday share as filler; first math since 2023 not read
 ("R1","N052.0"):"H", ("R2","N052.0"):"H",            # most of that spring is the private topic
 ("R1","N052.1"):"L1 H",                               # 'I can't tell why' while the private line is the reason
 ("R1","N054.0"):"H", ("R2","N054.0"):"H",
 ("R1","N055.0"):"L1 H", ("R2","N055.0"):"L1 H",      # friends' count in meta.hidden.friends never given
 ("R1","N057.0"):"L2",                                 # never says minutes are not in the export
 ("R1","N063.1"):"R",
 ("R1","N067.0"):"L2 W", ("R2","N067.0"):"L2",        # never says November has no rows
 ("R2","N068.0"):"W",                                  # 'a weak match' undersells it
 ("R2","N069.0"):"L1 W",                               # 'its title is cut off ... the full text I can show'
 ("R1","N109.0"):"L1 H", ("R2","N109.0"):"L1 H",
 ("R1","N112.0"):"W", ("R2","N112.0"):"R",            # never says the hour; 'too few to show a habit'
 ("R2","N113.0"):"L2 P",                               # answers with the saves, never says no likes
}
# secondary prompt causes inside X answers (what the model's own first form also lacked)
# what the model's FIRST form itself lacked, in the excluded answers (the values check sends roughly the first form);
# "" = the first form had no prompt-side fault (likely acceptable or good once nothing true is refused)
X_SECOND = {
 ("R2","N001.1"):"", ("R2","N005.0"):"", ("R1","N008.0"):"K", ("R2","N008.1"):"P", ("R2","N010.0"):"",
 ("R2","N010.1"):"", ("R1","N014.0"):"O M", ("R2","N016.0"):"O M", ("R2","N027.0"):"", ("R2","N032.0"):"",
 ("R2","N033.1"):"W", ("R2","N035.0"):"", ("R1","N036.0"):"handle (privacy, still refused)",
 ("R1","N038.0"):"L2 handle (privacy, still refused)", ("R2","N042.0"):"", ("R1","N048.1"):"caption number (still refused)",
 ("R2","N048.1"):"caption number (still refused)", ("R1","N049.0"):"", ("R2","N052.1"):"L1 H", ("R1","N053.0"):"",
 ("R2","N053.0"):"A (no yes or no)", ("R1","N056.0"):"W (rank over a tie)", ("R2","N056.0"):"", ("R1","N063.0"):"M",
 ("R2","N066.1"):"O", ("R1","N069.0"):"L1 W",
}
