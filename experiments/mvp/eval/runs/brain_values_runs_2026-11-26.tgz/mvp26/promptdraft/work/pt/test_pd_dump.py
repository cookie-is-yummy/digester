import os, sys, json
EXP = os.environ["PD_EXP"]
sys.path.insert(0, EXP)
from mvp.tests.test_mvp import env  # noqa: F401
from mvp.tests.test_brain_tools import NOW, TODAY, brain, built, no_real_keys, person  # noqa: F401
import pytest

@pytest.fixture()
def harness(brain):
    from mvp import eval_brain as E
    return E.Harness(brain["bot"], str(brain["lib"]), os.environ["MVP_DERIVED_HOME"], handle=person(brain)["handle"], now=NOW)

def test_dump(harness):
    from mvp.tests import brain_prompt_fixture as PF
    L = PF.ledgers(harness)
    out = os.environ["PD_OUT"]
    with open(out, "w") as f:
        for led in L:
            for rid, env_ in led.items():
                s = env_["sheet"]
                f.write(json.dumps({"meta": env_.get("meta"), "totals": s.get("totals"), "previous": s.get("previous"),
                                    "channels": s.get("channels"), "themes": s.get("themes"), "areas": s.get("areas")}, indent=0)[:9000] + "\n=====\n")
