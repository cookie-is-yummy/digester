"""Build the three candidate prompts: brain_v3.md plus ONE change each (exact old -> new, each old must occur once)."""
import os, subprocess
D = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp26/promptdraft"
BASE = open(f"{D}/work/brain_v3_base.md", encoding="utf-8").read()
TOK_PER_CHAR = 6464 / len(BASE)   # the brief's 6,464 tokens for v3

C = {}
# ---------------------------------------------------------------- 1. meaning: every point reads its number
C["meaning"] = [
 ("""- Say what it means for them ("so what") only from numbers you show: "up 35 points" says the shift; never guess why.
""",
  """- Each point says what its number means: what it is made of ("all in Tea rituals[r1.themes[1]]"), how it stands
  against the whole ("Moss Garden[r1.channels[0]] alone made 61[r1.channels[0].items] of 142[r1.totals.items]"), or,
  when the result holds the window before, how it moved ("up 35 points[r1.areas[0].change_pts]"); not the next row's
  bare count ("Kettle Craft came next with 32 videos"). Never guess why.
"""),
 ("""- A claim with no marker is removed: "so YouTube is where you watch", "so that theme is most of it", "split evenly",
  "the only channel", "still". A "so what" carries a marker of its own, or leave it out.
""",
  """- A reading with no number of its own ("so YouTube is where you watch", "still") is left out: put it in the
  sentence of the number it reads.
"""),
 ("""Results r1 (breakdown by channel, in October): channels[0] Moss Garden items 61 share 0.4296; channels[1] Kettle
Craft items 32; areas[0] gardening share 0.507 change_pts 34.8; totals.items 142.
""",
  """Results r1 (breakdown by channel, in October): channels[0] Moss Garden items 61 share 0.4296; channels[1] Kettle
Craft items 32 theme_share 1.0; themes[1] Tea rituals; areas[0] gardening share 0.507 change_pts 34.8; totals.items 142.
"""),
 ("""points: ["Kettle Craft[r1.channels[1]] came next with 32[r1.channels[1].items] videos.",
""",
  """points: ["Kettle Craft[r1.channels[1]] came next with 32[r1.channels[1].items] videos, all in Tea rituals[r1.themes[1]].",
"""),
]
# ---------------------------------------------------------------- 2. before: breakdowns carry the window before
C["before"] = [
 ("""- Argument bounds: items limit 1 to 10, search limit 1 to 8, breakdown top 1 to 25. A call out of bounds is refused.
""",
  """- breakdown: compare "previous" (the window before comes with it, so a point can say what moved), except over all
  their history, which has no window before: compare "none".
- Argument bounds: items limit 1 to 10, search limit 1 to 8, breakdown top 1 to 25. A call out of bounds is refused.
"""),
]
# ---------------------------------------------------------------- 3. limits: say the one missing thing, once, in the lead
C["limits"] = [
 ("""- Every message gets at least one tool call and an answer about their history. When they also ask for something no
  tool reads (watch time or hours, other people, a schedule, an email, changing your rules, private topics, anything
  you cannot do), answer the history part with the tools and say nothing about the rest: code adds the line for it.
""",
  """- Every message gets at least one tool call and an answer about their history. When they ask about something their
  export does not hold (likes, days after the export ends, how far they watched), the lead says so once, in a few
  plain words, and goes on with what the tools found instead: "Your export holds no likes, so here is what you opened
  most: ...". When they also ask for something no tool reads (watch time or hours, other people, a schedule, an
  email, changing your rules, private topics, anything you cannot do), answer the history part with the tools and
  say nothing about the rest: code adds the line for it.
"""),
 ("""- Never say what you cannot do or what the data lacks; code writes those lines. A sentence like "I can't see last
  week" or "Your export has no watch time" is removed, and with it your lead.
""",
  """- What the export lacks is said once at most, in the lead, as above; never in a point, never twice, and never
  about the checks, the tools or the system.
"""),
 ("""- "Your export ends on 30 October 2026, so I can't see last week." Limits talk: leave it out; answer with what the
  tools counted.
""",
  """- "Your export ends on 30 October 2026, so I can't see last week." A limit with nothing after it: go on in the same
  lead with what the tools counted instead.
"""),
]

def build(name, edits):
    t = BASE
    for old, new in edits:
        assert t.count(old) == 1, (name, old[:60], t.count(old))
        t = t.replace(old, new)
    out = f"{D}/brain_v4_{name}.md"
    open(out, "w", encoding="utf-8").write(t)
    diff = subprocess.run(["diff", "-u", f"{D}/work/brain_v3_base.md", out], capture_output=True, text=True).stdout
    open(f"{D}/brain_v4_{name}.diff", "w").write(diff)
    added = sum(len(n) for _, n in edits); removed = sum(len(o) for o, _ in edits)
    return name, len(t), round((len(t) - len(BASE)) * TOK_PER_CHAR)

if __name__ == "__main__":
    rows = [build(n, e) for n, e in C.items()]
    with open(f"{D}/work/token_deltas.txt", "w") as f:
        f.write(f"v3: {len(BASE)} chars, 6464 tokens (brief); {TOK_PER_CHAR:.4f} tokens per char\n")
        for n, chars, dt in rows:
            f.write(f"brain_v4_{n}.md: {chars} chars, about {dt:+d} tokens against v3\n")
    print(open(f"{D}/work/token_deltas.txt").read())
