import json, sys, collections, re
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp26/promptdraft/work")
from labels import X, HAND, X_SECOND
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
RUNS = [("R1", S+"/mvp24/recounta/answers.json", S+"/mvp24/runa/run1"),
        ("R2", S+"/mvp25/recount2/answers.json", S+"/mvp25/runa2/run1")]
LOOKUP = ("first_last", "items", "search")  # item lookups: a theme is not expected
def theme_names(rec):
    out = set()
    def walk(o, key=None):
        if isinstance(o, dict):
            for k, v in o.items():
                if k == "themes" and isinstance(v, list):
                    for r in v:
                        if isinstance(r, dict) and isinstance(r.get("name"), str): out.add(r["name"].lower())
                walk(v, k)
        elif isinstance(o, list):
            for v in o: walk(v, key)
    for c in rec.get("calls") or []:
        walk((c.get("result") or {}).get("sheet") or {})
    return out
cnt = collections.Counter(); who = collections.defaultdict(list); rows = []
for tag, ap, rd in RUNS:
    for a in json.load(open(ap)):
        k = (tag, a["key"]); rec = json.load(open(f"{rd}/{a['key']}.json"))
        if a["grade"] == "good":
            rows.append((tag, a["key"], "good", "", "")); continue
        if k in X:
            rows.append((tag, a["key"], a["grade"], "X:" + X[k], X_SECOND.get(k, ""))); cnt["X " + X[k]] += 1
            who["X " + X[k]].append(f"{tag}:{a['key']}"); continue
        codes = set((HAND.get(k) or "").split())
        if not a["answers_question"]: codes.add("A")
        if not a["says_what_numbers_mean"]: codes.add("M")
        if not a["carries_offer"]: codes.add("O")
        tools = {c["name"] for c in rec.get("calls") or []}
        names = theme_names(rec)
        f0 = (rec.get("forms") or [{}])[0]
        first = re.sub(r"\[[^\]]*\]", "", " ".join([f0.get("lead") or ""] + list(f0.get("points") or []))).lower()
        if not (tools <= set(LOOKUP)) and not any(n in first for n in names):
            codes.add("T")
        for c in codes: cnt[c] += 1; who[c].append(f"{tag}:{a['key']}")
        rows.append((tag, a["key"], a["grade"], " ".join(sorted(codes)), ""))
out = []
nonx = [r for r in rows if r[2] != "good" and not r[3].startswith("X")]
out.append(f"answers: 130; good {sum(r[2]=='good' for r in rows)}; acceptable/poor with a prompt-side reason {len(nonx)}; excluded (tool, checker, timeout) {sum(r[3].startswith('X') for r in rows)}")
names = {"A": "did not answer the question asked", "M": "data with no meaning (marked means=n)", "T": "no theme named in the first form (content answer; a string match, an upper bound)",
         "O": "weak or missing offer (marked offer=n)", "L1": "said what it cannot do / system talk", "L2": "never said the one limit the question needs",
         "H": "needed a hidden count (friends or private) the prompt never explains", "P": "planning (tool, window, scope, a second reference)",
         "K": "says a meaning but leaves out the key fact", "R": "a point repeats the lead", "W": "framing fault or heavy wording sent"}
for c in ["A", "M", "T", "O", "L1", "L2", "H", "P", "K", "R", "W"]:
    out.append(f"{c:3} {cnt[c]:3}  {names[c]}: {' '.join(who[c])}")
for c in sorted(k for k in cnt if k.startswith("X")):
    out.append(f"{c:12} {cnt[c]:3}: {' '.join(who[c])}")
out.append("")
out.append("first-form causes inside the excluded answers (what values-only would send):")
for k in sorted(X_SECOND): out.append(f"  {k[0]}:{k[1]} {X.get(k)} -> {X_SECOND[k] or 'no prompt-side fault in the first form'}")
out.append("")
for r in rows: out.append(" ".join(x for x in r if x))
open(S + "/mvp26/promptdraft/cause_counts.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out[:20]))
