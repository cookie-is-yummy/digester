import json, re, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
RUNS = [("R1", S+"/mvp24/recounta/answers.json", S+"/mvp24/runa/run1"),
        ("R2", S+"/mvp25/recount2/answers.json", S+"/mvp25/runa2/run1")]
# set notes from reading sheet
def setnotes(path):
    out = {}; key = None; before = {}
    cur = None
    for line in open(path, encoding="utf-8"):
        m = re.match(r"==== (\S+) \|", line)
        if m: key = m.group(1); before[key] = []; cur = None; continue
        if key and line.startswith("the set's note:"): out[key] = line[len("the set's note:"):].strip()
        if key and line.startswith("before:"): cur = "b"; continue
        if key and cur == "b" and line.startswith("  ["): before[key].append(line.strip()[:160])
        if key and line.startswith("message:"): cur = None
    return out, before
notes, before = setnotes(S+"/mvp25/runa2/run1/reading_sheet.txt")
ans = {}
for tag, ap, rd in RUNS:
    for a in json.load(open(ap)):
        ans.setdefault(a["key"], {})[tag] = (a, json.load(open(f"{rd}/{a['key']}.json")))
def short_args(a):
    a = dict(a); s = []
    w = a.get("window") or {}
    w = {k: v for k, v in w.items() if v}
    sc = a.get("scope") or {}
    sc = {k: v for k, v in sc.items() if v and v != "any" and v != "opened"}
    rest = {k: v for k, v in a.items() if k not in ("window", "scope") and v not in (None, "", [], "none")}
    return f"{json.dumps(rest)} w={json.dumps(w)} sc={json.dumps(sc)}"
for key in sorted(ans):
    print("=" * 100)
    first = next(iter(ans[key].values()))[0]
    print(key, "|", first["message"])
    for b in before.get(key, []): print("   before:", b)
    print("   SET:", notes.get(key, ""))
    for tag in ("R1", "R2"):
        if tag not in ans[key]: continue
        a, r = ans[key][tag]
        print(f" --{tag} grade={a['grade']} ans={int(bool(a['answers_question']))} means={int(bool(a['says_what_numbers_mean']))} offer={int(bool(a['carries_offer']))} src={a['lead_source']} cause={a.get('poor_cause')} s={r.get('seconds')} rounds={r.get('rounds')} req={r.get('n_requests')}")
        print("   NOTE:", a.get("note"))
        for c in r.get("calls") or []:
            res = c.get("result") or {}
            err = res.get("error") or (res.get("is_error") and json.dumps(res)[:150])
            print(f"   CALL r{c.get('round')} {c.get('name')} {short_args(c.get('args') or {})}" + (f" ERR {str(err)[:150]}" if err else ""))
        for i, f in enumerate(r.get("forms") or []):
            print(f"   FORM{i} lead: {f.get('lead')}")
            for p in f.get("points") or []: print(f"   FORM{i} pt: {p}")
            print(f"   FORM{i} offers: {json.dumps(f.get('offers'))} items={len(f.get('items') or [])} ask={f.get('ask_back')}")
        for d in r.get("dropped") or []:
            print(f"   DROP f{d.get('form')} {d.get('where')}{d.get('index')}: {d.get('reasons')} {d.get('details')}")
        print("   SENT: " + a["sent_text"].replace("\n", " // "))
