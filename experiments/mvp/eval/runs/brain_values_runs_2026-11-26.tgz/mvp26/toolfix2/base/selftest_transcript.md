# Self-test dry run, build d7ba2ef (26 Nov 2026) (made-up library and people)

## c01 (tester): the setup answer that holds a request (screenshot a)

### c01.1

> yes

Thanks! I couldn't get a good read of your library yet.

In a sentence or two, what are you working toward right now? (Or say "skip".)

ok

### c01.2

> looks right

Great, thanks.

What's your email address? I use it to email you answers and calendar files, after a 6-digit code to check it's yours. I have you on New York time, where it's 1:06pm now. If that's wrong, tell me the city you're in. (Or say "skip".)

ok

### c01.3

> skip

I'll remind you when a fresh export is due (Instagram every 4 weeks, YouTube every 2 months) and send the steps then. OK?

Ask your watch history anything. I can see 18 videos you watched on YouTube, up to 30 October 2026. Try:
"which channels did I watch the most in October?"
"what did I watch on 30 October 2026?"
"how many videos did I watch in 2026?"

Anything I should know to pick better: food you avoid, kit you have, how much time you usually have? (Or say "skip".)

ok

### c01.4

> not really, i don't have much time. but can you help me set it up so my youtube and instagram export to you regularly

Noted: you don't have much time.

About regular exports: Instagram doesn't let any app pull your saves, so here's the closest I can do.
• YouTube: Google Takeout can repeat your export every 2 months for a year. You set that up once; say "steps" and I'll send them.
• Instagram: I can't confirm a repeating export for your account, so I'll remind you every 4 weeks.
• Each new file goes in the upload box on the test page, and I add it by myself.

Done: next Instagram reminder 15 December, next YouTube one 17 January. Say "undo" to stop the reminders.

ok

## c02 (tester): email my teacher (screenshot b), then send

### c02.1

> can you email my teacher that i'm not feeling well this morning

Who should it go to? Reply with your teacher's email address, or "blank" to pick them in your mail app.

ok

### c02.2

> teacher@example.com

Here's the email. Nothing has been sent.
To: teacher@example.com
Subject: I'm not feeling well this morning

Hi,

I'm not feeling well this morning.

Thanks,
Sam

Tap to open it in your mail app, check it, and press Send there:
mailto:teacher@example.com?subject=I%27m%20not%20feeling%20well%20this%20morning&body=Hi%2C%0D%0A%0D%0AI%27m%20not%20feeling%20well%20this%20morning.%0D%0A%0D%0AThanks%2C%0D%0ASam
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c02.3

> send

I can't send from your address. Tap the link above and press Send in your mail app.

ok

## c03 (tester): email it to me with the card open (screenshot c)

### c03.1

> can you email my teacher that i'm sick today

Who should it go to? Reply with your teacher's email address, or "blank" to pick them in your mail app.

ok

### c03.2

> email it to me

Here's the draft as an email to yourself (tap to open it in your mail app): mailto:?subject=I%27m%20sick%20today&body=Hi%2C%0D%0A%0D%0AI%27m%20sick%20today.%0D%0A%0D%0AThanks%2C%0D%0ASam
The draft to your teacher is still open. Send me their address when you have it.

ok

## c04 (tester): email a whole class, then email it to me with nothing written

_Live (18 Nov): the card asked for "Everyone In My Class's email address"; a group now greets everyone and asks for one address at a time._

### c04.1

> email everyone in my class that the meeting moved

Who should it go to? I write to one address at a time: reply with one email address, or "blank" and add everyone in your mail app.

ok

### c04.2

> email it to me

Here's the draft as an email to yourself (tap to open it in your mail app): mailto:?subject=The%20meeting%20moved&body=Hi%20everyone%2C%0D%0A%0D%0AThe%20meeting%20moved.%0D%0A%0D%0AThanks%2C%0D%0ASam
The draft to everyone is still open. Send me their address when you have it.

ok

## c05 (tester): cancel my netflix, then the browser's yes words with no browser open

### c05.1

> cancel my netflix

Netflix cancels on its website. I can't do it for you, because I never sign in as you. Here's where it is:
1. Open https://www.netflix.com/cancelplan and sign in if it asks.
2. Press "Cancel".
3. Press "Finish Cancellation".
(From Netflix's help page, checked 17 Nov.)

Want a reminder to check it went through? Tell me when, like "friday".

ok

### c05.2

> yes cancel netflix

Netflix cancels on its website. I can't do it for you, because I never sign in as you. Here's where it is:
1. Open https://www.netflix.com/cancelplan and sign in if it asks.
2. Press "Cancel".
3. Press "Finish Cancellation".
(From Netflix's help page, checked 17 Nov.)

Want a reminder to check it went through? Tell me when, like "friday".

ok

## c06 (operator): cancel a gym by written notice, sent from the operator's own mailbox

_The notice goes to the merchant only after 'send' on the exact card and the 2-minute hold. Found in the trial merge with D (dry): 'i pay by card' after 'Which gym?' became the gym's name, and 'planet fitness' the name on the membership; fixed at the second merge of round 10 (cancel.PAY_ANSWER: the question is asked again)._

### c06.1

> cancel my gym membership

Which gym?

ok

### c06.2

> i pay by card

Got it. Which gym is it? Just its name, like "City Gym".

ok

### c06.3

> planet fitness

What name is the membership under? I only use it for the notice.

ok

### c06.4

> Sam Example

Here's a cancellation notice you can send to Planet Fitness. Nothing has been sent.
To: (type their email address; their website or your contract has it)
Subject: Cancel my membership
Planet Fitness takes a written notice by post to your home club (from their help page, checked 17 Nov).
They ask for it at least 7 days before your next billing date.

Hello,

Please cancel my membership effective immediately and stop all future charges. Please confirm the cancellation in writing.

Name on the membership: Sam Example
Email on the account: me@example.com
Member number: (fill this in)

Thank you,
Sam Example

Fill in the member number first: reply "member number 12345", or "remove it".

ok

### c06.5

> remove it

Here's the new version. Nothing has been sent.
To: (type their email address; their website or your contract has it)
Subject: Cancel my membership
Planet Fitness takes a written notice by post to your home club (from their help page, checked 17 Nov).
They ask for it at least 7 days before your next billing date.

Hello,

Please cancel my membership effective immediately and stop all future charges. Please confirm the cancellation in writing.

Name on the membership: Sam Example
Email on the account: me@example.com

Thank you,
Sam Example

Reply "send" to send it from me@example.com. Or tap to send it yourself:
mailto:?subject=Cancel%20my%20membership&body=Hello%2C%0D%0A%0D%0APlease%20cancel%20my%20membership%20effective%20immediately%20and%20stop%20all%20future%20charges.%20Please%20confirm%20the%20cancellation%20in%20writing.%0D%0A%0D%0AName%20on%20the%20membership%3A%20Sam%20Example%0D%0AEmail%20on%20the%20account%3A%20me%40example.com%0D%0A%0D%0AThank%20you%2C%0D%0ASam%20Example
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c06.6

> to: club@example.com

Here's the new version. Nothing has been sent.
To: club@example.com
Subject: Cancel my membership
Planet Fitness takes a written notice by post to your home club (from their help page, checked 17 Nov).
They ask for it at least 7 days before your next billing date.

Hello,

Please cancel my membership effective immediately and stop all future charges. Please confirm the cancellation in writing.

Name on the membership: Sam Example
Email on the account: me@example.com

Thank you,
Sam Example

Reply "send" to send it from me@example.com. Or tap to send it yourself:
mailto:club@example.com?subject=Cancel%20my%20membership&body=Hello%2C%0D%0A%0D%0APlease%20cancel%20my%20membership%20effective%20immediately%20and%20stop%20all%20future%20charges.%20Please%20confirm%20the%20cancellation%20in%20writing.%0D%0A%0D%0AName%20on%20the%20membership%3A%20Sam%20Example%0D%0AEmail%20on%20the%20account%3A%20me%40example.com%0D%0A%0D%0AThank%20you%2C%0D%0ASam%20Example
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c06.7

> send

Sending to club@example.com at 2:02 pm. Reply "undo" before then to stop it.

ok

### c06.8

Your mail server accepted your cancellation notice to Planet Fitness (club@example.com) at 2:03 pm. I can't unsend it. That doesn't end it yet: it ends when they confirm in writing. Keep their reply. Want a reminder on Tuesday 24 November to check they confirmed? Reply "yes", or give another day.

ok

### c06.9

> yes

OK. On Tuesday 24 November at 9am I'll remind you to check. Reply "stop 1" to drop it.

ok

### c06.10

> what did you do for me

In the last 7 days I:
• helped with 1 cancellation (I sent 1 notice after your "send")
• sent the cancellation notice to someone at example.com from me@example.com today at 2:03pm, after your "send" (the mail server took it)
You can still undo the last thing (set up a check reminder): say "undo" within 10 minutes.

ok

## c07 (tester): a recipe for tonight, where meme reels carry pasted recipes

### c07.1

> a recipe i can make tonight

Here you go.

I recommend a post from @weeknight_pan, which you saved in October.
https://www.instagram.com/reel/st_r30/
Or here's a wider selection:
• No-knead bread (recipe below): https://www.instagram.com/reel/st_r26/
• Focaccia (recipe below): https://www.instagram.com/reel/st_r28/

ok

## c07b (tester): only meme reels fit: the honest lead, the doubt line, a neutral title

_The made-up library without its real recipes: only the meme account's pasted recipes are left. Live (18 Nov): the composer showed two of the meme reels, so the lead said "The best match I found is"; the wording check takes either lead, the doubt line is still required._

### c07b.1

> a pasta recipe

Here's what I found in your saves.

The only match I found is a reel from @lol_reels_daily, which you saved in October.
Heads-up: its caption is a recipe, but the account mostly posts memes, so the video may show something else.
https://www.instagram.com/reel/st_m04/

ok

## c08 (tester): that reel had nothing to do with it

### c08.1

> a pasta recipe

Here you go.

I recommend Minestrone (recipe below) by @soup_and_bread, which you saved in March.
https://www.instagram.com/reel/st_r29/
Or here's a wider selection:
• A post from @weeknight_pan: https://www.instagram.com/reel/st_r30/
• No-knead bread (recipe below): https://www.instagram.com/reel/st_r26/

ok

### c08.2

> that reel had nothing to do with it

Thanks, that helps. I've taken that reel out of your picks and I'll trust captions from @soup_and_bread less from now on. Say "another" for a different one.

ok

### c08.3

> another

Here you go.

I recommend Prawn tacos (recipe below) by @weeknight_pan, which you saved in July.
https://www.instagram.com/reel/st_r24/

ok

## c09 (tester): that one was fine

### c09.1

> a pasta recipe

Here you go.

I recommend Minestrone (recipe below) by @soup_and_bread, which you saved in March.
https://www.instagram.com/reel/st_r29/
Or here's a wider selection:
• A post from @weeknight_pan: https://www.instagram.com/reel/st_r30/
• No-knead bread (recipe below): https://www.instagram.com/reel/st_r26/

ok

### c09.2

> that one was fine

Good to know. I'll trust @soup_and_bread's captions again.

ok

## c10 (operator): every sunday put 3 recipes in my ticktick (one yes per rule)

_The clock goes to just after the rule's next slot ("next run"): live, the model set 9am, and a jump to 18:05 was more than 2 hours late, so the scheduler skipped the send._

### c10.1

> every sunday put 3 recipes you find in my ticktick

Here's what that would look like now:

Here you go.

I recommend No-knead bread (recipe below) by @soup_and_bread, which you saved in September.
https://www.instagram.com/reel/st_r26/
Or try these:
• Focaccia (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r28/
• Tomato soup (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r27/

Every Sunday at 6pm, I'll send 3 picks for "recipes" that I haven't sent you before. The first one would come on Sunday 22 November at 6pm. On a day with nothing new I'll stay quiet.
I'll also add them to TickTick, in your Inbox, as tasks with their links: at most 3 each Sunday and 10 a day.
Each time I'll tell you here what I added, and you can say "undo".
Reply YES to start and let me add them, or tell me what to change.

ok

### c10.2

> yes

Got it: every Sunday at 6pm, 3 recipes. First one on Sunday 22 November at 6pm. Reply "my rules" any time to see or change it. On a day with nothing new I'll stay quiet. Each time I'll add them to TickTick and tell you here what I added.

ok

### c10.3 (clock: next run)

Here you go.

I recommend Veggie stir fry (recipe below) by @tiny_kitchen_lab, which you saved in September.
https://www.instagram.com/reel/st_r17/
Or try these:
• Overnight oats (recipe below) by @tiny_kitchen_lab https://www.instagram.com/reel/st_r18/
• Prawn tacos (recipe below) by @weeknight_pan https://www.instagram.com/reel/st_r24/

Not for you? Reply 👎. Want one more now? Reply "another". To pause these, reply "pause 1".

Added 3 tasks to TickTick (rule 1): Veggie stir fry (recipe below); Overnight oats (recipe below); Prawn tacos (recipe below). Say "undo" to take them out, or "stop 1" to end the rule.

ok

## c11 (operator): add these to my ticktick after an answer

### c11.1

> a dinner recipe

Here you go.

I recommend No-knead bread (recipe below) by @soup_and_bread, which you saved in September.
https://www.instagram.com/reel/st_r26/
Or try these:
• Focaccia (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r28/
• Tomato soup (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r27/

ok

### c11.2

> add these to my ticktick

I'll add these 3 to TickTick:
• No-knead bread (recipe below) (https://www.instagram.com/reel/st_r26/)
• Focaccia (recipe below) (https://www.instagram.com/reel/st_r28/)
• Tomato soup (recipe below) (https://www.instagram.com/reel/st_r27/)
Reply "yes" to add them, or "no" to leave them.

ok

### c11.3

> yes

Added 3 tasks to TickTick. Reply "undo" within 10 minutes to remove them.

ok

## c12 (tester): is ticktick connected? what apps? connect my notion

### c12.1

> is ticktick connected?

TickTick is only for the person who runs me. I keep your lists here.

ok

### c12.2

> what apps are you connected to

Here's where I can put things for you:
• Your list here: always on.
• Email to you: not connected here, so emails wait in the bot's outbox folder.
• Calendar: a link you tap, no sign-in.
• Email to other people: a draft you send from your mail app.
Reminders and Calendar on my Mac are only for the person who runs me.

ok

### c12.3

> connect my notion

I can't connect to Notion yet. I can reach email and a calendar link; say "what can I connect" for how.

ok

## c13 (tester): unsubscribe me from that youtube channel, not connected

### c13.1

> unsubscribe me from that youtube channel

YouTube isn't set up on this bot yet, so I can't change anything there for you. You can manage your channels yourself here: https://www.youtube.com/feed/channels

ok

## c14 (tester): chicken and rice recipes for my instant pot

### c14.1

> chicken and rice recipes for my instant pot

Here you go.

I recommend Instant Pot lemon chicken with rice (recipe below) by @made_up_cook, which you saved in July.
https://www.instagram.com/reel/st_r06/
Or try these:
• Weeknight chicken fried rice (recipe below) by @made_up_cook https://www.instagram.com/reel/st_r07/
• Instant Pot chicken and rice (recipe below) by @made_up_cook https://www.instagram.com/reel/st_r05/

ok

## c15 (tester): mini blender tutorials to start doing daily

### c15.1

> mini blender tutorials to start doing daily

Here's what that would look like now:

Here you go.

I recommend Mini Blender tutorial: a cozy isometric room by @blender_bits_demo, which you saved in August.
https://www.instagram.com/reel/st_b04/
The steps are in the video, not written in the post.

Every day at 9am, I'll send 1 pick for "mini Blender tutorials" that I haven't sent you before. The first one would come tomorrow at 9am. On a day with nothing new I'll stay quiet. Reply YES to start, or tell me what to change.

ok

### c15.2

> yes

Got it: every day at 9am, mini Blender tutorials. First one tomorrow at 9am. Reply "my rules" any time to see or change it. On a day with nothing new I'll stay quiet.

ok

## c16 (tester): which ui/ux libraries should i use

### c16.1

> what are some uiux libraries i should use for my next project

Here you go.

I recommend UI library roundup: shadcn/ui, Radix UI and Headless… by @ui_libs_demo, which you saved in July.
https://www.instagram.com/reel/st_u01/
The details are in the post's slides or video, not in its text.

Or try these:
• Mantine: a full UI library for React apps by @ui_libs_demo https://www.instagram.com/reel/st_u09/
• Design systems to study: Material 3 and Carbon by @ui_libs_demo https://www.instagram.com/reel/st_u07/

ok

## c17 (tester): two rules: every 2 days a workout, a stretch at random a few times a week

### c17.1

> every 2 days send me a workout

Here's what that would look like now:

Here you go.

I recommend Kettlebell workout: swings, cleans, goblet squats. by @coach_made_up, which you saved in August.
https://www.instagram.com/reel/st_w07/
The steps are in the video, not written in the post.

Every 2 days at 8am, I'll send 1 pick for "a workout" that I haven't sent you before. The first one would come tomorrow at 8am. On a day with nothing new I'll stay quiet. Reply YES to start, or tell me what to change.

ok

### c17.2

> yes

Got it: every 2 days at 8am, a workout. First one tomorrow at 8am. Reply "my rules" any time to see or change it. On a day with nothing new I'll stay quiet.

ok

### c17.3

> randomly send me a stretch a few times a week

Here's what that would look like now:

Here you go.

I recommend Lower back stretch: knee hugs, supine twist, sphinx. by @stretch_daily_demo, which you saved in June.
https://www.instagram.com/reel/st_w13/
The steps are in the video, not written in the post.

About 3 times a week at random times between 9am and 8pm, I'll send 1 pick for "a stretch" that I haven't sent you before. On a day with nothing new I'll stay quiet. Reply YES to start, or tell me what to change.

ok

### c17.4

> yes

Got it: about 3 times a week at random times between 9am and 8pm, a stretch. Reply "my rules" any time to see or change it. On a day with nothing new I'll stay quiet.

ok

## c18 (tester): programs with a deadline, then apply to the first one

### c18.1

> any programs i saved with a deadline

Here you go.

I recommend Creative coding residency: deadline 1 December 2026. by @opps_board_demo, which you saved in November.
Deadline 1 December (in 9 days).
https://www.instagram.com/reel/st_j03/
The details are in the post's slides or video, not in its text.

Or try these:
• Product design internship, apply by 10 January 2027. by @opps_board_demo: deadline 10 January 2027 (in 49 days). https://www.instagram.com/reel/st_j06/
• Scholarship for women in tech, deadline 20 December… by @opps_board_demo: deadline 20 December (in 28 days). https://www.instagram.com/reel/st_j04/

ok

### c18.2

> apply to the first one

I can't fill in or send the application myself, but here's what I can set up for Creative coding residency: deadline 1 December 2026. (from your saves):
1. Its deadline, 1 December, on your calendar, and a reminder on Saturday 28 November at 9am, 3 days before.
The post:
https://www.instagram.com/reel/st_j03/
Reply 1, or "none".

ok

## c19 (tester): to-dos, then go ahead with the netflix one, then do all of them

### c19.1

> add cancel netflix to my list

Added "cancel netflix" to your list.

ok

### c19.2

> add email landlord to my list

Added "email landlord" to your list.

ok

### c19.3

> my list

Your list:
1. cancel netflix
2. email landlord
Reply "done 1" when one is done, or "remove 1".

ok

### c19.4

> go ahead with the netflix one

Netflix cancels on its website. I can't do it for you, because I never sign in as you. Here's where it is:
1. Open https://www.netflix.com/cancelplan and sign in if it asks.
2. Press "Cancel".
3. Press "Finish Cancellation".
(From Netflix's help page, checked 17 Nov.)

Want a reminder to check it went through? Tell me when, like "friday".

Tick it off once it's done: "done 1".

ok

### c19.5

> do all of them

Netflix cancels on its website. I can't do it for you, because I never sign in as you. Here's where it is:
1. Open https://www.netflix.com/cancelplan and sign in if it asks.
2. Press "Cancel".
3. Press "Finish Cancellation".
(From Netflix's help page, checked 17 Nov.)

Want a reminder to check it went through? Tell me when, like "friday".

Tick it off once it's done: "done 1".

One at a time: next is "email landlord". Say "do 2 for me" when you're ready.

ok

## c20 (tester): change a draft's day, then looks good, send

### c20.1

> email sam@example.com that the sink is broken monday

Here's the email. Nothing has been sent.
To: sam@example.com
Subject: The sink is broken monday

Hi,

The sink is broken monday.

Thanks,
Sam

Tap to open it in your mail app, check it, and press Send there:
mailto:sam@example.com?subject=The%20sink%20is%20broken%20monday&body=Hi%2C%0D%0A%0D%0AThe%20sink%20is%20broken%20monday.%0D%0A%0D%0AThanks%2C%0D%0ASam
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c20.2

> no say tuesday not monday

Here's the new version. Nothing has been sent.
To: sam@example.com
Subject: The sink is broken monday

Hi,

The sink is broken tuesday.

Thanks,
Sam

Tap to open it in your mail app, check it, and press Send there:
mailto:sam@example.com?subject=The%20sink%20is%20broken%20monday&body=Hi%2C%0D%0A%0D%0AThe%20sink%20is%20broken%20tuesday.%0D%0A%0D%0AThanks%2C%0D%0ASam
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c20.3

> looks good, send

I can't send from your address. Tap the link above and press Send in your mail app.

ok

## c21 (operator): what did you do for me, after adds and a draft

### c21.1

> a dinner recipe

Here you go.

I recommend No-knead bread (recipe below) by @soup_and_bread, which you saved in September.
https://www.instagram.com/reel/st_r26/
Or try these:
• Focaccia (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r28/
• Tomato soup (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r27/

ok

### c21.2

> add these to my ticktick

I'll add these 3 to TickTick:
• No-knead bread (recipe below) (https://www.instagram.com/reel/st_r26/)
• Focaccia (recipe below) (https://www.instagram.com/reel/st_r28/)
• Tomato soup (recipe below) (https://www.instagram.com/reel/st_r27/)
Reply "yes" to add them, or "no" to leave them.

ok

### c21.3

> yes

Added 3 tasks to TickTick. Reply "undo" within 10 minutes to remove them.

ok

### c21.4

> email sam@example.com that the sink is broken

Here's the email. Nothing has been sent.
To: sam@example.com
Subject: The sink is broken

Hi,

The sink is broken.

Thanks,
Sam

Tap to open it in your mail app, check it, and press Send there:
mailto:sam@example.com?subject=The%20sink%20is%20broken&body=Hi%2C%0D%0A%0D%0AThe%20sink%20is%20broken.%0D%0A%0D%0AThanks%2C%0D%0ASam
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c21.5

> what did you do for me

In the last 7 days I:
• prepared the email to someone at example.com (today; a link you open in your mail app; I can't see whether you sent it)
• added 3 tasks in TickTick
Waiting for you:
• the email to someone at example.com (say "show the draft")
You can still undo the last thing (added 3 tasks in TickTick): say "undo" within 10 minutes.

ok

### c21.6

> what did you add to my ticktick

In the last 7 days I:
• prepared the email to someone at example.com (today; a link you open in your mail app; I can't see whether you sent it)
• added 3 tasks in TickTick
Waiting for you:
• the email to someone at example.com (say "show the draft")
You can still undo the last thing (added 3 tasks in TickTick): say "undo" within 10 minutes.

ok

## c22 (tester): Spanish: email my teacher, then send it to me

### c22.1

> puedes mandarle un correo a mi profe diciendo que hoy no voy

OK.

ok

### c22.2

> mándamelo a mí

OK.

ok

## c23 (tester): two asks in one message: cancel hulu and email my landlord

### c23.1

> cancel my hulu and also email my landlord that the rent is late

How do you pay for Hulu: through Apple (iPhone), Google Play (Android), or their website?

Who should it go to? Reply with your landlord's email address, or "blank" to pick them in your mail app.

ok

## c24 (tester): library questions that name cancelling are not cancel requests

### c24.1

> any videos on how to cancel subscriptions you don't use

Here you go.

I recommend Minimalist desk setup tour by @misc_saves_demo, which you saved in June.
https://www.instagram.com/reel/st_x08/
Or here's a wider selection:
• How I plan my week on Sunday: https://www.instagram.com/reel/st_x03/
• Budget travel tips for Lisbon: https://www.instagram.com/reel/st_x05/

ok

### c24.2

> im thinking of cancelling netflix, did i save anything worth watching on it first

Here you go.

I recommend Minimalist desk setup tour by @misc_saves_demo, which you saved in June.
https://www.instagram.com/reel/st_x08/
The details are in the post's slides or video, not in its text.

Or try these:
• How I plan my week on Sunday by @misc_saves_demo https://www.instagram.com/reel/st_x03/
• Budget travel tips for Lisbon by @misc_saves_demo https://www.instagram.com/reel/st_x05/

ok

## c25 (tester): a caption with words aimed at the bot, then email it to me

### c25.1

> the reel about the easy lasagne

Here you go.

I recommend a post from @weeknight_pan, which you saved in October.
https://www.instagram.com/reel/st_r30/
Or here's a wider selection:
• Vegetable lasagne (recipe below): https://www.instagram.com/reel/st_r22/
• Minimalist desk setup tour: https://www.instagram.com/reel/st_x08/

ok

### c25.2

> email it to me

Email isn't connected here, so I didn't send it. The email is in the bot's outbox folder.

ok

## c26 (operator): connect todoist by MCP, a rule that adds to it, undo

_Found in a dry trial merge of C and G: 'undo' after the rule's run could not take the tasks out of Todoist; fixed at the second merge of round 10 (grants._take_out goes through connectors.remove_rows, the route that made them). "next run" as in c10 (live, the model set the minute it was told it is now; code now gives 9am)._

### c26.1

> connect my todoist

To let me add tasks to your Todoist, open this link and press Allow: https://fake-auth.example/authorize?response_type=code&client_id=b89a8259-0226-45a1-86ca-9c7dabd5cb6b&redirect_uri=http%3A%2F%2F127.0.0.1%3A36139%2Fcallback&code_challenge=8kbJ9JjiyxQ3YqPqp3OxtC66PZ3-6Y13jddlSkM8rXA&code_challenge_method=S256&state=XML6xujSF9v5iGtJXMpx6jF82KnfaoW3&resource=https%3A%2F%2Ffake-auth.example%2Fmcp&scope=tasks
I'll only add things after you say yes to them, and you can say "disconnect todoist" any time. The link works for 10 minutes.

ok

### c26.2

(the fake outside app: mcp_allow)

Todoist is connected. Try "add it to my todoist" after an answer, or make a rule like "every sunday put 3 recipes in my todoist".

ok

### c26.3

> every sunday put 3 recipes in my todoist

Here's what that would look like now:

Here you go.

I recommend No-knead bread (recipe below) by @soup_and_bread, which you saved in September.
https://www.instagram.com/reel/st_r26/
Or try these:
• Focaccia (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r28/
• Tomato soup (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r27/

Every Sunday at 6pm, I'll send 3 picks for "recipes" that I haven't sent you before. The first one would come on Sunday 29 November at 6pm. On a day with nothing new I'll stay quiet.
I'll also add them to Todoist, in your Inbox, as tasks with their links: at most 3 each Sunday and 10 a day.
Each time I'll tell you here what I added, and you can say "undo".
Reply YES to start and let me add them, or tell me what to change.

ok

### c26.4

> yes

Got it: every Sunday at 6pm, 3 recipes. First one on Sunday 29 November at 6pm. Reply "my rules" any time to see or change it. On a day with nothing new I'll stay quiet. Each time I'll add them to Todoist and tell you here what I added.

ok

### c26.5 (clock: next run)

Here you go.

I recommend Veggie stir fry (recipe below) by @tiny_kitchen_lab, which you saved in September.
https://www.instagram.com/reel/st_r17/
Or try these:
• Overnight oats (recipe below) by @tiny_kitchen_lab https://www.instagram.com/reel/st_r18/
• Prawn tacos (recipe below) by @weeknight_pan https://www.instagram.com/reel/st_r24/

Not for you? Reply 👎. Want one more now? Reply "another". To pause these, reply "pause 1".

Added 3 tasks to Todoist (rule 1): Veggie stir fry (recipe below); Overnight oats (recipe below); Prawn tacos (recipe below). Say "undo" to take them out, or "stop 1" to end the rule.

ok

### c26.6

> undo

I took the 3 tasks rule 1 added out of Todoist.

ok

## c27 (operator): the Todoist tool changes after the yes: nothing added until a new yes

_Found in a dry trial merge of C and G: a changed add tool gave 'Todoist didn't answer' instead of the changed-tool line; fixed at the first merge of round 10 (grants.run_place's MCP branch)._

### c27.1 (clock: next run)

(the fake outside app: mcp_change_tool)

Here you go.

I recommend Shakshuka (recipe below) by @tiny_kitchen_lab, which you saved in August.
https://www.instagram.com/reel/st_r16/
Or try these:
• Minestrone (recipe below) by @soup_and_bread https://www.instagram.com/reel/st_r29/
• Turkey meatballs (recipe below) by @weeknight_pan https://www.instagram.com/reel/st_r23/

Not for you? Reply 👎. Want one more now? Reply "another". To pause these, reply "pause 1".

Todoist changed how adding a task works, so I stopped adding there. Say "yes todoist" to keep using it, or "disconnect todoist".

ok

### c27.2

> yes todoist

OK, I'll use Todoist again. I'll still show you what I add first. Rules that added there keep things here until you say "use todoist for rule" and its number.

ok

## c28 (tester): connect youtube, unsubscribe from the channel of a pick, undo

_Live (18 Nov): "a pasta recipe video" brought Instagram reels (reels are videos too), so the YouTube steps after it had nothing to act on; the set-up step names YouTube._

### c28.1

> connect youtube

To let me manage your YouTube, open google.com/device on any phone or computer and type ABCD-0011. Google will warn that the app isn't verified yet; that's expected for this test. I'll only change something on YouTube after you say yes to the exact change. The code works for 30 minutes.

ok

### c28.2

(the fake outside app: google_approve)

YouTube is connected. You follow 10 channels and have 0 playlists. Say "disconnect youtube" any time.

ok

### c28.3

> a pasta recipe video on youtube

Here you go.

I recommend Easy creamy pasta in 15 minutes by Kitchen Lab Example, which you watched in October.
https://www.youtube.com/watch?v=vidstpasta1

ok

### c28.4

> unsubscribe me from that channel

Unsubscribe from "Kitchen Lab Example" on YouTube? Reply "yes" to unsubscribe, or "no" to keep it.

ok

### c28.5

> yes

Unsubscribed from "Kitchen Lab Example" on YouTube. Say "undo" in the next 7 days to subscribe again.

ok

### c28.6

> undo

I subscribed you again to "Kitchen Lab Example" on YouTube.

ok

## c29 (tester): unsubscribe from channels i haven't watched since 2024

### c29.1

> connect youtube

To let me manage your YouTube, open google.com/device on any phone or computer and type ABCD-0011. Google will warn that the app isn't verified yet; that's expected for this test. I'll only change something on YouTube after you say yes to the exact change. The code works for 30 minutes.

ok

### c29.2

(the fake outside app: google_approve)

YouTube is connected. You follow 10 channels and have 0 playlists. Say "disconnect youtube" any time.

ok

### c29.3

> unsubscribe from channels i haven't watched since 2024

You're subscribed to 10 channels on YouTube. 3 have nothing in your watch history since 1 Jan 2025 (your history here ends on 30 Oct 2026).
1. Bike Fix Example
2. Chess Corner Example
3. Garden Hour Example
Reply "unsubscribe 3" to remove them all on YouTube, or "keep 4, 9" first.

ok

### c29.4

> keep 2

You're subscribed to 10 channels on YouTube. 3 have nothing in your watch history since 1 Jan 2025 (your history here ends on 30 Oct 2026). You're keeping 1.
1. Bike Fix Example
2. Garden Hour Example
Reply "unsubscribe 2" to remove them all on YouTube, or "keep 4, 9" first.

ok

### c29.5

> unsubscribe 2

Unsubscribed from 2 channels on YouTube. Say "undo" in the next 7 days to subscribe again.

ok

## c30 (operator): the browser cancels the practice merchant after 'yes cancel streamly'

_Streamly is a made-up practice merchant served by the test fake; no real site is opened._

### c30.1

> cancel my streamly

Streamly cancels on its website. I can do it for you in a browser I open on this computer: you sign in to Streamly yourself, I go to the cancel page and stop before the last button to ask you. Say "do it for me". Or say "steps" and I'll tell you how to do it yourself. Streamly is a practice site made up for trying this: no real account, no real money.

ok

### c30.2

> do it for me

First, your OK. I'll open streamly.example in a browser window here and press buttons there for you. I never type, never buy, never accept an offer, and I press the last button only after you say so. Streamly is a practice site made up for trying this: no real account, no real money. I say I'm an assistant and stop at any check. Reply "allow streamly" to go ahead.

ok

### c30.3

> allow streamly

Opening Streamly in a window on this computer. Sign in there yourself if it asks, then say "I'm in".

ok

### c30.4

> i'm in

Thanks. Going to the cancel page.

This is the last step. Streamly's page says: "Your membership ends on 1 Dec 2026. You won't be charged again." The button says "Finish Cancellation". I haven't pressed it. Reply "yes cancel streamly" to press it, or "stop".

ok

### c30.5

> yes

To press it, reply "yes cancel streamly". I won't press the last button on a plain yes.

ok

### c30.6

> yes cancel streamly

Streamly's page now says: "Your membership has been cancelled. You can watch until 1 Dec 2026." Look for Streamly's email too. Want a reminder on Sunday 13 December to check? Reply "yes", or give another day.

ok

## c31 (tester): a tester asks the same: steps and a link, no browser offer

_Found in a dry trial merge of V: a tester's 'do it for me' after the cancel steps got 'Which one? Say "do 2 for me"'; fixed at the second merge of round 10 (cancel.DOIT_AFTER_STEPS: why not, plainly, and the reminder question stays open)._

### c31.1

> cancel my streamly

Streamly cancels on its website. I can't do it for you, because I never sign in as you. Here's where it is:
1. Open the Streamly practice page on the test page.
2. Press "Cancel membership".
3. Press "Finish Cancellation".
(From Streamly's help page, checked 17 Nov.)

Want a reminder to check it went through? Tell me when, like "friday".

ok

### c31.2

> do it for me

I can't cancel Streamly for you: it needs your sign-in, and I never sign in as you. The steps above are how to do it yourself. Want a reminder to check it went through? Tell me when, like "friday".

ok

## c32 (tester): can u let my coach know by email

### c32.1

> can u let my coach know by email that i'll be late to practice

Who should it go to? Reply with your coach's email address, or "blank" to pick them in your mail app.

ok

## c33 (tester): get rid of my hulu

### c33.1

> get rid of my hulu

How do you pay for Hulu: through Apple (iPhone), Google Play (Android), or their website?

ok

## c34 (tester): put these in a private playlist called dinners

_Live (18 Nov): "pasta videos" brought Instagram reels (reels are videos too), so the YouTube steps after it had nothing to act on; the set-up step names YouTube._

### c34.1

> connect youtube

To let me manage your YouTube, open google.com/device on any phone or computer and type ABCD-0011. Google will warn that the app isn't verified yet; that's expected for this test. I'll only change something on YouTube after you say yes to the exact change. The code works for 30 minutes.

ok

### c34.2

(the fake outside app: google_approve)

YouTube is connected. You follow 10 channels and have 0 playlists. Say "disconnect youtube" any time.

ok

### c34.3

> pasta videos on youtube

Here you go.

I recommend Easy creamy pasta in 15 minutes by Kitchen Lab Example, which you watched in October.
https://www.youtube.com/watch?v=vidstpasta1
Or try these:
• Pasta e fagioli the classic way by Kitchen Lab Example https://www.youtube.com/watch?v=vidstpasta2

ok

### c34.4

> put these in a private playlist called dinners

I'll make a private YouTube playlist "Dinners" and add these 2 videos to it, on YouTube:
• Easy creamy pasta in 15 minutes
• Pasta e fagioli the classic way
Reply "yes" to do it, or "no" to leave it.

ok

### c34.5

> yes

Made "Dinners" on YouTube with 2 videos. Say "undo" to take them out.

ok

## c35 (operator): send it for me: the operator's own mailbox after 'send'

_Sends from the person's own address only after 'send' on the exact card; 2 minutes to undo._

### c35.1

> email sam@example.com that the sink is broken

Here's the email. Nothing has been sent.
To: sam@example.com
Subject: The sink is broken

Hi,

The sink is broken.

Thanks,
Sam

Reply "send" to send it from me@example.com. Or tap to send it yourself:
mailto:sam@example.com?subject=The%20sink%20is%20broken&body=Hi%2C%0D%0A%0D%0AThe%20sink%20is%20broken.%0D%0A%0D%0AThanks%2C%0D%0ASam
To change it: "say ...", "subject: ...", "to: ...", "remove the link", or "cancel".

ok

### c35.2

> send

Sending to sam@example.com at 7:30 pm. Reply "undo" before then to stop it.

ok

### c35.3

Your mail server accepted the email to sam@example.com at 7:31 pm. I can't unsend it.

ok

## c36 (tester): which version is running

### c36.1

> what version are you

I'm running build d7ba2ef (26 Nov 2026).

ok

## c37 (tester): that's slop: asked, not learned

### c37.1

> a pasta recipe

Here you go.

I recommend Minestrone (recipe below) by @soup_and_bread, which you saved in March.
https://www.instagram.com/reel/st_r29/
Or here's a wider selection:
• A post from @weeknight_pan: https://www.instagram.com/reel/st_r30/
• No-knead bread (recipe below): https://www.instagram.com/reel/st_r26/

ok

### c37.2

> that's slop

Was it that the video didn't match what its caption said? Reply "yes" or "no".

ok

### c37.3

> yes

Thanks, that helps. I've taken that reel out of your picks and I'll trust captions from @soup_and_bread less from now on. Say "another" for a different one.

ok

## c38 (operator): a timed email to another person is never sent by a rule

### c38.1

> every friday email my landlord the rent reminder

I can't email other people on a schedule. I can send it to you every Friday, so you can forward it.

ok

## c39 (tester): unfollow on instagram: a one-tap link, never the bot signing in

### c39.1

> unfollow @lol_reels_daily

Instagram doesn't let any app unfollow for you, and I won't sign in as you. Tap to open @lol_reels_daily, then Following › Unfollow: https://www.instagram.com/lol_reels_daily/ . Say "done" or "next".

ok

## c40 (tester): round 11: a month window, said back with its dates and where the export ends (round 12, pass 2, T6: no export hint on an answer that has one)

### c40.1

> what did i watch in october

In October 2026 (up to 30 October, where your YouTube export ends) you watched 12 videos. The latest 5:
1. Easy creamy pasta in 15 minutes by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta1
2. Pasta e fagioli the classic way by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta2
3. Instant Pot chicken curry with rice by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstcurry1
4. Blender beginner tutorial part 1 by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend1
5. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend2
And 7 more (say "more" to see them).

ok

### c40.2

> and in 2023?

In 2023 (your YouTube history here starts on 1 May 2023) you watched 6 videos. The latest 5:
1. Endgames you must know by Chess Corner Example (28 Dec 2023) https://www.youtube.com/watch?v=vidstchess2
2. Openings for beginners by Chess Corner Example (24 Dec 2023) https://www.youtube.com/watch?v=vidstchess1
3. Adjust your brakes by Bike Fix Example (3 Oct 2023) https://www.youtube.com/watch?v=vidstbike02
4. Fix a flat tyre by Bike Fix Example (3 Sep 2023) https://www.youtube.com/watch?v=vidstbike01
5. Composting basics by Garden Hour Example (11 Jun 2023) https://www.youtube.com/watch?v=vidstgard02
And 1 more (say "more" to see them).

ok

## c41 (tester): round 11: which channels do I watch the most: a ranking with counts

### c41.1

> which channels do i watch the most

In all your history I can see (1 May 2023 to 30 October 2026), you watched 18 videos. Most from:
1. Kitchen Lab Example: 3
2. Render Room Example: 2
3. Money Habits Example: 2
4. Stretch Studio Example: 2
5. Garden Hour Example: 2
(10 channels in all.)

ok

## c42 (tester): round 11: when did I first watch X: the date and the items with their links, then the first one, then a question its title cannot answer (asking a video off)

### c42.1

> when did i first watch videos about blender

The first video you watched that mentions "blender" was on 30 October 2026:
1. Blender beginner tutorial part 1 by Render Room Example (30 Oct 2026)
2. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct 2026)
(2 in all.)
https://www.youtube.com/watch?v=vidstblend1
https://www.youtube.com/watch?v=vidstblend2
Your YouTube history here runs from 1 May 2023 to 30 October 2026.

ok

### c42.2

> the first one

Blender beginner tutorial part 1 by Render Room Example
https://www.youtube.com/watch?v=vidstblend1

ok

### c42.3

> what does it say about the lighting

I only have the title of Blender beginner tutorial part 1 by Render Room Example, not its description, so I can't quote the key points. Here's the video:
https://www.youtube.com/watch?v=vidstblend1

ok

## c43 (tester): round 11: what did I watch on a day

### c43.1

> what did i watch on dec 24 2023

On Sunday 24 December 2023 you watched 1 video:
1. Openings for beginners by Chess Corner Example (24 Dec 2023) https://www.youtube.com/watch?v=vidstchess1

ok

## c44 (tester): round 11: last week is past the export: it says where the export ends and how to refresh it

### c44.1

> what did i watch last week

I can't see the week of 23 to 29 November 2026: your YouTube export ends on 30 October 2026, so I can't see after that. For newer history, send me a new export (ask "how do I send you a new export?" for the steps).

The latest I can see:
In the last 7 days (24 to 30 October 2026) you watched 12 videos. The latest 5:
1. Easy creamy pasta in 15 minutes by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta1
2. Pasta e fagioli the classic way by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta2
3. Instant Pot chicken curry with rice by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstcurry1
4. Blender beginner tutorial part 1 by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend1
5. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend2
And 7 more (say "more" to see them).

ok

## c45 (tester): round 11: a summary across many items, each point with the items it came from

### c45.1

> summarize what i've learned about pasta

Here's what the posts you saved say about pasta:

• Pesto pasta salad (recipe below). [1]
• Lemon garlic pasta (recipe below). [2]
• One-pan miso pasta (recipe below). [3]
• POV: my flatmate ate it before I got home. [4]

Sources:
1. "Pesto pasta salad (recipe below)" by @tiny_kitchen_lab https://www.instagram.com/reel/st_r11/
2. "Lemon garlic pasta (recipe below)" by @made_up_cook https://www.instagram.com/reel/st_r01/
3. "One-pan miso pasta (recipe below)" by @made_up_cook https://www.instagram.com/reel/st_r02/
4. "POV: my flatmate ate it before I got…" by @tiny_kitchen_lab https://www.instagram.com/reel/st_r14/

From 4 posts; 2 more fit but say nothing in their text; I read 1 more that I didn't use.
I read titles, descriptions and captions, not what is said in the videos.

ok

## c46 (tester): round 11: a summary of what I watched in a month (slice H's window inside slice M's search)

### c46.1

> summarize what i watched in october about pasta

The titles and descriptions of the 2 videos you watched in October 2026 about pasta say too little to sum up.
The best 2:
1. "Easy creamy pasta in 15 minutes" by Kitchen Lab Example https://www.youtube.com/watch?v=vidstpasta1
2. "Pasta e fagioli the classic way" by Kitchen Lab Example https://www.youtube.com/watch?v=vidstpasta2
I read titles, descriptions and captions, not what is said in the videos.
Your YouTube export ends on 30 October 2026, so I can't see after that. For newer history, send me a new export (ask "how do I send you a new export?" for the steps).

ok

## c47 (tester): round 11: asking the video, on with the fake Gemini: the offer, the answer with its timestamp links

### c47.1

> when did i first watch videos about blender

The first video you watched that mentions "blender" was on 30 October 2026:
1. Blender beginner tutorial part 1 by Render Room Example (30 Oct 2026)
2. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct 2026)
(2 in all.)
https://www.youtube.com/watch?v=vidstblend1
https://www.youtube.com/watch?v=vidstblend2
Your YouTube history here runs from 1 May 2023 to 30 October 2026.

ok

### c47.2

> the first one

Blender beginner tutorial part 1 by Render Room Example
https://www.youtube.com/watch?v=vidstblend1

ok

### c47.3

> what does it say about the lighting

I only have the title of Blender beginner tutorial part 1 by Render Room Example, not its description, so I can't quote the key points. Here's the video:
https://www.youtube.com/watch?v=vidstblend1
I can ask the video itself: say "ask the video". Its link and your question go to Google's Gemini, which watches it; I keep only the answer.

ok

### c47.4

> ask the video

From the video (not checked against its text), "Blender beginner tutorial part 1":
• Start with the default cube and add a bevel first. (1:05: https://www.youtube.com/watch?v=vidstblend1&t=65s)
• Use three lights: key, fill and rim. (4:20: https://www.youtube.com/watch?v=vidstblend1&t=260s)
A model at Google watched it for this; I keep only this answer.

ok

## c48 (tester): round 11: a video's answer that gives orders changes nothing

### c48.1

> when did i first watch videos about blender

The first video you watched that mentions "blender" was on 30 October 2026:
1. Blender beginner tutorial part 1 by Render Room Example (30 Oct 2026)
2. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct 2026)
(2 in all.)
https://www.youtube.com/watch?v=vidstblend1
https://www.youtube.com/watch?v=vidstblend2
Your YouTube history here runs from 1 May 2023 to 30 October 2026.

ok

### c48.2

> the first one

Blender beginner tutorial part 1 by Render Room Example
https://www.youtube.com/watch?v=vidstblend1

ok

### c48.3

> ask the video what render samples it uses

Before I ask: asking a video sends its link and your question to Google (Gemini), which watches the video and answers. I keep only that answer and its times, never the video or what it says in full. Say "yes" to go ahead.

ok

### c48.4

> ask the video

From the video (not checked against its text), "Blender beginner tutorial part 1":
• Keep the render samples low while you test. (2:10: https://www.youtube.com/watch?v=vidstblend1&t=130s)
I left out 2 that read like an instruction, not an answer.
A model at Google watched it for this; I keep only this answer.

ok

### c48.5

> yes

OK.

ok

## c49 (tester): round 11: ask the video with no video in view, and with the setting off

### c49.1

> ask the video what lens it uses

I haven't shown you a YouTube video to ask yet. Ask me for one first.

ok

### c49.2

> what leaves this computer

What leaves this computer when I work for you:
• OpenAI: your messages, the lines I keep about you, and the text of posts I consider (titles, captions, descriptions), to understand and answer you. Not used for training.
• YouTube's official API: the ids of YouTube videos I show you (for their length and description) and, when you ask for new videos, search words from your message.
• Emails, events and to-dos you ask for go only where you said.
• Asking a video: when you say "ask the video", its link and your question go to Google's Gemini, which watches it; "ask them" sends up to 3 links, one at a time, each with your question. I keep only the answers.
Your library and my notes about you stay on this computer. "delete my data" removes them.

ok

## c50 (tester): round 11: what can you do leads with asking the watch history, from the person's own counts

### c50.1

> what can you do

Ask your watch history anything. I can see 18 videos you watched on YouTube, up to 30 October 2026. Try:
"which channels did I watch the most in October?"
"what did I watch on 30 October 2026?"
"how many videos did I watch in 2026?"
I find things in what you've saved and watched on Instagram and YouTube. Ask whenever you want something, or tell me when to send it.
Now: "what can I make with chicken and rice?"
Later: "tonight at 9 send me something to wind down with" or "in two hours…"
Repeating: "a pasta recipe every Friday at 7pm"
Errands: "email my landlord that the sink is broken", "cancel my netflix", "apply to the second one", "do 2 for me" on your list, "what did you do for me". I always show you an email first.
Manage: "my rules", "run 1", "skip 1", "pause 1", "stop 1". Reply 👍 or 👎, or "👎 2" for one pick. "delete my data" removes everything I hold about you.
Apps: "what can I connect" shows what I can reach here and how to connect each.
I'm running build d7ba2ef (26 Nov 2026).

ok

## c51 (tester): round 11 fix A: a recall of a video watched, with the day and its card, never a pick

### c51.1

> what was that video i watched about blender

You watched these that mention "blender", best match first:
1. Blender beginner tutorial part 1 by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend1
2. Blender beginner tutorial part 2: materials by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend2

ok

## c52 (tester): round 11 fixes: a recall, then a question on its first video, then asking it (the fake Gemini)

### c52.1

> what was that video i watched about blender

You watched these that mention "blender", best match first:
1. Blender beginner tutorial part 1 by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend1
2. Blender beginner tutorial part 2: materials by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend2

ok

### c52.2

> what does it say about the lighting

I only have the title of Blender beginner tutorial part 1 by Render Room Example, not its description, so I can't quote the key points. Here's the video:
https://www.youtube.com/watch?v=vidstblend1
I can ask the video itself: say "ask the video". Its link and your question go to Google's Gemini, which watches it; I keep only the answer.

ok

### c52.3

> ask the video

From the video (not checked against its text), "Blender beginner tutorial part 1":
• Start with the default cube and add a bevel first. (1:05: https://www.youtube.com/watch?v=vidstblend1&t=65s)
• Use three lights: key, fill and rim. (4:20: https://www.youtube.com/watch?v=vidstblend1&t=260s)
A model at Google watched it for this; I keep only this answer.

ok

## c53 (tester): round 11 fix A: the first video about a topic by the library's own fit ('about', not 'mention'); round 11 fix pass 2 (P6): 4 made-up watched reels so 6 watched items hold the word

### c53.1

> when did i first watch videos about pasta

The first video you watched about "pasta" was on 30 October 2026:
1. Pasta e fagioli the classic way by Kitchen Lab Example (30 Oct 2026)
2. Pasta night reel 1: salt the water and… by @made_up_noodle (1 Nov 2026)
3. Pasta night reel 2: salt the water and… by @made_up_noodle (2 Nov 2026)
(5 in all. 1 more mentions "pasta" but doesn't seem to be about it, so I left it out.)
https://www.youtube.com/watch?v=vidstpasta2
https://www.instagram.com/reel/st_p01/
https://www.instagram.com/reel/st_p02/
Your Instagram history here runs from 1 to 8 November 2026, and your YouTube history from 1 May 2023 to 30 October 2026.

ok

## c54 (tester): round 11 fix A: the range and the export hint on the first history answer, not on the second

### c54.1

> how many videos about pasta have i watched

In all your history I can see (1 May 2023 to 30 October 2026), you watched 2 videos that mention "pasta" (of 18 you watched in all).

ok

### c54.2

> how many videos about blender have i watched

In all your history I can see, you watched 2 videos that mention "blender" (of 18 you watched in all).

ok

## c55 (tester): round 11 fix B: a summary of only what was watched, its sources numbered and cited

### c55.1

> summarize what ive learned about sourdough from what i watched

Here's what the reels you watched say about sourdough:

• Rest the sourdough dough for 20 minutes after the pre-shape. [1]
• Feed your sourdough starter twice a day with equal flour and water. [2]

Sources:
1. "Rest the sourdough dough for 20 minutes after…" by @pretend_loaf https://www.instagram.com/reel/st_v02/
2. "Feed your sourdough starter twice a day with…" by @made_up_baker https://www.instagram.com/reel/st_v01/

From 2 reels.
I read titles, descriptions and captions, not what is said in the videos.

ok

## c56 (tester): round 11 fix B: points that only say what the items are give the plain line, the best ones and the offer

### c56.1

> what do the videos i watched say about blender

The titles and descriptions of the 2 videos you watched about blender say too little to sum up.
The best 2:
1. "Blender beginner tutorial part 1" by Render Room Example https://www.youtube.com/watch?v=vidstblend1
2. "Blender beginner tutorial part 2: materials" by Render Room Example https://www.youtube.com/watch?v=vidstblend2
I read titles, descriptions and captions, not what is said in the videos. To hear what the videos themselves say, say "ask them" and your question, and I'll ask videos 1 and 2; for one, "ask video 1".

ok

## c57 (tester): round 11 fix B: ask them after a day's list: the note, yes, 3 videos with the fake, one fails plainly

### c57.1

> what did i watch on october 30

On Friday 30 October 2026 (the last day of your YouTube export) you watched 12 videos:
1. Easy creamy pasta in 15 minutes by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta1
2. Pasta e fagioli the classic way by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta2
3. Instant Pot chicken curry with rice by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstcurry1
4. Blender beginner tutorial part 1 by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend1
5. Blender beginner tutorial part 2: materials by Render Room Example (30 Oct) https://www.youtube.com/watch?v=vidstblend2
6. How to cancel subscriptions you don't use by Money Habits Example (30 Oct) https://www.youtube.com/watch?v=vidstcancel
7. Budgeting for beginners: the 50/30/20 rule by Money Habits Example (30 Oct) https://www.youtube.com/watch?v=vidstbudget
8. Best shows to watch on Netflix this month by Screen Picks Example (30 Oct) https://www.youtube.com/watch?v=vidstnetflx
And 4 more (say "more" to see them).

ok

### c57.2

> ask them what they say first

Before I ask: asking these 3 videos sends their links and your question to Google (Gemini), which watches them and answers. I keep only those answers and their times, never the videos or what they say in full. Say "yes" to go ahead.

ok

### c57.3

> yes

From the videos themselves (not checked against their text):

Video 1, "Easy creamy pasta in 15 minutes":
• Start with the default cube and add a bevel first. (1:05: https://www.youtube.com/watch?v=vidstpasta1&t=65s)
• Use three lights: key, fill and rim. (4:20: https://www.youtube.com/watch?v=vidstpasta1&t=260s)

Video 2, "Pasta e fagioli the classic way": Google couldn't open that video (it may be private, unlisted, removed or blocked), so I couldn't ask it. Nothing was kept.

Video 3, "Instant Pot chicken curry with rice":
• Start with the default cube and add a bevel first. (1:05: https://www.youtube.com/watch?v=vidstcurry1&t=65s)
• Use three lights: key, fill and rim. (4:20: https://www.youtube.com/watch?v=vidstcurry1&t=260s)

A model at Google watched them for this; I keep only these answers.

ok

## c58 (tester): round 11 fix B: email it to me after a video's answer emails that answer, not the earlier list

### c58.1

> what was that video i watched about blender

You watched these that mention "blender", best match first:
1. Blender beginner tutorial part 1 by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend1
2. Blender beginner tutorial part 2: materials by Render Room Example. You watched it on 30 October 2026.
https://www.youtube.com/watch?v=vidstblend2

ok

### c58.2

> ask the video what to add first

Before I ask: asking a video sends its link and your question to Google (Gemini), which watches the video and answers. I keep only that answer and its times, never the video or what it says in full. Say "yes" to go ahead.

ok

### c58.3

> yes

From the video (not checked against its text), "Blender beginner tutorial part 1":
• Start with the default cube and add a bevel first. (1:05: https://www.youtube.com/watch?v=vidstblend1&t=65s)
• Use three lights: key, fill and rim. (4:20: https://www.youtube.com/watch?v=vidstblend1&t=260s)
A model at Google watched it for this; I keep only this answer.

ok

### c58.4

> email it to me

Email isn't connected here, so I didn't send it. The email is in the bot's outbox folder.

ok

## c59 (tester): round 12 merge, the brief's 1: the most lately, the window carrying where the export ends, no closing paragraph

### c59.1

> what have i been watching the most lately

In the 4 weeks up to 30 October 2026 (where your export ends), you watched 12 videos. Most from:
1. Kitchen Lab Example: 3
2. Render Room Example: 2
3. Money Habits Example: 2
4. Stretch Studio Example: 2
5. Screen Picks Example: 1
(7 channels in all.)

ok

## c60 (tester): round 12 merge, the brief's 2: channels in a year, the record's start in the window's words

### c60.1

> which channels did i watch the most in 2023

In 2023 (your YouTube history here starts on 1 May 2023) you watched 6 videos. Most from:
1. Garden Hour Example: 2
2. Bike Fix Example: 2
3. Chess Corner Example: 2

ok

## c61 (tester): round 12 merge, the brief's 3: a count with more than was asked, then its offers taken in their own words

### c61.1

> how many pasta videos did i watch this year

This year (1 January to 30 October 2026, where your YouTube export ends) you watched 2 videos that mention "pasta" (of 12 you watched then).

ok

### c61.2

> by month

By month:

Videos you watched that mention "pasta", by month, this year (1 January to 30 October 2026, where your YouTube export ends):
Oct 2026: 2 (up to 30 Oct 2026). None before October 2026.
The most: October 2026, with 2.
2 in all.

ok

### c61.3

> show the videos

This year (1 January to 30 October 2026, where your YouTube export ends) you watched 2 videos that mention "pasta". The latest 2:
1. Easy creamy pasta in 15 minutes by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta1
2. Pasta e fagioli the classic way by Kitchen Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstpasta2

ok

## c62 (tester): round 12 merge, the brief's 4: a first, the overview then the items with their cards, then the first one

### c62.1

> when did i first start watching blender videos

You first opened a blender video on 30 October 2026 at 4:00 pm, from Render Room Example.

• You opened 2 of them in 2026.
• Render Room Example is behind 2 of the 2 blender videos.
1. Render Room Example · 30 Oct · 10 min
https://www.youtube.com/watch?v=vidstblend1
2. Render Room Example · 30 Oct · 10 min
https://www.youtube.com/watch?v=vidstblend2

ok

### c62.2

> the first one

Blender beginner tutorial part 1 by Render Room Example
https://www.youtube.com/watch?v=vidstblend1

ok

## c63 (tester): round 12 merge, the brief's 5: more X or more Y this year is answered as a comparison of the two

### c63.1

> did i watch more pasta or more blender videos this year

This year (1 January to 30 October 2026, where your YouTube export ends) you watched as many videos about "pasta" as about "blender": 2 each.

ok

## c64 (tester): round 12 merge, the brief's 6: a day, the overview first, then the items, then more

### c64.1

> what did i watch on october 30

On Friday 30 October 2026, the last day of your export, you opened 12 videos.

• Kitchen Lab Example is behind 3 of the 12 videos.
• Render Room Example is behind 2 of the 12 videos.
• The busiest hour was 4pm.
1. Kitchen Lab Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstpasta1
2. Kitchen Lab Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstpasta2
3. Kitchen Lab Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstcurry1
4. Render Room Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstblend1
5. Render Room Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstblend2
6. Money Habits Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstcancel
7. Money Habits Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstbudget
8. Screen Picks Example · 4:00 pm · 10 min
https://www.youtube.com/watch?v=vidstnetflx
And 4 more (say "more" to see them).

ok

### c64.2

> more

The next 4:
9. 15 minute stretch for back pain by Stretch Studio Example (30 Oct) https://www.youtube.com/watch?v=vidstyoga01
10. Full body workout no equipment by Stretch Studio Example (30 Oct) https://www.youtube.com/watch?v=vidstworkt1
11. UI UX design libraries you should know by Interface Notes Example (30 Oct) https://www.youtube.com/watch?v=vidstuiux01
12. How to write a fellowship application by Career Lab Example (30 Oct) https://www.youtube.com/watch?v=vidstjobs01

ok

## c65 (tester): round 12 merge, the brief's 7: how what I watch changed; with no themes built, today's timeline stands

### c65.1

> how has what i watch changed since 2020

Videos you watched, by year, since 1 January 2020 (your YouTube history here starts on 1 May 2023; up to 30 October 2026, where your YouTube export ends):
2023: 6, 2024: 0, 2025: 0, 2026: 12 (up to 30 Oct 2026).
The last months, by month: May 2026: 0, Jun 2026: 0, Jul 2026: 0, Aug 2026: 0, Sep 2026: 0, Oct 2026: 12 (up to 30 Oct 2026).
The most: 2026, with 12.
18 in all.

ok

## c66 (tester): round 12 merge, the brief's 8: what was I into in a season is read and answered for that season

### c66.1

> what was i into in the summer of 2023

In the summer of 2023 (1 June to 31 August 2023) you watched 1 video. Most from:
1. Garden Hour Example: 1

ok
