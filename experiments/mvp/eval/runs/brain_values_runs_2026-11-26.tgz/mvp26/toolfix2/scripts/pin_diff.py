"""The pinned ledger diff of the tip against this round's: which entries were added, removed or changed, by class."""
import json, re, sys
from collections import Counter
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
def entries(d):
    return {(led, e[0], e[1]): (e[2], e[3]) for led, es in d.items() for e in es}
A, B = entries(a), entries(b)
def cls(k):
    led, kind, path = k
    p = re.sub(r"\[\d+\]", "[]", path)
    p = re.sub(r"^\[\]\.", "", p)
    p = re.sub(r"meta\.notes(\[\])?$", "meta.notes", p)
    return f"{kind} {p}"
print(f"ledgers: tip {len(a)}, now {len(b)}; entries: tip {len(A)}, now {len(B)}")
add = Counter(cls(k) for k in B if k not in A)
rem = Counter(cls(k) for k in A if k not in B)
chg = Counter(cls(k) for k in B if k in A and A[k] != B[k])
print("\nadded:"); [print(f"  {n:4d} {c}") for c, n in add.most_common()]
print("\nremoved:"); [print(f"  {n:4d} {c}") for c, n in rem.most_common()]
print("\nchanged value:"); [print(f"  {n:4d} {c}") for c, n in chg.most_common()]
print("\nlist lengths now (every list_len entry, frozen -> today):")
for k, v in sorted(B.items()):
    if k[1] == "list_len":
        print(f"  {k[0]} {k[2]}: {v[0]} -> {v[1]}" + ("" if k not in A else f"   (tip: {A[k][0]} -> {A[k][1]})"))
print("\nlist_len entries of the tip gone now:")
for k, v in sorted(A.items()):
    if k[1] == "list_len" and k not in B:
        print(f"  {k[0]} {k[2]}: {v[0]} -> {v[1]}")
