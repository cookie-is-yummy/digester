import sys, json
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, sys.argv[1] + "/experiments")
from mvp import eval_brain as E
h = E.Harness.scratch(base=S + "/mvp26/toolfix2/_lib_plans")
s, out = E.plans(h)
print(s["numbers_in_results"], s["numbers_recounted"])
print(sorted(s["not_recounted"].items(), key=lambda x: -x[1])[:30])
print("number findings", [(f.get("at"), f.get("where"), f.get("why", f.get("detail"))) for f in s["findings"]["number"]][:10])
