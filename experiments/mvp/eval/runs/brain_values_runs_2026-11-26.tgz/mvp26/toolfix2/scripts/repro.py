"""mvp26 toolfix2: each defect of the second attack (mvp25/check/report.txt), shown on the tree given (argv[1]),
with the attacker's probes plus the three live calls (run2 N019.0, N049.0, run1 N001.1). Prints what each defect
looks like; run before and after the fixes. Made-up library only, no model."""
import json, os, re, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = sys.argv[1]
OUT = sys.argv[2]
sys.path.insert(0, TREE + "/experiments")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from mvp import eval_brain as E
from mvp.brain import tools as TL, loop as BL, verify as V, fallback as FB, answer as A
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
import probes as PR
assert TL.__file__.startswith(TREE), TL.__file__
h = E.Harness.scratch(base=S + "/mvp26/toolfix2/_lib_repro")
out, done = PR.run(h)
L = []
p = L.append


def res(tid, rid):
    t, rec = done[tid]
    return next(c["result"] for c in rec["calls"] if c["result"].get("rid") == rid)


def finish(tid, form, mode="cells", t=None):
    if t is None:
        t, rec = done[tid]
        t.results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and not c["result"].get("is_error")}
    vt = V.Turn.of(t)
    cm = V.check_mode(mode)
    v = V.check_answer(form, t.results, vt, mode=cm)
    r2 = {"forms": [form]}
    BL._finish(r2, t, vt, [v], cm)
    return r2


p("== 1. the window before, on part-of-period windows")
for tid in ("T02", "T03", "T04"):
    t, rec = done[tid]
    for c in rec["calls"]:
        e = c["result"]
        if e.get("is_error") or c["name"] == "compare" or not (e.get("sheet") or {}).get("previous"):
            continue
        m = e["meta"]; pv = e["sheet"]["previous"]
        wd = m.get("window_dates") or {}
        bd = m.get("window_dates_before") or {}
        pw = V.Ledger({e["rid"]: e}).get(e["rid"]).prev_window()
        p(f"  {tid} {e['rid']} {json.dumps(c['args'].get('window'))}: window {wd.get('said')} ({wd.get('days')} d) | "
          f"before {pv.get('words')!r} items {pv.get('items')} | dates_before {bd.get('said')} ({bd.get('days')} d) | "
          f"checker reads {pw} | note: {[n for n in m['notes'] if 'not the same length' in n or 'window before' in n.lower()][:1]}")

p("== 2. ask-backs and the scope line")
for tid, lead, ask in (("T16", "I found a few: 5[r3.totals.items] videos on 25 October 2026.", ["r3.items[0]", "r3.items[4]"]),
                       ("T16", "Which one do you mean?", ["r3.items[0]", "r3.items[4]"]),
                       ("T08", "You saved 6[r1.totals.items] items.", ["r2.items[0]", "r2.items[1]"]),
                       ("T08", "Which one?", ["r4.items[3]"]),
                       ("T08", "Which one?", ["Is it the series, or one specific video (say its part number)?"])):
    for between in (ask, []):
        for mode in ("cells", "full"):
            r2 = finish(tid, {"lead": lead, "points": [], "ask_back": {"between": between}}, mode)
            a = r2["answer"]
            p(f"  {tid} {mode} lead={lead[:40]!r} between={between} -> {r2['lead_source']} ask={a['ask']} "
              f"cards={[c['ref'] for c in a['cards']]} scope={a['scope_line']!r}")
# a model lead that cites nothing, with picks from r2 (Wet Paper)
r2 = finish("T16", {"lead": "Here they are.", "points": [], "items": [{"ref": "r2.items[0]"}]})
p(f"  T16 lead cites nothing, picks r2.items[0] -> cards={[c['ref'] for c in r2['answer']['cards']]} "
  f"scope={r2['answer']['scope_line']!r}")

p("== 3. first_last no_match")
e = res("T08", "r5")
p(f"  T08 r5 first_last sourdough: error={e.get('error')} options={e.get('options')} items_with_words="
  f"{e.get('items_with_words')} notes={e['meta']['notes']}")

p("== 4. titles in code leads")
for tid in ("T16",):
    t, rec = done[tid]
    for rid in ("r1", "r2"):
        t.results = {rid: res(tid, rid)}
        cl = FB.code_lead(V.Ledger(t.results), None, V.Turn.of(t))
        p(f"  {tid} {rid} code lead ({cl['how']}): {cl['lead']!r} | marked: {cl.get('marked')!r}")

p("== 5. the timeline of N001.1")
t = h.turn("huh why so much cooking all of a sudden")
e = TL.call(t, "timeline", {"unit": "month", "window": {"preset": "all"}, "scope": {"only": ["cooking"]}})
p(f"  periods {len(e['sheet']['periods'])} of {e['meta']['rows_of'].get('periods')}; parts_of_day "
  f"{'parts_of_day' in (e['sheet'].get('when') or {})}; size {len(json.dumps(e['sheet'], ensure_ascii=False))}")

p("== 6a. busiest_weekday over a tie")
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        w = ((c["result"].get("sheet") or {}).get("when") or {})
        if w.get("busiest_weekday") or w.get("busiest_weekdays"):
            p(f"  {tid} {c['result']['rid']}: busiest_weekday={w.get('busiest_weekday')} busiest_weekdays={w.get('busiest_weekdays')}")
p("== 6b. a code lead over a tie (T16 r3, one day)")
t, rec = done["T16"]
t.results = {"r3": res("T16", "r3")}
cl = FB.code_lead(V.Ledger(t.results), None, V.Turn.of(t))
p(f"  {cl['how']}: {cl['lead']!r}; themes {[(r['name'], r['items']) for r in t.results['r3']['sheet'].get('themes', [])][:3]}")
p("== 6c. new themes' first days on ranked sheets")
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        nw = (c["result"].get("sheet") or {}).get("new") or {}
        for r in nw.get("themes") or []:
            p(f"  {tid} {c['result']['rid']} {c['name']}: new theme {r['name']} first_watched={r.get('first_watched')} "
              f"first note={any('first_watched' in n for n in c['result']['meta'].get('notes', []))}")
p("== 6d. stopped rows with items in the window")
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        st = (c["result"].get("sheet") or {}).get("stopped") or {}
        for r in st.get("themes") or []:
            if r.get("items"):
                p(f"  {tid} {c['result']['rid']}: stopped {r['name']} items={r['items']} previous={r.get('previous_items')} "
                  f"note={[n for n in c['result']['meta']['notes'] if 'stopped' in n and 'still' in n][:1]}")
p("== 6e. the levels note")
from collections import Counter
cnt = Counter()
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        e = c["result"]
        if e.get("is_error"):
            continue
        sh = e.get("sheet") or {}
        lists = sum(1 for k in ("areas", "themes", "channels") if sh.get(k))
        if lists >= 2:
            cnt[(c["name"], any(n.startswith("areas, themes and channels") for n in e["meta"].get("notes", [])))] += 1
p(f"  results with 2+ ranked lists, by tool and note: {sorted(cnt.items())}")
p("== 6f. a window past the export's end")
for c in done["T05"][1]["calls"]:
    e = c["result"]
    if e.get("is_error"):
        continue
    rid = e["rid"]
    p(f"  T05 {rid}: said={e['meta'].get('window_said')!r} window_cut={e['meta'].get('window_cut')} "
      f"cannot_see={json.dumps((e.get('sheet') or {}).get('cannot_see'))}")
p(f"  T05 turn limits: {done['T05'][0].limits}")
p("== 6g. saved-only YouTube lengths")
for tid, (t, rec) in done.items():
    for c in rec["calls"]:
        e = c["result"]
        rows = [r for r in (e.get("sheet") or {}).get("items") or [] if r.get("length") == "unknown"]
        if rows:
            p(f"  {tid} {e['rid']}: {len(rows)} rows of unknown length ({sorted({r['platform'] for r in rows})}); "
              f"note={[n for n in e['meta']['notes'] if 'length' in n.lower() and 'unknown' in n.lower()][:1]}")
p("== 6h. a search over one title (run2 N049.0)")
t = h.turn("that video about integrals, when did i watch it", search=FakeEngine(), learned=fake_learned)
e = TL.call(t, "search", {"how": "opened", "limit": 5, "query": "video about integrals", "window": {"preset": "all"}})
p(f"  rows {[(r['title'], r['when'][:10], r.get('same_title')) for r in e['sheet']['items']]}")
p(f"  notes {[n for n in e['meta']['notes'] if 'title' in n]}")
p("== 6i. new channels under the floor (run2 N019.0)")
t = h.turn("new channels i picked up this fall")
e = TL.call(t, "changes", {"against": "previous", "level": "channel", "window": {"words": "this fall"}})
nw = e["sheet"].get("new") or {}
p(f"  new.channels {[(r['name'], r['items']) for r in nw.get('channels') or []]}; under the floor "
  f"{[(r['name'], r['items'], r.get('first_watched')) for r in nw.get('small_channels') or []]}")
p(f"  channel rows new_in_window: {[(r['name'], r['items'], r.get('first_watched')) for r in e['sheet'].get('channels') or [] if r.get('new_in_window')]}")
with open(OUT, "w") as f:
    f.write("\n".join(L) + "\n")
print("\n".join(L))
