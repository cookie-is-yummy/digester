import sys, json
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp26/tools_tree/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL, verify as V
h = E.Harness.scratch(base=S + "/mvp26/toolfix2/_lib_repro")
t = h.turn("what was my last Brick Realm video")
e = TL.call(t, "first_last", {"subject": "Brick Realm", "which": "last"})
t2 = h.turn("x"); e2 = TL.call(t2, "first_last", {"subject": "Pan Theory", "which": "last"})
for tt, ee in ((t, e), (t2, e2)):
    title = ee["sheet"]["items"][0]["title"]
    for lead in (f'In all your history, the last Brick Realm video you opened was "{title}"[r1.items[0]], on 20 October 2026[r1.items[0].when].',
                 f'In all your history, the last Brick Realm video you opened was {title}[r1.items[0]], on 20 October 2026[r1.items[0].when].',
                 f'In all your history, the last Brick Realm video you opened was “{title}”[r1.items[0]], on 20 October 2026[r1.items[0].when].'):
        for mode in ("full", "cells"):
            v = V.check_answer({"lead": lead, "points": []}, tt.results, V.Turn.of(tt), mode=mode)
            print(mode, v.lead_ok, [(o.reasons, o.details[:2]) for o in v.lead])
