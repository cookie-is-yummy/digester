"""mvp26 toolfix2: the fixed cells recounted by hand from the made-up library's rows. Imports only the library's rows
(through recount.py, which imports tests/brain_library.py and nothing of tools, facts, history or names). The windows
before come from a table written by hand from the convention of DESIGN 27.1, never from the tool's words."""
import json, re, sys, os
from collections import Counter
from datetime import date, timedelta
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import recount as RC   # the library's rows only (it asserts nothing of the tools)
assert not any(m.startswith(("mvp.brain", "mvp.facts", "mvp.history")) for m in sys.modules), "imports the tools"
R = json.load(open(sys.argv[1]))
D = date
BY = {(r["tid"], k): (r, c) for r in R for k, c in enumerate(r["calls"])}
OUT, BAD = [], []


def ok(cond, what):
    (OUT if cond else BAD).append(("ok  " if cond else "BAD ") + what)


# ---------------------------------------------------------------- 1. the window before (hand table)
HAND = {  # (turn, call index): (window start, end, before start, end, before words)
    ("T02", 0): (D(2026, 10, 21), D(2026, 10, 30), D(2026, 10, 11), D(2026, 10, 20), "mid October 2026 (11 October to 20 October 2026)"),
    ("T02", 2): (D(2026, 10, 21), D(2026, 10, 30), D(2026, 10, 11), D(2026, 10, 20), "mid October 2026 (11 October to 20 October 2026)"),
    ("T02", 3): (D(2026, 10, 11), D(2026, 10, 20), D(2026, 10, 1), D(2026, 10, 10), "early October 2026 (1 October to 10 October 2026)"),
    ("T03", 0): (D(2023, 5, 1), D(2023, 8, 31), D(2023, 1, 1), D(2023, 4, 30), "early 2023 (1 January to 30 April 2023)"),
    ("T03", 1): (D(2023, 1, 1), D(2023, 4, 30), D(2022, 9, 1), D(2022, 12, 31), "late 2022 (1 September to 31 December 2022)"),
    ("T03", 2): (D(2023, 7, 1), D(2023, 12, 31), D(2023, 1, 1), D(2023, 6, 30), "the first half of 2023 (1 January to 30 June 2023)"),
    ("T03", 3): (D(2023, 9, 1), D(2023, 12, 31), D(2023, 5, 1), D(2023, 8, 31), "mid 2023 (1 May to 31 August 2023)"),
    ("T04", 0): (D(2023, 8, 1), D(2023, 8, 31), D(2023, 7, 1), D(2023, 7, 31), "July 2023"),
    ("T04", 1): (D(2026, 1, 1), D(2026, 1, 31), D(2025, 12, 1), D(2025, 12, 31), "December 2025"),
    ("T04", 2): (D(2026, 9, 1), D(2026, 9, 30), D(2026, 8, 1), D(2026, 8, 31), "August 2026"),
    ("T04", 3): (D(2026, 5, 1), D(2026, 5, 31), D(2026, 4, 1), D(2026, 4, 30), "April 2026"),
    ("T04", 4): (D(2026, 8, 1), D(2026, 8, 31), D(2026, 7, 1), D(2026, 7, 31), "July 2026"),
    ("T04", 5): (D(2025, 1, 1), D(2025, 4, 30), D(2024, 9, 1), D(2024, 12, 31), "late 2024 (1 September to 31 December 2024)"),
    ("T04", 6): (D(2024, 12, 1), D(2025, 2, 28), D(2024, 9, 1), D(2024, 11, 30), "the fall before (1 September to 30 November 2024)"),
    ("T04", 7): (D(2026, 9, 1), D(2026, 10, 30), D(2026, 6, 1), D(2026, 8, 31), "the summer before (1 June to 31 August 2026)"),
    ("X4", 0): (D(2026, 8, 21), D(2026, 8, 31), D(2026, 8, 11), D(2026, 8, 20), "mid August 2026 (11 August to 20 August 2026)"),
    ("X4", 1): (D(2026, 10, 1), D(2026, 10, 15), D(2026, 9, 16), D(2026, 9, 30), "the second half of September 2026 (16 September to 30 September 2026)"),
    ("X4", 2): (D(2026, 10, 1), D(2026, 10, 10), D(2026, 9, 21), D(2026, 9, 30), "late September 2026 (21 September to 30 September 2026)"),
    ("X4", 3): (D(2026, 9, 1), D(2026, 10, 30), D(2026, 5, 1), D(2026, 6, 29), "the same days of mid 2026 (1 May to 29 June 2026)"),
    ("X4", 4): (D(2024, 1, 1), D(2024, 6, 30), D(2023, 7, 1), D(2023, 12, 31), "the second half of 2023 (1 July to 31 December 2023)"),
}
NEW_MIN, NEW_SHARE, NEW_PREV_MAX = 5, 0.02, 5
for (tid, k), (a, b, pa, pb, words) in HAND.items():
    r, c = BY[(tid, k)]
    e = c["result"]; sh = e["sheet"]; m = e["meta"]
    evs = RC.sel(a, b); pevs = RC.sel(pa, pb)
    n, pn = len(RC.items_of(evs)), len(RC.items_of(pevs))
    tag = f"{tid}.{k} {c['args']['window']['words']}"
    ok(sh["previous"]["words"] == words, f"{tag}: before words {sh['previous']['words']!r}")
    ok(sh["totals"]["items"] == n and sh["previous"]["items"] == pn,
       f"{tag}: {sh['totals']['items']} now (recount {n}), {sh['previous']['items']} before (recount {pn})")
    db = m.get("window_dates_before") or {}
    ok((db.get("start"), db.get("end")) == (pa.isoformat(), pb.isoformat()), f"{tag}: window_dates_before {db.get('said')}")
    same = (b - a).days == (pb - pa).days
    note = any(x.startswith("The window before is not the same length") for x in m["notes"])
    ok(m.get("same_days_before") == same and note == (not same),
       f"{tag}: {(b - a).days + 1} days against {(pb - pa).days + 1}, same_days_before={m.get('same_days_before')}, note={note}")
    # new and stopped themes against the window before (the floor of DESIGN: 5 items and 2%, at most 5 before)
    tc = Counter(RC.ITEM[i]["theme"] for i in RC.items_of(evs)); pc = Counter(RC.ITEM[i]["theme"] for i in RC.items_of(pevs))
    for row in (sh.get("new") or {}).get("themes") or []:
        th = next(x for x, nm in RC.THEME.items() if nm == row["name"])
        ok(row["items"] == tc[th] and row["previous_items"] == pc[th] and pc[th] <= NEW_PREV_MAX,
           f"{tag}: new theme {row['name']} {row['items']}/{row['previous_items']} (recount {tc[th]}/{pc[th]})")
    for row in (sh.get("stopped") or {}).get("themes") or []:
        th = next(x for x, nm in RC.THEME.items() if nm == row["name"])
        ok(row["items"] == tc[th] and row["previous_items"] == pc[th],
           f"{tag}: stopped theme {row['name']} {row['items']}/{row['previous_items']} (recount {tc[th]}/{pc[th]})")
        if row["items"]:
            ok(any(row["name"] in x and str(row["items"]) in x and "stopped" in x for x in m["notes"]),
               f"{tag}: stopped {row['name']} still has {row['items']}: note")

# ---------------------------------------------------------------- 2. weekdays over a tie (every result with `when`)
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
ties = singles = 0
for (tid, k), (r, c) in BY.items():
    e = c["result"]
    if e.get("is_error") or "sheet" not in e or c["name"] in ("search", "find", "learned"):
        continue
    w = e["sheet"].get("when") or {}
    if not (w.get("busiest_weekday") or w.get("busiest_weekdays")):
        continue
    wd = e["meta"]["window_dates"]
    a, b = D.fromisoformat(wd["start"]), D.fromisoformat(wd["end"])
    scope = c["args"].get("scope") or {}
    subj = c["args"].get("subject")
    names = list(scope.get("only") or []) + ([subj] if subj else [])
    priv = "dating" in [x.lower() for x in names] or (r["unlock"] == "relationships" and r["carried_unlock"] is None)
    evs = RC.sel(a, b, how=scope.get("how", "opened"), platforms=tuple(scope.get("platforms") or ()),
                 length=scope.get("length", "any"), weekday=scope.get("weekday"),
                 only=RC.only_fn(names) if names else None, private=priv)
    cnt = Counter(x["d"].weekday() for x in evs)
    top = max(cnt.values())
    tied = [DAYS[d] for d in range(7) if cnt[d] == top]
    if len(tied) > 1:
        ties += 1
        ok("busiest_weekday" not in w and w.get("busiest_weekdays") == tied and w.get("busiest_weekday_opens") == top,
           f"{tid}.{k}: tie {tied} at {top}: {w.get('busiest_weekdays')} {w.get('busiest_weekday_opens')}")
    else:
        singles += 1
        ok(w.get("busiest_weekday") == tied[0] and "busiest_weekdays" not in w, f"{tid}.{k}: one day {tied[0]}")
OUT.append(f"     weekdays: {ties} ties, {singles} single days")

# ---------------------------------------------------------------- 3. new channels under the floor (X1, this fall)
r, c = BY[("X1", 0)]
sh = c["result"]["sheet"]
a, b = D(2026, 9, 1), D(2026, 10, 30)
evs = RC.sel(a, b)
first = {}
for x in RC.EV:
    if x["kind"] == "opened" and x["theme"] != "da":
        first[x["channel"]] = min(first.get(x["channel"], x["d"]), x["d"])
by = {}
for x in evs:
    by.setdefault(x["channel"], []).append(x)
small = sorted(((ch, len(RC.items_of(v)), len({y["d"] for y in v}), first[ch].isoformat()) for ch, v in by.items()
                if first[ch] >= a and (len(RC.items_of(v)) < 5 or len({y["d"] for y in v}) < 2)), key=lambda t: (-t[1], t[0]))
big = [ch for ch, v in by.items() if first[ch] >= a and len(RC.items_of(v)) >= 5 and len({y["d"] for y in v}) >= 2]
got = [(x["name"], x["items"], x["days"], x["first_watched"]) for x in sh["new"].get("small_channels") or []]
ok(got == small, f"X1: small channels {got} (recount {small})")
ok(sorted(x["name"] for x in sh["new"]["channels"]) == sorted(big), f"X1: new channels {[x['name'] for x in sh['new']['channels']]} (recount {big})")

# ---------------------------------------------------------------- 4. the same title (X2, search over 'integrals')
r, c = BY[("X2", 0)]
rows = c["result"]["sheet"]["items"]
for x in rows:
    n = sum(1 for i, it in RC.ITEM.items() if it["title"] == x["title"] and any(e["kind"] == "opened" for e in RC.EV if e["id"] == i))
    ok(x.get("same_title") == n, f"X2: {x['title']!r} same_title {x.get('same_title')} (recount {n})")

# ---------------------------------------------------------------- 5. the timeline (X3: cooking by month, all history)
r, c = BY[("X3", 0)]
sh = c["result"]["sheet"]
months = sorted({(x["d"].year, x["d"].month) for x in RC.sel(None, None, only=RC.only_fn(["cooking"]))})
ok(len(months) <= 69 and c["result"]["meta"]["rows_of"]["periods"] == 69 and len(sh["periods"]) == 52,
   f"X3: {len(sh['periods'])} periods shown of {c['result']['meta']['rows_of']['periods']} (the tip showed 47; 4064f3e 52)")
last = [p for p in sh["periods"]][-1]
oct_n = len(RC.items_of(RC.sel(D(2026, 10, 1), D(2026, 10, 31), only=RC.only_fn(["cooking"]))))
ok(last["label"] == "Oct 2026" and last["items"] == oct_n, f"X3: last period {last['label']} {last['items']} (recount {oct_n})")
ok("parts_of_day" in (sh.get("when") or {}), "X3: the parts of the day kept")

# ---------------------------------------------------------------- 6. a window past the export's end (T05, by hand)
CUT = {0: ("2026-11-01", "2026-11-22", "2026-10-01", "2026-10-30"), 1: ("2026-11-09", "2026-11-15", "2026-10-24", "2026-10-30"),
       2: ("2026-11-09", "2026-11-22", "2026-10-17", "2026-10-30"), 4: ("2026-11-01", "2026-11-10", "2026-10-21", "2026-10-30"),
       6: ("2026-10-21", "2026-10-31", "2026-10-05", "2026-10-15")}
for k, (a0, a1, c0, c1) in CUT.items():
    r, c = BY[("T05", k)]
    cut = c["result"]["meta"].get("window_cut") or {}
    ok(((cut.get("asked") or {}).get("start"), (cut.get("asked") or {}).get("end"), (cut.get("counted") or {}).get("start"),
        (cut.get("counted") or {}).get("end")) == (a0, a1, c0, c1), f"T05.{k}: asked {a0}..{a1}, counted {c0}..{c1}: {cut and (cut['asked']['said'], cut['counted']['said'])}")
    n = len(RC.items_of(RC.sel(D.fromisoformat(c0), D.fromisoformat(c1), platforms=tuple((c["args"].get("scope") or {}).get("platforms") or ()))))
    ok(c["result"]["sheet"]["totals"]["items"] == n, f"T05.{k}: counted {c['result']['sheet']['totals']['items']} (recount {n})")
lim = BY[("T05", 0)][0]["limits"]
ok(any("1 to 22 November 2026 is not in it" in x for x in lim) and any("1 to 10 November 2026 is not in it" in x for x in lim),
   f"T05: limit lines {lim}")

# ---------------------------------------------------------------- 7. lengths 'unknown' (X5 r1: saved, newest)
r, c = BY[("X5", 0)]
unk = [x for x in c["result"]["sheet"]["items"] if x["length"] == "unknown"]
yt_saved_only = [x for x in unk if x["platform"] == "youtube" and RC.ITEM[x["item_id"]]["opens"] == 0]
photos = [x for x in unk if x["platform"] == "instagram" and RC.ITEM[x["item_id"]]["length"] == "post"]
ok(len(unk) == len(yt_saved_only) + len(photos) and any("unknown" in n and "only saved" in n and "photo" in n
                                                         for n in c["result"]["meta"]["notes"]),
   f"X5.0: {len(unk)} unknown = {len(yt_saved_only)} YouTube saved-only + {len(photos)} Instagram photo posts; note said")

# ---------------------------------------------------------------- 8. the no-match's next step (X5 r2, T08 r5)
for key in (("X5", 1), ("T08", 4)):
    r, c = BY[key]
    e = c["result"]
    n = sum(1 for it in RC.ITEM.values() if "sourdough" in it["title"].lower())
    notes = " ".join(e["meta"]["notes"])
    ok(e.get("error") == "no_match" and e.get("items_with_words") == n == 2 and "call search with query 'sourdough'" in notes
       and "use one of the options" not in notes, f"{key[0]}.{key[1]}: no_match, {e.get('items_with_words')} items hold the word (recount {n}); next: search")

print("\n".join(OUT))
print("\n".join(BAD))
print(f"checks: {len(OUT) + len(BAD) - 1}, wrong: {len(BAD)}")
