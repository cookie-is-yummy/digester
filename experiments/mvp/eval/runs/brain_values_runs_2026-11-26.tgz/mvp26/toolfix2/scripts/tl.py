import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, sys.argv[1] + "/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL
h = E.Harness.scratch(base=S + "/mvp26/toolfix2/_lib_tl")
t = h.turn("huh why so much cooking all of a sudden")
env = TL.call(t, "timeline", {"unit": "month", "window": {"preset": "all"}, "scope": {"only": ["cooking"]}})
sh = env["sheet"]
print(len(sh["periods"]), env["meta"]["notes"][-1])
for k, v in sh.items():
    print(k, len(json.dumps(v, ensure_ascii=False, default=str)))
print(json.dumps(sh.get("when"))[:800])
print(json.dumps(sh["periods"][-1]))
