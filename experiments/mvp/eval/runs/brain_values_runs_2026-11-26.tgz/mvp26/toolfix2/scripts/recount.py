"""Independent recount of every result in check/results.json from the library's rows (tests/brain_library.py only;
no tools, facts, history or names module). Prints every difference, call by call."""
import json, re, sys
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp26/tools_tree/experiments")
from mvp.tests import brain_library as B   # the made-up rows only
NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships"}
FIELD = {"gaming": "Gaming", "art and design": "Art", "math": "Math", "food and cooking": "Cooking", "relationships": "Dating"}
END = {"youtube": date(2026, 10, 30), "instagram": date(2026, 10, 15)}
KIND = {"watch": "opened", "playlist": "saved", "save": "saved", "collection": "saved"}
MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
MONTHS = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october",
          "november", "december"]

def title_of(c):
    return re.sub(r"\s*#\d+$", "", c)

EV = []    # one per event
ITEM = {}
for r in B.rows():
    if r.get("friend"):
        continue
    ch = r.get("channel") or ("@" + r["handle"])
    if r["platform"] == "youtube":
        L = r["length"]
        lw = None if L is None else ("short" if L <= 60 else "long")
    else:
        lw = "reel" if (r.get("media") or "reel") == "reel" else "post"
    ITEM[r["id"]] = dict(id=r["id"], platform=r["platform"], channel=ch, theme=r["theme"], area=AREA[r["theme"]],
                         title=title_of(r["caption"]), length=lw, opens=sum(1 for k, _ in r["events"] if k == "watch"))
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=KIND[k], t=t, d=t.date(), **{x: ITEM[r["id"]][x] for x in
                   ("platform", "channel", "theme", "area", "length")}))

def sel(start=None, end=None, how="opened", platforms=(), length="any", weekday=None, only=None, private=False):
    out = []
    for e in EV:
        if e["theme"] == "da" and not private:
            continue
        if how != "any" and e["kind"] != how:
            continue
        if start and e["d"] < start: continue
        if end and e["d"] > end: continue
        if platforms and e["platform"] not in platforms: continue
        if length == "short" and e["length"] not in ("short", "reel"): continue
        if length == "long" and e["length"] != "long": continue
        if weekday is not None and e["d"].weekday() != weekday: continue
        if only and not only(e): continue
        out.append(e)
    return out

def items_of(evs):
    return {e["id"] for e in evs}

def totals(evs):
    ids = items_of(evs)
    lens = Counter(ITEM[i]["length"] for i in ids)
    plat = Counter(ITEM[i]["platform"] for i in ids)
    return {"items": len(ids), "days_active": len({e["d"] for e in evs}), "shorts": lens["short"], "long": lens["long"],
            "reels": lens["reel"], "by_platform.youtube": plat["youtube"], "by_platform.instagram": plat["instagram"]}

LEN_S = {}
for _r in B.rows():
    LEN_S[_r["id"]] = _r.get("length")

def extra_totals(evs):
    ids = items_of(evs)
    yt = [i for i in ids if ITEM[i]["platform"] == "youtube"]
    sh = sum(1 for i in yt if ITEM[i]["length"] == "short")
    longs = sorted(LEN_S[i] for i in ids if ITEM[i]["length"] == "long")
    import statistics
    med = round(statistics.median(longs) / 60) if longs else None
    return {"shorts_share": round(sh / len(yt), 4) if yt else 0.0, "long_median_min": med}

def rows_by(evs, key):
    g = defaultdict(list)
    for e in evs:
        g[e[key]].append(e)
    return g

def first_watched(channel=None, theme=None, how="opened"):
    ds = [e["d"] for e in EV if e["kind"] == how and (channel is None or e["channel"] == channel)
          and (theme is None or e["theme"] == theme)]
    return min(ds).isoformat() if ds else None

def parse_said(s):
    """'1 July to 20 October 2026' / '12 to 15 October 2026' / '5 January 2021 to 30 October 2026' -> (start, end)."""
    m = re.search(r"(\d{1,2})(?: (\w+))?(?: (\d{4}))? to (\d{1,2}) (\w+) (\d{4})", s)
    if not m:
        return None
    d1, m1, y1, d2, m2, y2 = m.groups()
    e = date(int(y2), MONTHS.index(m2.lower()) + 1, int(d2))
    s_ = date(int(y1 or y2), MONTHS.index((m1 or m2).lower()) + 1, int(d1))
    return s_, e

def yearspan(y):
    return date(y, 1, 1), date(y, 12, 31)

DIFFS = []
def cmp(key, path, got, want, tol=0.00011):
    if want is None and got is None:
        return
    ok = (abs(got - want) <= tol) if isinstance(got, (int, float)) and isinstance(want, (int, float)) and not isinstance(got, bool) else got == want
    if not ok:
        DIFFS.append((key, path, got, want))

N_CHECKED = Counter()
def check_rows(key, sh, evs, pevs, tot, ptot, prefix=""):
    for lst, k in (("themes", "theme"), ("channels", "channel"), ("areas", "area")):
        g = rows_by(evs, k); pg = rows_by(pevs, k) if pevs is not None else {}
        for i, row in enumerate(sh.get(lst) or []):
            name = row["name"]
            if row.get("private"):
                kk = "da" if k == "theme" else "relationships"
            elif k == "theme":
                kk = next((x for x, n in THEME.items() if n == name), None)
            else:
                kk = name
            if kk is None:
                DIFFS.append((key, f"{prefix}{lst}[{i}].name", name, "no such theme")); continue
            re_ = g.get(kk, [])
            n = len(items_of(re_))
            p = f"{prefix}{lst}[{i}]"
            cmp(key, p + ".items", row.get("items"), n); N_CHECKED[key] += 1
            if "share" in row:
                cmp(key, p + ".share", row["share"], round(n / tot, 4) if tot else 0.0, 0.0002); N_CHECKED[key] += 1
            if "days" in row:
                cmp(key, p + ".days", row["days"], len({e["d"] for e in re_})); N_CHECKED[key] += 1
            if "previous_items" in row and pevs is not None:
                cmp(key, p + ".previous_items", row["previous_items"], len(items_of(pg.get(kk, [])))); N_CHECKED[key] += 1
            if "previous_share" in row and pevs is not None:
                pn = len(items_of(pg.get(kk, [])))
                cmp(key, p + ".previous_share", row["previous_share"], round(pn / ptot, 4) if ptot else 0.0, 0.0002); N_CHECKED[key] += 1
            if "change_pts" in row and pevs is not None and ptot:
                pn = len(items_of(pg.get(kk, [])))
                cmp(key, p + ".change_pts", row["change_pts"], round((n / tot - pn / ptot) * 100, 1), 0.11); N_CHECKED[key] += 1
            if "shorts_share" in row and n:
                cmp(key, p + ".shorts_share", row["shorts_share"], round(sum(1 for x in items_of(re_) if ITEM[x]["length"] == "short") / n, 4), 0.0002); N_CHECKED[key] += 1
            if k == "channel" and "first_watched" in row:
                cmp(key, p + ".first_watched", row["first_watched"], first_watched(channel=name)); N_CHECKED[key] += 1
            if k == "channel" and row.get("theme"):
                cmp(key, p + ".theme", row["theme"], THEME[ITEM[next(iter(items_of(re_)))]["theme"]] if re_ else None); N_CHECKED[key] += 1
            if k == "channel" and row.get("area"):
                cmp(key, p + ".area", row["area"], AREA[ITEM[next(iter(items_of(re_)))]["theme"]] if re_ else None); N_CHECKED[key] += 1
            if k == "theme" and row.get("field") and not row.get("private"):
                cmp(key, p + ".field", row["field"], FIELD[AREA[kk]]); N_CHECKED[key] += 1
            if "change_vs_previous" in row and pevs is not None and ptot and tot:
                pn = len(items_of(pg.get(kk, [])))
                want = round((n / tot - pn / ptot) * (100 if k == "theme" else 1), 1 if k == "theme" else 3)
                cmp(key, p + ".change_vs_previous", row["change_vs_previous"], want, 0.11 if k == "theme" else 0.0011); N_CHECKED[key] += 1
            if k == "area":
                tg = rows_by(re_, "theme")
                for j, th in enumerate(row.get("themes") or []):
                    tk = next((x for x, nn in THEME.items() if nn == th["name"]), None)
                    cmp(key, p + f".themes[{j}].share", th["share"], round(len(items_of(tg.get(tk, []))) / tot, 4) if tot else 0.0, 0.0002); N_CHECKED[key] += 1
            if k == "theme" and row.get("area") and not row.get("private"):
                cmp(key, p + ".area", row["area"], AREA[kk]); N_CHECKED[key] += 1
            if k == "theme":
                chg = rows_by(re_, "channel")
                for j, c in enumerate(row.get("channels") or []):
                    cmp(key, p + f".channels[{j}].items", c["items"], len(items_of(chg.get(c["name"], [])))); N_CHECKED[key] += 1
            if k == "channel" and "new_in_window" in row and evs:
                start = min(e["d"] for e in evs)
                fw = first_watched(channel=name)
                # new_in_window: first opened inside the window
                cmp(key, p + ".new_in_window", row["new_in_window"], fw is not None and fw >= WSTART[key].isoformat())
                N_CHECKED[key] += 1
    for i, row in enumerate(sh.get("fields") or []):
        g = rows_by(evs, "area")
        n = sum(len(items_of(v)) for a, v in g.items() if FIELD[a] == row["name"])
        cmp(key, f"{prefix}fields[{i}].items", row["items"], n); N_CHECKED[key] += 1
        cmp(key, f"{prefix}fields[{i}].share", row["share"], round(n / tot, 4) if tot else 0.0, 0.0002); N_CHECKED[key] += 1

WSTART = {}
def check_when(key, sh, evs):
    w = sh.get("when")
    if not w or not evs:
        return
    n = len(evs)
    hc = Counter(e["t"].hour for e in evs)
    for i, b in enumerate(w.get("busiest_hours") or []):
        cmp(key, f"when.busiest_hours[{i}].share", b["share"], round(hc[b["hour"]] / n, 4), 0.0002); N_CHECKED[key] += 1
    top = sorted(hc.values(), reverse=True)
    for i, b in enumerate(w.get("busiest_hours") or []):
        if i < len(top):
            cmp(key, f"when.busiest_hours[{i}].rank_share", hc[b["hour"]], top[i])
    wd = sum(1 for e in evs if e["d"].weekday() < 5)
    cmp(key, "when.weekday_share", w.get("weekday_share"), round(wd / n, 4), 0.0002); N_CHECKED[key] += 1
    cmp(key, "when.events", w.get("events"), n); N_CHECKED[key] += 1
    if "weekend_share" in w:
        cmp(key, "when.weekend_share", w["weekend_share"], round(1 - wd / n, 4), 0.0002); N_CHECKED[key] += 1
    dc = Counter(e["d"].strftime("%A") for e in evs)
    best = max(dc.values())
    if w.get("busiest_weekday") and dc[w["busiest_weekday"]] != best:
        DIFFS.append((key, "when.busiest_weekday", w["busiest_weekday"], [d for d, c in dc.items() if c == best]))
    N_CHECKED[key] += 1
    if w.get("busiest_weekday") and sum(1 for c in dc.values() if c == best) > 1:
        DIFFS.append((key, "when.busiest_weekday(TIE, said as one)", w["busiest_weekday"], {d: c for d, c in dc.items() if c == best}))
    def part(h):
        return "morning" if 5 <= h < 12 else "afternoon" if 12 <= h < 17 else "evening" if 17 <= h < 21 else "night"
    pc = Counter(part(e["t"].hour) for e in evs)
    for i, pp in enumerate(w.get("parts_of_day") or []):
        cmp(key, f"when.parts_of_day[{i}].events", pp["events"], pc[pp["part"]]); N_CHECKED[key] += 1
        cmp(key, f"when.parts_of_day[{i}].share", pp["share"], round(pc[pp["part"]] / n, 4), 0.0002); N_CHECKED[key] += 1

def fmt_when(t):
    h = t.hour % 12 or 12
    return f"{t.date().isoformat()} {h}:{t.minute:02d} {'am' if t.hour < 12 else 'pm'}"

def check_items(key, sh, evs, how):
    for i, row in enumerate(sh.get("items") or []):
        it = ITEM.get(row["item_id"])
        p = f"items[{i}]"
        if it is None:
            DIFFS.append((key, p, row["item_id"], "not a visible item")); continue
        cmp(key, p + ".platform", row.get("platform"), it["platform"]); N_CHECKED[key] += 1
        cmp(key, p + ".title", row["title"], it["title"]); cmp(key, p + ".channel", row["channel"], it["channel"])
        N_CHECKED[key] += 2
        if "times_opened" in row:
            cmp(key, p + ".times_opened", row["times_opened"], it["opens"]); N_CHECKED[key] += 1
        if row.get("length"):
            want = {"short": "short", "long": "long", "reel": "short", "post": None, None: None}[it["length"]]
            cmp(key, p + ".length", row["length"], want); N_CHECKED[key] += 1
        mine = [e for e in evs if e["id"] == row["item_id"]]
        if not mine:
            mine = [e for e in EV if e["id"] == row["item_id"]]
            DIFFS.append((key, p + " (not in the window/scope)", row["item_id"], [fmt_when(e["t"]) for e in mine]))
            continue
        whens = {fmt_when(e["t"]) for e in mine}
        if row.get("when") not in whens:
            DIFFS.append((key, p + ".when", row.get("when"), sorted(whens)))
        day = row["when"].split()[0] if row.get("when") else None
        kinds = sorted({e["kind"] for e in EV if e["id"] == row["item_id"] and e["d"].isoformat() == day})
        want_how = " and ".join(kinds) if kinds else None
        cmp(key, p + ".how", row.get("how"), want_how); N_CHECKED[key] += 2

def only_fn(names):
    fs = []
    for n in names:
        n2 = n.lower()
        if n2 in ("cooking", "food and cooking"):
            fs.append(lambda e: e["area"] == "food and cooking")
        elif n2 == "dating":
            fs.append(lambda e: e["theme"] == "da")
        elif n2 == "watercolor":
            fs.append(lambda e: e["theme"] == "wc")
        elif n2 in ("wet paper",):
            fs.append(lambda e: e["channel"] == "Wet Paper")
        elif n2 == "sourdough":
            fs.append(lambda e: e["id"] in ("rx_sour1", "rx_sour2"))
        elif n2 == "pan theory":
            fs.append(lambda e: e["channel"] == "Pan Theory")
        elif n2 == "brick realm":
            fs.append(lambda e: e["channel"] == "Brick Realm")
        else:
            raise SystemExit("no only for " + n)
    return (lambda e: any(f(e) for f in fs)) if fs else None

def main():
    R = json.load(open(sys.argv[1]))
    ncalls = 0
    for r in R:
        for k, c in enumerate(r["calls"]):
            key = f"{r['tid']}:{k}"
            env = c["result"]
            if env.get("is_error") or "sheet" not in env:
                continue
            ncalls += 1
            a = c["args"]; sh = env["sheet"]; m = env["meta"]
            scope = a.get("scope") or {}
            how = scope.get("how", "opened") if c["name"] != "search" else a.get("how", "saved")
            subj = a.get("subject")
            onames = list(scope.get("only") or []) + ([subj] if subj else [])
            priv = "dating" in [x.lower() for x in onames] or (r["unlock"] == "relationships" and r["carried_unlock"] is None)
            only = only_fn(onames) if onames else None
            if c["name"] == "find":
                continue
            if c["name"] == "search":
                evs = sel(how=how, private=priv)
                check_items(key, sh, evs, how); continue
            wd = m.get("window_dates") or {}
            if wd:
                ws, we = date.fromisoformat(wd["start"]), date.fromisoformat(wd["end"])
            else:
                ws, we = date.fromisoformat(sh["window"]["start"]), date.fromisoformat(sh["window"]["end"])
            WSTART[key] = ws
            kw = dict(how=how, platforms=tuple(scope.get("platforms") or ()), length=scope.get("length", "any"),
                      weekday=scope.get("weekday"), only=only, private=priv)
            evs = sel(ws, we, **kw)
            tot = len(items_of(evs))
            # the window before
            pevs, ptot = None, None
            prev = sh.get("previous")
            if prev:
                if c["name"] == "compare":
                    b = m["window_dates_b"]; ps, pe = date.fromisoformat(b["start"]), date.fromisoformat(b["end"])
                else:
                    got = parse_said(prev.get("words") or "")
                    if got:
                        ps, pe = got
                    elif re.fullmatch(r"\d{4}", prev.get("words") or ""):
                        ps, pe = yearspan(int(prev["words"]))
                    else:
                        mm = re.fullmatch(r"(\w+) (\d{4})", prev.get("words") or "")
                        if mm and mm.group(1).lower() in MONTHS:
                            mo = MONTHS.index(mm.group(1).lower()) + 1; y = int(mm.group(2))
                            ps = date(y, mo, 1); pe = (date(y + (mo == 12), mo % 12 + 1, 1) - timedelta(days=1))
                        else:
                            DIFFS.append((key, "previous.words (unparsed)", prev.get("words"), "?")); ps = pe = None
                if ps:
                    pevs = sel(ps, pe, **kw); ptot = len(items_of(pevs))
                    for f, v in totals(pevs).items():
                        g = prev
                        for part in f.split("."):
                            g = g.get(part) if isinstance(g, dict) else None
                        if g is not None:
                            cmp(key, "previous." + f, g, v); N_CHECKED[key] += 1
                    # the previous window's length against this one's
                    if c["name"] != "compare" and (pe - ps).days != (we - ws).days:
                        DIFFS.append((key, "previous window length", f"{ps}..{pe} ({(pe-ps).days+1} d)", f"this window {ws}..{we} ({(we-ws).days+1} d)"))
            T = sh.get("totals") or {}
            for f, v in totals(evs).items():
                g = T
                for part in f.split("."):
                    g = g.get(part) if isinstance(g, dict) else None
                if g is not None:
                    cmp(key, "totals." + f, g, v); N_CHECKED[key] += 1
            for f_, v_ in extra_totals(evs).items():
                if f_ in T and T[f_] is not None:
                    cmp(key, "totals." + f_, T[f_], v_, 0.0002); N_CHECKED[key] += 1
            if prev and pevs is not None:
                for f_, v_ in extra_totals(pevs).items():
                    if f_ in prev and prev[f_] is not None:
                        cmp(key, "previous." + f_, prev[f_], v_, 0.0002); N_CHECKED[key] += 1
            check_rows(key, sh, evs, pevs, tot, ptot)
            check_when(key, sh, evs)
            if c["name"] in ("items", "first_last"):
                check_items(key, sh, evs, how)
            for i, pr in enumerate(sh.get("periods") or []):
                lab = pr["label"]
                if re.fullmatch(r"\d{4}", lab):
                    s_, e_ = yearspan(int(lab))
                else:
                    mo = MON.index(lab[:3]) + 1; y = int(lab[-4:])
                    s_ = date(y, mo, 1); e_ = date(y + (mo == 12), mo % 12 + 1, 1) - timedelta(days=1)
                n = len(items_of([e for e in evs if s_ <= e["d"] <= e_]))
                cmp(key, f"periods[{i}].items({lab})", pr["items"], n); N_CHECKED[key] += 1
                pe_ = [e for e in evs if s_ <= e["d"] <= e_]
                for lst_, kk_ in (("themes", "theme"), ("areas", "area")):
                    g_ = rows_by(pe_, kk_)
                    for j, row_ in enumerate(pr.get(lst_) or []):
                        nm_ = next((x for x, nn in THEME.items() if nn == row_["name"]), None) if kk_ == "theme" else row_["name"]
                        cmp(key, f"periods[{i}].{lst_}[{j}].share({row_['name']})", row_["share"], round(len(items_of(g_.get(nm_, []))) / n, 4) if n else 0.0, 0.0002); N_CHECKED[key] += 1
            for lst in ("new", "stopped"):
                for kind_ in ("themes", "channels"):
                    for i, row in enumerate((sh.get(lst) or {}).get(kind_) or []):
                        kk = "theme" if kind_ == "themes" else "channel"
                        nm = next((x for x, n in THEME.items() if n == row["name"]), None) if kk == "theme" else row["name"]
                        n = len(items_of([e for e in evs if e[kk] == nm]))
                        cmp(key, f"{lst}.{kind_}[{i}].items({row['name']})", row.get("items"), n); N_CHECKED[key] += 1
                        if "previous_items" in row and pevs is not None:
                            cmp(key, f"{lst}.{kind_}[{i}].previous_items", row["previous_items"], len(items_of([e for e in pevs if e[kk] == nm]))); N_CHECKED[key] += 1
                        if "first_watched" in row:
                            fw = first_watched(theme=nm) if kk == "theme" else first_watched(channel=nm)
                            cmp(key, f"{lst}.{kind_}[{i}].first_watched", row["first_watched"], fw); N_CHECKED[key] += 1
                        if lst == "new" and kk == "theme" and "first_watched" not in row:
                            fw = first_watched(theme=nm)
                            if fw and fw < ws.isoformat():
                                DIFFS.append((key, f"MISLEAD new.themes[{i}] {row['name']} (no first_watched on the row)", "new", f"first opened {fw}, before the window {ws}"))
            for i, row in enumerate((sh.get("library") or {}).get("saved_not_opened") or []):
                nm = next((x for x, n in THEME.items() if n == row.get("theme")), None)
                sv = {e["id"] for e in EV if e["kind"] == "saved" and e["theme"] == nm}
                op = {e["id"] for e in EV if e["kind"] == "opened"}
                cmp(key, f"library.saved_not_opened[{i}].n({row.get('theme')})", row["n"], len(sv - op)); N_CHECKED[key] += 1
                cmp(key, f"library.saved_not_opened[{i}].youtube", row["youtube"], sum(1 for x in sv - op if ITEM[x]["platform"] == "youtube")); N_CHECKED[key] += 1
    print("calls recounted:", ncalls, " fields checked:", sum(N_CHECKED.values()))
    for d in DIFFS:
        print("DIFF", d[0], d[1], "| tool:", d[2], "| recount:", d[3])
    print("diffs:", len(DIFFS))

if __name__ == "__main__":
    main()
