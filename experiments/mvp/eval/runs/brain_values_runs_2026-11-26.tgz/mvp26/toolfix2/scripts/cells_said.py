"""Can the new cells be said through the locked checker? One true sentence per cell (and the attacker's d02, d08, d15
on the fixed results), in cells and full mode, as a lead."""
import sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp26/tools_tree/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL, verify as V
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
h = E.Harness.scratch(base=S + "/mvp26/toolfix2/_lib_said")
W = lambda w: {"words": w}
CASES = [
 ("what did I watch in October", [("breakdown", {"by": "channel", "window": W("October")})], [
   ("T", "In October 2026, your busiest weekdays were Thursday[r1.when.busiest_weekdays[0]] and Friday[r1.when.busiest_weekdays[1]], with 24[r1.when.busiest_weekday_opens] opens each."),
   ("T", "In October 2026, Thursday and Friday tied as your busiest days, with 24[r1.when.busiest_weekday_opens] opens each."),
   ("F", "In October 2026, your busiest weekday was Thursday[r1.when.busiest_weekdays[0]]."),
 ]),
 ("that video about integrals, when did i watch it", [("search", {"how": "opened", "limit": 5, "query": "video about integrals", "window": {"preset": "all"}})], [
   ("T", "You opened \"Integrals by parts\"[r1.items[0]] on 4 June 2023[r1.items[0].when], and 21[r1.items[0].same_title] of your videos share that title."),
 ]),
 ("new channels i picked up this fall", [("changes", {"against": "previous", "level": "channel", "window": W("this fall")})], [
   ("T", "This fall you also started @wetpaper.ig[r1.new.small_channels[0]], with 4[r1.new.small_channels[0].items] videos from 12 October 2026[r1.new.small_channels[0].first_watched]."),
 ]),
 ("what did I watch in late October", [("breakdown", {"by": "none", "window": W("late October")})], [
   ("T", "In late October 2026 you opened 38[r1.totals.items] videos, down from 52[r1.previous.items] in mid October."),
   ("F", "In late October 2026 you opened 38[r1.totals.items] videos, down from 52[r1.previous.items] in early October."),
 ]),
 ("late summer of 2023", [("breakdown", {"by": "theme", "window": W("late summer of 2023")})], [
   ("T", "In late summer of 2023 you opened 39[r1.totals.items] videos, down from 52[r1.previous.items] in July."),
   ("F", "In late summer of 2023 you opened 39[r1.totals.items] videos, down from 99[r1.previous.items] in the spring."),   # d02
   ("F", "In late summer of 2023 you opened 39[r1.totals.items] videos, down from 52[r1.previous.items] in the spring."),
 ]),
 ("late spring", [("breakdown", {"by": "theme", "window": W("late spring")})], [
   ("F", "In late spring you opened 5[r1.totals.items] videos, down from 13[r1.previous.items] in the winter before."),   # d15
   ("F", "In late spring you opened 5[r1.totals.items] videos, down from 5[r1.previous.items] in the winter before."),
 ]),
]
for msg, calls, sents in CASES:
    t = h.turn(msg, search=FakeEngine(), learned=fake_learned)
    for n, a in calls:
        TL.call(t, n, a)
    for truth, s in sents:
        out = []
        for mode in ("cells", "full"):
            v = V.check_answer({"lead": s, "points": []}, t.results, V.Turn.of(t), mode=mode)
            out.append(f"{mode}: {'kept' if v.lead_ok else 'dropped ' + ','.join(sorted({r for o in v.lead for r in o.reasons}))}")
        print(f"[{truth}] {s[:110]}\n      " + " | ".join(out))
