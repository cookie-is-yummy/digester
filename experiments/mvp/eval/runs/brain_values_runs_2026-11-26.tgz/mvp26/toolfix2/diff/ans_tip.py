"""mvp26 toolfix2: fallback.answer and answer.build of every saved form (look1, look2, run1, run2), both modes, through
the tip's fallback.py and answer.py (d7ba2ef, copied into toolfix2/base) and through this tree's; the same verify.py
and insight.py (this tree's, unchanged). Prints every form whose code lead or either build differs, with what moved."""
import glob, importlib.util, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import m as M  # noqa: E402
L = M.L
V = M.V
S = M.S
assert V.__file__.startswith(S + "/mvp26/tools_tree/"), V.__file__


def _load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = "mvp.brain"
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


FBb = _load(os.path.join(S, "mvp26/toolfix2/base/fallback_tip.py"), "mvp.brain.fallback_tip")
Ab = _load(os.path.join(S, "mvp26/toolfix2/base/answer_tip.py"), "mvp.brain.answer_tip")
from mvp.brain import fallback as FB, answer as A  # noqa: E402


def run2_inputs():
    h = L.harness()
    out = []
    for p in sorted(glob.glob(os.path.join(S, "mvp25/runa2/run1/N*.json"))):
        rec = json.load(open(p))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        out.append((rec, t, results))
    return out


CLS = {}


def main():
    ins = [(look, rec, t, results) for look, rec, t, results in L.look_inputs()] + \
          [("run1", rec, t, results) for rec, t, results in M.run1_inputs()] + \
          [("run2", rec, t, results) for rec, t, results in run2_inputs()]
    n = bad = 0
    lines = []
    for look, rec, t, results in ins:
        for fi, f in enumerate(rec.get("forms") or []):
            for mode in ("full", "cells"):
                vt = V.Turn.of(t)
                v = V.check_answer(f, results, vt, mode=mode)
                cb = FBb.answer(V.Ledger(results), v, vt, mode=mode)
                cr = FB.answer(V.Ledger(results), v, vt, mode=mode)
                ab = Ab.build(V.Ledger(results), verdict=None, code=cb, form=f, also=[v], mode=mode)
                ar = A.build(V.Ledger(results), verdict=None, code=cr, form=f, also=[v], mode=mode)
                mb = Ab.build(V.Ledger(results), verdict=v, form=f, also=[v], mode=mode)
                mr = A.build(V.Ledger(results), verdict=v, form=f, also=[v], mode=mode)
                n += 1
                if repr((cb, ab, mb)) != repr((cr, ar, mr)):
                    bad += 1
                    what = []
                    if cb["lead"] != cr["lead"]:
                        what.append(f"code lead: {cb['lead']!r} -> {cr['lead']!r}")
                    for tag, x, y in (("code build", ab, ar), ("model build", mb, mr)):
                        for k in sorted(set(x) | set(y)):
                            if x.get(k) != y.get(k) and k != "text":
                                xs = [c["ref"] for c in x[k]] if k == "cards" else x.get(k)
                                ys = [c["ref"] for c in y[k]] if k == "cards" else y.get(k)
                                what.append(f"{tag}.{k}: {xs!r} -> {ys!r}")
                    tag = "lead_ok" if v.lead_ok else "lead_failed"
                    lines.append(f"{look} {rec['key']} form {fi} {mode} [{tag}]:\n   " + "\n   ".join(what or ["(text only)"]))
                    for w in what:
                        k = w.split(":")[0]
                        if k.startswith("model build"):
                            k += f" [{tag}]"
                        CLS[k] = CLS.get(k, 0) + 1
    out = os.path.join(S, "mvp26/toolfix2/answers_vs_tip.txt")
    lines.insert(0, "by field: " + json.dumps(dict(sorted(CLS.items())), indent=1))
    with open(out, "w") as fh:
        fh.write(f"{n} form-modes, {bad} differ\n" + "\n".join(lines) + "\n")
    print(f"answers against the tip: {n} form-modes (forms x 2 modes), code lead + both builds compared, {bad} differ")


if __name__ == "__main__":
    main()
