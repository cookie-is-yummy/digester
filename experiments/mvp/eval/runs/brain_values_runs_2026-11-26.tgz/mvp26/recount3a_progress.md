# recount3a (mvp26) progress
- step 0: brief read; scripts copied from mvp25/recount2 to S/mvp26/recount3a. Library = merge_tree copy (sha 5845335, same as 16cd906).
- step 1: read the whole run A dump (look_dump.txt, flags added) and recounted every message from lib.py; verdicts drafted. Flag mode = the reasons cells/full mode would give (verify.py _values_flags), so a cells flag = run 2's checker would refuse.
- step 2: writing j_3a.py (checks + verdicts). Next: adapt assemble/a/tally, then compare.
- step 3: assemble/a/tally written and run: sentences.json, answers.json, numbers.txt, sent_faults.txt. Next: compare with run 2 (compare_3a.py).
- step 4: compare_3a.py written and run: compare.txt. Next: advisor check, final report.
- step 5 (advisor gaps): kept-only flag table + VALUES_REFUSE cells codes list; N019.0's cells rule found offline ('list cut to fit: say the top', a word rule); scope lines judged (30: 27 right, 1 misleading N005.0, 2 needless); hollow N042.0 date check replaced; reader floor in compare.txt. All outputs rebuilt.
- DONE: numbers.txt, sentences.json, answers.json, sent_faults.txt, compare.txt in S/mvp26/recount3a. $0, no model call. Run B not opened.
