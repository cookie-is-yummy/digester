"""mvp25 full-mode differential: every form of every set (planted, looks, skeptic, rc1, rc2, attack2 as point and lead,
run1 first and repair forms) through the base checker of f22d04f (its verify.py AND its insight.py) and the repo
checker in full mode, three ways (mode="full", MVP_BRAIN_CHECK unset, MVP_BRAIN_CHECK=full); the whole verdict
compared. --answers: fallback.answer and answer.build of every look and run1 form, base modules against the repo's."""
import importlib.util, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import m as M  # noqa: E402
L = M.L
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp26/merge/diff")
import diff_full as DF  # noqa: E402


def _load(path, name, pkg):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    mod.__package__ = pkg
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


IB = _load(os.path.join(M.S, "mvp25/cellsfix/base/insight_base.py"), "mvp.insight_base", "mvp")
VB = _load(os.path.join(M.S, "mvp25/cellsfix/base/verify_base.py"), "mvp.brain.verify_b25", "mvp.brain")
VB.I = IB
assert VB.I is IB and M.V.I is not IB and M.V.I.__file__.endswith("experiments/mvp/insight.py")


def forms():
    for x in DF.forms():
        yield x
    d = M.a2()
    for c in d["cases"]:
        led, car = d["ledgers"][c["record"]], d["carriers"][c["record"]]
        t = d["turns"][c["record"]]
        yield (f"attack2:{c['id']}:P", {"lead": car, "points": [c["text"]]}, led, None, ("a2", t))
        yield (f"attack2:{c['id']}:L", {"lead": c["text"], "points": []}, led, None, ("a2", t))
    for rec, t, results in M.run1_inputs():
        for fi, f in enumerate(rec.get("forms") or []):
            yield (f"run1:{rec['key']}:{fi}", f, results, None, t)


def turn_of(mod, c, t):
    if isinstance(t, tuple) and t[0] == "a2":
        from datetime import date
        x = t[1]
        return mod.Turn(message=x["message"], unlock=x["unlock"], screen=x["screen"],
                        today=date.fromisoformat(x["today"]) if x["today"] else None, names=list(x["names"]),
                        sensitive_names=list(x["sensitive_names"]))
    return L._pturn(mod, c) if c is not None else mod.Turn.of(t)


def main():
    n = bad = 0
    os.environ.pop("MVP_BRAIN_CHECK", None)
    for name, f, led, c, t in forms():
        b = DF.vdump(VB.check_answer(f, VB.Ledger(led), turn_of(VB, c, t)))
        for how in ("arg", "env_unset", "env_full"):
            if how == "env_full":
                os.environ["MVP_BRAIN_CHECK"] = "full"
            mode = "full" if how == "arg" else None
            r = DF.vdump(M.V.check_answer(f, M.V.Ledger(led), turn_of(M.V, c, t), mode=mode))
            os.environ.pop("MVP_BRAIN_CHECK", None)
            n += 1
            if r != b:
                bad += 1
                if bad <= 5:
                    print("DIFF", name, how)
    print(f"full-mode differential (base verify + base insight of f22d04f): {n} verdicts compared ({n // 3} forms x 3 "
          f"ways), {bad} differ")
    return bad


def answers():
    FBb = _load(os.path.join(HERE, "base", "fallback_base.py"), "mvp.brain.fallback_b25", "mvp.brain")
    FBb.V, FBb.I = VB, IB
    Ab = _load(os.path.join(HERE, "base", "answer_base.py"), "mvp.brain.answer_b25", "mvp.brain")
    Ab.V = VB
    from mvp.brain import fallback as FB, answer as A
    n = bad = 0
    ins = [(look, rec, t, results) for look, rec, t, results in L.look_inputs()] + \
          [("run1", rec, t, results) for rec, t, results in M.run1_inputs()]
    for look, rec, t, results in ins:
        for fi, f in enumerate(rec.get("forms") or []):
            vb = VB.check_answer(f, results, VB.Turn.of(t))
            vr = M.V.check_answer(f, results, M.V.Turn.of(t), mode="full")
            cb = FBb.answer(VB.Ledger(results), vb, VB.Turn.of(t))
            cr = FB.answer(M.V.Ledger(results), vr, M.V.Turn.of(t), mode="full")
            ab = Ab.build(VB.Ledger(results), verdict=None, code=cb, form=f, also=[vb])
            ar = A.build(M.V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode="full")
            mb = Ab.build(VB.Ledger(results), verdict=vb, form=f, also=[vb])
            mr = A.build(M.V.Ledger(results), verdict=vr, form=f, also=[vr], mode="full")
            n += 1
            if repr((cb, ab, mb)) != repr((cr, ar, mr)):
                bad += 1
                print("ANSWER DIFF", look, rec["key"], fi)
    print(f"full-mode answers (base verify, insight, fallback, answer of f22d04f): {n} forms, code lead + both builds "
          f"compared, {bad} differ")
    return bad


if __name__ == "__main__":
    sys.exit(1 if (answers() if "--answers" in sys.argv else main()) else 0)
