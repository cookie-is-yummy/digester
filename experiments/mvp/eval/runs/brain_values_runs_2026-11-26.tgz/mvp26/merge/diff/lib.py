"""mvp24 pin: one harness for every set, run through the REPO checker (pin_tree) in any CheckMode, or through the base
checker of f22d04f (base/verify_base.py) for the full-mode differential. Made-up library only; no model call.

Sets (each row: set, id, truth F/T, where, kept, reasons, private_line, text):
  planted   eval/brain_planted.json: builder (new, audit, insight_v5), attack, attack_true, audit_true
  looks     the held-out first forms and repair forms (mvp20/tune/heldout = look1, mvp20/fix/heldout_run = look2),
            truth from mvp22/raw/sentences.json
  skeptic   mvp22/skeptic/cases.py (48 F, 20 T) on scenarios rebuilt with the repo's tools
  rc1, rc2  mvp23/record_check cases.py as frozen (v1: P under the record's first-form lead) and cases_v2.py (lone lead)
"""
import glob
import importlib.util
import json
import os
import sys
from datetime import date

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
PIN = os.path.join(S, "mvp26", "merge_tree", "experiments")
DATA = os.path.join(S, "mvp24/pin/data")
sys.path.insert(0, PIN)
sys.path.insert(0, DATA)
import mvp.brain  # noqa: E402,F401
from mvp.brain import verify as V  # noqa: E402
from mvp.brain import planted as P  # noqa: E402
from mvp.brain import tools as TL  # noqa: E402
assert V.__file__.startswith(PIN), V.__file__


def _load(path, name):
    spec = importlib.util.spec_from_file_location("mvp.brain." + name, path)
    m = importlib.util.module_from_spec(spec)
    m.__package__ = "mvp.brain"
    sys.modules["mvp.brain." + name] = m
    spec.loader.exec_module(m)
    return m


VB = _load(os.path.join(S, "mvp24/pin/base/verify_base.py"), "verify_base")
LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
LAB = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r
       for r in json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))}
_H = None


def harness():
    global _H
    if _H is None:
        base = os.path.join(HERE, "_lib")
        os.makedirs(base, exist_ok=True)
        from mvp import eval_brain as E
        _H = E.Harness.scratch(base=base)
    return _H


def check(mod, form, ledger, turn, mode):
    """A verdict from the repo checker (mode) or the base checker (mode None)."""
    if mod is VB:
        return VB.check_answer(form, ledger, turn)
    return V.check_answer(form, ledger, turn, mode=mode)


# ------------------------------------------------------------------ planted
PLANTED = None


def planted_data():
    global PLANTED
    if PLANTED is None:
        PLANTED = P.load()
    return PLANTED


def _pturn(mod, case):
    t = case.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    return mod.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today, names=list(t.get("names") or []),
                    sensitive_names=list(t.get("sensitive_names") or []))


def _ptarget(v, case):
    tgt = case.get("target") or "point:0"
    kind, _, n = tgt.partition(":")
    if kind == "lead":
        os_ = [o for o in v.outcomes if o.where == "lead"]
        if n:
            o = next((o for o in os_ if o.index == int(n)), None)
            return bool(o and o.kept), list(o.reasons) if o else ["missing"]
        return bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
    if kind == "point":
        o = next((o for o in v.outcomes if o.where == "point" and o.index == int(n or 0)), None)
        return bool(o and o.kept), list(o.reasons) if o else ["missing"]
    if kind == "outside":
        e = v.outside[int(n or 0)] if len(v.outside) > int(n or 0) else None
        return bool(e and e["kept"]), list(e["reasons"]) if e else ["missing"]
    if kind == "item":
        e = v.items[int(n or 0)] if len(v.items) > int(n or 0) else None
        return bool(e and e["kept"] and not e["reasons"]), list(e["reasons"]) if e else ["missing"]
    raise ValueError(tgt)


def run_planted(mod, mode, keep_verdicts=False):
    data = planted_data()
    rows = []
    for c in data["cases"]:
        best = None
        forms = c.get("forms") or [c["form"]]
        for f in forms:
            v = check(mod, f, mod.Ledger(data["ledgers"][c["ledger"]]), _pturn(mod, c), mode)
            kept, reasons = _ptarget(v, c)
            r = (kept, reasons, v.private_line, v)
            if best is None or (r[0] and not best[0]):
                best = r
        src = c.get("source") or "new"
        truth = "T" if c["expect"] == "kept" else "F"
        row = {"set": "planted", "src": src, "id": c["id"], "truth": truth, "expect": c["expect"],
               "class": c.get("class"), "kept": best[0], "reasons": best[1], "private_line": best[2],
               "text": (c.get("form") or forms[0]).get("lead") if (c.get("target") or "").startswith("lead") else
               None}
        if keep_verdicts:
            row["verdict"] = best[3]
        rows.append(row)
    return rows


# ------------------------------------------------------------------ looks
_INPUTS = None


def look_inputs():
    global _INPUTS
    if _INPUTS is None:
        h = harness()
        out = []
        for look, d in LOOKS.items():
            for p in sorted(glob.glob(os.path.join(d, "*.json"))):
                if p.endswith("summary.json"):
                    continue
                rec = json.load(open(p))
                t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False,
                                                             sort_keys=True))
                results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                           and not c["result"].get("is_error")}
                out.append((look, rec, t, results))
        _INPUTS = out
    return _INPUTS


def run_looks(mod, mode, keep_verdicts=False):
    rows = []
    for look, rec, t, results in look_inputs():
        vt = mod.Turn.of(t)
        for fi, form in enumerate(rec.get("forms") or []):
            v = check(mod, form, results, vt, mode)
            for o in v.outcomes:
                lab = LAB.get((look, rec["key"], fi, o.where, o.index))
                tr = None if lab is None else {"true": "T", "wrongly_based": "F", "false": "F"}.get(lab["truth"],
                                                                                                 lab["truth"])
                rows.append({"set": look, "id": f"{rec['key']}.f{fi}.{o.where}{o.index}", "key": rec["key"],
                             "form_index": fi, "where": o.where, "index": o.index, "truth": tr, "kept": o.kept,
                             "reasons": list(o.reasons), "details": list(o.details), "sent": o.sent,
                             "private_line": v.private_line, "lead_ok": v.lead_ok, "repair": v.repair,
                             "text": o.text})
            if keep_verdicts:
                rows[-1]["verdict"] = v
    return rows


# ------------------------------------------------------------------ the skeptic's set
_SK = None


def skeptic_inputs():
    global _SK
    if _SK is None:
        import skeptic_cases as K
        import skeptic_scen as SC
        h = harness()
        built, out = {}, []
        for c in K.CASES + K.TRUE:
            cid, sk, where, truth, cls, sent = c[:6]
            if sk not in built:
                msg, calls, last = SC.SCEN[sk]
                lw = None
                if last:
                    t0 = h.turn("what have i been into lately")
                    TL.call(t0, "breakdown", {"by": "area", "window": SC.win(preset="lately"), "scope": SC.sc(),
                                              "compare": "none"})
                    lw = t0.windows.get("r1")
                t = h.turn(msg, last_window=lw) if lw is not None else h.turn(msg)
                for tool, args in calls:
                    TL.call(t, tool, args)
                built[sk] = t
            t = built[sk]
            form = {"lead": sent} if where == "L" else {"lead": K.CARRIER[sk], "points": [sent]}
            tgt = ("lead", 0) if where == "L" else ("point", 0)
            out.append((c, form, tgt, t))
        _SK = out
    return _SK


def run_skeptic(mod, mode):
    rows = []
    for c, form, tgt, t in skeptic_inputs():
        v = check(mod, form, t.results, mod.Turn.of(t), mode)
        if tgt[0] == "lead":
            os_ = [o for o in v.outcomes if o.where == "lead"]
            kept, reasons = bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
        else:
            o = next((o for o in v.outcomes if (o.where, o.index) == tgt), None)
            kept, reasons = bool(o and o.kept), (list(o.reasons) if o else ["missing"])
        rows.append({"set": "skeptic", "id": c[0], "truth": c[3], "class": c[4], "where": c[2], "kept": kept,
                     "reasons": reasons, "private_line": v.private_line, "text": c[5], "why": c[6]})
    return rows


# ------------------------------------------------------------------ the record checker's set
DUP = {"N04", "N08", "N22", "T06", "T11", "T12", "T13"}   # record_check dedupe.py: >= 0.93 to an older text


def run_rc(mod, mode, version=2):
    import rc_cases as C1
    import rc_cases_v2 as C2
    cases = C2.CASES if version == 2 else C1.CASES
    inp = {(look, rec["key"]): (rec, t, results) for look, rec, t, results in look_inputs()}
    rows = []
    for cid, look, key, where, truth, cls, text, recount, _rec in cases:
        rec, t, results = inp[(look, key)]
        form = {"lead": text} if where == "L" else {"lead": rec["forms"][0].get("lead") or "", "points": [text]}
        v = check(mod, form, results, mod.Turn.of(t), mode)
        if where == "L":
            os_ = [o for o in v.outcomes if o.where == "lead"]
            kept, reasons = bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
        else:
            o = next((o for o in v.outcomes if (o.where, o.index) == ("point", 0)), None)
            kept, reasons = bool(o and o.kept), (list(o.reasons) if o else ["missing"])
        rows.append({"set": f"rc{version}", "id": cid, "truth": truth, "class": cls, "where": where, "kept": kept,
                     "reasons": reasons, "private_line": v.private_line, "text": text, "why": recount,
                     "dup": cid in DUP})
    return rows


def run_all(mod, mode):
    return run_planted(mod, mode) + run_looks(mod, mode) + run_skeptic(mod, mode) + run_rc(mod, mode, 1) + \
        run_rc(mod, mode, 2)
