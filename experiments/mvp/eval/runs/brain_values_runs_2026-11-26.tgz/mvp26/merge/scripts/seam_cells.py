"""Seam of the merge: the new cells of toolfix2 through all three checker modes (cells, full, values), as a lead, on
the tree in argv[1]; true sentences, wrong-value twins, and unmarked made-up numbers that only a new cell or note
holds. Made-up library only; no model call. Prints one line per sentence."""
import os, sys
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"; sys.dont_write_bytecode = True
TREE = sys.argv[1]
sys.path.insert(0, TREE + "/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL, verify as V
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
assert V.__file__.startswith(TREE)
h = E.Harness.scratch(base=sys.argv[2])
W = lambda w: {"words": w}
CASES = [
 ("what did I watch in October", [("breakdown", {"by": "channel", "window": W("October")})], [
   ("T", "In October 2026, your busiest weekdays were Thursday[r1.when.busiest_weekdays[0]] and Friday[r1.when.busiest_weekdays[1]], with 24[r1.when.busiest_weekday_opens] opens each."),
   ("T", "In October 2026, Thursday and Friday tied as your busiest days, with 24[r1.when.busiest_weekday_opens] opens each."),
   ("F", "In October 2026, Thursday and Friday tied as your busiest days, with 25[r1.when.busiest_weekday_opens] opens each."),
   ("F", "In October 2026, Thursday[r1.when.busiest_weekdays[0]] was your busiest day, with 31 opens."),
   ("F", "In October 2026, your busiest weekday was Thursday[r1.when.busiest_weekdays[0]]."),
 ]),
 ("that video about integrals, when did i watch it", [("search", {"how": "opened", "limit": 5, "query": "video about integrals", "window": {"preset": "all"}})], [
   ("T", "You opened \"Integrals by parts\"[r1.items[0]] on 4 June 2023[r1.items[0].when], and 21[r1.items[0].same_title] of your videos share that title."),
   ("F", "You opened \"Integrals by parts\"[r1.items[0]] on 4 June 2023[r1.items[0].when], and 22[r1.items[0].same_title] of your videos share that title."),
   ("F", "You opened \"Integrals by parts\"[r1.items[0]] on 4 June 2023[r1.items[0].when], and 23 of your videos share that title."),
 ]),
 ("new channels i picked up this fall", [("changes", {"against": "previous", "level": "channel", "window": W("this fall")})], [
   ("T", "This fall you also started @wetpaper.ig[r1.new.small_channels[0]], with 4[r1.new.small_channels[0].items] videos from 12 October 2026[r1.new.small_channels[0].first_watched]."),
   ("F", "This fall you also started @wetpaper.ig[r1.new.small_channels[0]], with 5[r1.new.small_channels[0].items] videos from 12 October 2026[r1.new.small_channels[0].first_watched]."),
   ("F", "This fall you also started @wetpaper.ig[r1.new.small_channels[0]], with 4[r1.new.small_channels[0].items] videos from 14 October 2026[r1.new.small_channels[0].first_watched]."),
   ("T", "This fall so far has 60 days, against 92 in the summer before."),
   ("F", "This fall you opened 92 videos from new channels."),
   ("F", "This fall you started 60 new channels."),
   ("F", "Watercolor painting fell to 13 videos this fall."),
 ]),
 ("what did I watch in mid October", [("breakdown", {"by": "theme", "window": W("mid October")})], [
   ("T", "In mid October 2026 you opened 52[r1.totals.items] videos, against the 10 days before, 1 to 10 October 2026."),
   ("F", "In mid October 2026 you opened 52[r1.totals.items] videos, against the 9 days before, 2 to 10 October 2026."),
 ]),
 ("late August", [("breakdown", {"by": "theme", "window": W("late August")})], [
   ("T", "Late August 2026 has 11 days, from 21 to 31 August, and the part before it has 10."),
   ("F", "Late August 2026 has 12 days, from 20 to 31 August."),
 ]),
 ("late October on instagram", [("breakdown", {"by": "channel", "window": W("late October"), "scope": {"platforms": ["instagram"]}})], [
   ("T", "Your Instagram export ends on 15 October 2026, so this counts 5 to 15 October 2026."),
   ("F", "Your Instagram export ends on 16 October 2026, so this counts 6 to 16 October 2026."),
 ]),
]
for msg, calls, sents in CASES:
    t = h.turn(msg, search=FakeEngine(), learned=fake_learned)
    for n, a in calls:
        TL.call(t, n, a)
    for truth, s in sents:
        out = []
        for mode in ("cells", "full", "values"):
            v = V.check_answer({"lead": s, "points": []}, t.results, V.Turn.of(t), mode=mode)
            out.append(f"{mode}: {'kept' if v.lead_ok else 'out ' + ','.join(sorted({r for o in v.lead for r in o.reasons}))}")
        print(f"[{truth}] {s}\n      " + " | ".join(out))
