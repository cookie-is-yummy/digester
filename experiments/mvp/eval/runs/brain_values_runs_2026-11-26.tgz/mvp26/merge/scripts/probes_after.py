"""The attacker's 79 probes (probes.TURNS) plus the calls of this round's defects that the probes lack, on the tree in
argv[1]; every result saved to argv[2]. Imports the tools (it makes the results); the recount does not."""
import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = sys.argv[1]
sys.path.insert(0, TREE + "/experiments")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import probes as PR
from mvp import eval_brain as E
from mvp.brain import tools as TL
assert TL.__file__.startswith(TREE)
W = lambda w: {"words": w}
P = lambda p: {"preset": p}
EXTRA = [
 ("X1", "new channels i picked up this fall", None, [
   ("changes", {"against": "previous", "level": "channel", "window": W("this fall")})]),
 ("X2", "that video about integrals, when did i watch it", None, [
   ("search", {"how": "opened", "limit": 5, "query": "video about integrals", "window": P("all")})]),
 ("X3", "huh why so much cooking all of a sudden", None, [
   ("timeline", {"unit": "month", "window": P("all"), "scope": {"only": ["cooking"]}})]),
 ("X4", "late August, the first half of October, early October, late 2026, the first half of 2024", None, [
   ("breakdown", {"by": "theme", "window": W("late August")}),
   ("breakdown", {"by": "channel", "window": W("the first half of October")}),
   ("breakdown", {"by": "theme", "window": W("early October")}),
   ("breakdown", {"by": "theme", "window": W("late 2026")}),
   ("breakdown", {"by": "area", "window": W("the first half of 2024")})]),
 ("X5", "what did i save, and when did i last save the sourdough one", None, [
   ("items", {"window": P("all"), "scope": {"how": "saved"}, "order": "newest", "limit": 8}),
   ("first_last", {"subject": "sourdough", "which": "last", "scope": {"how": "any"}})]),
]
PR.TURNS = PR.TURNS + EXTRA
h = E.Harness.scratch(base=S + "/mvp26/merge/_lib_probe")
out, done = PR.run(h)
json.dump(out, open(sys.argv[2], "w"), indent=1, ensure_ascii=False)
print("calls", sum(len(r["calls"]) for r in out), "errors", sum(1 for r in out for c in r["calls"] if c["result"].get("is_error")))
