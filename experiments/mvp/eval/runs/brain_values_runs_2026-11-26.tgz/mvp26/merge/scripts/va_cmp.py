import json, sys
from collections import Counter
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
C = Counter(); ex = {}
for k in a:
    x, y = a[k], b[k]
    for f in ("lead_ok", "repair", "outcomes", "verdict_json"):
        if x[f] != y[f]:
            C["verdict." + f] += 1; ex.setdefault("verdict." + f, k)
    for f in ("code", "code_build", "model_build"):
        X, Y = x[f], y[f]
        if X == Y: continue
        if isinstance(X, dict) and isinstance(Y, dict):
            for kk in sorted(set(X) | set(Y)):
                if X.get(kk) != Y.get(kk):
                    C[f + "." + kk] += 1; ex.setdefault(f + "." + kk, k)
        else:
            C[f] += 1; ex.setdefault(f, k)
    if x != y: C["forms differing"] += 1
for k, n in sorted(C.items()): print(f"{n:4d} {k:30s} e.g. {ex.get(k, '')}")
