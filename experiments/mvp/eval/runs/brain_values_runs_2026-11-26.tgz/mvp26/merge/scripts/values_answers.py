"""Seam: values mode through the loop's answer path (verdict, code lead, both builds) on every saved form of the four
live runs, on the tree in VALUES_TREE; dumped to argv[1] for a comparison between the values tree and the merge.
Made-up library only; no model call."""
import json, os, sys
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp26/values")
import lib26 as L
V = L.V
from mvp.brain import fallback as FB, answer as A, loop as LP
out = {}
for run in ("look1", "look2", "run1", "run2"):
    for rec, t, results in L.inputs(run):
        for fi, f in enumerate(rec.get("forms") or []):
            v = V.check_answer(f, results, V.Turn.of(t), mode="values")
            c = FB.answer(V.Ledger(results), v, V.Turn.of(t), mode="values")
            cb = A.build(V.Ledger(results), verdict=None, code=c, form=f, also=[v], mode="values")
            mb = A.build(V.Ledger(results), verdict=v, form=f, also=[v], mode="values")
            out[f"{run}:{rec['key']}:{fi}"] = {
                "lead_ok": v.lead_ok, "repair": v.repair,
                "outcomes": [[o.where, o.index, o.kept, list(o.reasons), [str(x) for x in (o.flags or [])]] for o in v.outcomes],
                "code": json.loads(json.dumps(c, default=str)), "code_build": json.loads(json.dumps(cb, default=str)),
                "model_build": json.loads(json.dumps(mb, default=str)), "verdict_json": json.loads(json.dumps(LP.verdict_json(v), default=str))}
json.dump(out, open(sys.argv[1], "w"), indent=1, ensure_ascii=False, sort_keys=True)
print(len(out), "forms")
