"""Kinds of difference between the tip's tool results (toolfix2/results_before.json, made on d7ba2ef) and the merge's
(merge/results_merge.json), by generalised path. Made-up library only."""
import json, re, sys
from collections import Counter
a = json.load(open(sys.argv[1])); b = json.load(open(sys.argv[2]))
C = Counter(); EX = {}
def gen(p): return re.sub(r"\[\d+\]", "[]", p)
def walk(x, y, p):
    if isinstance(x, dict) and isinstance(y, dict):
        for k in sorted(set(x) | set(y)):
            q = f"{p}.{k}"
            if k not in x: C[("added", gen(q))] += 1; EX.setdefault(("added", gen(q)), q)
            elif k not in y: C[("removed", gen(q))] += 1; EX.setdefault(("removed", gen(q)), q)
            else: walk(x[k], y[k], q)
    elif isinstance(x, list) and isinstance(y, list):
        if len(x) != len(y):
            C[(f"list_len {'longer' if len(y) > len(x) else 'shorter'}", gen(p))] += 1
        for i in range(min(len(x), len(y))): walk(x[i], y[i], f"{p}[{i}]")
    elif x != y:
        C[("changed", gen(p))] += 1; EX.setdefault(("changed", gen(p)), (p, str(x)[:90], str(y)[:90]))
def results(d):
    out = {}
    for t in d:
        for i, c in enumerate(t.get("calls") or t.get("results") or []):
            out[f"{t.get('tid')}#{i}"] = c
    return out
ra, rb = results(a), results(b)
print("calls tip", len(ra), "merge", len(rb), "differ", sum(1 for k in ra if ra[k] != rb.get(k)))
for k in sorted(set(ra) | set(rb)):
    walk(ra.get(k, {}), rb.get(k, {}), "")
for (kind, p), n in sorted(C.items(), key=lambda kv: (kv[0][0], -kv[1])):
    print(f"{n:5d} {kind:18s} {p}")
