"""Seam: what values mode counts as 'found' (verify._Pool: numbers, dates, hours) in each probe turn, on the tip's tool
results against the merge's (the merge's verify.py on both). New members are values a made-up unmarked figure can now
match. Made-up library only."""
import json, sys
sys.dont_write_bytecode = True
sys.path.insert(0, sys.argv[1] + "/experiments")
from mvp.brain import verify as V
a = {t["tid"]: t for t in json.load(open(sys.argv[2]))}; b = {t["tid"]: t for t in json.load(open(sys.argv[3]))}
tot_n = tot_d = 0
for tid in b:
    ra = {c["rid"]: c["result"] for c in a[tid]["calls"] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
    rb = {c["rid"]: c["result"] for c in b[tid]["calls"] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
    pa, pb = V._Pool(V.Ledger(ra), b[tid]["message"]), V._Pool(V.Ledger(rb), b[tid]["message"])
    nn = sorted(x for x in pb.nums - pa.nums if x == int(x) and 0 <= x < 10000)
    gone = sorted(x for x in pa.nums - pb.nums if x == int(x) and 0 <= x < 10000)
    nd = sorted(pb.dates - pa.dates, key=str)
    tot_n += len(nn); tot_d += len(nd)
    print(f"{tid}: +{len(nn)} numbers {[int(x) for x in nn][:20]}  -{len(gone)}  +{len(nd)} dates {nd[:6]}")
print("total new whole numbers", tot_n, "new dates", tot_d)
