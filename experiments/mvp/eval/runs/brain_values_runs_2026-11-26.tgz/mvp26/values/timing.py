import time, statistics as st
import lib26 as L
V = L.V
forms = [(rec, t, res, f) for run in ("look1", "look2", "run1", "run2") for rec, t, res in L.inputs(run)
         for f in (rec.get("forms") or [])]
for name, mod, mode in (("cells@tip", L.VT, "cells"), ("full", L.VT, "full"), ("values", V, "values")):
    ts = []
    for rec, t, res, f in forms:
        vt = mod.Turn.of(t)
        a = time.perf_counter(); mod.check_answer(f, res, vt, mode=mode); ts.append((time.perf_counter() - a) * 1000)
    ts.sort()
    print(f"{name:10s} forms {len(ts)} median {st.median(ts):.1f} ms, p90 {ts[int(0.9*len(ts))]:.1f} ms, max {ts[-1]:.1f} ms")
v = V.check_answer(forms[0][3], forms[0][2], V.Turn.of(forms[0][1]), mode="values")
print("flags of the first form's lead:", v.outcomes[0].flags[:6])
