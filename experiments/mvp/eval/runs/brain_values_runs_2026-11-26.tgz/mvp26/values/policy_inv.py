"""Every live sentence (four runs, all forms) a policy or safety code drops, in full and cells mode (tip), by truth."""
import json
from collections import Counter, defaultdict
import lib26 as L
POL = ["sensitive", "psych", "outcome", "second_person", "language", "link", "outside_in_history", "watch_time",
       "private_total", "weak_fit", "generic_claim", "filler", "limits"]
seen = defaultdict(list)
for run in ("look1", "look2", "run1", "run2"):
    for mode in ("full", "cells"):
        for r in L.rows(run, L.VT, mode):
            for c in r["reasons"]:
                c0 = c.split(":")[0]
                if c0 in POL:
                    seen[(c0, mode)].append((run, r["key"], r["fi"], r["where"], r["index"], r["truth"],
                                             r["reasons"], r["text"]))
out = []
for (c, mode), xs in sorted(seen.items()):
    out.append(f"== {c} [{mode}] {len(xs)} drops; truth {dict(Counter(x[5] for x in xs))}")
    for x in xs:
        out.append(f"   {x[0]} {x[1]} f{x[2]} {x[3]}{x[4]} {x[5]} {','.join(x[6])} | {x[7][:230]}")
open("policy_inventory.txt", "w").write("\n".join(out) + "\n")
print("\n".join(l for l in out if l.startswith("==")))
