"""Does the tip's checker in the run's own mode reproduce the saved verdicts of each live run?"""
import json, sys
import lib26 as L
for run in ("look1", "look2", "run1", "run2"):
    n = bad = 0
    for rec, t, results in L.inputs(run):
        mode = rec.get("check") or "full"
        for fi, form in enumerate(rec.get("forms") or []):
            v = L.check(L.VT, form, results, t, mode)
            sv = (rec.get("verdicts") or [None] * 9)[fi]
            if sv is None:
                continue
            a = [(o.where, o.index, sorted(o.reasons)) for o in v.outcomes]
            b = [(o["where"], o["index"], sorted(o["reasons"])) for o in sv["outcomes"]]
            n += 1
            if a != b:
                bad += 1
                if bad <= 3:
                    print(run, rec["key"], fi, mode, [x for x in a if x not in b], [x for x in b if x not in a])
    print(run, "forms", n, "differ from saved (tip checker, the run's own mode)", bad,
          "modes", sorted({r.get("check") for r, _t, _x in L.inputs(run)}, key=str))
