"""Step 1: why run 2's checker dropped 48 true sentences (all forms). run 2's saved forms against run 2's own ledgers,
under the checker of 4064f3e (cells) and the tip's (cells), then the tip with its 24.8 parts switched off one by one."""
import json, re, sys
from collections import Counter
import lib26 as L
VT, VO = L.VT, L.VO
NEW_RULES = sorted(VT.CELLS_RULES - {"insight_walk"})
NEVER = re.compile(r"(?!x)x")
SEASON_RX = VT._LAST_BEFORE


def mode(rules=None, loose=None):
    c = VT.CELLS
    return VT.CheckMode("cells", off=c.off, loose=frozenset(c.loose if loose is None else loose), insight=c.insight,
                        cells=True, rules=frozenset(c.rules if rules is None else rules))


def outcome(mod, cm, form, results, t, where, index, season=True):
    VT._LAST_BEFORE = SEASON_RX if season else NEVER
    try:
        v = L.check(mod, form, results, t, cm)
    finally:
        VT._LAST_BEFORE = SEASON_RX
    o = next((o for o in v.outcomes if o.where == where and o.index == index), None)
    return o


OLD_LOOSE = set(VT.CELLS_LOOSE) | {"short_word", "platform_all"}
OLD_LOOSE_NOW = (OLD_LOOSE - {"own_fields", "hour_word", "handle", "month_alone", "label_in_date", "quoted_title"})
rows = []
for rec, t, results in L.inputs("run2"):
    for fi, form in enumerate(rec.get("forms") or []):
        v = L.check(VT, form, results, t, "cells")
        for o in v.outcomes:
            tr, lab = L.truth_of("run2", rec["key"], fi, o.where, o.index)
            if tr != "T" or o.kept:
                continue
            args = (form, results, t, o.where, o.index)
            oo = outcome(VO, "cells", *args)
            base = mode(rules=frozenset(), loose=OLD_LOOSE)   # tip with no 24.8 rule, the old loosenings back
            ob = outcome(VT, base, *args, season=False)
            r = {"id": f"{rec['key']}.f{fi}.{o.where}{o.index}", "text": o.text, "tip": o.reasons,
                 "old": (oo.reasons if oo else ["missing"]), "tip_no_new": ob.reasons}
            # each 24.8 part switched off alone on the tip
            alone = {}
            for nm in VT.CELLS_RULES:
                x = outcome(VT, mode(rules=VT.CELLS_RULES - {nm}), *args)
                alone[nm] = x.kept
            alone["season"] = outcome(VT, mode(), *args, season=False).kept
            for lz in ("short_word", "platform_all"):
                alone["+" + lz] = outcome(VT, mode(loose=set(VT.CELLS_LOOSE) | {lz}), *args).kept
            r["kept_if_off"] = sorted(k for k, k_ in alone.items() if k_)
            # which part alone, added to the base, drops it
            adds = {}
            for nm in VT.CELLS_RULES:
                adds[nm] = not outcome(VT, mode(rules={nm}, loose=OLD_LOOSE), *args, season=False).kept
            adds["season"] = not outcome(VT, mode(rules={"period_named"}, loose=OLD_LOOSE), *args, season=True).kept \
                and outcome(VT, mode(rules={"period_named"}, loose=OLD_LOOSE), *args, season=False).kept
            adds["-short_word/-platform_all"] = not outcome(VT, mode(rules=frozenset(), loose=VT.CELLS_LOOSE), *args,
                                                            season=False).kept
            r["drops_if_added"] = sorted(k for k, k_ in adds.items() if k_)
            if not ob.kept:
                cause = "old rule" if oo is not None and not oo.kept else "old rule, reached only on the tip"
            else:
                d = r["drops_if_added"]
                if "insight_walk" in d:
                    cause = "insight_walk"
                elif "season" in d:
                    cause = "season rule"
                elif d:
                    cause = "new rule: " + "+".join(d)
                else:
                    cause = "new rules together: " + ",".join(r["kept_if_off"])
            r["cause"] = cause
            rows.append(r)
json.dump(rows, open("attribution.json", "w"), indent=1)
print(len(rows), Counter(r["cause"].split(":")[0] for r in rows))
for r in rows:
    print(f"{r['id']:22s} {r['cause']:34s} tip={','.join(r['tip'])} old={','.join(r['old']) or 'KEPT'} "
          f"noNew={','.join(r['tip_no_new']) or 'KEPT'} offKeeps={r['kept_if_off']}")
