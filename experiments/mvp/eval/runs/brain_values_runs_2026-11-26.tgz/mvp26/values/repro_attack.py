"""Reproduce the published attack figures on the tip's checker (cells, full) before adding values."""
import lib26 as L
for mode in ("cells", "full"):
    c2 = L.run_check2(L.VT, mode)
    a2 = L.run_a2(L.VT, mode)
    pl = L.run_planted(L.VT, mode)
    F = [r for r in c2 if r["truth"] == "F"]; T = [r for r in c2 if r["truth"] == "T"]
    print(mode, "attacker2 false out", sum(r["out"] for r in F), "of", len(F), "| true refused",
          sum(not r["kept"] for r in T), "of", len(T))
    F = [r for r in a2 if r["truth"] == "F"]; T = [r for r in a2 if r["truth"] == "T"]
    print(mode, "attack2 false out", sum(r["out"] for r in F), "of", len(F), "| true refused", sum(not r["kept"] for r in T), "of", len(T))
    b = [r for r in pl if r["set"] in ("planted:new", "planted:audit", "planted:insight_v5")]
    print(mode, "planted builder false handled", sum(1 for r in b if r["truth"] == "F" and not r["out"]), "of",
          sum(1 for r in b if r["truth"] == "F"), "| true kept", sum(1 for r in b if r["truth"] == "T" and r["kept"]),
          "of", sum(1 for r in b if r["truth"] == "T"), "| sets", sorted({r["set"] for r in pl}))
