"""Step 3: the four live runs, every hand-judged sentence with a claim (first and repair forms), under the checkers:
full (tip), cells at 4064f3e, cells at the tip, values (number words flagged / refused). Made-up library; no model call."""
import json, sys
from collections import Counter
import lib26 as L
V = L.V
CHECKERS = [("full", L.VT, "full"), ("cells@4064f3e", L.VO, "cells"), ("cells@tip", L.VT, "cells"),
            ("values(nw flag)", V, V.values_mode("flag")), ("values(nw refuse)", V, V.values_mode("refuse"))]
RUNS = ("look1", "look2", "run1", "run2")


def paths(run, mod, mode):
    out = {"lead_first": 0, "reword": 0, "code_low": 0, "code_high": 0, "no_form": 0, "n": 0}
    for rec, t, results in L.inputs(run):
        out["n"] += 1
        forms = rec.get("forms") or []
        if not forms:
            out["no_form"] += 1
            out["code_low"] += 1
            out["code_high"] += 1
            continue
        v1 = L.check(mod, forms[0], results, t, mode)
        out["lead_first"] += v1.lead_ok
        out["reword"] += v1.repair
        if not v1.repair or v1.lead_ok:
            continue   # the model's lead goes out (its own, or kept while a reword fails)
        if len(forms) > 1:
            v2 = L.check(mod, forms[1], results, t, mode)
            if not v2.lead_ok:
                out["code_low"] += 1
                out["code_high"] += 1
        else:
            out["code_high"] += 1   # a reword the live run never asked for: unknown
    return out


def main():
    res = {}
    lists = {}
    for cname, mod, mode in CHECKERS:
        for run in RUNS:
            rs = L.rows(run, mod, mode)
            d = {}
            for scope, sel in (("first", lambda r: r["fi"] == 0), ("all", lambda r: True)):
                T = [r for r in rs if sel(r) and r["truth"] == "T"]
                F = [r for r in rs if sel(r) and r["truth"] == "F"]
                d[scope] = {"T": len(T), "T_refused": sum(not r["kept"] for r in T), "F": len(F),
                            "F_refused": sum(not r["kept"] for r in F), "F_out": sum(r["kept"] for r in F)}
            d.update(paths(run, mod, mode))
            res[(cname, run)] = d
            if cname.startswith("values"):
                lists[(cname, run)] = [r for r in rs if r["truth"] in ("T", "F") and not r["kept"]]
    lines = []
    P = lines.append
    for scope in ("first", "all"):
        P(f"== {scope} forms: true refused / wrongly based refused / wrongly based let out")
        P(f"{'checker':20s}" + "".join(f"{r:>16s}" for r in RUNS) + f"{'total':>18s}")
        for cname, _m, _x in CHECKERS:
            cells = []
            tot = Counter()
            for run in RUNS:
                d = res[(cname, run)][scope]
                cells.append(f"{d['T_refused']:3d}/{d['T']:<3d} {d['F_refused']:2d}/{d['F_out']:<2d}")
                tot.update({k: d[k] for k in ("T", "T_refused", "F_refused", "F_out")})
            P(f"{cname:20s}" + "".join(f"{c:>16s}" for c in cells) +
              f"{tot['T_refused']:5d}/{tot['T']:<4d} {tot['F_refused']:2d}/{tot['F_out']:<2d}")
    P("")
    P("== answers (first form): model lead kept on the first pass / rewords asked for / fall to a code lead (low-high)")
    P(f"{'checker':20s}" + "".join(f"{r:>18s}" for r in RUNS) + f"{'total':>18s}")
    for cname, _m, _x in CHECKERS:
        cells, tot = [], Counter()
        for run in RUNS:
            d = res[(cname, run)]
            cells.append(f"{d['lead_first']:2d}/{d['n']} {d['reword']:2d} {d['code_low']}-{d['code_high']}")
            tot.update({k: d[k] for k in ("lead_first", "n", "reword", "code_low", "code_high")})
        P(f"{cname:20s}" + "".join(f"{c:>18s}" for c in cells) +
          f"{tot['lead_first']:4d}/{tot['n']} {tot['reword']:2d} {tot['code_low']}-{tot['code_high']}")
    P("(code lead: low = a saved reword that still fails, or no form at all (time ran out); high = also every refused")
    P(" first lead with no saved reword, since the live run never asked for one. The looks ran in full mode, runs 1 and")
    P(" 2 in cells mode: a saved reword answers that checker's repair text, not this one's.)")
    no_form = {run: res[('full', run)]['no_form'] for run in RUNS}
    P(f"records with no form (time ran out before any answer): {no_form}")
    for cname in ("values(nw flag)", "values(nw refuse)"):
        P("")
        P(f"== {cname}: every hand-judged sentence it refuses")
        for run in RUNS:
            for r in lists[(cname, run)]:
                P(f"  {run} {r['key']} f{r['fi']} {r['where']}{r['index']} truth={r['truth']} {','.join(r['reasons'])}"
                  f" | {'; '.join(r['details'][:2])[:140]}")
                P(f"      {r['text'][:220]}")
    open("step3_live.txt", "w").write("\n".join(lines) + "\n")
    json.dump({f"{k[0]}|{k[1]}": v for k, v in res.items()}, open("step3_live.json", "w"), indent=1)
    print("\n".join(lines))


if __name__ == "__main__":
    main()
