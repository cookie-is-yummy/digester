"""The class split of every false attack sentence, by a hand rule written as code and kept apart from the checker's
"found" pool (stricter: sheet cells and date fields only, no note prose, no list lengths, no meta numbers but the
window dates, names only from name fields):
MADE-UP VALUE: a figure, date, clock time or name that no cell of the turn holds (nor the message), or a marker that
does not hold the value written beside it (a number, share, date, hour, name; a calc that does not give it).
REAL VALUE MISATTACHED: every value is held, but said of the wrong period, row, measure or event.
POLICY: the planted, skeptic and record sets' own policy class (outside knowledge, feelings, limits talk, ...).
Every MADE-UP case that values mode lets out is then read by hand (handread.txt)."""
import json, pickle, re, sys
from collections import Counter, defaultdict
from datetime import date
import lib26 as L
VT = L.VT
V = L.V
LOOSE = VT.CELLS_LOOSE
NAME_KEYS = ("name", "title", "channel", "label", "theme", "area", "handle", "part", "platform")
# code's own text that holds dates, spans and clock times: window words, labels, notes (never a title or a name)
CODE_TEXT_KEYS = ("words", "window_said", "said", "label", "notes", "filters_said", "previous_words", "asked")


class Strict:
    def __init__(self, results, message):
        self.nums, self.fracs, self.dates, self.months, self.years, self.hours, self.times = set(), [], set(), set(), set(), set(), set()
        self.names = set()
        self.code = []
        self.msg = " ".join(str(message or "").split()).lower()

        def walk(o, key=None):
            if isinstance(o, bool) or o is None:
                return
            if isinstance(o, (int, float)):
                self.nums.add(round(float(o), 6))
                if isinstance(o, float) and 0 <= o <= 1:
                    self.fracs.append(o * 100)
                if key == "hour":
                    self.hours.add(int(o) % 24)
            elif isinstance(o, str):
                if key in V._V_THIRD_PARTY:
                    if key in NAME_KEYS:
                        self.names.add(" ".join(o.lower().split()))
                    return
                if key in CODE_TEXT_KEYS or key is None:
                    self.code.append(o.lower())
                m = V._V_ISO.match(o.strip())
                if m:
                    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
                    self.dates.add((y, mo, d)); self.years.add(y)
                    if m.group(4):
                        h = int(m.group(4)) % 12 + (12 if (m.group(6) or "").lower().startswith("p") else 0) \
                            if m.group(6) else int(m.group(4))
                        self.hours.add(h); self.times.add((h, int(m.group(5))))
                if key == "label":
                    mm = re.match(r"^(" + V._V_MONTH + r")\w*\.?\s+((?:19|20)\d\d)$", o.strip(), re.I)
                    if mm:
                        self.months.add((int(mm.group(2)), V._mon_i(mm.group(1)))); self.years.add(int(mm.group(2)))
                    my = re.match(r"^((?:19|20)\d\d)$", o.strip())
                    if my:
                        self.years.add(int(my.group(1)))
                if key in NAME_KEYS:
                    self.names.add(" ".join(o.lower().split()))
                    if key == "handle":
                        self.names.add("@" + o.lower().lstrip("@"))
            elif isinstance(o, dict):
                for k, v in o.items():
                    walk(v, k)
            elif isinstance(o, list):
                for v in o:
                    walk(v, key)
        for env in (results.values() if isinstance(results, dict) else results):
            walk(env.get("sheet") or {})
            meta = env.get("meta") or {}
            for k in ("windows", "window_dates", "window_dates_b"):
                walk(meta.get(k) or {})
            for k in ("window_said", "notes", "filters_said"):
                walk(meta.get(k), k)
            for k, v in (meta.get("resolved") or {}).items():
                self.names.add(k.lower())
            fs = meta.get("filters_said")
            if isinstance(fs, str):
                for part in re.findall(r"(?:only|without)\s+([^()·]+?)\s*\(", fs):
                    self.names.add(part.strip().lower())
        ct = "\n".join(self.code) + "\n" + self.msg
        for m in re.finditer(r"(?<![\w.])\d+(?:\.\d+)?", ct):
            self.nums.add(float(m.group(0)))
        for m in re.finditer(r"\b(?:19|20)\d\d\b", ct):
            self.years.add(int(m.group(0)))
        for m in re.finditer(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(" + V._V_MONTH + r")\w*\.?(?:,?\s+((?:19|20)\d\d))?\b", ct):
            if 1 <= int(m.group(1)) <= 31:
                self.dates.add((int(m.group(3)) if m.group(3) else None, V._mon_i(m.group(2)), int(m.group(1))))
        for m in re.finditer(r"\b(" + V._V_MONTH + r")\w*\.?,?\s+((?:19|20)\d\d)\b", ct):
            self.months.add((int(m.group(2)), V._mon_i(m.group(1))))
        for m in V._V_CLOCK.finditer(ct):
            self.hours.add(int(m.group(1)) % 12 + (12 if m.group(3).lower().startswith("p") else 0))

    def num(self, n, pct, hedged):
        tol = 1.5 if hedged else 0.5
        if pct:
            return any(abs(f - n) <= tol for f in self.fracs)
        if round(n, 6) in self.nums:
            return True
        return any(abs(f - n) <= tol for f in self.fracs)

    def date(self, y, mo, d):
        if any((y is None or a is None or a == y) and (mo is None or b == mo) and (d is None or c == d)
               for a, b, c in self.dates):
            return True
        if d is None and mo is not None and any((y is None or a == y) and b == mo for a, b in self.months):
            return True
        if d is None and mo is None and y is not None:
            return y in self.years or str(y) in self.msg
        return False

    def name(self, s):
        s = " ".join(s.lower().split()).strip(" .,;:")
        if not s:
            return True
        rx = re.compile(r"(?<![\w@])" + re.escape(s) + r"(?![\w])")
        return any(rx.search(n) for n in self.names) or bool(rx.search(self.msg))


def strict_faults(text, results, message):
    """[(kind, detail)]: the values of one sentence that no cell holds, or markers that do not hold their value."""
    led = VT.Ledger(results)
    raw = " ".join(str(text or "").split())
    st = Strict(results, message)
    out = []
    markers, bad = VT.parse(raw, led, LOOSE)
    if bad:
        out.append(("marker", "a bracket that names no cell"))
    names_all = {n for r in led.by_rid.values() for n, _p in r.names}
    for r in led.by_rid.values():   # the rows' own labels and parts ("2021", "evening") are names of rows too
        stack = [r.sheet]
        while stack:
            o = stack.pop()
            if isinstance(o, dict):
                for k, v in o.items():
                    if k in ("label", "part") and isinstance(v, str) and v.strip():
                        names_all.add(v.strip())
                    else:
                        stack.append(v)
            elif isinstance(o, list):
                stack.extend(o)
    prev = 0
    for mk in sorted(markers, key=lambda m: m.mstart):
        if mk.kind in ("value", "count") and mk.said:
            r = VT.check_value(mk)
            if r and r[0] in ("wrong_value", "wrong_name", "wrong_measure"):
                out.append(("marker", f"{r[0]}: {r[1]}"))
        elif mk.kind == "value" and not mk.said:
            fm = V._V_FRACTION_RX.search(raw[prev:mk.mstart])
            if fm and VT._measure(mk.rest, mk.value)[1] == "share" and \
                    abs(float(mk.value) * 100 - V._V_FRACTIONS[fm.group("w").lower()]) > 2.0:
                out.append(("marker", f"'{fm.group('w')}' beside a share of {round(float(mk.value) * 100)}%"))
        elif mk.kind == "row" and not mk.said:
            pre = raw[prev:mk.mstart]
            q = re.search(r"[\"“]([^\"”]{2,160})[\"”]\s*$", pre)
            if q and isinstance(mk.value, dict) and mk.value.get("title"):
                if not V._title_said_ok(q.group(1), mk.value):
                    out.append(("marker", "a quoted title before an item that is not its"))
            else:
                own = V._row_own_names(mk.value, mk.rest)
                lp = pre.lower()
                other = next((n for n in sorted(names_all, key=len, reverse=True) if len(n) > 2 and
                              re.search(r"(?<![\w@])" + re.escape(n.lower()) + r"\s*$", lp)), None)
                if other and other.lower() not in own:
                    out.append(("marker", f"another row's name before {mk.path}"))
                elif not other:
                    claim = V._v_name_claim(pre)
                    if claim and not st.name(claim):
                        out.append(("name", f"before a row marker: '{claim[:40]}'"))
        elif mk.kind == "calc":
            r = V._values_calc(mk, led)
            if r and r[0] == "calc":
                out.append(("marker", f"calc: {r[1]}"))
        prev = mk.end
    wd = VT._typed_weekday(raw)
    if wd:
        out.append(("date", "weekday: " + wd[1]))
    # an unmarked ratio or fraction word is a computed value no cell holds (a share near a fraction word counts)
    tt = raw
    for mk in markers:
        if mk.kind == "calc":
            tt = V._blank(tt, mk.start, mk.end)
    for m in RATIO_WORDS.finditer(tt):
        w = m.group(0).lower()
        if re.search(r"\b(?:first|second|other)\s+$", tt[:m.start()], re.I) and w == "half":
            continue   # a period ("the first half of 2025")
        if w == "twice" and re.search(r"\b(?:opened|watched|saved|viewed)(?:\s+\w+)?\s*$", tt[:m.start()], re.I):
            if not st.num(2.0, False, False):
                out.append(("number word", "twice (a count of two)"))
            continue
        fr = next((v for k, v in V._V_FRACTIONS.items() if k in w), None)
        if fr is not None and any(abs(f - fr) <= 2.0 for f in st.fracs):
            continue
        out.append(("computed word", w))
    t = raw
    for mk in markers:
        t = V._blank(t, mk.start, mk.end)
    t = re.sub(r"\[[^\]]*\]", lambda m: " " * len(m.group(0)), t)
    for m in list(V._V_QUOTE.finditer(t)):
        q = re.sub(r"(?:\.\.\.|…)\s*$", "", m.group(1)).strip().lower()
        if not any(q in n or n.startswith(q) for n in st.names):
            out.append(("name", f"quoted '{q[:40]}'"))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_HANDLE.finditer(t)):
        if not st.name(m.group(0)):
            out.append(("name", m.group(0)))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_RANGE.finditer(t)):
        mo, y = V._mon_i(m.group(3)), (int(m.group(4)) if m.group(4) else None)
        for d in (int(m.group(1)), int(m.group(2))):
            if not st.date(y, mo, d):
                out.append(("date", m.group(0))); break
        t = V._blank(t, m.start(), m.end())
    for rx, order in ((V._V_DAYMON, "dmy"), (V._V_MONDAY, "mdy")):
        for m in list(rx.finditer(t)):
            if order == "dmy":
                d, mo, y = int(m.group(1)), V._mon_i(m.group(2)), (int(m.group(3)) if m.group(3) else None)
            else:
                mo, d, y = V._mon_i(m.group(1)), int(m.group(2)), (int(m.group(3)) if m.group(3) else None)
            if not 1 <= d <= 31:
                continue
            if y is None:
                ny = V._V_RANGE_END.match(raw[m.end():m.end() + 40])
                y = int(ny.group(1)) if ny else None
            if not st.date(y, mo, d):
                out.append(("date", m.group(0)))
            t = V._blank(t, m.start(), m.end())
    for m in list(V._V_MONYEAR.finditer(t)):
        if not st.date(int(m.group(2)), V._mon_i(m.group(1)), None):
            out.append(("date", m.group(0)))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_YEAR.finditer(t)):
        if not st.date(int(m.group(1)), None, None):
            out.append(("date", m.group(1)))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_MONALONE.finditer(t)):
        if m.group(1) in ("may", "march"):
            continue
        if not st.date(None, V._mon_i(m.group(1)), None):
            out.append(("date", m.group(1)))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_CLOCK.finditer(t)):
        h = int(m.group(1)) % 12 + (12 if m.group(3).lower().startswith("p") else 0)
        if h not in st.hours:
            out.append(("time", m.group(0)))
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_FIG.finditer(t)):
        n = float(m.group("num").replace(",", ""))
        hedged = bool(re.search(r"\b" + VT._HEDGE_RX + r"\s*$", t[:m.start()], re.I))
        if m.group("ord") and st.date(None, None, int(n)):
            pass
        elif not st.num(n, bool(m.group("pct")), hedged):
            out.append(("figure", m.group(0).strip()))
        t = V._blank(t, m.start(), m.end())
    for m in list(RATIO_WORDS.finditer(t)):
        t = V._blank(t, m.start(), m.end())
    for m in list(V._V_NUMWORD_RX.finditer(t)):
        w = m.group("w").lower()
        ok = st.num(float(V._V_NUM_WORDS[w]), False, False) if w in V._V_NUM_WORDS else \
            any(abs(f - V._V_FRACTIONS[w]) <= 5.0 for f in st.fracs)
        if not ok:
            out.append(("number word", w))
        t = V._blank(t, m.start(), m.end())
    lead_at = len(t) - len(t.lstrip(" \"“'(‘"))
    for m in V._V_CAPS.finditer(t):
        words = m.group(0).split()
        while words and V._v_plain_cap(words[0]):
            words = words[1:]
        while words and V._v_plain_cap(words[-1]):
            words = words[:-1]
        if not words:
            continue
        if m.start() == lead_at and len(m.group(0).split()) == 1 and not re.match(r"\s*[A-Z\"“@]", raw[m.end():]):
            continue
        run = " ".join(words)
        if not st.name(run):
            out.append(("name", run))
    return out


RATIO_WORDS = re.compile(r"\b(?:twice|double[ds]?|tripled?|triple|halved|quadrupled|(?:two|three|four|five|six|ten|\d+)"
                         r" times|(?:more|less) than half|half|a third|a quarter|two thirds|three quarters)\b", re.I)
POLICY_KINDS = re.compile(r"outside|psych|feeling|limits|repeat|watch|sensitive|outcome|instruction|inject|motive|"
                          r"second.person|language|link|private", re.I)


def gather():
    """Every false case of the attack sets with its text, results and message."""
    out = []
    from mvp.brain import planted as P
    pcls = P.classes()
    for r in L.run_planted(V, "full"):
        if r["truth"] != "F":
            continue
        c = r["case"]
        out.append({"set": r["set"], "id": r["id"], "text": r["text"], "results": L.planted_data()["ledgers"][c["ledger"]],
                    "message": (c.get("turn") or {}).get("message", ""),
                    "label": (pcls.get(r["id"]) or {}).get("class"),
                    "kind": r.get("kind") or c.get("why") or "", "target": r["target"]})
    for fn in (L.run_skeptic, L.run_rc, L.run_a2, L.run_check2):
        for r in fn(V, "full"):
            if r["truth"] == "F":
                out.append({"set": r["set"], "id": r["id"], "text": r["text"], "results": r["results"],
                            "message": r["message"], "label": r.get("class"), "kind": r.get("family") or r.get("why") or ""})
    return out


if __name__ == "__main__":
    cases = gather()
    rows = pickle.load(open("attack_rows.pkl", "rb"))
    res = []
    for c in cases:
        if c["label"] == "policy":
            cls, why = "POLICY", c["kind"]
        elif not c["text"]:
            cls, why = "NO_TEXT", c.get("target")
        else:
            f = strict_faults(c["text"], c["results"], c["message"])
            cls, why = ("MADE-UP", f) if f else ("MISATTACHED", [])
        e = {"set": c["set"], "id": c["id"], "class": cls, "why": why, "text": c["text"], "kind": c["kind"],
             "label": c["label"]}
        for ck in ("cells@tip", "values(nw flag)", "values(nw refuse)", "full"):
            rr = rows[(ck, c["set"], c["id"])]
            e[ck] = {"out": rr["out"], "reasons": rr["reasons"]}
        res.append(e)
    json.dump(res, open("classes.json", "w"), indent=1, default=str)
    tab = defaultdict(Counter)
    for e in res:
        s = e["set"].split(":")[0] if not e["set"].startswith("planted") else e["set"]
        for ck in ("full", "cells@tip", "values(nw flag)", "values(nw refuse)"):
            tab[(s, e["class"])][(ck, e[ck]["out"])] += 1
    print(f"{'set':22s} {'class':12s} {'n':>4s}   out: full / cells@tip / values(nw flag) / values(nw refuse)")
    for (s, cls), c in sorted(tab.items()):
        n = sum(v for (ck, o), v in c.items() if ck == "full")
        print(f"{s:22s} {cls:12s} {n:4d}   " + " / ".join(f"{c[(ck, True)]:3d}" for ck in
                                                           ("full", "cells@tip", "values(nw flag)", "values(nw refuse)")))
