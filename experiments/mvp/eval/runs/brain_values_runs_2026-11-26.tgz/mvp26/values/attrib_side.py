"""The 4064f3e checker (cells) and the tip's (cells) on run 1's and run 2's first forms: true drops by first code."""
from collections import Counter
import lib26 as L
lines = []
tab = {}
for run in ("run1", "run2"):
    for nm, mod in (("4064f3e", L.VO), ("tip", L.VT)):
        rs = [r for r in L.rows(run, mod, "cells") if r["fi"] == 0 and r["truth"] == "T"]
        d = [r for r in rs if not r["kept"]]
        tab[(run, nm)] = (len(d), len(rs), Counter(r["reasons"][0].split(":")[0] for r in d))
codes = sorted({c for v in tab.values() for c in v[2]}, key=lambda c: -sum(v[2].get(c, 0) for v in tab.values()))
hdr = f"{'first code':22s}" + "".join(f"{r + ' ' + n:>16s}" for r in ("run1", "run2") for n in ("4064f3e", "tip"))
lines.append(hdr)
for c in codes:
    lines.append(f"{c:22s}" + "".join(f"{tab[(r, n)][2].get(c, 0):16d}" for r in ("run1", "run2") for n in ("4064f3e", "tip")))
lines.append(f"{'total true dropped':22s}" + "".join(f"{tab[(r, n)][0]:>9d} of {tab[(r, n)][1]:<3d}" for r in ("run1", "run2")
                                                  for n in ("4064f3e", "tip")))
print("\n".join(lines))
open("attribution_side.txt", "w").write("\n".join(lines) + "\n")
