import sys, time
from collections import Counter
import lib26 as L
V = L.V
nw = sys.argv[1] if len(sys.argv) > 1 else "flag"
cm = V.values_mode(nw)
t0 = time.time(); n = 0
for run in ("look1", "look2", "run1", "run2"):
    rs = L.rows(run, V, cm)
    n += len(rs)
    T = [r for r in rs if r["truth"] == "T"]; F = [r for r in rs if r["truth"] == "F"]
    lost = [r for r in T if not r["kept"]]
    print(run, "true refused", len(lost), "of", len(T), "| false refused", sum(1 for r in F if not r["kept"]), "of", len(F),
          Counter(c for r in lost for c in r["reasons"]))
    for r in lost:
        print("   T-REFUSED", r["key"], r["fi"], r["where"], r["index"], r["reasons"], r["details"][:2], "|", r["text"][:170])
    for r in F:
        if not r["kept"]:
            print("   F-REFUSED", r["key"], r["fi"], r["where"], r["index"], r["reasons"], r["details"][:2], "|", r["text"][:170])
print("sec", round(time.time() - t0, 1), "outcomes", n)
