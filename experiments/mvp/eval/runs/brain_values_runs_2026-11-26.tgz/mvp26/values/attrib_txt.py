import json
from collections import Counter
import lib26 as L
rows = json.load(open("attribution.json"))
first = [r for r in rows if ".f0." in r["id"]]
out = []
P = out.append
P("mvp26 values, step 1: why run 2's checker dropped 48 true sentences (40 first forms, 8 repair forms).")
P("Method (attrib.py): run 2's saved forms (first and repair) against run 2's own saved ledgers. The tip's checker in cells")
P("mode gives run 2's live verdicts exactly (repro.py: 86 forms, 0 differ). Each dropped true sentence (truth:")
P("mvp25/recount2/sentences.json) was then checked by verify.py of 4064f3e (git show, cells mode, beside the repo's")
P("insight.py, which only gained the skip guards), and by the tip with its 24.8 parts switched off one at a time and all")
P("together (the nine CELLS_RULES, the merge's season rule, the short_word and platform_all loosenings put back).")
P("A cause is 'old rule' when the tip with every 24.8 part off still drops the sentence, and 4064f3e drops it too.")
P("")
P("Counts per cause (all forms / first forms):")
def cause(r):
    c = r["cause"]
    return "new rule (24.8): " + c.split(": ")[1] if c.startswith("new rule") else c
cc = Counter(cause(r) for r in rows); cf = Counter(cause(r) for r in first)
for k in sorted(cc, key=lambda k: -cc[k]):
    P(f"  {k:40s} {cc[k]:3d} / {cf.get(k, 0)}")
P(f"  {'the merge season rule':40s} {0:3d} / 0")
P(f"  {'insight_walk':40s} {0:3d} / 0")
P(f"  {'total':40s} {len(rows):3d} / {len(first)}")
P("")
P("No drop is caused by insight_walk or the season rule: switching either off gives back no sentence, and adding either")
P("alone to the tip-without-24.8 drops none. The removal of short_word and platform_all drops none on its own.")
P("Of the 5 new-rule drops, 4 are period_named (other_period) and 1 free_date ('date').")
P("")
P("The 43 old-rule drops by the first code the tip gives (all forms):")
oc = Counter(r["tip"][0] for r in rows if r["cause"] == "old rule")
for k, n in oc.most_common():
    P(f"  {k:22s} {n}")
P("Every one of the 43 is also dropped by 4064f3e's checker on the same form and ledger (in 3 the reasons differ:")
P("N016.0 lead f0 and f1 also had uncited_name at 4064f3e, given back by own_fields; N052.0's lead fell to insight's")
P("name:youtube3 at 4064f3e, and to bad_marker on the tip, once platform_all was taken out; N069.0 p1 also had")
P("uncited_name at 4064f3e).")
P("")
P("So the rise from 27 to 40 first-form true drops is not the rules of 24.8: those cost 5 of the 48 (4 of the 40). The")
P("other 43 are old rules meeting sentence shapes the model wrote on the new tool results:")
P("- uncited_number 13: a span or a time typed with no marker, most of them taken from cells or labels the tools now")
P("  give: '3 to 30 October 2026', '(12 to 15 October 2026)', 'the evening, 5pm to 9pm', 'at 3:00 pm', 'two channels',")
P("  '50 g flour ... 12 hours' (a saved post's own words).")
P("- two_results 8: a channel row of one result with the period rows of another (N005.0, N005.1: per-year counts), an")
P("  item of one result with a count of another (N054.0).")
P("- outside_in_history 6: 'which you first opened on', 'whose first day was', 'which you saved on', 'from Limit Lane'")
P("  after a quoted title, 'from Pan Theory' after a calc: history words read as outside knowledge.")
P("- the rest (16): insight's percent and wrong_measure on the new parts_of_day cells (4); insight's number on '722 of")
P("  the 729 items ... were on YouTube' (2); uncited_claim on a true limits line (2); unknown_name 2 ('Another' opening")
P("  a point, an '@handle' typed with no marker); one each of uncited_name, unnamed_owner, weekday, wrong_name,")
P("  bound_to_other, bad_marker.")
P("Measured directly (attrib_side.py): the checker of 4064f3e, in cells mode, drops 27 of 155 true first-form")
P("sentences of run 1 and 40 of 165 of run 2. The same old checker gives the whole rise. By first code:")
for l in open("attribution_side.txt"):
    P("  " + l.rstrip())
P("uncited_number goes from 3 to 12 and two_results from 1 to 8 under the same rules: the model wrote these shapes")
P("in run 2 and not in run 1. The tip gives back 9 of run 1's drops (the loosenings) and none net of run 2's.")
P("Note: the brief says watch_time refused 3 true sentences in run 2. This replay finds 1 (N048.1 f0 point 0, '12")
P("hours' of a saved post's text); the recount's own verifier_reasons also count 1. The 3 is not reproduced.")
P("")
P("Every dropped sentence (id = key.form.where+index; tip / 4064f3e / tip with no 24.8 part):")
for r in rows:
    P(f"  {r['id']:22s} {cause(r):34s} tip={','.join(r['tip'])} | 4064f3e={','.join(r['old']) or 'kept'} | "
      f"tip-no-24.8={','.join(r['tip_no_new']) or 'kept'}")
    P(f"      {r['text'][:200]}")
open("attribution.txt", "w").write("\n".join(out) + "\n")
print("\n".join(out[:40]))
