"""The attack sets under every checker: false out and true refused; saves rows for the class split."""
import json, sys, pickle
from collections import Counter
import lib26 as L
V = L.V
CHK = [("full", L.VT, "full"), ("cells@tip", L.VT, "cells"), ("values(nw flag)", V, V.values_mode("flag")),
       ("values(nw refuse)", V, V.values_mode("refuse"))]
SETS = [("planted", L.run_planted), ("skeptic", L.run_skeptic), ("rc2", L.run_rc), ("attack2", L.run_a2),
        ("attacker2", L.run_check2), ("extra", L.run_extra)]
allrows = {}
lines = []
for cname, mod, mode in CHK:
    for sname, fn in SETS:
        rs = fn(mod, mode)
        by = Counter()
        for r in rs:
            s = r["set"]
            by[(s, r["truth"], "out" if (r["out"] if r["truth"] == "F" else r["kept"]) else "no")] += 1
            allrows[(cname, s, r["id"])] = {k: r[k] for k in ("set", "id", "truth", "kept", "out", "reasons")} | \
                {"text": r.get("text"), "class": r.get("class"), "kind": r.get("kind"), "family": r.get("family")}
        for s in sorted({r["set"] for r in rs}):
            lines.append(f"{cname:18s} {s:22s} false out {by[(s, 'F', 'out')]:3d} of {by[(s, 'F', 'out')] + by[(s, 'F', 'no')]:3d}"
                         f" | true kept {by[(s, 'T', 'out')]:3d} of {by[(s, 'T', 'out')] + by[(s, 'T', 'no')]:3d}")
print("\n".join(lines))
open("attack_counts.txt", "w").write("\n".join(lines) + "\n")
pickle.dump(allrows, open("attack_rows.pkl", "wb"))
