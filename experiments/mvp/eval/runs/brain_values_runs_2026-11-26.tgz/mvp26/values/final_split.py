"""The made-up / misattached split with the hand reading applied: every case the code rule calls MADE-UP and values mode
lets out was read by hand (kept MADE-UP), and every MISATTACHED case out with a made-up-looking value was read; five
of those are MADE-UP by hand (HAND). Writes split_final.txt."""
import json
from collections import Counter, defaultdict
HAND = {  # (set, id): (class, why), read by hand against the results
    ("planted:attack", "attack_O06"): ("MADE-UP", "'all[...previous_share]': the cell is 87%"),
    ("attack2", "a31"): ("MADE-UP", "'anime clips': no result names anime (a lower-case made-up topic)"),
    ("attack2", "m03"): ("MADE-UP", "'anime videos': no result names anime"),
    ("attack2", "n08"): ("MADE-UP", "'anime videos': no result names anime"),
    ("planted:audit", "audit_F37"): ("MADE-UP", "'speedruns led 2023': no result of the turn holds speedruns or 2023's "
                                                "ranking"),
}
e = json.load(open("classes.json"))
CK = ["full", "cells@tip", "values(nw flag)", "values(nw refuse)"]
tab = defaultdict(Counter)
outs = []
for r in e:
    cls = HAND.get((r["set"], r["id"]), (r["class"], None))[0]
    if cls == "NO_TEXT":
        continue
    s = r["set"] if r["set"].startswith("planted") else r["set"]
    for ck in CK:
        tab[(s, cls)][ck] += r[ck]["out"]
    tab[(s, cls)]["n"] += 1
    if cls == "MADE-UP" and r["values(nw refuse)"]["out"]:
        outs.append((r["set"], r["id"], HAND.get((r["set"], r["id"]), (None, r["why"]))[1], r["text"]))
L = []
L.append(f"{'set':20s} {'class':12s} {'n':>4s}  out: full / cells@tip / values nw-flag / values nw-refuse (caught = n - out)")
tot = defaultdict(Counter)
for (s, cls), c in sorted(tab.items()):
    L.append(f"{s:20s} {cls:12s} {c['n']:4d}       " + " / ".join(f"{c[ck]:3d}" for ck in CK))
    for k in CK + ["n"]:
        tot[cls][k] += c[k]
L.append("")
for cls, c in sorted(tot.items()):
    L.append(f"{'ALL':20s} {cls:12s} {c['n']:4d}       " + " / ".join(f"{c[ck]:3d}" for ck in CK))
L.append("")
L.append("MADE-UP cases values mode (number words refused) lets out, each read by hand:")
for s, i, why, t in outs:
    L.append(f"  {s} {i}: {why}")
    L.append(f"      {t[:200]}")
open("split_final.txt", "w").write("\n".join(L) + "\n")
print("\n".join(L))
