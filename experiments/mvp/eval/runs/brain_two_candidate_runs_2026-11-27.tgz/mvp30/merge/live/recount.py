"""mvp30 merge: recount from the made-up library rows (mvp29/recount/lib.py) of the claims the hand reading of the
live run leans on. Private theme 'da' is left out of visible counts. No model call."""
import sys
from collections import Counter
from datetime import date as D
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp29/recount")
import lib  # noqa: E402
PRIV = {"da"}
TH = lib.THEME
op = lambda **kw: [e for e in lib.sel(kind="watch", **kw) if e["theme"] not in PRIV]
def show(k, v): print(f"{k:66s} {v}")
o = op(start=D(2026, 10, 1), end=D(2026, 10, 31))
gc = [e for e in o if TH[e["theme"]] == "Gaming clips"]
show("N008.1 Oct 2026 opens / Gaming clips by channel", (len(o), Counter(e["channel"] for e in gc)))
y = op(start=D(2026, 1, 1), end=D(2026, 12, 31))
show("F14.0 2026 Gaming clips theme / gaming area themes", (sum(TH[e["theme"]] == "Gaming clips" for e in y),
     Counter(TH[e["theme"]] for e in y if e.get("area", "") == "gaming" or TH[e["theme"]] in ("Gaming clips", "Minecraft builds", "Speedruns"))))
gd = [e for e in op() if e["channel"] == "Gaming Daily"]
show("F14.0 Gaming Daily opens / themes / first-last", (len(gd), Counter(TH[e["theme"]] for e in gd), min(e["date"] for e in gd), max(e["date"] for e in gd)))
ca = [e for e in op() if TH[e["theme"]] == "Calculus lessons"]
show("F15.0 calculus opens / lengths (s)", (len(ca), Counter(e["length"] for e in ca)))
show("K04.0 calculus saves", len([e for e in lib.sel(kind="save") if TH.get(e["theme"]) == "Calculus lessons"]))
lo = op(start=D(2026, 10, 21), end=D(2026, 10, 31))
show("N063.0 21-31 Oct opens / by channel", (len(lo), Counter(e["channel"] for e in lo).most_common(3)))
ids = Counter(e["item"] if "item" in e else e.get("id") for e in op())
show("C09.0 max opens of one item", max(ids.values()) if ids else None)
ig = [e for e in op() if e["platform"] == "instagram"]
show("D04/N035 Instagram opens first-last / n", (min(e["date"] for e in ig), max(e["date"] for e in ig), len(ig)))
show("D04.1 2022 opens", len(op(start=D(2022, 1, 1), end=D(2022, 12, 31))))
igs = [e for e in lib.sel(kind="save") if e["platform"] == "instagram"]
show("D04 Instagram saves dates", sorted(str(e["date"]) for e in igs))
# N005.0: themes per year (top rows) -- is Home cooking in every year?
for yr in range(2021, 2027):
    yy = op(start=D(yr, 1, 1), end=D(yr, 12, 31))
    show(f"N005.0 {yr} opens / themes", (len(yy), Counter(TH[e["theme"]] for e in yy).most_common()))
# N032.0: opens per weekday over all history (Mon=0)
show("N032.0 opens by weekday Mon..Sun", [sum(1 for e in op() if e["date"].weekday() == d) for d in range(7)])
# B05.0: last day per channel; channels of the 4 weeks before (3 Sep - 2 Oct 2026) absent in 3-30 Oct 2026
last = {}
for e in op():
    last[e["channel"]] = max(last.get(e["channel"], e["date"]), e["date"])
show("B05.0 last opened per channel", sorted((str(v), k) for k, v in last.items()))
cur = {e["channel"] for e in op(start=D(2026, 10, 3), end=D(2026, 10, 30))}
prev = {e["channel"] for e in op(start=D(2026, 9, 5), end=D(2026, 10, 2))}
show("B05.0 channels before / now / stopped", (sorted(prev), sorted(cur), sorted(prev - cur)))
# N019.0: channels first opened in fall 2026 (Sep 1 - Oct 30)
first = {}
for e in op():
    first[e["channel"]] = min(first.get(e["channel"], e["date"]), e["date"])
show("N019.0 channels first opened from 1 Sep 2026", sorted((k, str(v), sum(1 for x in op() if x['channel'] == k)) for k, v in first.items() if v >= D(2026, 9, 1)))
