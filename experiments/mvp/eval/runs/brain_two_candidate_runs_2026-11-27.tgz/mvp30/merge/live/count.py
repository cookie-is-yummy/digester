"""mvp30 merge: counters of the live run (written before reading any output), per cell and for the crossed run's
records of the same keys (mvp29, v3c and v4c, strict off and on) for comparison. Limit-only answers and read-failed
sentences use loopprompt/tools/count30.py's definitions (lim28.is_limit; READ_FAIL). Tool errors and argument errors
from each record's tool_args; rewords = records with a repair message; seconds per record.
usage: python3 count.py NAME=DIR ... [--keys K1,K2]"""
import json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
os.environ.setdefault("LIM_TREE", S + "/mvp29/run_tree")
sys.path.insert(0, S + "/mvp30/loopprompt/tools")
_argv = sys.argv
sys.argv = [sys.argv[0]]
import count30 as C  # noqa: E402
sys.argv = _argv
FAULTS = json.load(open(S + "/mvp30/cause/faults.json"))
KEYS = sorted({r["key"] for r in FAULTS["rows"]})


def load_all(d):
    import glob
    rs = []
    for f in glob.glob(os.path.join(d, "*.json")):
        if f.endswith("summary.json"):
            continue
        r = json.load(open(f, encoding="utf-8"))
        if "answer" in r:
            rs.append(r)
    return sorted(rs, key=lambda r: r["key"])


def fig(rs):
    f = {"records": len(rs)}
    f["limit-only answers"] = [r["key"] for r in rs if C.limit_only(r)]
    f["read-failed sentences"] = [(r["key"], s[:110]) for r in rs for s in C.model_sents(r) if C.READ_FAIL.search(s)]
    f["time_up events (records)"] = sum(1 for r in rs if "time_up" in (r.get("events") or []))
    f["provider_error / hard_stop"] = "/".join(str(sum(1 for r in rs if e in (r.get("events") or [])))
                                                for e in ("provider_error", "hard_stop"))
    te = [(r["key"], k, v) for r in rs for k, v in ((r.get("tool_args") or {}).get("tool_errors") or {}).items()]
    f["tool errors (calls)"] = sum(v for _k, _t, v in te)
    f["tool errors by kind"] = sorted({t for _k, t, _v in te})
    f["argument errors (calls)"] = sum((r.get("tool_args") or {}).get("arg_errors", 0) for r in rs)
    f["form errors"] = sum((r.get("tool_args") or {}).get("form_errors", 0) for r in rs)
    f["rewords (records with a repair message)"] = sum(1 for r in rs if r.get("repair_message"))
    f["lead model/repair/code/plain"] = "/".join(str(sum(1 for r in rs if r.get("lead_source") == s))
                                                 for s in ("model", "model_after_repair", "code", "plain"))
    f["refused sentences (all forms)"] = sum(1 for r in rs for v in r.get("verdicts") or [] if v
                                             for o in v.get("outcomes") or [] if not o.get("kept"))
    f["code time line / hand-back line"] = (f"{sum(1 for r in rs if C.TIME_LINE in (r.get('answer') or {}).get('text', ''))}"
                                            f" / {sum(1 for r in rs if C.HB_LINE in (r.get('answer') or {}).get('text', ''))}")
    secs = [r["seconds"] for r in rs]
    f["seconds median / p90 / max"] = f"{C.pct(secs, .5)} / {C.pct(secs, .9)} / {max(secs) if secs else None}"
    f["sentences sent per answer"] = round(sum((r.get("sentences") or {}).get("kept_sent", 0) for r in rs) / len(rs), 2) if rs else None
    f["values rules (records)"] = sorted({",".join(sorted(r.get("values_rules") or [])) for r in rs})
    f["cost $"] = round(sum(r.get("cost_usd", 0) for r in rs), 6)
    return f


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    only = None
    if "--keys" in sys.argv:
        only = set(sys.argv[sys.argv.index("--keys") + 1].split(","))
    for a in args:
        if "=" not in a:
            continue
        name, d = a.split("=", 1)
        rs = load_all(d)
        if only is not None:
            rs = [r for r in rs if r["key"] in only]
        print(f"######## {name} ({d})")
        for k, v in fig(rs).items():
            if isinstance(v, list) and v and isinstance(v[0], tuple):
                print(f"  {k}: {len(v)}")
                for x in v:
                    print(f"      {x}")
            else:
                print(f"  {k}: {v}")
