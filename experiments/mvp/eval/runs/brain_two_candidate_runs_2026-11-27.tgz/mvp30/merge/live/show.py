"""mvp30 merge: per fault key, the crossed run's fault rows and the live answers of the merged tree (v3d, v4d), with
the calls made (tool, args, error) for the hand reading. usage: python3 show.py [KEY ...] > show.txt"""
import collections, glob, json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
R = S + "/mvp30/merge/live"
F = json.load(open(S + "/mvp30/cause/faults.json"))
by = collections.defaultdict(list)
for r in F["rows"]:
    by[r["key"]].append(r)
recs = {}
for cell in ("A_v3d", "A_v4d", "H_v3d", "H_v4d"):
    for p in glob.glob(f"{R}/{cell}/*.json"):
        if p.endswith("summary.json"):
            continue
        r = json.load(open(p))
        recs[(cell[2:], r["key"])] = r
keys = sys.argv[1:] or sorted(by)
for k in keys:
    print("=" * 100)
    print(k)
    for r in by[k]:
        print(f"  was [{r['kind']}] {r['cell']} {r['class']}: {r['sentence'][:200]}")
    for p in ("v3d", "v4d"):
        r = recs.get((p, k))
        if not r:
            print(f"  {p}: no record"); continue
        print(f"  --- {p} lead {r.get('lead_source')} {r.get('seconds')}s events {r.get('events')} message: {r.get('message')}")
        for c in r.get("calls") or []:
            res = c.get("result") or {}
            print(f"     call {c.get('name')} {json.dumps(c.get('args'))[:230]} -> {res.get('rid') or ('ERROR ' + str(res.get('error'))[:150])}")
        print("     ANSWER: " + (r.get("answer") or {}).get("text", "").replace("\n", "\n             "))
        for v in r.get("verdicts") or []:
            for o in (v or {}).get("outcomes") or []:
                if not o.get("kept"):
                    print(f"     refused {o.get('reasons')}: {o.get('text', '')[:180]}")
