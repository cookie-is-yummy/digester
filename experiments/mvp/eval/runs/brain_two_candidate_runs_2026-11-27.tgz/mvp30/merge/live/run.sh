#!/bin/bash
# mvp30 merge live run: the merged tree (brain-r30-local), its default values mode (MVP_BRAIN_VALUES_RULES unset),
# MVP_BRAIN_STRICT=0, --parallel 3; every conversation the cause agent listed (set A fresh half a, set H plans
# held-out half), once with brain_v3d and once with brain_v4d. One cell at a time. Cap 0.11 (A) and 0.085 (H) each.
S=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad
R=$S/mvp30/merge/live; TREE=$S/mvp30/merge_tree
AIDS=N004,N005,N007,N008,N010,N018,N019,N024,N027,N032,N033,N035,N038,N041,N044,N048,N049,N052,N053,N055,N056,N057,N062,N063,N066,N068,N069
HIDS=A01,A03,A07,B05,B11,B14,C06,C09,D03,D04,D08,E04,F03,F04,F05,F08,F09,F11,F14,F15,I02,I03,K03,K04
ORDER="A_v3d A_v4d H_v3d H_v4d"
[ $# -gt 0 ] && ORDER="$*"
. $S/keys/anthropic.env
unset MVP_BRAIN_VALUES_RULES
for cell in $ORDER; do
  IFS=_ read -r set prompt <<< "$cell"
  if [ "$set" = A ]; then SETARGS="--set fresh --half a --ids $AIDS"; CAP=0.11; else SETARGS="--set plans --half heldout --ids $HIDS"; CAP=0.085; fi
  if [ -e "$R/$cell" ]; then echo "$cell exists, not run again" >> $R/starts.txt; continue; fi
  echo "$cell start $(date +%H:%M:%S) load $(cut -d' ' -f1-3 /proc/loadavg)" >> $R/starts.txt
  (cd $TREE/experiments && MVP_CLAUDE_CAP_USD=25 MVP_LEDGER_HOME=/home/user/digester/data/mvp \
    MVP_BRAIN_PROMPT=brain_$prompt MVP_BRAIN_STRICT=0 \
    python3 -B -m mvp.eval_brain run $SETARGS --check values --parallel 3 --max-usd $CAP --out $R/$cell 2>&1 \
    | sed -E 's/sk-ant-[A-Za-z0-9_-]+/<key>/g' > $R/$cell.log; echo "${PIPESTATUS[0]}" > $R/$cell.exit)
  NREC=$(ls $R/$cell 2>/dev/null | grep -v '^summary.json$' | grep -c '\.json$')
  echo "$cell end $(date +%H:%M:%S) exit $(cat $R/$cell.exit) records $NREC load $(cut -d' ' -f1-3 /proc/loadavg)" >> $R/starts.txt
done
