#!/bin/bash
# mvp31 runs: two candidates (brain_v3d, brain_v4d), each twice on set A (fresh half a) and twice on set H (plans
# held-out half). Strict off, the default values rules of the tip (MVP_BRAIN_VALUES_RULES unset). One at a time.
# usage: bash run8.sh [CELL ...]. Writes runs/<cell>/, <cell>.log, <cell>.exit and one line per run to starts.txt.
S=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad
R=$S/mvp31/runs
ORDER="A_v3d_1 A_v4d_1 A_v4d_2 A_v3d_2 H_v4d_1 H_v3d_1 H_v3d_2 H_v4d_2"
[ $# -gt 0 ] && ORDER="$*"
cd $S/mvp31/run_tree/experiments || exit 2
. $S/keys/anthropic.env
unset MVP_BRAIN_VALUES_RULES MVP_BRAIN_CHECK
for cell in $ORDER; do
  IFS=_ read -r set prompt rep <<< "$cell"
  if [ "$set" = A ]; then SETARGS="--set fresh --half a"; CAP=0.20; WANT=65; else SETARGS="--set plans --half heldout"; CAP=0.22; WANT=53; fi
  if [ -e "$R/$cell" ]; then echo "$cell exists, not run again" >> $R/starts.txt; continue; fi
  echo "$cell start $(date +%H:%M:%S) load $(cut -d' ' -f1-3 /proc/loadavg)" >> $R/starts.txt
  MVP_CLAUDE_CAP_USD=25 MVP_LEDGER_HOME=/home/user/digester/data/mvp \
    MVP_BRAIN_PROMPT=brain_$prompt MVP_BRAIN_STRICT=0 \
    python3 -B -m mvp.eval_brain run $SETARGS --check values --parallel 3 --max-usd $CAP --out $R/$cell 2>&1 \
    | sed -E 's/sk-ant-[A-Za-z0-9_-]+/<key>/g' > $R/$cell.log
  echo "${PIPESTATUS[0]}" > $R/$cell.exit
  NREC=$(ls $R/$cell | grep -v '^summary.json$' | grep -c '\.json$')
  echo "$cell end $(date +%H:%M:%S) exit $(cat $R/$cell.exit) records $NREC/$WANT load $(cut -d' ' -f1-3 /proc/loadavg)" >> $R/starts.txt
  if [ "$(cat $R/$cell.exit)" != 0 ] || [ "$NREC" != "$WANT" ]; then echo "$cell STOPPED THE LOOP" >> $R/starts.txt; break; fi
done
