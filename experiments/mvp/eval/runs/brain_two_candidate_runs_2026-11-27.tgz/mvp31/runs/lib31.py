"""mvp31 runs: shared loading for the eight runs of the two-candidate run (run_tree). Records are every
*.json of a run folder but summary.json (set A keys are N..., set H keys are A01... etc.), ordered as the eval's own
loader orders the set. No model call."""
import glob
import json
import os
import sys

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = os.path.join(S, "mvp31", "run_tree")
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E  # noqa: E402
from mvp.brain import verify as V  # noqa: E402

assert V.__file__.startswith(TREE), V.__file__
RUNS_DIR = os.path.join(S, "mvp31", "runs")
CELLS = ["A_v3d_1", "A_v4d_1", "A_v4d_2", "A_v3d_2", "H_v4d_1", "H_v3d_1", "H_v3d_2", "H_v4d_2"]
SETS = {"A": ("fresh", "a"), "H": ("plans", "heldout")}
WANT = {"A": 65, "H": 53}


def run_dir(cell):
    return os.environ.get("RUN_" + cell) or os.path.join(RUNS_DIR, cell)


def convs(set_key):
    name, half = SETS[set_key]
    return [p for p, _c in E.run_set(half, set_name=name)]


def keys(set_key):
    """The plan-message keys of the set, in the loader's order."""
    return [f"{p['id']}.{m['n']}" for p in convs(set_key) for m in p["messages"] if m["tier"] == "plan"]


def load(cell, d=None):
    d = d or run_dir(cell)
    order = {k: i for i, k in enumerate(keys(cell[0]))}
    rs = []
    for f in glob.glob(os.path.join(d, "*.json")):
        if os.path.basename(f) == "summary.json":
            continue
        r = json.load(open(f, encoding="utf-8"))
        if "key" in r:
            rs.append(r)
    rs.sort(key=lambda r: order.get(r["key"], 10 ** 6))
    sp = os.path.join(d, "summary.json")
    s = json.load(open(sp, encoding="utf-8")) if os.path.exists(sp) else None
    return rs, s


def pct(xs, q):   # summary27.pct, copied
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)
