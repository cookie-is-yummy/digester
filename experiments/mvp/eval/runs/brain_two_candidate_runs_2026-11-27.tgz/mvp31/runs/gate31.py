"""mvp31 runs: gate and mechanical figures of each finished run (free, no model call).
usage: python3 -B gate31.py CELL [CELL ...]"""
import json, os, sys
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib31 as L  # noqa: E402
V = L.V
WANT_RULES = sorted(V.VALUES_DEFAULT_RULES)
out = {}
for cell in sys.argv[1:]:
    sk, prompt, rep = cell.split("_")
    rs, s = L.load(cell)
    sett = (s or {}).get("settings") or {}
    bad = []
    if len(rs) != L.WANT[sk]:
        bad.append(f"records {len(rs)} != {L.WANT[sk]}")
    if any(r.get("skipped") for r in rs):
        bad.append("skipped " + ",".join(r["key"] for r in rs if r.get("skipped")))
    if {r.get("check") for r in rs} != {"values"}:
        bad.append("check")
    if {r.get("strict") for r in rs} != {False}:
        bad.append(f"strict {sorted({str(r.get('strict')) for r in rs})}")
    if {tuple(sorted(r.get("values_rules") or [])) for r in rs} != {tuple(WANT_RULES)}:
        bad.append("values_rules")
    if sett.get("prompt_version") != f"brain_{prompt}":
        bad.append(f"prompt {sett.get('prompt_version')}")
    if any(r.get("audit_error") for r in rs):
        bad.append("audit errors " + ",".join(r["key"] for r in rs if r.get("audit_error")))
    led = (s or {}).get("ledger") or {}
    if not led.get("matches_requests"):
        bad.append(f"ledger {led}")
    done = [r for r in rs if not r.get("skipped")]
    secs = [r["seconds"] for r in done if r.get("seconds") is not None]
    ev = Counter(e if isinstance(e, str) else (e.get("event") or e.get("kind") or str(e)[:30]) for r in done for e in (r.get("events") or []))
    sent = sum((r.get("sentences") or {}).get("kept_sent") or 0 for r in done)
    out[cell] = {"GATE_OK": not bad, "bad": bad, "records": len(rs), "lead_source": dict(Counter(r.get("lead_source") for r in done)),
                 "median_s": L.pct(secs, .5), "p90_s": L.pct(secs, .9), "max_s": max(secs) if secs else None,
                 "over_11s": sum(1 for x in secs if x > 11), "errors": sum(1 for r in done if r.get("error")),
                 "events": dict(ev), "rewords_asked": sum(1 for r in done if r.get("repair_message")),
                 "sentences_written": sum((r.get("sentences") or {}).get("written") or 0 for r in done),
                 "sentences_sent": sent, "dropped": sum(len(r.get("dropped") or []) for r in done),
                 "tool_errors": sum(sum(((r.get("tool_args") or {}).get("tool_errors") or {}).values()) for r in done),
                 "arg_errors": sum((r.get("tool_args") or {}).get("arg_errors") or 0 for r in done),
                 "audit_findings": sum(len((r.get("audit") or {}).get("findings") or []) for r in done),
                 "usd": led.get("brain_eval_usd"), "spent_settings": sett.get("spent_usd")}
    print(cell, json.dumps(out[cell]))
