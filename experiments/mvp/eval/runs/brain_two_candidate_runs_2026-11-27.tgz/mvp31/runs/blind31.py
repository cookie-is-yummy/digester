"""mvp29 runs: blind marking packets for the crossed run (adapted from mvp27/runs4/blind27.py). For every plan message
of set A (fresh half a, 65) and set H (plans held-out half, 53), loaded with the eval's own loader (eval_brain.run_set):
the user's message, the earlier turns of its conversation, and the four answers of that set's four runs exactly as sent
(answer.text verbatim, and its parts: lead, points, limit lines, ask-back, cards, scope line, private line, offers), in a
random order per message, each under a random code. Each answer carries the earlier answers its own run sent in the
conversation (as that run's user saw them). A turn that sent nothing, a record skipped or never written, is an empty
answer with its code. Nothing that could reveal the cell (timings, flags, prompt version, strict, run paths, events,
lead source, rids) is written. Groups: the conversations of each set split three ways (a conversation's messages stay
together; each group gets about a third of set A's messages and a third of set H's).
usage: python3 -B blind29.py OUT_DIR        (seed: SEED below)"""
import json
import os
import random
import re
import string
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib31 as L  # noqa: E402
from mvp.brain import answer as A  # noqa: E402

SEED = 31031
OUT = sys.argv[1]
rng = random.Random(SEED)
CELLS = {"A": [c for c in L.CELLS if c[0] == "A"], "H": [c for c in L.CELLS if c[0] == "H"]}
PART_KEYS = ["lead", "points", "limit_lines", "ask_back", "cards", "scope_line", "private_line", "offers"]


def parts(a):
    a = a or {}
    return {"lead": a.get("lead") or "",
            "points": list(a.get("points") or []),
            "limit_lines": list(a.get("limits") or []),
            "ask_back": A.ASK_LINE if a.get("ask") else None,
            "cards": [c.get("line") for c in (a.get("cards") or [])],
            "scope_line": a.get("scope_line") or None,
            "private_line": A.PRIVATE_LINE if a.get("private_line") else None,
            "offers": [o.get("label") for o in (a.get("offers") or [])]}


def sent(r):
    return ((r or {}).get("answer") or {}).get("text") or ""


used = set()


def code():
    while True:
        c = rng.choice(string.ascii_lowercase) + "".join(rng.choice(string.ascii_lowercase + string.digits)
                                                         for _ in range(2))
        if c not in used and not re.fullmatch(r"v\d[a-z]", c):   # never a code that reads like a build's name
            used.add(c)
            return c


recs, convs, keys = {}, {}, {}
for sk in ("A", "H"):
    convs[sk] = L.convs(sk)
    keys[sk] = L.keys(sk)
    assert len(keys[sk]) == L.WANT[sk], (sk, len(keys[sk]))
    for cell in CELLS[sk]:
        rs, _s = L.load(cell)
        recs[cell] = {r["key"]: r for r in rs}
        assert set(recs[cell]) <= set(keys[sk]), (cell, sorted(set(recs[cell]) - set(keys[sk])))
        for p in convs[sk]:
            for m in p["messages"]:
                k = f"{p['id']}.{m['n']}"
                if m["tier"] == "plan" and k in recs[cell]:
                    assert recs[cell][k]["message"] == m["text"], (cell, k)

packets, key, empties = {}, {}, []
for sk in ("A", "H"):
    for p in convs[sk]:
        for m in p["messages"]:
            if m["tier"] != "plan":
                continue
            k = f"{p['id']}.{m['n']}"
            earlier = []
            if p.get("before"):
                # what the bot was told it had read in the set-up turn (the same in all four runs; checked): tool,
                # window and filters as said, from the screen of the conversation's first plan record
                k0 = f"{p['id']}.{[x for x in p['messages'] if x['tier'] == 'plan'][0]['n']}"
                reads = set()
                for cell in CELLS[sk]:
                    pl = (((recs[cell].get(k0) or {}).get("screen") or {}).get("last_answer") or {}).get("plan") or []
                    reads.add(json.dumps([{"tool": e.get("tool"), "window": e.get("window_said"),
                                           "filters": e.get("filters_said")} for e in pl], sort_keys=True))
                assert len(reads) == 1, (p["id"], reads)
                earlier.append({"you": p["before"]["message"], "what_it_read": json.loads(reads.pop()),
                                "note": "set-up turn, run by code before the test; the bot knew what it had read then "
                                        "(shown here), not an answer text; no answer is shown"})
            prior = [x for x in p["messages"] if x["n"] < m["n"]]
            for x in prior:
                e = {"you": x["text"]}
                if x["tier"] != "plan":
                    e["note"] = "not sent to the bot in this test (no answer)"
                earlier.append(e)
            order = list(CELLS[sk])
            rng.shuffle(order)
            answers = []
            for cell in order:
                c = code()
                r = recs[cell].get(k)
                empty = r is None or bool(r.get("skipped")) or not sent(r)
                key[c] = {"set": sk, "cell": cell, "run_folder": L.run_dir(cell), "message_id": k,
                          "empty": empty, "why_empty": (None if not empty else "no record" if r is None else
                                                        "skipped: " + str(r.get("skipped")) if r.get("skipped") else
                                                        "nothing sent")}
                if empty:
                    empties.append((cell, k, key[c]["why_empty"]))
                seen = []
                for x in prior:
                    if x["tier"] != "plan":
                        continue
                    pr = recs[cell].get(f"{p['id']}.{x['n']}")
                    seen.append({"you": x["text"], "answer_sent": sent(pr)})
                answers.append({"code": c, "earlier_answers_seen": seen, "sent": "" if empty else sent(r),
                                "parts": parts(None if empty else r.get("answer")), "empty": empty})
            packets[k] = {"key": k, "set": sk, "conversation": p["id"], "earlier_turns": earlier, "message": m["text"],
                          "answers": answers}

# three groups per set by conversation (balanced: each conversation, in a seeded order then largest first, to the group
# with the fewest messages of that set)
groups = [[], [], []]
for sk in ("A", "H"):
    size = {p["id"]: sum(1 for m in p["messages"] if m["tier"] == "plan") for p in convs[sk]}
    order = [p["id"] for p in convs[sk]]
    rng.shuffle(order)
    gs = [[], [], []]
    for cid in sorted(order, key=lambda c: -size[c]):
        g = min(range(3), key=lambda i: (sum(size[c] for c in gs[i]), i))
        gs[g].append(cid)
    for i in range(3):
        groups[i] += [(sk, c) for c in gs[i]]

os.makedirs(OUT, exist_ok=True)
counts = []
for i, g in enumerate(groups):
    gset = set(g)
    msgs = [packets[k] for sk in ("A", "H") for k in keys[sk] if (sk, k.split(".")[0]) in gset]
    doc = {"group": i + 1,
           "how": ("Each message: the user's message, the earlier turns of its conversation, and four answers in a "
                   "random order under random codes. 'sent' is the answer exactly as the user saw it; 'parts' splits it "
                   "(lead, points, limit lines, ask-back, cards, scope line, private line, offers); "
                   "'earlier_answers_seen' is what this same answer's bot had sent before in the conversation. "
                   "'empty': true means that bot sent nothing for this message. 'set' A is the fresh set, H the plans "
                   "set; both use the same made-up library."),
           "messages": msgs}
    with open(os.path.join(OUT, f"group{i + 1}.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, ensure_ascii=False)
    counts.append({"group": i + 1,
                   "conversations": {sk: sum(1 for s_, _c in g if s_ == sk) for sk in ("A", "H")},
                   "messages": {sk: sum(1 for m in msgs if m["set"] == sk) for sk in ("A", "H")},
                   "answers": sum(len(m["answers"]) for m in msgs),
                   "empty_answers": sum(1 for m in msgs for a_ in m["answers"] if a_["empty"])})
with open(os.path.join(OUT, "KEY_do_not_open.json"), "w", encoding="utf-8") as f:
    json.dump({"seed": SEED, "script": os.path.abspath(__file__), "cells": CELLS,
               "run_folders": {c: L.run_dir(c) for c in L.CELLS},
               "groups": {f"group{i + 1}": [f"{sk}:{c}" for sk, c in g] for i, g in enumerate(groups)},
               "codes": key}, f, indent=1)

# self-tests: the key and the groups give back every sent answer.text byte for byte; every message has four answers;
# no leak words in the group files
back = {}
nmsg = 0
for i in range(3):
    doc = json.load(open(os.path.join(OUT, f"group{i + 1}.json"), encoding="utf-8"))
    for m in doc["messages"]:
        nmsg += 1
        assert len(m["answers"]) == 4, m["key"]
        assert sorted(a_["code"] for a_ in m["answers"]) == sorted(c for c, v in key.items() if v["message_id"] == m["key"]
                                                                   and v["set"] == m["set"])
        assert len({key[a_["code"]]["cell"] for a_ in m["answers"]}) == 4
        for a_ in m["answers"]:
            v = key[a_["code"]]
            back[(v["cell"], v["message_id"])] = a_["sent"]
            assert list(a_["parts"]) == PART_KEYS
assert nmsg == len(keys["A"]) + len(keys["H"]), nmsg
for cell, rs in recs.items():
    for k, r in rs.items():
        if not r.get("skipped"):
            assert back[(cell, k)] == sent(r), (cell, k)
leak = re.compile(r"brain_v|v3c|v4c|v3d|v4d|strict|prompt|seconds|flags?\b|lead_source|[AH]_v\d|/tmp|scratchpad|mvp2|mvp3|"
                  r"values|cells?\b|model_after|events?\b|time_up|rid\b|\"r\d\b|took_ms", re.I)
for i in range(3):
    raw = open(os.path.join(OUT, f"group{i + 1}.json"), encoding="utf-8").read()
    hits = sorted({h.group(0) for h in leak.finditer(raw)})
    print(f"group{i + 1}: leak-pattern hits {hits}")
same = sum(1 for sk in ("A", "H") for k in keys[sk]
           if len({sent(recs[c].get(k)) for c in CELLS[sk]}) < len(CELLS[sk]))
print(json.dumps({"seed": SEED, "counts": counts, "codes": len(key), "messages": nmsg,
                  "messages_with_two_answers_the_same_text": same, "empty": empties,
                  "self_test": f"ok: {len(back)} answers give back answer.text byte for byte"}, indent=1))
