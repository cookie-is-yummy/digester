import json,sys,glob,os
d=sys.argv[1]; ids=sys.argv[2:]
for f in sorted(glob.glob(d+'/*.json')):
    b=os.path.basename(f)
    if b=='summary.json': continue
    if ids and not any(b.startswith(i) for i in ids): continue
    r=json.load(open(f))
    print('==',b,'secs',r.get('seconds'),'lead_source',r.get('lead_source'),'events',r.get('events'),'err',r.get('error'))
    print('Q:',r.get('message'))
    print('A:',(r.get('answer') or {}).get('text','')[:1100])
    for x in r.get('dropped') or []:
        print('  DROPPED form',x.get('form'),x.get('where'),x.get('reasons'),'|',x.get('text','')[:260],'|',str(x.get('details'))[:260])
    if r.get('repair_message'): print('  REPAIR MSG:',r['repair_message'][:700])
