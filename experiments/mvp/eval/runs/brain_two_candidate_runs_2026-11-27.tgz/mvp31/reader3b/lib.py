"""Facts helper for reader3b: reads the library rows only (no brain tools)."""
import sys
from collections import Counter, defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # noqa: E402

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
AREA = {"mc": "Gaming", "sr": "Gaming", "cl": "Gaming", "wc": "Art and design", "dd": "Art and design",
        "ca": "Math", "np": "Math", "co": "Food and cooking", "da": "relationships (PRIVATE)"}

ROWS = B.rows()
EV = []  # one per event
for r in ROWS:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=k, t=t, d=t.date(), plat=r["platform"],
                       who=r.get("channel") or r.get("handle"), theme=r["theme"], area=AREA[r["theme"]],
                       tname=THEME[r["theme"]], length=r["length"], cap=r["caption"], friend=bool(r.get("friend")),
                       private=r["theme"] == "da"))


def sel(kind="watch", start=None, end=None, plat=None, friend=False, private=None, f=None):
    out = []
    for e in EV:
        if kind and e["kind"] != kind:
            continue
        if not friend and e["friend"]:
            continue
        if private is not None and e["private"] != private:
            continue
        if plat and e["plat"] != plat:
            continue
        if start and str(e["d"]) < start:
            continue
        if end and str(e["d"]) > end:
            continue
        if f and not f(e):
            continue
        out.append(e)
    return out


def summary(evs, label=""):
    n = len(evs)
    print(f"== {label}: n={n}")
    if not n:
        return
    for key in ("area", "tname", "who", "plat"):
        c = Counter(e[key] for e in evs)
        print(f"  {key}: " + ", ".join(f"{k}={v} ({100*v/n:.1f}%)" for k, v in c.most_common()))
    ds = sorted(e["d"] for e in evs)
    print(f"  first {ds[0]} last {ds[-1]}; distinct days {len(set(ds))}")
