import importlib, sys
sys.path.insert(0, '.')
import mk
for p in sys.argv[1:]:
    importlib.import_module(p)
mk.save()
