from mk import m

# N112.0 insta mornings. Facts: 4 Instagram opens, all 08:00 NY, Mon 12 to Thu 15 Oct 2026, wetpaper.ig Watercolor
# reels; Instagram ends 15 Oct.
m("N112.0", "jh8", "good", means="y", more="y", offer="n", note="true; 'posts' for reels is loose; 'And all?' vague")
m("N112.0", "o0m", "good", means="y", offer="y", lt=1, lu=0, note="true; small record and its end said")
m("N112.0", "oml", "good", means="y", more="y", offer="y", lt=1, lu=0, note="true")
m("N112.0", "ay3", "good", means="y", more="y", offer="y", lt=1, lu=0, note="true: 8 am, Monday to Thursday")

# A07.0 October channels without Shorts. Facts: 72 long YouTube videos in Oct: Pan Theory 32, Pixel Pencil 29, Brick Realm
# 6, Limit Lane 4, Wet Paper 1; Home cooking + Digital drawing 61 of 72.
m("A07.0", "y52", "good", more="y", offer="y", note="true")
m("A07.0", "mle", "good", means="y", more="y", offer="n", note="true; 'most' (61 of 72) right; 'Any length?' goes back")
m("A07.0", "os1", "acceptable", more="y", offer="n", note="true; 'the next row down' is system talk; 'By month?' on one month")
m("A07.0", "efk", "good", more="y", offer="y", note="true")

# B02.0 without gaming, 4 weeks. Facts: 66 opens; Art 32 (48%), Food 30 (45%, all Pan Theory Home cooking), Math 4;
# 4 weeks before (5 Sep-2 Oct): Art 78%, Food 5% -> +40 and -30 points.
m("B02.0", "p55", "good", means="y", more="y", offer="n", note="true; offer 'Only long videos?' useless without gaming")
m("B02.0", "wxa", "good", means="y", more="y", offer="y", note="true; repeats 'without gaming' a lot")
m("B02.0", "zjx", "good", more="y", offer="n", note="true; no reading")
m("B02.0", "z2q", "good", more="y", offer="n", note="true; no reading")

# B07.0 when did i start watercolor. Facts: first 10 Jan 2025 'Watercolor wet on wet #1' (Wet Paper); 95 opens (91 Wet
# Paper, 4 wetpaper.ig), last 21 Oct 2026.
m("B07.0", "my0", "acceptable", more="y", offer="y", note="true; 'all of them in its theme' is a tautology")
m("B07.0", "csy", "good", more="y", offer="y", note="true")
m("B07.0", "pnz", "good", more="y", offer="y", note="true")
m("B07.0", "e4b", "good", more="y", offer="y", note="true; 'all in art and design' adds little")

# C02.0 without Minecraft, 4 weeks. Facts: 125 opens; gaming 59 (47%) all Gaming clips, Clip Factory 56; Art 32 (26%);
# Pan Theory 30.
m("C02.0", "lon", "good", means="y", more="y", offer="y", note="true; Clip Factory 56 of the 59 gaming")
m("C02.0", "qem", "good", more="y", offer="y", note="true")
m("C02.0", "a2p", "good", means="y", more="y", offer="y", note="true; all gaming left is clips")
m("C02.0", "ecp", "good", more="y", offer="y", note="true")

# C06.0 gaming vs art this year. Facts 2026: 254 opens; art 133 (52%), gaming 79 (31%); of the two (212): 63% / 37%;
# Digital drawing 92 (Pixel Pencil), Gaming clips 66 of 79; 2025: art 54, gaming 0; 1 Jan-30 Oct = 303 days.
m("C06.0", "co0", "good", more="y", offer="y", note="true")
m("C06.0", "w21", "good", means="y", more="y", offer="y", note="true")
m("C06.0", "psm", "acceptable", more="y", offer="y",
  wb=[("This year up to 30 October 2026, art and design led gaming with 133 of the 212 videos you opened, 63% of what you opened.",
       "lenient", "212 is gaming plus art, not all you opened (254); base number and scope line beside it"),
      ("Gaming came next with 79 videos, 37% of what you opened.", "lenient",
       "37% is of the two areas, said 'of what you opened'; scope line names the two areas")],
  note="two-area base said as 'what you opened'")
m("C06.0", "mk7", "good", means="y", more="y", offer="y", lt=1, lu=0,
  note="true: 63/37 of the two areas, 2025 art 54 and no gaming, 303 days")

# D01.0 channels October. Facts: 142 opens; Clip Factory 61 (43%), Pan Theory 32 (Home cooking), Pixel Pencil 29
# (Digital drawing), Brick Realm 6.
m("D01.0", "nds", "good", more="y", offer="y", note="true")
m("D01.0", "f1c", "acceptable", more="y", offer="y", note="true; point repeats lead as 43%")
m("D01.0", "y7i", "good", more="y", offer="y", note="true; top three, no reading")
m("D01.0", "mg4", "good", more="y", offer="y", note="true")

# D01.1 and September. Facts: 44 opens; Pixel Pencil 31 (Digital drawing 70%), Brick Realm 7, Limit Lane 6.
m("D01.1", "lq4", "good", more="y", offer="n", note="true; 'And in October?' goes back to the turn before")
m("D01.1", "g9q", "good", more="y", offer="n", note="true; 'And in October?' goes back")
m("D01.1", "t3y", "good", more="y", offer="n", note="true; 70% repeats Pixel Pencil's share as a theme")
m("D01.1", "b5f", "good", more="y", offer="n", note="true; 'By month?' on one month")

# D07.0 30 October. Facts: 4 YouTube: 10:00 Digital drawing on the 30th (Pixel Pencil), 12:00 Gaming clip (Clip Factory,
# 40 s), 19:30 Digital art colour (Pixel Pencil), 21:00 Cooking soup (Pan Theory, 600 s); a Friday.
m("D07.0", "i12", "acceptable", more="y", offer="n", note="true; points repeat the cards' titles; 'Show some examples?' repeats the cards")
m("D07.0", "ak2", "good", more="y", offer="y", note="true; short and long said")
m("D07.0", "olk", "good", more="y", offer="n", note="true times; no cards but names all four")
m("D07.0", "eve", "good", more="y", offer="n", note="true; 'Show some examples?' repeats the cards")

# D07.1 the second one. Facts: by time and by the cards, 2nd = Gaming clip on the 30th (Clip Factory). qvg's own earlier
# answer had no cards and named Digital art colour second in its text (Gaming clip second by time and by point).
m("D07.1", "qvg", "acceptable", more="n",
  note="hard case: its own earlier text named 'Digital art colour' second (Pixel Pencil), though Gaming clip was second by time and in the second point; marked not false")
m("D07.1", "lrl", "acceptable", note="true; matches the cards it showed; bare")
m("D07.1", "sf7", "good", more="y", note="true; adds that it is a short")
m("D07.1", "eaf", "acceptable", note="true; bare")
