"""Helper: build mark records and save marks.json (reader3b)."""
import json
import os

OUT = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/reader3b/marks.json"
MARKS = []


def m(msg, code, grade, means="n", more="n", offer="n", answers="y", brief="y", false=(), wb=(), wrong_scope="n",
      limit_only="n", privacy="n", lt=0, lu=0, cause=None, note=""):
    """wb: list of (sentence, 'firm'|'lenient', why)."""
    MARKS.append(dict(
        message_id=msg, code=code, grade=grade, false_n=len(false), false_sentences=list(false),
        wb_firm_n=sum(1 for w in wb if w[1] == "firm"), wb_lenient_n=sum(1 for w in wb if w[1] == "lenient"),
        wb_sentences=[f"{w[1]}: {w[0]} -- {w[2]}" for w in wb], wrong_scope=wrong_scope, limit_only=limit_only,
        privacy_fault=privacy, answers=answers, means=means, more=more, offer=offer, brief=brief, limits_talk=lt,
        limits_unwanted=lu, poor_cause=cause if grade == "poor" else None, note=note))


def save():
    tmp = OUT + ".tmp"
    with open(tmp, "w") as f:
        json.dump(MARKS, f, indent=1)
    os.replace(tmp, OUT)
    print("saved", len(MARKS))
