from mk import m

# N004.0 gist of last few weeks vs summer. Facts: 4 wk 3-30 Oct = 130 opens (126 YT + 4 IG); summer Jun-Aug 2026 = 45,
# all Art (Pixel Pencil 32, Wet Paper 13); recent Gaming 64 (49%), Clip Factory 56, Art 32 (25%), Food 30 (23%) all Pan
# Theory, Digital drawing 27; Shorts 59 of 126 YT videos (47%).
m("N004.0", "c8i", "good", means="y", more="y", offer="y", note="all figures recount; says window lengths differ")
m("N004.0", "vv3", "good", means="y", more="y", offer="y", note="all figures recount")
m("N004.0", "bm9", "good", means="y", more="y", offer="y",
  note="47% Shorts = 59 of 126 YouTube videos; true on the YouTube base")
m("N004.0", "axj", "good", means="y", more="y", offer="y", note="all true; says compare shares, not counts")

# N016.0 first thing ever. Facts: Minecraft redstone door #1, Brick Realm, 5 Jan 2021 15:00 NY; 723 non-private opens.
m("N016.0", "wa7", "good", more="y", note="adds time 3:00 pm (true) and total 723 (true with private line)")
m("N016.0", "bgr", "acceptable", note="bare answer and card; nothing more")
m("N016.0", "x0n", "acceptable", note="bare answer; generic offer 'Show some examples?' adds nothing")
m("N016.0", "qdf", "acceptable", note="bare answer and card; nothing more")

# N017.0 who do i watch most. Facts: Brick Realm 163 of 723 (22.5%), Pixel Pencil 92 (all Digital drawing), Wet Paper 91
# (YouTube); Heart Notes 50 private, below anyway.
m("N017.0", "rgl", "good", more="y", offer="y", note="runner-up and themes named; 23% repeats lead as share")
m("N017.0", "ww5", "good", more="y", offer="y", note="theme and top three")
m("N017.0", "tx5", "good", more="y", offer="y", note="top three, true; no reading")
m("N017.0", "i1w", "acceptable", offer="y", note="point repeats lead as share (23%)")

# N017.1 and this year. Facts 2026: 254 opens; Pixel Pencil 92, Clip Factory 61, Wet Paper 37, Pan Theory 32, Brick
# Realm 13; no private rows in 2026; Pixel Pencil first 1 Aug 2026.
m("N017.1", "v34", "good", more="y", offer="y", note="true list of channels with runner-ups; no reading")
m("N017.1", "g1f", "good", more="y", offer="y", note="true list of channels with runner-ups; no reading")
m("N017.1", "z7c", "good", more="y", offer="y", note="same as v34: true runner-ups; no reading")
m("N017.1", "hc2", "good", means="y", more="y", offer="y", note="Pixel Pencil new this year, first 1 Aug 2026 (true)")

# N018.0 how much Frame Perfect. Facts: 90, all Speedruns, 35/41/14 in 2021-2023, first 1 Mar 2021, last 1 May 2023.
m("N018.0", "enq", "good", more="y", offer="y", note="all true")
m("N018.0", "hfg", "good", more="y", offer="y", note="all true")
m("N018.0", "c6j", "good", more="y", offer="y", note="all true")
m("N018.0", "gb3", "acceptable", more="y", offer="n", lt=1, lu=1,
  note="scope dates said twice (lead and scope line), 'where your export ends' not needed; offer 'And in 2022?' repeats the 41 just shown")

# N018.1 Brick Realm. Facts: 163, Minecraft builds, 91/59/0/0/0/13, first 5 Jan 2021, last 20 Oct 2026; evening
# (17-21h NY) 109 of 163 = 67%.
m("N018.1", "fyv", "good", more="y", offer="y", note="all true, by year shows the gap")
m("N018.1", "pu1", "good", more="y", offer="y", note="all true, by year shows the gap")
m("N018.1", "cj4", "good", more="y", offer="y", note="true but thin: no by-year, misses the 2023-2025 gap")
m("N018.1", "gen", "acceptable", more="y", offer="y",
  wb=[("Most opens came in the evening: 67% of what you opened.", "lenient",
       "67% is of Brick Realm's opens; said 'of what you opened' with the channel named in the scope line")],
  note="by year skips 2024-2025 zeros; evening share base clumsy")

# N019.0 new channels this fall. Facts: new in Sep-Oct: Clip Factory 61 and Gaming Daily 5 (both first 1 Oct, Gaming
# clips); wetpaper.ig 4 opens from 12 Oct; new handles with saves only: crumb.lab 2, noodle.nights 1 (friend excluded).
m("N019.0", "od6", "acceptable", more="y", offer="y",
  note="all true; 'below the floor for a new channel' is system talk")
m("N019.0", "rnl", "good", means="y", more="y", offer="n",
  note="'3 smaller new channels' true counting saves (wetpaper.ig, crumb.lab, noodle.nights); 'liked' in base is tool wording; offer 'Only long videos?' weak")
m("N019.0", "fxr", "acceptable", more="y", offer="y",
  wb=[("In the fall of 2026 up to 30 October 2026, 2 channels were new to you: Clip Factory with 61 videos and Gaming Daily with 5.",
       "lenient", "said as complete; wetpaper.ig (4 opens) and two save-only handles are also new, but a fair reader takes it as the real new channels")],
  note="list said as complete with smaller new accounts left out")
m("N019.0", "mj7", "good", more="y", offer="y", note="all true counting saves; names smaller new channels")

# N032.0 weekends. Facts: 723 non-private opens, weekend 202 (27.9%), Sat 101, Sun 101, Thu 108 busiest; evening
# 17-21h 69% on weekdays and weekends alike.
m("N032.0", "xx9", "good", means="y", more="y", offer="n", note="all true; 'By month?' generic here")
m("N032.0", "ubk", "good", means="y", more="y", offer="y", note="all true")
m("N032.0", "ynb", "good", means="y", more="y", offer="n", note="all true; 'By month?' generic here")
m("N032.0", "qqg", "good", means="y", more="y", offer="y", note="all true; 28% near 2/7 so 'even split' is right")

# N033.0 shorts in October. Facts: 66 YouTube Shorts (Clip Factory 61, Gaming Daily 5), all Gaming clips; 4 Instagram
# reels 12-15 Oct (Instagram ends 15 Oct).
m("N033.0", "ix4", "good", more="y", offer="n", note="all true; 'By month?' on one month")
m("N033.0", "ib8", "good", more="y", offer="y", note="all true")
m("N033.0", "qdc", "good", more="y", offer="n", lt=1, lu=0,
  note="all true; Instagram end is relevant to an October count; 'By month?' on one month")
m("N033.0", "b12", "good", more="y", offer="n", note="true, thin; offer 'Only long videos?' not useful")

# N033.1 is that more than usual. Facts: all 70 Shorts/reels fall in Oct 2026; none before. Oct 2026 all opens 142,
# Gaming clips 66 = 46% of the month (94% only of the Shorts and reels).
m("N033.1", "xa0", "good", means="y", more="y", offer="n", note="true; 'no usual' is the answer")
m("N033.1", "edx", "good", means="y", more="y", offer="y", note="true")
m("N033.1", "zwk", "good", means="y", more="y", offer="y", note="true")
m("N033.1", "p0y", "poor", means="y", more="y", offer="y",
  wb=[("Gaming clips is 94% of what you opened in that month.", "firm",
       "94% is of the 70 Shorts and reels; of all 142 October opens Gaming clips is 46%")],
  cause="wrongly based", note="filtered share said of the whole month")
