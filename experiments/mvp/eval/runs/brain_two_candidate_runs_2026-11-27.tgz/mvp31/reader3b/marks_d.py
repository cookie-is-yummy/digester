from mk import m

# D08.0 cooking this year. Facts 2026: 32 food and cooking opens, all Pan Theory Home cooking, on 26 days, evening 22
# (69%).
m("D08.0", "u51", "good", more="y", offer="y", note="true")
m("D08.0", "hf8", "good", more="y", offer="y", note="true; 69% evening right")
m("D08.0", "mbb", "good", more="y", offer="y", note="true; 26 days right")
m("D08.0", "fak", "good", more="y", offer="y", note="true")

# D08.1 wait i meant last year. Facts 2025: 8 cooking opens, all Pan Theory Home cooking, evening 5 (63%).
m("D08.1", "l2r", "acceptable", more="y", offer="y", note="true, corrected to 2025; '100% of what you opened in that scope' repeats")
m("D08.1", "x1o", "good", more="y", offer="y", note="true; 63% evening right")
m("D08.1", "cir", "good", more="y", offer="y", note="true; brief")
m("D08.1", "xbx", "acceptable", more="y", offer="y",
  note="true; garbled lead ('without anything else', 'all on YouTube of your videos'), 100% repeats")

# F11.0 biggest month ever. Facts: Oct 2026 142 (top, with or without private rows), next Jul 2023 52; Oct Shorts 66 of 142
# (46%), of 138 YouTube 48%, Shorts+reels 70 (49%).
m("F11.0", "yfl", "acceptable", more="y", offer="n", lt=1, lu=1,
  note="true; partial-month line not needed (it only strengthens the yes)")
m("F11.0", "ljf", "good", more="y", offer="n", note="true; 'By month?' fair but generic")
m("F11.0", "jt7", "acceptable", means="y", more="y", offer="n",
  wb=[("Almost half of October 2026's items were Shorts: 48% of what you opened that month.", "lenient",
       "48% is Shorts of the 138 YouTube videos; of the 142 items it is 46% (49% with reels); 'almost half' holds")],
  note="base slightly off")
m("F11.0", "et7", "acceptable", more="y", offer="n", lt=1, lu=1, note="true; end-of-history line not needed")

# F14.0 how much gaming daily stuff. Facts: Gaming Daily channel 5 Shorts, 1-5 Oct 2026; gaming area 319 (Minecraft 163 =
# 51%). The message names the channel; every lead answers the area.
NOTE14 = "lead answers the gaming area (319), not the Gaming Daily channel the message names; Gaming Daily's 5 only in a point"
m("F14.0", "rir", "poor", answers="n", wrong_scope="y", more="y", offer="y", cause="wrong scope",
  note=NOTE14 + "; its lead does point to Gaming Daily; figures true")
m("F14.0", "rgj", "poor", answers="n", wrong_scope="y", more="y", offer="n", cause="wrong scope", note=NOTE14 + "; figures true")
m("F14.0", "gc2", "poor", answers="n", wrong_scope="y", more="y", offer="y", cause="wrong scope", note=NOTE14 + "; figures true")
m("F14.0", "e9i", "poor", answers="n", wrong_scope="y", more="y", offer="n", cause="wrong scope", note=NOTE14 + "; figures true")

# I02.0 dating advice in 2024 (person named the private topic; unlocked this turn). Facts: 50 opens, all Heart Notes,
# 1 Feb-15 Aug 2024, 8 Feb ... 4 Aug, 7-8 a month, evening 34 (68%), 0 in 2023; 2024 non-private only 8.
m("I02.0", "jft", "good", more="y", offer="y", note="true; naming Heart Notes allowed in this turn")
m("I02.0", "xsa", "acceptable", more="y", offer="n", note="true; no yes or no in words; no offer")
m("I02.0", "vlv", "good", means="y", more="y", offer="y", note="true; 7 to 8 a month right")
m("I02.0", "gjx", "good", means="y", more="y", offer="y", note="true")

# I03.0 what else that year (2024). Facts: shown 8 Pan Theory Home cooking; 50 private; no saves at all in 2024 (the 3
# Home cooking saves are 5-10 Oct 2026).
m("I03.0", "r8p", "acceptable", offer="y", note="true with private line ('only' covered); 100% repeats")
m("I03.0", "n4u", "acceptable", offer="y", note="true with private line ('nothing else' covered); repeats")
m("I03.0", "e9g", "poor", more="y", offer="y",
  wb=[("You also saved 3 Home cooking posts that you never opened in 2024.", "firm",
       "the 3 Home cooking saves were made 5-10 October 2026; there are no saves in 2024")],
  cause="wrongly based", note="2026 saves said in a 2024 answer")
m("I03.0", "x4c", "acceptable", offer="y", note="true with private line; 100% of 100% repeats")

# K03.0 full picture of the year. Facts 2026: 254; themes Digital drawing 92, Gaming clips 66, Watercolor 41 (16%);
# channels Pixel Pencil 92, Clip Factory 61; new: Pixel Pencil / Digital drawing 1 Aug, Clip Factory / Gaming clips and
# Gaming Daily 1 Oct, wetpaper.ig 12 Oct; same stretch 2025: 52, Watercolor 45 (87%); nothing of 2025 stopped.
m("K03.0", "por", "good", means="y", more="y", offer="y", note="true; covers all four asks")
m("K03.0", "cf7", "good", means="y", more="y", offer="y", note="true; no total")
m("K03.0", "p5e", "poor", more="y", offer="y",
  wb=[("New this year: Clip Factory first opened 1 October 2026.", "firm",
       "list of what is new leaves out Pixel Pencil (top channel, first 1 Aug 2026) and Digital drawing")],
  cause="wrongly based", note="'what's new' said as Clip Factory alone")
m("K03.0", "wxb", "good", means="y", more="y", offer="y", note="true; clumsy 'where' clause")

# K04.0 what have i learned about calculus. Facts: 0 calculus saves; 85 calculus opens (Limit Lane: limits, derivatives,
# integrals by parts, chain rule; summer 2023 and Sep 2026). Rows hold what they watched on it.
m("K04.0", "rv3", "poor", answers="n", limit_only="y", offer="y", lt=1, lu=0, cause="limit only",
  note="true that nothing is saved, but the 85 opened calculus videos hold an answer")
m("K04.0", "lnm", "poor", answers="n", limit_only="y", offer="y", lt=1, lu=0, cause="limit only",
  note="true; points at opens but gives nothing from them")
m("K04.0", "zic", "poor", answers="n", more="y", offer="y", lt=1, lu=0, cause="thin",
  note="true (85 opened, 0 saved); bare count, no topics; no guess at what was learned")
m("K04.0", "s66", "poor", answers="n", limit_only="y", offer="y", lt=1, lu=0, cause="limit only",
  note="true but says only what it cannot report")
