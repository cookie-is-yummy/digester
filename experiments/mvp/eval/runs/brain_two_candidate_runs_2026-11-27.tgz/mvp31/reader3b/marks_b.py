from mk import m

# N035.0 insta or youtube. Facts: opens 719 YT / 4 IG (723); items incl. saves and playlist 722 YT / 7 IG (729, friend
# out); Instagram rows only 5-15 Oct 2026 (ends 15 Oct), YouTube from 5 Jan 2021.
m("N035.0", "drr", "good", means="y", more="n", offer="n", lt=1, lu=0,
  note="true; Instagram end said, relevant to the comparison; 'By month?' generic")
m("N035.0", "cl5", "acceptable", means="n", offer="y", lt=1, lu=0,
  note="true counts but never says which is used more in words; no reading")
m("N035.0", "mo6", "acceptable", means="y", more="y", offer="n",
  note="true (729 items incl. saves); does not say Instagram record covers only a few October days, so 'far more' leans on it; 'liked' is tool wording")
m("N035.0", "a0k", "acceptable", means="y", offer="y",
  note="true; Instagram's short record not said; second point heavy base wording")

# N035.1 what do i watch on insta. Facts: 4 opens, all Watercolor painting reels from wetpaper.ig, 12-15 Oct 2026, 08:00;
# Instagram also holds 3 saves (5, 6, 10 Oct) + a friend's post 9 Oct; 3 Wet Paper YouTube playlist adds.
m("N035.1", "iq7", "acceptable", means="y", offer="n", lt=1, lu=0,
  note="true; third point repeats the lead (100% art); offer 'And in October?' repeats the window")
m("N035.1", "fqi", "acceptable", means="n", more="y", offer="n", lt=1, lu=0,
  note="true; second point repeats lead as 100%; adds the 3 saved watercolor videos")
m("N035.1", "l5b", "poor", means="n", offer="y", lt=1, lu=0,
  wb=[("Your Instagram export only covers 12 to 15 October 2026, and in that time you opened 4 reels, all of them Watercolor painting.",
       "firm", "12-15 Oct is the span of the opens, said as the export's span; the Instagram record also holds saves on 5, 6 and 10 October")],
  cause="wrongly based", note="real span said of the wrong base (the export)")
m("N035.1", "lj4", "acceptable", offer="n", note="true, bare")

# N038.0 liked recently. Facts: no likes in the export; 4 wk to 30 Oct: 6 saves (3 Wet Paper playlist 3-5 Oct, 2 crumb.lab
# 5-6 Oct, 1 noodle.nights 10 Oct); a 7th is a friend's post (in no total).
m("N038.0", "zw7", "good", more="y", offer="y", lt=1, lu=0, note="true; no-likes limit is the point of the question")
m("N038.0", "crb", "good", more="y", offer="y", lt=1, lu=0, note="true; three cards")
m("N038.0", "u07", "acceptable", more="n", offer="y", lt=1, lu=0,
  note="true but counts only for a 'what' question, no item shown; '3 and 3' flat")
m("N038.0", "uwy", "good", more="y", offer="y", lt=1, lu=0, note="true; three cards")

# N048.0 find the sourdough starter post. Facts: rx_sour1 crumb.lab saved 5 Oct 2026; rx_sour2 saved 6 Oct.
m("N048.0", "loj", "good", more="y", note="right post first, second one named")
m("N048.0", "nh3", "acceptable", note="bare 'Here's what I found.' lead; the cards do answer")
m("N048.0", "gre", "acceptable", note="bare 'Here's what I found.' lead; the cards do answer")
m("N048.0", "bg1", "good", more="y", note="right post first, second one named")

# N048.1 what did it say about flour. Facts: caption 'feed 50 g flour and 50 g water, wait 12 hours'; only item with flour.
m("N048.1", "qxk", "good", more="y", note="true paraphrase (equal weights, then wait); amounts not given")
m("N048.1", "ayl", "acceptable", note="true paraphrase, thin; no card")
m("N048.1", "an1", "acceptable", note="true; gives only the truncated title, no reading of it")
m("N048.1", "dbp", "good", more="y", offer="n", note="true; paraphrase plus source")

# N052.0 spring 2024. Facts: 26 opens, 23 private (Heart Notes); shown 3 Pan Theory Home cooking (2 Mar Sat 16:00, 16 Apr
# Tue 18:00, 31 May Fri 19:00).
m("N052.0", "stf", "acceptable", offer="y", note="true with private line; point repeats lead as 100%")
m("N052.0", "dkh", "acceptable", offer="y", note="true with private line; flat")
m("N052.0", "drw", "good", more="y", offer="y", note="true with private line ('100%' covered); adds times")
m("N052.0", "fm0", "acceptable", offer="y", note="true with private line; 'Home cooking 100% of food and cooking' is a tautology")

# N052.1 why is so much missing. Facts: spring 2024 23 private items; 50 private in all; friend's post is Oct 2026;
# 729 non-private items in all.
m("N052.1", "m3m", "poor", means="y", offer="y", lt=2, lu=1,
  wb=[("Most of the gap is private topics: 50 items sit in topics you keep private, so they are left out of every count here.",
       "firm", "50 is the all-history private count; spring 2024 holds 23"),
      ("1 item is a friend's post, in no total and never shown.", "lenient",
       "true, but the friend's post is October 2026, not part of the spring gap")],
  cause="wrongly based", note="answers why, but with the wrong period's figure")
m("N052.1", "zph", "good", means="y", offer="n", lt=1, lu=0, note="true; 23 private in spring 2024")
m("N052.1", "byu", "good", means="y", more="y", offer="n", lt=1, lu=0, note="true; one a month is right")
m("N052.1", "ic3", "good", means="y", offer="y", lt=1, lu=0, note="true")

# N054.0 list everything March 2024. Facts: 8 opens: 1 shown (Cooking tofu three ways #26, Pan Theory, Sat 2 Mar 16:00,
# 600 s), 7 private.
m("N054.0", "a7v", "poor", offer="y",
  false=["In March 2024 you opened 1 video that is in this list: Cooking tofu three ways #26."],
  cause="wrong fact", note="no private line; 7 private opens hidden, so '1 video' is false by the convention")
m("N054.0", "kre", "good", more="y", offer="y", note="true with private line ('100%' covered)")
m("N054.0", "xhi", "good", more="y", offer="y", note="true: long video, Saturday afternoon")
m("N054.0", "uwo", "acceptable", offer="y", note="true with private line, bare")

# N057.0 minutes of YouTube a day. Facts: watch time not recorded but video lengths are in the library: 4 wk 3-30 Oct, 126
# YouTube videos on 28 days (4.5/day), 1,114 minutes of official length, about 40 minutes a day if watched through.
NOTE57 = "no row records time watched; lengths are in the library, so a ceiling estimate (about 40 min a day of video length) was possible but not given"
m("N057.0", "jtj", "acceptable", more="y", offer="n", lt=1, lu=0, note=NOTE57 + "; gives 4.5 videos a day as the substitute")
m("N057.0", "zy8", "poor", answers="n", more="y", offer="n", lt=1, lu=0, cause="misses the question",
  note=NOTE57 + "; gives no per-day figure at all (126 on 28 days)")
m("N057.0", "d5s", "acceptable", more="y", offer="n", lt=1, lu=0,
  note=NOTE57 + "; gives 4.5 videos a day; evening 89 of 126 true (17-21h)")
m("N057.0", "mty", "poor", answers="n", more="y", offer="n", lt=2, lu=1, cause="misses the question",
  note=NOTE57 + "; gives no per-day figure at all (126 on 28 days)")

# N068.0 dinner ideas in saves. Facts: only rx_pasta (noodle.nights, 10 Oct) is a dinner save; the friend's save is a
# beach post.
m("N068.0", "cne", "acceptable", lt=1, lu=1, note="true; 'not a full list' hedge not needed")
m("N068.0", "pl1", "poor", lt=1, lu=1, privacy="y",
  wb=[("Your export holds 1 friend's post of this kind, which is in no total and never shown.", "firm",
       "gives the friend's post a topic (dinner ideas); the friend's post is a beach post")],
  cause="wrongly based", note="privacy: says what kind the friend's post is ('of this kind')")
m("N068.0", "yw5", "acceptable", lt=1, lu=1, note="true; search-method hedge is system talk")
m("N068.0", "vh3", "acceptable", note="true, bare")
