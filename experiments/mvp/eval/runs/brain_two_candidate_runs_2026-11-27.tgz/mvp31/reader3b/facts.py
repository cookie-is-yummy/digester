"""reader3b facts: per-message counts from the library rows only (no brain tools). Writes facts.txt."""
import io
import sys
from contextlib import redirect_stdout

sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/reader3b")
from lib import EV, ROWS, Counter, sel, summary  # noqa: E402

OUT = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/reader3b/facts.txt"
EVE = lambda e: 17 <= e["t"].hour < 21  # evening, 17:00-21:00 New York (matches the tool's shares)
SHORT = lambda e: e["plat"] == "youtube" and e["length"] is not None and e["length"] <= 60
B = {}


def block(key):
    def deco(fn):
        B[key] = fn
        return fn
    return deco


def months(evs):
    return sorted(Counter(e["d"].strftime("%Y-%m") for e in evs).items())


@block("N004.0")
def _():
    summary(sel(start="2026-10-03", end="2026-10-30"), "4 weeks 3-30 Oct 2026")
    summary(sel(start="2026-06-01", end="2026-08-31"), "summer Jun-Aug 2026 (92 days)")
    y = sel(start="2026-10-03", end="2026-10-30", plat="youtube")
    print("  Shorts in 4 wk:", sum(map(SHORT, y)), "of", len(y), "YouTube videos")


@block("N016.0")
def _():
    e = min(sel(), key=lambda e: e["t"])
    print("first open:", e["t"], e["cap"], e["who"], "| non-private opens", len(sel(private=False)))


@block("N017.0")
def _():
    summary(sel(), "all opens incl private")
    print("  non-private opens", len(sel(private=False)))


@block("N017.1")
def _():
    summary(sel(start="2026-01-01"), "2026")
    print("  private rows in 2026:", len(sel(start="2026-01-01", private=True)))


@block("N018.0")
def _():
    x = [e for e in sel() if e["who"] == "Frame Perfect"]
    print("Frame Perfect", len(x), sorted(Counter(e["d"].year for e in x).items()), min(e["d"] for e in x),
          max(e["d"] for e in x), Counter(e["tname"] for e in x))


@block("N018.1")
def _():
    x = [e for e in sel() if e["who"] == "Brick Realm"]
    print("Brick Realm", len(x), sorted(Counter(e["d"].year for e in x).items()), min(e["d"] for e in x),
          max(e["d"] for e in x), "evening", sum(map(EVE, x)))


@block("N019.0")
def _():
    first = {}
    for e in sorted([e for e in EV if not e["friend"]], key=lambda e: e["t"]):
        first.setdefault(e["who"], (e["d"], e["kind"]))
    print("first event per channel/handle:", first)
    print("  fall opens by who (1 Sep-30 Oct):", Counter(e["who"] for e in sel(start="2026-09-01")).most_common())


@block("N032.0")
def _():
    a = sel(private=False)
    wd = Counter(e["d"].strftime("%a") for e in a)
    we = [e for e in a if e["d"].weekday() >= 5]
    print("non-private", len(a), dict(wd), "weekend", len(we), round(100 * len(we) / len(a), 1), "%")
    print("  evening share weekend", round(100 * sum(map(EVE, we)) / len(we), 1),
          "weekday", round(100 * sum(map(EVE, [e for e in a if e['d'].weekday() < 5])) / (len(a) - len(we)), 1),
          "all", round(100 * sum(map(EVE, a)) / len(a), 1))


@block("N033.0")
def _():
    o = sel(start="2026-10-01", end="2026-10-31")
    s = [e for e in o if SHORT(e)]
    print("Oct opens", len(o), "Shorts", len(s), Counter(e["who"] for e in s), "IG reels", len(sel(start="2026-10-01", plat="instagram")))


@block("N033.1")
def _():
    s = [e for e in sel() if SHORT(e)]
    print("all Shorts by month", months(s), "| Oct all opens 142; Gaming clips in Oct", sum(1 for e in sel(start='2026-10-01') if e['tname'] == 'Gaming clips'))


@block("N035.0")
def _():
    print("opens by platform", Counter(e["plat"] for e in sel(private=False)))
    items = {(e["id"], e["plat"]) for e in EV if not e["friend"] and not e["private"]}
    print("  items incl saves/playlist by platform", Counter(p for _, p in items))
    ig = [e for e in EV if e["plat"] == "instagram"]
    print("  Instagram events span", min(e["d"] for e in ig), "to", max(e["d"] for e in ig))


@block("N035.1")
def _():
    for e in [e for e in EV if e["plat"] == "instagram"]:
        print("  IG", e["kind"], e["t"], e["who"], e["tname"], "friend" if e["friend"] else "")


@block("N038.0")
def _():
    print("likes in export:", sum(1 for e in EV if e["kind"] == "like"))
    for e in [e for e in EV if e["kind"] in ("save", "playlist")]:
        print("  ", e["kind"], e["d"], e["who"], e["tname"], "FRIEND" if e["friend"] else "", e["cap"][:40])


@block("N048.0")
def _():
    for r in ROWS:
        if "sourdough" in r["caption"].lower():
            print("  ", r["id"], r["handle"], r["events"], r["caption"])


@block("N048.1")
def _():
    print("items with 'flour':", [(r["id"], r["caption"]) for r in ROWS if "flour" in r["caption"].lower()])


@block("N052.0")
def _():
    summary(sel(start="2024-03-01", end="2024-05-31"), "spring 2024 incl private")
    for e in sel(start="2024-03-01", end="2024-05-31", private=False):
        print("  ", e["t"], e["t"].strftime("%a"), e["cap"], e["who"])


@block("N052.1")
def _():
    print("private in spring 2024", len(sel(start="2024-03-01", end="2024-05-31", private=True)),
          "| private all", len(sel(private=True)), "| friend post date", [e["d"] for e in EV if e["friend"]])


@block("N054.0")
def _():
    for e in sel(start="2024-03-01", end="2024-03-31"):
        print("  ", e["t"], e["t"].strftime("%a"), e["cap"] if not e["private"] else "(private row)", e["length"])


@block("N057.0")
def _():
    y = sel(start="2026-10-03", end="2026-10-30", plat="youtube")
    mins = sum(e["length"] or 0 for e in y) / 60
    print("4 wk YouTube", len(y), "videos on", len({e['d'] for e in y}), "days =", round(len(y) / 28, 2), "a day;",
          "official length", round(mins), "min =", round(mins / 28, 1), "min a day; evening", sum(map(EVE, y)),
          "Shorts", sum(map(SHORT, y)), "Clip Factory", sum(1 for e in y if e['who'] == 'Clip Factory'))
    print("  no row records time watched")


@block("N068.0")
def _():
    for e in [e for e in EV if e["kind"] == "save"]:
        print("  save", e["d"], e["who"], "FRIEND" if e["friend"] else "", e["cap"][:60])


@block("N112.0")
def _():
    for e in sel(plat="instagram"):
        print("  IG open", e["t"], e["t"].strftime("%a"))


@block("A07.0")
def _():
    o = [e for e in sel(start="2026-10-01", plat="youtube") if not SHORT(e)]
    print("Oct long YouTube videos", len(o), Counter(e["who"] for e in o).most_common(), Counter(e["tname"] for e in o).most_common())


@block("B02.0")
def _():
    ng = lambda e: e["area"] != "Gaming"
    summary(sel(start="2026-10-03", end="2026-10-30", f=ng), "4 wk without gaming")
    summary(sel(start="2026-09-05", end="2026-10-02", f=ng), "4 wk before, without gaming")


@block("B07.0")
def _():
    w = sorted([e for e in sel() if e["theme"] == "wc"], key=lambda e: e["t"])
    print("watercolor opens", len(w), "first", w[0]["d"], w[0]["cap"], w[0]["who"], "last", w[-1]["d"],
          Counter(e["who"] for e in w))


@block("C02.0")
def _():
    nm = lambda e: e["tname"] != "Minecraft builds"
    summary(sel(start="2026-10-03", end="2026-10-30", f=nm), "4 wk without Minecraft builds")


@block("C06.0")
def _():
    a = sel(start="2026-01-01")
    g = [e for e in a if e["area"] in ("Gaming", "Art and design")]
    print("2026 opens", len(a), Counter(e["area"] for e in a), "| gaming+art", len(g))
    print("  2026 gaming themes", Counter(e["tname"] for e in a if e["area"] == "Gaming"), "art themes",
          Counter(e["tname"] for e in a if e["area"] == "Art and design"))
    b = sel(start="2025-01-01", end="2025-12-31")
    print("  2025 opens", len(b), Counter(e["area"] for e in b))


@block("D01.0")
def _():
    summary(sel(start="2026-10-01", end="2026-10-31"), "October 2026")


@block("D01.1")
def _():
    summary(sel(start="2026-09-01", end="2026-09-30"), "September 2026")


@block("D07.0")
def _():
    for e in sorted(sel(start="2026-10-30", end="2026-10-30"), key=lambda e: e["t"]):
        print("  ", e["t"], e["cap"], e["who"], e["tname"], e["length"])


@block("D07.1")
def _():
    print("by time, the 2nd video of 30 Oct is 'Gaming clip on the 30th' (Clip Factory); in text order of one bot's"
          " earlier answer the 2nd named is 'Digital art colour on the 30th' (Pixel Pencil)")


@block("D08.0")
def _():
    c = [e for e in sel(start="2026-01-01") if e["area"] == "Food and cooking"]
    print("2026 cooking", len(c), Counter(e["who"] for e in c), "days", len({e['d'] for e in c}), "evening", sum(map(EVE, c)))


@block("D08.1")
def _():
    c = [e for e in sel(start="2025-01-01", end="2025-12-31") if e["area"] == "Food and cooking"]
    print("2025 cooking", len(c), Counter(e["who"] for e in c), "evening", sum(map(EVE, c)))


@block("F11.0")
def _():
    a = sel(private=False)
    print("top months non-private", Counter(e["d"].strftime("%Y-%m") for e in a).most_common(4))
    print("top months incl private", Counter(e["d"].strftime("%Y-%m") for e in sel()).most_common(4))
    o = sel(start="2026-10-01")
    print("  Oct Shorts", sum(map(SHORT, o)), "of", len(o))


@block("F14.0")
def _():
    g = [e for e in sel() if e["area"] == "Gaming"]
    print("gaming all", len(g), Counter(e["tname"] for e in g), "| Gaming Daily", [str(e['d']) for e in g if e['who'] == 'Gaming Daily'])


@block("I02.0")
def _():
    d = sel(private=True)
    print("dating advice (private) opens", len(d), Counter(e["d"].year for e in d), months(d), min(e['d'] for e in d),
          max(e['d'] for e in d), "evening", sum(map(EVE, d)))


@block("I03.0")
def _():
    summary(sel(start="2024-01-01", end="2024-12-31"), "2024 incl private")
    print("  saves in 2024:", [e for e in EV if e["kind"] == "save" and e["d"].year == 2024])


@block("K03.0")
def _():
    a = sel(start="2026-01-01")
    summary(a, "2026")
    b = sel(start="2025-01-01", end="2025-10-30")
    summary(b, "same stretch 2025 (1 Jan-30 Oct)")
    first = {}
    for e in sorted(sel(), key=lambda e: e["t"]):
        first.setdefault(e["tname"], e["d"])
    print("  first open per theme", first)


@block("K04.0")
def _():
    c = [e for e in sel() if e["tname"] == "Calculus lessons"]
    print("calculus opens", len(c), "saves on calculus", sum(1 for e in EV if e['kind'] != 'watch' and e['tname'] == 'Calculus lessons'))


if __name__ == "__main__":
    import json
    pk = json.load(open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group3.json"))
    buf = io.StringIO()
    with redirect_stdout(buf):
        for x in pk["messages"]:
            print("#" * 8, x["key"], "|", x["message"])
            B.get(x["key"], lambda: print("(no block)"))()
            print()
    open(OUT, "w").write(buf.getvalue())
    print(buf.getvalue())
