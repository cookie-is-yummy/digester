"""Consistency pass after the advisor's review: one rule per test, applied to every code."""
from mk import MARKS

R = {(r["message_id"], r["code"]): r for r in MARKS}


def wb(key, sent, kind, why, grade=None, note=None):
    r = R[key]
    r["wb_sentences"].append(f"{kind}: {sent} -- {why}")
    r["wb_lenient_n" if kind == "lenient" else "wb_firm_n"] += 1
    if grade:
        r["grade"] = grade
    if note:
        r["note"] += "; " + note


# Shares on a narrower base (same rule as F11.0 jt7): lenient.
wb(("N004.0", "bm9"), "Food and cooking reached 23% of what you opened, through Pan Theory; 47% of the recent videos were Shorts.",
   "lenient", "47% is Shorts of the 126 YouTube videos; of the 130 items in the lead it is 45%", "acceptable")
# Filtered share said 'of what you opened' with no base in the sentence (same rule as N018.1 gen, C06.0 psm): lenient.
wb(("B02.0", "z2q"), "Food and cooking came next with 30 videos, 45% of what you opened.", "lenient",
   "45% is of the 66 opened without gaming; the sentence says 'of what you opened', the scope line names the filter",
   "acceptable")
# 'What's new' lists: leaving out the largest new channel is firm (K03.0 p5e); leaving out only small new accounts
# (5 items or fewer) is lenient (N019.0 fxr, K03.0 por).
wb(("K03.0", "por"), "New this year: Pixel Pencil first opened on 1 August 2026 and Clip Factory on 1 October 2026.", "lenient",
   "said as the list of what is new; Gaming Daily (5) and wetpaper.ig (4) are new too, small", "acceptable")

# F14.0: the scope line says 'only gaming (area)', so the scope is said; the lead still misses the channel asked about.
for c in ("rir", "rgj", "gc2", "e9i"):
    R[("F14.0", c)]["wrong_scope"] = "n"
    R[("F14.0", c)]["poor_cause"] = "misses the question"

# Limits talk: one rule (a sentence on the export's end, what it holds or records, or private rows left out).
R[("N004.0", "vv3")]["limits_talk"] = R[("N004.0", "bm9")]["limits_talk"] = R[("N004.0", "axj")]["limits_talk"] = 1
R[("N057.0", "mty")]["limits_unwanted"] = 0   # same as N004.0: the export end explains the 4-week window
R[("N052.1", "byu")]["limits_talk"] = 2
R[("N112.0", "jh8")]["limits_talk"] = 1

# brief = n where the answer repeats itself, holds a tautology, system talk, a scope said twice or garbled words.
for k in [("N018.0", "gb3"), ("N017.0", "i1w"), ("N019.0", "od6"), ("N035.1", "iq7"), ("N035.1", "fqi"), ("N052.0", "stf"),
          ("N052.0", "fm0"), ("A07.0", "os1"), ("B07.0", "my0"), ("D01.0", "f1c"), ("D07.0", "i12"), ("D08.1", "l2r"),
          ("D08.1", "xbx"), ("I03.0", "r8p"), ("I03.0", "n4u"), ("I03.0", "x4c"), ("N068.0", "yw5"), ("N068.0", "cne")]:
    R[k]["brief"] = "n"
