# reader2a progress
- Read brief_mark.md, rubric, decisions_section.md, library (brain_library.py + r12_library.py).
- Packet group2: 40 messages x 4 answers = 160.
- Next: facts script -> reader2a/facts.txt, then mark in batches of 10 into reader2a/marks.json.
- facts.py -> reader2a/facts.txt (rerun as batches are added). marks via reader2a/build_marks.py (upsert, all 20 fields).

## Fixed rules (apply mechanically)
- Offers: "Without gaming?" y when gaming leads the answer. "By month?" y on a window of a few months to a year,
  n on all history (6 years), a single month or shorter. "Show some examples?" y when a theme/channel is named
  (n when the answer already lists the examples). "Only long videos?" n when already long-only. Other offers judged
  once and noted.
- Means: a rank or a share list alone = n. y when a sentence gives a reading: one channel is all/most of it,
  a change/new/dropped/came back, "the only one every year", a plain conclusion that follows from the figures.
- Bare true answer to a simple lookup (a date, a last item) with nothing more = acceptable; with a bit more = good.
- Hesitation between grades: take the lower, say why.
- Empty answer: poor, bare fallback.
- Theme rank said "came next" over a higher theme, area not named beside it = firm; area named beside = lenient.
- Batch 1 (msgs 1-10) marked and saved. Extra rules: any lenient -> at most acceptable; offer n -> at most acceptable.
- Batch 2 (msgs 11-20) marked and saved.
- Batch 3 (msgs 21-30) marked and saved.
- Batch 4 (msgs 31-40) marked and saved. All 160 marked; next: consistency checks.
- Checks done: 160/160 codes marked; the one identical pair (F03.0 pry/p2d) marked alike; no flagged sentence left unflagged in a twin; offers marked by the fixed rule.
- Done. Hard cases: N005.0 ecz/a14, N034.0 zrz/s0m, N053.0 rnp, N053.1 (Heart Notes in follow-up), N069.0 ijg/t4i, N109/N113 save window, N113 'like', B14.0 ccu, A03.0 b1f, D10.1 t3s.
- Consistency pass after review: means rule tightened (a theme's own channel 'all from X' is detail, not a reading; 61 of 142 is not 'most'); lrh and f03 cleared; j6g, vk4, maz lenient; N053.1 privacy_fault y on all four by the letter (h7l capped at acceptable); brief and limit counts patched (batch_99_patch.py). Twin check rerun clean.
- FINAL: 160 marked: good 62, acceptable 84, poor 14 (false 5, firm 9, lenient 11, privacy 4). 19 acceptables rest only on the offer rule.
