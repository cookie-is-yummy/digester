"""Own facts from the made-up library rows (brain_library.rows), New York dates. Not the brain tools."""
import sys, collections, re
from datetime import datetime, date
from zoneinfo import ZoneInfo
sys.path.insert(0, '/home/user/digester/experiments')
from mvp.tests import brain_library as BL
NY = ZoneInfo('America/New_York')
AREA = {'mc': 'gaming', 'sr': 'gaming', 'cl': 'gaming', 'wc': 'art', 'dd': 'art', 'ca': 'math', 'np': 'math', 'co': 'food', 'da': 'dating'}
THEME = {'mc': 'Minecraft builds', 'sr': 'Speedruns', 'cl': 'Gaming clips', 'wc': 'Watercolor painting', 'dd': 'Digital drawing',
         'ca': 'Calculus lessons', 'np': 'Number puzzles', 'co': 'Home cooking', 'da': 'Dating advice'}
EV = []
for r in BL.rows():
    for k, at in r['events']:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r['id'], kind=k, t=t, d=t.date(), plat=r['platform'], ch=r.get('channel') or '@' + r.get('handle', ''),
                       theme=r['theme'], area=AREA[r['theme']], title=r['caption'], length=r['length'], friend=bool(r.get('friend')),
                       private=r['theme'] == 'da'))
def sel(kind='watch', a=None, b=None, priv=False, friend=False, **kw):
    out = []
    for e in EV:
        if kind and e['kind'] not in (kind if isinstance(kind, tuple) else (kind,)): continue
        if a and e['d'] < a: continue
        if b and e['d'] > b: continue
        if not priv and e['private']: continue
        if not friend and e['friend']: continue
        if any(e[k] != v for k, v in kw.items()): continue
        out.append(e)
    return out
C = collections.Counter
def stem(t): return re.sub(r'\s*#\d+$', '', t)
D = date
def yr(y): return D(y, 1, 1), D(y, 12, 31)
def short(e): return (e['length'] is not None and e['length'] <= 60) or e['plat'] == 'instagram'
if __name__ == '__main__':
    p = print
    W1, W0 = (D(2026, 10, 3), D(2026, 10, 30)), (D(2026, 9, 5), D(2026, 10, 2))
    w1 = sel(a=W1[0], b=W1[1]); w0 = sel(a=W0[0], b=W0[1])
    p('A03/D10/N001: 3-30 Oct opened', len(w1), 'themes', C(e['theme'] for e in w1), 'areas', C(e['area'] for e in w1))
    p('   without gaming themes', C(e['theme'] for e in w1 if e['area'] != 'gaming'), sum(1 for e in w1 if e['area'] != 'gaming'))
    p('   5 Sep-2 Oct', len(w0), C(e['theme'] for e in w0), C(e['area'] for e in w0))
    wc = sel(theme='wc'); p('   watercolor before 5 Sep 2026', sum(1 for e in wc if e['d'] < W0[0]), 'last before window', max(e['d'] for e in wc if e['d'] < W0[0]))
    al = sel(); p('B14: all opened non-private', len(al), 'shorts(yt<=60)', sum(1 for e in al if e['plat']=='youtube' and e['length'] and e['length']<=60),
      'long>60', sum(1 for e in al if e['length'] and e['length']>60), 'no length yt', sum(1 for e in al if e['plat']=='youtube' and e['length'] is None), 'ig', sum(1 for e in al if e['plat']=='instagram'))
    p('   shorts by year', C(e['d'].year for e in al if e['plat']=='youtube' and e['length'] and e['length']<=60), '2026 opened', len(sel(a=D(2026,1,1))))
    p('   shorts/reels by month', C((e['d'].year, e['d'].month) for e in al if short(e)))
    for y in (2024, 2025, 2026):
        p(f'E04/K03 {y} channels', C(e['ch'] for e in sel(a=D(y,1,1), b=D(y,10,30))), 'themes', C(e['theme'] for e in sel(a=D(y,1,1), b=D(y,10,30))))
    p('   Wet Paper 2026 opens', len(sel(a=D(2026,1,1), ch='Wet Paper')), 'any event', len(sel(kind=None, a=D(2026,1,1), ch='Wet Paper')), '2025 1 Jan-30 Oct', len(sel(a=D(2025,1,1), b=D(2025,10,30), ch='Wet Paper')), 'all 2025', len(sel(a=D(2025,1,1), b=D(2025,12,31), ch='Wet Paper')))
    o26 = sel(a=D(2026,1,1)); p('   2026 opened', len(o26), 'watercolor', sum(1 for e in o26 if e['theme']=='wc'), 'any event', len(sel(kind=None, a=D(2026,1,1))), 'wc any', len(sel(kind=None, a=D(2026,1,1), theme='wc')))
    o25 = sel(a=D(2025,1,1), b=D(2025,12,31)); p('   2025 opened', len(o25), 'wc', sum(1 for e in o25 if e['theme']=='wc'))
    first = {}; firstt = {}
    for e in sorted(sel(), key=lambda e: e['t']): first.setdefault(e['ch'], e['d']); firstt.setdefault(e['theme'], e['d'])
    p('   first opened per channel', sorted(first.items(), key=lambda x: x[1]))
    p('   first opened per theme', sorted(firstt.items(), key=lambda x: x[1]))
    last = {}
    for e in sel(): last[e['ch']] = max(last.get(e['ch'], e['d']), e['d'])
    p('   last opened per channel', sorted(last.items(), key=lambda x: x[1]))
    g = sel(area='gaming'); p('F06: gaming all', len(g), 'Feb 2026', len(sel(area='gaming', a=D(2026,2,1), b=D(2026,2,28))), 'Sep 2026', len(sel(area='gaming', a=D(2026,9,1), b=D(2026,9,30))), 'before Sep 2026', sum(1 for e in g if e['d'] < D(2026,9,1)), 'before Feb 2026', sum(1 for e in g if e['d'] < D(2026,2,1)))
    p('   gaming 3-30 Oct', len(sel(area='gaming', a=W1[0], b=W1[1])), '5 Sep-2 Oct', len(sel(area='gaming', a=W0[0], b=W0[1])), 'gaming by month 2026', sorted(C(e['d'].month for e in g if e['d'].year == 2026).items()))
    p('   gaming daily', len(sel(ch='Gaming Daily')), 'gaming themes all', C(e['theme'] for e in g))
    sv = sel(kind=('save', 'playlist'), friend=True); p('I03/N109/N113 saves', [(e['id'], e['kind'], e['ch'], str(e['d']), e['friend'], e['theme']) for e in sv])
    for y in range(2021, 2027):
        p(f'N005 {y}', 'Brick Realm', len(sel(ch='Brick Realm', a=D(y,1,1), b=D(y,12,31))), 'Pan Theory', len(sel(ch='Pan Theory', a=D(y,1,1), b=D(y,12,31))), 'non-private', len(sel(a=D(y,1,1), b=D(y,12,31))), 'with private', len(sel(a=D(y,1,1), b=D(y,12,31), priv=True)))
    oc = sel(a=D(2026,10,1), b=D(2026,10,31)); p('N033: Oct 2026 opened', len(oc), 'short items', sum(1 for e in oc if short(e)), 'gaming clips', sum(1 for e in oc if e['theme']=='cl'), 'clip factory', sum(1 for e in oc if e['ch']=='Clip Factory'))
    lg = [e for e in o26 if e['length'] and e['length'] > 60]; p('N034: 2026 long', len(lg), C(e['theme'] for e in lg), C(e['area'] for e in lg))
    sp = sel(theme='ca', a=D(2026,9,1), b=D(2026,9,30)); p('N045: Sep 2026 calculus', [(e['title'], str(e['d']), e['ch']) for e in sorted(sp, key=lambda e: e['t'])])
    ib = sorted([(e['d'], e['title'], e['ch']) for e in sel() if 'Integrals' in e['title']]); p('N049: integrals', len(ib), ib[0], ib[-4:], C(x[2] for x in ib), 'by month', sorted(C((x[0].year, x[0].month) for x in ib).items()))
    da = sel(theme='da', priv=True); p('N052/N053: dating', len(da), 'by month', sorted(C((e['d'].year, e['d'].month) for e in da).items()))
    p('   spring 2024 (Mar-May) private', sum(1 for e in da if D(2024,3,1) <= e['d'] <= D(2024,5,31)), 'non-private spring 2024', len(sel(a=D(2024,3,1), b=D(2024,5,31))), 'Mar-Jun', sum(1 for e in da if D(2024,3,1) <= e['d'] <= D(2024,6,20)))
    wk = sorted(C(e['t'].isocalendar()[1] for e in da).items()); p('   weeks with dating 2024', len(wk), wk[0], wk[-1], 'weeks span', wk[-1][0]-wk[0][0]+1, 'missing', [w for w in range(wk[0][0], wk[-1][0]+1) if w not in dict(wk)], 'days', len({e['d'] for e in da}), min(e['d'] for e in da), max(e['d'] for e in da))
    p('   all history any event non-private no friend', len(sel(kind=None)), 'by plat', C(e['plat'] for e in sel(kind=None)), 'distinct items any event', len({e['id'] for e in sel(kind=None)}), 'private items', len({e['id'] for e in sel(kind=None, priv=True) if e['private']}))
    p('N054: Mar 2024 non-private', [(e['title'], str(e['d'])) for e in sel(a=D(2024,3,1), b=D(2024,3,31))], 'private', len(sel(a=D(2024,3,1), b=D(2024,3,31), priv=True)) - len(sel(a=D(2024,3,1), b=D(2024,3,31))))
    p('N069: Oct 2026 watercolor', [(e['title'][:30], str(e['d']), e['plat']) for e in sel(theme='wc', a=D(2026,10,1), b=D(2026,10,31))])
    p('K04: calculus opened', len(sel(theme='ca')), 'saved calculus', len(sel(kind=('save','playlist'), theme='ca')))
    p('N035: IG events', [(e['kind'], str(e['d']), e['friend']) for e in sel(kind=None, plat='instagram', friend=True)])
