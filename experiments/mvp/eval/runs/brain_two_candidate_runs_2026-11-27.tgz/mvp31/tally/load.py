import json, collections, glob, os
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31'
K=json.load(open(f'{S}/blind/KEY_do_not_open.json'))
KEY=K['codes']; FOLD=K['run_folders']
CELLS=['v3d_1','v3d_2','v4d_1','v4d_2']
def packets():
    P={}
    for g in (1,2,3):
        d=json.load(open(f'{S}/blind/group{g}.json'))
        for m in d['messages']:
            m['group']=g; P[m['key']]=m
    return P
def marks():
    rows=[]
    for g in (1,2,3):
        for r in 'ab':
            for x in json.load(open(f'{S}/reader{g}{r}/marks.json')):
                x=dict(x); x['group']=g; x['reader']=r
                if not x.get('poor_cause'): x['poor_cause']=None
                k=KEY.get(x['code'])
                x['set']=k['set'] if k else None; x['runcell']=k['cell'] if k else None; x['cell']=k['cell'][2:] if k else None
                rows.append(x)
    return rows
def records():
    R={}
    for cell,d in FOLD.items():
        for f in [x for x in glob.glob(d+'/*.json') if not x.endswith('summary.json')]:
            r=json.load(open(f)); R[(cell, r['key'])]=r
    return R
