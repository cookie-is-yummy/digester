"""Tally of the six blind readers' marks (mvp31, the two-candidate run: v3d and v4d, two runs each on set A and set H).
Reads marks, packets, key and run records; the settlement is settle31.py (facts from facts31.py over brain_library.rows).
No model call. Writes tally_out.txt and tables.json.  Run: python3 -B tally31.py"""
import json, collections, statistics, sys
import numpy as np
sys.path.insert(0, '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/tally')
from load import S, KEY, packets, marks, records
import settle31 as ST

OUT = f'{S}/tally'
P = packets(); MK = marks(); REC = records()
RUNS = ['v3d_1', 'v3d_2', 'v4d_1', 'v4d_2']
BUILDS = {'v3d': ['v3d_1', 'v3d_2'], 'v4d': ['v4d_1', 'v4d_2']}
SETS = ['A', 'H']
GR = ['good', 'acceptable', 'poor']
BIN = ['answers', 'means', 'more', 'offer', 'brief']
SEV = {'true': 0, '-': 0, 'len': 1, 'firm': 2, 'F': 3}
L = []
def p(*a): L.append(' '.join(str(x) for x in a))

BY = collections.defaultdict(dict)
for x in MK:
    BY[(x['message_id'], x['code'])][x['reader']] = x
CODE = {}
for k, m in P.items():
    for a in m['answers']:
        CODE[(k, KEY[a['code']]['cell'][2:])] = a['code']
KEYS = {s: sorted(k for k in P if P[k]['set'] == s) for s in SETS}
CONV = {k: P[k]['conversation'] for k in P}
def rec(k, run): return REC[(f'{P[k]["set"]}_{run}', k)]
def ans(k, c): return [a for a in P[k]['answers'] if a['code'] == c][0]

# ============ 1. completeness ============
p('1. COMPLETENESS (every message and code, both readers)')
VOC = dict(grade=set(GR), answers={'y', 'n'}, means={'y', 'n'}, more={'y', 'n'}, offer={'y', 'n'}, brief={'y', 'n'},
           wrong_scope={'y', 'n'}, limit_only={'y', 'n'}, privacy_fault={'y', 'n'})
COMPLETE = {}
for g in (1, 2, 3):
    pk = {(m['key'], a['code']) for m in json.load(open(f'{S}/blind/group{g}.json'))['messages'] for a in m['answers']}
    for r in 'ab':
        xs = [x for x in MK if x['group'] == g and x['reader'] == r]
        mk = [(x['message_id'], x['code']) for x in xs]
        c = collections.Counter(mk); bad = []
        for x in xs:
            errs = [f for f, v in VOC.items() if x[f] not in v]
            for f in ['false_n', 'wb_firm_n', 'wb_lenient_n', 'limits_talk', 'limits_unwanted']:
                if not isinstance(x[f], int) or x[f] < 0: errs.append(f)
            if x['false_n'] != len(x['false_sentences']): errs.append('false_sentences')
            if x['wb_firm_n'] + x['wb_lenient_n'] != len(x['wb_sentences']): errs.append('wb_sentences')
            if (x['grade'] == 'poor') != (x['poor_cause'] is not None): errs.append('poor_cause')
            if x['code'] not in KEY or KEY[x['code']]['message_id'] != x['message_id']: errs.append('code')
            if errs: bad.append((x['message_id'], x['code'], errs))
        COMPLETE[f'{g}{r}'] = dict(marks=len(mk), answers=len(pk), messages=len({k for k, _ in pk}), missing=sorted(pk - set(mk)),
                                   extra=sorted(set(mk) - pk), duplicates=sum(v > 1 for v in c.values()), invalid=bad)
        p(f'  reader{g}{r}: {len(mk)} marks for {len(pk)} answers in {len({k for k, _ in pk})} messages; missing {len(pk - set(mk))}, '
          f'extra {len(set(mk) - pk)}, duplicates {sum(v > 1 for v in c.values())}, invalid {len(bad)} {bad if bad else ""}')
ALLC = all((k, c) in CODE for k in P for c in RUNS)
p(f'  key: {len(KEY)} codes; packets: {len(P)} messages (A {len(KEYS["A"])}, H {len(KEYS["H"])}); empty answers {sum(KEY[c]["empty"] for c in KEY)}; '
  f'every message has all four runs: {ALLC}; record for every code: {all((KEY[c]["cell"], KEY[c]["message_id"]) in REC for c in KEY)}; '
  f'every answer has both readers: {all(len(v) == 2 for v in BY.values())} ({len(BY)} answers)')

# ============ 2. agreement ============
def kappa(pairs, cats):
    n = len(pairs); po = sum(a == b for a, b in pairs) / n
    ca = collections.Counter(a for a, _ in pairs); cb = collections.Counter(b for _, b in pairs)
    pe = sum(ca[c] * cb[c] for c in cats) / n / n
    return None if pe == 1 else (po - pe) / (1 - pe)
def wkappa(pairs, cats):
    n = len(pairs); k = len(cats); idx = {c: i for i, c in enumerate(cats)}
    w = lambda i, j: 1 - abs(i - j) / (k - 1)
    po = sum(w(idx[a], idx[b]) for a, b in pairs) / n
    ca = collections.Counter(a for a, _ in pairs); cb = collections.Counter(b for _, b in pairs)
    pe = sum(w(idx[a], idx[b]) * ca[a] * cb[b] for a in cats for b in cats) / n / n
    return (po - pe) / (1 - pe)
AGREE = {}
p('\n2. READER AGREEMENT (pairs: one answer marked by reader a and reader b of its group)')
for scope in ['group1', 'group2', 'group3', 'all']:
    items = [v for (k, c), v in BY.items() if scope == 'all' or P[k]['group'] == int(scope[-1])]
    res = {}
    gp = [(v['a']['grade'], v['b']['grade']) for v in items]
    res['grade'] = dict(n=len(gp), exact=sum(a == b for a, b in gp) / len(gp), kappa=kappa(gp, GR),
                        kappa_linear=wkappa(gp, ['poor', 'acceptable', 'good']),
                        table={f'{a}|{b}': sum(1 for x in gp if x == (a, b)) for a in GR for b in GR})
    for f in ['answers', 'means', 'wrong_scope', 'more', 'offer', 'brief', 'limit_only', 'privacy_fault']:
        pr = [(v['a'][f], v['b'][f]) for v in items]
        res[f] = dict(n=len(pr), exact=sum(a == b for a, b in pr) / len(pr), kappa=kappa(pr, 'yn'),
                      table={f'{a}{b}': sum(1 for x in pr if x == (a, b)) for a in 'yn' for b in 'yn'})
    for name, fn in [('false_n>0', lambda x: 'y' if x['false_n'] > 0 else 'n'), ('wb_firm_n>0', lambda x: 'y' if x['wb_firm_n'] > 0 else 'n'),
                     ('false_or_firm>0', lambda x: 'y' if x['false_n'] + x['wb_firm_n'] > 0 else 'n')]:
        pr = [(fn(v['a']), fn(v['b'])) for v in items]
        res[name] = dict(n=len(pr), exact=sum(a == b for a, b in pr) / len(pr), kappa=kappa(pr, 'yn'),
                         table={f'{a}{b}': sum(1 for x in pr if x == (a, b)) for a in 'yn' for b in 'yn'})
    AGREE[scope] = res
    p(f'  {scope} ({len(items)} answers)')
    for f, r in res.items():
        k = r['kappa']; ks = 'undefined (both readers give the same single value)' if k is None else f'{k:.2f}'
        extra = f", linear-weighted {r['kappa_linear']:.2f}" if f == 'grade' else ''
        p(f"    {f:15s} exact {100 * r['exact']:5.1f}%  kappa {ks}{extra}   a|b {r['table']}")

# ============ 3. settlement ============
SET_BY = collections.defaultdict(list)
for e in ST.S:
    labs = [e['mine']] + ([e['alt']] if e['alt'] else [])
    e['L1'] = e['mine']
    e['LHI'] = max(labs + [e['a'], e['b']], key=lambda z: SEV[z])
    if e['LHI'] == '-': e['LHI'] = 'true'
    e['LLO'] = min(labs, key=lambda z: SEV[z])
    SET_BY[(e['key'], e['code'])].append(e)
COVER = []
for (k, c), v in BY.items():
    a, b = v['a'], v['b']
    if a['false_n'] or b['false_n'] or a['wb_firm_n'] or b['wb_firm_n']:
        if (k, c) not in SET_BY: COVER.append(('not settled', k, c))
for (k, c), es in SET_BY.items():
    for r in 'ab':
        x = BY[(k, c)][r]
        nF = sum(e[r] == 'F' for e in es); nf = sum(e[r] == 'firm' for e in es); nl = sum(e[r] == 'len' for e in es)
        if (nF, nf) != (x['false_n'], x['wb_firm_n']): COVER.append(('count', k, c, r, (nF, nf), (x['false_n'], x['wb_firm_n'])))
        if nl != x['wb_lenient_n']: COVER.append(('lenient count', k, c, r, nl, x['wb_lenient_n']))
    for e in es:
        if e['sentence'].rstrip('.') not in ans(k, c)['sent']: COVER.append(('sentence not in sent text', k, c, e['sentence'][:50]))
def settled(k, c, lab='L1'):
    es = SET_BY.get((k, c))
    if es is None:
        a, b = BY[(k, c)]['a'], BY[(k, c)]['b']
        return dict(F=0, firm=0, len=(a['wb_lenient_n'] + b['wb_lenient_n']) / 2)
    return dict(F=sum(e[lab] == 'F' for e in es), firm=sum(e[lab] == 'firm' for e in es), len=sum(e[lab] == 'len' for e in es))
p('\n3. SETTLEMENT (settle31.py; rows from facts31.py over brain_library.rows, New York dates; turn statements from the records)')
p(f'  answers settled: {len(SET_BY)}; sentences settled: {len(ST.S)} ({sum(e["sweep"] for e in ST.S)} added by the sweep of all 472 sent texts); '
  f'coverage problems: {COVER if COVER else "none"}')
p('  L1 = this settlement (the rubric line as written); LHI = most severe of L1, the other reading and both readers; LLO = least severe of L1 and the other reading')
RIGHT = collections.Counter()
for e in ST.S:
    cell = KEY[e['code']]['cell']
    if e['a'] == e['b']:
        who = 'both' if SEV[e['a']] == SEV[e['mine']] else 'neither (both readers ' + e['a'] + ')'
    else:
        ra, rb = SEV[e['a']] == SEV[e['mine']], SEV[e['b']] == SEV[e['mine']]
        who = 'reader a' if ra and not rb else 'reader b' if rb and not ra else 'neither'
    e['right'] = who
    RIGHT[(P[e['key']]['group'], who.split(' (')[0])] += 1
    p(f"  {e['key']} {e['code']} {cell}{' [sweep]' if e['sweep'] else ''}: \"{e['sentence']}\"")
    p(f"      readers a={e['a']} b={e['b']} -> settled {e['mine']}" + (f" (other reading: {e['alt']})" if e['alt'] else '') +
      f"; right: {who}; origin: {e['origin']}. Rows: {e['rows']}")
p(f'  who matched the settlement, by group: {dict(sorted(RIGHT.items()))}')
p('  PRIVACY. Marked y by both readers: N053.1 h7l, dfo, p4a, tce (group 2: Heart Notes named in the follow-up "and how did that year')
p('    compare to 2023"; code carried the topic unlock, unlock_carried true in all four records); N068.0 pl1 (group 3: "1 friend\'s post of this kind").')
p('    P1 (as written, the rubric\'s letter, used for the verdict): N053.1 x4 are faults (the person did not name the topic in that message);')
p('       pl1 is not a privacy fault (the friends\' convention makes it wrongly based, firm, which it is counted as). Faults per run:')
p('       A_v3d_1 1, A_v3d_2 1, A_v4d_1 1, A_v4d_2 1, set H 0.')
p('    P0 (a carried unlock counts as the person naming it, as mvp29 settled): no fault anywhere. P2 (strictest): P1 plus pl1 (A_v4d_2 2).')
p('    N053.0 names Heart Notes in all four runs where the person named the topic in that message: no fault (no reader marked it).')
p('  WRONG SCOPE (reader 3a y, 3b n): settled y for ' + ', '.join(f'{k} {c} {KEY[c]["cell"]}' for k, c in sorted(ST.WRONG_SCOPE)) + '.')
for k2, v2 in ST.WRONG_SCOPE_WHY.items(): p(f'    {k2}: {v2}')
p('  LIMIT ONLY (both readers): settled y for ' + ', '.join(f'{k} {c} {KEY[c]["cell"]}' for k, c in sorted(ST.LIMIT_ONLY)) +
  ': the rows hold 85 opened calculus videos and the answer says only what the saves lack; K04.0 zic (H_v4d_1) gives the 85: not limit only.')

# ============ 4. per-run tables ============
def pct(xs, q):
    xs = sorted(xs); kk = (len(xs) - 1) * q; lo, hi = int(kk), min(int(kk) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (kk - lo), 2)
NORM = {'misses the question': 'misses the question', 'wrong fact': 'false sentence', 'wrongly based': 'wrongly based',
        'limits not said': 'private line missing', 'limit only': 'limit only', 'thin': 'thin', 'says too much about limits': 'too much limit talk'}
TAB = {}
for s in SETS:
    for run in RUNS:
        ks = KEYS[s]; t = {}
        for r in 'ab':
            xs = [BY[(k, CODE[(k, run)])][r] for k in ks]
            d = {g: sum(x['grade'] == g for x in xs) for g in GR}
            for f in BIN: d[f] = sum(x[f] == 'y' for x in xs)
            for f in ['wrong_scope', 'limit_only', 'privacy_fault']: d[f] = sum(x[f] == 'y' for x in xs)
            for f in ['false_n', 'wb_firm_n', 'wb_lenient_n', 'limits_talk', 'limits_unwanted']: d[f] = sum(x[f] for x in xs)
            d['poor_causes'] = dict(collections.Counter(NORM[x['poor_cause']] for x in xs if x['grade'] == 'poor'))
            t[r] = d
        t['avg'] = {f: (t['a'][f] + t['b'][f]) / 2 for f in t['a'] if f != 'poor_causes'}
        pc = collections.Counter(); [pc.update(t[r]['poor_causes']) for r in 'ab']
        t['avg']['poor_causes'] = {k2: v / 2 for k2, v in sorted(pc.items())}
        rs = [rec(k, run) for k in ks]
        sent = sum(r['sentences']['kept_sent'] for r in rs)
        st = {}
        for lab in ['L1', 'LHI', 'LLO']:
            xx = [settled(k, CODE[(k, run)], lab) for k in ks]
            st[f'false_{lab}'] = sum(x['F'] for x in xx); st[f'firm_{lab}'] = sum(x['firm'] for x in xx)
            st[f'firm_per100_{lab}'] = round(100 * st[f'firm_{lab}'] / sent, 2)
            st[f'lenient_{lab}'] = round(sum(x['len'] for x in xx), 1)
        st['lenient_per100_L1'] = round(100 * st['lenient_L1'] / sent, 2)
        for pk_, pv in ST.PRIV.items(): st[f'privacy_{pk_}'] = sum((k, CODE[(k, run)]) in pv for k in ks)
        st['wrong_scope'] = sum((k, CODE[(k, run)]) in ST.WRONG_SCOPE for k in ks)
        st['limit_only'] = sum((k, CODE[(k, run)]) in ST.LIMIT_ONLY for k in ks)
        st['sentences_sent'] = sent; st['n'] = len(ks)
        t['settled'] = st
        secs = [r['seconds'] for r in rs]
        t['mech'] = dict(median_s=pct(secs, .5), p90_s=pct(secs, .9), max_s=max(secs), over_11s=sum(x > 11 for x in secs),
                         lead_source=dict(collections.Counter(r['lead_source'] for r in rs)), code_leads=sum(r['lead_source'] == 'code' for r in rs),
                         rewords_asked=sum(1 for r in rs if r.get('repair_message')), sentences_written=sum(r['sentences']['written'] for r in rs),
                         sentences_sent=sent, refused=sum(len(r.get('dropped') or []) for r in rs),
                         tool_errors=sum(sum(((r.get('tool_args') or {}).get('tool_errors') or {}).values()) for r in rs),
                         provider_errors=sum(1 for r in rs if r.get('error')))
        TAB[f'{s}_{run}'] = t
FIG = {}
for line in open(f'{S}/runs/figures.txt'):
    c, j = line.split(' ', 1); FIG[c] = json.loads(j)
MECH_OK = all(TAB[c]['mech']['median_s'] == FIG[c]['median_s'] and TAB[c]['mech']['p90_s'] == FIG[c]['p90_s'] and
              TAB[c]['mech']['sentences_sent'] == FIG[c]['sentences_sent'] and TAB[c]['mech']['refused'] == FIG[c]['dropped'] and
              TAB[c]['mech']['tool_errors'] == FIG[c]['tool_errors'] for c in TAB)
p('\n4. PER RUN (unblinded). a = readers 1a+2a+3a over the run\'s messages; b = 1b+2b+3b; avg = mean of a and b. Reader counts of')
p('   false / firm / lenient are the readers\' own; "settled" rows are this tally\'s.')
HDR = ['good', 'acceptable', 'poor', 'answers', 'means', 'more', 'offer', 'brief', 'false_n', 'wb_firm_n', 'wb_lenient_n', 'privacy_fault',
       'wrong_scope', 'limit_only', 'limits_talk', 'limits_unwanted']
for s in SETS:
    p(f'  set {s} ({len(KEYS[s])} messages)')
    p('    ' + f"{'run':6s} {'rd':3s} " + ' '.join(f'{h[:7]:>7s}' for h in HDR))
    for run in RUNS:
        t = TAB[f'{s}_{run}']
        for r in ['a', 'b', 'avg']:
            p('    ' + f'{run:6s} {r:3s} ' + ' '.join((f'{t[r][h]:7.1f}' if r == 'avg' else f'{t[r][h]:7d}') for h in HDR))
    p('    settled and mechanical:')
    for run in RUNS:
        t = TAB[f'{s}_{run}']; st = t['settled']; m = t['mech']
        p(f"    {run}: sent {st['sentences_sent']}; settled false {st['false_L1']} (LHI {st['false_LHI']}, LLO {st['false_LLO']}); "
          f"firm {st['firm_L1']} = {st['firm_per100_L1']}/100 (LHI {st['firm_LHI']} = {st['firm_per100_LHI']}/100); lenient {st['lenient_L1']} = "
          f"{st['lenient_per100_L1']}/100; privacy P1 {st['privacy_P1']} (P0 {st['privacy_P0']}, P2 {st['privacy_P2']}); wrong scope {st['wrong_scope']}; "
          f"limit only {st['limit_only']}")
        p(f"           seconds median {m['median_s']} p90 {m['p90_s']} max {m['max_s']} over 11 s {m['over_11s']}; leads {m['lead_source']} (code {m['code_leads']}); "
          f"rewords {m['rewords_asked']}; written {m['sentences_written']}, sent {m['sentences_sent']}, refused {m['refused']}; tool errors {m['tool_errors']}; "
          f"provider errors {m['provider_errors']}")
    p('    poor causes (reader a | reader b):')
    for run in RUNS:
        t = TAB[f'{s}_{run}']
        p(f"    {run}: a {t['a']['poor_causes']} | b {t['b']['poor_causes']}")
p(f'  mechanical figures match runs/figures.txt (gate31.py): {MECH_OK}')

# ============ bootstrap helpers ============
def val(x, f):
    if f in GR: return 1 if x['grade'] == f else 0
    if f in BIN or f in ('wrong_scope', 'limit_only', 'privacy_fault'): return 1 if x[f] == 'y' else 0
    return x[f]
def build_diff(ks, f, x_runs, y_runs, readers=('a', 'b')):
    """per message: mean over x_runs and readers minus mean over y_runs and readers."""
    out = {}
    for k in ks:
        vx = [val(BY[(k, CODE[(k, r_)])][r], f) for r_ in x_runs for r in readers]
        vy = [val(BY[(k, CODE[(k, r_)])][r], f) for r_ in y_runs for r in readers]
        out[k] = sum(vx) / len(vx) - sum(vy) / len(vy)
    return out
def boot_sum(dm, B=10000, seed=31, cluster=False):
    rng = np.random.default_rng(seed)
    if cluster:
        g = collections.defaultdict(float)
        for k, v in dm.items(): g[CONV[k]] += v
        arr = np.array(list(g.values()))
    else:
        arr = np.array(list(dm.values()))
    idx = rng.integers(0, len(arr), size=(B, len(arr)))
    tot = arr[idx].sum(axis=1)
    return round(float(np.percentile(tot, 2.5)), 2), round(float(np.percentile(tot, 97.5)), 2)
def sign(ds): return f"+{sum(d > 0 for d in ds)}/-{sum(d < 0 for d in ds)}"

# ============ 5. run-to-run noise ============
p('\n5. RUN-TO-RUN NOISE: run 2 minus run 1 of the same build (readers averaged; settled L1). Interval: paired per-message bootstrap of the')
p('   difference (both readers), 95%, 10000 resamples over messages.')
NOISE = {}
for s in SETS:
    for b, (r1, r2) in BUILDS.items():
        t1, t2 = TAB[f'{s}_{r1}'], TAB[f'{s}_{r2}']
        d = {}
        for f in ['good', 'poor', 'answers', 'means']:
            dm = build_diff(KEYS[s], f, [r2], [r1])
            d[f] = dict(run1=t1['avg'][f], run2=t2['avg'][f], diff=t2['avg'][f] - t1['avg'][f], ci=boot_sum(dm),
                        by_reader={r: t2[r][f] - t1[r][f] for r in 'ab'})
        for f in ['false_L1', 'firm_L1', 'lenient_L1']:
            d[f] = dict(run1=t1['settled'][f], run2=t2['settled'][f], diff=round(t2['settled'][f] - t1['settled'][f], 1))
        for f in ['median_s', 'p90_s']:
            d[f] = dict(run1=t1['mech'][f], run2=t2['mech'][f], diff=round(t2['mech'][f] - t1['mech'][f], 2))
        NOISE[f'{s}_{b}'] = d
        p(f'  set {s} {b}: ' + '; '.join(f"{f} {v['run1']:g} -> {v['run2']:g} ({v['diff']:+g}" + (f", ci {v['ci']}, by reader a {v['by_reader']['a']:+}, b {v['by_reader']['b']:+}" if 'ci' in v else '') + ')' for f, v in d.items()))
mx = {f: max(abs(NOISE[k][f]['diff']) for k in NOISE) for f in ['good', 'poor', 'answers', 'false_L1', 'firm_L1', 'median_s', 'p90_s']}
p(f'  largest same-build gap over the four pairs: {mx}')

# ============ 6. candidate ============
p('\n6. THE CANDIDATE, by the rule as written (DECISIONS.md, "The rule for the next run, written before it"; v3c/v4c read as v3d/v4d).')
CAND = {}
gA = {b: sum(TAB[f'A_{r}'][rd]['good'] for r in BUILDS[b] for rd in 'ab') for b in BUILDS}
CAND['good_A_sum_both_runs_both_readers'] = gA
CAND['good_A_per_run_avg'] = {r: TAB[f'A_{r}']['avg']['good'] for r in RUNS}
CAND['good_A_by_reader'] = {b: {rd: sum(TAB[f'A_{r}'][rd]['good'] for r in BUILDS[b]) for rd in 'ab'} for b in BUILDS}
CAND['good_H_sum'] = {b: sum(TAB[f'H_{r}'][rd]['good'] for r in BUILDS[b] for rd in 'ab') for b in BUILDS}
dmg = build_diff(KEYS['A'], 'good', BUILDS['v4d'], BUILDS['v3d'])
CAND['good_A_diff_v4d_minus_v3d_per_run'] = dict(diff=round(sum(dmg.values()), 2), ci=boot_sum(dmg), sign=sign(list(dmg.values())))
leader = 'v4d' if gA['v4d'] > gA['v3d'] else 'v3d' if gA['v3d'] > gA['v4d'] else 'tie'
other = {'v4d': 'v3d', 'v3d': 'v4d'}.get(leader)
CAND['leader_on_good'] = leader
p(f"  good answers on set A, summed over both runs and both readers (out of 260): v3d {gA['v3d']}, v4d {gA['v4d']}; per run (avg of readers): "
  f"{CAND['good_A_per_run_avg']}; by reader set: {CAND['good_A_by_reader']}")
p(f"  paired per-message difference v4d minus v3d in good answers per run on set A: {CAND['good_A_diff_v4d_minus_v3d_per_run']}")
p(f"  set H for reference (out of 212): {CAND['good_H_sum']}. More good on set A: {leader}.")
def provisos(lead, oth):
    out = {}
    for lab in ['L1', 'LHI', 'LLO']:
        fa = {b: sum(TAB[f'A_{r}']['settled'][f'false_{lab}'] for r in BUILDS[b]) for b in BUILDS}
        fall = {b: sum(TAB[f'{s}_{r}']['settled'][f'false_{lab}'] for s in SETS for r in BUILDS[b]) for b in BUILDS}
        out[f'false_{lab}'] = dict(setA=fa, all_runs=fall, pass_setA=fa[lead] <= fa[oth], pass_all=fall[lead] <= fall[oth])
    for s in SETS:
        pr = {b: sum(TAB[f'{s}_{r}']['avg']['poor'] for r in BUILDS[b]) / 2 for b in BUILDS}
        dmp = build_diff(KEYS[s], 'poor', BUILDS[lead], BUILDS[oth])
        n = len(KEYS[s])
        out[f'poor_{s}'] = dict(per_run_avg=pr, diff_per_run=round(pr[lead] - pr[oth], 2), per65=round((pr[lead] - pr[oth]) * 65 / n, 2),
                                ci=boot_sum(dmp), pass_raw4=pr[lead] - pr[oth] <= 4, pass_scaled=(pr[lead] - pr[oth]) * 65 / n <= 4)
        dma = build_diff(KEYS[s], 'answers', BUILDS[lead], BUILDS[oth])
        ci = boot_sum(dma); ciconv = boot_sum(dma, cluster=True)
        out[f'answers_{s}'] = dict(diff_per_run=round(sum(dma.values()), 2), ci=ci, ci_conv=ciconv, sign=sign(list(dma.values())),
                                   by_reader={rd: round(sum(build_diff(KEYS[s], 'answers', BUILDS[lead], BUILDS[oth], (rd,)).values()), 2) for rd in 'ab'},
                                   per_run_avg={b: sum(TAB[f'{s}_{r}']['avg']['answers'] for r in BUILDS[b]) / 2 for b in BUILDS},
                                   falls_clear_of_0=ci[1] < 0, pass_=not ci[1] < 0)
    return out
if leader != 'tie':
    PV = provisos(leader, other)
    CAND['provisos'] = PV
    p(f'  provisos for {leader} against {other}:')
    for lab in ['L1', 'LHI', 'LLO']:
        x = PV[f'false_{lab}']
        p(f"    settled false ({lab}): set A two runs {x['setA']}, all four runs {x['all_runs']} -> no more on set A: {x['pass_setA']}; no more over all runs: {x['pass_all']}")
    for s in SETS:
        x = PV[f'poor_{s}']
        p(f"    poor, set {s}: per run (avg readers, both runs) {x['per_run_avg']}; {leader} minus {other} {x['diff_per_run']:+} per run "
          f"(= {x['per65']:+} per 65; per-message ci {x['ci']}) -> within 4: raw {x['pass_raw4']}, scaled to 65 {x['pass_scaled']}")
    for s in SETS:
        x = PV[f'answers_{s}']
        p(f"    answers the question, set {s}: {leader} minus {other} {x['diff_per_run']:+} answers per run, 95% ci {x['ci']} (by conversation {x['ci_conv']}), "
          f"messages {x['sign']}; by reader a {x['by_reader']['a']:+}, b {x['by_reader']['b']:+}; per run {x['per_run_avg']} -> falls with an interval clear of 0: {x['falls_clear_of_0']}")
    rest = PV['poor_A']['pass_raw4'] and PV['poor_H']['pass_raw4'] and PV['poor_H']['pass_scaled'] and PV['answers_A']['pass_'] and PV['answers_H']['pass_']
    ok = {f'{lab}, false counted on {fs}': PV[f'false_{lab}']['pass_setA' if fs == 'set A' else 'pass_all'] and rest
          for lab in ['L1', 'LHI', 'LLO'] for fs in ['set A', 'all runs']}
    CAND['provisos_all_pass'] = ok
    CAND['candidate_by_reading'] = {k: (leader if v else other) for k, v in ok.items()}
    cand = leader if ok['L1, false counted on set A'] else other
    CAND['candidate'] = cand
    p(f'  all provisos pass for {leader}, by reading: {ok}')
    p(f'  CANDIDATE by reading: {CAND["candidate_by_reading"]}. Main reading (L1, false counted on set A, the set the rule picks on): {cand}.')
# answers v4d minus v3d always reported (the rule's own direction)
AV = {}
for s in SETS:
    dma = build_diff(KEYS[s], 'answers', BUILDS['v4d'], BUILDS['v3d'])
    AV[s] = dict(diff=round(sum(dma.values()), 2), ci=boot_sum(dma), ci_conv=boot_sum(dma, cluster=True), sign=sign(list(dma.values())))
CAND['answers_v4d_minus_v3d'] = AV
p(f"  'answers the question', v4d minus v3d per run (both runs, both readers pooled, bootstrap over messages): set A {AV['A']}; set H {AV['H']}")

# ============ 7. gate readiness ============
p('\n7. GATE READINESS (bars: settled false <= 1; firm <= 6 per 100 sent; privacy 0; median <= 8 s and p90 <= 11 s; answers >= 80%;')
p('   poor <= 20%; good >= 25%; rates = average of the two readers). Condition: each of the build\'s 4 runs misses at most one bar, none > 2 false.')
def gate_row(s, run, flab='L1', wlab='L1', plab='P1'):
    t = TAB[f'{s}_{run}']; st = t['settled']; m = t['mech']; n = st['n']; av = t['avg']
    g = dict(false=(st[f'false_{flab}'], st[f'false_{flab}'] <= 1), firm_per100=(st[f'firm_per100_{wlab}'], st[f'firm_per100_{wlab}'] <= 6),
             privacy=(st[f'privacy_{plab}'], st[f'privacy_{plab}'] == 0), median_s=(m['median_s'], m['median_s'] <= 8), p90_s=(m['p90_s'], m['p90_s'] <= 11),
             answers_pct=(round(100 * av['answers'] / n, 1), 100 * av['answers'] / n >= 80), poor_pct=(round(100 * av['poor'] / n, 1), 100 * av['poor'] / n <= 20),
             good_pct=(round(100 * av['good'] / n, 1), 100 * av['good'] / n >= 25))
    return g
def misses(g, speed_one=True):
    bars = ['false', 'firm_per100', 'privacy', 'answers_pct', 'poor_pct', 'good_pct']
    m = [b for b in bars if not g[b][1]]
    if speed_one:
        if not (g['median_s'][1] and g['p90_s'][1]): m.append('speed')
    else:
        m += [b for b in ('median_s', 'p90_s') if not g[b][1]]
    return m
def condition(build, flab='L1', wlab='L1', plab='P1', speed_one=True):
    rows = {f'{s}_{r}': gate_row(s, r, flab, wlab, plab) for s in SETS for r in BUILDS[build]}
    fails = {k: misses(g, speed_one) for k, g in rows.items()}
    met = all(len(v) <= 1 for v in fails.values()) and all(rows[k]['false'][0] <= 2 for k in rows)
    return met, rows, fails
GATE = {}
def pf(x): return 'pass' if x else 'FAIL'
for b in ['v4d', 'v3d']:
    met, rows, fails = condition(b)
    GATE[b] = dict(rows=rows, fails=fails, met=met)
    p(f'  {b}' + (' (the candidate)' if CAND.get('candidate') == b else ' (the other build)') + ', readings L1 / P1:')
    p('    ' + f"{'run':9s} {'false<=1':10s} {'firm/100<=6':12s} {'privacy=0':10s} {'median<=8':10s} {'p90<=11':10s} {'answers>=80%':13s} {'poor<=20%':10s} {'good>=25%':10s} misses")
    for k, g in rows.items():
        p('    ' + f"{k:9s} {g['false'][0]:<3} {pf(g['false'][1]):6s} {g['firm_per100'][0]:<5.2f} {pf(g['firm_per100'][1]):6s} {g['privacy'][0]:<3} {pf(g['privacy'][1]):6s} "
          f"{g['median_s'][0]:<5} {pf(g['median_s'][1]):4s} {g['p90_s'][0]:<5} {pf(g['p90_s'][1]):4s} {g['answers_pct'][0]:<6} {pf(g['answers_pct'][1]):6s} "
          f"{g['poor_pct'][0]:<5} {pf(g['poor_pct'][1]):4s} {g['good_pct'][0]:<5} {pf(g['good_pct'][1]):4s} {len(fails[k])}: {', '.join(fails[k]) or '-'}")
    p(f'    condition met: {met}')
GRID = {}
p('  the condition under every reading (false L1/LHI/LLO x firm L1/LHI x privacy P1/P0/P2 x speed as one bar or two):')
for b in ['v4d', 'v3d']:
    for flab in ['L1', 'LHI', 'LLO']:
        for wlab in ['L1', 'LHI']:
            for plab in ['P1', 'P0', 'P2']:
                for sp in [True, False]:
                    met, rows, fails = condition(b, flab, wlab, plab, sp)
                    GRID[f'{b}|false {flab}|firm {wlab}|privacy {plab}|speed {"one" if sp else "two"}'] = dict(met=met, fails={k: v for k, v in fails.items() if v})
    mets = {k: v['met'] for k, v in GRID.items() if k.startswith(b)}
    p(f'    {b}: met in {sum(mets.values())} of {len(mets)} readings')
    for k, v in GRID.items():
        if k.startswith(b): p(f"      {k}: {'MET' if v['met'] else 'not met'}; misses {v['fails']}")

# ============ 8. poor causes ============
p('\n8. WHAT MAKES THE POOR ANSWERS POOR. Readers\' causes, averaged over the two readers, per run; examples: message, code, run, sentence.')
PC = collections.defaultdict(lambda: collections.defaultdict(float)); EX = collections.defaultdict(list)
for (k, c), v in BY.items():
    run = KEY[c]['cell']
    for r in 'ab':
        if v[r]['grade'] == 'poor': PC[NORM[v[r]['poor_cause']]][run] += 0.5
    for r in 'ab':
        x = v[r]
        if not x['poor_cause']: continue
        cz = NORM[x['poor_cause']]
        es = [e for e in SET_BY.get((k, c), []) if e['L1'] in ('F', 'firm')]
        sent = es[0]['sentence'] if es and cz in ('false sentence', 'wrongly based') else ans(k, c)['parts']['lead']
        EX[cz].append((k, c, run, sent, v['a']['poor_cause'] == v['b']['poor_cause']))
R8 = {}
for cz in sorted(PC, key=lambda z: -sum(PC[z].values())):
    row = {f'{s}_{r}': PC[cz].get(f'{s}_{r}', 0.0) for s in SETS for r in RUNS}
    seen = []; exs = []
    for e in sorted(EX[cz], key=lambda e: not e[4]):
        if e[0] not in seen: seen.append(e[0]); exs.append(e)
        if len(exs) == 2: break
    R8[cz] = dict(total=sum(row.values()), per_run=row, examples=exs)
    p(f"  {cz}: {sum(row.values())} answers in all; " + ', '.join(f'{k2} {v2:g}' for k2, v2 in row.items()))
    for e in exs: p(f'      {e[0]} {e[1]} ({e[2]}{", both readers" if e[4] else ", one reader"}): "{e[3]}"')
# origin of the settled false and firm sentences
ORI = collections.defaultdict(lambda: collections.Counter())
for e in ST.S:
    if e['L1'] in ('F', 'firm'): ORI[e['origin']][KEY[e['code']]['cell']] += 1
p('  origin of the settled false and firm sentences (L1): ' + '; '.join(f'{o}: {sum(v.values())} ({dict(sorted(v.items()))})' for o, v in ORI.items()))
# refused sentences in poor answers (the checker's drops)
DROP = []
for (k, c), v in BY.items():
    if 'poor' not in (v['a']['grade'], v['b']['grade']): continue
    r = rec(k, KEY[c]['cell'][2:])
    for d in r.get('dropped') or []:
        DROP.append(dict(key=k, code=c, run=KEY[c]['cell'], grades=(v['a']['grade'], v['b']['grade']), where=d['where'], text=d['text'], reasons=d['reasons'],
                         details=d.get('details'), lead_source=r['lead_source']))
p(f'  sentences the checker refused in answers either reader graded poor: {len(DROP)}')
for d in DROP: p(f"    {d['key']} {d['code']} {d['run']} grades {d['grades']} {d['where']} lead_source {d['lead_source']}: \"{d['text']}\" reasons {d['reasons']} {d['details']}")
ALLDROP = collections.Counter()
for (cell, k), r in REC.items():
    for d in r.get('dropped') or []: ALLDROP[tuple(d['reasons'])] += 1
p(f'  all refused sentences in the eight runs, by reason: {dict(ALLDROP)}')

open(f'{OUT}/tally_out.txt', 'w').write('\n'.join(L) + '\n')
json.dump(dict(completeness=COMPLETE, agreement=AGREE, settlement=ST.S, settlement_coverage_problems=COVER,
               privacy={k: sorted(v) for k, v in ST.PRIV.items()}, wrong_scope=sorted(ST.WRONG_SCOPE), limit_only=sorted(ST.LIMIT_ONLY),
               per_run=TAB, mechanical_match_figures=MECH_OK, noise=NOISE, candidate=CAND, gate=GATE, gate_grid=GRID, poor_causes=R8,
               refused_in_poor=DROP, origin={k: dict(v) for k, v in ORI.items()}),
          open(f'{OUT}/tables.json', 'w'), indent=1, default=str)
print('\n'.join(L))
