"""Every combination of the seven false-or-not forks (settle31: sentences whose L1 and other reading differ across F),
with the false proviso counted on set A or on all four runs, and privacy P1 or P0: the candidate and the gate condition.
Other bars do not move (every run passes firm, speed, answers, poor, good under every reading; see tally_out.txt)."""
import itertools, json, collections
BASE = {'A_v3d_1': 2, 'A_v3d_2': 0, 'A_v4d_1': 2, 'A_v4d_2': 0, 'H_v3d_1': 0, 'H_v3d_2': 0, 'H_v4d_1': 1, 'H_v4d_2': 0}
FORKS = {'N053.0 rnp (len->F)': ('A_v4d_1', +1), 'N035.1 l5b (F->firm)': ('A_v4d_1', -1), 'N045.0 ceb (firm->F)': ('A_v3d_1', +1),
         'N054.0 a7v (firm->F)': ('A_v3d_1', +1), 'N001.1 y8p (true->F)': ('A_v3d_1', +1), 'N045.0 dpc (firm->F)': ('A_v3d_2', +1),
         'N049.0 l6d (F->firm)': ('A_v3d_1', -1)}
PRIV = {'P1': {'A_v3d_1': 1, 'A_v3d_2': 1, 'A_v4d_1': 1, 'A_v4d_2': 1}, 'P0': {}}
B = {'v3d': ['A_v3d_1', 'A_v3d_2', 'H_v3d_1', 'H_v3d_2'], 'v4d': ['A_v4d_1', 'A_v4d_2', 'H_v4d_1', 'H_v4d_2']}
def gate(build, F, priv):
    for r in B[build]:
        miss = (F[r] > 1) + (priv.get(r, 0) > 0)
        if miss > 1 or F[r] > 2: return False
    return True
out = collections.Counter(); single = {}
names = list(FORKS)
for bits in itertools.product([0, 1], repeat=len(names)):
    F = dict(BASE)
    for on, n in zip(bits, names):
        if on: F[FORKS[n][0]] += FORKS[n][1]
    for fset in ['A', 'all']:
        tot = {b: sum(F[r] for r in B[b] if fset == 'all' or r.startswith('A')) for b in B}
        cand = 'v4d' if tot['v4d'] <= tot['v3d'] else 'v3d'
        for pl, pv in PRIV.items():
            g = gate(cand, F, pv)
            out[(fset, pl, cand, g)] += 1
            if sum(bits) <= 1:
                single[(tuple(n for on, n in zip(bits, names) if on) or ('none',), fset, pl)] = (cand, g, dict(F))
res = dict(combos_per_reading=2 ** len(names), tally={' | '.join(map(str, k)): v for k, v in sorted(out.items())},
           single_flips={f'{k[0][0]} | false proviso on {k[1]} | privacy {k[2]}': dict(candidate=v[0], gate_condition_met=v[1]) for k, v in single.items()})
json.dump(res, open('forks31.json', 'w'), indent=1)
for k, v in res['tally'].items(): print(k, v)
for k, v in res['single_flips'].items(): print(k, v)
