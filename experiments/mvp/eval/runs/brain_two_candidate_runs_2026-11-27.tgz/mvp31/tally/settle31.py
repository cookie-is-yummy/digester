"""Settlement of every flagged or disputed sentence of mvp31, from the library rows (facts31.py / facts31.txt) and,
for statements about the turn, the run record. No brain tool is used for the facts.

Labels: F = false; firm / len = wrongly based firm / lenient; true = no fault; '-' = the reader did not mark it.
mine = this tally's settlement (L1, by the rubric's line as written). alt = the other defensible label where the line
leaves a choice (None = no other reading). tally31.py derives:
  L1  = mine;
  LHI = the most severe of mine, alt and both readers' labels (every reading that could count a sentence false counts it);
  LLO = the least severe of mine and alt.
origin: what the record shows the sentence came from: 'model' (the model's own judgement over a right tool result),
'tool' (a tool's cell, window words or missing cell led to it), 'code' (code's own line or a line code left out).

The line (eval/brain_reading_rubric.md, "False or wrongly based: the line"), as used here:
- F: a figure, name or date no nearby reading of the rows gives; a statement that the history lacks what it holds;
  a read said to fail when it did not; a statement about the turn that the record contradicts.
- firm: a real figure said of the wrong period, base, event or rank (a list said as complete included), misleading a
  careful reader.  len: clumsy wording a fair reader takes rightly.
- true: a true statement about the turn (the record shows it), or a sentence with no fault.
Private-row convention, friends' convention, "a limit that is the answer": as the rubric says.
"""
S = []


def add(key, code, sent, a, b, mine, alt, rows, origin, sweep=False):
    S.append(dict(key=key, code=code, sentence=sent, a=a, b=b, mine=mine, alt=alt, rows=rows, origin=origin,
                  sweep=sweep))


W1 = '3-30 Oct 2026 opens 130: Gaming clips 59, Home cooking 30, Digital drawing 27, Minecraft 5, Watercolor 5, Calculus 4'
add('A03.0', 'b1f', 'Watercolor painting had 5 videos, a theme new in this window.', 'firm', 'firm', 'firm', None,
    '0 watercolor opens in 5 Sep-2 Oct, but 90 before that (10 Jan 2025 to 26 Aug 2026): "new" reads as newly taken up; '
    'the result held no earlier window (note "new and stopped are not computed here"); same settlement as mvp29 A01.1 ppq / A03.0 geb', 'model')
add('B14.0', 'ccu', 'Over all your history, 66 of the 723 videos you opened were Shorts, a share of 9%; the other 651 were long videos.',
    'firm', 'len', 'len', 'firm',
    '723 opens (no private rows) = 66 Shorts + 651 known long + 2 YouTube with no length + 4 Instagram reels; "the other 651" '
    'leaves 6 of 723 out; the share (9%) and the split are right, so a fair reader takes it rightly', 'model')
add('D10.0', 'jj3', 'Pan Theory made 30 videos, all in Home cooking, which was 23% of what you opened in food and cooking.',
    'firm', 'firm', 'firm', None, W1 + '; 23% = 30 of all 130; of food and cooking Home cooking is 100%: a base fault', 'model')
add('D10.1', 't3s', 'Thanks for the correction. In the 4 weeks up to 30 October 2026, gaming was 49% of what you opened, 64 of 130 videos, so my last answer was wrong to leave it out.',
    'F', 'F', 'F', None,
    "record: the last answer's plan (screen.last_answer) was a breakdown by area with no exclude, so it did not leave gaming "
    "out; gaming 64 of 130 is true; a statement about the turn the record contradicts (corrects_previous: true)", 'model')
add('D10.1', 't3s', 'Gaming clips was 100% Shorts, against 47% Shorts across everything you opened.', 'len', 'len', 'len', None,
    '47% = 59 of the 126 YouTube opens (totals.shorts_share); 45% of all 130', 'tool')
add('E04.0', 'vfm', 'The one channel that fell in count is Wet Paper, with 40 videos this year against 45 in 2025, down 5 videos.',
    'firm', 'firm', 'firm', None,
    'Wet Paper 2026: 37 opens + 3 playlist saves = 40 (the model called changes with how "any"); 45 = opens 1 Jan-30 Oct 2025 '
    '(54 in all 2025); opens and saves added and said as videos: the rubric\'s own firm example', 'model')
add('E04.0', 'vfm', 'Watercolor painting fell from 87% of what you opened in 2025 to 17% this year.', '-', 'firm', 'len', 'firm',
    '2026 watercolor: 41 of 254 opens = 16.1%; 17% = 44 of 260 opens and saves; 2025 87% either base; same opens-plus-saves '
    'read, but one point off does not mislead a careful reader', 'model')
add('F06.0', 'dl0', 'Your gaming opens were 0 in Feb 2026 and 7 in Sep 2026, after 319 gaming videos since January 2021.',
    'firm', 'firm', 'firm', None, 'gaming all history 319 (Oct 2026 72 included); 240 before Feb 2026; Feb 2026 0, Sep 2026 7: '
    'the all-history total said as coming before', 'model')
add('I03.0', 'e9g', 'You also saved 3 Home cooking posts that you never opened in 2024.', 'firm', 'firm', 'firm', None,
    'the 3 Home cooking saves are 5, 6 and 10 Oct 2026; no saves in 2024; library.saved_not_opened is counted over all '
    'history (library.counted_over); same settlement as mvp29 I03.0 tgu', 'tool')
add('K03.0', 'p5e', 'New this year: Clip Factory first opened 1 October 2026.', 'firm', 'firm', 'firm', None,
    "first opened in 2026: Pixel Pencil 1 Aug (92, the year's top channel), Clip Factory 1 Oct, Gaming Daily 1 Oct, "
    "@wetpaper.ig 12 Oct; new themes Digital drawing, Gaming clips; the tool's new list held them: a list said as complete", 'model')
add('N001.0', 'm91', 'Digital drawing from Pixel Pencil was the largest single theme, with 27 videos.', 'firm', 'firm', 'firm', None,
    '3-30 Oct without gaming: Home cooking 30, Digital drawing 27: a rank said wrongly (27 is real; largest art theme)', 'model')
add('N001.1', 'y8p', "This result has no earlier window to compare with, so it can't show when the jump started.", '-', 'F', 'true', 'F',
    'rows hold the window before (2 cooking opens in 5 Sep-2 Oct), but the record shows the changes result (against previous) '
    'came back with change {} and the note "No window before this one: new and stopped are not computed here": a true '
    'statement about the turn (rubric: not false); still system talk', 'tool')
add('N005.0', 'a14', 'Brick Realm also runs the whole export: first watched on 5 January 2021, last on 20 October 2026, with 163 videos.',
    'firm', 'firm', 'firm', None, 'Brick Realm 91 (2021), 59 (2022), 0 (2023-2025), 13 (2026): dates true, said as a run '
    'across every year to an every-year question', 'model')
add('N005.0', 'ecz', 'Your history has few items in 2024: 8 in all, so the run is not unbroken across every year for every channel.',
    'firm', 'firm', 'firm', None, '2024: 8 shown, 58 with the 50 private; reads past the private line (as mvp29 N005.0 fyg)', 'model')
add('N033.1', 'p0y', 'Gaming clips is 94% of what you opened in that month.', 'firm', 'firm', 'firm', None,
    'Oct 2026: 142 opens, 70 Shorts and reels, Gaming clips 66: 94% is of the short items, said of the month', 'model')
add('N034.0', 'zrz', 'Home cooking came next with 32 videos from Pan Theory.', 'firm', 'firm', 'firm', None,
    '2026 long: Digital drawing 92, Watercolor painting 37, Home cooking 32: the tool listed watercolor second; a rank said wrongly', 'model')
add('N035.1', 'l5b', 'Your Instagram export only covers 12 to 15 October 2026, and in that time you opened 4 reels, all of them Watercolor painting.',
    'firm', 'firm', 'F', 'firm',
    "Instagram opens 12-15 Oct (4 reels); the Instagram record also holds saves on 5, 6, 10 Oct (and the friend's 9 Oct): "
    "'the export only covers 12 to 15 October' says the history lacks what it holds, the rubric's false absence; the same "
    "message's 'Your export holds no Instagram history before 12 October 2026' was settled false last round and DECISIONS "
    "quotes it among the false sentences; I cannot draw a line between the two. Other reading (both readers): firm, the "
    "opens' span (the tool's window words 'your Instagram opens: 12 to 15 October 2026') said of the export, the question "
    "being about watching", 'tool')
add('N045.0', 'ceb', 'The first in the window was Calculus derivatives fast #77, opened on 14 September 2026.', 'firm', 'F', 'firm', 'F',
    'Sep 2026 calculus: #76 10 Sep, #77 14, #78 18, #79 22, #80 26, #81 30; the items call returned the 5 newest of 6 '
    '("The list runs newest first"); #77 is the first of the page said as the first of the month: a rank said of the wrong rows', 'model')
add('N045.0', 'dpc', 'Your earliest in the month was Calculus derivatives fast #77, opened on 14 September 2026.', 'firm', 'F', 'firm', 'F',
    'as N045.0 ceb (same tool page of 5 of 6)', 'model')
add('N049.0', 'l6d', 'All five of these are from Limit Lane.', 'F', 'F', 'F', 'firm',
    '21 "Integrals by parts" opens, all Limit Lane; the search returned 5 of them; the answer names 3 and shows 2 cards: '
    'a count of "these" that matches nothing the person is shown (mvp29: a count above the cards is false)', 'model')
add('N049.0', 'qme', 'Other matches are Integrals by parts #10 on 13 June 2023 and #14 on 17 June 2023.', '-', 'firm', 'len', 'firm',
    'dates true; 21 match (19 in Jun-Aug 2023, 2 in Sep-Oct 2026); "other matches are" is not said as all of them; '
    'the omission of the 2026 ones is a grade matter', 'model')
add('N049.0', 'ze2', 'Integrals by parts #6 followed on 8 June 2023, and the series runs on through June 2023.', 'firm', 'firm', 'firm', None,
    'the series runs 4 Jun-24 Aug 2023 and again 18 Sep and 4 Oct 2026: "runs on through June 2023" says it ends in June', 'model')
add('N052.1', 'm3m', 'Most of the gap is private topics: 50 items sit in topics you keep private, so they are left out of every count here.',
    'firm', 'firm', 'firm', None, 'spring 2024 (Mar-May): 23 private opens, 3 shown; 50 is all history said of the spring gap '
    '(the model read all history)', 'model')
add('N052.1', 'm3m', "1 item is a friend's post, in no total and never shown.", 'firm', 'len', 'firm', 'len',
    "the friend's post is 9 Oct 2026, not part of the spring 2024 gap; said as part of why spring 2024 looks thin", 'model')
add('N052.1', 'm3m', 'Your history in all runs to 729 items, counted up to 30 October 2026 on YouTube.', 'len', '-', 'len', None,
    '729 items, any event, no private rows: 722 YouTube + 7 Instagram; "on YouTube" sits on the end date', 'model')
add('N053.0', 'rnp', 'In 2024 you opened 50 dating videos, on 50 different days, so about one a week from February to August.',
    'F', 'len', 'len', 'F',
    '50 opens on 50 days, 1 Feb-15 Aug 2024 = 29 ISO weeks, every week has one or two: 1.7 a week; "about one a week" '
    'answers "every week" rightly and the 50 is beside it; read as a rate, no reading gives one a week', 'model')
add('N054.0', 'a7v', 'In March 2024 you opened 1 video that is in this list: Cooking tofu three ways #26.', 'firm', 'F', 'firm', 'F',
    'March 2024: 1 shown, 7 private (left_out.private 7); code printed no private line in this run only (the other three '
    'N054.0 answers carry it); the shown count said as everything: firm by the line; false by the private-row '
    'convention\'s "without the line the same sentence is false"', 'code')
add('N068.0', 'pl1', "Your export holds 1 friend's post of this kind, which is in no total and never shown.", 'firm', 'firm', 'firm', None,
    "left_out.friends 1 with the tool note \"none of them is said to be of the words searched for\"; the model gives the "
    "friend's post a topic: firm by the friends' convention", 'model')
add('N069.0', 'ijg', 'The title is cut short in your history, so this is the closest of the matches for that name in October 2026.',
    'F', 'F', 'F', None, 'the row holds the whole title; the tool note says `title_clipped`: "the item\'s own title is whole in '
    'their history"; a false absence (as mvp29 N069.0 zom)', 'model')
add('N069.0', 'ijg', 'Other watercolor items you opened that month: Watercolor reel 1 on 12 October 2026 and Watercolor reel 2 on 13 October 2026.',
    '-', 'firm', 'len', 'firm', 'Oct 2026 watercolor: reels 1-4 (12-15 Oct) and the tips video (21 Oct); the tool returned all '
    'five; dates true; a side list not said as all', 'model')
add('N069.0', 't4i', 'Its title is clipped in your history, so the full title is longer than shown here.', 'F', 'F', 'F', None,
    'as N069.0 ijg: the history holds the whole title; the tool note said so', 'model')
SAVES = ("the 6 own saves are 3-10 Oct 2026 (3 Wet Paper playlist 3-5 Oct, @crumb.lab 5 and 6 Oct, @noodle.nights 10 Oct; "
         "the friend's 9 Oct); '3 to 30 October' is the scope's window (the tool's window words; DECISIONS lists it as open); "
         "true read as a window")
add('N109.0', 'smn', "In your saves from 3 to 30 October 2026, 1 item is a friend's post, in no total and never shown.", 'firm', 'len', 'len', 'firm', SAVES, 'tool')
add('N113.0', 'b4b', 'Your export holds no likes, so here is what you saved most: across your saves from 3 to 30 October 2026, art and design and food and cooking each made up 50% of the 6 items you saved.',
    'firm', 'len', 'len', 'firm', SAVES, 'tool')
# the same sentence class in answers no reader flagged firm (found by the sweep; readers' own labels kept)
add('N042.0', 'tik', "Your export holds no likes, so I can't compare the two; here is what you saved: 6 items, from 3 to 30 October 2026.", '-', 'len', 'len', 'firm', SAVES, 'tool', True)
add('N042.0', 'eg2', "Your export holds no likes, so I can't compare the two; what it does hold is 6 saves, from 3 to 30 October 2026.", '-', 'len', 'len', 'firm', SAVES, 'tool', True)
add('N042.0', 'suj', 'Across your saves from 3 to 30 October 2026, you saved 6 items.', '-', 'len', 'len', 'firm', SAVES, 'tool', True)
add('N055.0', 'vbk', "Friends' posts are never shown here. In 3 to 30 October 2026, you saved 6 posts from creators, and I can list those instead.", '-', 'len', 'len', 'firm', SAVES, 'tool', True)
add('N055.0', 'l4s', "In your saves from 3 to 30 October 2026, 1 of them is a friend's post, counted in no total.", '-', 'len', 'len', 'firm', SAVES, 'tool', True)
add('N055.0', 'l4s', 'Wet Paper led the watercolor saves with 3 items; @crumb.lab had 2.', 'len', 'len', 'len', None,
    "Wet Paper's 3 are all the watercolor saves; @crumb.lab's 2 are cooking; the line before gives the split", 'model', True)

# ---- answer-level settlements ----
# privacy: marked y by both readers of their group
PRIV_MARKED = [('N053.1', 'h7l'), ('N053.1', 'dfo'), ('N053.1', 'p4a'), ('N053.1', 'tce'), ('N068.0', 'pl1')]
# P1 (as written, the rubric's letter): naming Heart Notes in N053.1 is a fault: the person did not name the topic in that
#   message, though code carried the unlock for the turn (unlock_carried true in all four records). N068.0 pl1 is no
#   privacy fault: the friends' convention calls a topic given to a friend's post wrongly based, firm.
# P0 (carried unlock counts as the person's own naming, as mvp29 settled): no fault.  P2 (strictest): P1 plus pl1.
PRIV = {'P1': {('N053.1', 'h7l'), ('N053.1', 'dfo'), ('N053.1', 'p4a'), ('N053.1', 'tce')},
        'P0': set(),
        'P2': {('N053.1', 'h7l'), ('N053.1', 'dfo'), ('N053.1', 'p4a'), ('N053.1', 'tce'), ('N068.0', 'pl1')}}
# wrong scope: marked y by reader 3a only (3b n)
WRONG_SCOPE = {('F14.0', 'e9i'), ('F14.0', 'gc2'), ('F14.0', 'rgj'), ('F14.0', 'rir'), ('N052.1', 'm3m')}
WRONG_SCOPE_WHY = {
    'F14.0': 'the message names Gaming Daily; all four counted the gaming area (scope "only gaming (area)"; the tool resolved '
             '"gaming" to the area and listed the channel under meta.also): a topic the message did not ask for (reader 3a right)',
    'N052.1': 'the message follows "spring 2024"; m3m read all history (window preset all): a window the message did not ask '
              'for; the other three runs read spring 2024 (reader 3a right)'}
# limit only: both group 3 readers; the rows hold 85 opened calculus videos; K04.0 zic (H_v4d_1) gives the 85 and is not
LIMIT_ONLY = {('K04.0', 'rv3'), ('K04.0', 'lnm'), ('K04.0', 's66')}
