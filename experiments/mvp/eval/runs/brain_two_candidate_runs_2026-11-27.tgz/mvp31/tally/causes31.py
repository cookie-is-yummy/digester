"""Poor answers grouped by what the records show caused them (this tally's grouping, by hand from the records), counted
as the average of the two readers' poor grades (0.5 per reader). Writes causes31.json."""
import json, collections, sys
sys.path.insert(0, '.')
from load import KEY, marks
G = {
 'model: rank, list or count said wrongly over a right result': ['N001.0 m91', 'N034.0 zrz', 'K03.0 p5e', 'N045.0 ceb', 'N045.0 dpc', 'N049.0 l6d', 'N049.0 qme'],
 'model: base, window or event said wrongly': ['N033.1 p0y', 'D10.0 jj3', 'F06.0 dl0', 'N052.1 m3m', 'N005.0 a14', 'N049.0 ze2', 'E04.0 vfm', 'A03.0 b1f', 'N005.0 ecz', 'B14.0 ccu', 'N053.0 rnp'],
 'model: says the opposite of a tool note or of the record': ['N069.0 t4i', 'N069.0 ijg', 'N068.0 pl1', 'D10.1 t3s'],
 'model: misses the question (window, unit or depth chosen by the model)': ['B05.0 zra', 'B05.0 i2y', 'B05.0 rh3', 'B05.0 wkq', 'N057.0 zy8', 'N057.0 mty', 'N045.0 qtj', 'K04.0 zic'],
 'tool and model: the tool resolved "gaming" to the area, the model led with it (F14.0)': ['F14.0 gc2', 'F14.0 e9i', 'F14.0 rir', 'F14.0 rgj'],
 'tool: a cell or window words over another span repeated by the model': ['I03.0 e9g', 'N035.1 l5b', 'N109.0 smn', 'N113.0 b4b'],
 'checker: a true sentence refused, leaving the answer limit only or thin': ['K04.0 rv3', 'K04.0 lnm', 'K04.0 s66', 'F05.0 aph'],
 'code: no private line (the true point that set it off in the other runs was refused)': ['N054.0 a7v'],
 'system talk counted false by one reader; true about the turn (tool gave no earlier window)': ['N001.1 y8p'],
}
M = marks(); BY = collections.defaultdict(dict)
for x in M: BY[(x['message_id'], x['code'])][x['reader']] = x
allpoor = {f'{k} {c}' for (k, c), v in BY.items() if 'poor' in (v['a']['grade'], v['b']['grade'])}
mapped = {i for v in G.values() for i in v}
assert allpoor == mapped, (allpoor - mapped, mapped - allpoor)
out = {}
for g, items in G.items():
    per = collections.Counter()
    for i in items:
        k, c = i.split()
        per[KEY[c]['cell']] += sum(BY[(k, c)][r]['grade'] == 'poor' for r in 'ab') / 2
    out[g] = dict(total=sum(per.values()), per_run=dict(sorted(per.items())), answers=[f"{i} ({KEY[i.split()[1]]['cell']})" for i in items])
    print(f"{g}: {sum(per.values())}; {dict(sorted(per.items()))}")
json.dump(out, open('causes31.json', 'w'), indent=1)
