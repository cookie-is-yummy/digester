from load import *
import collections
P=packets(); M=marks()
BY=collections.defaultdict(dict)
for x in M: BY[(x['message_id'],x['code'])][x['reader']]=x
out=[]
n=0
for (k,c),v in sorted(BY.items()):
    a,b=v['a'],v['b']
    need=[]
    if a['false_n'] or b['false_n']: need.append('false')
    if (a['wb_firm_n'] or b['wb_firm_n']) and a['wb_firm_n']!=b['wb_firm_n']: need.append('wbfirm-diff')
    elif a['wb_firm_n'] and b['wb_firm_n']: need.append('wbfirm-both')
    if 'y' in (a['privacy_fault'],b['privacy_fault']): need.append('privacy')
    if 'y' in (a['wrong_scope'],b['wrong_scope']): need.append('scope')
    if 'y' in (a['limit_only'],b['limit_only']): need.append('limit_only')
    if not need: continue
    n+=1
    ans=[x for x in P[k]['answers'] if x['code']==c][0]
    out.append(f"=== {k} {c} {KEY[c]['cell']} g{P[k]['group']} need={need}")
    out.append("MSG: "+P[k]['message'])
    for t in P[k]['earlier_turns']: out.append("  earlier: "+str(t)[:300])
    out.append("SENT: "+ans['sent'].replace('\n',' | '))
    for r in 'ab':
        x=v[r]
        out.append(f"  [{r}] grade={x['grade']} false={x['false_n']} {x['false_sentences']} firm={x['wb_firm_n']} len={x['wb_lenient_n']} wb={x['wb_sentences']} priv={x['privacy_fault']} lo={x['limit_only']} cause={x['poor_cause']}")
        out.append(f"      note: {x['note']}")
    out.append('')
open('settle_items.txt','w').write('\n'.join(out))
print(n)
