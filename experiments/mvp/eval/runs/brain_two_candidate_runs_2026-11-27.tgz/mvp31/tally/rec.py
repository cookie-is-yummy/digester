import json, sys
from load import *
P=packets()
def show(cell, key, n=2500):
    r=json.load(open(f'{FOLD[cell]}/{key}.json'))
    print('=====', cell, key, '|', r['message'])
    print('screen:', json.dumps(r['screen'])[:1500])
    print('unlock:', r.get('unlock'), 'carried:', r.get('unlock_carried'), 'lead_source', r['lead_source'], 'events', r['events'], 'tool_args', r['tool_args'])
    for c in r['calls']:
        print('CALL', c['round'], c['name'], json.dumps(c['args']))
        print('  RESULT', json.dumps(c.get('result'))[:n])
    print('forms:', json.dumps(r['forms'])[:2000])
    print('dropped:', json.dumps(r['dropped'])[:1500])
    print('answer:', json.dumps(r['answer'])[:1500])
if __name__=='__main__':
    show(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv)>3 else 2500)
