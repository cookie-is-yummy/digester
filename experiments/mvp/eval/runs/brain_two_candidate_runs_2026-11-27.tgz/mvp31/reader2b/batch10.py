K="C09.0"
m(K,"vml","acceptable","y","n","n","y","y",lt=1,lu=0,note="true: every item has one open, 723 opened 5 Jan 2021 to 30 Oct 2026; the limit is the answer; 'runs newest first' is system talk")
m(K,"x2o","acceptable","y","n","n","y","y",lt=1,lu=0,len_=["Your export holds no rewatch counts: none of your 723 opened videos was opened more than once. -- the rows carry a watch count (1 for each); 'no rewatch counts' is loose, the second half is right"],note="newest two named rightly")
m(K,"l69","acceptable","y","n","n","y","y",lt=1,lu=0,note="true; second sentence is filler")
m(K,"aei","acceptable","y","n","n","y","y",lt=1,lu=0,note="true: 0 of 723; second sentence filler")
K="D03.0"
m(K,"hmd","good","y","n","y","y","y",note="all true: Clip Factory 61 of 142, Pan Theory 32 all cooking, Pixel Pencil 29 all drawing")
m(K,"z9s","acceptable","y","n","n","n","y",note="all true; bare list; 'By month?' generic")
m(K,"z57","good","y","n","y","y","y",note="all true")
m(K,"a6u","acceptable","y","n","n","y","y",note="all true; bare list")
K="D03.1"
for c,n in (("tzk","true: latest five October opens, newest first"),("zxb","true; all five cards are YouTube"),("s0v","true: five cards, two Pixel Pencil"),("fbk","true; 'none of these was opened more than once' is filler")):
    m(K,c,"acceptable","y","n","n","y","y",note=n+"; examples only, nothing tying them to the channels just named")
K="D03.2"
m(K,"dnk","acceptable","y","n","n","y","y",note="true: 72 gaming opens in October, latest Gaming clip on the 30th; 'each opened once' is filler")
m(K,"ync","acceptable","y","n","n","y","y",note="true; 'none opened more than once, so newest first' is filler")
m(K,"q4q","acceptable","y","n","y","y","y",note="true: 72; the three shown are Clip Factory Shorts; 'each opened once' filler")
m(K,"j88","acceptable","y","n","y","y","y",note="true: five cards, all Shorts; 'each opened once' filler")
