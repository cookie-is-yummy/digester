K="N053.1"
PN=" Heart Notes named in a follow-up of the turn where the person named the topic; code kept the topic ('only the topic you asked about'), so not marked a privacy fault (judgement call, same for all four)"
m(K,"p4a","acceptable","y","n","n","n","n",note="true: 50 in 2024, 0 in 2023, first 1 Feb 2024; the 366/365-day sentence is padding and 'not over the same length' is beside the point; 'By month?' already given last turn."+PN)
m(K,"dfo","acceptable","y","n","n","n","n",note="true; the day-count sentence adds nothing."+PN)
m(K,"h7l","good","y","n","y","n","y",note="true: 50 vs 0, first 1 Feb 2024, weekdays 36 of 50 = 72%."+PN)
m(K,"tce","acceptable","y","n","n","y","n",note="true; 'the gap is not a matter of length' padding; awkward 'the topic opened 50 items'."+PN)
K="N062.0"
m(K,"kcm","acceptable","y","n","n","n","y",lt=1,lu=0,note="true: history starts 5 Jan 2021; the limit is the answer; nothing more, no offer")
m(K,"kg7","good","y","n","y","n","y",lt=1,lu=0,note="true: starts 2021 with 134 items that year; limit is the answer")
m(K,"pbh","good","y","y","y","y","y",lt=1,lu=0,note="true: 134 in 2021, gaming 94%, led by Minecraft builds")
m(K,"hcf","good","y","n","y","n","y",lt=1,lu=0,note="true: 5 Jan 2021 to 30 Oct 2026, 134 in 2021, 729 items (opened or saved, no private, no friend's post); 'By month?' generic")
K="N063.0"
m(K,"xbb","good","y","n","y","y","y",note="all true for 21-30 Oct: 38, gaming 19 = 50%, Clip Factory 19, art 10 = 26% (drawing 9), cooking 9 all Pan Theory")
m(K,"css","good","y","y","y","y","y",note="all true; the 19 are all Shorts")
m(K,"sfx","good","y","y","y","y","y",note="all true; cooking 9 = 24%")
m(K,"fr8","good","y","y","y","y","y",note="all true; Shorts 19 of 38 YouTube = 50%")
K="N063.1"
m(K,"vya","good","y","y","y","y","y",note="all true: Oct 142, gaming 72, art 34, cooking 32, Clip Factory 61 all Shorts")
m(K,"ogt","good","y","n","y","y","y",note="all true; 72 = 51%")
m(K,"w9h","good","y","y","y","y","y",note="all true")
m(K,"d40","good","y","y","y","n","y",note="all true: art 34 = 24%, cooking 32 = 23%; 'By month?' on a month is generic")
