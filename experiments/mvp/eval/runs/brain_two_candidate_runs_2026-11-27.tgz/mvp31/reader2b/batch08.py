K="A03.0"
m(K,"qtw","acceptable","y","n","n","y","y",lt=1,lu=0,note="all true for 3-30 Oct: 130, Gaming clips 59, cooking 30 = 23%, drawing 27, watercolor 5; a list of themes, no reading")
m(K,"b1f","poor","y","n","y","n","y",firm=["Watercolor painting had 5 videos, a theme new in this window. -- 0 in the 4 weeks before, but watched all through 2025 and up to 26 Aug 2026; said as new"],cause="wrongly based",note="rest true; 'By month?' generic")
m(K,"ofw","acceptable","y","n","n","n","y",note="all true (drawing 27 = 21%); a list, no reading")
m(K,"u62","good","y","y","y","y","y",note="all true: 59 = 45%, cooking 3.9% to 23.1% (+19 points), drawing 56.9% to 20.8% (-36 points)")
K="A05.0"
m(K,"ebf","good","y","n","y","y","y",note="all true: Clip Factory 61 of 142, Pan Theory 32 all Home cooking, Pixel Pencil 29 all Digital drawing")
m(K,"qms","good","y","n","y","y","y",note="all true")
m(K,"joj","acceptable","y","n","n","y","y",note="all true; bare list of three channels")
m(K,"eia","acceptable","y","n","n","n","y",note="all true; bare list; 'By month?' on a month is generic")
K="A06.0"
m(K,"hhl","acceptable","y","n","n","n","y",note="all true: 70 without gaming, Pan Theory 32, Pixel Pencil 29 = 41%; no reading; 'By month?' generic")
m(K,"cnu","acceptable","y","n","n","n","y",note="all true; Limit Lane 4 ties wetpaper.ig 4 (said awkwardly)")
m(K,"il0","acceptable","y","n","n","n","y",note="all true; 'without gaming' said three times")
m(K,"amf","good","y","n","y","n","y",note="all true: 70 across 5 channels, Pan Theory 32 = 46%")
K="B01.0"
m(K,"zh2","good","y","y","y","y","y",lt=1,lu=0,note="all true: 4 weeks to 30 Oct, gaming 64/130 = 49%, up from 27% (+22), clips 59 mostly Clip Factory, art 57% to 25%; export end needed for 'right now'")
m(K,"tvc","good","y","y","y","y","y",lt=1,lu=0,note="all true")
m(K,"jrw","good","y","y","y","n","y",lt=1,lu=0,note="all true: Clip Factory 56 of 59, art 25% led by drawing")
m(K,"hup","good","y","y","y","y","y",lt=1,lu=0,note="all true")
