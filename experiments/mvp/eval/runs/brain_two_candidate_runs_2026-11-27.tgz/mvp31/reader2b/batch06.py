K="N064.0"
m(K,"xpz","good","y","y","y","y","y",note="all true for 1 May-31 Aug 2023: 138, math 135 = 98%, calculus 75 Limit Lane, puzzles 60 Odd Prime, Limit Lane first 3 June 2023")
m(K,"g54","good","y","y","y","y","y",note="all true; window not dated but 'mid 2023' fair")
m(K,"phf","good","y","n","y","y","y",note="all true: cooking 2, gaming 1")
m(K,"wqg","good","y","y","y","y","y",note="all true")
K="N067.0"
m(K,"ck5","good","y","y","y","y","y",lt=1,lu=0,note="limit is the answer (export ends 30 Oct); October 142, gaming 51%, Clip Factory 61, art 24% true")
m(K,"m9e","good","y","y","y","y","y",lt=1,lu=0,note="all true: Gaming clips 66, Clip Factory 61, Pan Theory next channel 32")
m(K,"bhx","good","y","y","y","y","y",lt=1,lu=0,note="all true; evening (17:00-20:59 New York) 95 of 142 = 67%")
m(K,"j6g","acceptable","y","y","y","y","y",lt=1,lu=0,len_=["Home cooking came next with 32 videos, all from Pan Theory. -- true as the second theme and second channel, but it follows an area ('Gaming was 51%') and art (34) is the second area"],note="rest true")
