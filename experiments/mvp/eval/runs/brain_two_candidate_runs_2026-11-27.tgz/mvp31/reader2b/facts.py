import io, contextlib, sys
from lib import *
F = {}
def fact(key):
    def deco(fn): F[key] = fn; return fn
    return deco
def W(*a): print(*a)
@fact("N002.0")
def _():
    summ(ev(kind="watch", plat="youtube"), "YouTube opened, all history, private left out")
    W("  private (dating) YouTube opens:", len(ev(kind="watch", plat="youtube", f=lambda e: e["theme"] == "da", priv=True)))
@fact("N005.0")
def _():
    for th in ("co", "mc"):
        ys = Counter(e["d"].year for e in ev(kind="watch", f=lambda e, th=th: e["theme"] == th))
        W(f"  {TN[th]} opens by year:", dict(sorted(ys.items())))
    W("  only theme in every year 2021-2026: Home cooking (Pan Theory), 72, first 2021-02-01, last 2026-10-30 (NY)")
    W("  all opens (all platforms, no private):", len(ev(kind="watch")), "; 2024 shown 8 + 50 private")
@fact("N005.1")
def _():
    for y in range(2021, 2027):
        es = ev(kind="watch", start=D(y, 1, 1), end=D(y, 12, 31)); g = sum(e["area"] == "gaming" for e in es)
        W(f"  {y}: gaming {g} of {len(es)} opened = {100*g/max(len(es),1):.1f}% (private that year: {len([e for e in EV if e['theme']=='da' and e['d'].year==y])})")
@fact("N010.0")
def _():
    for y in (2025, 2026): summ(ev(kind="watch", start=D(y, 6, 1), end=D(y, 8, 31)), f"summer {y} (1 Jun-31 Aug) opened")
@fact("N010.1")
def _():
    for y in (2025, 2026): summ(ev(kind="watch", start=D(y, 6, 1), end=D(y, 8, 31), f=lambda e: e["area"] == "art"), f"summer {y} art opened")

@fact("N013.0")
def _():
    x = sorted(ev(kind="watch", f=lambda e: e["theme"] == "mc"), key=lambda e: e["t"])
    W("  Minecraft builds opened:", len(x), "channels", Counter(e["ch"] for e in x))
    for e in x[-3:]: W("  last:", e["d"], e["title"][:60])
@fact("N013.1")
def _():
    x = sorted(ev(kind="watch", f=lambda e: e["theme"] == "mc"), key=lambda e: e["t"])
    W("  first:", x[0]["d"], x[0]["title"], x[0]["ch"])
@fact("N014.0")
def _():
    x = sorted(ev(kind="watch", f=lambda e: e["area"] == "cooking"), key=lambda e: e["t"])
    for e in x[-3:]: W("  last cooking:", e["t"], e["title"][:60], e["ch"])

@fact("N034.0")
def _():
    yt = ev(kind="watch", plat="youtube", start=D(2026,1,1))
    summ([e for e in yt if e["length"] and e["length"] > 60], "2026 YouTube long (>60 s) opened")
@fact("N034.1")
def _():
    es = ev(kind="watch", start=D(2026,1,1))
    summ([e for e in es if (e["length"] and e["length"] <= 60) or e["plat"] == "instagram"], "2026 Shorts (40 s) + Instagram reels opened")
@fact("N036.0")
def _():
    x = ev(kind="watch", plat="instagram", start=D(2026,10,1))
    W("  Instagram reels opened in October:", len(x), [(str(e["t"]), e["t"].strftime("%a"), TN[e["theme"]]) for e in x])
    W("  Instagram saves in October (posts, not reels):", [(e["id"], str(e["d"]), e["friend"]) for e in ev(kind="save", friend=True)])
    W("  Instagram export ends 15 Oct 2026")

@fact("N049.0")
def _():
    x = sorted([e for e in EV if "ntegral" in e["title"]], key=lambda e: e["t"])
    W("  titles with 'integral':", len(x), "all Limit Lane:", all(e["ch"] == "Limit Lane" for e in x))
    W("  dates:", [str(e["d"]) for e in x])
@fact("N053.0")
def _():
    d = sorted([e for e in EV if e["theme"] == "da"], key=lambda e: e["t"])
    W("  dating (private; named by the person here): opens", len(d), "days", len({e["d"] for e in d}), "first", d[0]["d"], "last", d[-1]["d"], "channel Heart Notes")
    W("  by month:", sorted(Counter(e["d"].month for e in d).items()), "; one every 4 days, every week 1 Feb-15 Aug had 1 or 2; none Sep-Dec; none in 2023")
    W("  hour 17:00+ New York:", sum(e["t"].hour >= 17 for e in d), "of 50")

@fact("N053.1")
def _():
    d = [e for e in EV if e["theme"] == "da"]
    W("  dating 2024:", sum(e["d"].year == 2024 for e in d), "2023:", sum(e["d"].year == 2023 for e in d), "weekday share 2024:", sum(e["t"].weekday() < 5 for e in d), "of 50")
@fact("N062.0")
def _():
    W("  earliest event:", min(e["d"] for e in EV), "; 2020 rows: 0; 2021 opens:", len(ev(kind="watch", start=D(2021,1,1), end=D(2021,12,31))))
    W("  distinct items, no private, no friend:", len({e["id"] for e in EV if e["theme"] != "da" and not e["friend"]}))
@fact("N063.0")
def _():
    summ(ev(kind="watch", start=D(2026,10,21), end=D(2026,10,31)), "late October (21-30 Oct) opened")
@fact("N063.1")
def _():
    summ(ev(kind="watch", start=D(2026,10,1), end=D(2026,10,31)), "October 2026 opened")

@fact("N064.0")
def _():
    summ(ev(kind="watch", start=D(2023,5,1), end=D(2023,8,31)), "mid 2023 (1 May-31 Aug) opened")
    W("  Limit Lane first ever 2023-06-03, Odd Prime first 2023-06-05")
@fact("N067.0")
def _():
    W("  November 2026: no rows (YouTube ends 30 Oct, Instagram 15 Oct)")
    es = ev(kind="watch", start=D(2026,10,1), end=D(2026,10,31))
    W("  October opened 142; 17:00-20:59 New York:", sum(17 <= e["t"].hour <= 20 for e in es))

@fact("N069.0")
def _():
    x = ev(kind="watch", start=D(2026,10,1), f=lambda e: e["theme"] == "wc")
    W("  watercolor opened in October:", [(str(e["d"]), e["title"], e["plat"], e["ch"]) for e in x])
    W("  rx_love title holds a planted feeling; library holds the full title")
@fact("N109.0")
def _():
    s = [e for e in EV if e["kind"] in ("save", "playlist")]
    W("  saves:", [(e["id"], str(e["d"]), e["plat"], "FRIEND" if e["friend"] else "") for e in s])
    W("  own saves 6 (3 YouTube playlist, 3 Instagram posts), friend's post 1 (never shown, in no total); saves run 3-10 Oct")
@fact("N113.0")
def _():
    W("  like events:", sum(e["kind"] == "like" for e in EV), "; own saves 6: watercolor 3 (Wet Paper), cooking 3 (crumb.lab 2, noodle.nights 1)")
    summ(ev(kind="watch"), "all opens (for 'usually')")

@fact("A03.0")
def _():
    summ(ev(kind="watch", start=D(2026,10,3), end=D(2026,10,30)), "the 4 weeks 3-30 Oct 2026 opened")
    summ(ev(kind="watch", start=D(2026,9,5), end=D(2026,10,2)), "the 4 weeks before (5 Sep-2 Oct)")
    W("  YouTube watercolor last before Oct: 2026-08-26 (not new)")
@fact("A05.0")
def _():
    summ(ev(kind="watch", start=D(2026,10,1), end=D(2026,10,31)), "October 2026 opened")
@fact("A06.0")
def _():
    summ(ev(kind="watch", start=D(2026,10,1), end=D(2026,10,31), f=lambda e: e["area"] != "gaming"), "October 2026 without gaming")
@fact("B01.0")
def _():
    W("  same windows as A03.0: gaming 64/130 = 49.2% vs 14/51 = 27.5% before; art 32/130 = 24.6% vs 29/51 = 56.9%")

@fact("B14.0")
def _():
    yt = ev(kind="watch", plat="youtube")
    W("  all opens", len(ev(kind="watch")), "; YouTube", len(yt), "Shorts (40 s)", sum(e["length"] == 40 for e in yt), "known long", sum((e["length"] or 0) > 60 for e in yt), "no length", sum(e["length"] is None for e in yt), "; Instagram reels 4")
    W("  Shorts by channel", Counter(e["ch"] for e in yt if e["length"] == 40), "; all in 2026 (first 1 Oct); 2026 opens 254")
@fact("C01.0")
def _():
    W("  October channels:", Counter(e["ch"] for e in ev(kind="watch", start=D(2026,10,1))).most_common())
@fact("C04.0")
def _():
    summ(ev(kind="watch", f=lambda e: e["t"].weekday() == 6), "Sundays (New York) all history opened")
    W("  private Sunday opens:", len(ev(kind="watch", priv=True, f=lambda e: e["t"].weekday() == 6)) - 101)

@fact("C09.0")
def _():
    c = Counter(e["id"] for e in EV if e["kind"] == "watch")
    W("  most opens of one item:", max(c.values()), "; opened items 723 (no private)")
    x = sorted(ev(kind="watch"), key=lambda e: e["t"])[-3:]
    W("  newest:", [(str(e["t"]), e["title"]) for e in x])
@fact("D03.0")
def _():
    W("  as A05.0: Clip Factory 61, Pan Theory 32, Pixel Pencil 29 of 142")
@fact("D03.1")
def _():
    x = sorted(ev(kind="watch", start=D(2026,10,1)), key=lambda e: e["t"])[-5:]
    W("  latest five October opens:", [(str(e["t"]), e["title"], e["ch"]) for e in x][::-1])
@fact("D03.2")
def _():
    x = sorted(ev(kind="watch", start=D(2026,10,1), f=lambda e: e["area"] == "gaming"), key=lambda e: e["t"])
    W("  October gaming opens:", len(x), Counter(e["ch"] for e in x), "latest five:", [(str(e["d"]), e["title"], e["length"]) for e in x[-5:]][::-1])

@fact("D10.0")
def _():
    summ(ev(kind="watch", start=D(2026,10,3), end=D(2026,10,30)), "the 4 weeks 3-30 Oct 2026 opened")
@fact("D10.1")
def _():
    es = ev(kind="watch", start=D(2026,10,3), end=D(2026,10,30)); yt = [e for e in es if e["plat"] == "youtube"]
    sh = sum(e["length"] == 40 for e in yt)
    W("  gaming", sum(e["area"] == "gaming" for e in es), "of", len(es), "by channel", Counter(e["ch"] for e in es if e["area"] == "gaming"))
    W("  Shorts", sh, "of YouTube", len(yt), f"= {100*sh/len(yt):.1f}%; of all opened {100*sh/len(es):.1f}%")

@fact("F03.0")
def _():
    W("  2019 rows: 0; earliest", min(e["d"] for e in EV))
@fact("F09.0")
def _():
    x = ev(kind="watch", f=lambda e: e["theme"] == "mc")
    W("  Minecraft builds channels:", Counter(e["ch"] for e in x), "first", min(e["d"] for e in x), "last", max(e["d"] for e in x), "; YouTube-wide popularity: not in the record")

@fact("F15.0")
def _():
    x = sorted(ev(kind="watch", f=lambda e: e["theme"] == "ca"), key=lambda e: e["t"])
    W("  Calculus lessons opened:", len(x), "lengths", Counter(e["length"] for e in x), "latest", [(str(e["d"]), e["title"]) for e in x[-2:]])
@fact("G03.0")
def _():
    W("  Wet Paper in October:", [(str(e["d"]), e["kind"], e["title"]) for e in EV if e["ch"] == "Wet Paper" and e["d"] >= D(2026,10,1)])
@fact("I01.0")
def _():
    c = ev(kind="watch", start=D(2024,1,1), end=D(2024,12,31))
    W("  2024 shown:", len(c), Counter(TN[e["theme"]] for e in c), "private 50; shown hours", Counter(e["t"].hour for e in c))
if __name__ == "__main__":
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        for k, fn in F.items():
            print("=" * 80); print(k); fn()
    open("facts.txt", "w").write(out.getvalue()); print(out.getvalue()[-1500:])
