K="N002.0"
for c in ("az3","iri"):
    m(K,c,"acceptable","y","n","y","y","y",note="all figures true (719 YT, 44/25/20/10%, 163 Brick Realm); lists areas and themes with no reading of what they say about the person")
m(K,"nfc","acceptable","y","n","n","y","y",note="all true; flat list of shares, no reading")
m(K,"zy0","acceptable","y","n","n","n","y",note="all true; flat list; 'By month?' over all history is generic")
K="N005.0"
m(K,"ecz","poor","y","y","y","y","n",firm=["Your history has few items in 2024: 8 in all, so the run is not unbroken across every year for every channel. -- 2024 holds 58 opens, 50 of them private; reads past the private line (quiet-year reading)"],cause="wrongly based",note="lead true (Pan Theory every year, 1 Feb 2021 to 30 Oct 2026, 72); Brick Realm point true; third point garbled and reads past the private line")
m(K,"a14","poor","y","y","y","n","y",firm=["Brick Realm also runs the whole export: first watched on 5 January 2021, last on 20 October 2026, with 163 videos. -- dates true, but said as a run across the whole export in answer to 'every year': Brick Realm has nothing in 2023, 2024 or 2025"],cause="wrongly based",note="lead and Pan Theory point true; 'By month?' generic here")
m(K,"xjy","good","y","y","y","y","y",note="all true: only theme every year, 72 of 723 opened (all platforms) = 10%, first/last dates right")
m(K,"dwd","good","y","y","n","n","y",note="all true; 'By month?' generic on a six-year answer")
K="N005.1"
m(K,"kvx","good","y","y","y","n","y",note="all true: 2021 126/134 = 94%, 2022 100/108 = 93%, Minecraft 163; no private line needed (2021/2022 hold no private rows); 'By month?' generic")
m(K,"yoc","good","y","y","y","n","y",note="all true incl. 2026 79 of 254; 'By month?' generic")
m(K,"ndr","good","y","y","y","y","y",note="all true: 2023 14, 2024 0, 2026 79; gives the arc")
m(K,"tuy","good","y","y","y","n","y",note="all true: 0 in 2024 and 2025, 79 in 2026, 14 of 157 in 2023")
K="N010.0"
m(K,"hhv","good","y","y","y","y","y",note="all true: 45 vs 16, drawing 32 new, watercolor 14 to 13")
m(K,"a4f","good","y","y","y","y","y",note="all true; 'whole window sits in art and design' true of this summer")
m(K,"d6r","acceptable","y","y","y","n","y",note="all true; no offer")
m(K,"hmm","good","y","y","y","y","y",note="all true")
K="N010.1"
for c in ("sqx","d1o","mgq"):
    m(K,c,"good","y","y","y","y","y",note="all true: art 45 vs 14, drawing 32 from Pixel Pencil first 1 Aug 2026, watercolor 13 vs 14")
m(K,"e6f","good","y","y","y","y","y",note="all true; 32 of 45 = 71%")
