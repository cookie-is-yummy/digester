K="B14.0"
m(K,"ccu","acceptable","y","y","y","n","y",len_=["Over all your history, 66 of the 723 videos you opened were Shorts, a share of 9%; the other 651 were long videos. -- 651 are the YouTube videos known to be long; 723 - 66 = 657 (2 calculus videos have no length, 4 are Instagram reels), so 'the other' does not add up; small and the share is right"],note="rest true: all Shorts in Gaming clips, Clip Factory 61, 2026 26% vs none before; 'And in 2026?' repeats the 2026 point")
m(K,"aoo","good","y","y","y","n","y",note="all true: 66 of 723 = 9%, 651 long, 26% in 2026; 'And in 2026?' repeats")
m(K,"zez","acceptable","y","n","n","y","y",len_=["Across all your history, 66 of the 723 videos you opened were Shorts, which is 9% of your YouTube videos; 651 were long. -- 723 counts the 4 Instagram reels, then the share is called 'of your YouTube videos' (719); 9% either way"],note="thin")
m(K,"nv4","good","y","y","y","n","y",note="all true: 651 of 723 long, 66 Shorts = 9%, Shorts on Clip Factory and Gaming Daily, Clip Factory first 1 Oct 2026, Minecraft 163 biggest long theme; 'By month?' generic")
K="C01.0"
FIVE="the five least-opened are Wet Paper 1, Limit Lane 4, wetpaper.ig 4, Gaming Daily 5, Brick Realm 6; four are named"
m(K,"vk4","acceptable","y","n","n","n","y",len_=["Brick Realm had 6 videos, the most of these five channels. -- "+FIVE],note="counts true; leaves out the Instagram account tied at 4; 'By month?' generic")
m(K,"n7o","acceptable","y","n","n","y","y",note="true: Wet Paper 1, Limit Lane 4, Gaming Daily 5; leaves out wetpaper.ig tied at 4 (no rank claimed over it)")
m(K,"jx6","good","y","n","y","y","y",note="true: Wet Paper 1, Limit Lane 4 all calculus, Gaming Daily 5 all Shorts; leaves out wetpaper.ig tied at 4 (no rank claimed)")
m(K,"maz","acceptable","y","n","y","y","y",len_=["Brick Realm had 6 videos, the most of these five channels. -- "+FIVE+" (Gaming Daily left out)"],note="tie of Limit Lane and the Instagram watercolor account at 4 said rightly")
K="C04.0"
m(K,"d8b","good","y","n","y","y","y",note="all true (New York weekday): 101, gaming 45%, Brick Realm 23 all Minecraft, art 25%, math 20%; private line shown (7 private Sunday opens)")
m(K,"f03","good","y","n","y","y","y",note="all true; Pixel Pencil 13 of art's 25 ('mostly', a slim majority over Wet Paper 12)")
m(K,"j45","good","y","n","y","y","y",note="all true")
m(K,"tal","good","y","n","y","y","y",note="all true")
