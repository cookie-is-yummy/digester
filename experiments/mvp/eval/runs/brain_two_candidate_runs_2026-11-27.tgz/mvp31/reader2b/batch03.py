K="N034.0"
m(K,"zrz","poor","y","y","y","y","y",firm=["Home cooking came next with 32 videos from Pan Theory. -- after Digital drawing (92) the next theme is Watercolor painting (37); 32 is real but given the wrong rank, and watercolor is left out"],cause="wrongly based",note="lead true (art 129 of 184 long = 70%); drawing 92 true; Minecraft 13, Calculus 10 true")
m(K,"s0m","acceptable","y","y","y","y","y",len_=["Home cooking came next in food and cooking with 32 videos, from Pan Theory. -- reads as the next area (food and cooking, 32) with its one theme; watercolor 37 is the next theme"],note="lead and drawing true; 'Only long videos?' repeats, 'By month?' fine")
m(K,"nyx","good","y","y","y","n","y",note="all true; 'Only long videos?' repeats what was shown")
m(K,"exk","good","y","y","y","y","y",note="all true: 129 of 184, drawing 92 = 50%, watercolor 37, cooking 32, Minecraft 13, calculus 10")
K="N034.1"
m(K,"n6j","good","y","y","y","n","y",note="all true: 70 Shorts and reels, gaming 66 = 94%, Clip Factory 61, 4 watercolor reels; 'Only long videos?' repeats the turn before")
m(K,"yrf","good","y","y","y","n","y",note="all true incl. the 4 on Instagram")
m(K,"lrh","acceptable","y","n","n","n","y",note="all true; thin, no theme named for the 94%")
m(K,"scj","good","y","y","y","n","y",note="all true; 61 of 70 = 87%, base named")
K="N036.0"
m(K,"h91","acceptable","y","y","y","y","y",lt=1,lu=0,len_=["All 4 of your Instagram items in that window were from Watercolor painting, opened on weekdays in the morning. -- true of the 4 reels opened; 'your Instagram items' leaves out the cooking posts saved 5-10 Oct, but the 4 and the scope line tie it to opens"],note="4 reels 12-15 Oct (Mon-Thu, 08:00 New York) true; export end said once, needed")
m(K,"ola","acceptable","y","y","y","y","n",lt=2,lu=1,note="all true; the Instagram end is said twice (lead and a point)")
m(K,"c5j","acceptable","y","n","n","y","y",lt=1,lu=0,note="true; bare count, no theme")
m(K,"fva","good","y","y","y","y","y",lt=1,lu=0,note="all true: 4, all watercolor, one channel (wetpaper.ig); export end needed here")
