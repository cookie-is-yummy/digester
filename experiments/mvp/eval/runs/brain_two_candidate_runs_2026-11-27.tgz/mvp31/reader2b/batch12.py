K="F03.0"
m(K,"w5m","acceptable","y","n","n","n","y",lt=1,lu=0,note="true: history starts 5 Jan 2021; the limit is the answer; no offer, nothing more")
m(K,"pry","acceptable","y","n","n","y","y",lt=1,lu=0,note="true; limit is the answer; nothing more")
m(K,"rku","acceptable","y","n","n","y","y",lt=1,lu=0,note="true; limit is the answer; nothing more")
m(K,"p2d","acceptable","y","n","n","y","y",lt=1,lu=0,note="true; limit is the answer; nothing more")
K="F09.0"
m(K,"io7","good","y","y","y","y","y",lt=1,lu=0,note="true: popularity on YouTube is outside the record (said once); Brick Realm the only Minecraft channel, 163, 5 Jan 2021 to 20 Oct 2026")
m(K,"zbh","good","y","y","y","y","y",lt=1,lu=0,note="all true")
m(K,"yrm","good","y","y","y","y","y",lt=1,lu=0,note="all true")
m(K,"e61","acceptable","y","y","y","y","y",lt=1,lu=0,len_=["All 163 of your Minecraft builds videos on YouTube came from Brick Realm, from 5 January 2021 to 30 October 2026. -- the last Brick Realm open is 20 Oct 2026 (said in the next point); 30 Oct is the export's end"],note="rest true")
