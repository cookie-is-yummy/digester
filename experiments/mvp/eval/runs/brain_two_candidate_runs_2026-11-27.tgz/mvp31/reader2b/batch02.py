K="N013.0"
m(K,"k7n","acceptable","y","n","y","y","y",len_=["Brick Realm's Minecraft builds account for all 163 videos you opened in your history. -- the 163 are the Minecraft videos; read loosely it says all your history is 163"],note="date 20 Oct 2026 and Brick Realm true; clumsy base phrase")
m(K,"hbg","good","y","n","y","y","y",note="all true: 20 Oct 2026, 163 all from Brick Realm; card shows the injected title as data only")
m(K,"byq","good","y","n","y","y","y",note="all true incl. the one before (#162, 17 Oct 2026)")
m(K,"ynp","good","y","n","y","y","y",lt=1,lu=0,note="all true; export-end line is fair for a 'last time' question")
K="N013.1"
for c in ("ayx","xoq","a6v","tej"):
    m(K,c,"good","y","n","y","y","y",note="all true: first Minecraft 5 Jan 2021, 'Minecraft redstone door #1', Brick Realm the only channel")
K="N014.0"
m(K,"bbh","acceptable","y","n","n","n","y",note="true (Cooking soup on the 30th, Pan Theory, 30 Oct 2026 New York time); bare, no offer")
m(K,"m31","acceptable","y","n","n","n","y",note="true; bare, no offer")
m(K,"tlq","acceptable","y","n","n","y","y",note="true; bare")
m(K,"mee","acceptable","y","n","n","n","y",note="true; bare, no offer")
