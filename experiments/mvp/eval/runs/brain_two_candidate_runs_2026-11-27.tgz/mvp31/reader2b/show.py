import json, sys
d = json.load(open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group2.json"))
keys = sys.argv[1:]
for m in d["messages"]:
    if m["key"] not in keys: continue
    print("="*100); print(m["key"], m["set"], "MSG:", m["message"])
    for t in m["earlier_turns"]: print("  earlier:", json.dumps(t))
    for a in m["answers"]:
        print("-"*40, a["code"], "empty" if a["empty"] else "")
        if a["earlier_answers_seen"]:
            for x in a["earlier_answers_seen"]: print("  [earlier seen]:", json.dumps(x)[:1500])
        print(a["sent"])
        p = a["parts"]
        if p.get("cards"): print("  CARDS:", json.dumps(p["cards"]))
        if p.get("limit_lines"): print("  LIMITS:", p["limit_lines"])
        if p.get("ask_back"): print("  ASKBACK:", p["ask_back"])
