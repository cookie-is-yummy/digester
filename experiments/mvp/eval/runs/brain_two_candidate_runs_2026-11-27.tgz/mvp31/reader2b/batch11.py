K="D10.0"
m(K,"zte","good","y","n","y","y","y",lt=1,lu=0,note="all true for 3-30 Oct: gaming 49%, clips 59, art 25% (drawing 27), cooking 23% (Pan Theory 30)")
m(K,"efo","good","y","y","y","y","y",note="all true: 56 of 59 clips from Clip Factory, art mostly drawing (27 of 32), cooking all Pan Theory")
m(K,"jj3","poor","y","y","y","y","y",firm=["Pan Theory made 30 videos, all in Home cooking, which was 23% of what you opened in food and cooking. -- 23% is 30 of all 130 opened; said of what you opened in food and cooking, where it is 100%"],cause="wrongly based",note="lead and the two moves (+22 points, art 57% to 25%) true")
m(K,"nas","acceptable","y","n","n","y","y",note="all true: 64 of 130, art 32 = 25%, cooking 30 = 23%; areas only, no themes or channels")
K="D10.1"
m(K,"t3s","poor","y","y","y","y","y",false=["Thanks for the correction. In the 4 weeks up to 30 October 2026, gaming was 49% of what you opened, 64 of 130 videos, so my last answer was wrong to leave it out. -- its last answer led with gaming at 49%; nothing was left out, and it thanks the person for a correction the rows do not bear out"],len_=["Gaming clips was 100% Shorts, against 47% Shorts across everything you opened. -- 59 of the 126 YouTube videos = 47%; of all 130 opened it is 45%"],cause="wrong fact",note="figures 64 of 130, 59, 56 true")
m(K,"iwz","good","y","y","y","y","y",note="true: 56 of 64 gaming from Clip Factory, all Shorts; holds to the rows plainly")
m(K,"ei9","good","y","y","y","y","y",note="true: 64 of 130, Clip Factory 56 all Shorts, Brick Realm 5")
m(K,"zo9","good","y","y","y","y","y",lt=1,lu=0,note="true; 'I can only go by the export' is fair framing for a dispute")
