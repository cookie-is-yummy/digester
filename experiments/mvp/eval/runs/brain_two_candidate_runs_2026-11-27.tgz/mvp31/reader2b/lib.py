import sys
sys.path.insert(0, "/home/user/digester/experiments")
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter, defaultdict
from mvp.tests import brain_library as B
NY = ZoneInfo("America/New_York")
TN = {"mc":"Minecraft builds","sr":"Speedruns","cl":"Gaming clips","wc":"Watercolor painting","dd":"Digital drawing",
      "ca":"Calculus lessons","np":"Number puzzles","co":"Home cooking","da":"Dating advice (PRIVATE)"}
AREA = {"mc":"gaming","sr":"gaming","cl":"gaming","wc":"art","dd":"art","ca":"math","np":"math","co":"cooking","da":"dating(PRIVATE)"}
ROWS = B.rows()
EV = []  # one per event
for r in ROWS:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=k, t=t, d=t.date(), plat=r["platform"], theme=r["theme"], area=AREA[r["theme"]],
                       ch=r.get("channel") or r.get("handle"), title=r["caption"], length=r["length"],
                       friend=r.get("friend", False), pub=r["published"], media=r.get("media")))
def ev(kind=None, plat=None, start=None, end=None, priv=False, friend=False, f=None):
    out = []
    for e in EV:
        if kind and e["kind"] != kind: continue
        if plat and e["plat"] != plat: continue
        if start and e["d"] < start: continue
        if end and e["d"] > end: continue
        if not priv and e["theme"] == "da": continue
        if not friend and e["friend"]: continue
        if f and not f(e): continue
        out.append(e)
    return out
def summ(es, label=""):
    n = len(es)
    a = Counter(e["area"] for e in es); t = Counter(TN[e["theme"]] for e in es); c = Counter(e["ch"] for e in es)
    print(f"--- {label}: n={n}")
    print("  areas:", [(k, v, f"{100*v/n:.1f}%") for k, v in a.most_common()] if n else [])
    print("  themes:", [(k, v, f"{100*v/n:.1f}%") for k, v in t.most_common()] if n else [])
    print("  channels:", [(k, v) for k, v in c.most_common()])
    if n:
        ds = sorted(e["d"] for e in es); print("  first", ds[0], "last", ds[-1])
from datetime import date as D
