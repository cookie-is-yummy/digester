import json, sys, os, runpy
HERE = os.path.dirname(os.path.abspath(__file__))
MP = os.path.join(HERE, "marks.json")
PK = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group2.json"
CAUSES = {"wrong fact", "misses the question", "thin", "wrongly based", "wrong scope", "limits not said",
          "says too much about limits", "limit only", "bare fallback", "other"}
OUT = []
def m(key, code, grade, ans, means, more, offer, brief, false=(), firm=(), len_=(), scope="n", lo="n", priv="n",
      lt=0, lu=0, cause=None, note=""):
    wb = [f"[firm] {s}" for s in firm] + [f"[lenient] {s}" for s in len_]
    OUT.append(dict(message_id=key, code=code, grade=grade, false_n=len(false), false_sentences=list(false),
                    wb_firm_n=len(firm), wb_lenient_n=len(len_), wb_sentences=wb, wrong_scope=scope, limit_only=lo,
                    privacy_fault=priv, answers=ans, means=means, more=more, offer=offer, brief=brief,
                    limits_talk=lt, limits_unwanted=lu, poor_cause=cause, note=note))
def check(r):
    e = []
    if r["grade"] not in ("good", "acceptable", "poor"): e.append("grade")
    for k in ("wrong_scope", "limit_only", "privacy_fault", "answers", "means", "more", "offer", "brief"):
        if r[k] not in ("y", "n"): e.append(k)
    must_poor = r["false_n"] > 0 or r["wb_firm_n"] > 0 or r["answers"] == "n" or r["limit_only"] == "y"
    if must_poor and r["grade"] != "poor": e.append("must be poor")
    if r["grade"] == "poor":
        if not r["poor_cause"]: e.append("poor needs cause")
        else:
            for c in r["poor_cause"].split(";"):
                if c.strip() not in CAUSES: e.append("bad cause " + c)
    elif r["poor_cause"]: e.append("cause on non-poor")
    if r["limits_unwanted"] > r["limits_talk"]: e.append("lu>lt")
    return e
if __name__ == "__main__":
    for f in sys.argv[1:]:
        g = runpy.run_path(f, init_globals={"m": m})
    pk = json.load(open(PK))
    valid = {(x["key"], a["code"]) for x in pk["messages"] for a in x["answers"]}
    marks = json.load(open(MP)) if os.path.exists(MP) else []
    idx = {(r["message_id"], r["code"]): i for i, r in enumerate(marks)}
    bad = False
    for r in OUT:
        k = (r["message_id"], r["code"])
        if k not in valid: print("NOT IN PACKET", k); bad = True; continue
        er = check(r)
        if er: print("ERR", k, er); bad = True; continue
        if k in idx: marks[idx[k]] = r
        else: idx[k] = len(marks); marks.append(r)
    if bad: print("not saved"); sys.exit(1)
    json.dump(marks, open(MP + ".tmp", "w"), indent=1); os.replace(MP + ".tmp", MP)
    done = {(r["message_id"], r["code"]) for r in marks}
    print("saved", len(marks), "marks;", len(valid - done), "pairs left;",
          "msgs done:", len({k for k, _ in done}))
