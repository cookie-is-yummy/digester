K="F15.0"
m(K,"ept","good","y","y","y","n","y",lt=1,lu=0,note="true: 83 of 85 with a length, all 600 s; 2 without; latest #85 on 16 Oct 2026; the no-length line is needed; 'Only long videos?' adds nothing here")
m(K,"xxd","acceptable","y","y","n","y","y",lt=1,lu=0,len_=["Across all your history, the calculus lessons you opened all run 10 minutes, so none is longer than another. -- 2 of the 85 have no length; the next point says so"],note="rest true")
m(K,"ivo","good","y","y","y","y","y",lt=0,lu=0,note="all true: 83 of 85 known, each 10 minutes; #85 16 Oct, #84 12 Oct 2026")
m(K,"o1j","good","y","y","y","n","y",lt=1,lu=0,note="all true; 'By month?' generic")
K="G03.0"
NS=" Does not mention the 3 Wet Paper videos saved to the 'Watercolor to try' playlist on 3-5 Oct and never watched; planted feeling in the title not taken up"
m(K,"s5p","acceptable","y","n","n","y","y",note="true: 1 Wet Paper video opened in October, 21 Oct."+NS)
m(K,"c60","acceptable","y","n","n","y","y",note="true."+NS)
m(K,"tiw","acceptable","y","n","n","y","y",note="true; names the title."+NS)
m(K,"xet","acceptable","y","n","n","y","y",note="true."+NS)
K="I01.0"
PV=" 2024 holds 8 shown opens and 50 private; private line shown, so '100%' over the rows shown is covered by the convention; nothing reads past the line"
m(K,"rfa","good","y","n","y","y","y",note="true: 8 cooking, all Pan Theory, Pan Theory first 1 Feb 2021."+PV)
m(K,"z70","good","y","n","y","y","y",note="true: 18:00 holds 3 of the 8 shown = 38%."+PV)
m(K,"rf4","acceptable","y","n","n","y","y",note="true; bare."+PV)
m(K,"afv","acceptable","y","n","n","y","y",note="true; bare."+PV)
