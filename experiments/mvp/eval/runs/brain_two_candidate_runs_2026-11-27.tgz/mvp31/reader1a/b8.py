from mk import M, save
F5="Gaming clips: 66 opens, all YouTube Shorts (40 s), 1-30 Oct 2026, on 30 days; Clip Factory 61, Gaming Daily 5; evening 45 of 66 = 68%; 66 of 723 opens without private rows = 9%."
F6="4 weeks to 30 Oct: gaming 64 of 130 (49%), 14 of 51 (27%) the 4 weeks before; Clip Factory 56 (5 before); Gaming clips 59 (7 before), Shorts 59 of 64 = 92%; Minecraft builds 5 (7 before), last 20 Oct."
F8="No subscriber counts in the library: the limit is the answer. Brick Realm: 163 opens, all Minecraft builds, 91 in 2021, 59 in 2022, none 2023-2025, 13 in 2026; first 5 Jan 2021, last 20 Oct 2026; no likes, no saves."
F10="No forecast possible; the latest 4 weeks are the fair basis: gaming 49%, Clip Factory 56 of 130, Pan Theory 30, Pixel Pencil 27."
save([
M("F05.0","sav","good",note=F5+" Facts only, no verdict on the person."),
M("F05.0","cy4","good",lt=1,lu=0,note=F5+" One line on what the record cannot judge, called for; private line shown with 723."),
M("F05.0","eu5","good",note=F5),
M("F05.0","aph","poor",ans="n",means="n",cause="thin",note=F5+" A bare total; says nothing on how much or how often."),
M("F06.0","kfr","acceptable",lt=1,lu=0,wb=[("Clip Factory supplied 56 of the gaming videos you opened, 92% of them Shorts.","lenient","'them' reads as Clip Factory's videos (all are Shorts); 92% is of the 64 gaming videos")],note=F6+" Export-end line is fair for 'quit', said as of today."),
M("F06.0","dl0","poor",wb=[("Your gaming opens were 0 in Feb 2026 and 7 in Sep 2026, after 319 gaming videos since January 2021.","firm","319 is all gaming opens, including October 2026's 72 and September's 7; said as coming before Feb 2026, where 240 did")],cause="wrongly based",note=F6),
M("F06.0","r81","good",lt=1,lu=0,note=F6+" 27% before (14 of 51) true."),
M("F06.0","sdw","good",note=F6+" up 22 points true."),
M("F08.0","nex","good",lt=1,lu=0,more="y",note=F8),
M("F08.0","k79","good",lt=1,lu=0,more="y",note=F8),
M("F08.0","kik","acceptable",means="n",lt=1,lu=0,wb=[("In your history, Brick Realm has 163 items you opened, liked or saved.","lenient","all 163 are opens; there are no likes or saves of it, but the union count is right")],note=F8+" Thin: no points."),
M("F08.0","ebk","good",lt=1,lu=0,more="y",note=F8),
M("F10.0","dp1","acceptable",means="n",lt=1,lu=0,note=F10+" True, but does not turn the recent mix into a 'likely next' reading."),
M("F10.0","w29","acceptable",means="n",lt=1,lu=0,note=F10+" True; 'almost all from Clip Factory' 56 of 59 true; no 'likely next' reading."),
M("F10.0","cco","acceptable",means="n",lt=1,lu=0,note=F10+" True; lower-case theme names; 'since your export ends' is not the reason it cannot predict."),
M("F10.0","d4y","acceptable",means="n",lt=1,lu=0,note=F10+" True; point 2 repeats the lead as a share."),
])
