import json, os, sys
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "marks.json")
FIELDS = ["message_id", "code", "grade", "false_n", "false_sentences", "wb_firm_n", "wb_lenient_n", "wb_sentences",
          "wrong_scope", "limit_only", "privacy_fault", "answers", "means", "more", "offer", "brief", "limits_talk",
          "limits_unwanted", "poor_cause", "note"]
def load():
    try:
        return json.load(open(OUT))
    except Exception:
        return []
def M(mid, code, grade, ans="y", means="y", more="n", offer="y", brief="y", lt=0, lu=0, false=(), wb=(),
      scope="n", lonly="n", priv="n", cause=None, note=""):
    """wb: list of (sentence, 'firm'|'lenient', why)."""
    return {"message_id": mid, "code": code, "grade": grade, "false_n": len(false), "false_sentences": list(false),
            "wb_firm_n": sum(1 for w in wb if w[1] == "firm"), "wb_lenient_n": sum(1 for w in wb if w[1] == "lenient"),
            "wb_sentences": [f"{w[1]}: {w[0]} -- {w[2]}" for w in wb], "wrong_scope": scope, "limit_only": lonly,
            "privacy_fault": priv, "answers": ans, "means": means, "more": more, "offer": offer, "brief": brief,
            "limits_talk": lt, "limits_unwanted": lu, "poor_cause": cause if grade == "poor" else None, "note": note}
def save(new):
    cur = {(m["message_id"], m["code"]): m for m in load()}
    for m in new:
        cur[(m["message_id"], m["code"])] = m
    json.dump(list(cur.values()), open(OUT, "w"), indent=1)
    print("saved", len(cur))
