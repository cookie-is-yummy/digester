from mk import M, save
IG="Instagram opens are 4 reels, 12 to 15 Oct 2026 (first Instagram event a save on 5 Oct 2026); 2022 has 108 opens, all YouTube. The limit is the answer and is true. None says what Instagram does hold, so flat."
E4="This year (1 Jan-30 Oct 2026) no channel of 2025 is missing (Wet Paper and Pan Theory both continue). Wet Paper 37 this year vs 45 in 1 Jan-30 Oct 2025 (54 in all 2025); Watercolor painting 87% of 2025, 16% of 2026 (41 of 254)."
save([
M("D04.1","kcz","acceptable",means="n",lt=1,lu=0,note=IG),
M("D04.1","ohu","acceptable",means="n",lt=1,lu=0,note=IG+" 'left out of this ranking' is system talk."),
M("D04.1","hrg","acceptable",means="n",lt=1,lu=0,note=IG),
M("D04.1","hgn","acceptable",means="n",lt=1,lu=0,note=IG),
M("E04.0","efa","good",more="y",note=E4+" 'the only channel that fell' true (Pan Theory rose; others are new)."),
M("E04.0","vfm","poor",false=["The one channel that fell in count is Wet Paper, with 40 videos this year against 45 in 2025, down 5 videos."],cause="wrong fact",note=E4+" Wet Paper had 37 this year (41 with the Instagram account); 40 fits no reading, and 45 is only the same stretch of 2025. '17% this year' (16.1%) is within a point, not counted."),
M("E04.0","ycu","acceptable",more="y",note=E4+" True; 'the stopped list is empty' is system talk."),
M("E04.0","a8h","acceptable",more="y",note=E4+" True; 'the stopped list is empty' is system talk."),
M("F02.0","p6w","acceptable",means="n",lt=1,lu=0,more="y",note="Yesterday (21 Nov) is past the export end: the limit is the answer. 30 Oct (NY): 4 videos, Pixel Pencil 2, Clip Factory 1, Pan Theory 1: true. Points repeat the cards by title."),
M("F02.0","hfp","good",means="n",lt=1,lu=0,more="y"),
M("F02.0","uz4","good",means="n",lt=1,lu=0,more="y"),
M("F02.0","u49","good",means="n",lt=1,lu=0,more="y",note="Names the themes."),
M("F04.0","o8i","good",lt=1,lu=0,note="Why: the record has no reasons; one line says so and gives the stop (last 1 May 2023, 90 from Frame Perfect, 1 Mar 2021 to 1 May 2023). No motive guessed."),
M("F04.0","vnc","good",lt=1,lu=0,note="Every month Mar 2021-Apr 2023 (3 to 4 each), 1 in May 2023: true; shows a steady habit that stopped at once."),
M("F04.0","nis","good",lt=1,lu=0,more="y",note="35/41/14 by year true; evenings 59 of 90 = 66% true."),
M("F04.0","qub","good",lt=1,lu=0),
])
