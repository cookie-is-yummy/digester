import sys
sys.path.insert(0, "/home/user/digester/experiments")
from datetime import datetime, date
from zoneinfo import ZoneInfo
from collections import Counter, defaultdict
from mvp.tests import brain_library as B

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art", "dd": "art", "ca": "math", "np": "math",
        "co": "food", "da": "relationships(PRIVATE)"}
ROWS = B.rows()
EV = []  # one per event
for r in ROWS:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=k, t=t, d=t.date(), theme=r["theme"], area=AREA[r["theme"]],
                       plat=r["platform"], ch=r.get("channel") or r.get("handle"), length=r["length"],
                       friend=bool(r.get("friend")), cap=r["caption"], private=r["theme"] == "da"))

def sel(kind="watch", d0=None, d1=None, pred=None, friends=False):
    out = []
    for e in EV:
        if kind and e["kind"] not in (kind if isinstance(kind, tuple) else (kind,)):
            continue
        if not friends and e["friend"]:
            continue
        if d0 and e["d"] < d0: continue
        if d1 and e["d"] > d1: continue
        if pred and not pred(e): continue
        out.append(e)
    return out

def tally(evs, key="theme", show=True):
    c = Counter(e[key] for e in evs)
    n = sum(c.values())
    rows = [(THEME.get(k, k) if key == "theme" else k, v, round(100 * v / n, 1) if n else 0) for k, v in c.most_common()]
    return n, rows

def D(s): return date.fromisoformat(s)
