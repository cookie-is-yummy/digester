"""Corrections after the evenness pass (run after b1..b8)."""
import json
from mk import OUT
mk = json.load(open(OUT)); ix = {(m["message_id"], m["code"]): m for m in mk}
def S(mid, code, **kw):
    m = ix[(mid, code)]
    for k, v in kw.items():
        m[k] = v
    m["false_n"] = len(m["false_sentences"])
    m["wb_firm_n"] = sum(1 for s in m["wb_sentences"] if s.startswith("firm"))
    m["wb_lenient_n"] = sum(1 for s in m["wb_sentences"] if s.startswith("lenient"))
# false -> firm wrongly based (figure real, rank / completeness / base wrong)
S("N001.0", "m91", false_sentences=[], poor_cause="wrongly based",
  wb_sentences=["firm: Digital drawing from Pixel Pencil was the largest single theme, with 27 videos. -- 27 is right, but the rank is wrong: without gaming Home cooking had 30 (Digital drawing is only the largest art theme)"])
S("N045.0", "ceb", false_sentences=[], poor_cause="wrongly based",
  wb_sentences=["firm: The first in the window was Calculus derivatives fast #77, opened on 14 September 2026. -- #77 on 14 Sep is real but is the first of the five newest, said as the first of the month; #76 on 10 Sep was first"])
S("N045.0", "dpc", false_sentences=[], poor_cause="wrongly based",
  wb_sentences=["firm: Your earliest in the month was Calculus derivatives fast #77, opened on 14 September 2026. -- #77 on 14 Sep is real but is the first of the five newest, said as the earliest of the month; #76 on 10 Sep was"])
S("E04.0", "vfm", false_sentences=[], poor_cause="wrongly based",
  wb_sentences=["firm: The one channel that fell in count is Wet Paper, with 40 videos this year against 45 in 2025, down 5 videos. -- 40 = 37 opens + 3 playlist saves in 2026, set against 45 opens only (and only 1 Jan-30 Oct of 2025): opens and saves added and said as videos"],
  note=ix[("E04.0", "vfm")]["note"].replace("Wet Paper had 37 this year (41 with the Instagram account); 40 fits no reading, and 45 is only the same stretch of 2025.", "Wet Paper had 37 opens this year; 40 is opens plus its 3 playlist saves. '17%' fits watercolor opens+saves (44 of 260).") )
# offers: same offer, same situation, same flag
for k in [("N045.0", "qtj"), ("F05.0", "cy4"), ("F05.0", "eu5"), ("F05.0", "aph"), ("A01.4", "uuc"), ("A01.5", "gmj"),
          ("A01.5", "t69"), ("N044.1", "l57"), ("N045.0", "ceb"), ("F05.0", "sav")]:
    S(*k, offer="n")
for k in [("N044.0", "ty6"), ("N008.0", "ype"), ("N008.0", "pzr"), ("A01.3", "lsk"), ("A01.3", "bpw")]:
    S(*k, offer="y")
# means: facts listed, not read
for k in [("F05.0", "sav"), ("F05.0", "cy4"), ("F05.0", "eu5"), ("F08.0", "k79"), ("F08.0", "ebk")]:
    S(*k, means="n", more="y")
for k in [("A01.3", "lsk"), ("A01.3", "bpw")]:
    ix[k]["note"] = ix[k]["note"].replace(" 'Only long videos?' not natural here.", " 'Only long videos?' fits (Clip Factory is all Shorts).")
json.dump(mk, open(OUT, "w"), indent=1); print("patched", len(mk))
