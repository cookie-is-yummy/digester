from mk import M, save
B5="No window asked. Over the history Frame Perfect (Speedruns, last 1 May 2023) and Odd Prime (Number puzzles, last 22 Aug 2023) were dropped; the private channel also ended in 2024. The answer reads only the 4 weeks to 30 Oct and says none stopped (true there: every channel of 5 Sep-2 Oct appears again), so it misses the question though it names its window."
save([
M("B05.0","i2y","poor",ans="n",means="n",lt=0,cause="misses the question",note=B5+" 'the tools flag' is system talk. Gaming Daily last 5 Oct, 3 in window: true."),
M("B05.0","wkq","poor",ans="n",means="n",cause="misses the question",note=B5+" Pixel Pencil 29->27, Brick Realm 7->5, Limit Lane 6->4 last 16 Oct: true."),
M("B05.0","rh3","poor",ans="n",means="n",lt=1,lu=1,cause="misses the question",note=B5+" The 'can't see after 30 Oct' point is unwanted."),
M("B05.0","zra","poor",ans="n",means="n",cause="misses the question",note=B5+" 'your stopped channels list is empty' is system talk."),
M("B11.0","q5g","good",means="n",lt=1,lu=0,note="Doing part handed back by the code line (allowed). 24 Oct-30 Oct: Clip Factory 13 of 24, Pixel Pencil 6, Pan Theory 5: true. Export-end point explains which week."),
M("B11.0","m8o","acceptable",means="n",lt=1,lu=0,note="Counts true. 'Your export ends on 30 October 2026, so I can't set up a Sunday report' gives the wrong reason (it is a read-only bot); not a figure, so not counted false. Point 3 repeats the lead as a share."),
M("B11.0","x6z","acceptable",lt=1,lu=1,note="Counts true (13 Shorts, 54%). 'I can't send things on a schedule' says again what the code hand-back line says."),
M("B11.0","gfl","acceptable",means="n",offer="n",lt=1,lu=0,note="True; no offer."),
M("C08.0","zxw","good",means="n",more="y",note="Last Speedruns video: Speedrun glitch explained #90, Frame Perfect, 1 May 2023; 90 in all. True. Point 1 wording odd."),
M("C08.0","vfk","good",more="y",note="Frame Perfect is the only Speedruns channel: true."),
M("C08.0","glt","acceptable",means="n",note="True and brief, but bare: no reading, nothing more."),
M("C08.0","s62","acceptable",more="y",means="n",note="True; point 2 repeats the lead's date."),
M("D04.0","nob","good",note="2022: 108; gaming 100 (93%); Minecraft builds 59 Brick Realm; Speedruns 41 Frame Perfect; Home cooking 8. True."),
M("D04.0","ubv","acceptable",means="y",note="True but thin: one point, Speedruns and cooking not named."),
M("D04.0","i58","good"),
M("D04.0","ht9","good"),
])
