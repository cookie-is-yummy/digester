from mk import M, save
O="October 2026: 142 opens; Clip Factory 61 (43%), Pan Theory 32 (Home cooking), Pixel Pencil 29 (Digital drawing), Brick Realm 6, Gaming Daily 5."
W="October 2026 without gaming: 70; Pan Theory 32 (46%), Pixel Pencil 29 (41%), Limit Lane 4, wetpaper.ig 4, Wet Paper 1; art 34 (49%)."
S="Without gaming and Shorts (known long only; 4 Instagram reels have no length): 66; Pan Theory 32 (48%), Pixel Pencil 29, Limit Lane 4, Wet Paper 1."
save([
M("A01.3","lsk","good",means="n",more="y",offer="n",note=O+" Identical to bpw. 'Only long videos?' not natural here."),
M("A01.3","bpw","good",means="n",more="y",offer="n",note=O+" Identical to lsk."),
M("A01.3","as4","acceptable",means="n",note=O+" True, a bare ranked list."),
M("A01.3","wbb","acceptable",means="n",note=O+" True; point 2 repeats the lead as a share."),
M("A01.4","uuc","acceptable",means="n",note=W+" True; point 2 repeats the lead as a share."),
M("A01.4","kgj","acceptable",means="n",offer="y",note=W+" True; point 2 repeats the lead as a share. 'Only long videos?' fits (it is taken next)."),
M("A01.4","ahz","acceptable",means="n",note=W+" True; 'Limit Lane had 4, Wet Paper 1' leaves out wetpaper.ig (4) but claims no completeness."),
M("A01.4","m5r","good",note=W+" Art as an area at 49% beside Pan Theory leading is a useful reading."),
M("A01.5","gmj","acceptable",means="n",note=S+" True; 'These 4 channels make up the list' names only 3 of them, muddled."),
M("A01.5","uys","good",offer="n",note=S+" 'the two channels made up nearly all of it' (61 of 66) is a true reading."),
M("A01.5","t69","acceptable",means="n",note=S+" True, a bare list."),
M("A01.5","t2e","acceptable",means="n",note=S+" True, a bare list."),
M("B03.0","ull","acceptable",means="n",note="4 weeks to 30 Oct, long only (known length >60 s): 67; food 30 (45%), art 28 (42%; Digital drawing 27, Watercolor 1), gaming 5, math 4. True but names no theme or channel, no reading."),
M("B03.0","vg1","good",means="n",more="y",note="True; names Digital drawing 27 and Pan Theory."),
M("B03.0","nwr","acceptable",means="n",note="True ('math had the fewest' 4 vs gaming 5); a bare list, no theme named."),
M("B03.0","b5g","acceptable",means="n",note="True; a bare list, no theme named."),
])
