from mk import M, save
N20="Clock is 22 Nov; export ends 30 Oct, so the limit is part of the answer. 24 Oct to 30 Oct: 24 opens, all YouTube; Gaming clips 13 (54%, Clip Factory), Digital drawing 6 (Pixel Pencil), Home cooking 5."
save([
M("N066.0","vbl","good",means="n",more="y",lt=1,lu=0,note=N20),
M("N066.0","qp1","good",means="n",more="y",lt=1,lu=0,note=N20+" '24 of them on YouTube' is clumsy."),
M("N066.0","z3c","good",more="y",lt=1,lu=0,note=N20+" Evening 15 of 24 = 62.5%, said 63%."),
M("N066.0","y7q","good",means="n",more="y",lt=1,lu=0,note=N20),
M("N066.1","uc9","acceptable",means="n",offer="n",lt=1,lu=0,note="Both ends right (YouTube 30 Oct, Instagram 15 Oct). Bare, no offer."),
M("N066.1","tgr","good",means="n",more="y",lt=1,lu=0,note="Both ends right; 723 opens = 719 YouTube + 4 Instagram without private rows (line shown)."),
M("N066.1","xjx","good",means="n",lt=1,lu=0,note="Both ends right."),
M("N066.1","h5a","acceptable",means="n",more="y",lt=1,lu=0,note="True, but leaves out that Instagram ends earlier (15 Oct), which this question is about; history from 5 Jan 2021, 723 opens true."),
M("A01.0","t2q","good",lt=1,lu=0,note="Oct 3-30: gaming 64 of 130 (49%), Gaming clips 59, Clip Factory 56; art 57% -> 25% (down 32). 'at 49% of what you opened' repeats the base phrase."),
M("A01.0","z9a","good"),
M("A01.0","d1v","good",lt=1,lu=0,note="'almost all from Clip Factory' = 56 of 59, true."),
M("A01.0","n2g","good",lt=1,lu=0,note="Clip Factory 56, all 40 s Shorts; food 23% up 19 points (from 4%). True."),
M("A01.1","k7u","acceptable",lt=1,lu=1,note="Answers the correction with themes; Gaming clips 45% up 32, Home cooking 23% up 19, Digital drawing down 36: true. Repeats the export-end sentence its earlier answer already gave."),
M("A01.1","ymi","good",note="True; switches to themes as the correction asked."),
M("A01.1","vpc","good",note="Home cooking 30 vs 2, Digital drawing 27 vs 29: true."),
M("A01.1","s80","good"),
])
