"""Facts per message from the library rows (brain_library.rows()); no brain tool imported. Writes facts.txt.
Times in New York. 'opened' = watch events; saves = Instagram saves + YouTube playlist adds; friend's post left out of
totals and counted apart. Private = Dating advice / Heart Notes / relationships; printed apart."""
import json, os
from lib import *
HERE = os.path.dirname(os.path.abspath(__file__))
pk = json.load(open(os.path.join(HERE, "..", "blind", "group1.json")))
out = []
def P(*a): out.append(" ".join(str(x) for x in a))
def T(ev, key="theme"):
    n, r = tally(ev, key); return f"{n}: " + ", ".join(f"{a} {b} ({c}%)" for a, b, c in r)
def nopriv(ev): return [e for e in ev if not e["private"]]
def W(a, b, pred=None): return sel(d0=D(a), d1=D(b), pred=pred)
def band(h): return "night" if (h >= 21 or h < 5) else "morning" if h < 12 else "afternoon" if h < 17 else "evening"
L = lambda e: e["length"] is not None and e["length"] > 60
ALL = sel()
def basics():
    P("  all opens: with private", len(ALL), "| without private", len(nopriv(ALL)), "| private (Dating advice, Heart Notes)", len(ALL) - len(nopriv(ALL)), "all in 2024")
    P("  ends: YouTube 2026-10-30, Instagram 2026-10-15 (Instagram opens 12-15 Oct, first Instagram event a save 5 Oct); first open 2021-01-05; clock Sun 2026-11-22")
F = {}
def f(k):
    def d(fn): F[k] = fn; return fn
    return d
@f("N001.0")
def _():
    ev = W("2026-10-03", "2026-10-30"); ng = [e for e in ev if e["area"] != "gaming"]
    P("  4 weeks 3-30 Oct all:", T(ev)); P("  areas:", T(ev, "area"))
    P("  without gaming area:", T(ng, "area"), "|", T(ng))
    pv = [e for e in W("2026-09-05", "2026-10-02") if e["area"] != "gaming"]; P("  4 weeks before (5 Sep-2 Oct) without gaming:", T(pv, "area"))
    P("  without Gaming clips theme only:", T([e for e in ev if e["theme"] != "cl"], "area"))
@f("N001.1")
def _():
    co = sel(pred=lambda e: e["theme"] == "co")
    P("  cooking opens", len(co), "all Pan Theory; by month 2025-26:", sorted(Counter((e['d'].year, e['d'].month) for e in co if e['d'].year >= 2025).items()))
    P("  Sep 2026: 0; 4 weeks 3-30 Oct: 30 of 130 (23%), on", len({e['d'] for e in co if D('2026-10-03') <= e['d'] <= D('2026-10-30')}), "of 28 days; 4 weeks before: 2 (both 2 Oct); first Pan Theory 2021-02-01")
@f("N007.0")
def _():
    P("  2021:", T(W("2021-01-01", "2021-12-31")))
    P("  Speedruns last 2023-05-01, 0 in 2026; Minecraft builds 2021 91, 2022 59, 2026 13 (5 in 4 weeks), last 2026-10-20; 2026 window 303 days")
@f("N008.0")
def _():
    P("  2026 by month:", sorted(Counter(e['d'].month for e in W("2026-01-01", "2026-10-30")).items()), "total", len(W("2026-01-01", "2026-10-30")))
    P("  Digital drawing 92 from 1 Aug; Gaming clips 66 from 1 Oct")
@f("N008.1")
def _():
    ev = W("2026-10-01", "2026-10-31"); P("  Oct 2026:", T(ev)); P("  areas:", T(ev, "area")); P("  channels:", T(ev, "ch"))
@f("N012.0")
def _():
    for y in (2022, 2023):
        ev = W(f"{y}-01-01", f"{y}-12-31"); P(f"  {y}:", T(ev), "| areas", T(ev, "area"))
@f("N022.0")
def _():
    ev = W("2023-01-01", "2023-12-31"); P("  2023:", T(ev), "| areas", T(ev, "area"))
@f("N022.1")
def _():
    ev = W("2023-01-01", "2023-12-31", lambda e: e["area"] == "math"); P("  2023 math:", T(ev, "ch"), "| plat", Counter(e['plat'] for e in ev))
    P("  Odd Prime last 2023-08-22; Limit Lane last 2026-10-16")
@f("N024.0")
def _():
    ev = W("2026-01-01", "2026-10-30"); P("  2026 areas:", T(ev, "area"))
@f("N024.1")
def _():
    ev = W("2025-01-01", "2025-12-31"); P("  2025:", T(ev, "area"), "|", T(ev), "|", T(ev, "ch"), "| gaming 0, math 0")
@f("N027.0")
def _():
    for lab, ev in (("without private", nopriv(ALL)), ("with private", ALL)):
        P(f"  {lab}: {len(ev)}", dict(Counter(band(e['t'].hour) for e in ev)), "(night 9pm-5am, morning 5-12, afternoon 12-5pm, evening 5-9pm; NY)")
@f("N029.0")
def _():
    for lab, ev in (("without private", nopriv(ALL)), ("with private", ALL)):
        s = [e for e in ev if e['t'].weekday() == 5]; P(f"  Saturdays {lab}:", T(s, "area"), "|", T(s))
@f("N041.0")
def _():
    sv = sel(kind=("save", "playlist"), friends=True)
    for e in sv: P("   save", e['id'], e['d'], e['plat'], e['ch'] if not e['friend'] else "(friend's post: count only)", THEME[e['theme']] if not e['friend'] else "")
    P("  own saves 6 (3 YouTube playlist watercolor 3-5 Oct; 3 Instagram home cooking 5, 6, 10 Oct) + 1 friend's post")
F["N041.1"] = lambda: P("  Instagram own saves 3: rx_pasta noodle.nights 10 Oct, rx_sour2 crumb.lab 6 Oct, rx_sour1 crumb.lab 5 Oct; all Home cooking; none opened")
F["N042.0"] = lambda: P("  no like events in the library; 6 own saves (3 watercolor Wet Paper, 3 home cooking)")
@f("N044.0")
def _():
    co = sorted(sel(pred=lambda e: e["theme"] == "co"), key=lambda e: e['t'], reverse=True)
    P("  72 cooking opens; newest 10:", [(e['id'], str(e['d'])) for e in co[:10]])
F["N044.1"] = F["N044.0"]
@f("N045.0")
def _():
    ev = sorted(W("2026-09-01", "2026-09-30", lambda e: e["theme"] == "ca"), key=lambda e: e['t'])
    P("  Sept 2026 calculus:", len(ev), [(e['cap'], str(e['d'])) for e in ev])
F["N055.0"] = lambda: P("  1 friend's post saved (9 Oct): count only, no topic, no handle; own saves 6: Watercolor 3 (Wet Paper), Home cooking 3 (crumb.lab 2, noodle.nights 1)")
F["N056.0"] = lambda: P("  no completion data in the library; every item opened once (773 with private, 723 without); newest: soup 30 Oct 21:00 NY (600 s)")
@f("N066.0")
def _():
    ev = W("2026-10-24", "2026-10-30"); P("  this week 16-22 Nov: 0 (past export end). 24-30 Oct:", T(ev), "|", T(ev, "ch"), "| evening", sum(1 for e in ev if band(e['t'].hour) == 'evening'))
F["N066.1"] = lambda: P("  YouTube ends 2026-10-30, Instagram 2026-10-15; 723 opens without private = 719 YouTube + 4 Instagram")
@f("A01.0")
def _():
    ev = W("2026-10-03", "2026-10-30"); pv = W("2026-09-05", "2026-10-02")
    P("  4 weeks:", T(ev, "area"), "|", T(ev), "|", T(ev, "ch")); P("  before:", T(pv, "area"), "|", T(pv), "|", T(pv, "ch"))
F["A01.1"] = F["A01.0"]
F["A01.3"] = F["N008.1"]
@f("A01.4")
def _():
    ev = W("2026-10-01", "2026-10-31", lambda e: e["area"] != "gaming"); P("  Oct without gaming:", T(ev, "ch"), "|", T(ev, "area"))
@f("A01.5")
def _():
    ev = W("2026-10-01", "2026-10-31", lambda e: e["area"] != "gaming" and L(e)); P("  Oct without gaming, long known:", T(ev, "ch"))
@f("B03.0")
def _():
    ev = W("2026-10-03", "2026-10-30", L); P("  4 weeks long known:", T(ev, "area"), "|", T(ev))
@f("B05.0")
def _():
    fl = defaultdict(list)
    for e in ALL: fl[e['ch']].append(e['d'])
    for c, v in sorted(fl.items(), key=lambda x: max(x[1])): P(f"   {c}: {len(v)} {min(v)} to {max(v)}" + (" PRIVATE" if c == "Heart Notes" else ""))
    P("  dropped over history: Frame Perfect, Odd Prime (and the private one); no channel of 5 Sep-2 Oct missing in 3-30 Oct")
@f("E04.0")
def _():
    P("  1 Jan-30 Oct 2025:", T(W("2025-01-01", "2025-10-30"), "ch"), "| 2026:", T(W("2026-01-01", "2026-10-30"), "ch"))
    P("  no 2025 channel missing in 2026; Watercolor 2026 41 of 254 (16%)")
F["B11.0"] = F["N066.0"]
F["C08.0"] = lambda: P("  last Speedruns: Speedrun glitch explained #90, Frame Perfect, 2023-05-01; 90 in all")
F["D04.0"] = lambda: P("  2022:", T(W("2022-01-01", "2022-12-31")), "| areas", T(W("2022-01-01", "2022-12-31"), "area"))
F["D04.1"] = lambda: P("  Instagram opens in 2022: 0; Instagram opens 12-15 Oct 2026 (4 watercolor reels); 2022 opens 108 all YouTube")
F["F02.0"] = lambda: P("  yesterday 21 Nov: past export end; 30 Oct NY:", [(e['cap'], e['ch']) for e in W("2026-10-30", "2026-10-30")])
@f("F04.0")
def _():
    sp = sel(pred=lambda e: e["theme"] == "sr"); P("  Speedruns", len(sp), "Frame Perfect, 2021-03-01 to 2023-05-01; by year", dict(Counter(e['d'].year for e in sp)), "; 3-4 every month to Apr 2023, 1 in May 2023; evening", sum(1 for e in sp if band(e['t'].hour) == 'evening'))
@f("F05.0")
def _():
    cl = sel(pred=lambda e: e["theme"] == "cl"); P("  Gaming clips", len(cl), T(cl, "ch"), "| days", len({e['d'] for e in cl}), "| evening", sum(1 for e in cl if band(e['t'].hour) == 'evening'), "| all 40 s")
@f("F06.0")
def _():
    g = W("2026-10-03", "2026-10-30", lambda e: e["area"] == "gaming"); gp = W("2026-09-05", "2026-10-02", lambda e: e["area"] == "gaming")
    P("  gaming 4 weeks:", T(g), "|", T(g, "ch"), "| before:", T(gp), "| all gaming ever", len(sel(pred=lambda e: e['area'] == 'gaming')), "| 2026 by month", sorted(Counter(e['d'].month for e in sel(d0=D('2026-01-01'), pred=lambda e: e['area'] == 'gaming')).items()))
F["F08.0"] = lambda: P("  no subscriber data; Brick Realm 163 opens (2021 91, 2022 59, 2026 13), 5 Jan 2021 to 20 Oct 2026")
F["F10.0"] = lambda: (P("  no forecast possible; 4 weeks:", T(W("2026-10-03", "2026-10-30"), "ch")))
basics_done = False
P("FACTS (reader1a) from experiments/mvp/tests/brain_library.py rows")
basics()
for m in pk["messages"]:
    P("=" * 90); P(m["key"], m["set"], "|", m["message"], "| codes:", ", ".join(a["code"] for a in m["answers"]))
    F[m["key"]]()
open(os.path.join(HERE, "facts.txt"), "w").write("\n".join(out) + "\n")
print("wrote", len(out), "lines")
