import json, sys
d=json.load(open('/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group1.json'))
lo, hi = int(sys.argv[1]), int(sys.argv[2])
for i,m in enumerate(d['messages'][lo:hi], lo):
    print('='*100); print(i, m['key'], m['set'], 'MSG:', m['message'])
    for t in m['earlier_turns']: print('   earlier>', json.dumps(t))
    for a in m['answers']:
        print('-'*40, a['code'], 'empty' if a['empty'] else '')
        if a['earlier_answers_seen']:
            for e in a['earlier_answers_seen']: print('   [seen]', json.dumps(e))
        print(a['sent'])
        if a['parts'].get('cards'): print('   CARDS:', json.dumps(a['parts']['cards']))
        if a['parts'].get('limit_lines'): print('   LIMITS:', a['parts']['limit_lines'])
        if a['parts'].get('ask_back'): print('   ASK:', a['parts']['ask_back'])
