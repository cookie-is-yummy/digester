# reader1a progress
- Packet group1.json: 40 messages x 4 codes = 160 answers. ALL MARKED.
- Outputs: reader1a/marks.json (160 marks), reader1a/facts.txt (from reader1a/facts.py, rows of brain_library.py only).
- Marks sources: reader1a/b1.py .. b8.py, then b9.py (corrections: false->firm for 4, offer/means evenness). Rerun b1..b9 in order.
- End checks passed: every (message, code) marked; false_n matches quotes; poor_cause only on poor; false/firm -> poor; lenient -> not good; identical pair A01.3 lsk/bpw marked alike.
- Grades: good 83, acceptable 66, poor 11.
