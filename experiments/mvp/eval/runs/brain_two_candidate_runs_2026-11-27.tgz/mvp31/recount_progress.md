# recount progress
- step 0: read brief, rubric, DECISIONS last three sections + gate bars (lines 417-433). Started scripts in recount/.
- step 1 done: count.py -> counts.json (per run, per reader side a/b, avg; sentences sent; seconds).
- step 2 done: boot.py -> boot.json (seed 3131, 10000 resamples, per-message mean over runs x readers).
- step 3 (in progress): false-marked settled (see settle.json when written): false = l6d, t4i, a7v (A_v3d_1), rnp, ijg (A_v4d_1), t3s (H_v4d_1); firm = ceb, dpc; not = y8p. Privacy N053.1 x4 runs: fault by rubric letter (carried unlock, message does not name topic); pl1 N068.0: firm wb, not privacy. Next: 20 random firm (seed 31313).
- step 3 done: settle.py -> settle.json. Firm pool 25 unique (firm_pool.py, seed 31313), sample 20: 15 firm, 1 false (a7v), 4 not firm. Settled false per run: A_v3d_1 3, A_v4d_1 2, H_v4d_1 1, rest 0.
- step 5 done (before reading tally): blindcheck.py: no timings/flags/prompt/paths in packets (2 'flag' hits are answer text), 4 distinct codes per message, 472 codes once each, texts match records, key folders match prompt_version/set in summaries, 23 distinct orders over 118 messages.
- step 4: reading tally now.
- step 4 done: compare.json, verdict.py -> verdict.json. Numbers agree; settlement differs on rnp (me false, tally lenient), a7v (me false, tally firm), the two E04.0 vfm sentences swapped firm/lenient. l5b false agreed (checked after tally). My verdict: candidate v4d (set A count) / v3d (all runs); gate condition NOT met in either reading, either privacy reading (A_v4d_1 3 false; A_v3d_1 3 false). Tally: not met under P1, met under P0.
- advisor review applied: verdict split into independent vs with-l5b; compare.json extended; b1f note fixed (90 before window). rnp-style weekly claim appears only in A_v4d_1 N053.0.
