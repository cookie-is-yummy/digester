reader3b: done. 38 messages, 152 answers in reader3b/marks.json (built from marks_a-d + marks_fix consistency pass); facts in reader3b/facts.txt
