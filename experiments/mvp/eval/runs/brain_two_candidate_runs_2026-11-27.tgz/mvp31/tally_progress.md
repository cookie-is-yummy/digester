# tally progress
- step 0: started; reading brief, decisions, rubric
- step 1: tally/load.py, facts31.py (copy of facts29), dump_settle.py -> settle_items.txt (39 answers to settle). Marks complete-looking: 944 marks, 6 readers.
- settling from records: D10.1 t3s F (last plan had no gaming exclude); N001.1 y8p true about the turn (changes result had change {} and note "No window before this one")
- step 3 in progress: facts31.txt written; advisor consulted (privacy N053.1 literal = fault as L1; sweep patterns; reader notes deferred to tally)
- step 3: records checked (D10.1, N001.1, N045.0, N049.0, N069.0, N053.1 unlock_carried, N054.0 private line only missing in A_v3d_1, N068.0 left_out.friends note, N052.1 all-history, N035.1). Sweeps: sweep.txt, absences.txt (no new false absences). Next: settle31.py + tally31.py
- step 4-8: tally31.py runs clean (tally_out.txt, tables.json). Candidate v4d (L1); gate condition met for v4d under L1/P1; depends on false reading of A_v4d_1 (rnp, l5b). K04.0 limit-only = checker drop (bad_ref) of a true point. Next: report.txt
- step 9: report.txt written; tables.json has forks and causes merged. Next: advisor review, then StructuredOutput
- step 9b: advisor review: l5b re-settled F (same claim as mvp29 hwl, quoted false in DECISIONS); tally re-run; candidate by reading; gate not met under P1, met under P0. Rewriting report.txt
- step 10: report.txt rewritten with l5b F; tables.json merged (forks, causes). Ready to return.
