# reader2a batch 3: messages 21-30
# N109.0 show the friend's post (rule: never shown; the limit is the answer). Saves: 3 playlist (3-5 Oct), 3 IG (5, 6, 10 Oct), friend 9 Oct. Last save 10 Oct.
SAVEWIN = ("the saves run 3 to 10 October; '3 to 30 October' is the scope's span (export end), so the saves are said to run to 30 October")
M("N109.0", "smn", "poor", "y", "n", "n", "n", lt=2, lu=0,
  wb=[("In your saves from 3 to 30 October 2026, 1 item is a friend's post, in no total and never shown.", "firm", SAVEWIN)],
  cause="wrongly based", note="the save-window fault named in the decisions note; no privacy fault; 'Show some examples?' of nothing named")
M("N109.0", "cnp", "acceptable", "y", "n", "n", "n", lt=2, lu=0, note="true; the point repeats the lead")
M("N109.0", "rt3", "good", "y", "n", "y", "y", lt=2, lu=0, note="true: own saves 6 = 3 YouTube playlist + 3 Instagram; friend left out of the total, which is right")
M("N109.0", "may", "acceptable", "y", "n", "n", "n", lt=2, lu=0, note="true; point repeats; no offer")

# N113.0 what kind of videos do i usually like (no like events; saves 6: Watercolor 3 Wet Paper playlist, Home cooking 3 = crumb.lab 2 + noodle.nights 1; friend left out)
M("N113.0", "b4b", "poor", "y", "n", "n", "n", lt=1, lu=0,
  wb=[("Your export holds no likes, so here is what you saved most: across your saves from 3 to 30 October 2026, art and design and food and cooking each made up 50% of the 6 items you saved.", "firm", SAVEWIN)],
  cause="wrongly based", note="no-likes limit is wanted; 'And lately?' repeats (all saves are recent)")
M("N113.0", "ym4", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note="true; thin: 6 saves from one week of October said as what they usually like, not said how few")
M("N113.0", "yb9", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note="true; thin")
M("N113.0", "iid", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note="true; thin")

# A03.0 topics recently (3-30 Oct: 130; Gaming clips 59 = 45%, Home cooking 30 = 23%, DD 27 = 21%, Minecraft 5, Watercolor 5, Calculus 4; 4 weeks before 5 Sep-2 Oct: 51, DD 29, Watercolor 0)
M("A03.0", "qtw", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note="true; a list of themes, no reading; export-end line fair for 'recently'")
M("A03.0", "b1f", "poor", "y", "y", "y", "n",
  wb=[("Watercolor painting had 5 videos, a theme new in this window.", "firm",
       "0 in the 4 weeks before, but 86 watercolor videos earlier (2025 and 2026); 'new' misleads")],
  cause="wrongly based", note="rest true; 'By month?' on 4 weeks")
M("A03.0", "ofw", "acceptable", "y", "n", "n", "n", note="true; list only; 'By month?' on 4 weeks")
M("A03.0", "u62", "good", "y", "y", "y", "y", note="true: Home cooking share 23.1 vs 3.9 (+19 points), DD 20.8 vs 56.9 (-36 points)")

# A05.0 channels most in October (Clip Factory 61, Pan Theory 32, Pixel Pencil 29, Brick Realm 6, Gaming Daily 5, Limit Lane 4, wetpaper.ig 4, Wet Paper 1; 142 opens)
M("A05.0", "ebf", "good", "y", "n", "y", "y", note="true; 'Only long videos?' natural after a Shorts channel leads")
M("A05.0", "qms", "good", "y", "n", "y", "y", note="true")
M("A05.0", "joj", "acceptable", "y", "n", "n", "y", note="true; bare ranking")
M("A05.0", "eia", "acceptable", "y", "n", "n", "n", note="true; bare ranking; 'By month?' on one month")

# A06.0 without gaming, October channels (70: Pan Theory 32 = 46%, Pixel Pencil 29 = 41%, Limit Lane 4, wetpaper.ig 4, Wet Paper 1; 5 channels)
M("A06.0", "hhl", "acceptable", "y", "n", "n", "n", note="true; 'By month?' on one month")
M("A06.0", "cnu", "acceptable", "y", "n", "y", "n", note="true: Limit Lane 4 ties wetpaper.ig 4; 'By month?' on one month")
M("A06.0", "il0", "acceptable", "y", "n", "n", "n", note="true; 'without gaming' said twice; 'By month?' on one month")
M("A06.0", "amf", "acceptable", "y", "n", "y", "n", note="true: 5 channels, 32/70 = 46%; 'By month?' on one month")

# B01.0 most into right now (3-30 Oct: gaming 64/130 = 49%, before 14/51 = 27%; art 32 = 25% vs 29/51 = 57%; Gaming clips 59, Clip Factory 56)
M("B01.0", "zh2", "acceptable", "y", "y", "y", "n", lt=1, lu=0, note="true; the offer 'And in the 4 weeks before?' repeats what was just shown")
M("B01.0", "tvc", "good", "y", "y", "y", "y", lt=1, lu=0, note="true")
M("B01.0", "jrw", "acceptable", "y", "y", "y", "n", lt=1, lu=0, note="true; 'By month?' on 4 weeks")
M("B01.0", "hup", "good", "y", "y", "y", "y", lt=1, lu=0, note="true")

# B14.0 shorts vs long (723 opens = 719 YouTube + 4 reels; Shorts 66; long 651; 4 reels and 2 deleted calculus have no length; 2026: 66/254 = 26%; none before)
M("B14.0", "ccu", "poor", "y", "y", "y", "n",
  wb=[("Over all your history, 66 of the 723 videos you opened were Shorts, a share of 9%; the other 651 were long videos.", "firm",
       "66 + 651 = 717: 'the other' says the rest are all long; 4 reels and 2 videos with no length are left out")],
  cause="wrongly based", note="rest true; 'And in 2026?' repeats the 2026 point")
M("B14.0", "aoo", "acceptable", "y", "y", "y", "n", note="true; 'Long videos were 651 of what you opened' clumsy; 'And in 2026?' repeats the 2026 point")
M("B14.0", "zez", "acceptable", "y", "n", "n", "y",
  wb=[("Across all your history, 66 of the 723 videos you opened were Shorts, which is 9% of your YouTube videos; 651 were long.", "lenient",
       "723 includes 4 Instagram reels, said as YouTube videos; the share is 9% on either base")],
  note="thin")
M("B14.0", "nv4", "acceptable", "y", "y", "y", "n", note="true; 'By month?' over all history")

# C01.0 least channels October (Wet Paper 1; Limit Lane 4 and wetpaper.ig 4 tied; Gaming Daily 5; Brick Realm 6)
M("C01.0", "vk4", "acceptable", "y", "n", "y", "n",
  wb=[("Brick Realm had 6 videos, the most of these five channels.", "lenient", "true of the five least channels, but four are named (wetpaper.ig left out)")], note="true; wetpaper.ig (4, tied with Limit Lane) left unnamed but nothing said complete; 'By month?' on one month")
M("C01.0", "n7o", "acceptable", "y", "n", "n", "y", note="true; thin")
M("C01.0", "jx6", "good", "y", "n", "y", "y", note="true")
M("C01.0", "maz", "acceptable", "y", "n", "y", "y",
  wb=[("Brick Realm had 6 videos, the most of these five channels.", "lenient", "true of the five least channels, but four are named (Gaming Daily left out)")], note="names the tie")

# C04.0 Sundays (New York weekday; 101 opens; gaming 45 = 45%, art 25, math 20, food 11; Brick Realm 23; art on Sundays: Pixel Pencil 13, Wet Paper 12; 7 private Sunday rows left out)
M("C04.0", "d8b", "good", "y", "n", "y", "y", note="true")
M("C04.0", "f03", "good", "y", "n", "y", "y", note="true; 13 of 25 is a majority, so 'mostly' holds")
M("C04.0", "j45", "good", "y", "n", "y", "y", note="true")
M("C04.0", "tal", "acceptable", "y", "n", "y", "n", note="true; 'Only long videos?' adds nothing here")

# C09.0 rewatched most (every row holds one watch: no rewatches; the limit is the answer)
M("C09.0", "vml", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note="true; 'runs newest first' is system talk; generic offer")
M("C09.0", "x2o", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note="true; the newest-opens point adds little; generic offer")
M("C09.0", "l69", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note="true; generic offer")
M("C09.0", "aei", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note="true; generic offer")
