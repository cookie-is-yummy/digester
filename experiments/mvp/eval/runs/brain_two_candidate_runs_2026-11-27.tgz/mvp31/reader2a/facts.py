"""reader2a facts: one block per message key, computed from the library rows only (lib.py). Writes facts.txt."""
from collections import Counter
from datetime import date

from lib import C, EV, sel

OUT = []
W = [e for e in EV if e["kind"] == "watch"]
YT = [e for e in W if e["plat"] == "youtube"]
NP = [e for e in YT if not e["private"]]  # YouTube opened, private left out
F = {}


def fact(key):
    def deco(fn):
        F[key] = fn
        return fn
    return deco


def p(*a):
    OUT.append(" ".join(str(x) for x in a))


def rng(evs, a, b):
    return [e for e in evs if a <= e["d"] <= b]


def yr(evs):
    c = {}
    for e in evs:
        c.setdefault(e["d"].year, Counter())[e["area"]] += 1
    return {y: (sum(v.values()), v.most_common()) for y, v in sorted(c.items())}


@fact("N002.0")
def _():
    p("YouTube opened (no private):", len(NP), "| with private:", len(YT))
    for a, n in C(NP, "area"):
        p(f"  area {a}: {n} = {100 * n / len(NP):.1f}%")
    p("  themes:", C(NP, "tname"))
    p("  channels:", C(NP, "ch"))
    p("  Brick Realm = all of Minecraft builds (163). Window 5 Jan 2021 to 30 Oct 2026.")


@fact("N005.0")
def _():
    p("Themes present per year (non-private opens, both platforms):")
    nw = [e for e in W if not e["private"]]
    for y in range(2021, 2027):
        p(" ", y, C([e for e in nw if e["d"].year == y], "tname"))
    co = sorted([e for e in YT if e["theme"] == "co"], key=lambda e: e["t"])
    mc = sorted([e for e in YT if e["theme"] == "mc"], key=lambda e: e["t"])
    p("  Pan Theory/Home cooking: every year, 72; first", co[0]["d"], "last", co[-1]["d"])
    p("  Brick Realm: 163; years", sorted(Counter(e["d"].year for e in mc).items()), "first", mc[0]["d"], "last",
      mc[-1]["d"], "-> NOT every year (none 2023-2025)")
    p("  2024 opened: all", len([e for e in W if e["d"].year == 2024]), "non-private", len([e for e in nw if e["d"].year == 2024]))
    p("  All opened both platforms non-private:", len(nw), "(719 YT + 4 IG reels)")


@fact("N005.1")
def _():
    nw = [e for e in W if not e["private"]]
    for y, (n, v) in yr(nw).items():
        g = dict(v).get("gaming", 0)
        p(f"  {y}: opened {n} (both platforms, non-private), gaming {g} = {100 * g / n:.1f}%; YT-only {len([e for e in NP if e['d'].year == y])}")
    p("  2024 with private:", len([e for e in W if e["d"].year == 2024]))
    p("  Minecraft builds 163 all history")


@fact("N010.0")
def _():
    for y in (2025, 2026):
        s = rng(YT, date(y, 6, 1), date(y, 8, 31))
        p(f"  summer {y} (1 Jun-31 Aug): {len(s)}", C(s, "tname"), C(s, "area"), "private", sum(e["private"] for e in s))
    p("  Digital drawing first opened", min(e["d"] for e in YT if e["theme"] == "dd"), "(Pixel Pencil)")
    p("  IG: nothing in summers")


@fact("N010.1")
def _():
    for y in (2025, 2026):
        s = [e for e in rng(W, date(y, 6, 1), date(y, 8, 31)) if e["area"] == "art and design"]
        p(f"  summer {y} art: {len(s)}", C(s, "tname"))
    p("  32/45 =", f"{100 * 32 / 45:.1f}%", "; 45-14 = 31")


@fact("N013.0")
def _():
    mc = sorted([e for e in YT if e["theme"] == "mc"], key=lambda e: e["t"])
    p("  last 3 Minecraft:", [(str(e["d"]), e["cap"][:40], e["ch"]) for e in mc[-3:]])
    p("  163 Minecraft builds, all Brick Realm; record ends 30 Oct 2026")


@fact("N013.1")
def _():
    mc = sorted([e for e in YT if e["theme"] == "mc"], key=lambda e: e["t"])
    p("  first Minecraft:", mc[0]["d"], mc[0]["cap"], mc[0]["ch"], mc[0]["id"])


@fact("N014.0")
def _():
    co = sorted([e for e in EV if e["theme"] == "co"], key=lambda e: e["t"])
    p("  last cooking events:", [(str(e["d"]), e["cap"][:30], e["plat"], e["kind"]) for e in co[-4:]])
    p("  last cooking video watched: Cooking soup on the 30th, Pan Theory, 30 Oct 2026 (NY; 01:00 UTC 31 Oct)")


@fact("N034.0")
def _():
    y = [e for e in W if e["d"].year == 2026]
    lg = [e for e in y if e["length"] and e["length"] > 60]
    p("  2026 opened", len(y), "long (>60 s):", len(lg), C(lg, "area"), C(lg, "tname"), C(lg, "ch"))
    p("  art share 129/184 =", f"{100 * 129 / 184:.1f}%", "DD 92/184 =", f"{100 * 92 / 184:.1f}%",
      "; theme rank: DD 92 > Watercolor 37 > Home cooking 32 > Minecraft 13 > Calculus 10")


@fact("N034.1")
def _():
    y = [e for e in W if e["d"].year == 2026]
    sh = [e for e in y if (e["length"] and e["length"] <= 60) or e["plat"] == "instagram"]
    p("  2026 short (Shorts <=60 s + IG reels):", len(sh), C(sh, "area"), C(sh, "tname"), C(sh, "ch"), C(sh, "plat"))
    p("  gaming 66/70 =", f"{100 * 66 / 70:.1f}%", "; Clip Factory 61/70 =", f"{100 * 61 / 70:.1f}%")


OCT = [e for e in W if e["d"].year == 2026 and e["d"].month == 10]


@fact("N036.0")
def _():
    ig = [e for e in EV if e["plat"] == "instagram"]
    for e in ig:
        p(" ", e["id"], e["kind"], e["t"].strftime("%a %Y-%m-%d %H:%M"), e["ch"], e["tname"], "FRIEND" if e["friend"] else "")
    p("  reels opened in Oct: 4 (12-15 Oct, Mon-Thu 08:00 NY), all Watercolor painting, wetpaper.ig; IG ends 15 Oct")


@fact("N049.0")
def _():
    it = sorted([e for e in EV if "ntegral" in e["cap"]], key=lambda e: e["t"])
    p("  'Integrals' videos:", len(it), "all", C(it, "ch"))
    p("  ", [(e["cap"].split("#")[1], str(e["d"])) for e in it])


@fact("N053.0")
def _():
    da = sorted([e for e in EV if e["theme"] == "da"], key=lambda e: e["t"])
    wk = {e["d"].isocalendar()[1] for e in da}
    p("  dating (private; named by the person):", len(da), "on", len({e["d"] for e in da}), "days,", da[0]["d"], "to", da[-1]["d"])
    p("  by month:", sorted(Counter(e["d"].month for e in da).items()), "; ISO weeks with one:", len(wk),
      "of span", min(wk), "-", max(wk), "-> every week Feb to mid-Aug, none after; 50/29 = 1.7 a week")
    p("  hours NY:", sorted(Counter(e["t"].hour for e in da).items()), "17-20h:", sum(17 <= e["t"].hour <= 20 for e in da),
      "; weekdays:", sum(e["t"].weekday() < 5 for e in da))


@fact("N053.1")
def _():
    p("  dating 2024: 50; 2023: 0 (2023 was math 135, speedruns 14, cooking 8). Channel Heart Notes.")


@fact("N062.0")
def _():
    nw = [e for e in EV if not e["private"] and not e["friend"]]
    p("  first event:", min(e["d"] for e in EV), "; nothing in 2020 (publish dates of 2020 exist, watch dates do not)")
    p("  2021 opens:", len([e for e in W if e["d"].year == 2021]), "; all non-private non-friend events:", len(nw),
      Counter(e["kind"] for e in nw), "; likes: 0")


@fact("N063.0")
def _():
    for a in (16, 20, 21):
        s = [e for e in OCT if e["d"].day >= a]
        p(f"  {a}-31 Oct: {len(s)}", C(s, "area"), C(s, "ch"))
    p("  21-30 Oct gives the 38 the answers use: gaming 19 (50%), art 10 (26%), food 9 (24%)")


@fact("N063.1")
def _():
    p("  October opened:", len(OCT), C(OCT, "plat"), C(OCT, "area"))
    for a, n in C(OCT, "area"):
        p(f"    {a}: {n} = {100 * n / len(OCT):.1f}%")
    p("  channels:", C(OCT, "ch"))
    p("  themes:", C(OCT, "tname"))


@fact("N064.0")
def _():
    m = rng(W, date(2023, 5, 1), date(2023, 8, 31))
    p("  May-Aug 2023:", len(m), C(m, "area"), C(m, "tname"), C(m, "ch"))
    p("  Limit Lane first", min(e["d"] for e in EV if e["theme"] == "ca"), "Odd Prime first",
      min(e["d"] for e in EV if e["theme"] == "np"))


@fact("N067.0")
def _():
    p("  November events:", len([e for e in EV if e["d"] >= date(2026, 11, 1)]), "(record ends 30 Oct)")
    p("  October:", len(OCT), "evening 17-20h:", sum(17 <= e["t"].hour <= 20 for e in OCT), "=",
      f"{100 * sum(17 <= e['t'].hour <= 20 for e in OCT) / len(OCT):.1f}%")
    p("  channel rank Oct:", C(OCT, "ch")[:3], "theme rank:", C(OCT, "tname")[:3])


@fact("N069.0")
def _():
    wc = sorted([e for e in EV if e["theme"] == "wc" and e["d"] >= date(2026, 10, 1)], key=lambda e: e["t"])
    for e in wc:
        p(" ", e["id"], e["kind"], e["d"], e["ch"], e["cap"])
    p("  the 'tips' one: rx_love, Wet Paper, opened 21 Oct 2026; full title held in the rows")


SAVES = sorted([e for e in EV if e["kind"] in ("save", "playlist")], key=lambda e: e["t"])


def four_weeks():
    from datetime import timedelta
    end = date(2026, 10, 30)
    st = end - timedelta(days=27)
    cur = rng(W, st, end)
    pv = rng(W, st - timedelta(days=28), st - timedelta(days=1))
    return st, cur, pv


@fact("N109.0")
def _():
    for e in SAVES:
        p(" ", e["id"], e["kind"], e["d"], e["plat"], e["ch"], e["tname"], "FRIEND (never shown, in no total)" if e["friend"] else "")
    p("  own saves: 6 (3 YouTube playlist + 3 Instagram); saves run 3 to 10 October")


@fact("N113.0")
def _():
    p("  like events:", sum(e["kind"] == "like" for e in EV), "; saves (friend out):",
      C([e for e in SAVES if not e["friend"]], "tname"), C([e for e in SAVES if not e["friend"]], "ch"),
      "; span", SAVES[0]["d"], "to", max(e["d"] for e in SAVES))


@fact("A03.0")
def _():
    st, cur, pv = four_weeks()
    p("  4 weeks", st, "to 30 Oct:", len(cur), C(cur, "tname"))
    p("  4 weeks before:", len(pv), C(pv, "tname"))
    for t in ("Gaming clips", "Home cooking", "Digital drawing", "Watercolor painting"):
        a = sum(e["tname"] == t for e in cur) / len(cur)
        b = sum(e["tname"] == t for e in pv) / len(pv)
        p(f"    {t}: {100 * a:.1f}% vs {100 * b:.1f}% ({100 * (a - b):+.1f} points)")
    p("  watercolor opened before 3 Oct 2026:", sum(1 for e in W if e["theme"] == "wc" and e["d"] < st))


@fact("A05.0")
def _():
    p("  October channels:", C(OCT, "ch"), "of", len(OCT))
    p("  Pan Theory = Home cooking only; Pixel Pencil = Digital drawing only")


@fact("A06.0")
def _():
    ng = [e for e in OCT if e["area"] != "gaming"]
    p("  October without gaming:", len(ng), C(ng, "ch"), "; Pan Theory", f"{100 * 32 / len(ng):.1f}%", "Pixel Pencil",
      f"{100 * 29 / len(ng):.1f}%")


@fact("B01.0")
def _():
    st, cur, pv = four_weeks()
    for nm, s in (("now", cur), ("before", pv)):
        a = Counter(e["area"] for e in s)
        p(f"  {nm}: {len(s)}", a.most_common(), {k: f"{100 * v / len(s):.1f}%" for k, v in a.items()})
    gc = [e for e in cur if e["tname"] == "Gaming clips"]
    p("  Gaming clips now:", len(gc), C(gc, "ch"))


@fact("B14.0")
def _():
    nw = [e for e in W if not e["private"]]
    yt = [e for e in nw if e["plat"] == "youtube"]
    p("  opened (both platforms, private out):", len(nw), "YouTube", len(yt), "Shorts (<=60 s):",
      sum(1 for e in yt if e["length"] and e["length"] <= 60), "long:", sum(1 for e in yt if e["length"] and e["length"] > 60),
      "YouTube no length:", sum(1 for e in yt if not e["length"]), "IG reels (no length):", len(nw) - len(yt))
    p("  Shorts channels:", C([e for e in yt if e["length"] and e["length"] <= 60], "ch"), "; all in 2026 (from 1 Oct)")
    p("  2026: 66 of 254 opens (250 YouTube) = 26%")


@fact("C01.0")
def _():
    p("  October channels, least first:", list(reversed(C(OCT, "ch"))))


@fact("C04.0")
def _():
    nw = [e for e in W if not e["private"]]
    s = [e for e in nw if e["t"].weekday() == 6]
    p("  Sundays (NY):", len(s), [(a, n, f"{100 * n / len(s):.1f}%") for a, n in C(s, "area")])
    p("  channels:", C(s, "ch"))
    p("  private Sunday rows left out:", sum(1 for e in W if e["private"] and e["t"].weekday() == 6))


@fact("C09.0")
def _():
    per = Counter(e["id"] for e in W)
    p("  items opened:", len(per), "; times each opened:", Counter(per.values()).most_common(), "-> no rewatches")
    nw = [e for e in W if not e["private"]]
    p("  opened, private out:", len(nw), "; newest:", [(e["cap"], str(e["d"])) for e in sorted(nw, key=lambda e: e["t"])[-2:]])


@fact("D03.0")
def _():
    F["A05.0"]()


@fact("D03.1")
def _():
    o = sorted(OCT, key=lambda e: e["t"])
    p("  latest October opens:", [(e["cap"], e["ch"], e["t"].strftime("%d %H:%M"), e["plat"]) for e in o[-5:][::-1]])


@fact("D03.2")
def _():
    g = sorted([e for e in OCT if e["area"] == "gaming"], key=lambda e: e["t"])
    p("  October gaming:", len(g), C(g, "ch"), "; latest five:", [(e["cap"], e["t"].strftime("%d %H:%M"), e["length"]) for e in g[-5:][::-1]])
    p("  every item opened once")


@fact("D10.0")
def _():
    F["B01.0"]()
    st, cur, pv = four_weeks()
    p("  now themes:", C(cur, "tname"), "; food:", C([e for e in cur if e["area"] == "food and cooking"], "tname"))


@fact("D10.1")
def _():
    st, cur, pv = four_weeks()
    ys = [e for e in cur if e["plat"] == "youtube"]
    sh = [e for e in ys if e["length"] and e["length"] <= 60]
    p("  gaming:", sum(e["area"] == "gaming" for e in cur), "of", len(cur), C([e for e in cur if e["area"] == "gaming"], "ch"))
    p("  Shorts:", len(sh), "of", len(ys), "YouTube =", f"{100 * len(sh) / len(ys):.1f}%", "; of all", len(cur), "=",
      f"{100 * len(sh) / len(cur):.1f}%", "; with 4 reels", f"{100 * (len(sh) + 4) / len(cur):.1f}%")
    p("  previous answer (each code's own) led with gaming at 49%: it did not leave gaming out")


@fact("F03.0")
def _():
    p("  first event:", min(e["d"] for e in EV), "-> nothing from 2019")


@fact("F09.0")
def _():
    br = sorted([e for e in W if e["ch"] == "Brick Realm"], key=lambda e: e["t"])
    p("  popularity on YouTube: not in the record. Minecraft builds channels:", C([e for e in W if e["theme"] == "mc"], "ch"),
      "first", br[0]["d"], "last", br[-1]["d"])


@fact("F15.0")
def _():
    ca = sorted([e for e in W if e["theme"] == "ca"], key=lambda e: e["t"])
    p("  Calculus lessons opened:", len(ca), "lengths:", Counter(e["length"] for e in ca).most_common(), "-> all tie at 10 min")
    p("  latest:", [(e["cap"], str(e["d"])) for e in ca[-2:][::-1]])


@fact("G03.0")
def _():
    p("  Wet Paper events in Oct:", [(e["id"], e["kind"], str(e["d"])) for e in OCT + SAVES if e["ch"] == "Wet Paper"])
    p("  watched: 1 (rx_love, 21 Oct); the 3 playlist saves were never watched")


@fact("I01.0")
def _():
    y = [e for e in W if e["d"].year == 2024]
    nw = [e for e in y if not e["private"]]
    p("  2024 opens:", len(y), "; shown (private out):", len(nw), C(nw, "tname"), C(nw, "ch"))
    p("  hours of the 8 shown:", sorted(Counter(e["t"].hour for e in nw).items()), "; 18:00 = 3/8 = 37.5%")


if __name__ == "__main__":
    import json
    d = json.load(open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group2.json"))
    for m in d["messages"]:
        OUT.append("=" * 80)
        OUT.append(f"{m['key']} [{m['set']}] {m['message']}")
        if m["key"] in F:
            F[m["key"]]()
        else:
            OUT.append("  (facts not yet written)")
    open("facts.txt", "w").write("\n".join(OUT) + "\n")
    print("\n".join(OUT))
