"""reader2a: rows of the made-up library, flattened, with New York local dates. Reads rows only."""
import sys
from collections import Counter, defaultdict
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # noqa: E402

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships (PRIVATE)"}

EV = []  # one per event
for r in B.rows():
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], plat=r["platform"], kind=k, t=t, d=t.date(), theme=r["theme"],
                       tname=THEME[r["theme"]], area=AREA[r["theme"]],
                       ch=r.get("channel") or r.get("handle"), length=r["length"], cap=r["caption"],
                       friend=bool(r.get("friend")), private=r["theme"] == "da", pub=r["published"]))


def sel(**kw):
    out = EV
    for k, v in kw.items():
        if callable(v):
            out = [e for e in out if v(e[k])]
        else:
            out = [e for e in out if e[k] == v]
    return out


def C(evs, key):
    return Counter(e[key] for e in evs).most_common()


def by_year(evs, key="area"):
    d = defaultdict(Counter)
    for e in evs:
        d[e["d"].year][e[key]] += 1
    return {y: d[y].most_common() for y in sorted(d)}
