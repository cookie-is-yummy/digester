# reader2a batch 2: messages 11-20
# N036.0 instagram reels in october how many  (4 reels, 12-15 Oct, Mon-Thu 08:00 NY, all wetpaper.ig watercolor)
M("N036.0", "h91", "acceptable", "y", "y", "y", "y", lt=1, lu=0,
  wb=[("All 4 of your Instagram items in that window were from Watercolor painting, opened on weekdays in the morning.", "lenient",
       "true of the reels opened (the scope is 'what you opened'); the window also holds 3 saved cooking posts, which are not 'Instagram items' opened")],
  note="count true; export-end limit is wanted for an October question")
M("N036.0", "ola", "acceptable", "y", "y", "y", "y", lt=2, lu=1, note="true; the export end is said twice (lead and point)")
M("N036.0", "c5j", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note="true; bare count with the needed limit")
M("N036.0", "fva", "good", "y", "y", "n", "y", lt=1, lu=0, note="true; 'one channel' = wetpaper.ig")

# N049.0 that video about integrals (21 'Integrals by parts' videos, Limit Lane; 19 in Jun-Aug 2023, 2 in Sep/Oct 2026)
M("N049.0", "qme", "acceptable", "y", "n", "n", "n", note="all dates true; four candidates and an ask-back; does not say there are 21 or that two are from 2026")
M("N049.0", "rya", "acceptable", "y", "n", "n", "n", note="true; two candidates and an ask-back")
M("N049.0", "ze2", "poor", "y", "n", "n", "y",
  wb=[("Integrals by parts #6 followed on 8 June 2023, and the series runs on through June 2023.", "firm",
       "the series runs to 24 Aug 2023 and has two more in Sep and Oct 2026; 'runs on through June' reads as ending in June")],
  cause="wrongly based", note="no ask-back while the match is one of 21")
M("N049.0", "l6d", "poor", "y", "n", "n", "y", false=["All five of these are from Limit Lane."],
  cause="wrong fact", note="'five' matches nothing: three are named, two cards shown, 21 videos match")

# N053.0 dating every week in 2024 (topic named by the person: unlocked). 50 on 50 days, 1 Feb-15 Aug 2024; every ISO week of that span has one (29 weeks); months 8,7,8,8,7,8,4; evening 17-19h 34/50 = 68%
M("N053.0", "jps", "good", "y", "y", "y", "y", note="true; 'not quite' fair: not all year, Feb to mid-Aug only")
M("N053.0", "tg8", "good", "y", "y", "y", "y", note="true")
M("N053.0", "r1h", "good", "y", "y", "y", "y", note="true; evening 68% true with evening = 17:00-20:59")
M("N053.0", "rnp", "poor", "y", "y", "n", "y", false=["In 2024 you opened 50 dating videos, on 50 different days, so about one a week from February to August."],
  cause="wrong fact", note="50 over the 29 weeks of Feb to mid-Aug is about 1.7 a week, not about one; rest true")

# N053.1 compare to 2023 (2024: 50; 2023: 0). The topic is carried from the previous turn (scope line 'the topic you asked about'); all four name Heart Notes; not marked as a privacy fault (see note)
M("N053.1", "p4a", "acceptable", "y", "n", "n", "y", priv="y", note="privacy by the letter: Heart Notes (private topic channel) named in a turn where the person said only \'that year\'; true; the 366 vs 365 days point is filler system talk; Heart Notes named in a follow-up on the topic the person named")
M("N053.1", "dfo", "acceptable", "y", "n", "n", "y", priv="y", note="privacy by the letter: Heart Notes (private topic channel) named in a turn where the person said only \'that year\'; true; days-in-year point is filler; Heart Notes named in the follow-up")
M("N053.1", "h7l", "acceptable", "y", "n", "y", "y", priv="y", note="privacy by the letter: Heart Notes (private topic channel) named in a turn where the person said only 'that year'; capped at acceptable; otherwise true: 36/50 = 72% weekdays")
M("N053.1", "tce", "acceptable", "y", "n", "n", "y", priv="y", note="privacy by the letter: Heart Notes (private topic channel) named in a turn where the person said only \'that year\'; true; 'the topic you asked about opened 50 items' clumsy; days-in-year filler; Heart Notes named in the follow-up")

# N062.0 anything from 2020 (record starts 5 Jan 2021; 2021 holds 134 opens; all history 729 = 723 opens + 6 saves, private and friend out)
M("N062.0", "kcm", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note="true; the limit is the answer; bare, no offer")
M("N062.0", "kg7", "acceptable", "y", "n", "y", "n", lt=1, lu=0, note="true; no offer")
M("N062.0", "pbh", "good", "y", "y", "y", "y", lt=1, lu=0, note="true; 126/134 = 94% gaming in 2021")
M("N062.0", "hcf", "acceptable", "y", "n", "y", "n", lt=1, lu=0, note="true; 729 is right (no likes in the rows, so 'liked' adds nothing); 'By month?' over all history not natural")

# N063.0 late October (21-30 Oct: 38 opens; gaming 19 = 50% all Clip Factory Shorts; art 10 = 26% (DD 9 + Wet Paper 1); food 9 = 24% Pan Theory)
M("N063.0", "xbb", "good", "y", "y", "y", "y", note="true")
M("N063.0", "css", "good", "y", "y", "y", "y", note="true")
M("N063.0", "sfx", "good", "y", "y", "y", "y", note="true")
M("N063.0", "fr8", "good", "y", "y", "y", "y", note="true; Shorts 19/38 = 50%")

# N063.1 all October (142 opens = 138 YouTube + 4 reels; gaming 72 = 51%, art 34 = 24%, food 32 = 23%; Clip Factory 61)
M("N063.1", "vya", "good", "y", "y", "y", "y", note="true")
M("N063.1", "ogt", "acceptable", "y", "n", "n", "y", note="true; a list of areas and the top channel, no reading")
M("N063.1", "w9h", "acceptable", "y", "n", "n", "y", note="true; 61 of 142 is a channel figure, not a reading; same content as ogt")
M("N063.1", "d40", "acceptable", "y", "n", "y", "n", note="true; 'By month?' on a single month")

# N064.0 mid 2023 (May-Aug: 138; math 135 = 98%; Calculus 75 Limit Lane from 3 Jun; puzzles 60 Odd Prime from 5 Jun; food 2, gaming 1)
M("N064.0", "xpz", "good", "y", "y", "y", "y", note="true")
M("N064.0", "g54", "good", "y", "y", "y", "y", note="true; window not stated, 138 matches May-Aug")
M("N064.0", "phf", "good", "y", "y", "y", "y", note="true")
M("N064.0", "wqg", "good", "y", "y", "y", "y", note="true")

# N067.0 november vs october (nothing after 30 Oct: the limit is the answer; October as above; evening 17-20h 95/142 = 67%)
M("N067.0", "ck5", "acceptable", "y", "n", "y", "n", lt=1, lu=0, note="true; 'And lately?' repeats October, the latest month")
M("N067.0", "m9e", "acceptable", "y", "n", "y", "n", lt=1, lu=0, note="true; 'I can't compare' fair since November is empty; 'And lately?' repeats October")
M("N067.0", "bhx", "acceptable", "y", "n", "y", "n", lt=1, lu=0, note="true (evening 67%); 'And lately?' repeats October")
M("N067.0", "j6g", "acceptable", "y", "n", "y", "y", lt=1, lu=0,
  wb=[("Home cooking came next with 32 videos, all from Pan Theory.", "lenient",
       "a theme said next after an area and a channel; right as theme (2nd) and channel (2nd), but art and design (34) is the next area")],
  note="rest true")

# N069.0 the watercolor tips one (rx_love, Wet Paper, 21 Oct 2026; full title held in the history; the title plants a feeling and is quoted as a title in all four, not asserted)
M("N069.0", "ijg", "poor", "y", "n", "y", "y", false=["The title is cut short in your history, so this is the closest of the matches for that name in October 2026."],
  cause="wrong fact", note="the history holds the full title; quoting the title is data, not a fault; reels 1 and 2 dates true")
M("N069.0", "fz3", "acceptable", "y", "n", "n", "y", note="true; the Instagram point adds little")
M("N069.0", "t4i", "poor", "y", "n", "n", "y", false=["Its title is clipped in your history, so the full title is longer than shown here."],
  cause="wrong fact", note="the history holds the full title; only the display is clipped")
M("N069.0", "pv3", "acceptable", "y", "n", "n", "y", lt=1, lu=1, note="true; the point is system talk about search the question did not call for")
