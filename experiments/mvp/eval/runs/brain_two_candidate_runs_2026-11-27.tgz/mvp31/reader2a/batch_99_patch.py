# reader2a patch after the consistency pass: brief = n where the answer says a thing twice, carries filler or
# system talk, or its points only repeat the cards; limit sentences that were not counted.
for mid, code in [("N036.0", "ola"), ("N109.0", "cnp"), ("N109.0", "may"), ("A06.0", "il0"), ("F15.0", "xxd"),
                  ("N053.1", "p4a"), ("N053.1", "dfo"), ("N053.1", "tce"), ("D03.1", "tzk"), ("D03.1", "zxb"),
                  ("D03.1", "s0v"), ("D03.1", "fbk"), ("D03.2", "dnk"), ("D03.2", "ync"), ("N069.0", "pv3"),
                  ("C09.0", "vml"), ("N049.0", "qme")]:
    P(mid, code, brief="n")
P("N049.0", "rya", limits_talk=1, limits_unwanted=0)
P("N049.0", "l6d", limits_talk=1, limits_unwanted=0)
P("N069.0", "ijg", limits_talk=1, limits_unwanted=1)
P("N069.0", "t4i", limits_talk=1, limits_unwanted=1)
