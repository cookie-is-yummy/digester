"""reader2a: marks builder. Each batch file adds M(...) calls; this writes marks.json (upsert on message_id, code)."""
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
MARKS = {}


def M(mid, code, grade, ans, means, more, offer, brief="y", false=(), wb=(), scope="n", lo="n", priv="n",
      lt=0, lu=0, cause="", note=""):
    assert grade in ("good", "acceptable", "poor")
    firm = [w for w in wb if w[1] == "firm"]
    len_ = [w for w in wb if w[1] == "lenient"]
    if grade != "poor":
        assert not false and not firm and ans == "y" and not cause, (mid, code)
    else:
        assert cause, (mid, code)
    MARKS[(mid, code)] = {
        "message_id": mid, "code": code, "grade": grade,
        "false_n": len(false), "false_sentences": list(false),
        "wb_firm_n": len(firm), "wb_lenient_n": len(len_),
        "wb_sentences": [f"[{w[1]}] {w[0]} -- {w[2]}" for w in wb],
        "wrong_scope": scope, "limit_only": lo, "privacy_fault": priv,
        "answers": ans, "means": means, "more": more, "offer": offer, "brief": brief,
        "limits_talk": lt, "limits_unwanted": lu, "poor_cause": cause if grade == "poor" else "", "note": note}


def P(mid, code, **kw):
    """Patch fields of a mark already made (applied after the batches)."""
    r = MARKS[(mid, code)]
    for k, v in kw.items():
        assert k in r, k
        r[k] = v


if __name__ == "__main__":
    for f in sorted(glob.glob(os.path.join(HERE, "batch_*.py"))):
        exec(open(f).read(), {"M": M, "P": P})
    pkt = json.load(open(os.path.join(HERE, "..", "blind", "group2.json")))
    order = [(m["key"], a["code"]) for m in pkt["messages"] for a in m["answers"]]
    out = [MARKS[k] for k in order if k in MARKS]
    extra = [k for k in MARKS if k not in set(order)]
    assert not extra, extra
    json.dump(out, open(os.path.join(HERE, "marks.json"), "w"), indent=1)
    missing = [k for k in order if k not in MARKS]
    from collections import Counter
    print("marked", len(out), "of", len(order), "missing", len(missing), Counter(m["grade"] for m in out))
