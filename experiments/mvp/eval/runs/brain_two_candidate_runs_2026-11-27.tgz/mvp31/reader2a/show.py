import json, sys
d = json.load(open('/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31/blind/group2.json'))
a, b = int(sys.argv[1]), int(sys.argv[2])
for m in d['messages'][a:b]:
    print('=' * 100)
    print(m['key'], m['set'], 'MSG:', m['message'])
    for t in m['earlier_turns']:
        print('  EARLIER:', json.dumps(t)[:300])
    for x in m['answers']:
        print('-' * 40, x['code'], 'empty' if x['empty'] else '')
        for e in x['earlier_answers_seen']:
            print('   [seen before]:', json.dumps(e)[:600])
        print(x['sent'])
        p = x['parts']
        if p.get('cards'):
            print('   CARDS:', json.dumps(p['cards'])[:1500])
        if p.get('limit_lines'):
            print('   LIMITS:', p['limit_lines'])
        if p.get('ask_back'):
            print('   ASKBACK:', p['ask_back'])
