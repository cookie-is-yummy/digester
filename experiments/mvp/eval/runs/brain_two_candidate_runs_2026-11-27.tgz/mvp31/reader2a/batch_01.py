# reader2a batch 1: messages 1-10
# N002.0 what does my youtube say about me
M("N002.0", "az3", "good", "y", "n", "y", "y", note="all true: 319/719=44%, art 25%, math 20%, food 10%; 'Brick Realm alone made 163 of them' is all of the theme, said oddly")
M("N002.0", "nfc", "good", "y", "n", "y", "y", note="all true")
M("N002.0", "iri", "good", "y", "n", "y", "y", note="all true; Calculus 85 of math 145 = 'mostly' fair")
M("N002.0", "zy0", "acceptable", "y", "n", "y", "n", note="all true; 'By month?' over six years of history is not a natural next step")

# N005.0 anything kept watching every year
M("N005.0", "ecz", "poor", "y", "y", "n", "y",
  wb=[("Your history has few items in 2024: 8 in all, so the run is not unbroken across every year for every channel.", "firm",
       "8 is the count without private rows; the history holds 58 opens in 2024, so 'your history has few items' reads past the private line")],
  cause="wrongly based", note="lead true (Pan Theory every year, 1 Feb 2021 to 30 Oct 2026, 72); third point garbled and reads past the private line")
M("N005.0", "a14", "poor", "y", "y", "y", "n",
  wb=[("Brick Realm also runs the whole export: first watched on 5 January 2021, last on 20 October 2026, with 163 videos.", "firm",
       "dates and count right, but Brick Realm has no opens in 2023, 2024 or 2025; to an every-year question 'also runs the whole export' misleads")],
  cause="wrongly based", note="lead true (Home cooking in every year); 'By month?' over six years not natural")
M("N005.0", "xjy", "good", "y", "y", "y", "y", note="all true; 723 = 719 YouTube + 4 Instagram reels opened, 72/723 = 10%")
M("N005.0", "dwd", "acceptable", "y", "y", "n", "n", note="true; 'within food and cooking' clumsy, 'dated' could read as publish date; 'By month?' over six years not natural")

# N005.1 which year was the most gaming heavy
M("N005.1", "kvx", "good", "y", "n", "y", "y", note="true: 2021 126/134=94%, 2022 100/108=93%; no private line but 2021/2022 hold no private rows, so nothing hidden in the figures")
M("N005.1", "yoc", "good", "y", "n", "y", "y", note="true; 254 = 2026 opens on both platforms (250 YouTube + 4 reels)")
M("N005.1", "ndr", "good", "y", "y", "y", "y", note="true; drop to 14 in 2023, 0 in 2024, back to 79 in 2026")
M("N005.1", "tuy", "good", "y", "y", "y", "y", note="true; 0 in 2024 and 2025, 14 of 157 in 2023")

# N010.0 this summer vs last summer
M("N010.0", "hhv", "good", "y", "y", "y", "y", note="true: 45 vs 16, Digital drawing 32 new, Watercolor 14 to 13")
M("N010.0", "a4f", "acceptable", "y", "y", "y", "y",
  wb=[("Watercolor painting fell from 14 videos to 13; the whole window sits in art and design.", "lenient",
       "true of summer 2026 (45 all art); summer 2025 had 2 cooking videos, but a fair reader takes 'the window' as this summer")],
  note="otherwise true")
M("N010.0", "d6r", "acceptable", "y", "y", "y", "n", note="true; no offer")
M("N010.0", "hmm", "good", "y", "y", "y", "y", note="true")

# N010.1 just the art side
M("N010.1", "sqx", "good", "y", "y", "y", "y", note="true: art 45 vs 14, up 31; DD 32; Watercolor 13 vs 14")
M("N010.1", "d1o", "good", "y", "y", "y", "y", note="true")
M("N010.1", "mgq", "good", "y", "y", "y", "y", note="true")
M("N010.1", "e6f", "good", "y", "y", "y", "y", note="true; 32/45 = 71%")

# N013.0 last time any minecraft
M("N013.0", "k7n", "acceptable", "y", "n", "y", "y",
  wb=[("Brick Realm's Minecraft builds account for all 163 videos you opened in your history.", "lenient",
       "reads at first as if 163 were all you opened; with the theme in the scope line a fair reader takes it as the 163 Minecraft videos")],
  note="last 20 Oct 2026 Brick Realm true")
M("N013.0", "hbg", "good", "y", "n", "y", "y", note="true")
M("N013.0", "byq", "good", "y", "n", "y", "y", note="true; previous one Minecraft village makeover #162 on 17 Oct 2026 is right")
M("N013.0", "ynp", "good", "y", "n", "y", "y", lt=1, lu=0, note="true; the export-end line is fair for a 'last time' question asked on 22 Nov")

# N013.1 and the first time
M("N013.1", "ayx", "good", "y", "n", "y", "y", note="true: Minecraft redstone door #1, 5 Jan 2021, Brick Realm only channel")
M("N013.1", "xoq", "good", "y", "n", "y", "y", note="true")
M("N013.1", "a6v", "good", "y", "n", "y", "y", note="true")
M("N013.1", "tej", "good", "y", "n", "y", "y", note="true")

# N014.0 last cooking video
M("N014.0", "bbh", "acceptable", "y", "n", "n", "n", note="true (Cooking soup on the 30th, 30 Oct NY); bare, no offer")
M("N014.0", "m31", "acceptable", "y", "n", "n", "n", note="true; bare, no offer")
M("N014.0", "tlq", "acceptable", "y", "n", "n", "y", note="true; bare lookup with nothing more")
M("N014.0", "mee", "acceptable", "y", "n", "n", "n", note="true; bare, no offer")

# N034.0 long videos this year
M("N034.0", "zrz", "poor", "y", "y", "y", "y",
  wb=[("Home cooking came next with 32 videos from Pan Theory.", "firm",
       "said after Digital drawing as the next theme; Watercolor painting (37) is next, and it is never named")],
  cause="wrongly based", note="rest true: 129/184 = 70%, DD 92, Minecraft 13, Calculus 10")
M("N034.0", "s0m", "acceptable", "y", "y", "y", "y",
  wb=[("Home cooking came next in food and cooking with 32 videos, from Pan Theory.", "lenient",
       "area named beside the theme: food and cooking is the next area; Watercolor 37 is the next theme")],
  note="'Only long videos?' repeats; 'By month?' fine")
M("N034.0", "nyx", "acceptable", "y", "y", "y", "n", note="true; the one offer 'Only long videos?' repeats what was shown")
M("N034.0", "exk", "good", "y", "y", "y", "y", note="true: DD 92 = 50%, Watercolor 37, Home cooking 32, Minecraft 13, Calculus 10")

# N034.1 no I meant the short ones
M("N034.1", "n6j", "good", "y", "y", "y", "y", note="true: 70 short, gaming 66 = 94%, Clip Factory 61, 4 watercolor reels")
M("N034.1", "yrf", "good", "y", "y", "y", "y", note="true")
M("N034.1", "lrh", "good", "y", "y", "n", "y", note="true; 'Art and design came next' is right at the area level of the lead")
M("N034.1", "scj", "good", "y", "y", "y", "y", note="true; 61/70 = 87%")
