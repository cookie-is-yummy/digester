G0 = "scope: whole gaming area removed where the person named gaming clips (Minecraft builds 5 also left out); scope line says it; not capped, same for all four. "
M("N001.0", "m91", "poor", "y", "n", "y", "y",
  wb=[("firm", "Digital drawing from Pixel Pencil was the largest single theme, with 27 videos.",
       "27 is right but Home cooking had 30 in the same window: wrong rank")],
  cause="wrongly based", note=G0 + "Lead and first point true (32/66=48%, food 30=45%).")
M("N001.0", "bsg", "acceptable", "y", "n", "y", "y", lt=1, lu=0,
  note=G0 + "All figures true (32/66, 30=45%, Digital drawing 27). Reads as a list; export-end clause is fair for 'lately'.")
M("N001.0", "g08", "good", "y", "y", "y", "y",
  note=G0 + "True: 78%->48% art (-30), food 5%->45% (+40) on 5 Sep-2 Oct. 'rose up'/'fell down' clumsy.")
M("N001.0", "j6q", "acceptable", "y", "n", "y", "y",
  note=G0 + "All true; first point repeats the lead as a share.")

M("N001.1", "yng", "acceptable", "y", "y", "n", "y", lt=0,
  note="True: 32 of 72 in Oct 2026, 0 in Sep, all Pan Theory; 23% = 30/130 of all opens in the 4 weeks (base clumsy beside 'only food and cooking' scope line but named). Does not say the history cannot show why.")
M("N001.1", "qf4", "good", "y", "y", "n", "y", lt=1, lu=0,
  note="True: 32 in Oct, 0 in Sep, earlier months at most 1; 30 vs 2 in the 4 weeks before. Says the history shows what, not why (wanted for 'why').")
M("N001.1", "jom", "good", "y", "y", "y", "y",
  note="True: 45%, +40 points, 30 vs 2, Pan Theory since 1 Feb 2021; 'almost entirely' understates 'all'. Good reading: an old channel coming back.")
M("N001.1", "y8p", "poor", "n", "y", "n", "y", lt=1, lu=1,
  false=["This result has no earlier window to compare with, so it can't show when the jump started."],
  cause="wrong fact",
  note="Statement about the turn, tally to settle: the rows hold the earlier window (2 in the 4 weeks before, 0 in Sep). Other lines true (30, 25 of 28 days). Does not show the sudden jump.")

M("N007.0", "eks", "acceptable", "y", "y", "n", "y", lt=1, lu=1,
  note="All true (35 Speedruns all Frame Perfect, last 1 May 2023, 0 this year; Minecraft 91 -> 13, last 20 Oct 2026; 303 days). Third point is heavy caveat talk; 'still open' clumsy.")
M("N007.0", "x23", "good", "y", "y", "n", "y", note="All true. Clear: one drop, one fade.")
M("N007.0", "vdq", "good", "y", "y", "n", "y", note="All true: 35 of 134 in 2021; 13 of 254 this year.")
M("N007.0", "s22", "acceptable", "y", "y", "n", "n",
  wb=[("lenient", "Minecraft builds fell from 91 in 2021 to 5 in the 4 weeks up to 30 October 2026.",
       "a year against 4 weeks, both named; 'fell' over unlike windows")],
  note="Figures true (5 Minecraft in 3-30 Oct). Offer 'And in 2021?' repeats what was asked.")

M("N008.0", "ype", "acceptable", "y", "y", "n", "n",
  note="True, but month by month leaves out March to July; 'sparse' carries meaning. Offer generic.")
M("N008.0", "pzr", "acceptable", "y", "y", "n", "n",
  note="True, but leaves out Feb-May and Jul; odd pick of Jan and Jun. Offer generic.")
M("N008.0", "c00", "good", "y", "y", "n", "y", note="True: Jan-Jul each 4 or 5; covers every month.")
M("N008.0", "pu9", "good", "y", "y", "y", "n",
  note="Every month given and true; Digital drawing 92 since 1 Aug and Gaming clips 66 since 1 Oct explain the rise. Offer 'By month?' repeats what was shown.")

M("N008.1", "u41", "good", "y", "y", "y", "y",
  note="True: Oct 142, gaming 72=51%, Clip Factory 61, Pan Theory 32 (second channel), Pixel Pencil 29.")
M("N008.1", "noa", "good", "y", "y", "y", "y", note="True: 72 of 142, 66 clips, 61 Clip Factory, 29, 32.")
M("N008.1", "af3", "acceptable", "y", "y", "y", "n",
  wb=[("lenient", "Art and design came next with 34 videos, and Home cooking had 32 from Pan Theory.",
       "area said next after a theme (Gaming clips 66 of gaming's 72, so not the area-is-its-theme case); art is second at area level, so a fair reader is not misled")],
  note="Figures true. Offer 'By month?' on one month is generic.")
M("N008.1", "vua", "acceptable", "y", "y", "y", "n",
  wb=[("lenient", "Art and design came next with 34 videos, and food and cooking had 32.",
       "area said next after a theme (Gaming clips 66 of gaming's 72); second at area level, a fair reader not misled")],
  note="Figures true. No offer.")

M("N012.0", "rie", "good", "y", "y", "y", "y",
  note="True: 157 vs 108, math 0%->86%, gaming 93%->9%, Minecraft 59 -> 0, calc 75, puzzles 60.")
M("N012.0", "uim", "acceptable", "y", "y", "n", "y",
  note="True; lower-case area names; second point repeats the lead's math figure.")
M("N012.0", "m4y", "good", "y", "y", "y", "y", note="All true.")
M("N012.0", "uve", "good", "y", "y", "y", "y", note="All true.")

M("N022.0", "brw", "good", "y", "n", "y", "y", note="True: 75, 60, 14, 8 of 157; math 86%.")
M("N022.0", "h47", "acceptable", "y", "n", "n", "y", note="True (60 = 38%); a flat list.")
M("N022.0", "hs0", "good", "y", "n", "y", "y", note="True; math 86% rolls it up.")
M("N022.0", "i62", "acceptable", "y", "n", "y", "y",
  note="True; clumsy 'had 8, of what you opened' and lower-case 'math'.")

M("N022.1", "ejl", "good", "y", "y", "y", "y",
  note="True: 135, 75 (56%) Limit Lane, 60 (44%) Odd Prime, Odd Prime last 22 Aug 2023, Limit Lane 16 Oct 2026.")
M("N022.1", "mo5", "acceptable", "y", "y", "y", "y", note="True; lead 'In 2023, only math, you opened' clumsy.")
M("N022.1", "u4o", "good", "y", "y", "y", "y", note="All true.")
M("N022.1", "irg", "good", "y", "y", "y", "y", note="All true.")

for c in ["zai", "qso", "vz0", "ug3"]:
    M("N024.0", c, "acceptable", "y", "n", "n", "y",
      note="True: art 133 (52%), gaming 79 (31%), food 32 (13%), math 10 (4%) of 254 (4 of them Instagram). A bare split with no themes behind it.")

M("N024.1", "ikl", "acceptable", "y", "n", "n", "n",
  note="True: 54 of 62, watercolor 87% all Wet Paper, food 8 Pan Theory. Does not say gaming and math had 0. Offer 'And last year?' unclear after a correction to 2025.")
M("N024.1", "njo", "acceptable", "y", "n", "n", "y", note="True; gaming and math at 0 not said.")
M("N024.1", "ust", "good", "y", "y", "n", "y",
  note="True: only art and food had opens (gaming, math 0), 54 of 62 = 87%, food 8 Home cooking. Lead wording 'In 1 January to 31 December 2025' clumsy.")
M("N024.1", "x8l", "acceptable", "y", "n", "n", "y", note="True; gaming and math at 0 not said.")

M("N027.0", "omm", "good", "y", "y", "n", "y",
  note="True (private line shown): evening 498 of 723 = 69%, afternoon 219 = 30%, night 1.")
M("N027.0", "ry6", "good", "y", "y", "y", "n",
  note="True: 5-9pm 498, noon-5pm 219, 9pm-5am 1, mornings 5. Offer 'By month?' generic here.")
M("N027.0", "lau", "good", "y", "y", "n", "n", note="True. Offer 'Only long videos?' generic here.")
M("N027.0", "jk2", "good", "y", "y", "y", "y", note="True.")

M("N029.0", "kk3", "acceptable", "y", "n", "n", "y",
  note="True (private line): gaming 44 of 101, art 26%, math 20, food 11. No themes named.")
M("N029.0", "fnb", "good", "y", "y", "y", "n",
  note="True: Digital drawing 14 of art's 26; Minecraft builds 23 all Brick Realm. Offer generic.")
M("N029.0", "beh", "good", "y", "y", "y", "y", note="True: Minecraft builds top theme 23.")
M("N029.0", "xke", "good", "y", "y", "y", "y", note="True.")

for c, off in [("dky", "n"), ("v59", "n"), ("wyh", "n"), ("ofa", "n")]:
    M("N041.0", c, "good", "y", "n", "y", off,
      note="True: 6 saves (3 YouTube playlist, 3 Instagram), watercolor 3, cooking 3; friend's save left out by rule. Offer generic: all saves are in October 2026.")
