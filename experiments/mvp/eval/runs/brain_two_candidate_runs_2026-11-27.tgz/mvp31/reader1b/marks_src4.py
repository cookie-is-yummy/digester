B5 = ("No window asked: over all history Frame Perfect (last 1 May 2023) and Odd Prime (last 22 Aug 2023) were dropped (and a private channel in 2024). "
      "All four answer only for the 4 weeks (said in the text), where no channel of 5 Sep-2 Oct stopped (true), so 'no channel dropped' misleads; same for all four. ")
M("B05.0", "i2y", "poor", "n", "n", "n", "n", lt=1, lu=1, cause="misses the question",
  note=B5 + "Gaming Daily last 5 Oct, 3 in window: true. 'the tools flag' is system talk.")
M("B05.0", "wkq", "poor", "n", "n", "n", "y", cause="misses the question",
  note=B5 + "Pixel Pencil 29->27, Brick Realm 7->5, Limit Lane 6->4, last 16 Oct: true.")
M("B05.0", "rh3", "poor", "n", "n", "n", "n", lt=1, lu=1, cause="misses the question",
  note=B5 + "Gaming Daily 3, Limit Lane 4: true; export-end line not called for.")
M("B05.0", "zra", "poor", "n", "n", "n", "n", cause="misses the question",
  note=B5 + "'your stopped channels list is empty' is system talk; Gaming Daily and Limit Lane lines true.")

WK7 = "24-30 Oct: 24 opens; Clip Factory 13 (54%, all 40 s Shorts), Pixel Pencil 6, Pan Theory 5. Hand-back line called for by the message."
M("B11.0", "q5g", "good", "y", "n", "y", "y", lt=2, lu=0, note=WK7 + " True.")
M("B11.0", "m8o", "acceptable", "y", "n", "n", "y", lt=2, lu=1,
  wb=[("lenient", "Your export ends on 30 October 2026, so I can't set up a Sunday report; in the last 7 days up to 30 October 2026, Clip Factory led what you opened, with 13 of 24 videos.",
       "true end date given as the reason it cannot schedule; the hand-back line under it gives the real reason")],
  note=WK7 + " 54% point repeats the lead.")
M("B11.0", "x6z", "good", "y", "y", "y", "y", lt=2, lu=1, note=WK7 + " True; 'I can't send things on a schedule' doubles the hand-back line.")
M("B11.0", "gfl", "acceptable", "y", "n", "n", "n", lt=2, lu=0, note=WK7 + " True; no offer.")

SR = "Last speedrun: Speedrun glitch explained #90, Frame Perfect, 1 May 2023; 90 in all, Frame Perfect only."
M("C08.0", "zxw", "acceptable", "y", "n", "n", "y",
  wb=[("lenient", "Your history holds 90 speedrun videos you opened, all of them up to your export's end on 30 October 2026.", "the scope's end said as the span of the speedruns (last one 1 May 2023, said in the lead)")],
  note=SR)
M("C08.0", "vfk", "good", "y", "y", "y", "y", note=SR + " True.")
M("C08.0", "glt", "good", "y", "n", "n", "y", note=SR + " True and brief.")
M("C08.0", "s62", "acceptable", "y", "n", "y", "y", note=SR + " True; third point repeats the lead's date.")

Y22 = "2022: 108, gaming 100 (93%), Minecraft builds 59 Brick Realm (55%), Speedruns 41 Frame Perfect, Home cooking 8 Pan Theory."
M("D04.0", "nob", "good", "y", "y", "y", "y", note=Y22 + " True.")
M("D04.0", "ubv", "acceptable", "y", "n", "n", "y", note=Y22 + " True but thin: Speedruns (41) left out.")
M("D04.0", "i58", "good", "y", "y", "y", "y", note=Y22 + " True.")
M("D04.0", "ht9", "good", "y", "y", "y", "y", note=Y22 + " True.")

IG = "Instagram opens start 12 Oct 2026 (saves 5 Oct): nothing on Instagram in 2022; the limit is the answer. 108 YouTube opens in 2022."
M("D04.1", "kcz", "good", "y", "n", "y", "y", lt=1, lu=0, note=IG + " True.")
M("D04.1", "ohu", "acceptable", "y", "n", "n", "y", lt=2, lu=1, note=IG + " True; second line ('left out of this ranking') is system talk.")
M("D04.1", "hrg", "good", "y", "n", "y", "y", lt=1, lu=0, note=IG + " True.")
M("D04.1", "hgn", "good", "y", "n", "y", "y", lt=1, lu=0, note=IG + " True; second line clumsy.")

E4 = "2025 channels Wet Paper and Pan Theory both still opened in 2026: none stopped. Wet Paper 37 in 2026 vs 45 in 1 Jan-30 Oct 2025 (54 in all 2025), last 21 Oct; Pan Theory rose 7->32. Watercolor 87% of 2025 (either base) -> 41/254 = 16% in 2026."
M("E04.0", "efa", "good", "y", "y", "y", "y", note=E4 + " True.")
M("E04.0", "vfm", "poor", "y", "y", "y", "y",
  wb=[("firm", "The one channel that fell in count is Wet Paper, with 40 videos this year against 45 in 2025, down 5 videos.",
       "40 is opens plus the 3 never-watched playlist saves (37 opens); 45 is the 1 Jan-30 Oct 2025 stretch said as all 2025 (54)"),
      ("firm", "Watercolor painting fell from 87% of what you opened in 2025 to 17% this year.",
       "17% is opens plus saves (44 of 260) said as 'of what you opened' (41 of 254 = 16%)")],
  cause="wrongly based",
  note=E4 + " Both figures come from an opens-plus-saves read; not false by the rubric's line, wrongly based firm.")
M("E04.0", "ycu", "good", "y", "y", "y", "y", note=E4 + " True.")
M("E04.0", "a8h", "good", "y", "y", "y", "y", note=E4 + " True (16%).")

YD = "Yesterday (21 Nov) is after the export's end (limit is the answer). 30 Oct 2026 (New York): 4 opens, rday1-4: 2 Pixel Pencil, 1 Clip Factory, 1 Pan Theory, all YouTube."
M("F02.0", "p6w", "good", "y", "n", "y", "y", lt=1, lu=0, note=YD + " True; points partly repeat cards.")
M("F02.0", "hfp", "good", "y", "n", "y", "y", lt=1, lu=0, note=YD + " True.")
M("F02.0", "uz4", "good", "y", "n", "y", "y", lt=1, lu=0, note=YD + " True.")
M("F02.0", "u49", "good", "y", "n", "y", "y", lt=1, lu=0, note=YD + " True; names the themes.")

F4 = "Speedruns: 90, all Frame Perfect, 1 Mar 2021 to 1 May 2023, every month in between, 35/41/14 by year, May 2023 had 1; evening 59/90 = 66%. No motive guessed in any."
M("F04.0", "o8i", "good", "y", "y", "n", "y", lt=1, lu=0, note=F4 + " True.")
M("F04.0", "vnc", "good", "y", "y", "y", "y", lt=1, lu=0, note=F4 + " True.")
M("F04.0", "nis", "good", "y", "y", "y", "y", lt=1, lu=0, note=F4 + " True; evening share is a side fact.")
M("F04.0", "qub", "good", "y", "y", "y", "y", lt=1, lu=0, note=F4 + " True.")

F5 = "Gaming clips: 66 (Clip Factory 61, Gaming Daily 5), all 40 s Shorts, 1-30 Oct 2026, on 30 days, evening 45/66 = 68%; 66 of 723 = 9% of all opens (private out). None judges the person."
M("F05.0", "sav", "acceptable", "y", "n", "y", "y", note=F5 + " True; does not say the history cannot judge addiction, and no reading of the numbers.")
M("F05.0", "cy4", "good", "y", "y", "y", "y", lt=1, lu=0, note=F5 + " True; private line shown with the 723 base.")
M("F05.0", "eu5", "acceptable", "y", "n", "y", "y", note=F5 + " True; no reading, does not say it cannot judge.")
M("F05.0", "aph", "poor", "n", "n", "n", "y", cause="thin", note=F5 + " A bare total only.")

F6 = "4 weeks 3-30 Oct: gaming 64 (49%) vs 14 (27%) in 5 Sep-2 Oct (+22 points); Clip Factory 56 (5 before); Shorts 59 of 64 = 92%; Gaming clips 7 -> 59; Minecraft 7 -> 5, last 20 Oct. Gaming all history 319 (240 before Sep 2026); Feb 2026 0, Sep 2026 7."
M("F06.0", "kfr", "acceptable", "y", "y", "y", "y", lt=1, lu=0,
  wb=[("lenient", "Clip Factory supplied 56 of the gaming videos you opened, 92% of them Shorts.",
       "92% is of the gaming videos (59/64); could be read as of Clip Factory's 56 (100%)")],
  note=F6)
M("F06.0", "dl0", "poor", "y", "y", "y", "y",
  wb=[("firm", "Your gaming opens were 0 in Feb 2026 and 7 in Sep 2026, after 319 gaming videos since January 2021.",
       "319 is the all-history total including October 2026; said as the count before September (240)")],
  cause="wrongly based", note=F6 + " Lead and first point true.")
M("F06.0", "r81", "good", "y", "y", "y", "y", lt=1, lu=0, note=F6 + " True.")
M("F06.0", "sdw", "good", "y", "y", "y", "n", note=F6 + " True. Offer generic.")

F8 = "No subscriber counts in the library: limit is the answer. Brick Realm 163 opens, 91 (2021), 59 (2022), 0 (2023-25), 13 (2026), first 5 Jan 2021, last 20 Oct 2026, all Minecraft builds."
M("F08.0", "nex", "good", "y", "y", "y", "y", lt=1, lu=0, note=F8 + " True.")
M("F08.0", "k79", "good", "y", "n", "y", "y", lt=1, lu=0, note=F8 + " True.")
M("F08.0", "kik", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note=F8 + " True; 'opened, liked or saved' clumsy (all 163 are opens); nothing more.")
M("F08.0", "ebk", "good", "y", "n", "y", "y", lt=1, lu=0, note=F8 + " True.")

F10 = "The future is not in the record: the limit is the answer. 4 weeks 3-30 Oct: gaming 49% of 130, Clip Factory 56 (43%), Pan Theory 30, Pixel Pencil 27; Gaming clips 45%."
M("F10.0", "dp1", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note=F10 + " True; 'next week is not in it' does not say it cannot forecast; no reading of the pattern.")
M("F10.0", "w29", "good", "y", "n", "y", "y", lt=1, lu=0, note=F10 + " True.")
M("F10.0", "cco", "good", "y", "n", "y", "y", lt=1, lu=0, note=F10 + " True; names the themes (lower case).")
M("F10.0", "d4y", "acceptable", "y", "n", "n", "y", lt=1, lu=0, note=F10 + " True; 43% point repeats the lead.")
