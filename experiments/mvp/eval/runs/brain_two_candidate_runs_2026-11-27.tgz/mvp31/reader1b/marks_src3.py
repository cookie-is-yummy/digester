A0 = "4 weeks 3-30 Oct: 130 opens, gaming 64 (49%), Gaming clips 59, Clip Factory 56 (all 40 s Shorts); art 57% -> 25% (-32) on 5 Sep-2 Oct; food 4% -> 23% (+19); Home cooking 30 all Pan Theory."
M("A01.0", "t2q", "good", "y", "y", "y", "y", lt=1, lu=0, note=A0 + " All true.")
M("A01.0", "z9a", "good", "y", "y", "y", "y", note=A0 + " All true; 'Home cooking came next' holds at theme and area level.")
M("A01.0", "d1v", "good", "y", "y", "y", "y", lt=1, lu=0, note=A0 + " All true; 56 of 59 'almost all'.")
M("A01.0", "n2g", "good", "y", "y", "y", "y", lt=1, lu=0, note=A0 + " All true.")

A1 = "Themes, 4 weeks: Gaming clips 59 (45%; 14% before -> +32 by unrounded shares), Home cooking 30 (23%, +19; 2 before), Digital drawing 27 (21%; 29 = 57% before, -36)."
M("A01.1", "k7u", "good", "y", "y", "y", "y", lt=1, lu=0, note=A1 + " All true.")
M("A01.1", "ymi", "good", "y", "y", "y", "y", note=A1 + " All true.")
M("A01.1", "vpc", "good", "y", "y", "y", "y", note=A1 + " All true.")
M("A01.1", "s80", "good", "y", "y", "y", "y", note=A1 + " All true.")

A3 = "October 2026 channels: Clip Factory 61 of 142 (43%), Pan Theory 32 (all Home cooking), Pixel Pencil 29 (all Digital drawing)."
M("A01.3", "lsk", "good", "y", "n", "y", "y", note=A3 + " True; names the themes behind.")
M("A01.3", "bpw", "good", "y", "n", "y", "y", note=A3 + " True; word for word as lsk.")
M("A01.3", "as4", "acceptable", "y", "n", "n", "y", note=A3 + " True; a bare ranked list.")
M("A01.3", "wbb", "acceptable", "y", "n", "n", "y", note=A3 + " True; the 43% point repeats the lead as a share.")

A4 = "October 2026 without gaming area: 70 opens; Pan Theory 32 (46%), Pixel Pencil 29 (41%), Limit Lane 4, wetpaper.ig 4, Wet Paper 1; art 34 = 49%. Same 'without gaming' line as N001.0."
M("A01.4", "uuc", "acceptable", "y", "n", "n", "y", note=A4 + " True; third point repeats the lead as a share.")
M("A01.4", "kgj", "acceptable", "y", "n", "n", "y", note=A4 + " True; third point repeats the lead as a share.")
M("A01.4", "ahz", "acceptable", "y", "n", "n", "y", note=A4 + " True; a flat channel list (wetpaper.ig left out, no 'all' claimed).")
M("A01.4", "m5r", "good", "y", "y", "y", "y", note=A4 + " True; adds art 49% at area level.")

A5 = "October 2026 without gaming, only known-long videos: 66; Pan Theory 32 (48%), Pixel Pencil 29, Limit Lane 4, Wet Paper 1 (4 channels; Instagram reels have no length)."
M("A01.5", "gmj", "acceptable", "y", "n", "n", "y", note=A5 + " True; 'These 4 channels make up the list' names only three.")
M("A01.5", "uys", "good", "y", "y", "n", "n", note=A5 + " True: 61 of 66 'nearly all'. Offer 'Only long videos?' repeats what was just done.")
M("A01.5", "t69", "acceptable", "y", "n", "n", "y", note=A5 + " True; flat list.")
M("A01.5", "t2e", "acceptable", "y", "n", "n", "y", note=A5 + " True; flat list.")

B3 = "4 weeks 3-30 Oct, known-long only: 67; food 30 (45%), art 28 (42%; Digital drawing 27, Wet Paper 1), gaming 5 (Minecraft), math 4."
M("B03.0", "ull", "acceptable", "y", "n", "n", "y", note=B3 + " True; first point repeats the lead.")
M("B03.0", "vg1", "good", "y", "n", "y", "y", note=B3 + " True.")
M("B03.0", "nwr", "good", "y", "n", "y", "y", note=B3 + " True; math fewest (4 vs gaming 5).")
M("B03.0", "b5g", "good", "y", "n", "y", "y", note=B3 + " True.")
