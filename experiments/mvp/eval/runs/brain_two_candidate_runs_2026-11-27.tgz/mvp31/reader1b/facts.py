"""Writes facts.txt: the counts behind each message key, from the library rows only (reader1b). Run with python3 -B."""
import io
import os
from contextlib import redirect_stdout

from facts_lib import *  # noqa

HERE = os.path.dirname(os.path.abspath(__file__))
W4 = (D(2026, 10, 3), D(2026, 10, 30))
W4B = (D(2026, 9, 5), D(2026, 10, 2))
ng = lambda e: e["area"] != "gaming"  # noqa
th = lambda k: (lambda e: e["theme"] == k)  # noqa


def part(h):
    return "morning 5-12" if 5 <= h < 12 else "afternoon 12-17" if 12 <= h < 17 else "evening 17-21" if 17 <= h < 21 else "night 21-5"


BLOCKS = {}


def block(key):
    def deco(fn):
        BLOCKS[key] = fn
        return fn
    return deco


@block("N001.0")
def _():
    show("4 weeks 3-30 Oct 2026, without gaming area (both platforms)", sel(start=W4[0], end=W4[1], f=ng))
    show("4 weeks before 5 Sep-2 Oct, without gaming", sel(start=W4B[0], end=W4B[1], f=ng), keys=("area", "tname"))
    show("4 weeks, without Gaming clips theme only", sel(start=W4[0], end=W4[1], f=lambda e: e["theme"] != "cl"), keys=("area", "tname"))


@block("N001.1")
def _():
    co = sel(f=th("co"))
    print("cooking opens all history", len(co), Counter(e["chan"] for e in co), "first", min(e["d"] for e in co))
    print("by month", sorted(Counter((e["d"].year, e["d"].month) for e in co).items()))
    c4 = sel(start=W4[0], end=W4[1], f=th("co"))
    print("4 weeks:", len(c4), "days with one:", len(set(e["d"] for e in c4)), "of 28; 4 weeks before:", len(sel(start=W4B[0], end=W4B[1], f=th("co"))))
    print("4 weeks all opens", len(sel(start=W4[0], end=W4[1])), "-> 30/130 = 23%")
    print("cooking saves (Instagram):", [(e["id"], e["d"]) for e in sel(kind="save", f=th("co"))])


@block("N007.0")
def _():
    show("2021", sel(start=D(2021, 1, 1), end=D(2021, 12, 31)))
    for k in ["sr", "mc", "co"]:
        x = sel(f=th(k))
        print(THEME[k], "first", min(e["d"] for e in x), "last", max(e["d"] for e in x),
              "2026:", len([e for e in x if e["d"].year == 2026]), "4wk:", len([e for e in x if W4[0] <= e["d"] <= W4[1]]))
    print("2026 opens", len(sel(start=D(2026, 1, 1))), "; days 1 Jan-30 Oct 2026 = 303")


@block("N008.0")
def _():
    y = sel(start=D(2026, 1, 1))
    print("2026 opens", len(y), "by month", sorted(Counter(e["d"].month for e in y).items()))
    print("Digital drawing 2026", len([e for e in y if e["theme"] == "dd"]), "Gaming clips", len([e for e in y if e["theme"] == "cl"]))


@block("N008.1")
def _():
    show("October 2026", sel(start=D(2026, 10, 1), end=D(2026, 10, 31)))


@block("N012.0")
def _():
    show("2022", sel(start=D(2022, 1, 1), end=D(2022, 12, 31)))
    show("2023", sel(start=D(2023, 1, 1), end=D(2023, 12, 31)))


@block("N022.0")
def _():
    show("2023", sel(start=D(2023, 1, 1), end=D(2023, 12, 31)))


@block("N022.1")
def _():
    m = sel(start=D(2023, 1, 1), end=D(2023, 12, 31), f=lambda e: e["area"] == "math")
    show("2023 math", m, keys=("tname", "chan", "plat"))
    for k in ["np", "ca"]:
        print(THEME[k], "last", max(e["d"] for e in sel(f=th(k))))


@block("N024.0")
def _():
    show("2026 to 30 Oct", sel(start=D(2026, 1, 1)), keys=("area", "plat"))


@block("N024.1")
def _():
    show("2025", sel(start=D(2025, 1, 1), end=D(2025, 12, 31)))


@block("N027.0")
def _():
    print("all history, private left out:", len(sel()), Counter(part(e["t"].hour) for e in sel()))
    print("with private:", len(sel(private=True)), Counter(part(e["t"].hour) for e in sel(private=True)))


@block("N029.0")
def _():
    show("Saturdays, all history, private out", [e for e in sel() if e["t"].weekday() == 5])
    print("Saturdays with private:", len([e for e in sel(private=True) if e["t"].weekday() == 5]))


@block("N041.0")
def _():
    s = sel(kind=["save", "playlist"], friend=True)
    for e in s:
        print("  ", e["id"], e["kind"], e["plat"], e["d"], e["tname"], e["chan"], "FRIEND" if e["friend"] else "", "|", e["title"][:60])
    print("saves without the friend's:", len([e for e in s if not e["friend"]]))


@block("N041.1")
def _():
    for e in sel(kind="save", plat="instagram", friend=True):
        print("  ", e["id"], e["d"], e["chan"], e["tname"], "FRIEND (never shown)" if e["friend"] else "", "opened:", any(x["id"] == e["id"] and x["kind"] == "watch" for x in EV))
    print("Instagram ends", max(e["d"] for e in EV if e["plat"] == "instagram"))


@block("N042.0")
def _():
    print("event kinds in library:", Counter(e["kind"] for e in EV), "(no likes)")
    s = sel(kind=["save", "playlist"])
    print("saves (no friend):", len(s), "first", min(e["d"] for e in s), "last", max(e["d"] for e in s), Counter(e["tname"] for e in s))


@block("N044.0")
def _():
    co = sorted(sel(f=th("co")), key=lambda e: e["t"], reverse=True)
    print("cooking opens", len(co), Counter(e["chan"] for e in co))
    for e in co[:10]:
        print("  ", e["id"], e["t"], e["title"][:50])


@block("N045.0")
def _():
    for e in sorted(sel(start=D(2026, 9, 1), end=D(2026, 9, 30), f=th("ca")), key=lambda e: e["t"]):
        print("  ", e["id"], e["d"], e["title"], e["chan"])


@block("N055.0")
def _():
    for e in sel(kind=["save", "playlist"], friend=True):
        print("  ", e["id"], e["d"], e["chan"] if not e["friend"] else "(friend)", e["tname"] if not e["friend"] else "", "FRIEND" if e["friend"] else "")


@block("N056.0")
def _():
    ids = Counter(e["id"] for e in sel())
    print("opens", len(sel()), "distinct", len(ids), "opened more than once:", [k for k, v in ids.items() if v > 1])
    for e in sorted(sel(), key=lambda e: e["t"], reverse=True)[:3]:
        print("  newest", e["id"], e["t"], e["title"], e["length"])


@block("N066.0")
def _():
    w = sel(start=D(2026, 10, 24), end=D(2026, 10, 30))
    show("24-30 Oct 2026", w)
    print("parts of day", Counter(part(e["t"].hour) for e in w), "; this week 16-22 Nov 2026: none (export ends 30 Oct)")


@block("N066.1")
def _():
    print("YouTube last", max(e["d"] for e in EV if e["plat"] == "youtube"), "Instagram last", max(e["d"] for e in EV if e["plat"] == "instagram"), "first", min(e["d"] for e in EV))
    print("opens without private", len(sel()), Counter(e["plat"] for e in sel()))


LONG = lambda e: e["plat"] == "youtube" and e["length"] and e["length"] > 60  # noqa


@block("A01.0")
def _():
    show("4 weeks 3-30 Oct", sel(start=W4[0], end=W4[1]))
    show("4 weeks before 5 Sep-2 Oct", sel(start=W4B[0], end=W4B[1]))
    print("Clip Factory lengths", Counter(e["length"] for e in sel(f=lambda e: e["chan"] == "Clip Factory")))


@block("A01.1")
def _():
    print("(themes) see A01.0 blocks: 4 weeks vs 4 weeks before")


@block("A01.3")
def _():
    show("October 2026", sel(start=D(2026, 10, 1), end=D(2026, 10, 31)), keys=("chan",))


@block("A01.4")
def _():
    show("October 2026 without gaming", sel(start=D(2026, 10, 1), end=D(2026, 10, 31), f=ng))


@block("A01.5")
def _():
    show("October 2026 without gaming, known-long only", sel(start=D(2026, 10, 1), end=D(2026, 10, 31), f=lambda e: ng(e) and LONG(e)))


@block("B03.0")
def _():
    show("4 weeks, known-long only", sel(start=W4[0], end=W4[1], f=LONG))


@block("B05.0")
def _():
    last, first = {}, {}
    for e in sel(private=True):
        c = e["chan"] + (" (PRIVATE)" if e["private"] else "")
        last[c] = max(last.get(c, e["d"]), e["d"])
        first[c] = min(first.get(c, e["d"]), e["d"])
    for c in sorted(last, key=lambda c: last[c]):
        print("  ", c, first[c], "->", last[c])
    show("4 weeks before, channels", sel(start=W4B[0], end=W4B[1]), keys=("chan",))
    show("4 weeks, channels", sel(start=W4[0], end=W4[1]), keys=("chan",))


@block("B11.0")
def _():
    show("24-30 Oct", sel(start=D(2026, 10, 24), end=D(2026, 10, 30)), keys=("chan",))


@block("C08.0")
def _():
    sr = sel(f=th("sr"))
    e = max(sr, key=lambda e: e["t"])
    print("speedruns", len(sr), Counter(e["chan"] for e in sr), "last:", e["title"], e["d"])


@block("D04.0")
def _():
    show("2022", sel(start=D(2022, 1, 1), end=D(2022, 12, 31)))


@block("D04.1")
def _():
    ig = [e for e in EV if e["plat"] == "instagram"]
    print("Instagram events:", sorted((e["d"], e["kind"], e["id"]) for e in ig))
    print("2022 opens by platform", Counter(e["plat"] for e in sel(start=D(2022, 1, 1), end=D(2022, 12, 31))))


@block("E04.0")
def _():
    show("2026 to 30 Oct", sel(start=D(2026, 1, 1)), keys=("chan", "tname"))
    show("2025 1 Jan-30 Oct", sel(start=D(2025, 1, 1), end=D(2025, 10, 30)), keys=("chan",))
    show("2025 all", sel(start=D(2025, 1, 1), end=D(2025, 12, 31)), keys=("chan",))
    allk = [e for e in EV if e["d"] >= D(2026, 1, 1) and not e["private"] and not e["friend"]]
    print("2026 opens+saves:", len(allk), "Wet Paper", sum(e["chan"] == "Wet Paper" for e in allk), "(37 opens + 3 playlist)",
          "watercolor", sum(e["theme"] == "wc" for e in allk), "-> 44/260 = 16.9%; opens only 41/254 = 16.1%")


@block("F02.0")
def _():
    for e in sel(start=D(2026, 10, 29), end=D(2026, 10, 30)):
        print("  ", e["id"], e["t"], e["chan"], e["title"])


@block("F04.0")
def _():
    sr = sel(f=th("sr"))
    print("by year", Counter(e["d"].year for e in sr), "months", len(set((e["d"].year, e["d"].month) for e in sr)),
          "first", min(e["d"] for e in sr), "last", max(e["d"] for e in sr), "evening", sum(17 <= e["t"].hour < 21 for e in sr))


@block("F05.0")
def _():
    cl = sel(f=th("cl"))
    print("clips", len(cl), Counter(e["chan"] for e in cl), "days", len(set(e["d"] for e in cl)), "evening", sum(17 <= e["t"].hour < 21 for e in cl),
          "lengths", Counter(e["length"] for e in cl), "of all opens", len(sel()))


@block("F06.0")
def _():
    g = sel(f=lambda e: e["area"] == "gaming")
    print("gaming all", len(g), "before Sep 2026", len([e for e in g if e["d"] < D(2026, 9, 1)]), "Feb 2026", len([e for e in g if (e["d"].year, e["d"].month) == (2026, 2)]),
          "Sep 2026", len([e for e in g if (e["d"].year, e["d"].month) == (2026, 9)]))
    g4 = sel(start=W4[0], end=W4[1], f=lambda e: e["area"] == "gaming")
    g4b = sel(start=W4B[0], end=W4B[1], f=lambda e: e["area"] == "gaming")
    print("4 weeks", len(g4), Counter(e["tname"] for e in g4), "Shorts", sum(e["length"] == 40 for e in g4), "; before", len(g4b), Counter(e["tname"] for e in g4b))


@block("F08.0")
def _():
    br = sel(f=lambda e: e["chan"] == "Brick Realm")
    print("Brick Realm", len(br), Counter(e["d"].year for e in br), min(e["d"] for e in br), max(e["d"] for e in br), "; no subscriber data in rows")


@block("F10.0")
def _():
    show("4 weeks 3-30 Oct", sel(start=W4[0], end=W4[1]), keys=("area", "tname", "chan"))


@block("N044.1")
def _():
    co = sorted(sel(f=th("co")), key=lambda e: e["t"], reverse=True)
    print("cooking opens 6th-10th newest:", [(e["id"], str(e["d"])) for e in co[5:10]], "watch counts all 1")


if __name__ == "__main__":

    import json
    PK = json.load(open(os.path.join(HERE, "..", "blind", "group1.json")))
    MSG = {m["key"]: m["message"] for m in PK["messages"]}
    out = io.StringIO()
    for key in MSG:
        fn = BLOCKS[key]
        out.write(f"===== {key}: {MSG[key]}\n")
        buf = io.StringIO()
        with redirect_stdout(buf):
            fn()
        out.write(buf.getvalue())
    open(os.path.join(HERE, "facts.txt"), "w").write(out.getvalue())
    print(out.getvalue())
