"""Builds marks.json from the compact entries in marks_src*.py (reader1b)."""
import glob
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def M(mid, code, grade, ans, means, more, offer, brief="y", lt=0, lu=0, false=(), wb=(), scope="n", lo="n",
      priv="n", cause=None, note=""):
    wbf = [w for w in wb if w[0] == "firm"]
    wbl = [w for w in wb if w[0] == "lenient"]
    OUT.append({"message_id": mid, "code": code, "grade": grade, "false_n": len(false),
                "false_sentences": list(false), "wb_firm_n": len(wbf), "wb_lenient_n": len(wbl),
                "wb_sentences": [f"{k}: {s} -- {why}" for k, s, why in wb], "wrong_scope": scope,
                "limit_only": lo, "privacy_fault": priv, "answers": ans, "means": means, "more": more,
                "offer": offer, "brief": brief, "limits_talk": lt, "limits_unwanted": lu,
                "poor_cause": cause if grade == "poor" else None, "note": note})


if __name__ == "__main__":
    for f in sorted(glob.glob(os.path.join(HERE, "marks_src*.py"))):
        exec(open(f).read(), {"M": M})
    json.dump(OUT, open(os.path.join(HERE, "marks.json"), "w"), indent=1)
    print(len(OUT), "marks written")
