import json
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31'
d=json.load(open(S+'/blind/group1.json')); m=json.load(open(S+'/reader1b/marks.json'))
want={(x['key'],a['code']) for x in d['messages'] for a in x['answers']}
have=[(r['message_id'],r['code']) for r in m]
print('packet answers',len(want),'marks',len(have),'dups',len(have)-len(set(have)))
print('extra',set(have)-want)
miss=sorted(want-set(have)); print('missing',len(miss), sorted({k for k,_ in miss}))
print('empty answers', [(x['key'],a['code']) for x in d['messages'] for a in x['answers'] if a['empty']])
from collections import Counter; print(Counter(r['grade'] for r in m))
