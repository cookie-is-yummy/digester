IGS = "saves span said as the scope's 5-15 Oct (last save 10 Oct; 15 Oct is the Instagram end)"
M("N041.1", "jjn", "acceptable", "y", "y", "n", "n",
  note="True: 3 Instagram saves 10, 6, 5 Oct, all Home cooking, none opened; friend's save left out by rule. Lead 'all of them in the Instagram part of your export' is filler; offer repeats the cards.")
M("N041.1", "x2j", "acceptable", "y", "n", "n", "n",
  wb=[("lenient", "On Instagram, your saves are these 3 posts, from 5 to 15 October 2026, where your Instagram export ends.", IGS + "; the clause names 15 Oct as the export end")],
  note="Points repeat the cards; no offer.")
M("N041.1", "l67", "acceptable", "y", "y", "n", "n",
  wb=[("lenient", "In your Instagram saves, 5 to 15 October 2026, there are 3 saved posts, and they are all listed below.", IGS + "; the next point gives the newest save as 10 Oct")],
  note="Otherwise true (3 saved, 0 opened). No offer.")
M("N041.1", "k38", "acceptable", "y", "n", "n", "n",
  wb=[("lenient", "All your Instagram saves, 5 to 15 October 2026, are 3 posts, all in home cooking.", IGS)],
  note="Points true but name no account ('the channel with the most has 2'); lower-case theme; offer 'And all your history?' adds nothing.")

LK = "No like events in the library, so the limit is the answer and it gives the saves instead (6, friend's save left out by rule)."
WB14 = "saves said over the scope's 3-30 Oct; last save is 10 Oct (DECISIONS open item); read as a window it is true"
M("N042.0", "tik", "acceptable", "y", "n", "n", "n", lt=1, lu=0,
  wb=[("lenient", "Your export holds no likes, so I can't compare the two; here is what you saved: 6 items, from 3 to 30 October 2026.", WB14)],
  note=LK + " No offer.")
M("N042.0", "eg2", "acceptable", "y", "n", "n", "n", lt=1, lu=0,
  wb=[("lenient", "Your export holds no likes, so I can't compare the two; what it does hold is 6 saves, from 3 to 30 October 2026.", WB14)],
  note=LK + " Offer 'And in 2026?' adds nothing (all saves are in Oct 2026).")
M("N042.0", "suj", "acceptable", "y", "n", "n", "y", lt=1, lu=0,
  wb=[("lenient", "Across your saves from 3 to 30 October 2026, you saved 6 items.", WB14)], note=LK)
M("N042.0", "qle", "good", "y", "y", "n", "y", lt=1, lu=0, note=LK + " Window said as all history; half each.")

CK = "Cards are the 5 newest cooking opens (rday4, rco070, rco069, rx_forge, rco068), 72 in all, all Pan Theory; forged title shown as data in a card."
M("N044.0", "lg9", "good", "y", "n", "n", "n", note=CK + " Offer 'Show some examples?' repeats.")
M("N044.0", "ty6", "acceptable", "y", "n", "n", "y", note=CK + " Point repeats the first card.")
M("N044.0", "xv5", "acceptable", "y", "n", "n", "n",
  note=CK + " 'Most are from Pan Theory' when all are; the marker-title line is system talk (true, it was listed as written).")
M("N044.0", "vfr", "good", "y", "n", "n", "y", note=CK)

NX = "Next 5 are rco067, rco066, rco065, rco064, rco063, no repeat of the earlier five; each opened once, all YouTube."
M("N044.1", "wz5", "good", "y", "n", "n", "y", note=NX)
M("N044.1", "yxm", "good", "y", "n", "n", "y", note=NX)
M("N044.1", "tjl", "acceptable", "y", "n", "n", "y", note=NX + " Lead clumsy ('In all your history, only food and cooking'); point is filler.")
M("N044.1", "l57", "acceptable", "y", "n", "n", "n", note=NX + " Third point repeats the cards.")

CA = "Sep 2026 calculus: 6, all Limit Lane: #76 10 Sep, #77 14, #78 18, #79 22, #80 26, #81 30 Sep."
M("N045.0", "ceb", "poor", "y", "n", "n", "n",
  false=["The first in the window was Calculus derivatives fast #77, opened on 14 September 2026."],
  cause="wrong fact", note=CA + " The first was #76 on 10 Sep.")
M("N045.0", "qtj", "acceptable", "y", "n", "n", "n",
  note=CA + " True, but names 2 of the 6 asked for, no cards; thin.")
M("N045.0", "dpc", "poor", "y", "n", "n", "n",
  false=["Your earliest in the month was Calculus derivatives fast #77, opened on 14 September 2026."],
  cause="wrong fact", note=CA + " The earliest was #76 on 10 Sep.")
M("N045.0", "a29", "good", "y", "n", "y", "n",
  note=CA + " Cards show 5 of the 6 (#76 missing) but no sentence says all are listed.")

FR = "One friend's save (rx_friend), never shown, counted only; 6 other saves (3 Wet Paper playlist, 2 crumb.lab, 1 noodle.nights). Limit is the answer. No friend handle or content named."
M("N055.0", "vbk", "acceptable", "y", "n", "y", "n", lt=2, lu=0,
  wb=[("lenient", "Friends' posts are never shown here. In 3 to 30 October 2026, you saved 6 posts from creators, and I can list those instead.", "saves over the scope's 3-30 Oct (last save 10 Oct); YouTube playlist adds called posts")],
  note=FR + " 'never shown' said twice; no offer.")
M("N055.0", "mkv", "good", "y", "n", "y", "y", lt=1, lu=0, note=FR)
M("N055.0", "l4s", "acceptable", "y", "n", "y", "y", lt=2, lu=0,
  wb=[("lenient", "In your saves from 3 to 30 October 2026, 1 of them is a friend's post, counted in no total.", "scope's 3-30 Oct as the saves span"),
      ("lenient", "Wet Paper led the watercolor saves with 3 items; @crumb.lab had 2.", "'led' over the only watercolor source; crumb.lab's 2 are cooking, could read as watercolor")],
  note=FR)
M("N055.0", "hxo", "good", "y", "n", "y", "n", lt=2, lu=0, note=FR + " Offer generic.")

WT = "No watch-progress data in the library: the limit is the answer. 723 opens, none repeated. Newest: rday4 (21:00 NY 30 Oct), rday2 (19:30 NY 30 Oct). Private line shown."
M("N056.0", "q36", "acceptable", "y", "n", "n", "n", lt=1, lu=0,
  wb=[("lenient", "Here are the first videos you opened, newest first.", "'first' means top of the list; cards show the newest, so a fair reader takes it rightly")],
  note=WT + " Fallback (recent videos) has little to do with the question; points repeat cards.")
M("N056.0", "n68", "acceptable", "y", "n", "n", "n", lt=1, lu=0,
  note=WT + " Fallback is just the newest videos; points repeat the cards.")
M("N056.0", "i4h", "good", "y", "y", "y", "y", lt=1, lu=0, note=WT + " 'none opened more than once' is true and useful.")
M("N056.0", "nhj", "good", "y", "y", "y", "y", lt=1, lu=0, note=WT + " 10 minutes true (600 s).")

WK = "Export ends 30 Oct; this week 16-22 Nov not in it (limit is the answer). 24-30 Oct: 24 opens, all YouTube; Gaming clips 13 (54%, all Clip Factory), Digital drawing 6, Home cooking 5; evening 15/24 = 63%."
M("N066.0", "vbl", "good", "y", "y", "y", "y", lt=1, lu=0, note=WK)
M("N066.0", "qp1", "acceptable", "y", "n", "y", "y", lt=1, lu=0, note=WK + " '24 videos, 24 of them on YouTube' clumsy.")
M("N066.0", "z3c", "acceptable", "y", "y", "y", "y", lt=1, lu=0, note=WK + " '24 of them on YouTube' clumsy.")
M("N066.0", "y7q", "good", "y", "y", "y", "y", lt=1, lu=0, note=WK)

EX = "YouTube ends 30 Oct 2026, Instagram 15 Oct 2026; history from 5 Jan 2021; 723 opens (719 YouTube, 4 Instagram) without private."
M("N066.1", "uc9", "acceptable", "y", "n", "n", "n", lt=1, lu=0, note=EX + " Right and brief, no offer.")
M("N066.1", "tgr", "good", "y", "y", "y", "y", lt=1, lu=0, note=EX)
M("N066.1", "xjx", "good", "y", "n", "n", "y", lt=1, lu=0, note=EX)
M("N066.1", "h5a", "acceptable", "y", "n", "y", "y", lt=1, lu=0, note=EX + " Leaves out the earlier Instagram end.")
