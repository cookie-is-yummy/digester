"""Reader1b facts helper: reads the library rows only (no brain tools)."""
import sys
from collections import Counter
from datetime import datetime, date
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # rows only

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships (PRIVATE)"}

EV = []  # one per event
for r in B.rows():
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], plat=r["platform"], kind=k, t=t, d=t.date(), theme=r["theme"],
                       tname=THEME[r["theme"]], area=AREA[r["theme"]],
                       chan=r.get("channel") or r.get("handle"), length=r.get("length"), title=r["caption"],
                       friend=bool(r.get("friend")), private=r["theme"] == "da"))


def sel(kind="watch", start=None, end=None, plat=None, private=False, friend=False, f=None):
    out = []
    for e in EV:
        if kind and e["kind"] not in (kind if isinstance(kind, (list, tuple, set)) else [kind]):
            continue
        if start and e["d"] < start:
            continue
        if end and e["d"] > end:
            continue
        if plat and e["plat"] != plat:
            continue
        if not private and e["private"]:
            continue
        if not friend and e["friend"]:
            continue
        if f and not f(e):
            continue
        out.append(e)
    return out


def tally(evs, key="tname"):
    c = Counter(e[key] for e in evs)
    n = sum(c.values())
    return n, [(k, v, round(100 * v / n) if n else 0) for k, v in c.most_common()]


def show(label, evs, keys=("area", "tname", "chan")):
    print(f"--- {label}: n={len(evs)}")
    for k in keys:
        n, t = tally(evs, k)
        print(f"   by {k}: " + "; ".join(f"{a}={b} ({c}%)" for a, b, c in t))


D = date
