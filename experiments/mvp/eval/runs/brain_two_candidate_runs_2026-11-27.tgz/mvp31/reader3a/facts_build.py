"""Reader3a facts: every figure recounted from brain_library rows (no brain tools). New York dates.
Opened = watch events. Private = dating advice (Heart Notes). Friend = rx_friend (in no total). Evening = 5-9 pm."""
import sys; sys.path.insert(0,'.')
from lib import *
from collections import Counter
P=print
def eve(es): return sum(1 for e in es if 17<=e['t'].hour<21)
def top(es,k='ch',n=6): return Counter(e[k] for e in es).most_common(n)
def short(es): return [e for e in es if e['length'] and e['length']<=60]
W=sel('watch'); WP=sel('watch',private=True)
wk4=sel('watch',D(2026,10,3),D(2026,10,30)); summer=sel('watch',D(2026,6,1),D(2026,8,31)); oc=sel('watch',D(2026,10,1),D(2026,10,31)); y26=sel('watch',D(2026,1,1),D(2026,12,31))
H={}
H['N004.0']=[f'4 weeks 3-30 Oct 2026: {len(wk4)} opens (YouTube {sum(e["plat"]=="youtube" for e in wk4)}), areas {top(wk4,"area")}, themes {top(wk4,"theme")}, channels {top(wk4)}; Shorts {len(short(wk4))}',
  f'summer 2026 (1 Jun-31 Aug, 92 days): {len(summer)} opens, areas {top(summer,"area")}, themes {top(summer,"theme")}']
f=sorted(W,key=lambda e:e['t'])[0]; H['N016.0']=[f'first open: {f["cap"]} ({f["ch"]}) {f["t"]}; private rows start 2024; non-private opens {len(W)}']
H['N017.0']=[f'all history opens {len(W)} (with private {len(WP)}); channels {top(W,n=5)}; Brick Realm 163/723 = {100*163/723:.1f}%']
H['N017.1']=[f'2026: {len(y26)} opens, channels {top(y26,n=6)}; Pixel Pencil first {min(e["d"] for e in W if e["ch"]=="Pixel Pencil")}; no private rows in 2026']
fp=sel('watch',ch='Frame Perfect'); H['N018.0']=[f'Frame Perfect {len(fp)}, by year {sorted(Counter(e["d"].year for e in fp).items())}, first {min(e["d"] for e in fp)}, last {max(e["d"] for e in fp)}, all Speedruns, all YouTube']
br=sel('watch',ch='Brick Realm'); H['N018.1']=[f'Brick Realm {len(br)}, by year {sorted(Counter(e["d"].year for e in br).items())}, first {min(e["d"] for e in br)}, last {max(e["d"] for e in br)}, evening {eve(br)} ({100*eve(br)/len(br):.0f}%)']
first={}
for e in sorted(sel(['watch','save','playlist']),key=lambda e:e['t']): first.setdefault(e['ch'],e['d'])
fall=sel(['watch','save','playlist'],D(2026,9,1),D(2026,10,30))
H['N019.0']=[f'first seen by channel/account: {first}', f'fall 2026 counts by channel (opens+saves): {top(fall,n=12)}; friend account sunny.crew not counted']
wd=Counter(e['t'].strftime('%a') for e in W); we=[e for e in W if e['t'].weekday()>=5]; wkd=[e for e in W if e['t'].weekday()<5]
H['N032.0']=[f'weekday counts {dict(wd)}; weekend {len(we)}/{len(W)} = {100*len(we)/len(W):.1f}%; evening all {100*eve(W)/len(W):.0f}%, weekend {100*eve(we)/len(we):.0f}%, weekday {100*eve(wkd)/len(wkd):.0f}%']
H['N033.0']=[f'Oct 2026: YouTube Shorts {len(short(oc))} {top(short(oc))}; Instagram reels opened {sum(e["plat"]=="instagram" for e in oc)} (length unknown, scope counts them)']
sa=short(W); H['N033.1']=[f'Shorts in all history: {len(sa)}, months {Counter((e["d"].year,e["d"].month) for e in sa)}; plus 4 reels, all Oct 2026; Oct 2026 all opens {len(oc)}, Gaming clips {sum(e["theme"]=="cl" for e in oc)} ({100*66/len(oc):.0f}%)']
allev=sel(); H['N035.0']=[f'opens by platform {top(W,"plat")}; opened+saved items {len(allev)} by platform {top(allev,"plat")}; Instagram ends 15 Oct 2026']
ig=sel(plat='instagram',friend=True); H['N035.1']=[f'Instagram rows: {[(e["id"],e["kind"],str(e["d"]),e["theme"]) for e in ig]}; opens 12-15 Oct (all watercolor, wetpaper.ig), saves 5, 6, 10 Oct (+friend 9 Oct)']
sv=sel(['save','playlist'],D(2026,10,3),D(2026,10,30)); H['N038.0']=[f'likes in rows: {sum(e["kind"]=="like" for e in EV)}; saves 3-30 Oct (friend left out): {len(sv)} {[(e["id"],str(e["d"]),e["ch"],e["theme"]) for e in sv]}']
H['N048.0']=['sourdough: rx_sour1 "Sourdough starter day 3: feed 50 g flour and 50 g water, wait 12 hours" saved 5 Oct 2026; rx_sour2 crumb post saved 6 Oct (both @crumb.lab)']
H['N048.1']=['only rx_sour1 mentions flour: 50 g flour + 50 g water, wait 12 hours']
sp=sel('watch',D(2024,3,1),D(2024,5,31),private=True)
H['N052.0']=[f'spring 2024: non-private {sum(not e["private"] for e in sp)} {[(e["id"],e["t"].strftime("%a %H:%M %d %b")) for e in sp if not e["private"]]}; private {sum(e["private"] for e in sp)}']
H['N052.1']=[f'private in spring 2024: {sum(e["private"] for e in sp)}; private in all history: {sum(e["private"] for e in EV)}; friend post: 1 (9 Oct 2026); non-private non-friend items: {len(allev)}']
m24=sel('watch',D(2024,3,1),D(2024,3,31),private=True); H['N054.0']=[f'March 2024: non-private {[e["cap"] for e in m24 if not e["private"]]} (Sat 2 Mar 16:00, 600 s); private {sum(e["private"] for e in m24)}']
y4=[e for e in wk4 if e['plat']=='youtube']; H['N057.0']=[f'4 weeks YouTube {len(y4)} on {len(set(e["d"] for e in y4))} days = {len(y4)/28:.1f}/day; lengths sum {sum(e["length"] for e in y4)} s = {sum(e["length"] for e in y4)/60/28:.1f} min/day at most; Gaming clips {sum(e["theme"]=="cl" for e in y4)}, Shorts {len(short(y4))}, evening {eve(y4)}; no watch time in rows']
H['N068.0']=['saves: pasta night post (noodle.nights, 10 Oct 2026) is the one dinner save; sourdough x2; watercolor playlist x3; friend post caption "Beach day with the crew"']
igw=sel('watch',plat='instagram'); H['N112.0']=[f'Instagram opens {[(e["t"].strftime("%a %d %b %H:%M")) for e in igw]}']
ocl=[e for e in oc if e['plat']=='youtube' and e['length'] and e['length']>60]; H['A07.0']=[f'Oct 2026 long videos {len(ocl)}: {top(ocl)}']
def ar(a,b,ex=None,exth=None):
    es=[e for e in sel('watch',a,b) if e['area']!=ex and e['theme']!=exth]; return len(es), top(es,'area'), top(es,'theme')
H['B02.0']=[f'4 weeks without gaming {ar(D(2026,10,3),D(2026,10,30),"gaming")}; 4 weeks before {ar(D(2026,9,5),D(2026,10,2),"gaming")}']
wc=sel('watch',theme='wc'); H['B07.0']=[f'watercolor opens {len(wc)} {top(wc)}, first {sorted(wc,key=lambda e:e["t"])[0]["cap"]} {min(e["d"] for e in wc)}, last {max(e["d"] for e in wc)}']
H['C02.0']=[f'4 weeks without Minecraft builds {ar(D(2026,10,3),D(2026,10,30),exth="mc")}']
y25=sel('watch',D(2025,1,1),D(2025,12,31)); H['C06.0']=[f'2026 areas {top(y26,"area")}, themes {top(y26,"theme")}; 2025 areas {top(y25,"area")}; days 1 Jan-30 Oct 2026 = 303']
H['D01.0']=[f'Oct 2026 {len(oc)}: {top(oc,n=8)}']
s9=sel('watch',D(2026,9,1),D(2026,9,30)); H['D01.1']=[f'Sep 2026 {len(s9)}: {top(s9)} themes {top(s9,"theme")}']
d30=[e for e in W if e['d']==D(2026,10,30)]; H['D07.0']=[f'30 Oct 2026 (Friday): {[(e["cap"],e["ch"],e["t"].strftime("%H:%M"),e["length"]) for e in sorted(d30,key=lambda e:e["t"])]}']
H['D07.1']=['second by time and card order: Gaming clip on the 30th (Clip Factory, 40 s)']
c26=[e for e in y26 if e['area']=='cooking']; c25=[e for e in y25 if e['area']=='cooking']
H['D08.0']=[f'cooking 2026: {len(c26)} {top(c26)}, days {len(set(e["d"] for e in c26))}, evening {eve(c26)} ({100*eve(c26)/len(c26):.0f}%)']
H['D08.1']=[f'cooking 2025: {len(c25)} {top(c25)}, evening {eve(c25)} ({100*eve(c25)/len(c25):.1f}%)']
mon=Counter((e['d'].year,e['d'].month) for e in WP); H['F11.0']=[f'top months (with private rows) {mon.most_common(4)}; Oct 2026 Shorts {len(short(oc))}/142 = 46.5%, /138 YouTube = 47.8%']
g=[e for e in W if e['area']=='gaming']; gd=sel('watch',ch='Gaming Daily')
H['F14.0']=[f'Gaming Daily channel: {len(gd)} opens, 40 s each, {min(e["d"] for e in gd)} to {max(e["d"] for e in gd)}; gaming area {len(g)} {top(g,"theme")}']
da=sel('watch',theme='da',private=True); H['I02.0']=[f'dating advice (private, unlocked by the person): {len(da)} in 2024, months {sorted(Counter(e["d"].month for e in da).items())}, {min(e["d"] for e in da)} to {max(e["d"] for e in da)}, evening {eve(da)} ({100*eve(da)/len(da):.0f}%), 2023: 0']
y24=sel('watch',D(2024,1,1),D(2024,12,31)); H['I03.0']=[f'2024 non-private: {len(y24)} {top(y24)}; saves in 2024: {len(sel(["save","playlist"],D(2024,1,1),D(2024,12,31)))} (Home cooking saves are Oct 2026)']
s25=sel('watch',D(2025,1,1),D(2025,10,30)); H['K03.0']=[f'2026: {len(y26)}, themes {top(y26,"theme",8)}, channels {top(y26,n=3)}; new in 2026: Pixel Pencil 1 Aug, Clip Factory 1 Oct, Gaming Daily 1 Oct; 1 Jan-30 Oct 2025: {len(s25)} {top(s25,"theme")}, watercolor {100*45/52:.0f}% -> 2026 {100*41/254:.0f}%; nothing of 2025 stopped']
ca=sel('watch',theme='ca'); H['K04.0']=[f'calculus opens {len(ca)} by year {sorted(Counter(e["d"].year for e in ca).items())}, titles {sorted(Counter(e["cap"].split(" #")[0] for e in ca).items())}; calculus saves 0']
import json
d=json.load(open('../blind/group3.json')); m=json.load(open('marks.json'))
out=[]
for x in d['messages']:
    k=x['key']; out.append(f'### {k} [{x["set"]}] {x["message"]}')
    for line in H.get(k,['(no facts)']): out.append('  fact: '+line)
    for r in m:
        if r['message_id']==k: out.append(f'  mark {r["code"]}: {r["grade"]} false={r["false_n"]} firm={r["wb_firm_n"]} lenient={r["wb_lenient_n"]} answers={r["answers"]}')
open('facts.txt','w').write('\n'.join(out)+'\n')
print('missing facts', [x['key'] for x in d['messages'] if x['key'] not in H])
