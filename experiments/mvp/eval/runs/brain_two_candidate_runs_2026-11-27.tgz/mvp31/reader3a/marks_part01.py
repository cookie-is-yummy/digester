# [0] N004.0
M('N004.0','c8i','good','y','y','y','y', note='all figures check: 130 vs 45, 49/25/23%, Clip Factory 56, Digital drawing 27 vs 32')
M('N004.0','vv3','good','y','y','y','y', lt=1, lu=0, note='export-end line frames "last few weeks"; needed')
M('N004.0','bm9','acceptable','y','y','y','y', lt=1, lu=0, wbs=[("47% of the recent videos were Shorts.","lenient","59 of the 126 YouTube videos; the lead's base is 130 items (45%); YouTube base is natural for Shorts")], note='lenient base on the Shorts share')
M('N004.0','axj','good','y','y','n','y', lt=1, lu=0, note='"compare shares more than counts" says what the numbers mean')
# [1] N016.0
M('N016.0','wa7','acceptable','y','n','y','n', note='true (5 Jan 2021, 3:00 pm New York, 723 opens); no offer')
M('N016.0','bgr','acceptable','y','n','n','n', note='true; no offer')
M('N016.0','x0n','acceptable','y','n','n','n', note='true; "Show some examples?" is generic after one first item')
M('N016.0','qdf','acceptable','y','n','n','n', note='same text as bgr')
# [2] N017.0
M('N017.0','rgl','good','y','n','y','y', note='163 of 723 (23%), Pixel Pencil 92 all Digital drawing: true')
M('N017.0','ww5','good','y','n','y','y', note='Wet Paper 91 opens third: true')
M('N017.0','tx5','good','y','n','y','y')
M('N017.0','i1w','acceptable','y','n','y','y', note='second point repeats the lead as a share')
# [3] N017.1
M('N017.1','v34','good','y','n','y','y', note='2026: Pixel Pencil 92 of 254, Clip Factory 61, Wet Paper 37, Pan Theory 32: true; no private rows in 2026')
M('N017.1','g1f','good','y','n','y','y', note='Brick Realm 13 in 2026 true')
M('N017.1','z7c','good','y','n','y','y', note='same text as v34')
M('N017.1','hc2','good','y','y','y','y', note='Pixel Pencil first opened 1 Aug 2026: true; "new this year" is a reading')
# [4] N018.0
M('N018.0','enq','good','y','n','y','y', note='90; first 1 Mar 2021, last 1 May 2023; 41 in 2022: true')
M('N018.0','hfg','good','y','n','y','y', note='35/41/14 true')
M('N018.0','c6j','good','y','n','y','y')
M('N018.0','gb3','acceptable','y','n','y','y', lt=1, lu=1, note='window said twice (lead and scope line), export-end note not needed')
# [5] N018.1
M('N018.1','fyv','good','y','n','y','y', note='163; 91/59/0/0/0/13; first 5 Jan 2021, last 20 Oct 2026: true')
M('N018.1','pu1','good','y','n','y','y')
M('N018.1','cj4','acceptable','y','n','n','y', note='true but thin next to the others')
M('N018.1','gen','good','y','n','y','y', note='evening 67% true (5 pm to 9 pm New York); "0 in 2023" skips 2024-25 but is not false')
# [6] N019.0
M('N019.0','od6','acceptable','y','n','y','y', note='"below the floor for a new channel" is system talk; "one more" true of opens (two more new accounts by saves only)')
M('N019.0','rnl','good','y','y','y','y', note='Gaming clips 66 = Clip Factory 61 + Gaming Daily 5; 3 smaller new accounts (wetpaper.ig 4, crumb.lab 2, noodle.nights 1): true')
M('N019.0','fxr','good','y','n','y','y', note='both first opened 1 Oct 2026: true')
M('N019.0','mj7','good','y','y','y','y')
# [7] N032.0
M('N032.0','xx9','good','y','y','y','y', note='28%/72%, Sat 101, Sun 101, Thu 108, evening 69% on weekends and weekdays alike: true')
M('N032.0','ubk','good','y','y','y','y')
M('N032.0','ynb','good','y','y','y','y')
M('N032.0','qqg','acceptable','y','y','n','y', wbs=[("Not much: over all your history, weekends were 28% of what you opened, close to an even split of the week.","lenient","28% is close to the 2/7 share of the days; \'even split\' can read as 50/50")])
# [8] N033.0
M('N033.0','ix4','good','y','n','y','y', note='66 Shorts (Clip Factory 61 + Gaming Daily 5) + 4 reels: true')
M('N033.0','ib8','good','y','n','y','y')
M('N033.0','qdc','good','y','n','y','y', lt=1, lu=0, note='Instagram end note is relevant to an October count')
M('N033.0','b12','good','y','n','y','y', note='leaves out the 4 reels the scope line names, but the question is Shorts')
# [9] N033.1
M('N033.1','xa0','good','y','y','y','y', note='all 70 short items in Oct 2026: true; the limit is the answer')
M('N033.1','edx','good','y','y','y','y')
M('N033.1','zwk','good','y','y','y','y')
M('N033.1','p0y','poor','y','y','y','y', wbs=[("Gaming clips is 94% of what you opened in that month.","firm","94% is 66 of the 70 short items; of everything opened in October 2026 (142) Gaming clips is 46%")], pc='wrongly based')
