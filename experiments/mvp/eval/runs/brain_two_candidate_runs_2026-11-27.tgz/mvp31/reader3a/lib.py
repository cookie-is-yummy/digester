"""Reader's own facts helper: reads the library rows only (no brain tools)."""
import sys
from collections import Counter, defaultdict
from datetime import datetime, date
from zoneinfo import ZoneInfo
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art", "dd": "art", "ca": "math", "np": "math",
        "co": "cooking", "da": "dating"}
ROWS = B.rows()
EV = []  # one per event
for r in ROWS:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=k, t=t, d=t.date(), plat=r["platform"], theme=r["theme"],
                       area=AREA[r["theme"]], ch=r.get("channel") or r.get("handle"), length=r["length"],
                       friend=bool(r.get("friend")), private=r["theme"] == "da", cap=r["caption"],
                       pub=r["published"]))


def sel(kind=None, start=None, end=None, plat=None, private=False, friend=False, **eq):
    out = []
    for e in EV:
        if kind and (e["kind"] not in (kind if isinstance(kind, (list, tuple, set)) else [kind])):
            continue
        if start and e["d"] < start: continue
        if end and e["d"] > end: continue
        if plat and e["plat"] != plat: continue
        if not private and e["private"]: continue
        if not friend and e["friend"]: continue
        if any(e[k] != v for k, v in eq.items()): continue
        out.append(e)
    return out


def summ(evs, label=""):
    n = len(evs)
    print(f"== {label}: n={n}")
    if not n: return
    for key in ("area", "theme", "ch", "plat", "kind"):
        c = Counter(e[key] for e in evs)
        print(f"  {key}: " + ", ".join(f"{k}={v} ({100*v/n:.0f}%)" for k, v in c.most_common()))
    ds = sorted(e["d"] for e in evs)
    print(f"  dates {ds[0]} .. {ds[-1]}; distinct days {len(set(ds))}")
    L = [e["length"] for e in evs if e["length"]]
    if L: print(f"  lengths known {len(L)}, total {sum(L)}s = {sum(L)/3600:.1f}h, shorts(<=60) {sum(1 for x in L if x<=60)}")


D = date
