import json, glob, os
OUT = []
def M(mid, code, grade, ans, means, more, offer, brief='y', lt=0, lu=0, fs=(), wbs=(), ws='n', lo='n', pf='n', pc=None, note=''):
    wbs = list(wbs)
    OUT.append(dict(message_id=mid, code=code, grade=grade, false_n=len(fs), false_sentences=list(fs),
        wb_firm_n=sum(1 for w in wbs if w[1]=='firm'), wb_lenient_n=sum(1 for w in wbs if w[1]=='lenient'),
        wb_sentences=[f"{w[0]} [{w[1]}: {w[2]}]" for w in wbs], wrong_scope=ws, limit_only=lo, privacy_fault=pf,
        answers=ans, means=means, more=more, offer=offer, brief=brief, limits_talk=lt, limits_unwanted=lu,
        poor_cause=pc if grade=='poor' else None, note=note))
for f in sorted(glob.glob('marks_part*.py')):
    exec(open(f).read())
json.dump(OUT, open('marks.json','w'), indent=1)
print(len(OUT), 'marks')
