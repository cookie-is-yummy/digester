import json
from collections import Counter
d=json.load(open('../blind/group3.json')); m=json.load(open('marks.json'))
pk={(x['key'],a['code']) for x in d['messages'] for a in x['answers']}
mk=[(r['message_id'],r['code']) for r in m]
print('packet', len(pk), 'marks', len(mk), 'dups', [k for k,v in Counter(mk).items() if v>1])
print('missing', pk-set(mk), 'extra', set(mk)-pk)
by={(r['message_id'],r['code']):r for r in m}
for x in d['messages']:
    for i,a in enumerate(x['answers']):
        for b in x['answers'][i+1:]:
            if a['sent']==b['sent']:
                ra,rb=by[(x['key'],a['code'])],by[(x['key'],b['code'])]
                diff=[k for k in ra if k not in('code','note') and ra[k]!=rb[k]]
                print('same text', x['key'], a['code'], b['code'], 'diff fields', diff)
    # near-identical lead check
print('grades', Counter(r['grade'] for r in m))
print('by set', {s:Counter(by[(x['key'],a['code'])]['grade'] for x in d['messages'] if x['set']==s for a in x['answers']) for s in 'AH'})
print('false', sum(r['false_n'] for r in m), 'firm', sum(r['wb_firm_n'] for r in m), 'lenient', sum(r['wb_lenient_n'] for r in m), 'privacy', sum(r['privacy_fault']=='y' for r in m), 'limit_only', sum(r['limit_only']=='y' for r in m))
print('poor causes', Counter(r['poor_cause'] for r in m if r['grade']=='poor'))
bad=[r for r in m if r['grade'] not in ('good','acceptable','poor') or (r['grade']=='poor')!=(r['poor_cause'] is not None) or ((r['false_n'] or r['wb_firm_n'] or r['answers']=='n') and r['grade']!='poor')]
print('rule breaks', [(r['message_id'],r['code']) for r in bad])
