import sys; sys.path.insert(0,'.')
from lib import *
from collections import Counter
def eve(es): return sum(1 for e in es if 17<=e['t'].hour<21)
s=sel('watch',D(2026,9,1),D(2026,9,30)); print('Sep', len(s), Counter(e['ch'] for e in s).most_common(), Counter(e['theme'] for e in s))
d30=[e for e in sel('watch',private=True) if e['d']==D(2026,10,30)]; print('30 Oct', [(e['cap'],e['t'].strftime('%a %H:%M'),e['length']) for e in sorted(d30,key=lambda e:e['t'])])
for y in (2025,2026):
    c=sel('watch',D(y,1,1),D(y,12,31),area='cooking'); print('cook',y,len(c),Counter(e['ch'] for e in c),'days',len(set(e['d'] for e in c)),'eve',eve(c), round(100*eve(c)/len(c)))
mon=Counter((e['d'].year,e['d'].month) for e in sel('watch')); print('top months', mon.most_common(5))
monp=Counter((e['d'].year,e['d'].month) for e in sel('watch',private=True)); print('top months incl private', monp.most_common(4))
oc=sel('watch',D(2026,10,1),D(2026,10,31)); sh=[e for e in oc if e['length'] and e['length']<=60]; print('Oct shorts', len(sh), len(oc), round(100*len(sh)/len(oc),1), round(100*len(sh)/sum(1 for e in oc if e['plat']=='youtube'),1))
g=sel('watch',area='gaming'); print('gaming', len(g), Counter(e['theme'] for e in g), round(100*163/len(g)))
gd=sel('watch',ch='Gaming Daily'); print('GD', len(gd), [(e['d'],e['length']) for e in gd])
da=sel('watch',theme='da',private=True); print('dating', len(da), min(e['d'] for e in da), max(e['d'] for e in da), sorted(Counter(e['d'].month for e in da).items()), 'eve', eve(da), round(100*eve(da)/len(da)), Counter(e['d'].year for e in da))
y26=sel('watch',D(2026,1,1),D(2026,12,31)); y25s=sel('watch',D(2025,1,1),D(2025,10,30))
print('2025 Jan1-Oct30', len(y25s), Counter(e['theme'] for e in y25s), 'wc share', round(100*sum(1 for e in y25s if e['theme']=='wc')/len(y25s)))
print('2026 wc', sum(1 for e in y26 if e['theme']=='wc'), round(100*41/254))
first_theme={}
for e in sorted(sel('watch'),key=lambda e:e['t']): first_theme.setdefault(e['theme'],e['d'])
print('first theme', first_theme)
last_theme={}
for e in sorted(sel('watch'),key=lambda e:e['t']): last_theme[e['theme']]=e['d']
print('last theme', last_theme)
lastch={}
for e in sorted(sel('watch'),key=lambda e:e['t']): lastch[e['ch']]=e['d']
print('last ch', lastch)
ca=sel('watch',theme='ca'); print('calculus', len(ca), Counter(e['d'].year for e in ca), Counter(e['cap'].split(' #')[0] for e in ca))
print('calc saves', [e for e in sel(['save','playlist'],friend=True) if 'alcul' in e['cap']])
