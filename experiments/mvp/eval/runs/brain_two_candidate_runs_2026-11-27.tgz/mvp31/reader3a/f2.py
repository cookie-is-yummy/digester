import sys; sys.path.insert(0,'.')
from lib import *
from collections import Counter
w4=sel('watch',D(2026,10,3),D(2026,10,30),plat='youtube'); print('4wk yt',len(w4), 'eve17-22', sum(1 for e in w4 if 17<=e['t'].hour<22), 'secs', sum(e['length'] for e in w4 if e['length']))
print('Mar24 private', len(sel('watch',D(2024,3,1),D(2024,3,31),private=True)))
# Oct long videos (>60s, known)
oc=sel('watch',D(2026,10,1),D(2026,10,31),plat='youtube'); lg=[e for e in oc if e['length'] and e['length']>60]
print('Oct long', len(lg), Counter(e['ch'] for e in lg), Counter(e['theme'] for e in lg))
print('Oct yt', len(oc), 'unknown len', sum(1 for e in oc if not e['length']))
# 4 weeks without gaming and prior 4 weeks
def areas(a,b,excl=None,exth=None):
    es=[e for e in sel('watch',a,b) if e['area']!=excl and e['theme']!=exth]
    c=Counter(e['area'] for e in es); n=len(es); return n,{k:(v,round(100*v/n)) for k,v in c.items()}, Counter(e['theme'] for e in es)
print('4wk no gaming', areas(D(2026,10,3),D(2026,10,30),'gaming'))
print('prev4wk no gaming', areas(D(2026,9,5),D(2026,10,2),'gaming'))
print('4wk no mc', areas(D(2026,10,3),D(2026,10,30),exth='mc'))
print('prev4wk no mc', areas(D(2026,9,5),D(2026,10,2),exth='mc'))
wc=sel('watch',theme='wc'); print('wc opens', len(wc), min(e['d'] for e in wc), max(e['d'] for e in wc), Counter(e['ch'] for e in wc), sorted(wc,key=lambda e:e['t'])[0]['cap'])
print('wc all events', Counter(e['kind'] for e in sel(theme='wc')))
