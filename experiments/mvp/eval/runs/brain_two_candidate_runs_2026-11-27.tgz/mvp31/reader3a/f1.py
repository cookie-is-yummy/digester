import sys; sys.path.insert(0,'.')
from lib import *
from collections import Counter
W=sel('watch')
print('first open', sorted(W,key=lambda e:e['t'])[0]['cap'], sorted(W,key=lambda e:e['t'])[0]['t'])
fp=sel('watch',ch='Frame Perfect'); print('FP', len(fp), min(e['d'] for e in fp), max(e['d'] for e in fp), Counter(e['d'].year for e in fp))
br=sel('watch',ch='Brick Realm'); print('BR', len(br), min(e['d'] for e in br), max(e['d'] for e in br), Counter(e['d'].year for e in br))
print(' BR hours', sorted(Counter(e['t'].hour for e in br).items()))
def ev(es,a,b): return sum(1 for e in es if a<=e['t'].hour<b)
for a,b in [(17,22),(18,23),(17,24),(18,24),(16,22),(17,21)]:
    print(' evening',a,b,'BR',round(100*ev(br,a,b)/len(br)),'all',round(100*ev(W,a,b)/len(W)))
print('all hours', sorted(Counter(e['t'].hour for e in W).items()))
wd=Counter(e['t'].strftime('%a') for e in W); print('weekday', wd, 'weekend share', (wd['Sat']+wd['Sun'])/len(W))
we=[e for e in W if e['t'].weekday()>=5]; wk=[e for e in W if e['t'].weekday()<5]
for a,b in [(17,22),(18,23),(17,24)]: print(' eve we',a,b,round(100*ev(we,a,b)/len(we)),'wk',round(100*ev(wk,a,b)/len(wk)))
# fall new channels
first={}
for e in sorted(sel(['watch','save','playlist']),key=lambda e:e['t']): first.setdefault(e['ch'],e['d'])
print('first seen', first)
oc=sel(['watch'],D(2026,10,1),D(2026,10,31)); print('Oct opens', len(oc), Counter(e['ch'] for e in oc))
sh=[e for e in sel('watch') if e['length'] and e['length']<=60]; print('shorts all', len(sh), Counter((e['d'].year,e['d'].month) for e in sh), Counter(e['ch'] for e in sh))
print('saves', [(e['id'],e['d'],e['kind'],e['ch']) for e in sel(['save','playlist'],friend=True)])
print('likes', [e for e in EV if e['kind']=='like'])
sp=sel('watch',D(2024,3,1),D(2024,5,31),private=True); print('spring24', [(e['id'],e['t'].strftime('%a %H:%M %Y-%m-%d'),e['private']) for e in sp])
print('2024 private', len(sel('watch',D(2024,1,1),D(2024,12,31),private=True)))
print('private total', sum(1 for e in EV if e['private']), 'items total', len(set(e['id'] for e in EV)))
for y in (2023,2024,2025): print('spring',y, len(sel('watch',D(y,3,1),D(y,5,31))), Counter(e['ch'] for e in sel('watch',D(y,3,1),D(y,5,31))))
