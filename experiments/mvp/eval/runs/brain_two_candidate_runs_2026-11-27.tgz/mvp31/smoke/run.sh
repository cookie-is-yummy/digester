#!/bin/bash
# mvp31 smoke: the post-repair tip (merge_tree 2c69ded), default values rules, strict off; a few known-risk conversations.
S=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad
R=$S/mvp31/smoke; TREE=${TREE:-$S/mvp30/merge_tree}
AIDS=N041,N062,N056,N008
HIDS=F15,K04,C09,B11,F11,B14
. $S/keys/anthropic.env
unset MVP_BRAIN_VALUES_RULES
for cell in "$@"; do
  IFS=_ read -r set prompt <<< "$cell"
  if [ "$set" = A ]; then SETARGS="--set fresh --half a --ids $AIDS"; else SETARGS="--set plans --half heldout --ids $HIDS"; fi
  (cd $TREE/experiments && MVP_CLAUDE_CAP_USD=25 MVP_LEDGER_HOME=/home/user/digester/data/mvp \
    MVP_BRAIN_PROMPT=brain_$prompt MVP_BRAIN_STRICT=0 \
    python3 -B -m mvp.eval_brain run $SETARGS --check values --parallel 3 --max-usd 0.06 --out $R/$cell 2>&1 \
    | sed -E 's/sk-ant-[A-Za-z0-9_-]+/<key>/g' > $R/$cell.log; echo "${PIPESTATUS[0]}" > $R/$cell.exit)
done
