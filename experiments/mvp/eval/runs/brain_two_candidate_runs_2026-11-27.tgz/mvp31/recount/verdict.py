"""recount step 4: verdicts from my settlement (settle.json), plus l5b (N035.1, A_v4d_1), which was outside my set
(firm-marked, not drawn in the 20) and which I settled only after reading the tally: false (says the Instagram export
covers only 12-15 Oct while it holds saves on 5, 6 and 10 Oct; the history lacks what it holds)."""
import json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L
s = json.load(open(os.path.join(os.path.dirname(__file__), "settle.json")))
fb = {c: list(v) for c, v in s["false_by_cell"].items()}
def verdict(fb, privacy_letter, label):
    tot = lambda b, sets="AH": sum(len(fb[c]) for c in L.CELLS if c[2:5] == b and c[0] in sets)
    out = {"label": label, "false_by_cell": {c: len(v) for c, v in fb.items()},
           "false_setA": {b: tot(b, "A") for b in ("v3d", "v4d")}, "false_all": {b: tot(b) for b in ("v3d", "v4d")}}
    for reading, sets in (("setA", "A"), ("all", "AH")):
        cand = "v4d" if tot("v4d", sets) <= tot("v3d", sets) else "v3d"   # good, poor and answers provisos pass
        misses = {}
        for c in L.CELLS:
            if c[2:5] != cand: continue
            b = s["bars"][c]
            m = [x for x in b["miss_without_privacy"] if x != "false"]
            if len(fb[c]) > 1: m.append("false")
            if privacy_letter and c[0] == "A": m.append("privacy")
            misses[c] = m
        met = all(len(m) <= 1 for m in misses.values()) and all(len(fb[c]) <= 2 for c in misses)
        out[reading] = {"candidate": cand, "misses": misses, "condition_met": met}
    return out
res = []
fb2 = {c: list(v) for c, v in fb.items()}; fb2["A_v4d_1"].append("l5b")
for f, lab in ((fb, "my set only"), (fb2, "my set + l5b false")):
    for p in (True, False):
        res.append(verdict(f, p, lab + (" / privacy by letter" if p else " / privacy not a fault")))
# one-at-a-time forks on my close calls (with l5b false)
forks = {"rnp lenient": ("A_v4d_1", "rnp"), "a7v firm": ("A_v3d_1", "a7v"), "l6d firm": ("A_v3d_1", "l6d")}
for name, (c, code) in forks.items():
    f = {k: list(v) for k, v in fb2.items()}; f[c].remove(code)
    for p in (True, False):
        res.append(verdict(f, p, "with l5b, " + name + (" / privacy letter" if p else " / privacy not a fault")))
for r in res:
    print(r["label"], "| A:", r["false_setA"], "all:", r["false_all"], "| setA reading:", r["setA"]["candidate"],
          "met" if r["setA"]["condition_met"] else "NOT met", {k: v for k, v in r["setA"]["misses"].items() if v},
          "| all-runs reading:", r["all"]["candidate"], "met" if r["all"]["condition_met"] else "NOT met")
json.dump(res, open(os.path.join(os.path.dirname(__file__), "verdict.json"), "w"), indent=1)
