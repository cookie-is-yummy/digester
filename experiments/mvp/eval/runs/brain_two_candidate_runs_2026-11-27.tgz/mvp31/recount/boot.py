"""recount step 2: v4d against v3d, and run 1 against run 2 within each build, bootstrap over messages.
Per message: the mean of the indicator over the marks in each arm (runs x readers); the difference summed over
messages = the difference in count per run. 95% percentile interval, 10000 resamples, seed 3131."""
import collections
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L  # noqa: E402

SEED, B = 3131, 10000
M = L.marks()
IND = {"good": lambda m: m["grade"] == "good", "poor": lambda m: m["grade"] == "poor",
       "answers": lambda m: m["answers"] == "y", "means": lambda m: m["means"] == "y"}


def per_msg(set_key, arm1, arm2, ind, side=None):
    """arm = function(mark) -> bool selecting marks. returns list of per-message differences arm1 - arm2."""
    d = collections.defaultdict(lambda: [[], []])
    for m in M:
        if m["set"] != set_key or (side and m["side"] != side):
            continue
        v = 1.0 if IND[ind](m) else 0.0
        if arm1(m):
            d[m["message_id"]][0].append(v)
        elif arm2(m):
            d[m["message_id"]][1].append(v)
    diffs = []
    for k, (a, b) in sorted(d.items()):
        assert a and b, k
        diffs.append(sum(a) / len(a) - sum(b) / len(b))
    return diffs


def boot(diffs, seed=SEED):
    rng = random.Random(seed)
    n = len(diffs)
    sims = sorted(sum(diffs[rng.randrange(n)] for _ in range(n)) for _ in range(B))
    up = sum(1 for x in diffs if x > 0)
    dn = sum(1 for x in diffs if x < 0)
    return {"diff": round(sum(diffs), 3), "lo": round(sims[int(0.025 * B)], 3), "hi": round(sims[int(0.975 * B) - 1], 3),
            "n": n, "up": up, "down": dn}


res = {}
for sk in ("A", "H"):
    for ind in IND:
        r = boot(per_msg(sk, lambda m: m["build"] == "v4d", lambda m: m["build"] == "v3d", ind))
        res[f"{sk} v4d-v3d {ind}"] = r
        for side in ("a", "b"):
            r2 = boot(per_msg(sk, lambda m: m["build"] == "v4d", lambda m: m["build"] == "v3d", ind, side))
            res[f"{sk} v4d-v3d {ind} side{side}"] = r2
        for bld in ("v3d", "v4d"):
            r3 = boot(per_msg(sk, lambda m, b=bld: m["build"] == b and m["rep"] == "2",
                              lambda m, b=bld: m["build"] == b and m["rep"] == "1", ind))
            res[f"{sk} {bld} run2-run1 {ind}"] = r3
for k, v in res.items():
    flag = " CLEAR>0" if v["lo"] > 0 else " CLEAR<0" if v["hi"] < 0 else ""
    print(f"{k:<32} {v['diff']:>7} [{v['lo']:>7}, {v['hi']:>7}] n={v['n']} up={v['up']} down={v['down']}{flag}")
json.dump(res, open(os.path.join(os.path.dirname(__file__), "boot.json"), "w"), indent=1)
