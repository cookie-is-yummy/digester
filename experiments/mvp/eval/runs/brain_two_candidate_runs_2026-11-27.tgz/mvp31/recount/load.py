"""recount: load key, marks and run records. Read-only, no model call."""
import glob
import json
import os

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp31"
CELLS = ["A_v3d_1", "A_v3d_2", "A_v4d_1", "A_v4d_2", "H_v3d_1", "H_v3d_2", "H_v4d_1", "H_v4d_2"]
READERS = ["reader1a", "reader1b", "reader2a", "reader2b", "reader3a", "reader3b"]

KEY = json.load(open(os.path.join(S, "blind", "KEY_do_not_open.json")))
CODES = KEY["codes"]


def marks():
    """list of dicts with reader, side (a/b), group, cell, set, build, rep added"""
    out = []
    for r in READERS:
        for m in json.load(open(os.path.join(S, r, "marks.json"))):
            k = CODES[m["code"]]
            assert k["message_id"] == m["message_id"]
            cell = k["cell"]
            out.append(dict(m, reader=r, side=r[-1], group=r[-2], cell=cell, set=cell[0], build=cell[2:5],
                            rep=cell[-1]))
    return out


def records(cell):
    rs = {}
    for f in glob.glob(os.path.join(S, "runs", cell, "*.json")):
        if os.path.basename(f) == "summary.json":
            continue
        r = json.load(open(f))
        if "key" in r:
            rs[r["key"]] = r
    return rs


def summary(cell):
    return json.load(open(os.path.join(S, "runs", cell, "summary.json")))


def pct(xs, q):
    xs = sorted(xs)
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)
