"""recount: the pool of sentences any reader marked wrongly based firm, unique by (code, sentence); random 20, seed 31313."""
import json, os, random, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L

def parse(s):
    s = s.strip()
    m = re.match(r"^\[?(firm|lenient)\]?:?\s*(.*?)\s+--\s+(.*)$", s, re.S)
    if m:
        return m.group(1), m.group(2).strip(), m.group(3).strip()
    m = re.match(r"^(.*?)\s*\[(firm|lenient):\s*(.*)\]\s*$", s, re.S)
    if m:
        return m.group(2), m.group(1).strip(), m.group(3).strip()
    raise ValueError(s)

pool = {}
for m in L.marks():
    for s in m["wb_sentences"]:
        kind, sent, why = parse(s)
        if kind != "firm":
            continue
        key = (m["code"], sent.rstrip("."))
        pool.setdefault(key, {"code": m["code"], "cell": m["cell"], "message_id": m["message_id"], "sentence": sent,
                              "readers": [], "why": []})
        pool[key]["readers"].append(m["reader"]); pool[key]["why"].append(why)
items = sorted(pool.values(), key=lambda x: (x["cell"], x["message_id"], x["code"], x["sentence"]))
print("firm marks", sum(m["wb_firm_n"] for m in L.marks()), "unique sentences", len(items),
      "both readers", sum(len(set(i["readers"])) == 2 for i in items))
rng = random.Random(31313)
pick = rng.sample(range(len(items)), 20)
sample = [dict(items[i], idx=i) for i in sorted(pick)]
json.dump({"seed": 31313, "pool": items, "sample_idx": sorted(pick)}, open(os.path.join(os.path.dirname(__file__), "firm_pool.json"), "w"), indent=1)
for i, it in enumerate(items):
    star = "*" if i in pick else " "
    print(star, i, it["cell"], it["message_id"], it["code"], it["readers"], "|", it["sentence"][:200], "||", it["why"][0][:200])
