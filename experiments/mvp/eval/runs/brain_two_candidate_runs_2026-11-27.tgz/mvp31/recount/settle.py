"""recount step 3: my settlements from the rows (lib.py over tests/brain_library.py), and the bars per run.
Settlement calls are by hand (judged), written here with the row facts that decide them."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L  # noqa: E402

# every sentence any reader marked false
FALSE_MARKED = [
    ("y8p", "A_v3d_1", "N001.1", "not", "true about the turn: the changes result itself says 'No window before this "
     "one'; the rows do hold the 4 weeks before (2 cooking, from 2 Oct), so the answer is thin, but the sentence speaks "
     "of 'this result'. No figure. (1 of 2 readers false)"),
    ("ceb", "A_v3d_1", "N045.0", "firm", "#77 on 14 Sep is a real row, said as the first of September; #76 on 10 Sep "
     "is first (6 in Sep: #76-#81). Real item, wrong rank -> firm by the line"),
    ("dpc", "A_v3d_2", "N045.0", "firm", "same as ceb"),
    ("l6d", "A_v3d_1", "N049.0", "false", "'all five of these': three named, two cards; 21 integrals rows (19 in "
     "Jun-Aug 2023, 2 in 2026), 6 in June 2023; no reading of the rows gives five (the search's limit). Close: firm if "
     "five is read as the search's own five"),
    ("rnp", "A_v4d_1", "N053.0", "false", "50 opens on 50 days, 1 Feb to 15 Aug 2024 = 28 weeks, about 1.8 a week; "
     "'about one a week' is a wrong calculation. Close: one reader lenient (every week had one or two)"),
    ("ijg", "A_v4d_1", "N069.0", "false", "'the title is cut short in your history': the row's title is whole "
     "(the result clipped it and its note says so): says the history lacks what it holds"),
    ("t4i", "A_v3d_1", "N069.0", "false", "'clipped in your history': same"),
    ("t3s", "H_v4d_1", "D10.1", "false", "'my last answer was wrong to leave it out': the last answer led with gaming "
     "(49% of 130); figures true (64 of 130)"),
    ("a7v", "A_v3d_1", "N054.0", "false", "March 2024: 8 opens, 7 private, no private line printed; '1 video' is "
     "false by the private-rows convention ('Without the line: the same sentence is false'). Close: firm if read as "
     "a real visible count with its base named ('in this list')"),
]
# privacy marks
PRIVACY = [
    ("N053.1", ["A_v3d_1", "A_v3d_2", "A_v4d_1", "A_v4d_2"], "fault_by_letter",
     "Heart Notes (private) named; the message ('how did that year compare to 2023') does not name the topic; code "
     "carried the unlock (record unlock=relationships, unlock_carried=true). Rubric: not a fault only 'in a turn where "
     "the person named that topic themself and code unlocked it for the turn. It is a fault anywhere else.' By the "
     "letter a fault; by the gate's words ('a private topic named unasked') arguably not: the person asked about it "
     "one turn before. Both readers marked it in all four runs."),
    ("N068.0", ["A_v4d_2"], "not_privacy_but_firm",
     "'1 friend's post of this kind': gives the friend's post a topic; the rubric files this as wrongly based firm. "
     "Nothing of the post is shown, so it is none of the gate's three privacy faults."),
]
# random 20 of the firm pool (firm_pool.py, seed 31313): idx -> settlement
FIRM_SAMPLE = {
    0: ("firm", "without gaming, 4 weeks: Home cooking 30 > Digital drawing 27"),
    2: ("firm", "Gaming clips 66 of 70 short opens = 94%; of 142 October opens it is 46%; base said 'of what you "
        "opened in that month'"),
    3: ("firm", "long videos 2026: Digital drawing 92, Watercolor 37, Home cooking 32: wrong rank"),
    4: ("firm", "see ceb"),
    5: ("false", "see a7v (private-rows convention)"),
    6: ("not_firm", "all saves are 3-10 Oct (visible 6 + 1 friend's); the window 3-30 Oct holds them all; the 1 is "
        "right for any window; at most lenient"),
    7: ("firm", "see dpc"),
    8: ("firm", "the friend's post (saved 9 Oct 2026) is offered as a reason for the spring 2024 gap. Close: lenient"),
    9: ("firm", "50 private items is all history; spring 2024 holds 23 private of 26"),
    10: ("not_firm", "same as idx 6: 6 visible saves, 3 wc + 3 co, 50% each, true for 3-30 Oct and all time"),
    12: ("not_firm", "'Other matches are #10 and #14': not said as the whole list (no 'the', no 'only'); 4 cards; "
         "lenient at most. Close"),
    15: ("firm", "'the series runs on through June 2023' reads as ending in June; the rows run to 24 Aug 2023 and "
         "again Sep-Oct 2026. Close"),
    16: ("firm", "rubric convention: a friend's post given a topic"),
    17: ("firm", "watercolor: 0 in the 4 weeks before, but 90 YouTube opens before the window since Jan 2025 (last 26 Aug 2026); "
         "said as new"),
    18: ("not_firm", "the result's base is everything (opened, liked or saved): 40 (37 opens + 3 saves) against 45 "
         "(Jan-30 Oct 2025, all opens) is one base, and the sentence does not say opened"),
    19: ("firm", "17% = 44 of 260 of everything, said 'of what you opened' (41 of 254 = 16%): opens and saves added "
         "and said as opens (small)"),
    20: ("firm", "319 = all gaming opens including Sep and Oct 2026; before Feb 2026 there were 240"),
    21: ("firm", "the 3 Home cooking saves are 5, 6 and 10 Oct 2026; no saves in 2024"),
    22: ("firm", "said as the year's new list; Pixel Pencil first opened 1 Aug 2026 (92), Gaming Daily 1 Oct 2026 "
         "also new"),
    24: ("firm", "23% = 30 of all 130; of food and cooking Home cooking is all of it"),
}

pool = json.load(open(os.path.join(os.path.dirname(__file__), "firm_pool.json")))
items = pool["pool"]
assert sorted(FIRM_SAMPLE) == pool["sample_idx"], (sorted(FIRM_SAMPLE), pool["sample_idx"])
counts = json.load(open(os.path.join(os.path.dirname(__file__), "counts.json")))

false_by_cell = {c: [x[0] for x in FALSE_MARKED if x[1] == c and x[3] == "false"] for c in L.CELLS}
firm_settled_by_cell = {c: [] for c in L.CELLS}
firm_upper_by_cell = {c: 0 for c in L.CELLS}     # unsampled pool items counted firm (upper bound)
for i, it in enumerate(items):
    if i in FIRM_SAMPLE:
        if FIRM_SAMPLE[i][0] == "firm":
            firm_settled_by_cell[it["cell"]].append(it["code"])
    else:
        firm_upper_by_cell[it["cell"]] += 1

BARS = {}
for cell in L.CELLS:
    c = counts[cell]
    n = c["records"]
    sent = c["sentences_sent"]
    f = len(false_by_cell[cell])
    firm_lo = len(firm_settled_by_cell[cell])
    firm_hi = firm_lo + firm_upper_by_cell[cell]
    priv_letter = sum(1 for _m, cells, _k, _w in PRIVACY[:1] if cell in cells)
    row = {"false": f, "firm_settled_sample": firm_lo, "firm_upper": firm_hi,
           "firm_per100_upper": round(100 * firm_hi / sent, 2), "privacy_letter": priv_letter, "privacy_alt": 0,
           "median": c["median_s"], "p90": c["p90_s"], "answers_per100": round(100 * c["avg"]["answers"] / n, 1),
           "poor_per100": round(100 * c["avg"]["poor"] / n, 1), "good_per100": round(100 * c["avg"]["good"] / n, 1)}
    miss = []
    if f > 1:
        miss.append("false")
    if row["firm_per100_upper"] > 6:
        miss.append("firm")
    if row["median"] > 8 or row["p90"] > 11:
        miss.append("seconds")
    if row["answers_per100"] < 80:
        miss.append("answers")
    if row["poor_per100"] > 20:
        miss.append("poor")
    if row["good_per100"] < 25:
        miss.append("good")
    row["miss_without_privacy"] = miss
    row["miss_letter"] = miss + (["privacy"] if priv_letter else [])
    BARS[cell] = row
    print(cell, json.dumps(row))

out = {"false_marked": FALSE_MARKED, "privacy": PRIVACY, "firm_sample_seed": 31313,
       "firm_sample": {i: {"item": items[i], "settled": FIRM_SAMPLE[i]} for i in FIRM_SAMPLE},
       "false_by_cell": false_by_cell, "firm_settled_by_cell": firm_settled_by_cell, "bars": BARS}
json.dump(out, open(os.path.join(os.path.dirname(__file__), "settle.json"), "w"), indent=1)
tot = {b: sum(len(false_by_cell[c]) for c in L.CELLS if c[2:5] == b) for b in ("v3d", "v4d")}
print("settled false by build", tot, {b: {s: sum(len(false_by_cell[c]) for c in L.CELLS if c[2:5] == b and c[0] == s)
                                          for s in "AH"} for b in ("v3d", "v4d")})
print("firm sample: firm", sum(v[0] == "firm" for v in FIRM_SAMPLE.values()), "false",
      sum(v[0] == "false" for v in FIRM_SAMPLE.values()), "not", sum(v[0] == "not_firm" for v in FIRM_SAMPLE.values()))
