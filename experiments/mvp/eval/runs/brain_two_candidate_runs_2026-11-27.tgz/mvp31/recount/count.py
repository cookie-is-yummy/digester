"""recount step 1: per-run counts from marks and records."""
import collections
import json
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L  # noqa: E402

M = L.marks()
# every code marked by exactly two readers, one a and one b, same group
by_code = collections.defaultdict(list)
for m in M:
    by_code[m["code"]].append(m)
assert set(by_code) == set(L.CODES), (len(by_code), len(L.CODES))
for c, ms in by_code.items():
    assert sorted(x["side"] for x in ms) == ["a", "b"], c
    assert len({x["group"] for x in ms}) == 1, c

out = {}
for cell in L.CELLS:
    ms = [m for m in M if m["cell"] == cell]
    row = {}
    for side in ("a", "b"):
        s = [m for m in ms if m["side"] == side]
        g = collections.Counter(m["grade"] for m in s)
        row[side] = {"n": len(s), "good": g["good"], "acceptable": g["acceptable"], "poor": g["poor"],
                     "answers": sum(m["answers"] == "y" for m in s), "means": sum(m["means"] == "y" for m in s),
                     "wrong_scope": sum(m["wrong_scope"] == "y" for m in s),
                     "limit_only": sum(m["limit_only"] == "y" for m in s),
                     "privacy": sum(m["privacy_fault"] == "y" for m in s),
                     "false_marked": sum(m["false_n"] for m in s),
                     "wb_firm_marked": sum(m["wb_firm_n"] for m in s),
                     "wb_lenient_marked": sum(m["wb_lenient_n"] for m in s),
                     "limits_unwanted": sum(m["limits_unwanted"] for m in s),
                     "offer": sum(m["offer"] == "y" for m in s)}
    row["avg"] = {k: (row["a"][k] + row["b"][k]) / 2 for k in row["a"]}
    rs = L.records(cell)
    secs = [r["seconds"] for r in rs.values()]
    summ = L.summary(cell)
    row["records"] = len(rs)
    row["prompt_version"] = summ["settings"]["prompt_version"]
    row["set_half"] = (summ["settings"]["set"], summ["settings"]["half"])
    row["strict"] = summ["settings"]["strict"]
    row["sentences_sent"] = sum(r["sentences"]["kept_sent"] for r in rs.values())
    row["sentences_written"] = sum(r["sentences"]["written"] for r in rs.values())
    row["median_s"] = round(statistics.median(secs), 3)
    row["p90_s"] = round(L.pct(secs, 0.9), 3)
    row["max_s"] = max(secs)
    row["lead_source"] = dict(collections.Counter(r["lead_source"] for r in rs.values()))
    out[cell] = row

json.dump(out, open(os.path.join(os.path.dirname(__file__), "counts.json"), "w"), indent=1)
hdr = ["good", "acceptable", "poor", "answers", "means", "wrong_scope", "limit_only", "privacy", "false_marked",
       "wb_firm_marked", "wb_lenient_marked", "limits_unwanted"]
print("cell     prompt     n  " + " ".join(f"{h[:8]:>14}" for h in hdr))
for cell, row in out.items():
    print(f"{cell} {row['prompt_version']:<10} {row['records']:>3} " + " ".join(
        f"{row['a'][h]:>4}/{row['b'][h]:<4}={row['avg'][h]:<5}" for h in hdr))
print()
for cell, row in out.items():
    print(cell, "sent", row["sentences_sent"], "written", row["sentences_written"], "median", row["median_s"], "p90",
          row["p90_s"], "max", row["max_s"], row["lead_source"], row["set_half"], "strict", row["strict"])
