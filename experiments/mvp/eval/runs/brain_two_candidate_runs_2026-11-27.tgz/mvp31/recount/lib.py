"""recount: the library rows as flat events (New York dates), from experiments/mvp/tests/brain_library.py."""
import sys
from datetime import datetime
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as BL  # noqa: E402
from mvp.tests import r12_library as R  # noqa: E402

NY = ZoneInfo("America/New_York")
THEME_NAME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
              "dd": "Digital drawing", "ca": "Calculus", "np": "Number puzzles", "co": "Home cooking",
              "da": "Dating advice (private)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art", "dd": "art", "ca": "math", "np": "math",
        "co": "food", "da": "dating(private)"}
ROWS = BL.rows()
EV = []   # (id, kind, local datetime, row)
for r in ROWS:
    for k, at in r["events"]:
        EV.append((r["id"], k, datetime.fromisoformat(at).astimezone(NY), r))


def ev(kind=None, start=None, end=None, theme=None, platform=None, friend=None, pred=None):
    """events filtered; start/end are 'YYYY-MM-DD' inclusive local dates"""
    out = []
    for iid, k, d, r in EV:
        if kind and k != kind:
            continue
        ds = d.date().isoformat()
        if start and ds < start:
            continue
        if end and ds > end:
            continue
        if theme and r["theme"] not in (theme if isinstance(theme, (list, tuple, set)) else [theme]):
            continue
        if platform and r["platform"] != platform:
            continue
        if friend is not None and bool(r.get("friend")) != friend:
            continue
        if pred and not pred(r, d):
            continue
        out.append((iid, k, d, r))
    return out


def show(es, n=50):
    for iid, k, d, r in sorted(es, key=lambda x: x[2])[:n]:
        print(f"  {d:%Y-%m-%d %H:%M} {k:<8} {iid:<9} {r['platform']:<9} {r.get('channel') or r.get('handle'):<14} "
              f"{r['theme']} len={r['length']} {r['caption'][:60]}")
