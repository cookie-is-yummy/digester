"""recount step 5: is the blind sound?"""
import collections, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L
codes = L.CODES
seen = collections.Counter()
keysets = collections.Counter()
orders = collections.Counter()
problems = []
recs = {c: L.records(c) for c in L.CELLS}
pat = re.compile(r"(seconds|took_ms|timing|median|p90|v3d|v4d|brain_v|prompt|strict|lead_source|/tmp|scratchpad|runs/|A_v|H_v|_1\b|_2\b|flag|rid\b|toolu_|usd|cost)", re.I)
for g in (1, 2, 3):
    doc = json.load(open(os.path.join(L.S, "blind", f"group{g}.json")))
    hits = collections.Counter()
    def walk(o, path=""):
        if isinstance(o, dict):
            for k, v in o.items():
                keysets[path + "." + k] += 1
                if pat.search(k): hits["KEY " + path + "." + k] += 1
                walk(v, path + "." + k)
        elif isinstance(o, list):
            for v in o: walk(v, path + "[]")
        elif isinstance(o, str):
            for m in pat.finditer(o): hits[m.group(0).lower()] += 1
    walk(doc)
    print("group", g, "messages", len(doc["messages"]), "pattern hits", dict(hits))
    for m in doc["messages"]:
        cs = [a["code"] for a in m["answers"]]
        if len(cs) != 4 or len(set(cs)) != 4: problems.append(("not four", m["key"]))
        cells = [codes[c]["cell"] for c in cs]
        if sorted(cells) != sorted(x for x in L.CELLS if x[0] == m["set"]): problems.append(("cells", m["key"], cells))
        orders[tuple(x[2:] for x in cells)] += 1
        for a in m["answers"]:
            seen[a["code"]] += 1
            k = codes[a["code"]]
            if k["message_id"] != m["key"]: problems.append(("msg", a["code"]))
            r = recs[k["cell"]][m["key"]]
            if a["sent"] != r["answer"]["text"]: problems.append(("text differs", a["code"]))
            if r["message"] != m["message"]: problems.append(("message differs", a["code"]))
print("codes seen", len(seen), "max", max(seen.values()), "key codes", len(codes))
print("problems", problems[:10], len(problems))
print("distinct orders", len(orders), "most common", orders.most_common(3))
# key run folders vs summary prompt version and set
for c in L.CELLS:
    s = L.summary(c)["settings"]
    print(c, s["prompt_version"], s["set"], s["half"], s["strict"], KEYF := L.KEY["run_folders"][c].endswith("/" + c))
print("answer fields", sorted({k for k in keysets if k.startswith(".messages[].answers[]")}))
print("message fields", sorted({k for k in keysets if k.count(".") == 2 and k.startswith(".messages[]")}))
