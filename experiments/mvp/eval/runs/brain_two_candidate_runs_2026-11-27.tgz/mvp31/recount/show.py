"""recount: show one coded answer: message, earlier turns, answer sent, and the record's turn facts.
usage: python3 -B show.py CODE [--calls]"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import load as L  # noqa: E402

code = sys.argv[1]
k = L.CODES[code]
rec = L.records(k["cell"])[k["message_id"]]
pk = None
for g in (1, 2, 3):
    doc = json.load(open(os.path.join(L.S, "blind", f"group{g}.json")))
    for m in doc["messages"]:
        if m["key"] == k["message_id"] and m["set"] == k["set"]:
            pk = m
print("CODE", code, k["cell"], k["message_id"])
print("EARLIER:", json.dumps(pk["earlier_turns"], indent=0)[:1500])
for a in pk["answers"]:
    if a["code"] == code:
        for e in a["earlier_answers_seen"]:
            print("  PRIOR ANSWER:", e["answer_sent"][:1200])
print("MESSAGE:", pk["message"])
print("SENT:", rec["answer"]["text"] if rec.get("answer") else None)
print("lead_source", rec["lead_source"], "rounds", rec["rounds"], "events", rec["events"], "error", rec["error"],
      "tool_args", rec["tool_args"], "unlock", rec.get("unlock"), "carried", rec.get("unlock_carried"),
      "seconds", rec["seconds"])
if "--calls" in sys.argv:
    for c in rec["calls"]:
        print("CALL", json.dumps({x: c.get(x) for x in ("round", "name", "args")})[:600])
        res = c.get("result") or c.get("content") or c.get("output")
        print("   RESULT", (json.dumps(res) if not isinstance(res, str) else res)[:3000])
