export const meta = {
  name: 'brain-two-candidate-blind-marks',
  description: 'mvp31: six blind readers mark the eight runs of the two candidates, a tally settles from the rows and applies the rule written beforehand, an independent recount checks it',
  phases: [
    { title: 'Mark', detail: 'six blind readers (three message groups, two readers each)' },
    { title: 'Tally', detail: 'unblind, settle disputed sentences from the rows, apply the pre-written rule' },
    { title: 'Recount', detail: 'an independent recount of the tally' },
  ],
}
const S = '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
const M = `${S}/mvp31`
const BRIEF = `Read ${M}/brief_mark.md first and follow its rules exactly. `
const OPT = { model: 'opus', effort: 'high', agentType: 'general-purpose' }
const FIG = (args && args.figures) || ''

phase('Mark')
const READ = {
  type: 'object',
  properties: {
    marked: { type: 'number' }, grades: { type: 'string' }, hard: { type: 'string' }, not_done: { type: 'string' },
  },
  required: ['marked', 'not_done'],
}
const READER = (g, n) => BRIEF + `Your key is "reader${g}${n}". Read-only, no model call, $0. You are a blind reader. Your packet is ${M}/blind/group${g}.json: messages from two sets, each with four answers, in random order, labelled by random codes. The four answers come from two builds, each run twice; you are not told which is which. You must NOT open ${M}/blind/KEY_do_not_open.json, any folder under ${M}/runs, ${M}/smoke, ${M}/smoke2, ${M}/smoke3, ${M}/fix, ${M}/repair, ${M}/v1, ${M}/v2, ${M}/mycheck, any folder ${S}/mvp24 to ${S}/mvp30, another reader's folder, or any summary; and do not try to work out which answer came from which build. Write only under ${M}/reader${g}${n}/. Save your marks file after every 10 messages so nothing is lost if you are stopped; if it exists when you start, continue from it.
For each message, first build the facts yourself from the library rows (experiments/mvp/tests/brain_library.py in /home/user/digester; write a small script that reads the rows and does not import the brain tools): what the right answer to the question is, the counts, shares, dates, names, ranks, video lengths, what is private, which rows are friends' posts, what the export does not hold. Then mark each of the four answers against those facts, against experiments/mvp/eval/brain_reading_rubric.md (read it whole; its last two parts decide the hard cases) and the founder's rules in the brief. Use the private-row convention and the friends' posts convention. Be even-handed: the same standard for every code. Two answers to one message are often word for word alike; mark them alike.
Marks per answer, in ${M}/reader${g}${n}/marks.json as a list of {message_id, code, grade, false_n, false_sentences, wb_firm_n, wb_lenient_n, wb_sentences, wrong_scope, limit_only, privacy_fault, answers, means, more, offer, brief, limits_talk, limits_unwanted, poor_cause, note}:
- grade: good, acceptable or poor (rubric). An answer with a false sentence, or that misses the question, is poor.
- false_n: sentences with a wrong number, name, date or calculation as shown to the user (include a stated count of items shown that contradicts the cards shown, and a statement that a read failed or that the history holds nothing when the rows say otherwise). false_sentences: quote each. Follow the rubric's line between false and wrongly based.
- wrongly based: a sentence whose figures are right but said of the wrong period, base, rank, completeness or event. wb_firm_n: a careful ordinary reader would be misled. wb_lenient_n: clumsy but a fair reader would take it rightly (for example a share whose base is named beside it, a rank across an area and a theme where the area is the whole of the theme, "most" said of the largest share). wb_sentences: quote each with firm or lenient and one line why.
- wrong_scope: y if the answer is about a window, a platform or a topic the message did not ask for (and does not say so), else n.
- limit_only: y if the answer says only what the bot cannot do or could not get, though the rows hold an answer. A limit that is itself the answer is not limit-only (rubric).
- privacy_fault: y if it names a private topic's content, a friend's handle or post content, guesses a motive or a state of mind, or says something sensitive about the person; else n. Quote it in note.
- answers: y or n, does it answer the question asked. means: y or n, does it say what the numbers mean, not just list them. more: y or n, a bit more than asked that is worth having. offer: y or n, a follow-up worth taking. brief: y or n. limits_talk: how many sentences say what the bot cannot do or what is missing; limits_unwanted: how many of those the question did not call for.
- poor_cause, for poor only: wrong fact, misses the question, thin, wrongly based, wrong scope, limits not said, says too much about limits, limit only, bare fallback, other.
Check your own work: every code in the packet has a mark; counts from your facts script are printed beside each message in ${M}/reader${g}${n}/facts.txt.
Return: how many answers you marked, your grade counts overall (you do not know the builds), any message where the facts were hard to establish, and anything not done.`

const readers = await parallel([1, 2, 3].flatMap(g => ['a', 'b'].map(n => () => agent(READER(g, n), { ...OPT, label: `reader${g}${n}`, phase: 'Mark', schema: READ }))))
log(`readers done: ${readers.map(x => x ? x.marked : 'null').join(', ')}`)

phase('Tally')
const TALLY_S = {
  type: 'object',
  properties: {
    per_run: { type: 'string', description: 'the per-run table for set A and set H (eight runs)' },
    candidate_verdict: { type: 'string', description: 'which build is the gate candidate under the rule, each proviso with its numbers' },
    gate_readiness: { type: 'string', description: 'bar by bar for each of the candidate\'s four runs; whether the condition to run half B is met' },
    other_candidate: { type: 'string', description: 'the same bar table for the other build' },
    agreement: { type: 'string' }, false_sentences: { type: 'string', description: 'every settled false sentence: run, message id, the sentence, what the rows say' },
    wrongly_based: { type: 'string' }, poor_causes: { type: 'string' }, run_to_run: { type: 'string', description: 'how much the two runs of one build differ on each measure' },
    uncertain: { type: 'string' },
  },
  required: ['per_run', 'candidate_verdict', 'gate_readiness', 'false_sentences', 'uncertain'],
}
const tally = await agent(BRIEF + `Your key is "tally". Read-only on the repo, no model call, $0. Write under ${M}/tally/.
Six blind readers marked eight runs: three message groups, two readers (a, b) each. Marks: ${M}/reader<g><n>/marks.json. The key ${M}/blind/KEY_do_not_open.json: you may open it. The runs: ${M}/runs/<A|H>_<v3d|v4d>_<1|2>/ (one json per message, summary.json apart); A = set A (65 messages), H = set H (53 messages); v3d and v4d are the two builds (the prompt differs, nothing else). Mechanical figures per run, by script (${M}/runs/gate31.py; seconds are record.seconds): ${FIG}
Readers returned (short): ${JSON.stringify(readers).slice(0, 4000)}
Last round's tally scripts are in ${S}/mvp29/tally/ (load.py, tally29.py, settle29.py, facts29.py); adapt them. Read the last three sections of experiments/mvp/design/brain_v1/DECISIONS.md: the rule ("The rule for the next run, written before it") and the bars were written before these runs. Apply them as written; where the wording leaves a choice, say so, show both readings and say whether the verdict depends on it.
1. Check the marks are complete (every message and code, both readers). List anything missing; do not fill gaps with guesses.
2. Reader agreement per group and overall: exact agreement and Cohen's kappa on grade, answers, means, wrong_scope; agreement on false_n > 0 and wb_firm_n > 0.
3. Settle from the library rows (experiments/mvp/tests/brain_library.py; your own script, not the brain tools): every sentence either reader marked false, every wb_firm sentence where the readers disagree or which only one marked, every privacy_fault, every wrong_scope and every limit_only. For each: the sentence, the run, what the rows say, your settlement (false, wrongly based firm, wrongly based lenient, true), and which reader was right. Use the rubric's line between false and wrongly based, the private-row convention and the friends' posts convention. The same sentence in two runs gets the same settlement.
4. Unblind. Per run (A_v3d_1, A_v3d_2, A_v4d_1, A_v4d_2, H_v3d_1, H_v3d_2, H_v4d_1, H_v4d_2), by each reader and averaged: good / acceptable / poor; answers; means; more; offer; brief; settled false sentences; settled wrongly based firm, also per 100 sentences sent (and lenient beside it); privacy faults; wrong scope; limit only; limits_talk and limits_unwanted; poor causes. Beside them the mechanical figures (seconds median and p90, code leads, errors).
5. Run-to-run noise: for each build and set, how much its two runs differ on good, poor, answers, settled false, wrongly based, median and p90 seconds. This is the noise any difference between the builds must be read against.
6. The candidate, by the rule as written: the candidate for the gate is the build with more good answers on set A (both runs, both readers), provided that against the other it has no more settled false sentences, no more poor answers beyond 4 of 65, and "answers the question" does not fall on either set with an interval clear of 0. If v4d fails a proviso, v3d is the candidate. Give the good counts on set A (both runs, both readers), each proviso with its numbers, and for "answers the question" the paired per-message difference v4d minus v3d on each set (both runs and both readers pooled, bootstrap over messages, 95% interval). Name the candidate.
7. Gate readiness, by the rule as written: the gate on half B is run once on the candidate only if both of its set A runs and both of its set H runs meet every bar but one at most, and none has more than 2 settled false sentences. The bars: settled false sentences at most 1 per run; settled wrongly based firm at most 6 per 100 sentences sent; privacy faults 0; median at most 8 s and p90 at most 11 s; answers the question at least 80%; poor at most 20%; good at least 25% (rates are the average of the two readers). A table of pass and fail per bar for each of the candidate's four runs, with the numbers, then one plain sentence: the condition is met, or it is not and which run and which bars fail. Give the same table for the other build.
8. What makes the poor answers poor, grouped, with counts per run and two examples each (message id and the sentence). Say which causes look like the model's judgement, which like a tool result, which like the checker dropping a true sentence (the records hold "dropped" with each refused sentence and its reason).
Write ${M}/tally/report.txt and tables.json. Return the tables and verdicts with numbers and intervals, and what is uncertain.`, { ...OPT, label: 'tally', phase: 'Tally', schema: TALLY_S })

phase('Recount')
const RECOUNT = {
  type: 'object',
  properties: {
    agrees: { type: 'boolean' },
    differences: { type: 'array', items: { type: 'object', properties: { what: { type: 'string' }, tally_says: { type: 'string' }, recount_says: { type: 'string' }, matters: { type: 'string' } }, required: ['what', 'tally_says', 'recount_says'] } },
    verdicts: { type: 'string', description: 'your own reading of the two verdicts (the candidate, the condition to run half B) from your own numbers' },
    blind_sound: { type: 'string' },
    summary: { type: 'string' },
  },
  required: ['agrees', 'differences', 'verdicts', 'summary'],
}
const recount = await agent(BRIEF + `Your key is "recount". Read-only, no model call, $0. Write under ${M}/recount/. You are an independent checker of a tally; you did not make it, and your job is to find where it is wrong. Do NOT read anything under ${M}/tally/ before you have your own numbers (you may read report.txt and tables.json only at step 4).
1. From the readers' marks (${M}/reader<g><n>/marks.json), the key (${M}/blind/KEY_do_not_open.json, you may open it) and the run records (${M}/runs/<A|H>_<v3d|v4d>_<1|2>/), write your own script and compute per run: grade counts by reader and averaged, answers, means, wrong scope, limit only, privacy faults, sentences sent, seconds median and p90 from the records (record.seconds, interpolated percentile).
2. Your own comparison of the two builds with bootstrap intervals over messages: v4d against v3d on good, poor, answers, means, on each set (both runs and both readers pooled). And the run-to-run difference within each build.
3. Settle yourself, from the library rows with your own script (experiments/mvp/tests/brain_library.py), every sentence any reader marked false in any run, and a random 20 of the sentences marked wrongly based firm (fixed seed, written down). Use the rubric's last two parts.
4. Now read ${M}/tally/report.txt and tables.json and compare with yours. List every difference in a number, a settlement or a verdict, and say whether it changes a verdict. Read the rule and the bars in the last three sections of experiments/mvp/design/brain_v1/DECISIONS.md and say whether the tally applied each as written (the candidate rule with its three provisos; the condition "both set A runs and both set H runs meet every bar but one at most, and none has more than 2 settled false sentences").
5. Check the blind was sound: the packets hold nothing that reveals a run or a build (open ${M}/blind/group1.json and look for timings, flags, prompt names, paths); each message has four codes; the key matches the run folders; the per-message random order is not the same order throughout.
Return whether your numbers agree, each difference, your own reading of the verdicts, and a short summary.`, { ...OPT, label: 'independent recount', phase: 'Recount', schema: RECOUNT })

return { readers, tally, recount }
