# reader3a progress
- started; read brief, rubric, library
- marks saved for messages 0-9 (40 answers)
- marks saved for messages 10-19 (80 answers)
- marks saved for messages 20-37 (all 152); next: facts.txt, self-check
- fixed o0m; facts.txt written; self-check passes
- DONE: 152 answers marked (good 74, acceptable 61, poor 17); files marks.json, facts.txt under reader3a/
