"""mvp28 checks (lib27 copy; base = the tip 8b9440e in checks/base/, the four runs4 runs added). mvp27 prep (copied from mvp26/values/lib26.py; base = the merged tip 650062c, runs A and B added). mvp26 values: one harness for the four live runs (look1, look2, run1, run2) and the attack sets, through the repo
checker of the values worktree in any mode, the tip's checker (d7ba2ef) and the checker of 4064f3e (both loaded from
base/, beside the repo's insight.py, which only gained the `skip` guards since 4064f3e). Made-up library only; no
model call."""
import glob
import re
import importlib.util
import json
import os
import sys
from datetime import date

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = os.environ.get("VALUES_TREE") or os.path.join(S, "mvp28", "merge_tree")
PIN = os.path.join(TREE, "experiments")
REPO = os.path.join(PIN, "mvp")
sys.path.insert(0, PIN)
import mvp.brain  # noqa: E402,F401
from mvp.brain import verify as V  # noqa: E402
assert V.__file__.startswith(PIN), V.__file__


def _load(path, name, pkg="mvp.brain"):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    m.__package__ = pkg
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


VT = _load(os.path.join(HERE, "base", "verify_tip.py"), "mvp.brain.verify_tip")   # 8b9440e

RUNS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run"),
        "run1": os.path.join(S, "mvp24/runa/run1"), "run2": os.path.join(S, "mvp25/runa2/run1"),
        "runA": os.path.join(S, "mvp26/runs3/runA"), "runB": os.path.join(S, "mvp26/runs3/runB"),
        "base1": os.path.join(S, "mvp27/runs4/base1"), "base2": os.path.join(S, "mvp27/runs4/base2"),
        "arm1": os.path.join(S, "mvp27/runs4/arm1"), "arm2": os.path.join(S, "mvp27/runs4/arm2")}
SEVEN = ("run2", "runA", "runB", "base1", "base2", "arm1", "arm2")
TRUTH = {"look1": os.path.join(S, "mvp22/raw/sentences.json"), "look2": os.path.join(S, "mvp22/raw/sentences.json"),
         "run1": os.path.join(S, "mvp24/recounta/sentences.json"),
         "run2": os.path.join(S, "mvp25/recount2/sentences.json"),
         "runA": os.path.join(S, "mvp26/recount3a/sentences.json"),
         "runB": os.path.join(S, "mvp26/recount3b/sentences.json")}
TMAP = {"true": "T", "wrongly_based": "F", "false": "F"}
_LAB = {}


def labels(run):
    if run not in TRUTH:
        return {}
    if run not in _LAB:
        out = {}
        for r in json.load(open(TRUTH[run])):
            if r.get("form_index") is None:
                continue
            if run.startswith("look") and r.get("look") != run:
                continue
            out[(r["key"], r["form_index"], r["where"], r["index"])] = r
        _LAB[run] = out
    return _LAB[run]


_H = None


def harness():
    global _H
    if _H is None:
        base = os.path.join(HERE, "_lib")
        os.makedirs(base, exist_ok=True)
        from mvp import eval_brain as E
        _H = E.Harness.scratch(base=base)
    return _H


_IN = {}


def inputs(run):
    """[(rec, tools turn, results by rid)] of one live run, from its saved records."""
    if run not in _IN:
        h = harness()
        out = []
        for p in sorted(glob.glob(os.path.join(RUNS[run], "*.json"))):
            if p.endswith("summary.json"):
                continue
            rec = json.load(open(p))
            if "message" not in rec:
                continue
            kw = {}
            if rec.get("unlock_carried") and rec.get("unlock"):
                kw["carried_unlock"] = rec["unlock"]
            t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True),
                       **kw)
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                       and not c["result"].get("is_error")}
            out.append((rec, t, results))
        _IN[run] = out
    return _IN[run]


def check(mod, form, results, t, mode):
    return mod.check_answer(form, results, mod.Turn.of(t), mode=mode)


def truth_of(run, key, fi, where, index):
    lab = labels(run).get((key, fi, where, index))
    if lab is None:
        return None, None
    return TMAP.get(lab["truth"], lab["truth"]), lab


def rows(run, mod, mode, keep=False):
    out = []
    for rec, t, results in inputs(run):
        for fi, form in enumerate(rec.get("forms") or []):
            v = check(mod, form, results, t, mode)
            for o in v.outcomes:
                tr, lab = truth_of(run, rec["key"], fi, o.where, o.index)
                r = {"run": run, "key": rec["key"], "fi": fi, "where": o.where, "index": o.index, "truth": tr,
                     "kept": o.kept, "reasons": list(o.reasons), "details": list(o.details), "text": o.text,
                     "flags": list(getattr(o, "flags", []) or []), "repair": v.repair, "lead_ok": v.lead_ok}
                if keep:
                    r["verdict"] = v
                out.append(r)
    return out


def answer_paths(run, mod, mode):
    """Per record: whether the model's lead is kept on the first pass, whether a reword would be asked for, and what
    would go out (model / model_after_repair / code), using the saved repair form when the run has one."""
    out = []
    for rec, t, results in inputs(run):
        forms = rec.get("forms") or []
        if not forms:
            out.append({"key": rec["key"], "forms": 0, "lead_first": False, "repair": False, "source": "no_form"})
            continue
        v1 = check(mod, forms[0], results, t, mode)
        v2 = check(mod, forms[1], results, t, mode) if len(forms) > 1 else None
        if not v1.repair:
            src = "model"
        elif v2 is not None and v2.lead_ok:
            src = "model_after_repair"
        elif v1.lead_ok:
            src = "model"
        else:
            src = "code"
        out.append({"key": rec["key"], "forms": len(forms), "lead_first": v1.lead_ok, "repair": v1.repair,
                    "source": src, "had_repair_form": v2 is not None})
    return out


# ------------------------------------------------------------------ the attack sets
DATA = os.path.join(S, "mvp24", "pin", "data")
CHECK2 = os.path.join(S, "mvp25", "check")
sys.path.insert(0, DATA)
_P = None


def planted_data():
    global _P
    if _P is None:
        from mvp.brain import planted as P
        _P = P.load()
    return _P


def _pturn(mod, case):
    t = case.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    return mod.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today, names=list(t.get("names") or []),
                    sensitive_names=list(t.get("sensitive_names") or []))


def _ptarget(v, case):
    tgt = case.get("target") or "point:0"
    kind, _, n = tgt.partition(":")
    if kind == "lead":
        os_ = [o for o in v.outcomes if o.where == "lead"]
        if n:
            o = next((o for o in os_ if o.index == int(n)), None)
            return bool(o and o.kept), list(o.reasons) if o else ["missing"]
        return bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
    if kind == "point":
        o = next((o for o in v.outcomes if o.where == "point" and o.index == int(n or 0)), None)
        return bool(o and o.kept), list(o.reasons) if o else ["missing"]
    if kind == "outside":
        e = v.outside[int(n or 0)] if len(v.outside) > int(n or 0) else None
        return bool(e and e["kept"]), list(e["reasons"]) if e else ["missing"]
    if kind == "item":
        e = v.items[int(n or 0)] if len(v.items) > int(n or 0) else None
        return bool(e and e["kept"] and not e["reasons"]), list(e["reasons"]) if e else ["missing"]
    raise ValueError(tgt)


def planted_forms():
    data = planted_data()
    for c in data["cases"]:
        for k, f in enumerate(c.get("forms") or [c["form"]]):
            yield c, k, f, data["ledgers"][c["ledger"]]


def _conv():
    from mvp.eval import brain_attack_cases as ATK
    return {"attack_" + x for x in getattr(ATK, "PRIVATE_ROW_CONVENTION", ())}


def run_planted(mod, mode):
    data = planted_data()
    rows = []
    for c in data["cases"]:
        best = None
        for f in (c.get("forms") or [c["form"]]):
            v = mod.check_answer(f, mod.Ledger(data["ledgers"][c["ledger"]]), _pturn(mod, c), mode=mode)
            kept, reasons = _ptarget(v, c)
            r = (kept, reasons, v.private_line, f)
            if best is None or (r[0] and not best[0]):
                best = r
        f0 = best[3]
        tgt = c.get("target") or "point:0"
        text = f0.get("lead") if tgt.startswith("lead") else (
            (f0.get("points") or [None])[int(tgt.partition(":")[2] or 0)] if tgt.startswith("point") and
            len(f0.get("points") or []) > int(tgt.partition(":")[2] or 0) else None)
        src = c.get("source") or "new"
        base = re.sub(r"_[LP]$", "", c["id"]) if src == "attack" else c["id"]
        line_ok = bool(best[2]) and (c["expect"] == "private_line" or c["id"] in _conv() or base in _conv())
        rows.append({"set": "planted:" + src, "id": c["id"],
                     "truth": "T" if c["expect"] == "kept" else "F", "expect": c["expect"], "class": c.get("class"),
                     "kind": c.get("kind"), "out": best[0] and not line_ok,
                     "kept": best[0], "reasons": best[1], "private_line": best[2], "text": text, "target": tgt,
                     "case": c})
    return rows


_SK = None


def skeptic_inputs():
    global _SK
    if _SK is None:
        import skeptic_cases as K
        import skeptic_scen as SC
        from mvp.brain import tools as TL
        h = harness()
        built, out = {}, []
        for c in K.CASES + K.TRUE:
            cid, sk, where, truth, cls, sent = c[:6]
            if sk not in built:
                msg, calls, last = SC.SCEN[sk]
                lw = None
                if last:
                    t0 = h.turn("what have i been into lately")
                    TL.call(t0, "breakdown", {"by": "area", "window": SC.win(preset="lately"), "scope": SC.sc(),
                                              "compare": "none"})
                    lw = t0.windows.get("r1")
                t = h.turn(msg, last_window=lw) if lw is not None else h.turn(msg)
                for tool, args in calls:
                    TL.call(t, tool, args)
                built[sk] = t
            t = built[sk]
            out.append((c, sent, K.CARRIER[sk], where, t))
        _SK = out
    return _SK


def _pl(mod, mode, results, vt, text, carrier):
    """A sentence as a point under its carrier lead, and alone as a lead: (kept as point, kept as lead, reasons)."""
    vp = mod.check_answer({"lead": carrier, "points": [text]}, results, vt, mode=mode)
    op = next((o for o in vp.outcomes if o.where == "point" and o.index == 0), None)
    vl = mod.check_answer({"lead": text, "points": []}, results, vt, mode=mode)
    ol = [o for o in vl.outcomes if o.where == "lead"]
    return (bool(op and op.kept), bool(ol) and all(o.kept for o in ol),
            sorted(set(op.reasons if op else ["missing"]) | {r for o in ol for r in o.reasons}))


def run_skeptic(mod, mode):
    rows = []
    for c, sent, carrier, where, t in skeptic_inputs():
        vt = mod.Turn.of(t)
        form = {"lead": sent} if where == "L" else {"lead": carrier, "points": [sent]}
        v = mod.check_answer(form, t.results, vt, mode=mode)
        if where == "L":
            os_ = [o for o in v.outcomes if o.where == "lead"]
            kept, reasons = bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
        else:
            o = next((o for o in v.outcomes if (o.where, o.index) == ("point", 0)), None)
            kept, reasons = bool(o and o.kept), (list(o.reasons) if o else ["missing"])
        rows.append({"set": "skeptic", "id": c[0], "truth": c[3], "class": c[4], "kept": kept, "out": kept,
                     "reasons": reasons, "text": sent, "why": c[6], "results": t.results, "message": t.message})
    return rows


def look_lookup():
    return {(run, rec["key"]): (rec, t, res) for run in ("look1", "look2") for rec, t, res in inputs(run)}


def run_rc(mod, mode):
    import rc_cases_v2 as C2
    inp = look_lookup()
    rows = []
    for cid, look, key, where, truth, cls, text, recount, _rec in C2.CASES:
        rec, t, results = inp[(look, key)]
        form = {"lead": text} if where == "L" else {"lead": rec["forms"][0].get("lead") or "", "points": [text]}
        v = mod.check_answer(form, results, mod.Turn.of(t), mode=mode)
        if where == "L":
            os_ = [o for o in v.outcomes if o.where == "lead"]
            kept, reasons = bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons})
        else:
            o = next((o for o in v.outcomes if (o.where, o.index) == ("point", 0)), None)
            kept, reasons = bool(o and o.kept), (list(o.reasons) if o else ["missing"])
        rows.append({"set": "rc2", "id": cid, "truth": truth, "class": cls, "kept": kept, "out": kept,
                     "reasons": reasons, "text": text, "why": recount, "results": results, "message": rec["message"]})
    return rows


_A2 = None


def a2():
    global _A2
    if _A2 is None:
        _A2 = json.load(open(os.path.join(REPO, "eval/brain_cells_attack2.json")))
    return _A2


def a2_turn(mod, t):
    return mod.Turn(message=t["message"], unlock=t["unlock"], screen=t["screen"],
                    today=date.fromisoformat(t["today"]) if t["today"] else None, names=list(t["names"]),
                    sensitive_names=list(t["sensitive_names"]))


def run_a2(mod, mode):
    d = a2()
    rows = []
    for c in d["cases"]:
        led, car = d["ledgers"][c["record"]], d["carriers"][c["record"]]
        P_, L_, rs = _pl(mod, mode, led, a2_turn(mod, d["turns"][c["record"]]), c["text"], car)
        out = c["truth"] == "F" and (P_ or L_)
        rows.append({"set": "attack2", "id": c["id"], "truth": c["truth"], "family": c["family"], "P": P_, "L": L_,
                     "kept": P_ and L_, "out": out, "reasons": rs, "text": c["text"], "results": led,
                     "message": d["turns"][c["record"]]["message"]})
    return rows


_C2 = None


def check2_inputs():
    global _C2
    if _C2 is None:
        sys.path.insert(0, os.path.join(CHECK2, "scripts"))
        import importlib
        C = importlib.import_module("cases")
        saved = {r["tid"]: r for r in json.load(open(os.path.join(CHECK2, "results.json")))}
        h = harness()
        turns = {}
        for tid, r in saved.items():
            t = h.turn(r["message"], carried_unlock=r.get("carried_unlock"))
            results = {c["rid"]: c["result"] for c in r["calls"] if c.get("rid") and not c["result"].get("is_error")}
            turns[tid] = (t, results)
        _C2 = (C, turns)
    return _C2


def run_check2(mod, mode):
    C, turns = check2_inputs()
    rows = []
    for cid, tid, truth, fam, s, note in C.CASES:
        t, results = turns[tid]
        P_, L_, rs = _pl(mod, mode, results, mod.Turn.of(t), s, C.CARRIER[tid])
        rows.append({"set": "attacker2", "id": cid, "truth": truth, "family": fam, "P": P_, "L": L_,
                     "kept": P_ and L_, "out": truth == "F" and (P_ or L_), "reasons": rs, "text": s, "note": note,
                     "results": results, "message": t.message})
    return rows


def run_extra(mod, mode):
    ex = json.load(open(os.path.join(REPO, "eval/brain_cells_extra.json")))
    rows = []
    for e in ex["cases"]:
        t = dict(e["turn"])
        t["today"] = date.fromisoformat(t["today"]) if t.get("today") else None
        v = mod.check_answer(e["form"], ex["ledgers"][e["ledger"]], mod.Turn(**t), mode=mode)
        os_ = [o for o in v.outcomes if o.where == "lead"] if e["where"] == "L" else \
            [o for o in v.outcomes if (o.where, o.index) == ("point", 0)]
        kept = bool(os_) and all(o.kept for o in os_)
        rows.append({"set": "extra", "id": e["id"], "truth": e["truth"], "kept": kept,
                     "out": e["truth"] == "F" and kept, "reasons": sorted({r for o in os_ for r in o.reasons})})
    return rows
