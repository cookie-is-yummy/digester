# limitonly progress (mvp28 prep)

- step 0: worktree mvp28/limitonly_tree, branch brain-limitonly-local from brain-r28-local (9ff2fba). Evidence mvp28/limitonly/.
- step 1 (diagnosis, records only, no change): tools/timeup.py -> timeup_all.txt, tools/noresult.py -> noresult_all.txt.
  time_up turns: base1 0, base2 0, arm1 1 (N007.0), arm2 1 (N007.0), runA 0, runB 1 (N007.0), v3b 1 (N007.0),
  v3c first 0, v3c final 1 (N067.0), v4c 2 (N112.0, N113.0).
  Every earlier time_up turn (4, all N007.0) had 1 or 2 successful read results in hand; the model (arm2, v3b) answered
  with content from them; arm1/runB timed out after and the code lead gave content from r1.
  The three limit-only turns had NO successful read result in hand: N067.0 and N113.0 one call that errored (export
  ends / no likes), then the next request ran past 7 s so its read was refused by TIME_UP; N112.0 the first request
  took 7.00 s and its one read call was refused by TIME_UP (rounds 0). In all 595 turns of the ten runs, the only turns
  with no read result are these three. Cause: the loop (it sends "answer with the results you already have" when there
  are none). Wording: no v3c time_up turn had a result in hand, so the dropped "with the tools" is not shown to matter.
- step 2 (loop): tests/test_brain_r28_limitonly.py written first: 5 of 7 fail on the unchanged loop
  (limitonly/test_before_fix.txt). loop.py: one predicate (a call whose result is not an error); past the soft/deep
  deadline with none in hand and before the hard stop, the round runs (event first_result_late); out of rounds with
  none in hand, the turn ends with the code lead (event no_result; fallback's plain line). Rounds, CALLS_MAX, hard stop
  unchanged; a result in hand still gets the one TIME_UP. 7/7 pass; test_brain_slice unchanged and passing.
  NOT built: refusing a model give_answer only because no read result is in the turn. Values check cannot (no wrong
  value in "I couldn't pull your history"); the loop could, but it is not general: a message about only what the export
  lacks has a true answer whose only source is an errored call ("Your export holds no likes."), and the override lands
  on fallback's PLAIN "in time" line with answer.build dropping code's limit lines under plain. With the loop change
  the false sentence has no path from code's own refusal. ambiguous/no_match come back as results (rid, no is_error).
- step 3 (prompts): v3c two rule lines reworded, no example touched: the limit "(it opens the lead) or ... (after the
  answer)" in place of "never as the opener of an answer the tools can give"; items "A number of items you show ... is
  said only when items holds every row: "these 3[r1.items.count] lessons"; never over a longer list." v4c regenerated
  by limits/tools/make_v4c.py (4 hunks equal). Tokens prefix v3c 13235 -> 13234, v4c 13381 -> 13380. Prompt tests pass
  (every example still passes values mode on the fixtures). Diffs limitonly/v3c_change.diff, v4c_change.diff (same).
- step 4: live runs runs/v3c ($0.075612), runs/v4c ($0.07382), exit 0; counters m28_new.txt, limonly_new.txt,
  limits_v3c_new.txt, limits_v4c_new.txt; hand reads targets_new.txt; summary.txt. Spend $0.149432.
- step 5: brain suite 624 passed in four shards (tools/shard_brain.sh). Changed files: loop.py, brain_v3c.md, brain_v4c.md,
  test_brain_r28_prompts.py, test_brain_r28_limitonly.py (new). verify.py, answer.py, fallback.py, brain_v3*.md locked
  files, bot untouched (bot does not import brain/).
- step 6 (advisor): classified unwanted limits by class; after-the-answer rose under v3c r1, so the limit line went back
  to the smaller form ("never as the opener unless they ask about it"; tokens 13234 / 13380), v4c regenerated, and
  the pair was rerun (runs/v3c_r2 $0.074559, runs/v4c_r2 $0.078106; first pair renamed runs/*_r1). Total live spend
  $0.302097. planted full/cells/values and eval_brain planted full/cells byte-same as merge; verify/answer/fallback
  unchanged. Suite 624 passed in four shards. summary.txt rewritten.
