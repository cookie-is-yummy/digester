# merge2 progress (mvp28, key merge2)
- step 0: start; worktree S/mvp28/merge_tree on brain-r28-local (tip 9ff2fba)
- step 1: merged rules 6641064, limitonly 183824d (auto), args f7be8d4 (eval_brain.py conflict at the record update: kept both sides, strict + tool_args + values_rules_settings)
- step 2: suite 1 running (merge2/suite_out); DESIGN 30.8 draft in merge2/design_30_8.md; seam plan: tool_args counts first_result_late/no_result + test
- step 3: suite 1 on f7be8d4: 6337 passed, 2 skipped, 0 failed (1448, 1484, 1484+2s, 1921) = 6302 + 12 + 7 + 16
- step 4: seam commit 80951b4 (tool_args counts first_result_late, no_result; arg_error_then_late; test in test_brain_r28_limitonly)
- step 5 differentials on 80951b4 (tip = cd0f7ba, which differs from 8b9440e only in DECISIONS.md; base copies equal search-loop's files):
  prove.py (rules harness, VALUES_TREE=merge_tree, rules env unset): 553 forms, 1546 sentences, 0 differ vs tip values; live 1119, 3 differ (runB, tip same)
  diff_attack (harness copy merge2/a, alib TREE from VALUES_TREE): checker 4598 verdicts 0 differ, answers 2130 form-modes 0 differ
  replay (args/h) vs args/replay_tip.json: 1188 calls, seven runs 612 calls 0 differ; only diffs the 3 strictoff speed calls (order left out)
  planted: brain.planted full/cells/values and eval_brain planted full/cells/values byte-same as rules/planted tip outputs (eb cells, values exit 1 as tip)
  dry selftest 164/164 (first try with MVP_TOTAL_CAP_USD=0 gave over_cap on 51 steps: my env, rerun with cap 1); console log = merge/selftest_tip.txt but build id (2), fake sign-in ids (2), summary line + transcript path; demo 10 passed
- step 6 smokes (fresh half a limit 4 values, --max-usd 0.02, exit 0 all): v3c s1 $0.010094 med 9.22 p90 12.31; v3c s0 $0.0072 8.77/9.47; v4c s1 $0.011114 10.36/13.32; v4c s0 $0.007229 7.79/10.74. All: 4/4 model lead, every sentence kept, strict flag right (True/False in summary and records), values_rules = last round's 4, r28 [], tool_args: 6 calls, 1 after_export_end, 0 arg, 0 form; no audit_error. Total $0.035637
- step 7: DESIGN 30.8 + corrections, README (6338, brain row); suite 2 on the final tree: 6338 passed, 2 skipped, 0 failed (1450,1484,1486+2s,1918)
- step 8: docs commit c84e499. final.diff (search-loop...brain-r28-local) privscan2: 1 caption hit ("Nothing changed", my own DESIGN 30.8 words), 56 name hits (47 single-word): all generic words, product/publication names (Google, YouTube, Claude, Anthropic, WIRED in "not wired", "the independent check"), or made-up library titles (Crumb, crispy, Bread). Nothing to fix. Hits file at S/mvp28/privscan2_hits.json (scratch). suite_out, caches removed. Not pushed.
- step 9 (after advisor): seam test index fixed (request 2), DESIGN 30.4/30.5 correction lines; commit a36e24b; limitonly file 8 passed; final.diff regenerated (4142 lines), privscan same hits (1 caption 'Nothing changed', 56 generic names). /tmp/pytest-of-root and my args_replay temp removed. Smoke ledger = records ($0.035637, rows match requests). DONE, not pushed.
