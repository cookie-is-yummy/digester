# repair progress (mvp28, key repair)
- step 0: started; worktree merge_tree on brain-r28-local at abc2486
- step 0 slip (to report): three recursive greps during orientation walked the merge tree without excluding
  eval/brain_fresh_b.py (grep -rn "...instruction..." --include=*.py . from experiments/mvp with the eval/ path only
  filtered from the output; two `grep -rn "def _sdk_error"` from the tree root). Only lines matching those patterns
  could print; nothing from the locked file printed (the hits were in brain/, lib/ai.py). From here: grep named dirs only.
- step 1: harness copy S/mvp28/repair/a (+ a/h from attack/h, base/ tip copies), repointed to merge_tree; look1/look2
  removed from RUNS and TRUTH in a/h/lib28.py, look_lookup and run_rc raise. Baselines in repair/before/: attr28
  19/11/1 (first form 18/10/1, as the merger); attack1 false out 25 / true kept 15 (the checker's file says 27/16: on a
  fresh harness the saved5 turn holds 5 once, so F34/F35 are caught; same on attack_tree), attack1b 0/12, attack2
  30/42, attack3 22/39, probes28 16 found, probes28b 0, --cite 16+... ; ref_abc.json = per-sentence verdicts (1546
  sentences, run1 + seven runs) of abc2486.
- step 2: verify.py values-only rules added: row_quote, rows_before, screen_uncited, outcome_cited, page_cited,
  shown_said, rows_kept. Per-sentence replay vs abc2486: 0 of 1546 differ. attack1 false out 22/48, true kept 21/24;
  attack1b 1/12; attack2 15/42; attack3 8/39; probes28 0 found (was 16); probes28b 0; --cite 16 (cards_found 0).
- step 3: provider retry by error type inside the stream + estimate row + no retry without 3 s left; tests/test_brain_r28_repair.py 13 passed; committed 878cbad
- step 4: reruns on 878cbad: diff_attack (no look/rc2) checker 4598/0, answers 2130/0; brain.planted full/cells/values
  and eval_brain planted full/cells byte-same as merge (= tip); dry selftest 164/164, transcript = merge's but build id
  (2) and fake sign-in link (1); attr28 19/11/1 (first 18/10/1) unchanged; per sentence 0/1546 differ; after/ holds
  attack1 22/48 out, 21/24 kept; attack1b 1/12; attack2 15/42; attack3 8/39; ablate_repair.txt attributions.
- step 5: DESIGN 30.7 + two corrections (30.2 row_text note, 30.5 held-out runs in 11,850); README 6299. Suite running.
- step 6: advisor fixes (shown_said unmarked only, rows_kept per-sentence fixed point, converted template path); reruns all same (0/1546, attacks 22/21, 1/12, 15, 8; diff 4598/0, 2130/0; planted same); committed 9ff2fba; final suite started (the first suite run was invalid: files edited mid-run)
- step 7: cleanup of _lib, try files, pycache under repair/; main checkout clean; waiting on the final suite (repair/suite_out)
- step 8: final suite on 9ff2fba: 6302 passed, 2 skipped, 0 failed (1449, 1452, 1482+2s, 1919) = README; suite_out removed. DONE (not pushed)
