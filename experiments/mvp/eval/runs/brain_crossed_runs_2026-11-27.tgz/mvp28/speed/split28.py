"""mvp28 speed, step 1b: the cause split of the gap between runs A/B and the four new runs (no model call).

Model per request: seconds = a + b*out + c*cache_write (+ d*uncached is ~3 tokens everywhere, left out).
Per turn: sum over its requests. The gap in mean seconds per turn between the two groups is split by swapping one
factor at a time (A/B as the base): output tokens per request, requests per turn, cache-write tokens, and the rest
(the session: intercept and seconds per token). Timeouts are counted apart: a timed-out turn sits at about 15 s and
its last request is not in the record.
"""
import json
import statistics as st

import numpy as np

import records28 as R

data = {n: R.recs(p) for n, p in R.RUNS.items()}
AB, NEW = ["runA", "runB"], ["base1", "base2", "arm1", "arm2"]


def reqs(names, form=None):
    return [r for n in names for d in data[n] for r in d["requests"]
            if form is None or R.is_form(r) == form]


def mfit(rr, cols):
    X = np.array([[1.0] + [c(r) for c in cols] for r in rr])
    y = np.array([r["seconds"] for r in rr])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    pred = X @ beta
    r2 = 1 - ((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum()
    return beta, r2


OUT = lambda r: r["usage"]["output_tokens"]
CW = lambda r: r["usage"]["cache_creation_input_tokens"]
CR = lambda r: r["usage"]["cache_read_input_tokens"]

print("fits: seconds = a + b*out + c*cache_write  (b, c in ms per token)")
for name, names in [("A+B", AB), ("new4", NEW)] + [(n, [n]) for n in data]:
    rr = reqs(names)
    (a, b, c), r2 = mfit(rr, [OUT, CW])
    (a1, b1), r21 = mfit(rr, [OUT])
    print(f"  {name:6s} n={len(rr):3d}  a={a:.2f}s b={b * 1000:.2f} c={c * 1000:.3f} r2={r2:.3f} | out only: "
          f"a={a1:.2f} b={b1 * 1000:.2f} r2={r21:.3f}")
for lab, form in [("form requests", True), ("read requests", False)]:
    for name, names in [("A+B", AB), ("new4", NEW)]:
        rr = reqs(names, form)
        (a, b, c), r2 = mfit(rr, [OUT, CW])
        print(f"  {lab} {name}: n={len(rr)} a={a:.2f} b={b * 1000:.2f} c={c * 1000:.3f} r2={r2:.3f} "
              f"mean out {st.mean(map(OUT, rr)):.0f} mean cw {st.mean(map(CW, rr)):.0f} mean s {st.mean(r['seconds'] for r in rr):.2f}")

# the split, on turns that did not time out (their records are whole)
def group(names):
    ds = [d for n in names for d in data[n] if d.get("error") != "ClaudeTimeout"]
    rr = [r for d in ds for r in d["requests"]]
    return {"turns": len(ds), "req_per_turn": len(rr) / len(ds), "out": st.mean(map(OUT, rr)),
            "cw": st.mean(map(CW, rr)), "turn_s": st.mean(d["seconds"] for d in ds),
            "req_s_per_turn": sum(r["seconds"] for r in rr) / len(ds)}


g0, g1 = group(AB), group(NEW)
(a0, b0, c0), _ = mfit(reqs(AB), [OUT, CW])
(a1, b1, c1), _ = mfit(reqs(NEW), [OUT, CW])


def turn_s(n, out, cw, a, b, c):
    return n * (a + b * out + c * cw)


base = turn_s(g0["req_per_turn"], g0["out"], g0["cw"], a0, b0, c0)
full = turn_s(g1["req_per_turn"], g1["out"], g1["cw"], a1, b1, c1)
d_out = turn_s(g0["req_per_turn"], g1["out"], g0["cw"], a0, b0, c0) - base
d_n = turn_s(g1["req_per_turn"], g0["out"], g0["cw"], a0, b0, c0) - base
d_cw = turn_s(g0["req_per_turn"], g0["out"], g1["cw"], a0, b0, c0) - base
d_sess = turn_s(g1["req_per_turn"], g1["out"], g1["cw"], a1, b1, c1) - \
    turn_s(g1["req_per_turn"], g1["out"], g1["cw"], a0, b0, c0)
print("\ngroups (turns without a timeout):")
for lab, g in (("A+B", g0), ("new4", g1)):
    print(f"  {lab}: " + ", ".join(f"{k} {v:.3f}" if isinstance(v, float) else f"{k} {v}" for k, v in g.items()))
print(f"\nmodelled request seconds per turn: A+B {base:.2f}, new4 {full:.2f}, gap {full - base:.2f} "
      f"(measured request-seconds gap {g1['req_s_per_turn'] - g0['req_s_per_turn']:.2f}; turn-seconds gap "
      f"{g1['turn_s'] - g0['turn_s']:.2f})")
print(f"  more output tokens per request: {d_out:+.2f} s")
print(f"  more requests per turn:         {d_n:+.2f} s")
print(f"  more cache-write tokens:        {d_cw:+.2f} s")
print(f"  session (a, b, c of the fit):   {d_sess:+.2f} s")
print(f"  interaction remainder:          {full - base - d_out - d_n - d_cw - d_sess:+.2f} s")

# timeouts: effect on median and p90 per run
print("\ntimeouts: median / p90 with and without the timed-out turns")
for n in data:
    secs = [d["seconds"] for d in data[n]]
    no = [d["seconds"] for d in data[n] if d.get("error") != "ClaudeTimeout"]
    print(f"  {n}: {R.q(secs, .5):.2f}/{R.q(secs, .9):.2f} -> {R.q(no, .5):.2f}/{R.q(no, .9):.2f} "
          f"({len(secs) - len(no)} timeouts)")

# first request of a turn: cache misses on the prefix
print("\nfirst request of a turn: cache read 0 (prefix written again)")
for n in data:
    m = [(d["key"], d["requests"][0]["seconds"]) for d in data[n]
         if d["requests"] and d["requests"][0]["usage"]["cache_read_input_tokens"] == 0]
    f1 = [d["requests"][0]["seconds"] for d in data[n] if d["requests"]]
    print(f"  {n}: {m} ; first-request mean s {st.mean(f1):.2f}")
