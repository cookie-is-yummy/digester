"""mvp28 speed: the arms on the fixed 20-message sample (live records under speed/arms/<arm>_r<k>/).

Per run: turn seconds median / p90 / mean / over 11 s / timeouts; per request: message_start (streamed arms), the
residual seconds - 3.9 ms x output tokens (a per-request start-and-overhead figure comparable across arms), output
tokens per request, requests per turn, tool errors, rewords, lead sources, cost. Paired by message: each arm's mean turn
seconds against A0 over the same 20 messages, with the noise of the two same-arm runs beside it.
"""
import glob
import json
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ARMS = {"A0": "baseline (no warm, not streamed)", "A1": "warm + streamed (answer-neutral)",
        "A2": "A1 + strict off on all tools (needs the blind run)", "A3": "A1 + thinking disabled (needs the blind run)"}
SLOPE = 0.0039


def q(xs, p):
    xs = sorted(xs)
    k = (len(xs) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


SUB = sys.argv[1] if len(sys.argv) > 1 else "arms"
BASE = sys.argv[2] if len(sys.argv) > 2 else "A0"


def load(run):
    out = {}
    for f in glob.glob(os.path.join(HERE, SUB, run, "N*.json")):
        d = json.load(open(f))
        assert d.get("half") == "a"
        out[d["key"]] = d
    return out


def tool_errors(d):
    return sum(1 for c in d.get("calls") or [] if (c.get("result") or {}).get("is_error"))


def main():
    runs = sorted(os.path.basename(p) for p in glob.glob(os.path.join(HERE, SUB, "*_r*")) if os.path.isdir(p))
    data = {r: load(r) for r in runs}
    keys = sorted(set.intersection(*(set(v) for v in data.values())))
    print(f"messages in every run: {len(keys)}")
    rows = {}
    for r in runs:
        ds = [data[r][k] for k in keys]
        secs = [d["seconds"] for d in ds]
        reqs = [x for d in ds for x in d["requests"]]
        ms = [x["timing"]["message_start"] for x in reqs if x.get("timing")]
        resid = [x["seconds"] - SLOPE * x["usage"]["output_tokens"] for x in reqs]
        src = {}
        for d in ds:
            src[d["lead_source"]] = src.get(d["lead_source"], 0) + 1
        rows[r] = dict(
            median=q(secs, .5), p90=q(secs, .9), mean=st.mean(secs), over11=sum(s > 11 for s in secs),
            timeouts=sum(1 for d in ds if d.get("error") == "ClaudeTimeout"),
            req_turn=len(reqs) / len(ds), out_req=st.mean(x["usage"]["output_tokens"] for x in reqs),
            out_turn=sum(x["usage"]["output_tokens"] for x in reqs) / len(ds),
            ms_med=st.median(ms) if ms else None, ms_mean=st.mean(ms) if ms else None,
            resid=st.mean(resid), tool_err=sum(tool_errors(d) for d in ds),
            rewords=sum(1 for d in ds if d.get("repair_message")), src=src,
            sent=sum(d["sentences"]["kept_sent"] for d in ds), written=sum(d["sentences"]["written"] for d in ds),
            cost=sum(d["cost_usd"] for d in ds), cache_miss=sum(1 for x in reqs if
                                                                x["usage"]["cache_read_input_tokens"] == 0),
            first3=st.mean(data[r][k]["requests"][0]["seconds"] - SLOPE * data[r][k]["requests"][0]["usage"][
                "output_tokens"] for k in ("N004.0", "N005.0", "N007.0") if data[r][k]["requests"]))
    hdr = ("run", "median", "p90", "mean", ">11", "tmo", "req/turn", "out/req", "out/turn", "start med", "resid/req",
           "first-req resid N004/5/7", "tool err", "rewords", "sent/written", "cost $", "leads")
    print("  ".join(hdr))
    for r in runs:
        x = rows[r]
        print("  ".join(str(v) for v in (
            r, f"{x['median']:.2f}", f"{x['p90']:.2f}", f"{x['mean']:.2f}", x["over11"], x["timeouts"],
            f"{x['req_turn']:.2f}", f"{x['out_req']:.0f}", f"{x['out_turn']:.0f}",
            "-" if x["ms_med"] is None else f"{x['ms_med']:.2f}", f"{x['resid']:.2f}", f"{x['first3']:.2f}",
            x["tool_err"], x["rewords"], f"{x['sent']}/{x['written']}", f"{x['cost']:.4f}", x["src"])))
    # arm means of the two runs, and paired differences against A0 (mean over messages of the arm's two-run mean
    # minus A0's two-run mean), with the same-arm noise (run 1 minus run 2, paired)
    print("\npaired by message (mean turn seconds; noise = |mean(r1 - r2)| of the same arm, and the sd of per-message"
          " r1-r2 / sqrt(n))")
    arms = sorted({r.split("_")[0] for r in runs})

    def m(arm, k):
        v = [data[r][k]["seconds"] for r in runs if r.startswith(arm + "_")]
        return st.mean(v)
    base = {k: m(BASE, k) for k in keys}
    for a in arms:
        rs = [r for r in runs if r.startswith(a + "_")]
        diff = [m(a, k) - base[k] for k in keys]
        noise = None
        if len(rs) >= 2:
            dd = [data[rs[0]][k]["seconds"] - data[rs[1]][k]["seconds"] for k in keys]
            noise = (st.mean(dd), st.stdev(dd) / len(dd) ** .5)
        pool = [data[r][k]["seconds"] for r in rs for k in keys]
        print(f"  {a} {ARMS.get(a, '')}: pooled median {q(pool, .5):.2f} p90 {q(pool, .9):.2f} | vs {BASE} mean "
              f"{st.mean(diff):+.2f} s (se {st.stdev(diff) / len(diff) ** .5:.2f}) | same-arm r1-r2 "
              + ("n/a" if noise is None else f"{noise[0]:+.2f} (se {noise[1]:.2f})"))
    json.dump(rows, open(os.path.join(HERE, SUB + "28.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
