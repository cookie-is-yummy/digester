"""mvp28 speed, step 1: per-request figures of the six saved runs (no model call, no key).

Reads S/mvp26/runs3/{runA,runB} and S/mvp27/runs4/{base1,base2,arm1,arm2} records (half A only; every record is
checked to be half 'a'). Prints per-run tables and writes speed/records28.json.

Thinking text is not in the records (the API returns thinking blocks with empty text and a signature). The split of
output between thinking and the tool call is ESTIMATED: tool-call tokens = len(json of tool input) / k, with k fitted
on requests that carry no thinking block (output tokens there are the tool call alone); thinking = output - that.
"""
import glob
import json
import os
import statistics as st
import sys

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
RUNS = {"runA": f"{S}/mvp26/runs3/runA", "runB": f"{S}/mvp26/runs3/runB",
        "base1": f"{S}/mvp27/runs4/base1", "base2": f"{S}/mvp27/runs4/base2",
        "arm1": f"{S}/mvp27/runs4/arm1", "arm2": f"{S}/mvp27/runs4/arm2"}


def recs(path):
    out = []
    for f in sorted(glob.glob(os.path.join(path, "N*.json"))):
        d = json.load(open(f))
        assert d.get("half") == "a", f
        out.append(d)
    return out


def q(xs, p):
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * p
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return xs[lo] + (xs[hi] - xs[lo]) * (k - lo)


def tool_chars(r):
    n = 0
    for b in r["blocks"]:
        if b.get("type") == "tool_use":
            inp = b.get("input")
            n += len(inp if isinstance(inp, str) else json.dumps(inp, ensure_ascii=False))
    return n


def has_thinking(r):
    return any(b.get("type") == "thinking" for b in r["blocks"])


def sig_len(r):
    return sum(len(b.get("signature") or "") for b in r["blocks"] if b.get("type") == "thinking")


def is_form(r):
    return any(b.get("type") == "tool_use" and b.get("name") == "give_answer" for b in r["blocks"])


def fit(xs, ys):
    mx, my = st.mean(xs), st.mean(ys)
    sxx = sum((x - mx) ** 2 for x in xs)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx
    a = my - b * mx
    res = [y - a - b * x for x, y in zip(xs, ys)]
    r2 = 1 - sum(e * e for e in res) / sum((y - my) ** 2 for y in ys)
    return a, b, r2


def main():
    data = {n: recs(p) for n, p in RUNS.items()}
    # k: characters of tool input per output token, from requests with no thinking block
    pairs = [(tool_chars(r), r["usage"]["output_tokens"]) for rs in data.values() for d in rs for r in d["requests"]
             if not has_thinking(r) and r["usage"]["output_tokens"] > 0]
    k = sum(c for c, _ in pairs) / sum(o for _, o in pairs)
    print(f"no-thinking requests: {len(pairs)}; chars per output token k = {k:.2f}")
    a, b, r2 = fit([c for c, _ in pairs], [o for _, o in pairs])
    print(f"  fit out = {a:.1f} + chars/{1 / b:.2f} (r2 {r2:.3f})")
    out = {"k": k, "runs": {}}
    hdr = ("run", "msgs", "req", "req/turn", "rounds/turn", "rewords", "tmo", "sec med", "p90",
           "req s mean", "out/req", "think/req", "tool/req", "unc", "cread", "cwrite", "miss1",
           "fit a(s)", "ms/tok", "r2")
    rows = []
    for n, rs in data.items():
        reqs = [r for d in rs for r in d["requests"]]
        secs = [d["seconds"] for d in rs]
        outs = [r["usage"]["output_tokens"] for r in reqs]
        rsec = [r["seconds"] for r in reqs]
        tools = [tool_chars(r) / k for r in reqs]
        thinks = [max(0.0, o - t) for o, t in zip(outs, tools)]
        fa, fb, fr2 = fit(outs, rsec)
        miss1 = sum(1 for d in rs if d["requests"] and d["requests"][0]["usage"]["cache_read_input_tokens"] == 0)
        tmo = sum(1 for d in rs if d.get("error") == "ClaudeTimeout")
        rew = sum(1 for d in rs if d.get("repair_message"))
        form_reqs = [r for r in reqs if is_form(r)]
        read_reqs = [r for r in reqs if not is_form(r)]
        info = {
            "msgs": len(rs), "requests": len(reqs), "req_per_turn": len(reqs) / len(rs),
            "rounds_per_turn": st.mean(d["rounds"] for d in rs), "rewords": rew, "timeouts": tmo,
            "sec_median": q(secs, .5), "sec_p90": q(secs, .9),
            "sec_median_no_tmo": q([d["seconds"] for d in rs if d.get("error") != "ClaudeTimeout"], .5),
            "sec_p90_no_tmo": q([d["seconds"] for d in rs if d.get("error") != "ClaudeTimeout"], .9),
            "req_sec_mean": st.mean(rsec), "req_sec_sum_per_turn": sum(rsec) / len(rs),
            "out_per_req": st.mean(outs), "think_per_req": st.mean(thinks), "tool_per_req": st.mean(tools),
            "out_per_turn": sum(outs) / len(rs),
            "uncached": st.mean(r["usage"]["input_tokens"] for r in reqs),
            "cache_read": st.mean(r["usage"]["cache_read_input_tokens"] for r in reqs),
            "cache_write": st.mean(r["usage"]["cache_creation_input_tokens"] for r in reqs),
            "first_req_cache_miss": miss1, "fit_a": fa, "fit_ms_per_tok": fb * 1000, "fit_r2": fr2,
            "form_reqs": len(form_reqs), "form_out": st.mean(r["usage"]["output_tokens"] for r in form_reqs),
            "form_think": st.mean(max(0, r["usage"]["output_tokens"] - tool_chars(r) / k) for r in form_reqs),
            "form_tool": st.mean(tool_chars(r) / k for r in form_reqs),
            "form_sec": st.mean(r["seconds"] for r in form_reqs),
            "form_thinking_share": sum(1 for r in form_reqs if has_thinking(r)) / len(form_reqs),
            "read_reqs": len(read_reqs), "read_out": st.mean(r["usage"]["output_tokens"] for r in read_reqs),
            "read_sec": st.mean(r["seconds"] for r in read_reqs),
            "read_think": st.mean(max(0, r["usage"]["output_tokens"] - tool_chars(r) / k) for r in read_reqs),
            "overhead_per_turn": st.mean(d["seconds"] - sum(r["seconds"] for r in d["requests"]) for d in rs
                                         if d.get("error") != "ClaudeTimeout"),
            "rate_tok_per_s_form": sum(r["usage"]["output_tokens"] for r in form_reqs) / sum(r["seconds"] for r in form_reqs),
        }
        out["runs"][n] = info
        rows.append((n, len(rs), len(reqs), f"{info['req_per_turn']:.2f}", f"{info['rounds_per_turn']:.2f}", rew, tmo,
                     f"{info['sec_median']:.2f}", f"{info['sec_p90']:.2f}", f"{info['req_sec_mean']:.2f}",
                     f"{info['out_per_req']:.0f}", f"{info['think_per_req']:.0f}", f"{info['tool_per_req']:.0f}",
                     f"{info['uncached']:.1f}", f"{info['cache_read']:.0f}", f"{info['cache_write']:.0f}", miss1,
                     f"{fa:.2f}", f"{fb * 1000:.2f}", f"{fr2:.2f}"))
    w = [max(len(str(r[i])) for r in rows + [hdr]) for i in range(len(hdr))]
    for r in [hdr] + rows:
        print("  ".join(str(x).rjust(w[i]) for i, x in enumerate(r)))
    print()
    print("form request (give_answer) vs read requests")
    for n, i in out["runs"].items():
        print(f"  {n}: form n={i['form_reqs']} out {i['form_out']:.0f} (think~{i['form_think']:.0f}, "
              f"form~{i['form_tool']:.0f}) sec {i['form_sec']:.2f} thinking block in {i['form_thinking_share']:.0%}"
              f" tok/s {i['rate_tok_per_s_form']:.0f} | read n={i['read_reqs']} out {i['read_out']:.0f} "
              f"(think~{i['read_think']:.0f}) sec {i['read_sec']:.2f} | code overhead/turn {i['overhead_per_turn']:.2f}s"
              f" | sec med/p90 without timeouts {i['sec_median_no_tmo']:.2f}/{i['sec_p90_no_tmo']:.2f}")
    # pooled fit A/B vs new four
    def pool(names):
        rr = [r for nm in names for d in data[nm] for r in d["requests"]]
        return fit([r["usage"]["output_tokens"] for r in rr], [r["seconds"] for r in rr]), rr
    (aA, bA, r2A), rrA = pool(["runA", "runB"])
    (aN, bN, r2N), rrN = pool(["base1", "base2", "arm1", "arm2"])
    print(f"\npooled fit A+B: sec = {aA:.2f} + {bA * 1000:.2f} ms/tok (r2 {r2A:.2f}); "
          f"new four: sec = {aN:.2f} + {bN * 1000:.2f} ms/tok (r2 {r2N:.2f})")
    out["pooled"] = {"AB": [aA, bA, r2A], "new": [aN, bN, r2N]}
    json.dump(out, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "records28.json"), "w"), indent=1)
    return data, out


if __name__ == "__main__":
    main()
