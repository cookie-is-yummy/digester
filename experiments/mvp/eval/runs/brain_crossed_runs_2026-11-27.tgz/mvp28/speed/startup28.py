"""mvp28 speed: is there a start-up cost inside the first turns of a run? Residual of request 1 (seconds minus the run's
fit on output tokens) for the first three conversations launched (N001, N002, N004 with --parallel 3) against every
other first request. Also the give_answer-only fit of output tokens on form characters (no-thinking forms)."""
import json, statistics as st, sys
import numpy as np
import records28 as R

data = {n: R.recs(p) for n, p in R.RUNS.items()}
for n, rs in data.items():
    rr = [r for d in rs for r in d["requests"]]
    b, a = np.polyfit([r["usage"]["output_tokens"] for r in rr], [r["seconds"] for r in rr], 1)
    res = lambda r: r["seconds"] - (a + b * r["usage"]["output_tokens"])
    first = {d["key"]: res(d["requests"][0]) for d in rs if d["requests"]}
    early = [first[k] for k in ("N001.0", "N002.0", "N004.0") if k in first]
    rest = [v for k, v in first.items() if k not in ("N001.0", "N002.0", "N004.0")]
    later_early = [res(r) for d in rs if d["key"] in ("N001.0", "N002.0", "N004.0") for r in d["requests"][1:]]
    print(f"{n}: first-request residual N001/N002/N004.0 {['%.2f' % x for x in early]} mean {st.mean(early):+.2f} | "
          f"other first requests n={len(rest)} mean {st.mean(rest):+.2f} sd {st.stdev(rest):.2f} | later requests of "
          f"those 3 turns mean {st.mean(later_early):+.2f}")
# give_answer-only fit on forms without thinking
pairs = [(R.tool_chars(r), r["usage"]["output_tokens"]) for rs in data.values() for d in rs for r in d["requests"]
         if R.is_form(r) and not R.has_thinking(r) and sum(1 for b in r["blocks"] if b.get("type") == "tool_use") == 1]
b, a = np.polyfit([c for c, _ in pairs], [o for _, o in pairs], 1)
print(f"\nno-thinking single give_answer forms n={len(pairs)}: out = {a:.0f} + {b:.3f}*chars")
for n, rs in data.items():
    fr = [r for d in rs for r in d["requests"] if R.is_form(r) and R.has_thinking(r)]
    th = [r["usage"]["output_tokens"] - (a + b * R.tool_chars(r)) for r in fr]
    fo = [a + b * R.tool_chars(r) for r in fr]
    secs = [r["seconds"] for r in fr]
    print(f"  {n}: forms with thinking n={len(fr)} out {st.mean(r['usage']['output_tokens'] for r in fr):.0f} = "
          f"form ~{st.mean(fo):.0f} + thinking ~{st.mean(th):.0f} (median {st.median(th):.0f}); sec {st.mean(secs):.2f}")
