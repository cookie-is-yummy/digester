"""mvp28 speed: the stall question on every streamed request (probe, arms A1-A3, w1, prompt pair). The gap rule written
before the probe (any gap > 5 s = stall) fired, and was wrong: thinking streams as silence. Replacement: the output rate
after message_start, (end - message_start) / output tokens, for every request with a gap over 5 s, beside the rate of
all requests. A stalled request would sit far above the normal rate. Also the wall clock of the committed build:
every timed-out turn of the runs made on it (w1 and the prompt pair) with its seconds and failed_request."""
import glob, json, statistics as st
gap, allr, tmo = [], [], []
for f in sorted(glob.glob("probe/*/N*.json") + glob.glob("arms/A[123]_*/N*.json") + glob.glob("prompt/*/N*.json")):
    d = json.load(open(f))
    for x in d["requests"]:
        t = x.get("timing")
        if not t or not t.get("message_start") or not x["usage"]["output_tokens"]:
            continue
        rate = (t["end"] - t["message_start"]) / x["usage"]["output_tokens"] * 1000
        allr.append(rate)
        if t["max_gap"] > 5:
            gap.append((f.split("/")[1], d["key"], t["max_gap"], x["usage"]["output_tokens"], round(rate, 2)))
    if d.get("error") == "ClaudeTimeout" and (f.startswith("prompt/") or f.startswith("probe/w1")):
        fr = d.get("failed_request") or {}
        tmo.append((f.split("/")[1], d["key"], d["seconds"], fr.get("seconds"), (fr.get("timing") or {}).get("end"),
                    (fr.get("timing") or {}).get("message_start")))
print(f"streamed requests: {len(allr)}; ms per output token after message_start: median {st.median(allr):.2f}, "
      f"p10 {sorted(allr)[len(allr) // 10]:.2f}, p90 {sorted(allr)[9 * len(allr) // 10]:.2f}, max {max(allr):.2f}")
print(f"requests with a gap > 5 s: {len(gap)}; their rate: min {min(g[4] for g in gap)}, max {max(g[4] for g in gap)}")
for g in gap:
    print("  ", g)
print("timed-out turns on the committed build (run, key, turn s, failed request s, its timing end, message_start):")
for t in tmo:
    print("  ", t)
