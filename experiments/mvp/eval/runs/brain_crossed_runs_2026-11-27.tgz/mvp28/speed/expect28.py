"""mvp28 speed: expected median / p90 on all of half A (65 messages) from the six saved runs, with savings applied per
request (an estimate, not a run). Timed-out turns stay at 15 s (whether they would finish is not known).
- warm: the measured start-up (+1.15 s) off the first request of N001.0, N002.0, N004.0.
- strict off: per request, that run's own mean residual (seconds - 3.9 ms x output tokens, first requests of N001.0,
  N002.0, N004.0 left out) minus the strict-off floor measured live (A2: 0.405 s), so a session whose starts were already
  quick gains less than one whose starts were slow.
Also: the six saved runs restricted to the 20 sample messages beside today's same-sample runs (session vs prompt)."""
import glob, json, os, statistics as st
import records28 as R
data = {n: R.recs(p) for n, p in R.RUNS.items()}
WARM, FLOOR, SLOPE = 1.15, 0.405, 0.0039
FIRST3 = ("N001.0", "N002.0", "N004.0")
SAMPLE = ['N004.0', 'N005.0', 'N005.1', 'N007.0', 'N012.0', 'N013.0', 'N013.1', 'N018.0', 'N018.1', 'N032.0', 'N048.0',
          'N048.1', 'N053.0', 'N053.1', 'N056.0', 'N063.0', 'N063.1', 'N066.0', 'N066.1', 'N068.0']
f = lambda xs: f"{R.q(xs, .5):.2f}/{R.q(xs, .9):.2f} (>11: {sum(x > 11 for x in xs)})"
print("run: resid/request | as run | warm (answer-neutral) | warm + strict off (needs the blind run)")
for n, rs in data.items():
    res = [x["seconds"] - SLOPE * x["usage"]["output_tokens"] for d in rs for i, x in enumerate(d["requests"])
           if not (i == 0 and d["key"] in FIRST3)]
    save = max(0.0, st.mean(res) - FLOOR)
    a, w, s = [], [], []
    for d in rs:
        sec, tmo = d["seconds"], d.get("error") == "ClaudeTimeout"
        cut = WARM if d["key"] in FIRST3 else 0.0
        a.append(sec)
        w.append(sec if tmo else sec - cut)
        s.append(sec if tmo else sec - cut - save * len(d["requests"]))
    print(f"  {n}: {st.mean(res):.2f} (saving {save:.2f}/request) | {f(a)} | {f(w)} | {f(s)}")
print("\nthe 20 sample messages: saved runs (as run) and today's runs (A0 = today's build as committed at 8b9440e)")
for n, rs in data.items():
    xs = [d["seconds"] for d in rs if d["key"] in SAMPLE]
    print(f"  {n} ({len(xs)}): mean {st.mean(xs):.2f}, median/p90 {f(xs)}")
for run in [r for r in sorted(glob.glob("arms/A0_*")) + sorted(glob.glob("prompt/*_r*")) if os.path.isdir(r)]:
    xs = [json.load(open(p))["seconds"] for p in glob.glob(os.path.join(run, "N*.json"))]
    print(f"  today {run} ({len(xs)}): mean {st.mean(xs):.2f}, median/p90 {f(xs)}")
print("\ntimeouts on the four timeout messages (N004.0, N005.0, N007.0, N032.0) per run today:")
for run in [r for r in sorted(glob.glob("arms/*_r*")) + sorted(glob.glob("prompt/*_r*")) if os.path.isdir(r)]:
    t = [k for k in ("N004.0", "N005.0", "N007.0", "N032.0")
         if json.load(open(os.path.join(run, k + ".json"))).get("error") == "ClaudeTimeout"]
    print(f"  {run}: {t}")
