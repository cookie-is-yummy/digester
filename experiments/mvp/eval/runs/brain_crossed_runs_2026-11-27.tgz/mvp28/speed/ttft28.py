"""mvp28 speed: where the time to message_start goes (live, made-up text only, a few cents).
Sequential, interleaved shapes: count_tokens round trip (free); a minimal streamed request (no system, no tools);
the real prefix (system + ten tools, cached) with a one-word message, strict on the nine read tools (as sent) and with
strict off (grammar not compiled). Each billed request goes through provider.send's own logging (ai.log_batch)."""
import json, os, sys, time, statistics as st
sys.path.insert(0, os.getcwd())
from mvp.brain import provider as P, loop as BL

prov = P.AnthropicProvider(prompt_version="ttft28_probe", purpose="brain_eval", stream=True)
system, tools = BL.system_text(), BL.tool_list()
out = {"count": [], "minimal": [], "prefix_strict": [], "prefix_loose": []}
loose = P.AnthropicProvider(prompt_version="ttft28_probe", purpose="brain_eval", stream=True,
                            loose=tuple(t["name"] for t in tools))
t0 = time.time(); prov.warm(system, tools, 1); print("warm", round(time.time() - t0, 2))
msgs = [{"role": "user", "content": "<message>\nhi\n</message>"}]


def minimal():
    # the provider's own send, with a body of no system and no tools
    orig = prov.body
    prov.body = lambda s, t, m, mt=None: {"model": prov.model, "max_tokens": 64, "messages": m, "tools": [],
                                          "thinking": {"type": "disabled"}, "output_config": {"effort": "low"}}  # no tool_choice
    try:
        return prov.send("", [], [{"role": "user", "content": "Say ok."}], timeout=30)
    finally:
        prov.body = orig


for i in range(5):
    t = time.time(); prov.count_tokens(system, tools, msgs); out["count"].append(round(time.time() - t, 3))
    r = minimal(); out["minimal"].append((r.timing["message_start"], r.seconds, r.usage["output_tokens"]))
    r = prov.send(system, tools, msgs, max_tokens=300, timeout=30)
    out["prefix_strict"].append((r.timing["message_start"], r.seconds, r.usage["output_tokens"],
                                 r.usage["cache_read_input_tokens"], r.usage["cache_creation_input_tokens"]))
    r = loose.send(system, tools, msgs, max_tokens=300, timeout=30)
    out["prefix_loose"].append((r.timing["message_start"], r.seconds, r.usage["output_tokens"],
                                r.usage["cache_read_input_tokens"], r.usage["cache_creation_input_tokens"]))
for k, v in out.items():
    ms = [x if isinstance(x, float) else x[0] for x in v]
    print(k, "median", round(st.median(ms), 3), v)
print("spent", round(prov.spent + loose.spent, 6))
json.dump(out, open(sys.argv[1], "w"), indent=1)
