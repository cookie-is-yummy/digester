#!/bin/bash
# usage: live.sh OUTDIR IDS MAXUSD [ENV=VAL ...]  -- one eval run in the args tree, brain_v3b, values check
S=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad
OUT=$1; IDS=$2; MAX=$3; shift 3
. $S/keys/anthropic.env
cd $S/mvp28/args_tree/experiments
env PYTHONDONTWRITEBYTECODE=1 MVP_BRAIN_PROMPT=${PROMPT:-brain_v3b} MVP_LEDGER_HOME=/home/user/digester/data/mvp MVP_CLAUDE_CAP_USD=25 "$@" \
  python3 -m mvp.eval_brain run --set fresh --half a --check values --ids "$IDS" --out "$OUT" --parallel 3 \
  --max-usd "$MAX" 2>&1 | sed -E 's/sk-ant-[A-Za-z0-9_-]+/<key>/g' > "$OUT.log"
echo "exit ${PIPESTATUS[0]}" > "$OUT.exit"
