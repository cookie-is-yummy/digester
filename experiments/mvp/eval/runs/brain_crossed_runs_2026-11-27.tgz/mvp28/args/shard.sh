#!/bin/bash
# run the brain tests of the args tree in 4 parallel shards by file (sorted by size, round-robin)
cd /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/args_tree/experiments
OUT=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/args/suite_out
rm -rf $OUT; mkdir -p $OUT
files=$(ls -S ${PATTERN:-mvp/tests/test_brain_*.py})
i=0
for f in $files; do echo $f >> $OUT/list$((i%4)); i=$((i+1)); done
for k in 0 1 2 3; do
  env -u MVP_BRAIN_STREAM -u MVP_BRAIN_STRICT -u MVP_BRAIN_PROMPT PYTHONDONTWRITEBYTECODE=1 python3 -m pytest -q -p no:cacheprovider $(cat $OUT/list$k) > $OUT/res$k 2>&1 &
done
wait
for k in 0 1 2 3; do tail -1 $OUT/res$k; done
grep -h -E '^(FAILED|ERROR)' $OUT/res* | head -40
