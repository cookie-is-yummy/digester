"""Half A messages only, through the eval's own loader (run_set('a', set_name='fresh')); prints only matches."""
import re, sys
import alib as L
from mvp import eval_brain as E
convs = E.run_set("a", set_name="fresh")
msgs = [(p["id"], m.get("text") or m.get("message") or "") for p, _c in convs for m in p["messages"]]
print("half A conversations", len(convs), "messages", len(msgs))
for pat in sys.argv[1:]:
    hits = [(i, t) for i, t in msgs if re.search(pat, t, re.I)]
    print(f"== {pat!r}: {len(hits)}")
    for i, t in hits[:6]:
        print("  ", i, t[:120])
