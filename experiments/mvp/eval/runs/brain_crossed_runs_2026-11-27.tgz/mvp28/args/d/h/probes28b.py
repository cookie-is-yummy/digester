"""Task 2/4: how much rule cards_found (with rows_shown) widens what is found. On every saved form of the seven runs
whose result has a page of items, a made-up point "N of them came in that window." (N = 1..10) is added to the form
and the whole form checked (so the answer's cards are known): N the tip refuses and the tree finds, with each rule off."""
import copy
import lib28 as L
import variants28 as variants
V, VT = L.V, L.VT


import sys
CITE = "row" if "--cite" in sys.argv else None


def main():
    modes = [("tree", "values"), ("tree-cards_found", variants.mode("tree-cards_found")),
             ("tree-rows_shown", variants.mode("tree-rows_shown"))]
    n = tip_ref = forms = 0
    found = {m: 0 for m, _ in modes}
    ex = []
    for run in L.SEVEN:
        for rec, t, results in L.inputs(run):
            pages = V._Pool(V.Ledger(results)).pages
            if not pages:
                continue
            prid = sorted(pages)[0]
            for fi, f in enumerate(rec.get("forms") or []):
                forms += 1
                for k in range(1, 11):
                    g = copy.deepcopy(f)
                    g["points"] = (list(g.get("points") or [])[:2]) + [f"{k} of them came in that window." if CITE is None else
                                                             f"{k} of them came in that window, like this one[{prid}.items[0]]."]
                    a = VT.check_answer(g, results, VT.Turn.of(t), mode="values")
                    oa = [o for o in a.outcomes if o.where == "point"][-1]
                    n += 1
                    if oa.kept:
                        continue
                    tip_ref += 1
                    for name, md in modes:
                        b = V.check_answer(g, results, V.Turn.of(t), mode=md)
                        ob = [o for o in b.outcomes if o.where == "point"][-1]
                        found[name] += ob.kept
                        if ob.kept and name == "tree" and len(ex) < 8:
                            ex.append((run, rec["key"], fi, k))
    print(f"{forms} forms with a page; {n} made-up points, {tip_ref} refused by the tip; now found:",
          ", ".join(f"{k} {v}" for k, v in found.items()))
    print("examples (run, message, form, N):", ex)


if __name__ == "__main__":
    main()
