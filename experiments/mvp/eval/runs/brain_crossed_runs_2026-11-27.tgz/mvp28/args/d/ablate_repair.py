"""repair: for each attack sentence the unchanged tree (abc2486, h/base/verify_abc.py) keeps and the repaired tree
refuses, the repair rule whose removal alone lets it out again. Truth per script (attack1 F/T; attack2, attack3 all
false). No model call."""
import collections, os
import alib as L
import attack1 as A1, attack2 as A2, attack3 as A3
from mvp.tests.fakes.fake_brain import FakeEngine
VA = L._load(os.path.join(L.HERE, "h", "base", "verify_abc.py"), "mvp.brain.verify_abc")
REP = ["row_quote", "rows_before", "screen_uncited", "outcome_cited", "page_cited", "shown_said", "rows_kept"]
MODES = {r: L.V.values_mode(rules=L.V.VALUES_RULES - {r}) for r in REP}

def go(name, items):
    cnt = collections.Counter()
    for form, t, where, truth, s in items:
        ka = L.outcome(L.check(VA, form, t), where)[0]
        kv = L.outcome(L.check(L.V, form, t), where)[0]
        if ka == kv:
            continue
        who = [r for r, m in MODES.items() if L.outcome(L.check(L.V, form, t, m), where)[0] == ka]
        key = ("closed " if truth == "F" else ("kept " if kv else "REFUSED ")) + ("+".join(who) or "several")
        cnt[key] += 1
        print(f"{name} {truth} {'abc kept -> refused' if ka else 'abc refused -> kept'} [{'+'.join(who) or 'several'}] {s[:150]}")
    print(name, dict(cnt))

b = {}
it1 = []
for cid, sk, form, where, truth, shape in A1.CASES:
    if sk not in b:
        m, c, kw = A1.SCEN[sk]; b[sk] = L.turn(m, c, **kw)
    it1.append((form, b[sk], where, truth, f"{cid} {form['lead']} {form['points']}"))
go("attack1", it1)
ts2 = A2.built()
go("attack2", [({"lead": "Here is what the posts say.", "points": [s]}, ts2[sk], "point:0", "F", s) for sk, s, sh in A2.A])
ts3 = {k: L.turn(m, c, screen=sc, search=FakeEngine()) for k, (m, c, sc) in A3.SCEN.items()}
go("attack3", [({"lead": "Here is what I found.", "points": [s], "items": [{"ref": r, "note": None} for r in its]},
                ts3[sk], "point:0", "F", s) for sk, s, its, sh in A3.A])
