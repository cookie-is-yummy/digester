"""mvp28 merge: values mode of the merged tree on every saved form of the seven half A runs.
Every sentence whose verdict differs from the saved live verdict (runA, runB, base1, base2, arm1, arm2 ran values
live; run2 ran cells live, so its reference is the tip's values replay) is listed with:
  - whether the tip (8b9440e) already gives the new verdict (then an earlier round changed it), and
  - for a change made this round: the rule(s) of this round that make it, found by turning each new rule off alone
    (and, if none restores the tip's verdict alone, each pair).
Then totals of true sentences refused and false sentences caught, tip against merge, by hand truth:
run2/runA/runB the hand recount's label; base1..arm2 the settled false list of mvp27/tally/report.txt section 5a
plus the one-reader marks of mvp28/checks/marks28.txt for refused sentences. No model call."""
import itertools
import os
import re
import sys
import lib28 as L

V, VT = L.V, L.VT
NEW = sorted(V.VALUES_RULES - VT.VALUES_RULES)
LIVE = ("runA", "runB", "base1", "base2", "arm1", "arm2")
MARKS = os.path.join(L.S, "mvp28", "checks", "marks28.txt")
# settled false (mvp27 tally 5a, both readers agree): (run, key, form, place)
SETTLED_F = {("base1", "N044.0"), ("base2", "N044.0"), ("arm1", "N044.0"), ("base1", "N044.1"),
             ("base2", "N048.1"), ("base2", "N049.0")}


def marks():
    out = {}
    for line in open(MARKS):
        m = re.match(r"^(run2|runA|runB|base1|base2|arm1|arm2)\s+(N\d+\.\d)\s+f(\d)\s+(lead|point)(\d)\s+(\S)\s", line)
        if m:
            out[(m[1], m[2], int(m[3]), m[4], int(m[5]))] = m[6]
    return out


def mode_without(off):
    return V.values_mode(rules=V.VALUES_RULES - set(off))


def key_of(o):
    return (o.kept, tuple(o.reasons))


def main():
    mk = marks()
    rows, tot = [], {}
    for run in L.SEVEN:
        n_forms = n_sent = 0
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                n_forms += 1
                vt = VT.check_answer(f, results, VT.Turn.of(t), mode="values")
                vm = V.check_answer(f, results, V.Turn.of(t), mode="values")
                saved = None
                if run in LIVE and rec.get("verdicts") and fi < len(rec["verdicts"]):
                    saved = {(o["where"], o["index"]): (o["kept"], tuple(o["reasons"]))
                             for o in rec["verdicts"][fi]["outcomes"]}
                for pos, (ot, om) in enumerate(zip(vt.outcomes, vm.outcomes)):
                    n_sent += 1
                    place = (om.where, om.index)
                    ref = saved.get(place) if saved is not None else key_of(ot)
                    tr, _ = L.truth_of(run, rec["key"], fi, om.where, om.index)
                    if tr is None:
                        tr = mk.get((run, rec["key"], fi, om.where, om.index))
                    if tr is None and (run, rec["key"]) in SETTLED_F and run not in ("run2", "runA", "runB"):
                        tr = "F?"   # settled false message; this sentence's own mark is not listed
                    tot.setdefault(run, {"tip": [0, 0, 0], "merge": [0, 0, 0]})
                    tot[run].setdefault("tip0", [0, 0, 0]); tot[run].setdefault("merge0", [0, 0, 0])
                    for name, o in (("tip", ot), ("merge", om)):
                        if not o.kept:
                            tot[run][name][0 if tr == "T" else 1 if tr == "F" else 2] += 1
                            if fi == 0:
                                tot[run][name + "0"][0 if tr == "T" else 1 if tr == "F" else 2] += 1
                    if key_of(om) == ref:
                        continue
                    if key_of(ot) == key_of(om):
                        why = None
                        for r in sorted(VT.VALUES_RULES):
                            vo = VT.check_answer(f, results, VT.Turn.of(t), mode=VT.values_mode(rules=VT.VALUES_RULES - {r}))
                            if key_of(vo.outcomes[pos]) == ref:
                                why = (why + "," if why else "") + r
                        why = "earlier round (the tip already gives it): " + (why or "no single mvp27 rule; older change")
                    else:
                        why = None
                        for r in NEW:
                            vo = V.check_answer(f, results, V.Turn.of(t), mode=mode_without([r]))
                            if key_of(vo.outcomes[pos]) == key_of(ot):
                                why = (why + "," if why else "") + r
                        if why is None:
                            for a, b in itertools.combinations(NEW, 2):
                                vo = V.check_answer(f, results, V.Turn.of(t), mode=mode_without([a, b]))
                                if key_of(vo.outcomes[pos]) == key_of(ot):
                                    why = (why + " | " if why else "") + f"{a}+{b} together"
                        why = "this round: " + (why or "no single rule or pair")
                    rows.append((run, rec["key"], fi, f"{om.where}{om.index}", tr or "-",
                                 "live" if saved is not None else "tip replay", ref, key_of(ot), key_of(om), why,
                                 om.text))
        tot[run]["forms"], tot[run]["sent"] = n_forms, n_sent
    print("Values mode of the merged tree against the saved live verdict (run2: against the tip's values replay; it ran"
          " cells live).\nfields: run message form place truth reference: ref -> tip -> merge; what changed it\n")
    for r in rows:
        fmt = lambda k: ("kept" if k[0] else "refused") + (f" {list(k[1])}" if k[1] else "")
        print(f"{r[0]:5s} {r[1]} f{r[2]} {r[3]:7s} truth={r[4]:2s} {r[5]}: {fmt(r[6])} -> tip {fmt(r[7])} -> merge "
              f"{fmt(r[8])}\n      {r[9]}\n      \"{r[10][:200]}\"")
    print(f"\n{len(rows)} sentences differ from their reference; "
          f"{sum(1 for r in rows if r[9].startswith('this round'))} of them by this round's rules, "
          f"{sum(1 for r in rows if r[9].startswith('earlier'))} already on the tip.")
    print("\nSentences refused on replay of every saved form (T true refused, F false caught, ? no hand mark):")
    print("run    forms sentences  tip T/F/?     merge T/F/?")
    allt = {"tip": [0, 0, 0], "merge": [0, 0, 0]}
    for run in L.SEVEN:
        d = tot[run]
        for k in allt:
            allt[k] = [a + b for a, b in zip(allt[k], d[k])]
        print(f"{run:6s} {d['forms']:5d} {d['sent']:9d}  {'/'.join(map(str, d['tip'])):12s}  "
              f"{'/'.join(map(str, d['merge']))}")
    print(f"all                     {'/'.join(map(str, allt['tip'])):12s}  {'/'.join(map(str, allt['merge']))}")
    a0 = {"tip0": [0, 0, 0], "merge0": [0, 0, 0]}
    for run in L.SEVEN:
        for k in a0:
            a0[k] = [a + b for a, b in zip(a0[k], tot[run][k])]
    print(f"first form only (what a turn sends before any reword): tip {'/'.join(map(str, a0['tip0']))}, "
          f"merge {'/'.join(map(str, a0['merge0']))}")


if __name__ == "__main__":
    sys.exit(main())
