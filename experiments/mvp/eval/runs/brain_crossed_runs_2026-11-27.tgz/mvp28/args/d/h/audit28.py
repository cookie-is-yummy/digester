"""Task 1: the in-run audit path (eval_brain.audit_sent, as reaudit and live_conversation call it) over every saved
record of the seven runs and mvp24 run1, with the tip's eval_claims (8b9440e, checks/base/) and this tree's. Prints
every record where one crashes or the two differ. usage: audit28.py [tip|tree|both]"""
import glob, json, os, sys, traceback
import lib28 as L
from mvp import eval_brain as E
import mvp.eval_claims as EC_TREE
EC_TIP = L._load(os.path.join(L.HERE, "base", "eval_claims_tip.py"), "mvp.eval_claims_tip", pkg="mvp")
RUNS = dict(L.RUNS)
RUNS["run1"] = os.path.join(L.S, "mvp24/runa/run1")
ORDER = ("run1",) + L.SEVEN


def audit(ec, h, rec):
    sys.modules["mvp.eval_claims"] = ec
    import mvp
    mvp.eval_claims = ec
    results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid")}
    unlock = rec["unlock"] if "unlock" in rec else h.turn(rec["message"]).unlock
    try:
        return E.audit_sent(h, results, unlock, rec, rec["message"])
    except Exception as e:   # noqa: BLE001
        return ("CRASH", f"{type(e).__name__}: {e}", traceback.format_exc().splitlines()[-3])


def records(run):
    for p in sorted(glob.glob(os.path.join(RUNS[run], "*.json"))):
        rec = json.load(open(p))
        if "message" in rec and "calls" in rec:
            yield rec


def main():
    h = L.harness()
    n = crash = {"tip": 0, "tree": 0}
    n, crash, differ = 0, {"tip": 0, "tree": 0}, 0
    for run in ORDER:
        for rec in records(run):
            n += 1
            a, b = audit(EC_TIP, h, rec), audit(EC_TREE, h, rec)
            for name, x in (("tip", a), ("tree", b)):
                if isinstance(x, tuple) and x and x[0] == "CRASH":
                    crash[name] += 1
                    print("CRASH", name, run, rec["key"], x[1], "|", x[2])
            if json.dumps(a, default=str, sort_keys=True) != json.dumps(b, default=str, sort_keys=True):
                differ += 1
                print("DIFF", run, rec["key"])
                print("   tip ", json.dumps(a, default=str)[:600])
                print("   tree", json.dumps(b, default=str)[:600])
    sys.modules["mvp.eval_claims"] = EC_TREE
    print(f"records {n}; crashes tip {crash['tip']} tree {crash['tree']}; audit results that differ: {differ}")


if __name__ == "__main__":
    main()
