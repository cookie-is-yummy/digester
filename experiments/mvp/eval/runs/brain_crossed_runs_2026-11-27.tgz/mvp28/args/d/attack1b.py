"""attack 1b: true sentences that say an honest page count over fewer cards, worded so the tip keeps them (no second
figure no cell holds): what item_count costs on its own."""
import alib as L
import attack1 as A1
F, it = A1.F, A1.it
T = [
 ("cook5", F("The list gave 5[r1.items.count]; the ones below have a title no other video of yours shares.", items=it("r1", 0, 3))),
 ("cook5", F("The list gives 5[r1.items.count] at a time; here are some from Pan Theory[r1.items[0].channel].", items=it("r1", 0, 1))),
 ("cook5", F("All 5[r1.items.count] on the list were opened once, so none ranks above the others; a few are below.", items=it("r1", 0, 1))),
 ("cook5", F("Of the five the list gave, here are the ones to start with.", items=it("r1", 0, 1))),
 ("cook5", F("Pan Theory[r1.items[0].channel] leads.", ["Of the 5 on the list, these are titles you opened under the same name many times."], it("r1", 1, 2, 4))),
 ("cook5", F("Of the 5[r1.items.count] the list gave, Cooking hack[r1.items[3]] has a title that reads like code.", items=it("r1", 3))),
 ("cook10", F("The list gave 10[r1.items.count]; here are the first of them.", items=it("r1", 0, 1, 2, 3, 4))),
 ("cook10", F("The 10[r1.items.count] most opened include these from Pan Theory[r1.items[0].channel].", items=it("r1", 0, 1, 2, 3, 4))),
 ("saved5", F("Your 5[r1.items.count] newest saves include the watercolor lessons below.", items=it("r1", 3, 4))),
 ("saved5", F("Your 5[r1.items.count] newest saves include 2 watercolor lessons, shown below.", items=it("r1", 3, 4))),
 ("cook3", F("Of the 3[r1.items.count] newest, start with Cooking soup on the 30th[r1.items[0]].", items=it("r1", 0))),
 ("cook3", F("Of your 3[r1.items.count] newest cooking videos, the soup one is the one to try first.", items=it("r1", 0))),
]
built = {}
tip_k = tree_k = 0
for sk, f in T:
    if sk not in built:
        m, c, kw = A1.SCEN[sk]; built[sk] = L.turn(m, c, **kw)
    t = built[sk]
    kt, rt, _ = L.outcome(L.check(L.VT, f, t), "point:0" if f["points"] else "lead")
    kv, rv, _ = L.outcome(L.check(L.V, f, t), "point:0" if f["points"] else "lead")
    tip_k += kt; tree_k += kv
    print(f"tip={'kept' if kt else rt} tree={'kept' if kv else rv} | {f['lead']} {f['points']}")
print(f"{len(T)} true: kept by the tip {tip_k}, by the tree {tree_k}")
