import inspect, alib as L
V, VT = L.V, L.VT
for n in ("_sensitive", "_not_english", "_values_safety", "check_sentence_values", "_values_flags", "repair_message", "check_answer", "_check_answer_cells" ):
    a, b = getattr(V, n, None), getattr(VT, n, None)
    if a is None or b is None: print(n, "missing", a is None, b is None); continue
    print(n, "same source" if inspect.getsource(a) == inspect.getsource(b) else "DIFFERS")
for n in ("PSYCH", "OUTCOME", "_MOTIVE", "_V_MOTIVE", "_V_STATE", "LIMITS", "WATCH_TIME", "_V_HANDLE"):
    a, b = getattr(V, n, None), getattr(VT, n, None)
    print(n, "same" if (a is not None and b is not None and (a == b if isinstance(a, str) else (a.pattern == b.pattern and a.flags == b.flags))) else "DIFFERS", type(a))
print("I._LINK same", V.I._LINK.pattern == VT.I._LINK.pattern)
print("VALUES_SAFETY", V.VALUES_SAFETY == VT.VALUES_SAFETY, "VALUES_CODES new:", set(V.VALUES_CODES) - set(VT.VALUES_CODES), "gone:", set(VT.VALUES_CODES) - set(V.VALUES_CODES))
print("FULL rules same", V.FULL.rules == VT.FULL.rules, "CELLS rules same", V.CELLS.rules == VT.CELLS.rules)
