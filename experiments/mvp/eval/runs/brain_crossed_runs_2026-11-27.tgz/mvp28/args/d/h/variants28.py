"""Named values-mode variants of this tree: 'tree' (every rule), 'tree-<rule>' (one rule off), 'tree-<a>-<b>'."""
import lib28 as L


def mode(name):
    V = L.V
    if name == "tree":
        return "values"
    off = set(name.split("-")[1:])
    assert off <= V.VALUES_RULES, off
    return V.values_mode(rules=V.VALUES_RULES - off)
