"""Which r28 rule lets each OUT of attack2/attack3 out: the rule whose removal (alone) restores the refusal."""
import collections
import alib as L
import attack2 as A2, attack3 as A3
from mvp.tests.fakes.fake_brain import FakeEngine
R28 = ["item_count", "item_count_free", "cards_found", "rows_shown", "row_text", "screen_window", "cited_rows", "row_group", "outcome_you"]
MODES = {r: L.V.values_mode(rules=L.V.VALUES_RULES - {r}) for r in R28}
MODES["all_r28_off"] = L.V.values_mode(rules=L.V.VALUES_RULES - set(R28))

def run(name, cases, ts, mk):
    cnt = collections.Counter()
    for c in cases:
        sk, s = c[0], c[1]
        form = mk(c)
        t = ts[sk]
        kv, _, _ = L.outcome(L.check(L.V, form, t), "point:0")
        kt, _, _ = L.outcome(L.check(L.VT, form, t), "point:0")
        if not kv or kt:
            continue
        who = [r for r, m in MODES.items() if r != "all_r28_off" and not L.outcome(L.check(L.V, form, t, m), "point:0")[0]]
        alloff = L.outcome(L.check(L.V, form, t, MODES["all_r28_off"]), "point:0")[0]
        key = "+".join(who) if who else ("several (only all off refuses)" if not alloff else "NONE (all r28 off still keeps)")
        cnt[key] += 1
        print(f"{name} {key:30s} {s}")
    print(name, dict(cnt))

ts2 = A2.built()
run("attack2", A2.A, ts2, lambda c: {"lead": "Here is what the posts say.", "points": [c[1]]})
ts3 = {k: L.turn(m, calls, screen=sc, search=FakeEngine()) for k, (m, calls, sc) in A3.SCEN.items()}
run("attack3", A3.A, ts3, lambda c: {"lead": "Here is what I found.", "points": [c[1]], "items": [{"ref": r, "note": None} for r in c[2]]})
