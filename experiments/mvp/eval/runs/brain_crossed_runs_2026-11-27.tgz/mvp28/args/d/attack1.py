"""attack 1: the count-against-cards check (rules item_count, item_count_free, cards_found, rows_shown). Made-up
give_answer forms over the made-up library through the tools. Each case: truth by hand from the rows printed by
explore2/explore3 (titles, channels, counts). Reports, per truth: kept by the tip's values mode and by this tree's.
usage: python3 -B attack1.py [-v]"""
import sys
import alib as L
from mvp.tests.fakes.fake_brain import FakeEngine

COOK = ("items", {"limit": 5, "order": "most_opened", "window": {"preset": "all"},
                  "scope": {"how": "opened", "only": ["cooking"]}})
COOK3 = ("items", {"limit": 3, "order": "newest", "window": {"preset": "all"},
                   "scope": {"how": "opened", "only": ["cooking"]}})
COOK10 = ("items", {"limit": 10, "order": "most_opened", "window": {"preset": "all"},
                    "scope": {"how": "opened", "only": ["cooking"]}})
SAVED = ("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "saved"}})
BREAD = [("find", {"names": ["Bread days"], "kinds": ["collection"]}),
         ("items", {"limit": 5, "order": "newest", "window": {"preset": "all"},
                    "scope": {"how": "saved", "only": ["Bread days"]}})]
WC = ("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "saved", "only": ["watercolor"]}})
BD = ("breakdown", {"by": "theme", "window": {"preset": "lately"}, "scope": {}, "compare": "none"})
SRCH = ("search", {"query": "sourdough", "how": "saved", "limit": 5, "window": {"preset": "all"}})

SCEN = {"cook5": ("show me a few of my cooking videos", [COOK], {}),
        "cook5b": ("show me a few of my cooking videos and what I watch lately", [COOK, BD], {}),
        "cook3": ("my newest cooking videos", [COOK3], {}),
        "cook10": ("my cooking videos", [COOK10], {}),
        "saved5": ("what did I save", [SAVED], {}),
        "bread": ("what is in Bread days", BREAD, {}),
        "wc": ("my saved watercolor lessons", [WC], {}),
        "srch": ("my sourdough saves", [SRCH], {"search": FakeEngine()})}


def F(lead, points=(), items=(), **kw):
    return dict({"lead": lead, "points": list(points), "items": [{"ref": r, "note": None} for r in items]}, **kw)


def it(rid, *ks):
    return [f"{rid}.items[{k}]" for k in ks]


T72 = "[r1.totals.items]"
WRONG_PT = "Cooking hack[r1.items[3]] and Cooking tofu three ways[r1.items[4]] were opened on 2 October 2026."
CASES = [
    # ---------------------------------------------------------------- false: a count of shown rows over fewer
    ("F01", "cook5", F(f"Here are five of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "F", "number word, lead"),
    ("F02", "cook5", F(f"Here are a handful of the 72{T72} cooking videos you opened.", items=it("r1", 0)), "lead", "F", "a handful over 1"),
    ("F03", "cook5", F(f"Here are all 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "F", "total said as shown"),
    ("F04", "cook5", F("Pan Theory[r1.items[0].channel] made every cooking video you opened most.", ["Here are 5 of them below."], it("r1", 0, 1)), "point:0", "F", "digit in a point, no marker"),
    ("F05", "cook5", F("Pan Theory[r1.items[0].channel] made every one.", ["These 5[r1.items.count] are the ones you opened most."], it("r1", 0, 1)), "point:0", "F", "marker in a point"),
    ("F06", "cook5", F("These three are your most opened cooking videos.", items=it("r1", 0, 1)), "lead", "F", "these three, not the page length"),
    ("F07", "cook5", F("Both of these are from Pan Theory[r1.items[0].channel].", items=it("r1", 0)), "lead", "F", "both over 1"),
    ("F08", "cook5", F("Here are the 5 you opened most, all from Pan Theory[r1.items[0].channel].", items=it("r1", 0, 1, 2)), "lead", "F", "digit no marker"),
    ("F09", "cook5", F(f"I picked the top 5[r1.items.count] of your 72{T72} cooking videos for you below."), "lead", "F", "marker, no card at all"),
    ("F10", "cook5", F(f"Here are 5[r1.items.count] of the 72{T72} cooking videos you opened.", [WRONG_PT], it("r1", 0, 1, 2)), "lead", "F", "rows named in a refused point"),
    ("F11", "cook5", F("Here are half a dozen of your cooking videos.", items=it("r1", 0, 1, 2)), "lead", "F", "half a dozen"),
    ("F12", "cook5", F("Here is a pair of cooking videos you opened.", items=it("r1", 0)), "lead", "F", "a pair over 1"),
    ("F13", "cook5", F("Here are a couple of cooking videos you opened.", items=it("r1", 0)), "lead", "F", "a couple over 1"),
    ("F14", "cook5", F(f"Here are 5[r1.items.count] of the 72{T72} cooking videos you opened.", items=it("r1", 0, 0, 1, 1, 2)), "lead", "F", "picks repeated"),
    ("F15", "cook5", F("Pan Theory[r1.items[0].channel] leads.", ["Five favourites are below."], it("r1", 0, 1)), "point:0", "F", "number word in a point"),
    ("F16", "cook5", F("Pan Theory[r1.items[0].channel] leads.", ["The top 5 are listed below."], it("r1", 0, 1, 2)), "point:0", "F", "digit in a point"),
    ("F17", "cook5", F("Here are the five you opened most.", items=it("r1", 0, 1, 2, 3)), "lead", "F", "five over 4"),
    ("F18", "cook5", F("Here are your 5 most opened cooking videos, each opened once[r1.items[0].times_opened].", items=it("r1", 0, 1)), "lead", "F", "digit + other marker"),
    ("F19", "cook5", F("Here are a few cooking videos; all five are from Pan Theory[r1.items[0].channel].", items=it("r1", 0, 1)), "lead", "F", "all five, 2 shown"),
    ("F20", "cook5", F("Which of these 5 do you want first?", ask_back={"between": it("r1", 0, 1)}), "lead", "F", "ask-back over 2"),
    ("F21", "cook5", F(f"Here are 5 of the 72{T72} cooking videos you opened (the top five).", items=it("r1", 0, 1, 2)), "lead", "F", "twice, digit and word"),
    ("F22", "cook5", F("Five cooking videos you opened are below.", items=it("r1", 0)), "lead", "F", "number word first"),
    # page with a second result beside it (another cell holds 5)
    ("F23", "cook5b", F(f"Here are 5 of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "F", "digit, two results"),
    ("F24", "cook5b", F(f"Here are five of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "F", "word, two results"),
    ("F25", "cook5b", F(f"Here are 5[r1.items.count] of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "F", "marker, two results"),
    ("F26", "cook5b", F("Pan Theory[r1.items[0].channel] leads.", ["Here are the top 5 of them."], it("r1", 0)), "point:0", "F", "point, two results"),
    ("F27", "cook5b", F("Here are your top five cooking videos.", items=it("r1", 0, 1)), "lead", "F", "word, two results, no total"),
    # page of 3
    ("F28", "cook3", F(f"Here are 3 of the 72{T72} cooking videos you opened.", items=it("r1", 0)), "lead", "F", "digit, page 3"),
    ("F29", "cook3", F(f"Here are three of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1)), "lead", "F", "word, page 3"),
    ("F30", "cook3", F("Here are your 3 newest cooking videos."), "lead", "F", "digit, no card"),
    ("F31", "cook3", F("Here are your 3[r1.items.count] newest cooking videos."), "lead", "F", "marker, no card"),
    # page of 10
    ("F32", "cook10", F(f"Here are your 10[r1.items.count] most opened of the 72{T72} cooking videos.", items=it("r1", 0, 1, 2, 3)), "lead", "F", "marker, page 10"),
    ("F33", "cook10", F("Here are ten of them.", items=it("r1", 0, 1, 2, 3)), "lead", "F", "word, page 10"),
    # page of 5 of 6, 5 held twice
    ("F34", "saved5", F("Here are your 5 newest saves.", items=it("r1", 1, 2)), "lead", "F", "digit, 5 held twice"),
    ("F35", "saved5", F("Here are your five newest saves.", items=it("r1", 1, 2)), "lead", "F", "word, 5 held twice"),
    ("F36", "saved5", F("Here are your 5[r1.items.count] newest saves.", items=it("r1", 1, 2)), "lead", "F", "marker"),
    ("F37", "saved5", F("Your 6[r1.totals.items] saves are all below.", items=it("r1", 0, 1, 2)), "lead", "F", "total said as shown"),
    ("F38", "saved5", F("These two sourdough posts are your saves from @crumb.lab[r1.items[1].channel].", items=it("r1", 1)), "lead", "F", "these two over 1"),
    ("F39", "saved5", F("Here are 3 of your newest saves.", items=it("r1", 1, 2)), "lead", "F", "digit another cell holds"),
    ("F40", "saved5", F("Here are your newest saves; all 6 are shown.", items=it("r1", 0, 1, 2)), "lead", "F", "all 6 shown"),
    # complete lists (no page)
    ("F41", "bread", F("Here are both posts in Bread days.", items=it("r2", 0)), "lead", "F", "both, complete list"),
    ("F42", "bread", F("Here are the 2[r2.items.count] posts in Bread days.", items=it("r2", 0)), "lead", "F", "marker, complete list"),
    ("F43", "bread", F("Here are your two Bread days saves.", items=it("r2", 0)), "lead", "F", "word, complete list"),
    ("F44", "wc", F("Here are the 3[r1.items.count] watercolor lessons you saved.", items=it("r1", 0)), "lead", "F", "marker, complete list of 3"),
    ("F45", "wc", F("Here are all three watercolor lessons you saved.", items=it("r1", 0, 1)), "lead", "F", "word, complete list of 3"),
    # search (no totals)
    ("F46", "srch", F("Here are the 2[r1.items.count] sourdough posts you saved.", items=it("r1", 0)), "lead", "F", "marker, search"),
    ("F47", "srch", F("Here are both sourdough posts you saved.", items=it("r1", 0)), "lead", "F", "both, search"),
    ("F48", "srch", F("Here are your two sourdough saves.", items=it("r1", 1)), "lead", "F", "word, search"),
    # ---------------------------------------------------------------- true
    ("T01", "cook5", F(f"You opened 72{T72} cooking videos in all; here are the newest.", items=it("r1", 0, 1, 2)), "lead", "T", "total"),
    ("T02", "cook5", F(f"Here are 5[r1.items.count] of your 72{T72} cooking videos.", items=it("r1", 0, 1, 2, 3, 4)), "lead", "T", "all five sent"),
    ("T03", "cook5", F("The list gave 5[r1.items.count]; the two below have a title no other video of yours shares.", items=it("r1", 0, 3)), "lead", "T", "honest fewer, said"),
    ("T04", "cook5", F("The list gives 5[r1.items.count] at a time; here are two from Pan Theory[r1.items[0].channel].", items=it("r1", 0, 1)), "lead", "T", "honest fewer, said"),
    ("T05", "cook5", F("All 5[r1.items.count] on the list were opened once, so none ranks above the others; two are below.", items=it("r1", 0, 1)), "lead", "T", "honest fewer, said"),
    ("T06", "cook5", F("Pan Theory[r1.items[0].channel] made all 5 shown.", items=it("r1", 0, 1, 2, 3, 4)), "lead", "T", "all 5 sent"),
    ("T07", "cook5", F(f"Each of the 72{T72} cooking videos was opened once."), "lead", "T", "total, no card"),
    ("T08", "cook5", F(f"Here are 4 of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2, 4)), "lead", "T", "four sent"),
    ("T09", "cook5", F("These 2 are worth a rewatch: Cooking soup on the 30th[r1.items[0]] and Cooking crispy rice[r1.items[1]]."), "lead", "T", "rows cited"),
    ("T10", "cook5", F("Of the five the list gave, here are the two to start with.", items=it("r1", 0, 1)), "lead", "T", "honest fewer, word"),
    ("T11", "cook5", F("Pan Theory[r1.items[0].channel] leads.", ["Of the 5 on the list, 3 are titles you opened under the same name many times."], it("r1", 1, 2, 4)), "point:0", "T", "honest fewer, point"),
    ("T12", "saved5", F(f"You saved 6{T72} things; here are the 2 sourdough posts.", items=it("r1", 1, 2)), "lead", "T", "total + subset"),
    ("T13", "saved5", F("Here are your 5[r1.items.count] newest saves; a friend's post is left out.", items=it("r1", 0, 1, 2, 3, 4)), "lead", "T", "all sent"),
    ("T14", "saved5", F("Your 5[r1.items.count] newest saves include 2 watercolor lessons, shown below.", items=it("r1", 3, 4)), "lead", "T", "honest fewer, marker"),
    ("T15", "saved5", F("Of your 5 newest saves, the two from @crumb.lab[r1.items[1].channel] are below.", items=it("r1", 1, 2)), "lead", "T", "honest fewer, digit"),
    ("T16", "bread", F("Both posts in Bread days are from @crumb.lab[r2.items[0].channel].", items=it("r2", 0, 1)), "lead", "T", "both sent"),
    ("T17", "bread", F("Bread days holds 2[r2.totals.items] posts; here is the newest.", items=it("r2", 0)), "lead", "T", "total + one"),
    ("T18", "cook3", F("Here are your 3[r1.items.count] newest cooking videos.", items=it("r1", 0, 1, 2)), "lead", "T", "all sent"),
    ("T19", "cook3", F("Of the 3[r1.items.count] newest, start with Cooking soup on the 30th[r1.items[0]].", items=it("r1", 0)), "lead", "T", "honest pick of 3"),
    ("T20", "cook10", F("The list gave 10[r1.items.count]; here are the first 5 of them.", items=it("r1", 0, 1, 2, 3, 4)), "lead", "T", "page 10, cards max 5"),
    ("T21", "cook10", F(f"Here are 5 of the 72{T72} cooking videos you opened most.", items=it("r1", 0, 1, 2, 3, 4)), "lead", "T", "five of page 10"),
    ("T22", "cook5b", F(f"Here are 3 of the 72{T72} cooking videos you opened.", items=it("r1", 0, 1, 2)), "lead", "T", "three sent, two results"),
    ("T23", "wc", F("You saved 3 watercolor lessons from Wet Paper[r1.items[0].channel]; here is the newest.", items=it("r1", 0)), "lead", "T", "count of other things"),
    ("T24", "srch", F("Both sourdough posts you saved are from @crumb.lab[r1.items[0].channel].", items=it("r1", 0, 1)), "lead", "T", "both sent, search"),
]


def main():
    verbose = "-v" in sys.argv
    built = {}
    rows = []
    for cid, sk, form, where, truth, shape in CASES:
        if sk not in built:
            msg, calls, kw = SCEN[sk]
            built[sk] = L.turn(msg, calls, **kw)
        t = built[sk]
        kv, rv, fv = L.outcome(L.check(L.V, form, t), where)
        kt, rt, _ft = L.outcome(L.check(L.VT, form, t), where)
        rows.append((cid, sk, truth, shape, kt, rt, kv, rv, fv, form))
    for truth, name in (("F", "false"), ("T", "true")):
        rs = [r for r in rows if r[2] == truth]
        tip_k, tree_k = sum(r[4] for r in rs), sum(r[6] for r in rs)
        print(f"{name}: {len(rs)} cases; kept by the tip {tip_k}, by the tree {tree_k}")
    for r in rows:
        cid, sk, truth, shape, kt, rt, kv, rv, fv, form = r
        bad = (truth == "F" and kv) or (truth == "T" and not kv)
        if verbose or bad or kt != kv:
            print(f"{cid} {sk:7s} {truth} {'OUT ' if truth == 'F' and kv else ('REFUSED ' if truth == 'T' and not kv else '')}"
                  f"tip={'kept' if kt else rt} tree={'kept' if kv else rv} [{shape}]")
            print("     ", form["lead"], "|", form.get("points"), "| items", [x["ref"] for x in form["items"]])


if __name__ == "__main__":
    main()
