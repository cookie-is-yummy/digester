"""repair (mvp28): values-mode verdict of every sentence of every saved form of run1 and the seven half A runs,
through the tree's checker (VALUES_TREE) -> JSON. With a second file, the sentences whose verdict differs, with their
hand truth (recount label, or the settled false list and marks28 of attr28). No model call.
usage: python3 -B dump_ref.py OUT.json [REF.json]"""
import json
import sys
import lib28 as L
import attr28 as AT

V = L.V


def dump():
    out = {}
    for run in ("run1",) + L.SEVEN:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                v = V.check_answer(f, results, V.Turn.of(t), mode="values")
                for o in v.outcomes:
                    out[f"{run}|{rec['key']}|{fi}|{o.where}|{o.index}"] = [o.kept, list(o.reasons), o.text]
    return out


def truth(run, key, fi, where, idx, mk):
    tr, _ = L.truth_of(run, key, fi, where, idx)
    if tr:
        return L.TMAP.get(tr, tr)
    if (run, key) in AT.SETTLED_F:
        return "F?"
    return mk.get((run, key, fi, where, idx), "?")


def main():
    cur = dump()
    json.dump(cur, open(sys.argv[1], "w"))
    print(f"{len(cur)} sentences")
    if len(sys.argv) > 2:
        ref = json.load(open(sys.argv[2]))
        mk = AT.marks()
        n = 0
        for k, (kept, rs, text) in sorted(cur.items()):
            r = ref.get(k)
            if r is None or r[0] != kept or r[1] != rs:
                n += 1
                run, key, fi, where, idx = k.split("|")
                tr = truth(run, key, int(fi), where, int(idx), mk)
                print(f"{run} {key} f{fi} {where}{idx} truth={tr}: {'kept' if r and r[0] else (r[1] if r else 'new')}"
                      f" -> {'kept' if kept else rs}\n    {text[:200]}")
        print(f"{n} sentences differ from {sys.argv[2]}")


if __name__ == "__main__":
    main()
