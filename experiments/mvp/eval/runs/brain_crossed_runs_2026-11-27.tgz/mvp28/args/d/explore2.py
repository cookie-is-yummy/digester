import json, alib as L
def show(t):
    for rid, r in L.results(t).items():
        sh = r.get("sheet") or {}
        print(rid, r.get("tool"), "totals", sh.get("totals"), "is_error", r.get("is_error"), "keys", list(sh)[:12])
        for it in sh.get("items") or []:
            print("   ", it.get("ref"), "|", it.get("title"), "|", it.get("channel"), it.get("when"), it.get("how"), it.get("times_opened"), it.get("length"), it.get("same_title"))
        p = L.V._Pool(L.V.Ledger(L.results(t)), t.message)
        print("   pages", p.pages, "held5", p.held.get(5.0), "held3", p.held.get(3.0), "held2", p.held.get(2.0), "held4", p.held.get(4.0), "held10", p.held.get(10.0))
S=L.__dict__
for name, calls in [
  ("cook5", [("items", {"limit": 5, "offset": 0, "order": "most_opened", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["cooking"]}})]),
  ("cook3", [("items", {"limit": 3, "offset": 0, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["cooking"]}})]),
  ("saved5", [("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "saved"}})]),
  ("bread", [("find", {"names": ["Bread days"], "kinds": ["collection"]}), ("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "saved", "only": ["Bread days"]}})]),
  ("search", [("search", {"query": "sourdough", "how": "saved", "limit": 5})]),
  ("wc", [("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "saved", "only": ["watercolor"]}})]),
  ("gd", [("items", {"limit": 10, "order": "newest", "window": {"words": "October 2026"}, "scope": {"how": "opened", "only": ["Gaming Daily"]}})]),
]:
    print("==", name)
    t = L.turn("show me", calls)
    show(t)
