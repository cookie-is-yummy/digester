"""Task 1: the N019.0 crash rebuilt from base1's saved N019.0 result (the record of the crashed runs was lost): the same
record with one more kept point that cites a date cell whose path does not end .when (new.small_channels[0].first_watched
holds '2026-10-12', the value of the crash), and one that cites the weekday-list cell (when.busiest_weekdays). Writes
the built records under checks/crash/ (a run folder for `audit --run`) and runs the in-run path (audit_sent) with
the tip's eval_claims and this tree's."""
import copy, json, os, shutil, sys
import audit28 as A
import lib28 as L

SENTS = {
    "date": "Wet Paper's Instagram account @wetpaper.ig[r1.new.small_channels[0]] was first opened on 12 October "
            "2026[r1.new.small_channels[0].first_watched].",
    "date_wrong": "It was first opened on 14 October 2026[r1.new.small_channels[0].first_watched].",
    "weekdays": "Your busiest were 2 days, Thursday and Friday[r1.when.busiest_weekdays].",
}


def built():
    base = json.load(open(os.path.join(L.RUNS["base1"], "N019.0.json")))
    out = {}
    for name, s in SENTS.items():
        rec = copy.deepcopy(base)
        o = copy.deepcopy(rec["verdicts"][0]["outcomes"][-1])
        o.update({"where": "point", "index": 9, "text": s, "sent": L.V.strip_markers(s), "kept": True, "reasons": []})
        rec["verdicts"][0]["outcomes"].append(o)
        out[name] = rec   # key and id stay N019.0 (the hand plan and G2 of the message)
    return out


def main():
    h = L.harness()
    for name, rec in built().items():
        d = os.path.join(L.HERE, "auditrun", "crash_" + name)
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(d)
        with open(os.path.join(d, "N019.0.json"), "w") as fh:
            json.dump(rec, fh, indent=1, ensure_ascii=False)
        for ec_name, ec in (("tip", A.EC_TIP), ("tree", A.EC_TREE)):
            x = A.audit(ec, h, rec)
            if isinstance(x, tuple) and x and x[0] == "CRASH":
                print(f"{name:10s} {ec_name}: CRASH {x[1]}")
            else:
                bad, checked = x
                new = [b for b in bad if "small_channels" in str(b.get("where")) or "weekdays" in str(b.get("where"))]
                print(f"{name:10s} {ec_name}: completes, {checked} rows checked, findings on the built cell: {new}")
    sys.modules["mvp.eval_claims"] = A.EC_TREE


if __name__ == "__main__":
    main()
