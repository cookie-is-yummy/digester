"""Task 5 (N049.0): how often a kept sentence cites a row's cell with that row neither marked nor named in the same
sentence (the shape of N049.0: a channel's first_watched said of a title). Seven runs, tree values mode, every form;
labels from the hand recounts where there are any."""
import re
from collections import Counter
import lib28 as L
V = L.V


def main():
    c = Counter()
    ex = []
    for run in L.SEVEN:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                v = V.check_answer(f, results, V.Turn.of(t), mode="values")
                led = V.Ledger(results)
                for o in v.outcomes:
                    if not o.kept or o.where not in ("lead", "point"):
                        continue
                    mks, _bad = V.parse(" ".join(o.text.split()), led, V.CELLS_LOOSE)
                    rows_marked = {(m.rid, m.rest) for m in mks if m.kind == "row"}
                    low = V.strip_markers(o.text).lower()
                    for m in mks:
                        if m.kind != "value" or not m.owner:
                            continue
                        c["value markers on a row's cell"] += 1
                        if (m.rid, m.owner) in rows_marked:
                            continue
                        try:
                            row = V._resolve(led.get(m.rid).sheet, m.owner)
                        except Exception:   # noqa: BLE001
                            continue
                        names = [x for x in V._row_own_names(row, m.owner) if len(x) >= 3]
                        if any(n in low for n in names):
                            continue
                        tr, _l = L.truth_of(run, rec["key"], fi, o.where, o.index)
                        c[f"row neither marked nor named (label {tr})"] += 1
                        if len(ex) < 12:
                            ex.append((run, rec["key"], fi, o.where, m.path, o.text[:170]))
    for k, n in c.items():
        print(f"{n:5d}  {k}")
    for e in ex:
        print("  ", *e)


if __name__ == "__main__":
    main()
