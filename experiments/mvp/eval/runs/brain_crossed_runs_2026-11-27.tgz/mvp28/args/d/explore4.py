import json, alib as L
from mvp.tests.fakes.fake_brain import FakeEngine
for q, how in (("castle rule email", "opened"), ("watercolor tips love", "opened"), ("cooking hack views", "opened"), ("pasta night", "saved")):
    t = L.turn("x", [("search", {"query": q, "how": how, "limit": 5, "window": {"preset": "all"}})], search=FakeEngine())
    for rid, r in L.results(t).items():
        for it in (r.get("sheet") or {}).get("items") or []:
            print(q, "|", it.get("ref"), "|", it.get("title"), "|", it.get("channel"), it.get("when"), "|", it.get("why_matched"))
        print(" left_out", (r.get("sheet") or {}).get("left_out"), r.get("is_error"))
