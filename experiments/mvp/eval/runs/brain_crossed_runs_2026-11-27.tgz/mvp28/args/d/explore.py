import json, alib as L
t = L.turn("show me what I saved", [("items", {"window": {"preset": "all"}, "scope": {"how": "saved"}, "order": "newest", "limit": 5}),
                                     ("items", {"window": {"preset": "all"}, "scope": {"how": "opened"}, "order": "most_opened", "limit": 5}),
                                     ("breakdown", {"by": "channel", "window": {"preset": "lately"}, "scope": {}, "compare": "none"})])
for rid, r in L.results(t).items():
    print(rid, json.dumps(r, ensure_ascii=False)[:3000])
    print()
