"""Gate: values mode of the tip (8b9440e) and of this tree on every saved form of the seven half A runs. On the four
runs4 runs (made with the tip's checker) against their saved live verdicts; on run2, runA, runB (older builds) the tree
against the tip's replay. Prints every differing sentence."""
import sys
import lib28 as L


def sig(v):
    return [(o.where, o.index, o.kept, list(o.reasons)) for o in v.outcomes], v.repair, \
        [(i["ref"], i["kept"], list(i["reasons"])) for i in v.items]


def main():
    tot = {}
    for run in L.SEVEN:
        live = run in ("base1", "base2", "arm1", "arm2")
        for name, mod in (("tip", L.VT), ("tree", L.V)):
            if name == "tip" and not live:
                continue
            n = bad = 0
            for rec, t, results in L.inputs(run):
                for fi, f in enumerate(rec.get("forms") or []):
                    v = mod.check_answer(f, results, mod.Turn.of(t), mode="values")
                    if live:
                        sv = rec["verdicts"][fi]
                        want = ([(o["where"], o["index"], o["kept"], list(o["reasons"])) for o in sv["outcomes"]],
                                sv["repair"])
                        got = sig(v)[:2]
                    else:
                        vt = L.VT.check_answer(f, results, L.VT.Turn.of(t), mode="values")
                        want, got = sig(vt), sig(v)
                    n += 1
                    if got != want:
                        bad += 1
                        print("DIFF", name, run, rec["key"], fi)
                        for a, b in zip(got[0], want[0]):
                            if a != b:
                                print("    got", a, "want", b)
                        if got[1:] != want[1:]:
                            print("    repair/items got", got[1:], "want", want[1:])
            tot[(name, run)] = (n, bad)
    for (name, run), (n, bad) in tot.items():
        ref = "saved live verdicts" if run in ("base1", "base2", "arm1", "arm2") else "the tip's replay"
        print(f"{name:5s} {run:6s}: {n} forms, {bad} differ from {ref}")


if __name__ == "__main__":
    main()
