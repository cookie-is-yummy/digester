import json, alib as L
from mvp.tests.fakes.fake_brain import FakeEngine
def show(t):
    for rid, r in L.results(t).items():
        sh = r.get("sheet") or {}
        print(rid, r.get("tool"), "totals", sh.get("totals"), "err", r.get("is_error"), json.dumps(r)[:300] if r.get("is_error") else "")
        for it in sh.get("items") or []:
            print("   ", it.get("ref"), "|", it.get("title"), "|", it.get("channel"), it.get("when"), it.get("how"), "|", it.get("why_matched"))
    p = L.V._Pool(L.V.Ledger(L.results(t)), t.message)
    print("   pages", p.pages, {k: p.held.get(float(k)) for k in (2,3,4,5,10)})
t = L.turn("my sourdough saves", [("search", {"query": "sourdough", "how": "saved", "limit": 5, "window": {"preset": "all"}})], search=FakeEngine()); show(t)
t = L.turn("cooking", [("items", {"limit": 10, "order": "most_opened", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["cooking"]}})]); show(t)
t = L.turn("cooking", [("items", {"limit": 5, "order": "most_opened", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["cooking"]}}), ("breakdown", {"by": "theme", "window": {"preset": "lately"}, "scope": {}, "compare": "none"})]); show(t)
t = L.turn("gaming daily", [("items", {"limit": 5, "order": "newest", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["Gaming Daily"]}})]); show(t)
