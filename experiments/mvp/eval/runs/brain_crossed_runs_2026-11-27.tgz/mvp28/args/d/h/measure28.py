"""Values mode of this tree's variants against the tip's values mode, on every saved form of the seven half A runs:
every sentence whose verdict changed (run, message, form, place, before -> after, text). Live-run truth is read by hand
(checks/marks28.txt); run2, runA, runB carry the hand recount's label where it has one.
usage: python3 -B measure28.py tree tree-item_count ..."""
import sys
import lib28 as L
import variants28 as variants


def main():
    for name in sys.argv[1:] or ["tree"]:
        mode = variants.mode(name)
        ch = 0
        refused = {"tip": 0, name: 0}
        print(f"== {name} against the tip")
        for run in L.SEVEN:
            for rec, t, results in L.inputs(run):
                for fi, f in enumerate(rec.get("forms") or []):
                    a = L.VT.check_answer(f, results, L.VT.Turn.of(t), mode="values")
                    b = L.V.check_answer(f, results, L.V.Turn.of(t), mode=mode)
                    for oa, ob in zip(a.outcomes, b.outcomes):
                        refused["tip"] += not oa.kept
                        refused[name] += not ob.kept
                        if oa.reasons != ob.reasons:
                            ch += 1
                            tr, _lab = L.truth_of(run, rec["key"], fi, ob.where, ob.index)
                            print(f"  {run} {rec['key']} f{fi} {ob.where}{ob.index} label={tr} {oa.reasons} -> "
                                  f"{ob.reasons}\n      {ob.text[:230]}")
        print(f"  {ch} sentences changed; sentences refused (every form): tip {refused['tip']}, {name} {refused[name]}")


if __name__ == "__main__":
    main()
