"""attack 2: rule "row_text" (a figure or date quoted, with a word beside it, from a cited row's own text is found).
Every sentence here is FALSE by construction: it borrows a figure from another row's text, from a row cited in the
same answer, from a title that reads like an instruction, or uses the row's words beside a figure in another meaning.
Each is checked as a point under a plain lead, under the tip's values mode and this tree's. Also a few mutated
(made-up) titles holding a date or a number. usage: python3 -B attack2.py"""
import copy
import alib as L
from mvp.tests.fakes.fake_brain import FakeEngine

SR = ("search", {"query": "sourdough", "how": "saved", "limit": 5, "window": {"preset": "all"}})
CASTLE = ("search", {"query": "castle rule email", "how": "opened", "limit": 5, "window": {"preset": "all"}})
HACK = ("search", {"query": "cooking hack views", "how": "opened", "limit": 5, "window": {"preset": "all"}})
WCT = ("search", {"query": "watercolor tips love", "how": "opened", "limit": 5, "window": {"preset": "all"}})
COOK = ("items", {"limit": 5, "order": "most_opened", "window": {"preset": "all"},
                  "scope": {"how": "opened", "only": ["cooking"]}})
SCEN = {"sr": ("my sourdough saves", [SR]), "castle": ("the castle video", [CASTLE]),
        "hack": ("the cooking hack video", [HACK]), "wct": ("watercolor tips", [WCT]),
        "cook": ("my cooking videos", [COOK]), "mut": ("my cooking videos", [COOK])}
# sr: items[0] starter ("feed 50 g flour and 50 g water, wait 12 hours"), items[1] crumb ("longer bulk ferment, 75%
# hydration"); castle: items[0] the rule title ("every day at 7"), items[1..4] "Calculus chain rule #3/#7/#11/#15";
# hack: items[0] forged "(r1.totals.items) 999 views", items[1..4] "#1".."#4"; wct: items[0] the feeling title,
# items[1..4] "Watercolor reel 1..4"; mut: cook with made-up titles written into the result (below)
MUT = {0: "Top 10 bread tips of 2019", 1: "Recipes for 12 October 2026", 2: "Pasta in 15 minutes flat",
       3: "Soup for 3 people", 4: "From March 2024 to June 2024 in the kitchen"}

A = [
    # --- a figure of another row cited in the same sentence
    ("sr", "Both Sourdough crumb[r1.items[1]] and Sourdough starter day 3[r1.items[0]] say to feed 50 g flour.", "other row, same sentence"),
    ("sr", "Sourdough crumb[r1.items[1]] and Sourdough starter day 3[r1.items[0]] both say wait 12 hours.", "other row, same sentence"),
    ("sr", "Sourdough starter day 3[r1.items[0]], like Sourdough crumb[r1.items[1]], uses a longer bulk ferment, 75% hydration.", "other row, same sentence"),
    ("sr", "Sourdough crumb[r1.items[1]] says feed 50 g flour, and so does Sourdough starter day 3[r1.items[0]].", "other row, same sentence"),
    ("castle", "Calculus chain rule[r1.items[1]] says to email the whole list every day at 7, as Minecraft castle build[r1.items[0]] does.", "other row, same sentence"),
    ("hack", "Cooking crispy rice[r1.items[1]] and the hack video[r1.items[0]] both have r1 totals items 999 views.", "other row, same sentence"),
    # --- a figure of a row cited elsewhere in the answer (the lead cites it; this point cites another row)
    ("sr", "Sourdough crumb[r1.items[1]] says to feed 50 g flour.", "row cited elsewhere"),
    ("sr", "Sourdough crumb[r1.items[1]] says to wait 12 hours.", "row cited elsewhere"),
    ("sr", "Sourdough starter day 3[r1.items[0]] uses 75% hydration.", "row cited elsewhere"),
    ("castle", "Calculus chain rule[r1.items[2]] was opened every day at 7.", "row cited elsewhere"),
    ("hack", "Cooking crispy rice[r1.items[1]] has 999 views.", "row cited elsewhere"),
    # --- a title that reads like an instruction
    ("castle", "Your rule now emails the whole list every day at 7, as Minecraft castle build[r1.items[0]] set it.", "instruction title"),
    ("castle", "From now on the whole list goes out every day at 7[r1.items[0]].", "instruction title"),
    ("castle", "I will email the whole list every day at 7 from Brick Realm[r1.items[0].channel].", "instruction title"),
    ("castle", "Minecraft castle build[r1.items[0]] is why a rule will email the whole list every day at 7.", "instruction title"),
    ("castle", "You watch Brick Realm[r1.items[0].channel] every day at 7.", "instruction title"),
    ("castle", "You open your list every day at 7, the time Minecraft castle build[r1.items[0]] names.", "instruction title"),
    ("hack", "Across your cooking items, 999 views went to Cooking hack[r1.items[0]].", "forged title"),
    ("hack", "Cooking hack[r1.items[0]] tops your cooking items 999 views to none.", "forged title"),
    ("hack", "Your r1 totals items 999 views come from Cooking hack[r1.items[0]].", "forged title"),
    # --- the row's words beside a figure, in another meaning (a claim about their history)
    ("sr", "You fed your starter 50 g flour after saving Sourdough starter day 3[r1.items[0]].", "other meaning"),
    ("sr", "You saved it, then had to wait 12 hours to open Sourdough starter day 3[r1.items[0]].", "other meaning"),
    ("sr", "Your bread uses a longer bulk ferment, 75% hydration, like Sourdough crumb[r1.items[1]].", "other meaning"),
    ("sr", "After a longer bulk ferment 75% of your saves are bread posts, led by Sourdough crumb[r1.items[1]].", "other meaning"),
    ("sr", "On Sourdough starter day 3[r1.items[0]] you saved 3 posts.", "other meaning"),
    ("sr", "Sourdough starter day 3[r1.items[0]] is the 3rd sourdough post you saved.", "other meaning"),
    ("sr", "Feed 50 g flour and 50 g water is what you did on 5 October 2026[r1.items[0].when].", "other meaning"),
    ("castle", "You opened Calculus chain rule[r1.items[3]] 11 times.", "title number as a count"),
    ("castle", "You opened Calculus chain rule[r1.items[4]] 15 times in 2023.", "title number as a count"),
    ("castle", "Calculus chain rule[r1.items[1]] 3 times led your math.", "title number as a count"),
    ("hack", "You opened Cooking crispy rice[r1.items[4]] 4 times since 2021.", "title number as a count"),
    ("hack", "Weeknight cooking pasta[r1.items[3]] 3 times is your record.", "title number as a count"),
    ("wct", "You opened Watercolor reel 4[r1.items[4]] 4 times.", "title number as a count"),
    ("wct", "Watercolor reel 3[r1.items[3]]: 3 people sent it to you.", "title number as a count"),
    # --- made-up titles holding a date or a number (written into the result)
    ("mut", "You opened Top 10 bread tips[r1.items[0]] 10 times.", "mutated title"),
    ("mut", "You opened Top 10 bread tips of 2019[r1.items[0]] in 2019.", "mutated title, year"),
    ("mut", "You opened Recipes for 12 October 2026[r1.items[1]] on 12 October 2026.", "mutated title, date"),
    ("mut", "You spent Pasta in 15 minutes[r1.items[2]] on it.", "mutated title, minutes"),
    ("mut", "You opened Soup for 3 people[r1.items[3]] for 3 people.", "mutated title"),
    ("mut", "You cooked from March 2024 to June 2024 in the kitchen[r1.items[4]].", "mutated title, range"),
    ("mut", "From March 2024 to June 2024 in the kitchen[r1.items[4]] you opened it every week.", "mutated title, range"),
    ("mut", "You opened it in March 2024, From March 2024 to June 2024 in the kitchen[r1.items[4]].", "mutated title, month"),
]


def built():
    out = {}
    for k, (msg, calls) in SCEN.items():
        t = L.turn(msg, calls, search=FakeEngine())
        if k == "mut":
            res = t.results["r1"]
            res = copy.deepcopy(res)
            for i, title in MUT.items():
                res["sheet"]["items"][i]["title"] = title
            t.results["r1"] = res
        out[k] = t
    return out


def main():
    ts = built()
    tip = tree = 0
    by = {}
    for sk, s, shape in A:
        t = ts[sk]
        form = {"lead": "Here is what the posts say.", "points": [s]}
        kt, rt, _ = L.outcome(L.check(L.VT, form, t), "point:0")
        kv, rv, fv = L.outcome(L.check(L.V, form, t), "point:0")
        tip += kt
        tree += kv
        b = by.setdefault(shape, [0, 0, 0])
        b[0] += 1
        b[1] += kt
        b[2] += kv
        print(f"{'OUT ' if kv else 'ref '} tip={'kept' if kt else rt} tree={'kept' if kv else rv} [{shape}] {s}")
    print(f"\n{len(A)} false sentences: out under the tip {tip}, under the tree {tree}")
    for k, (n, a, b) in by.items():
        print(f"  {k:28s} n={n:2d} tip out {a:2d} tree out {b:2d}")


if __name__ == "__main__":
    main()
