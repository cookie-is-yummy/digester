"""Task 2: hand-written truthful rewords of each sentence the item-count rules refuse, replayed on the saved turn (the
form's other fields as saved). Each must be kept; the refused original is shown beside it."""
import copy
import lib28 as L

CASES = [
    # run, key, form index, {field: new value}, what the reword does
    ("base1", "N044.0", 0, {"items": [{"ref": f"r1.items[{k}]", "note": None} for k in range(5)]},
     "the same lead, all five rows sent as cards"),
    ("base1", "N044.0", 0, {"lead": "These are the newest of the 72[r1.totals.items] food and cooking items you opened, "
                                    "newest first."}, "no count of the shown rows"),
    ("base1", "N044.1", 0, {"items": [{"ref": f"r1.items[{k}]", "note": None} for k in range(5)]},
     "the same lead, the five rows sent as cards"),
    ("base2", "N044.0", 0, {"lead": "Across all your history, here are 3 of the 72[r1.totals.items] food and cooking "
                                    "items you opened."}, "the count of the 3 cards sent"),
    ("arm1", "N044.0", 0, {"lead": "These 4 are from your 72[r2.totals.items] food and cooking items, newest first, all "
                                   "opened."}, "the count of the 4 cards sent"),
    ("arm1", "N044.0", 0, {"lead": "These four are from your 72[r2.totals.items] food and cooking items, newest first."},
     "the same as a number word"),
    ("run2", "N044.0", 1, {"lead": "Here are 4 of the 72[r1.totals.items] food and cooking items you opened."},
     "the count of the 4 cards sent"),
    ("run2", "N044.0", 1, {"lead": "Here are 5[r1.items.count] of the 72[r1.totals.items] food and cooking items you "
                                   "opened.", "items": [{"ref": f"r1.items[{k}]", "note": None} for k in range(5)]},
     "the same count, all five rows as cards"),
    # guards: a true total of the set with fewer cards, and a count of something else, are not compared
    ("arm1", "N044.0", 0, {"lead": "You opened 72[r2.totals.items] food and cooking items in all; these are the newest."},
     "a true total with 4 cards"),
    ("base2", "N044.0", 0, {"lead": "Across all your history you opened 72 food and cooking items; here are the newest."},
     "an unmarked true total with 3 cards"),
]


def main():
    bad = 0
    for run, key, fi, change, why in CASES:
        rec, t, res = next(x for x in L.inputs(run) if x[0]["key"] == key)
        f0 = rec["forms"][fi]
        f = copy.deepcopy(f0)
        f.update(change)
        v0 = L.V.check_answer(f0, res, L.V.Turn.of(t), mode="values")
        v = L.V.check_answer(f, res, L.V.Turn.of(t), mode="values")
        lead0 = [o.reasons for o in v0.outcomes if o.where == "lead"]
        lead = [o.reasons for o in v.outcomes if o.where == "lead"]
        ok = all(not r for r in lead)
        bad += not ok
        print(f"{'KEPT ' if ok else 'REFUSED'} {run} {key} f{fi}: {why}\n      original lead {lead0} | reword {lead}"
              f" | {f['lead'][:110]}")
    print(f"{len(CASES)} rewords, {bad} refused")


if __name__ == "__main__":
    main()
