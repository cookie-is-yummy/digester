"""Every sentence the tip's values mode or this tree's refuses, on every saved form of the seven runs (replay), with
the hand recount's label where there is one; and per run the rewords asked on the first form."""
import lib28 as L


def main():
    rew = {}
    for run in L.SEVEN:
        rt = rv = 0
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                a = L.VT.check_answer(f, results, L.VT.Turn.of(t), mode="values")
                b = L.V.check_answer(f, results, L.V.Turn.of(t), mode="values")
                if fi == 0:
                    rt += a.repair
                    rv += b.repair
                for oa, ob in zip(a.outcomes, b.outcomes):
                    if oa.kept and ob.kept:
                        continue
                    tr, _l = L.truth_of(run, rec["key"], fi, ob.where, ob.index)
                    print(f"{run:5s} {rec['key']} f{fi} {ob.where}{ob.index} label={tr} tip={oa.reasons} "
                          f"tree={ob.reasons}\n      {ob.text[:250]}")
        rew[run] = (rt, rv)
    print("rewords asked on the first form, tip -> tree:", rew)


if __name__ == "__main__":
    main()
