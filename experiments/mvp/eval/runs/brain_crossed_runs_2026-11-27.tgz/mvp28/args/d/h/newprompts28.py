"""mvp28 merge: the merged checker's values mode on the limits builder's four saved sample runs (made on the limits
tree, i.e. the tip's checker, live values mode; prompts v3b fresh, v3c first, v3c final, v4c). Every sentence whose
verdict differs from the saved live verdict, with the rule of this round that changes it (one rule off at a time),
plus the reword flag and card verdicts. No hand truth exists for these runs; marks are read by hand afterwards.
No model call."""
import os
import lib28 as L

V, VT = L.V, L.VT
NEW = sorted(V.VALUES_RULES - VT.VALUES_RULES)
RUNS = {"lim_v3b": "v3b", "lim_v3c1": "v3c", "lim_v3c2": "v3c2", "lim_v4c": "v4c"}
for k, d in RUNS.items():
    L.RUNS[k] = os.path.join(L.S, "mvp28", "limits", "runs", d)


def key_of(o):
    return (o.kept, tuple(o.reasons))


def main():
    for run in RUNS:
        n = nd = rep = 0
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                if not rec.get("verdicts") or fi >= len(rec["verdicts"]):
                    continue
                n += 1
                sv = rec["verdicts"][fi]
                saved = {(o["where"], o["index"]): (o["kept"], tuple(o["reasons"])) for o in sv["outcomes"]}
                vt = VT.check_answer(f, results, VT.Turn.of(t), mode="values")
                vm = V.check_answer(f, results, V.Turn.of(t), mode="values")
                same_tip = [key_of(o) for o in vt.outcomes] == [saved.get((o.where, o.index)) for o in vt.outcomes]
                if not same_tip:
                    print(f"  GATE {run} {rec['key']} f{fi}: tip replay differs from the saved live verdict")
                if vm.repair != sv["repair"]:
                    rep += 1
                for pos, om in enumerate(vm.outcomes):
                    ref = saved.get((om.where, om.index))
                    if key_of(om) == ref:
                        continue
                    nd += 1
                    why = []
                    for r in NEW:
                        vo = V.check_answer(f, results, V.Turn.of(t), mode=V.values_mode(rules=V.VALUES_RULES - {r}))
                        if key_of(vo.outcomes[pos]) == ref:
                            why.append(r)
                    print(f"{run} {rec['key']} f{fi} {om.where}{om.index}: live {ref} -> merge {key_of(om)} "
                          f"by {','.join(why) or '?'} (reword live {sv['repair']} -> merge {vm.repair}; cards kept "
                          f"{sum(1 for i in vm.items if i['kept'])} of {len(vm.items)})\n      \"{om.text[:220]}\"")
        print(f"== {run}: {n} forms, {nd} sentences differ from the saved live verdict, {rep} reword flags differ")


if __name__ == "__main__":
    main()
