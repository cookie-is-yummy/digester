"""Task 4 (N024.1): would a figure in the model's own tool arguments count as found? On every saved form of the seven
runs: each sentence the tree's values mode refuses on an unfound figure, and whether the figure stands in the turn's
call arguments (a number, or the length of a list); and per turn, the figures the arguments would add that no cell
holds (what a made-up value could hide behind)."""
import json, re
import lib28 as L
V = L.V


def arg_nums(rec):
    out = set()

    def walk(o):
        if isinstance(o, bool) or o is None:
            return
        if isinstance(o, (int, float)):
            out.add(float(o))
        elif isinstance(o, str):
            for m in re.finditer(r"(?<![\w.])\d+(?:\.\d+)?", o):
                out.add(float(m.group(0)))
        elif isinstance(o, dict):
            for v in o.values():
                walk(v)
        elif isinstance(o, list):
            if o:
                out.add(float(len(o)))
            for v in o:
                walk(v)
    for c in rec["calls"]:
        walk(c.get("args"))
    return out


def main():
    hits, added, turns = [], 0, 0
    for run in L.SEVEN:
        for rec, t, results in L.inputs(run):
            an = arg_nums(rec)
            pool = V._Pool(V.Ledger(results), rec["message"])
            extra = {x for x in an if x == int(x) and 0 < x < 1000 and x not in pool.cell_nums}
            turns += 1
            added += len(extra)
            for fi, f in enumerate(rec.get("forms") or []):
                v = V.check_answer(f, results, V.Turn.of(t), mode="values")
                for o in v.outcomes:
                    for d in o.details:
                        m = re.match(r"'([\d.,]+|[a-z]+)' has no marker", d)
                        if not m:
                            continue
                        w = m.group(1)
                        n = float(w.replace(",", "")) if w[0].isdigit() else V._V_NUM_WORDS.get(w)
                        if n is not None and n in an:
                            hits.append((run, rec["key"], fi, o.where, o.index, w, o.text))
    print(f"{turns} turns; figures the arguments hold that no cell holds: {added} in all")
    print(f"refused sentences whose unfound figure stands in the arguments: {len(hits)}")
    for h in hits:
        print("  ", *h[:6], "|", h[6][:200])


if __name__ == "__main__":
    main()
