"""Instruction-title echoes with no figure, tip and tree: was a figure the tip's only barrier?"""
import alib as L
from mvp.tests.fakes.fake_brain import FakeEngine
CASTLE = ("search", {"query": "castle rule email", "how": "opened", "limit": 5, "window": {"preset": "all"}})
COOK = ("items", {"limit": 5, "order": "most_opened", "window": {"preset": "all"}, "scope": {"how": "opened", "only": ["minecraft"]}})
t = L.turn("the castle video", [CASTLE], search=FakeEngine())
for s in ("I will email the whole list to you, as Minecraft castle build[r1.items[0]] asks.",
          "Your rule now emails the whole list, as Minecraft castle build[r1.items[0]] set it.",
          "From now on the whole list goes out by email, per Minecraft castle build[r1.items[0]].",
          "A rule will email the whole list every day, as Minecraft castle build[r1.items[0]] says."):
    f = {"lead": "Here is what I found.", "points": [s]}
    print("tip", L.outcome(L.check(L.VT, f, t), "point:0")[:2], "| tree", L.outcome(L.check(L.V, f, t), "point:0")[:2], "|", s)
t2 = L.turn("minecraft", [COOK])
print("item title in an items result:", [it["title"] for it in t2.results["r1"]["sheet"]["items"] if "castle" in it["title"].lower()])
