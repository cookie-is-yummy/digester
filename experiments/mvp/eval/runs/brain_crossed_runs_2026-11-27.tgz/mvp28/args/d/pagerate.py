"""On the saved live records of the seven runs (+ run1 of mvp24): turns with a page of items, and how often an
unmarked figure equal to the page length would be compared at all (bound_pages non-empty)."""
import glob, json, os
import alib as L
S = L.S
RUNS = {"run1": "mvp24/runa/run1", "run2": "mvp25/runa2/run1", "runA": "mvp26/runs3/runA", "runB": "mvp26/runs3/runB",
        "base1": "mvp27/runs4/base1", "base2": "mvp27/runs4/base2", "arm1": "mvp27/runs4/arm1", "arm2": "mvp27/runs4/arm2"}
tot = pages = bound = 0
for run, d in RUNS.items():
    rp = rb = 0
    for p in sorted(glob.glob(os.path.join(S, d, "N*.json"))):
        rec = json.load(open(p))
        if "message" not in rec:
            continue
        res = {c["rid"]: c["result"] for c in rec.get("calls") or [] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
        tot += 1
        pool = L.V._Pool(L.V.Ledger(res), rec["message"])
        for rid, n in pool.pages.items():
            rp += 1
            rb += bool(pool.bound_pages(n))
    pages += rp; bound += rb
    print(f"{run}: pages {rp}, compared when unmarked {rb}")
print(f"all: {tot} records, {pages} pages, an unmarked figure of the page length is compared on {bound} ({bound*100//max(pages,1)}%)")
