"""Task 4: how much the found-count rules (cited_rows, row_group) widen what is found. On every saved turn of the
seven runs with a list row cited by a kept first-form sentence, the made-up sentence "N of them came in that window,
like <row>[ref]." for N = 2..10 (digits) is checked under the tip and under this tree's values mode (rules on, and each
one off). Counts the N that the tip refuses and the tree finds. Also probes27's pool numbers, tip against tree."""
import re
import lib28 as L
import variants28 as variants
V, VT = L.V, L.VT


def main():
    modes = [("tree", "values"), ("tree-row_group", variants.mode("tree-row_group")),
             ("tree-cited_rows", variants.mode("tree-cited_rows"))]
    tot = {m: 0 for m, _ in modes}
    n_probe = tip_ref = 0
    seen = set()
    for run in L.SEVEN:
        for rec, t, results in L.inputs(run):
            forms = rec.get("forms") or []
            if not forms:
                continue
            v = VT.check_answer(forms[0], results, VT.Turn.of(t), mode="values")
            for o in v.outcomes:
                if not o.kept:
                    continue
                for m in re.finditer(r"\[(r\d+\.(?:items|channels|themes|areas)\[\d+\])\]", o.text):
                    ref = m.group(1)
                    if (run, rec["key"], ref) in seen:
                        continue
                    seen.add((run, rec["key"], ref))
                    for n in range(2, 11):
                        s = f"{n} of them came in that window, like this one[{ref}]."
                        a = VT.check_sentence_values(s, VT.Ledger(results), VT.Turn.of(t), "point", 0)
                        n_probe += 1
                        if a.kept:
                            continue
                        tip_ref += 1
                        for name, md in modes:
                            b = V.check_sentence_values(s, V.Ledger(results), V.Turn.of(t), "point", 0, md)
                            tot[name] += b.kept
    print(f"made-up counts beside a cited row: {n_probe} probes, {tip_ref} refused by the tip; now found:",
          ", ".join(f"{k} {v}" for k, v in tot.items()))
    # pool numbers (probes27): the tree's pool holds the same numbers as the tip's
    import json
    b = json.load(open(L.S + "/mvp26/merge/results_merge.json"))
    same = 0
    for t in b:
        rb = {c["rid"]: c["result"] for c in t["calls"] if c.get("rid") and c.get("result") and
              not c["result"].get("is_error")}
        p, q = V._Pool(V.Ledger(rb), t["message"]), VT._Pool(VT.Ledger(rb), t["message"])
        same += (p.nums, p.cell_nums, p.win_units, p.day_nums, p.dates) == (q.nums, q.cell_nums, q.win_units,
                                                                            q.day_nums, q.dates)
    print(f"probe turns of mvp26/merge: {same} of {len(b)} pools hold the same numbers, dates and units as the tip's")


if __name__ == "__main__":
    main()
