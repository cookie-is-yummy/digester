"""`python -m mvp.eval_brain audit --run <dir>` in process, with this tree's eval_claims or the tip's (argv[1])."""
import os, runpy, sys
import lib28 as L
which, d = sys.argv[1], sys.argv[2]
if which == "tip":
    import mvp
    ec = L._load(os.path.join(L.HERE, "base", "eval_claims_tip.py"), "mvp.eval_claims", pkg="mvp")
    mvp.eval_claims = ec
sys.argv = ["eval_brain", "audit", "--run", d]
runpy.run_module("mvp.eval_brain", run_name="__main__")
