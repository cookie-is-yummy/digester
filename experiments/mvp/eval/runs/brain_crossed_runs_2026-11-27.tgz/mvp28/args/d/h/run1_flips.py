"""Out of the builders' seven: mvp24 run1 (hand truth mvp24/recounta). Values mode, tip against tree, every form."""
import os, collections
os.environ.setdefault("VALUES_TREE", "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/merge_tree")
import lib28 as L
a = {(r["key"], r["fi"], r["where"], r["index"]): r for r in L.rows("run1", L.VT, "values")}
b = {(r["key"], r["fi"], r["where"], r["index"]): r for r in L.rows("run1", L.V, "values")}
c = collections.Counter()
for k in sorted(a):
    x, y = a[k], b[k]
    if x["kept"] != y["kept"]:
        c[(x["truth"], "kept->refused" if x["kept"] else "refused->kept")] += 1
        print(k, "truth", x["truth"], "tip", "kept" if x["kept"] else x["reasons"], "-> tree", "kept" if y["kept"] else y["reasons"], "|", x["text"][:170])
print("sentences", len(a), "flips", dict(c))
