"""mvp27 prep: the attack sets under values mode, base (the tip 8b9440e) against this tree's variants: the made-up class
(labels from mvp26/values/classes.json with final_split's hand overrides), the misattached class, policy, and true
sentences refused. usage: python3 -B attack27.py variant [variant ...]"""
import json, sys
from collections import Counter, defaultdict
import lib28 as L
import variants28 as variants
sys.path.insert(0, L.S + "/mvp26/values")
HAND = {("planted:attack", "attack_O06"): "MADE-UP", ("attack2", "a31"): "MADE-UP", ("attack2", "m03"): "MADE-UP",
        ("attack2", "n08"): "MADE-UP", ("planted:audit", "audit_F37"): "MADE-UP"}
CL = {(r["set"], r["id"]): HAND.get((r["set"], r["id"]), r["class"])
      for r in json.load(open(L.S + "/mvp26/values/classes.json"))}


def rows(mod, mode):
    out = []
    out += L.run_planted(mod, mode)
    out += L.run_skeptic(mod, mode)
    out += L.run_rc(mod, mode)
    out += L.run_a2(mod, mode)
    out += L.run_check2(mod, mode)
    return out


def main():
    cks = [("base", L.VT, "values")] + [(n, L.V, variants.mode(n)) for n in sys.argv[1:]]
    allr = {}
    for name, mod, mode in cks:
        allr[name] = {(r["set"], r["id"]): r for r in rows(mod, mode)}
    print(f"{'class':14s} {'n':>4s} " + " ".join(f"{n:>22s}" for n, _m, _x in cks) + "   (out)")
    for cls in ("MADE-UP", "MISATTACHED", "POLICY"):
        keys = [k for k in allr["base"] if allr["base"][k]["truth"] == "F" and CL.get(k) == cls]
        print(f"{cls:14s} {len(keys):4d} " + " ".join(f"{sum(allr[n][k]['out'] for k in keys):22d}" for n, _m, _x in cks))
    tk = [k for k in allr["base"] if allr["base"][k]["truth"] == "T"]
    def t_ref(n, k):
        r = allr[n][k]
        return not r["kept"] if r["set"] not in ("attack2", "attacker2") else not (r["P"] and r["L"])
    print(f"{'TRUE refused':14s} {len(tk):4d} " + " ".join(f"{sum(t_ref(n, k) for k in tk):22d}" for n, _m, _x in cks))
    for n, _m, _x in cks[1:]:
        print(f"== {n} against base: cases whose outcome changed")
        for k in sorted(allr["base"]):
            a, b = allr["base"][k], allr[n][k]
            if (a["out"], a["kept"], a["reasons"]) != (b["out"], b["kept"], b["reasons"]):
                print(f"  {k[0]} {k[1]} truth={a['truth']} class={CL.get(k)} out {a['out']}->{b['out']} "
                      f"{a['reasons']} -> {b['reasons']}")
                print(f"      {(b.get('text') or '')[:220]}")


if __name__ == "__main__":
    main()
