"""Task 4 inventory: every sentence refused LIVE (saved verdicts, every form) in the seven runs by a safety code, and
every sentence refused live whose refusal goes away with cell_found and day_typed off (values replay, tip rules)."""
import json
import lib28 as L
SAFE = {"sensitive", "psych", "outcome", "language", "link", "watch_time", "motive_you"}
V = L.VT
NOCF = V.values_mode(rules=V.VALUES_RULES - {"cell_found", "day_typed"})
for run in L.SEVEN:
    for rec, t, results in L.inputs(run):
        for fi, f in enumerate(rec.get("forms") or []):
            sv = rec["verdicts"][fi]
            vt = V.Turn.of(t)
            for o in sv["outcomes"]:
                if o["kept"]:
                    continue
                rs = set(o["reasons"])
                tag = []
                if rs & SAFE:
                    tag.append("SAFETY:" + ",".join(sorted(rs & SAFE)))
                if run in ("base1", "base2", "arm1", "arm2") and rs & {"unfound_number", "unfound_date"}:
                    form = {"lead": o["text"]} if o["where"] == "lead" else {"lead": f.get("lead") or "",
                                                                             "points": [o["text"]]}
                    v2 = V.check_sentence_values(o["text"], V.Ledger(results), vt, o["where"], o["index"], NOCF)
                    if v2.kept:
                        tag.append("CELL_FOUND")
                if tag:
                    print(f"{run} {rec['key']} f{fi} {o['where']}{o['index']} {tag} {o['reasons']} | {o['details']}")
                    print("     ", o["text"])
