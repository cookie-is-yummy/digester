"""Where a figure stands in a turn's results: every path whose value is the number, or a string holding it."""
import json, re, sys
import lib28 as L


def walk(o, path, out, n):
    if isinstance(o, bool) or o is None:
        return
    if isinstance(o, (int, float)):
        if float(o) == n:
            out.append((path, o))
    elif isinstance(o, str):
        if re.search(r"(?<![\d.])" + re.escape(f"{n:g}") + r"(?![\d])", o):
            out.append((path, o[:140]))
    elif isinstance(o, dict):
        for k, v in o.items():
            walk(v, f"{path}.{k}", out, n)
    elif isinstance(o, list):
        if len(o) == n:
            out.append((path + "  (list length)", len(o)))
        for i, v in enumerate(o):
            walk(v, f"{path}[{i}]", out, n)


def main(run, key, n):
    for rec, t, results in L.inputs(run):
        if rec["key"] != key:
            continue
        print(run, key, rec["message"], "| screen:", json.dumps(rec.get("screen"))[:300])
        for c in rec["calls"]:
            print("  call", c.get("name"), c.get("rid"), json.dumps(c.get("args"))[:300])
        out = []
        for rid, env in results.items():
            walk(env, rid, out, float(n))
        for p, v in out:
            print("   ", p, "=", v)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3])
