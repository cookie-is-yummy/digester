"""Task 2: the cards the values check counts are the cards build() sends. On every saved form of the ten runs and
the planted forms with items: (a) verify._shown_cards (before the sentences are checked) against build()'s cards with
the final values verdict; (b) the tree's build against the tip's build with the same verdict (the refactor of
answer.py moves code only)."""
import os
import lib28 as L
from mvp.brain import answer as A, verify as V
At = L._load(os.path.join(L.HERE, "base", "answer_tip.py"), "mvp.brain.answer_tip")
At.V = V


def main():
    n = bad_a = bad_b = with_cards = asks = 0
    for run in L.RUNS:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                vt = V.Turn.of(t)
                led = V.Ledger(results)
                v = V.check_answer(f, led, vt, mode="values")
                if v.form_error:
                    continue
                n += 1
                fv = V.AnswerForm.model_validate(f)
                shown, _touched = V._shown_cards(led, fv, f, rows_shown=False)
                b = A.build(led, verdict=v, form=f, also=[v], mode="values")
                got = {}
                for c in b["cards"]:
                    rid = c["ref"].split(".", 1)[0]
                    got[rid] = got.get(rid, 0) + 1
                with_cards += bool(b["cards"])
                asks += bool(f.get("ask_back"))
                if got != shown or [c["ref"] for c in b["cards"]] != A.card_refs(led, v, f):
                    bad_a += 1
                    print("CARDS DIFFER", run, rec["key"], fi, shown, got)
                bt = At.build(led, verdict=v, form=f, also=[v], mode="values")
                if repr(bt) != repr(b):
                    bad_b += 1
                    print("BUILD DIFFERS", run, rec["key"], fi)
    print(f"{n} forms ({with_cards} with cards, {asks} with an ask-back): counted cards differ from build's on "
          f"{bad_a}; the tree's build differs from the tip's on {bad_b}")


if __name__ == "__main__":
    main()
