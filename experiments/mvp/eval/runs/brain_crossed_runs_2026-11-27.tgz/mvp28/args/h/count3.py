"""mvp28 args, step 3: per saved run, tool errors by kind, argument errors, form errors, strict on/off, and every call
today's code accepted although it is outside the schema sent (the tree's sent_problems)."""
import glob, json, os, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp28/args_tree/experiments")
from mvp import eval_brain as E
from mvp.brain import tools as TL
RUNS = {"run2": "mvp25/runa2/run1", "runA": "mvp26/runs3/runA", "runB": "mvp26/runs3/runB",
        "base1": "mvp27/runs4/base1", "base2": "mvp27/runs4/base2", "arm1": "mvp27/runs4/arm1", "arm2": "mvp27/runs4/arm2"}
for d in sorted(glob.glob(S + "/mvp28/speed/*/*/")):
    RUNS["speed/" + os.path.relpath(d, S + "/mvp28/speed").rstrip("/")] = os.path.relpath(d, S)
OFF = {"speed/full/strictoff", "speed/arms/A2_r1", "speed/arms/A2_r2"}
print(f"{'run':22s} strict msgs calls tool_err arg_err form_err keys_dropped  kinds")
tot = {"on": [0, 0, 0, 0, 0, 0], "off": [0, 0, 0, 0, 0, 0]}
accepted = []
for run, rel in RUNS.items():
    recs = [json.load(open(p)) for p in sorted(glob.glob(os.path.join(S, rel, "N*.json")))]
    recs = [r for r in recs if "calls" in r]
    sm = E.tool_args_summary(recs)
    side = "off" if run in OFF else "on"
    for i, v in enumerate((len(recs), sm["calls"], sm["tool_errors"], sm["arg_errors"], sm["form_errors"],
                           sm["form_keys_dropped"])):
        tot[side][i] += v
    print(f"{run:22s} {side:6s} {len(recs):4d} {sm['calls']:5d} {sm['tool_errors']:8d} {sm['arg_errors']:7d} "
          f"{sm['form_errors']:8d} {sm['form_keys_dropped']:12d}  {json.dumps(sm['tool_errors_by_kind'])}")
    for r in recs:
        for c in r["calls"]:
            if c["name"] in TL.REGISTRY and TL.REGISTRY[c["name"]].run and not (c.get("result") or {}).get("is_error"):
                bad = TL.sent_problems(c["name"], c["args"])
                if bad:
                    accepted.append((run, r["key"], c["name"], [b["said"] for b in bad], r["message"]))
for side in ("on", "off"):
    m, c, te, ae, fe, kd = tot[side]
    print(f"TOTAL strict {side}: messages {m}, calls {c}, tool errors {te} ({te / c:.3f} a call), argument errors {ae}, "
          f"form errors {fe}, form keys dropped {kd}")
print("\nCalls today's code accepted although outside the schema sent:", len(accepted))
for a in accepted:
    print(" ", a[0], a[1], a[2], a[3], "| message:", a[4])
