"""mvp28 args, step 2: every saved read call of the seven half A runs (and the speed key's runs) replayed through the
model's path of TREE, per conversation in message order with the turn's state as the live run built it (screen,
last window, carried topic, the fake search and learned backends). usage: replay.py TREE OUT.json"""
import glob, inspect, json, os, sys, tempfile
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E
H = E.Harness.scratch(base=tempfile.mkdtemp(prefix="args_replay_"))
from mvp.brain import loop as BL, tools as TL
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
SENT = "sent" in inspect.signature(TL.call).parameters
RUNS = {"run2": "mvp25/runa2/run1", "runA": "mvp26/runs3/runA", "runB": "mvp26/runs3/runB",
        "base1": "mvp27/runs4/base1", "base2": "mvp27/runs4/base2", "arm1": "mvp27/runs4/arm1", "arm2": "mvp27/runs4/arm2"}
for d in sorted(glob.glob(S + "/mvp28/speed/*/*/")):
    RUNS["speed/" + os.path.relpath(d, S + "/mvp28/speed").rstrip("/")] = os.path.relpath(d, S)
out = {}
meta = {}
for run, rel in RUNS.items():
    recs = [json.load(open(p)) for p in glob.glob(os.path.join(S, rel, "N*.json"))]
    recs = [r for r in recs if "message" in r and "calls" in r]
    recs.sort(key=lambda r: (r["id"], r["n"]))
    last, carry, conv = None, None, None
    for rec in recs:
        if rec["id"] != conv:
            conv, last, carry = rec["id"], None, None
        t = H.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True),
                   last_window=last, search=FakeEngine(), learned=fake_learned, carried_unlock=carry)
        meta[f"{run}/{rec['key']}"] = {"unlock": t.unlock, "rec_unlock": rec.get("unlock"),
                                       "carried_same": bool(rec.get("unlock_carried")) == bool(t.carried_only)}
        calls = []
        for k, c in enumerate(rec["calls"]):
            if (c.get("result") or {}).get("error") == BL.LIMIT:
                continue
            env = TL.call(t, c["name"], c["args"], sent=True) if SENT else TL.call(t, c["name"], c["args"])
            env = dict(env)
            env.pop("took_ms", None)
            out[f"{run}/{rec['key']}/{k}"] = {"name": c["name"], "args": c["args"],
                                              "env": json.dumps(env, sort_keys=True, ensure_ascii=False, default=str)}
            calls.append({"name": c["name"], "args": c["args"], "result": env})
        r2 = {"calls": calls}
        last = BL.last_window(t, r2) or last
        carry = BL.unlock_after(t, r2)
json.dump({"calls": out, "turns": meta}, open(sys.argv[2], "w"))
print(len(out), "calls;", sum(1 for m in meta.values() if m["unlock"] != m["rec_unlock"]), "turns whose unlock differs from the record")
