"""mvp28 args, step 1 and 2: bad arguments to every tool on the made-up library, through the path the model's calls
take (tools.call as loop.run_turn calls it, `sent` when the tree has it). usage: probe.py TREE OUT.json"""
import copy, inspect, json, os, sys, tempfile
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E
H = E.Harness.scratch(base=tempfile.mkdtemp(prefix="args_probe_"))
from mvp.brain import tools as TL
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
MSG = "what did I watch in October and in 2024, and how did 2023 compare?"
SENT = "sent" in inspect.signature(TL.call).parameters

W = {"preset": None, "same_as": None, "words": "in October"}
SC = {"exclude": [], "how": "opened", "length": "any", "only": [], "platforms": [], "weekday": None}
BASE = {
    "find": {"kinds": [], "names": ["Cooking"]},
    "breakdown": {"by": "theme", "compare": "previous", "order": "most", "scope": SC, "top": 8, "window": W},
    "timeline": {"scope": SC, "unit": "month", "window": dict(W, words="2024")},
    "changes": {"against": "previous", "level": "theme", "scope": SC, "window": dict(W, words="2024")},
    "compare": {"a": dict(W, words="2024"), "b": dict(W, words="2023"), "by": "none", "scope": SC},
    "first_last": {"scope": SC, "subject": "Cooking", "which": "first"},
    "items": {"limit": 5, "offset": 0, "order": "most_opened", "scope": SC, "window": W},
    "search": {"how": "saved", "limit": 5, "query": "sourdough bread", "window": None},
    "learned": {"scope": SC, "topic": "sourdough"},
    "propose_rule": {"output": "chat", "plan": "this_turn", "quote": "every Monday", "when": "{}"},
    "propose_send": {"quote": "email me this", "what": "this_answer"},
}


def setp(d, path, v):
    d = copy.deepcopy(d)
    cur = d
    for k in path[:-1]:
        cur = cur[k]
    if v is DEL:
        cur.pop(path[-1], None)
    else:
        cur[path[-1]] = v
    return d


DEL = object()


def cases(tool):
    b = BASE[tool]
    out = [("unknown key (top)", setp(b, ["made_up"], 1))]
    keys = sorted(b)
    if "scope" in b:
        out += [("unknown key in scope (platform)", setp(b, ["scope", "platform"], "youtube")),
                ("scope.how not in enum ('watched')", setp(b, ["scope", "how"], "watched")),
                ("scope.length made-up word ('medium')", setp(b, ["scope", "length"], "medium")),
                ("scope.platforms ['tiktok']", setp(b, ["scope", "platforms"], ["tiktok"])),
                ("scope.only a string, not a list", setp(b, ["scope", "only"], "Cooking")),
                ("scope.only made-up name", setp(b, ["scope", "only"], ["zzqx blorp"])),
                ("scope.only 6 names (over 5)", setp(b, ["scope", "only"], ["a"] * 6)),
                ("scope.weekday 9 (out of 0-6)", setp(b, ["scope", "weekday"], 9)),
                ("scope.weekday '3' (string)", setp(b, ["scope", "weekday"], "3")),
                ("scope.weekday 3.0 (float)", setp(b, ["scope", "weekday"], 3.0)),
                ("scope.weekday true (bool)", setp(b, ["scope", "weekday"], True)),
                ("scope missing", setp(b, ["scope"], DEL)),
                ("scope.how missing", setp(b, ["scope", "how"], DEL)),
                ("scope null", setp(b, ["scope"], None)),
                ("scope {} (all keys missing)", setp(b, ["scope"], {}))]
    for wk in [k for k in ("window", "a", "b") if k in b and b[k] is not None]:
        out += [(f"{wk}: unknown key ('word')", setp(b, [wk, "word"], "October")),
                (f"{wk}: made-up words", setp(b, [wk, "words"], "the blursday period")),
                (f"{wk}: preset not in enum ('yesterday')", setp(setp(b, [wk, "words"], None), [wk, "preset"], "yesterday")),
                (f"{wk}: same_as made-up rid ('r9')", setp(setp(b, [wk, "words"], None), [wk, "same_as"], "r9")),
                (f"{wk}: two of words/preset/same_as", setp(b, [wk, "preset"], "lately")),
                (f"{wk}: none set", setp(b, [wk, "words"], None)),
                (f"{wk}: words missing (others null)", setp(b, [wk, "words"], DEL)),
                (f"{wk}: only words given", setp(b, [wk], {"words": b[wk]["words"]})),
                (f"{wk}: a string, not an object", setp(b, [wk], b[wk]["words"])),
                (f"{wk}: missing", setp(b, [wk], DEL)),
                (f"{wk}: words a number (2024)", setp(b, [wk, "words"], 2024))]
    if tool == "search":
        out += [("window: unknown key ('word')", setp(b, ["window"], {"word": "October"})),
                ("window: made-up words", setp(b, ["window"], dict(W, words="the blursday period"))),
                ("window missing", setp(b, ["window"], DEL)),
                ("window a string", setp(b, ["window"], "in October"))]
    for k in keys:
        if k in ("scope", "window", "a", "b"):
            continue
        v = b[k]
        out.append((f"{k} missing", setp(b, [k], DEL)))
        out.append((f"{k} null", setp(b, [k], None)))
        if isinstance(v, str):
            out.append((f"{k} not in enum / made-up ('zzz')", setp(b, [k], "zzz")))
            out.append((f"{k} a number (5)", setp(b, [k], 5)))
            out.append((f"{k} a list", setp(b, [k], [v])))
        elif isinstance(v, bool):
            pass
        elif isinstance(v, int):
            out += [(f"{k} '{v}' (string)", setp(b, [k], str(v))), (f"{k} {v}.0 (float)", setp(b, [k], float(v))),
                    (f"{k} 2.5 (fraction)", setp(b, [k], 2.5)), (f"{k} true (bool)", setp(b, [k], True)),
                    (f"{k} 500 (out of range)", setp(b, [k], 500)), (f"{k} -1 (out of range)", setp(b, [k], -1))]
        elif isinstance(v, list):
            out += [(f"{k} a string, not a list", setp(b, [k], "Cooking")), (f"{k} []", setp(b, [k], [])),
                    (f"{k} [5] (number in list)", setp(b, [k], [5])), (f"{k} ['zzz'] (not in enum)", setp(b, [k], ["zzz"]))]
    out.append(("arguments a JSON string", json.dumps(b)))
    out.append(("arguments a list", [b]))
    out.append(("arguments not JSON", "{not json"))
    return out


def run(tool, args):
    t = H.turn(MSG, search=FakeEngine(), learned=fake_learned)
    env = TL.call(t, tool, args, sent=True) if SENT else TL.call(t, tool, args)
    env = copy.deepcopy(env)
    env.pop("took_ms", None)
    return env


rows = []
for tool in BASE:
    base = run(tool, BASE[tool])
    for what, args in cases(tool):
        try:
            env = run(tool, args)
        except Exception as e:  # noqa
            rows.append({"tool": tool, "bad": what, "args": args, "outcome": "crash", "detail": repr(e)[:300]})
            continue
        if env.get("is_error"):
            oc, detail = "refused", env.get("error")
        elif env == base:
            oc, detail = "same result as the valid call", None
        elif env.get("error") in ("no_match", "ambiguous"):
            oc, detail = "no-match result (options)", env.get("error")
        else:
            oc, detail = "different result", json.dumps({k: env.get(k) for k in ("meta",)}, default=str)[:300]
        rows.append({"tool": tool, "bad": what, "args": args, "outcome": oc, "detail": detail,
                     "base_is_error": bool(base.get("is_error")), "env": env})
json.dump(rows, open(sys.argv[2], "w"), indent=1, default=str)
print(len(rows), "cases;", {o: sum(1 for r in rows if r["outcome"] == o) for o in sorted({r["outcome"] for r in rows})})
