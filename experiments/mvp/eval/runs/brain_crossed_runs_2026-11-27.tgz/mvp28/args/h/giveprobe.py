"""mvp28 args, step 1: give_answer outside its schema, as the loop takes it (loop.clean_form, then
verify.AnswerForm as check_answer validates it). propose_rule / propose_send through tools.call."""
import copy, json, os, sys, tempfile
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E
H = E.Harness.scratch(base=tempfile.mkdtemp(prefix="args_ga_"))
from mvp.brain import loop as BL, verify as V, tools as TL
OK = {"understood": "their October", "lead": "You opened 12 videos.", "points": ["A point."], "items": [],
      "chart": None, "outside": [], "ask_back": None, "offers": [{"kind": "by_month", "ref": None, "window_words": None}],
      "setup": None, "corrects_previous": False, "hand_back": None}
def m(**kw):
    f = copy.deepcopy(OK)
    for k, v in kw.items():
        if v is DEL: f.pop(k)
        else: f[k] = v
    return f
DEL = object()
CASES = [("unknown key (top)", m(lead_fix=None)), ("unknown key in an offer", m(offers=[{"kind": "by_month", "ref": None, "window_words": None, "why": "x"}])),
         ("lead missing", m(lead=DEL)), ("every field but lead missing", {"lead": OK["lead"]}),
         ("points a string, not a list", m(points="A point.")), ("offer kind not in enum", m(offers=[{"kind": "share", "ref": None, "window_words": None}])),
         ("lead a number", m(lead=5)), ("corrects_previous 'true' (string)", m(corrects_previous="true")),
         ("corrects_previous 1 (int)", m(corrects_previous=1)), ("chart list not in enum", m(chart={"from": "r1", "list": "items", "value": "share"})),
         ("points [5] (number in list)", m(points=[5])), ("items a dict", m(items={"ref": "r1.items[0]"}))]
base = V.AnswerForm.model_validate(OK).model_dump()
for what, form in CASES:
    cleaned, dropped = BL.clean_form(form)
    try:
        got = V.AnswerForm.model_validate(cleaned).model_dump()
        oc = "accepted, same as the valid form" if got == base else "accepted, value coerced or defaulted"
        if dropped: oc += f" (keys dropped by clean_form: {dropped}; event form_keys_dropped)"
        det = ""
    except Exception as e:  # noqa
        oc, det = "form error -> one repair request", BL._form_error_text(cleaned)[:160]
    print(f"give_answer | {what} | {oc} | {det}")
t = H.turn("email me this every monday")
for name, args in (("propose_rule", {"quote": "x", "when": 5, "made_up": 1}), ("propose_send", {"what": "zzz"})):
    print(f"{name} | any arguments | {TL.call(t, name, args, sent=True) if 'sent' in TL.call.__code__.co_varnames else TL.call(t, name, args)}")
