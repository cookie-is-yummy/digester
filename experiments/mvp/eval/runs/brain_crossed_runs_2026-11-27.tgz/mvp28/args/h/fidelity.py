"""How many of the tip's replayed results equal the saved live result (took_ms left out): the replay's own check."""
import glob, json, os, sys
from collections import Counter
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp28/args/h")
rp = json.load(open(sys.argv[1]))["calls"]
RUNS = {"run2": "mvp25/runa2/run1", "runA": "mvp26/runs3/runA", "runB": "mvp26/runs3/runB",
        "base1": "mvp27/runs4/base1", "base2": "mvp27/runs4/base2", "arm1": "mvp27/runs4/arm1", "arm2": "mvp27/runs4/arm2"}
for d in sorted(glob.glob(S + "/mvp28/speed/*/*/")):
    RUNS["speed/" + os.path.relpath(d, S + "/mvp28/speed").rstrip("/")] = os.path.relpath(d, S)
same, n = Counter(), Counter()
for run, rel in RUNS.items():
    for p in glob.glob(os.path.join(S, rel, "N*.json")):
        rec = json.load(open(p))
        for k, c in enumerate(rec.get("calls") or []):
            key = f"{run}/{rec['key']}/{k}"
            if key not in rp:
                continue
            env = dict(c["result"]); env.pop("took_ms", None)
            n[run] += 1
            same[run] += json.dumps(env, sort_keys=True, ensure_ascii=False, default=str) == rp[key]["env"]
for run in RUNS:
    print(f"{run:22s} replay equals saved: {same[run]}/{n[run]}")
