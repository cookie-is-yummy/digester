"""The three strict-off calls with `order` left out: the message, the args, and whether order changes the result."""
import json, os, sys, tempfile
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, S + "/mvp28/merge_tree/experiments")
from mvp import eval_brain as E
H = E.Harness.scratch(base=tempfile.mkdtemp(prefix="args_o3_"))
from mvp.brain import tools as TL
for key in ("N055.0", "N057.0", "N109.0"):
    rec = json.load(open(f"{S}/mvp28/speed/full/strictoff/{key}.json"))
    c = rec["calls"][0]
    print(key, "|", rec["message"], "| screen plan:", bool((rec.get("screen") or {}).get("last_answer")))
    print("   args:", json.dumps(c["args"]))
    envs = {}
    for o in ("most", "least"):
        t = H.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        e = dict(TL.call(t, c["name"], dict(c["args"], order=o))); e.pop("took_ms", None)
        envs[o] = e
    m, l = (json.dumps(envs[x], sort_keys=True) for x in ("most", "least"))
    print("   most vs least identical:", m == l, "| differ only in meta.order:",
          m.replace('"order": "most"', '"order": "least"') == l)
    sh = envs["most"]["sheet"]
    print("   filters_said:", envs["most"]["meta"].get("filters_said"), "| base:", envs["most"]["meta"].get("base"),
          "| window:", envs["most"]["meta"].get("window_said"), "| totals:", json.dumps(sh.get("totals"))[:120])
    print("   later calls:", [(x["name"], x["args"].get("by"), (x["result"] or {}).get("is_error")) for x in rec["calls"][1:]],
          "| lead_source:", rec["lead_source"], "| seconds:", rec["seconds"])
