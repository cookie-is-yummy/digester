"""Quick scan (jsonschema, scratch only): every saved read call's args against the schema sent to the model."""
import glob, json, os, sys
from collections import Counter
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/args_tree/experiments")
import jsonschema
from mvp.brain import tools as TL
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
RUNS = {"run2": "mvp25/runa2/run1", "runA": "mvp26/runs3/runA", "runB": "mvp26/runs3/runB",
        "base1": "mvp27/runs4/base1", "base2": "mvp27/runs4/base2", "arm1": "mvp27/runs4/arm1", "arm2": "mvp27/runs4/arm2"}
for d in sorted(glob.glob(S + "/mvp28/speed/*/*/")):
    RUNS["speed/" + os.path.relpath(d, S + "/mvp28/speed").rstrip("/")] = os.path.relpath(d, S)
for run, rel in RUNS.items():
    n = bad = err = 0
    kinds = Counter()
    for p in sorted(glob.glob(os.path.join(S, rel, "N*.json"))):
        rec = json.load(open(p))
        for c in rec.get("calls") or []:
            n += 1
            if (c.get("result") or {}).get("is_error"):
                err += 1
                kinds[str(c["result"].get("error"))[:50]] += 1
            if c["name"] not in TL.REGISTRY or TL.REGISTRY[c["name"]].run is None:
                continue
            v = jsonschema.Draft202012Validator(TL.schema(c["name"]))
            es = list(v.iter_errors(c.get("args")))
            if es:
                bad += 1
                print(run, os.path.basename(p), c["name"], json.dumps(c["args"])[:200], "|", es[0].message[:100],
                      "| result error:", (c.get("result") or {}).get("error"))
    print(f"== {run}: calls {n}, outside schema {bad}, tool errors {err}: {dict(kinds)}")
