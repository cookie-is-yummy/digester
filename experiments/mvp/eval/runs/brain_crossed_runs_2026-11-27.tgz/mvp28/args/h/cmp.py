"""Compare two replays (tip vs tree): per run, calls that differ; a diff only in the friends note is said apart."""
import json, sys
from collections import Counter
a, b = json.load(open(sys.argv[1]))["calls"], json.load(open(sys.argv[2]))["calls"]
OLD, NEW = (sys.argv[3], sys.argv[4]) if len(sys.argv) > 4 else (None, None)
per, diffs = Counter(), Counter()
lines = []
for k in sorted(a):
    run = k.rsplit("/", 2)[0]
    per[run] += 1
    if a[k]["env"] == b[k]["env"]:
        continue
    if OLD and a[k]["env"].replace(OLD, NEW) == b[k]["env"]:
        diffs[(run, "friends note only")] += 1
        continue
    diffs[(run, "other")] += 1
    lines.append(f"{k} {a[k]['name']} {json.dumps(a[k]['args'])[:160]}\n   tip:  {a[k]['env'][:200]}\n   tree: {b[k]['env'][:300]}")
for run in per:
    print(f"{run:22s} calls {per[run]:4d}  differ: other {diffs[(run, 'other')]}, friends note only {diffs[(run, 'friends note only')]}")
print(f"TOTAL calls {sum(per.values())}, other diffs {sum(v for (r, kind), v in diffs.items() if kind == 'other')}, "
      f"friends-note-only diffs {sum(v for (r, kind), v in diffs.items() if kind != 'other')}")
print("\n".join(lines))
