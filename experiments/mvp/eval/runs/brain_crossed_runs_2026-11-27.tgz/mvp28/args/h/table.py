"""table.txt from the two probes (tip = brain-r28-local 9ff2fba, tree = brain-args-local) and the give_answer probe."""
import json, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/args"
tip = json.load(open(f"{S}/probe_tip.json")); tree = json.load(open(f"{S}/probe_tree.json"))
VALID = ("kinds []", "names ['zzz']", "query not in enum", "topic not in enum", "subject not in enum", "scope.only made-up name",
         "arguments a JSON string")


def today(r):
    b, oc = r["bad"], r["outcome"]
    if oc == "crash":
        return "CRASH"
    if oc == "refused":
        return "refused, readable: " + (r["detail"] or "")[:90]
    if oc == "no-match result (options)":
        return "in schema: no-match result with options (readable)"
    if any(b.startswith(v) or v in b for v in VALID):
        return "in schema: answered as asked"
    if "true (bool)" in b:
        return "SILENTLY COERCED to another value (true read as 1)" + (" -> a different result" if oc == "different result" else "")
    if "(string)" in b or "(float)" in b:
        return "SILENTLY COERCED (read as the number it spells)"
    if "missing" in b or "{}" in b or "only words given" in b:
        return "SILENTLY DEFAULTED (" + ("same result as the default" if oc.startswith("same") else oc) + ")"
    return oc.upper()


def after(r):
    if r["outcome"] == "refused":
        return "refused: " + (r["detail"] or "")[:110]
    return r["outcome"]


key = {(r["tool"], r["bad"]): r for r in tree}
lines = ["mvp28 args: what code does with a tool argument outside the schema sent to the model",
         "(probe: args/h/probe.py on the made-up library, each bad call alone on a fresh turn, through the model's path;",
         " tip = brain-r28-local 9ff2fba; after = brain-args-local. 'in schema' rows are valid calls kept for contrast.)", ""]
cnt = {}
for r in tip:
    t, a = today(r), after(key[(r["tool"], r["bad"])])
    cls = t.split(":")[0].split(" (")[0]
    cnt[cls] = cnt.get(cls, 0) + 1
    lines.append(f"{r['tool']:10s} | {r['bad']:42s} | today: {t}\n{'':10s}   {'':42s}   after: {a}")
lines.append("")
lines.append("give_answer and the propose tools (args/h/giveprobe.py; loop.clean_form then verify.AnswerForm; not changed by")
lines.append("this branch: give_answer is sent without strict grammar in both arms, and loop/verify are not this key's files):")
lines += ["  " + x for x in open(f"{S}/give_tip.txt").read().splitlines()]
lines.append("")
lines.append("counts of today's outcomes (read tools, 358 cases): " + json.dumps(cnt))
lines.append("after: " + json.dumps({o: sum(1 for r in tree if r["outcome"] == o) for o in sorted({r["outcome"] for r in tree})}) +
             "; every 'after' that is not refused is a call inside the schema")
open(f"{S}/table.txt", "w").write("\n".join(lines) + "\n")
print(json.dumps(cnt, indent=1))
