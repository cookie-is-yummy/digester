"""mvp28 args, step 5: what each read tool does with friends' posts, on the made-up library, under a message that
asks about friends (the note is added then): the friends' count in meta.hidden, the left_out cell, the note."""
import json, os, sys, tempfile
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E
H = E.Harness.scratch(base=tempfile.mkdtemp(prefix="args_fr_"))
from mvp.brain import tools as TL
from mvp.tests.fakes.fake_brain import FakeEngine, fake_learned
MSG = "what did my friends send me that i saved, all time?"
W = {"preset": "all", "same_as": None, "words": None}
SC = {"exclude": [], "how": "saved", "length": "any", "only": [], "platforms": [], "weekday": None}
CALLS = [("find", {"kinds": [], "names": ["Home cooking"]}),
         ("breakdown", {"by": "theme", "compare": "none", "order": "most", "scope": SC, "top": 8, "window": W}),
         ("timeline", {"scope": SC, "unit": "month", "window": W}),
         ("changes", {"against": "previous", "level": "theme", "scope": SC, "window": {"preset": "lately", "same_as": None, "words": None}}),
         ("compare", {"a": {"preset": "this_month", "same_as": None, "words": None}, "b": {"preset": "last_month", "same_as": None, "words": None}, "by": "none", "scope": SC}),
         ("first_last", {"scope": SC, "subject": "Home cooking", "which": "last"}),
         ("items", {"limit": 10, "offset": 0, "order": "newest", "scope": SC, "window": W}),
         ("search", {"how": "saved", "limit": 8, "query": "friend shared post", "window": None}),
         ("learned", {"scope": SC, "topic": "cooking"})]
for name, args in CALLS:
    t = H.turn(MSG, search=FakeEngine(), learned=fake_learned)
    env = TL.call(t, name, args, sent=True) if "sent" in TL.call.__code__.co_varnames else TL.call(t, name, args)
    meta = env.get("meta") or {}
    sh = env.get("sheet") or {}
    ids = [r.get("item_id") for r in sh.get("items") or []]
    fr_rows = [i for i in ids if i and not t.lib.is_visible(i)]
    print(f"{name:10s} err={env.get('error')!s:.40} hidden.friends={(meta.get('hidden') or {}).get('friends')} "
          f"left_out={sh.get('left_out')} friend rows shown={len(fr_rows)} note={[n for n in meta.get('notes') or [] if 'riend' in n]}")
