# checks progress (mvp28, key "checks")
- worktree S/mvp28/checks_tree on brain-checks-local from 8b9440e (made fresh)
- base copies of 8b9440e files in S/mvp28/checks/base/ (git show, no write in the repo)
- harness: checks/lib28.py (lib27 + runs4 four runs, SEVEN), gate28.py (tree vs saved live verdicts on runs4; vs tip
  replay on run2/runA/runB): unchanged tree 0 differ on all seven.
- inv28.py: live safety refusals in seven runs: run2 N048.1 watch_time (cells live), arm1 N048.1 outcome ("You saved it
  on 5 October 2026", OUTCOME's `saved it`). cell_found live: base1 N066.1 ("last 7 days", from the screen's window_said),
  base1 N069.0 ("Four Watercolor reel", a count of rows of a search list), arm2 N069.0 ("Two watercolor reels").
  N024.1 base2 lead f0 "the four areas" (4 only in the model's own args `only`), kept on the reword.
- TASK 1 DONE (commit on brain-checks-local): audit_ledger reads the cell by value (_iso_day, _as_num). Evidence
  checks/audit28.py (517 records of run1+seven runs: tip 0 crash, tree 0 crash, 0 audit results differ tip vs tree);
  checks/crash28.py + crash28.txt (base1 N019.0 rebuilt with a cited new.small_channels[0].first_watched and
  when.busiest_weekdays: tip crashes with the same ValueError, tree completes, right date ok, wrong date flagged);
  checks/auditcli28.py: `audit --run` on copies under checks/auditrun/: tip exit 1 on the three built folders, tree
  exit 0 on them and on all eight run copies. eval_brain.py (not mine) still lets an auditor exception lose a record: open.
- TASK 2 built (not committed yet): verify values rules item_count (items.count marker on a page), item_count_free
  (an unmarked figure only a page length holds), cards_found (a figure no cell holds = rows the answer shows of a page is
  found), rows_shown (a row named by a sentence marker counts as shown, besides cards). Page = sheet.items rows with
  totals.items > len. Compared only for a page the answer shows rows of (spares arm2 N063.1 "the list tool gives 10 at a
  time"). answer.py: _card_list (build uses it) and card_refs. Results: gate changes exactly run2 N044.0 f0,f1, base1
  N044.0, base1 N044.1, base2 N044.0, arm1 N044.0 (all false); 0 true refused on seven runs. attack28: made-up 10/157
  out, misattached 625 out, policy 24, true refused 3: all = tip (rows_shown off: rc2 N44 caught, misattached 624).
  reword28.txt: 10 truthful rewords all kept (4 need cards_found). planted values/full/cells byte-same as the tip copy
  (checks/tipcopy, git archive of 8b9440e). diff28: checker 11850 verdicts 0 differ, answers 1410 form-modes 0 differ.
  cards28: counted cards = build cards on 704/705 forms (runB N049.0: ask-back fallback, a refused sentence's row
  counted before the check; documented). tree build == tip build with the same verdict on all 705.
- TASKS 3-4 built: row_text (a figure or date quoted with a neighbouring word from a cited row's own strings),
  outcome_you ("you/they saved it" is history), screen_window (window_said on the screen with its unit), cited_rows,
  row_group (counts tied to cited rows). measure28_tree.txt: 18 sentences change against the tip on the seven runs: 6
  F now refused (item_count), 12 T released (8 N048.1, base1 N066.1, base1 N069.0, arm1 N048.1 outcome, arm2 N069.0).
  attack28: no class changes (made-up 10, misattached 625, policy 24, true refused 3). probes28: 16 of 3753 made-up
  counts beside a cited row now found, all by row_group. args28: arguments would add 148 figures to free 2 N024.1
  sentences: kept "no". task5_28: the N049.0 shape (row cell with the row unnamed) is 68 T to 2 F labelled: not built.
  marks28.txt: true refused 31 -> 19, false caught 5 -> 11 (replay, every form).
- final checks: gate28.txt, diff28 checker 11850/0 and answers 1410/0, planted values/full/cells byte-same as tip copy,
  suite (shard.sh) 6267 passed 2 skipped. COMMITTED tasks 2-4 on brain-checks-local. notes28.txt holds task 4/5.
- after advisor: eval_brain planted full/cells byte-same tip vs tree; dry selftest 164/164 both, transcript differs only
  by build id and fake sign-in ids (tip extracted to checks/tipcopy by git archive, removed after). cards_found tied to
  sentences citing the page's result (probes28b: 0/503 bare, 16/503 citing a page row). loop test added. 3rd commit.
- lock notes: two greps (audit_ledger|cited_cells over mvp/ with only output filtered; FakeEngine over mvp/) ran over
  folders holding eval/brain_fresh_b.py and evalset/brain_fresh.jsonl; neither printed a line from them.
