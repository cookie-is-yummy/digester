"""attack 6: the streamed provider's retry, timeout and ledger paths, on the real SDK over a fake transport (the
tree's own test fixtures; no network, no money). Prints what happened; asserts nothing that would hide it."""
import json
import os
import sys
import threading
import time

TREE = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/attack_tree/experiments"
sys.path.insert(0, TREE)
sys.path.insert(0, os.path.join(TREE, "mvp", "tests"))

from mvp.tests.test_claude_backend import cl, rows  # noqa: E402,F401
from mvp.tests.test_brain_r28_speed import (ARGS, MSGS, SYSTEM, TOOLS, USAGE, message_body, provider,  # noqa: E402
                                             sse)

OUT = []


def note(*a):
    OUT.append(" ".join(str(x) for x in a))
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "speed_attack.txt"), "a") as f:
        f.write(" ".join(str(x) for x in a) + "\n")


def sse_error_after_start():
    """message_start, a thinking block start, then an SSE error event (overloaded) mid-stream."""
    start = dict(USAGE, output_tokens=1)
    evs = [("message_start", {"type": "message_start", "message": {
        "id": "msg_fake", "type": "message", "role": "assistant", "model": "claude-haiku-5-5", "content": [],
        "stop_reason": None, "stop_sequence": None, "usage": start}}),
        ("content_block_start", {"type": "content_block_start", "index": 0,
                                 "content_block": {"type": "thinking", "thinking": "", "signature": ""}}),
        ("error", {"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}})]

    def gen():
        for name, data in evs:
            yield f"event: {name}\ndata: {json.dumps(data)}\n\n".encode()
    return gen


def test_529_then_success(cl, monkeypatch):
    from mvp.brain import provider as P
    monkeypatch.setattr(P, "BACKOFF_S", (0.05, 0.05))
    _, prov, seen = provider(cl, monkeypatch, [{"status": 529, "json": {"type": "error", "error": {
        "type": "overloaded_error", "message": "o"}}}, {"sse": sse()}], stream=True)
    r = prov.send(SYSTEM, TOOLS, MSGS, timeout=10)
    note("529 then success (stream): requests sent", len(seen), "replies 1, retries", r.retries,
         "ledger rows", len(rows(cl)), [x["prompt_version"] for x in rows(cl)], "spent", round(prov.spent, 6))


def test_sse_error_mid_stream(cl, monkeypatch):
    from mvp.brain import provider as P
    monkeypatch.setattr(P, "BACKOFF_S", (0.05, 0.05))
    _, prov, seen = provider(cl, monkeypatch, [{"sse": sse_error_after_start()}, {"sse": sse()}], stream=True)
    try:
        r = prov.send(SYSTEM, TOOLS, MSGS, timeout=10)
        note("SSE overloaded mid-stream: RETRIED, requests sent", len(seen), "retries", r.retries, "ledger rows",
             len(rows(cl)), [x["prompt_version"] for x in rows(cl)])
    except P.ProviderError as e:
        note("SSE overloaded mid-stream: NOT retried, kind", repr(e.kind), "requests sent", len(seen), "ledger rows",
             len(rows(cl)), [x["prompt_version"] for x in rows(cl)], "timing kept", bool(e.timing))


def test_sse_error_mid_stream_created_equivalent(cl, monkeypatch):
    """The created path's equivalent (a 529 answer) is retried: the contrast."""
    from mvp.brain import provider as P
    monkeypatch.setattr(P, "BACKOFF_S", (0.05, 0.05))
    _, prov, seen = provider(cl, monkeypatch, [{"status": 529, "json": {"type": "error", "error": {
        "type": "overloaded_error", "message": "o"}}}, {"json": message_body()}], stream=False)
    r = prov.send(SYSTEM, TOOLS, MSGS, timeout=10)
    note("529 then success (created): requests sent", len(seen), "retries", r.retries, "ledger rows", len(rows(cl)))


def test_backoff_eats_the_deadline(cl, monkeypatch):
    from mvp.brain import provider as P
    monkeypatch.setattr(P, "BACKOFF_S", (1.0, 1.0))
    _, prov, seen = provider(cl, monkeypatch, [{"status": 529, "json": {"type": "error", "error": {
        "type": "overloaded_error", "message": "o"}}}, {"sse": sse(stall_after_start=0.5)}], stream=True)
    t0 = time.monotonic()
    try:
        prov.send(SYSTEM, TOOLS, MSGS, timeout=1.05)
        note("back-off ate the deadline: the retry ANSWERED, requests", len(seen))
    except P.ProviderError as e:
        took = round(time.monotonic() - t0, 2)
        time.sleep(1.0)
        note("back-off ate the deadline: kind", e.kind, "took", took, "s; requests sent", len(seen),
             "(the retry was sent and abandoned)" if len(seen) == 2 else "", "ledger rows", len(rows(cl)),
             [x["prompt_version"] for x in rows(cl)])


def test_hang_wall_clock_and_worker(cl, monkeypatch):
    from mvp.brain import provider as P
    _, prov, seen = provider(cl, monkeypatch, [{"sse": sse(stall_after_start=2.0)}], stream=True)
    before = {t.name for t in threading.enumerate()}
    try:
        prov.send(SYSTEM, TOOLS, MSGS, timeout=0.6)
    except P.ProviderError as e:
        alive = [t.name for t in threading.enumerate() if t.name == "brain-stream"]
        note("hang: kind", e.kind, "requests", len(seen), "ledger rows", len(rows(cl)),
             [x["prompt_version"] for x in rows(cl)], "worker threads alive right after", len(alive))
        time.sleep(2.5)
        alive2 = [t.name for t in threading.enumerate() if t.name == "brain-stream"]
        note("hang: worker threads alive 2.5 s later", len(alive2), "spent", round(prov.spent, 6),
             "requests counted", prov.requests)


def test_raw_bytes_created_vs_streamed(cl, monkeypatch):
    """What the second request carries back for the assistant turn: created raw (SDK objects) vs streamed raw."""
    from mvp.brain import provider as P
    body = message_body()
    body["content"] = [{"type": "thinking", "thinking": "t", "signature": "sig-1"},
                       {"type": "text", "text": "x", "citations": None},
                       {"type": "tool_use", "id": "toolu_1", "name": "breakdown", "input": ARGS}]
    _, a, seen = provider(cl, monkeypatch, [{"json": body}, {"json": message_body()}], stream=False)
    ra = a.send(SYSTEM, TOOLS, MSGS, timeout=10)
    a.send(SYSTEM, TOOLS, MSGS + [{"role": "assistant", "content": ra.raw}, {"role": "user", "content": "go"}],
           timeout=10)
    start = dict(USAGE, output_tokens=1)
    evs = [("message_start", {"type": "message_start", "message": {"id": "m", "type": "message", "role": "assistant",
                                                                    "model": "claude-haiku-5-5", "content": [],
                                                                    "stop_reason": None, "stop_sequence": None,
                                                                    "usage": start}}),
           ("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {
               "type": "thinking", "thinking": "", "signature": ""}}),
           ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "thinking_delta",
                                                                                       "thinking": "t"}}),
           ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "signature_delta",
                                                                                       "signature": "sig-1"}}),
           ("content_block_stop", {"type": "content_block_stop", "index": 0}),
           ("content_block_start", {"type": "content_block_start", "index": 1, "content_block": {
               "type": "text", "text": ""}}),
           ("content_block_delta", {"type": "content_block_delta", "index": 1, "delta": {"type": "text_delta",
                                                                                       "text": "x"}}),
           ("content_block_stop", {"type": "content_block_stop", "index": 1}),
           ("content_block_start", {"type": "content_block_start", "index": 2, "content_block": {
               "type": "tool_use", "id": "toolu_1", "name": "breakdown", "input": {}}}),
           ("content_block_delta", {"type": "content_block_delta", "index": 2, "delta": {
               "type": "input_json_delta", "partial_json": json.dumps(ARGS)}}),
           ("content_block_stop", {"type": "content_block_stop", "index": 2}),
           ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "tool_use", "stop_sequence": None},
                              "usage": {"output_tokens": 42}}),
           ("message_stop", {"type": "message_stop"})]

    def gen():
        for name, data in evs:
            yield f"event: {name}\ndata: {json.dumps(data)}\n\n".encode()
    _, b, seen2 = provider(cl, monkeypatch, [{"sse": gen}, {"sse": sse()}], stream=True)
    rb = b.send(SYSTEM, TOOLS, MSGS, timeout=10)
    b.send(SYSTEM, TOOLS, MSGS + [{"role": "assistant", "content": rb.raw}, {"role": "user", "content": "go"}],
           timeout=10)
    ca = seen[1]["body"]["messages"][1]["content"]
    cb = seen2[1]["body"]["messages"][1]["content"]
    note("assistant turn sent back: created", json.dumps(ca, sort_keys=True))
    note("assistant turn sent back: streamed", json.dumps(cb, sort_keys=True))
    note("same bytes:", json.dumps(ca, sort_keys=True) == json.dumps(cb, sort_keys=True))
