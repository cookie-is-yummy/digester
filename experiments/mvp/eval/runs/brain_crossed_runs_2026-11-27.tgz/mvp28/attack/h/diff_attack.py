"""attack 7: full and cells of the tree against the tip (git show copies in base/), byte for byte, on: the planted
forms, the eight non-heldout live runs of lib28 (look1/look2 left out: they are runs of the plans held-out half),
the skeptic, a2 and c2 sets, and the attack forms of attack1/2/3. Then answers (code lead, code build, model build,
verdict_json) on the same runs and the attack forms. No model call."""
import os, sys
os.environ.setdefault("VALUES_TREE", "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/attack_tree")
import lib28 as L
L.RUNS = {k: v for k, v in L.RUNS.items() if not k.startswith("look")}
import diff28 as D
sys.path.insert(0, os.path.dirname(L.HERE))
V, VT = L.V, L.VT


def attack_forms():
    import alib as AL
    AL.V, AL.VT = V, VT   # same modules
    import attack1 as A1, attack2 as A2, attack3 as A3
    from mvp.tests.fakes.fake_brain import FakeEngine
    built = {}
    for cid, sk, form, where, truth, shape in A1.CASES:
        if sk not in built:
            m, c, kw = A1.SCEN[sk]; built[sk] = AL.turn(m, c, **kw)
        yield f"a1:{cid}", form, built[sk]
    ts2 = A2.built()
    for k, (sk, s, shape) in enumerate(A2.A):
        yield f"a2x:{k}", {"lead": "Here is what the posts say.", "points": [s]}, ts2[sk]
    ts3 = {k: AL.turn(m, c, screen=sc, search=FakeEngine()) for k, (m, c, sc) in A3.SCEN.items()}
    for k, (sk, s, items, shape) in enumerate(A3.A):
        yield f"a3:{k}", {"lead": "Here is what I found.", "points": [s], "items": [{"ref": r, "note": None} for r in items]}, ts3[sk]
    # ask-backs with `between` and picks over a page
    t = built["cook5"]
    for k, betw in enumerate((["r1.items[2]", "r1.items[4]"], ["r1.items[0]"], [], ["r9.items[0]"])):
        yield f"ask:{k}", {"lead": "Which one do you mean?", "points": [], "ask_back": {"between": betw}}, t


def forms_no_rc2():
    for c, k, f, led in L.planted_forms():
        yield f"planted:{c['id']}:{k}", f, led, ("p", c)
    for run in L.RUNS:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                yield f"{run}:{rec['key']}:{fi}", f, results, ("t", t)
    for c, sent, carrier, where, t in L.skeptic_inputs():
        f = {"lead": sent} if where == "L" else {"lead": carrier, "points": [sent]}
        yield f"skeptic:{c[0]}", f, t.results, ("t", t)
    d = L.a2()
    for c in d["cases"]:
        led, car, tt = d["ledgers"][c["record"]], d["carriers"][c["record"]], d["turns"][c["record"]]
        yield f"a2:{c['id']}:P", {"lead": car, "points": [c["text"]]}, led, ("a2", tt)
        yield f"a2:{c['id']}:L", {"lead": c["text"], "points": []}, led, ("a2", tt)
    C, turns = L.check2_inputs()
    for cid, tid, truth, fam, s, note in C.CASES:
        t, results = turns[tid]
        yield f"c2:{cid}:P", {"lead": C.CARRIER[tid], "points": [s]}, results, ("t", t)
        yield f"c2:{cid}:L", {"lead": s, "points": []}, results, ("t", t)


def main():
    n = bad = 0
    gen = list(forms_no_rc2())
    gen += [(name, f, t.results, ("t", t)) for name, f, t in attack_forms()]
    for name, f, led, how in gen:
        for mode in ("full", "cells"):
            b = D.vdump(VT.check_answer(f, VT.Ledger(led), D.turn_of(VT, how), mode=mode))
            a = D.vdump(V.check_answer(f, V.Ledger(led), D.turn_of(V, how), mode=mode))
            n += 1
            if a != b:
                bad += 1
                print("DIFF", name, mode)
    print(f"checker: {n} verdicts (full and cells), {bad} differ; forms {len(gen)}")
    # answers
    FBt = L._load(os.path.join(L.HERE, "base", "fallback_tip.py"), "mvp.brain.fallback_tip"); FBt.V = VT
    At = L._load(os.path.join(L.HERE, "base", "answer_tip.py"), "mvp.brain.answer_tip"); At.V = VT
    LPt = L._load(os.path.join(L.HERE, "base", "loop_tip.py"), "mvp.brain.loop_tip")
    from mvp.brain import fallback as FB, answer as A, loop as LP
    m = abad = 0
    items = [(f"{run}:{rec['key']}:{fi}", f, results, t) for run in L.RUNS for rec, t, results in L.inputs(run)
             for fi, f in enumerate(rec.get("forms") or [])]
    items += [(name, f, t.results, t) for name, f, t in attack_forms()]
    for name, f, results, t in items:
        for mode in ("full", "cells", "values"):
            vb = VT.check_answer(f, results, VT.Turn.of(t), mode=mode)
            vr = V.check_answer(f, results, V.Turn.of(t), mode=mode)
            cb = FBt.answer(VT.Ledger(results), vb, VT.Turn.of(t), mode=mode)
            cr = FB.answer(V.Ledger(results), vr, V.Turn.of(t), mode=mode)
            ab = At.build(VT.Ledger(results), verdict=None, code=cb, form=f, also=[vb], mode=mode)
            ar = A.build(V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode=mode)
            # the tree's verdict through both builds (values verdicts differ by design; the build must not)
            mb = At.build(results, verdict=vr, form=f, also=[vr], mode=mode)
            mr = A.build(results, verdict=vr, form=f, also=[vr], mode=mode)
            jb, jr = LPt.verdict_json(vb), LP.verdict_json(vr)
            m += 1
            same_main = repr((cb, ab, jb)) == repr((cr, ar, jr)) if mode != "values" else True
            if not same_main or repr(mb) != repr(mr):
                abad += 1
                print("ANSWER DIFF", name, mode, "lead/code/json" if not same_main else "build with the same verdict")
    print(f"answers: {m} form-modes (full, cells; values only for the build with one verdict), {abad} differ")


if __name__ == "__main__":
    main()
