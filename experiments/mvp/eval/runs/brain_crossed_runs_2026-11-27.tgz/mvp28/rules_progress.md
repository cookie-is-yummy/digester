# rules progress (mvp28, key rules)
- step 0: worktree rules_tree on brain-rules-local at 9ff2fba
- step 1: verify.py: VALUES_RULES back to last round's four (the default); VALUES_RULES_R28 (16 rules, kept), VALUES_RULES_ALL;
  MVP_BRAIN_VALUES_RULES read once (values_rules_env) into VALUES_DEFAULT_RULES; values_mode(rules=None) = that set.
  VALUES_REFUSE / VALUES_CODES back to last round's; item_count in VALUES_REFUSE_R28 / VALUES_CODES_R28.
- step 2 (proof, harness copy rules/a, VALUES_TREE=rules_tree): rules/prove_default.txt: default vs tip values on run1 + seven
  half A runs: 553 forms, 1546 sentences, 0 differ (all fields incl. details, notes, flags, repair_message). vs saved live
  (six values-live runs): 1119 sentences, 3 differ, all runB, tip gives the same 3 (last round's rules, after runB ran).
  MVP_BRAIN_VALUES_RULES=r28 vs repair/after/ref_final.json: 0 of 1546 differ (the rules' code intact).
- step 3: eval_brain.py (outside my list, needed for item 1): values_rules_settings(check) -> settings values_rules,
  values_rules_r28 for a values run. Tests: test_brain_values pin back to last round's (6faec7f8...); r28_checks and
  r28_repair run under an autouse fixture r28_on (MVP_BRAIN_VALUES_RULES=r28, modules re-imported; 21 fail without it);
  r28_prompts: the forged-title test's short form is kept by default, refused with item_count on. New
  test_brain_r28_rules.py (10 tests). Comments with eval message ids rewritten by class (6 places, this round's only).
- step 4: per_rule.py and planted (tree vs tipcopy = git archive 8b9440e) running.
- step 5: planted (rules/planted/): brain.planted full/cells/values and `python3 -m mvp.eval_brain planted` with
  MVP_BRAIN_CHECK full/cells/values byte-same tree vs tipcopy (exit codes same: eval_brain cells and values exit 1 on
  both). diff_attack and per_rule running.
- step 6: diff_attack (rules/diff_attack.txt): checker 4598 verdicts full+cells 0 differ, answers 2130 form-modes 0 differ.
  per_rule.txt written (20 flips under all r28 over 11 runs; 0 on v3c final and v4c; 1 on v3c first, 2 on v3b).
  Default proof rerun after the comment edits: 0/1546 vs tip; r28 vs merged 0/1546. Brain tests in 4 shards:
  627 passed (162+181+142+142); values-related files with MVP_BRAIN_CHECK cells and values: 200 passed each.
- step 7: committed d0151a4 on brain-rules-local (not pushed). tipcopy, caches removed. DONE.
- step 8 (after advisor): base2/arm1/arm2 summaries hold empty settings, so each record of a values run now carries
  values_rules / values_rules_r28 too (live_conversation), tested with the fake provider; message ids left in
  test_brain_r28_checks.py comments reworded by class. eval_brain planted full/cells/values still = tip outputs.
  Committed b7aa606. Whole suite in 4 shards running (rules/suite_out).
- step 9: whole suite on b7aa606, 4 shards: 6314 passed, 2 skipped, 0 failed (1449, 1487, 1491+2s, 1887) = 6302 + 12 new. suite_out removed. DONE (not pushed).
