"""mvp28 limits: the counters of summary27 (limit sentences narrow and wide, in the lead and in points; left_out cells
cited; sentences; output tokens per request; seconds) over the fixed sample, split into WANTED / unwanted messages,
plus the shown count against the cards. usage: LIM_TREE=<tree> python3 m28.py NAME=DIR [NAME=DIR ...] [--keys K,K]"""
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lim28 as L  # noqa: E402

WANTED = set("N038.0 N042.0 N113.0 N067.0 N066.0 N066.1 N055.0 N109.0 N052.1 N056.0 N062.0 N063.0 N064.0".split())
NOT_LIMIT = {"N053.0", "N036.0", "N057.0"}   # the private topic is the subject; allowed not needed; code's line
LEFT_OK = {"N052.1", "N055.0", "N109.0"}
args = [a for a in sys.argv[1:] if not a.startswith("--keys") and "=" in a]
keys = None
for a in sys.argv[1:]:
    if a.startswith("--keys"):
        keys = set(a.split("=", 1)[1].split(","))
WORDS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
SHOWN = re.compile(r"\b(?:here are|these|the next|next|showing)\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten)\b",
                   re.I)


def pct(xs, q):   # summary27.pct, copied
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)


def load(d):
    rs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(d, "N*.json"))]
    rs = [r for r in rs if keys is None or r["key"] in keys]
    return sorted(rs, key=lambda r: (r["key"].split(".")[0], int(r["key"].split(".")[1])))


def card_faults(r):
    """A shown count (a count marker of an items or search list, or 'here are / next N' as sent) above the cards."""
    a = r.get("answer") or {}
    ncards = len(a.get("cards") or [])
    out = []
    v = (r.get("verdicts") or [{}])[-1]
    lists = {}
    for c in r.get("calls") or []:
        res = c.get("result") or {}
        sh = res.get("sheet") or {}
        if isinstance(sh.get("items"), list):
            lists[res.get("rid")] = len(sh["items"])
    for o in v.get("outcomes") or []:
        if not o.get("kept"):
            continue
        for m in re.finditer(r"\[(r\d+)\.items\.count\]", o.get("text") or ""):
            n = lists.get(m.group(1))
            if n is not None and n > ncards:
                out.append(f"count marker {n} > {ncards} cards")
        for m in SHOWN.finditer(o.get("sent") or ""):
            if int(WORDS.get(m.group(1).lower(), m.group(1))) > ncards and lists:
                out.append(f"'{m.group(0)}' > {ncards} cards")
    return out


def fig(d):
    rs = load(d)
    f = {"messages": len(rs)}
    lead = lambda r: (r.get("answer") or {}).get("lead") if r["lead_source"].startswith("model") else None
    pts = lambda r: (r.get("answer") or {}).get("points") or []
    for cls, pick in (("all", lambda k: True), ("WANTED", lambda k: k in WANTED),
                      ("unwanted", lambda k: k not in WANTED and k not in NOT_LIMIT)):
        sub = [r for r in rs if pick(r["key"])]
        f[f"[{cls}] n"] = len(sub)
        f[f"[{cls}] narrow lead answers"] = sum(1 for r in sub if L.narrow(lead(r)))
        f[f"[{cls}] narrow point sentences"] = sum(1 for r in sub for p in pts(r) if L.narrow(p))
        f[f"[{cls}] wide lead answers"] = sum(1 for r in sub if L.is_limit(lead(r)))
        f[f"[{cls}] wide point sentences"] = sum(1 for r in sub for p in pts(r) if L.is_limit(p))
        f[f"[{cls}] answers with any wide limit sentence"] = sum(
            1 for r in sub if L.is_limit(lead(r)) or any(L.is_limit(p) for p in pts(r)))
        f[f"[{cls}] answers with 2+ wide limit sentences"] = sum(
            1 for r in sub if (1 if L.is_limit(lead(r)) else 0) + sum(1 for p in pts(r) if L.is_limit(p)) >= 2)
    lo = [(r["key"], o.get("sent")) for r in rs for v in (r.get("verdicts") or [])[-1:]
          for o in v.get("outcomes") or [] if o.get("kept") and ".left_out." in (o.get("text") or "")]
    f["left_out cited (sentences; answers)"] = f"{len(lo)} ({len({k for k, _ in lo})})"
    f["left_out cited where not asked"] = sum(1 for k, _ in lo if k not in LEFT_OK)
    f["private line"] = sum(1 for r in rs if (r.get("answer") or {}).get("private_line"))
    f["code's limit lines"] = sum(len((r.get("answer") or {}).get("limits") or []) for r in rs)
    sent = sum((r.get("sentences") or {}).get("kept_sent", 0) for r in rs)
    wr = sum((r.get("sentences") or {}).get("written", 0) for r in rs)
    f["sentences written / sent per answer"] = f"{round(wr / len(rs), 2)} / {round(sent / len(rs), 2)}"
    f["points per answer"] = round(sum(len(pts(r)) for r in rs) / len(rs), 2)
    nreq = sum(r["n_requests"] for r in rs)
    f["output tokens per request"] = round(sum(r["tokens"]["output_tokens"] for r in rs) / nreq, 1)
    f["requests"] = nreq
    secs = [r["seconds"] for r in rs]
    f["seconds median / p90 / max"] = f"{pct(secs, .5)} / {pct(secs, .9)} / {max(secs)}"
    f["provider errors"] = sorted(r["key"] for r in rs if r.get("error"))
    f["lead source model/repair/code"] = "/".join(str(sum(1 for r in rs if r["lead_source"] == s))
                                                  for s in ("model", "model_after_repair", "code"))
    ref = [(r["key"], o.get("reasons")) for r in rs for v in r.get("verdicts") or [] for o in v.get("outcomes") or []
           if not o.get("kept")]
    f["sentences refused (all forms)"] = len(ref)
    f["shown count above cards"] = [(r["key"], x) for r in rs for x in card_faults(r)]
    f["cost $ (records)"] = round(sum(r["cost_usd"] for r in rs), 6)
    return f, rs


if __name__ == "__main__":
  cols = [(a.split("=", 1)[0], fig(a.split("=", 1)[1])) for a in args]
  for k in cols[0][1][0]:
      vals = [str(c[1][0].get(k)) for c in cols]
      if max(len(v) for v in vals) > 22:
          print(f"{k}:")
          for (n, _), v in zip(cols, vals):
              print(f"    {n:>8}: {v}")
      else:
          print(f"{k:52s}" + "".join(f"{v:>24}" for v in vals))
