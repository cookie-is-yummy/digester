"""mvp28 limits: summary27's limit-sentence definitions, copied verbatim (lines 18-41) so they can be imported.
usage: import after sys.path has the tree's experiments folder (TREE from env LIM_TREE)."""
import glob
import json
import os
import re
import sys
from collections import Counter

TREE = os.environ["LIM_TREE"]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import verify as V  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


# A limit sentence (one mechanical definition for every column): the checker's own LIMITS and _SELF_TALK patterns,
# plus the plain ways the tools' limits are said ("holds no likes", "nothing after", "not in your export", ...).
_EXTRA = re.compile(r"\b(?:holds? no|has no|no likes|nothing (?:after|past|from)|not in (?:your|the) (?:export|history|"
                    r"data)|isn'?t in (?:your|the)|aren'?t in (?:your|the)|does ?n[o']t hold|do ?n[o']t hold|"
                    r"(?:export|history|data) (?:only )?(?:goes|runs|stops|ends)|stops? (?:on|at) \d|ends? on \d|"
                    r"only (?:as )?(?:a )?counts?|friends?'?s? (?:post|save)s?|private|how far you watched|"
                    r"not (?:recorded|tracked|kept))", re.I)


_WIN = re.compile(r"(?:where|when) your (?:youtube |instagram )?export ends", re.I)


def unwin(s):
    """The checker's own step (verify 3.10): the window phrase 'where your export ends' is not a limit sentence."""
    return _WIN.sub(" ", s or "")


def narrow(s):
    return bool(s) and bool(V.LIMITS.search(unwin(s)) or V._SELF_TALK.search(unwin(s)))


def is_limit(s):
    return bool(s) and (narrow(s) or bool(_EXTRA.search(unwin(s))))

