"""The fixed sample (chosen before any v3c output): targets, every conversation with a limit sentence (wide) or a
left_out citation in base1 or base2, N044 N048 N049, and 10 controls with no limits talk in any of the four runs.
usage: python3 pick.py TREE RUNS4"""
import glob, hashlib, json, os, sys
TREE, R4 = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); os.environ["LIM_TREE"] = TREE

import lim28 as S27  # noqa: E402
TARGETS = "N038.0 N042.0 N113.0 N067.0 N055.0 N109.0 N052.0 N052.1 N054.0 N049.0 N056.0".split()
def recs(run):
    return {json.load(open(f))["key"]: json.load(open(f)) for f in glob.glob(f"{R4}/{run}/N*.json")}
hit = {}
for run in ("base1", "base2"):
    for k, r in recs(run).items():
        a = r.get("answer") or {}
        why = []
        if r["lead_source"].startswith("model") and S27.is_limit(a.get("lead")):
            why.append("lead")
        if any(S27.is_limit(p) for p in a.get("points") or []):
            why.append("point")
        if any(o.get("kept") and ".left_out." in (o.get("text") or "") for v in (r.get("verdicts") or [])[-1:]
               for o in v.get("outcomes") or []):
            why.append("left_out")
        if why:
            hit.setdefault(k, set()).update(f"{run}:{w}" for w in why)
convs = sorted({k.split(".")[0] for k in TARGETS} | {k.split(".")[0] for k in hit} | {"N044", "N048", "N049"})
# controls: conversations with no limits talk in any of the four runs, not N019 (the eval's auditor crash), chosen
# by a fixed hash order (no reading of answers)
quiet = set()
allk = set()
for run in ("base1", "base2", "arm1", "arm2"):
    for k, r in recs(run).items():
        allk.add(k.split(".")[0])
        a = r.get("answer") or {}
        if (S27.is_limit(a.get("lead")) or any(S27.is_limit(p) for p in a.get("points") or []) or
                a.get("private_line") or a.get("limits") or
                any(".left_out." in (o.get("text") or "") for v in r.get("verdicts") or [] for o in v.get("outcomes") or [])):
            quiet.add(k.split(".")[0])
cand = sorted((allk - quiet - set(convs) - {"N019"}), key=lambda c: hashlib.sha1(("ctl28" + c).encode()).hexdigest())
controls = sorted(cand[:10])
print("TARGETS", " ".join(TARGETS))
print("HITS", len(hit))
for k in sorted(hit):
    print("  ", k, sorted(hit[k]))
print("CONVS", len(convs), ",".join(convs))
print("CONTROLS", ",".join(controls), "of", len(cand))
print("IDS", ",".join(sorted(set(convs) | set(controls))))
