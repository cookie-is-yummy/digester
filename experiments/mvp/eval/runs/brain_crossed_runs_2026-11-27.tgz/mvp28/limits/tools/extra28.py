"""Free checks over the saved records (made after seeing v3c/v4c output): turns with zero read calls, turns where a read
call errored and none followed; hidden-count sentences by words (marker or not); refusals and the flags bad_ref,
number_word, bad_marker, number; p90 without timed-out messages. usage: python3 extra28.py KEYSFILE NAME=DIR ..."""
import glob, json, os, re, sys
keys = set(open(sys.argv[1]).read().strip().split(","))
HID = re.compile(r"\b(?:private|friend'?s'? posts?|friend's post)\b", re.I)
def pct(xs, q):
    xs = sorted(xs); k = (len(xs) - 1) * q; lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)
for a in sys.argv[2:]:
    name, d = a.split("=", 1)
    rs = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(d, "N*.json")))]
    rs = [r for r in rs if r["key"] in keys]
    zero = [(r["key"], r.get("rounds"), r.get("events")) for r in rs if not r["calls"]]
    noretry = []
    for r in rs:
        cs = r["calls"]
        if cs and (cs[-1].get("result") or {}).get("is_error"):
            noretry.append((r["key"], r.get("rounds"), r.get("events")))
    hid = [(r["key"], s) for r in rs for s in [(r.get("answer") or {}).get("lead")] + ((r.get("answer") or {}).get("points") or [])
           if s and HID.search(s) and r["lead_source"].startswith("model")]
    fl = {}
    for r in rs:
        for x in r.get("flags") or []:
            if x["code"] in ("bad_ref", "number_word", "bad_marker", "number"):
                fl[x["code"]] = fl.get(x["code"], 0) + 1
    ref = [(r["key"], o["reasons"]) for r in rs for v in r.get("verdicts") or [] for o in v.get("outcomes") or [] if not o["kept"]]
    secs = [r["seconds"] for r in rs if not r.get("error")]
    print(f"== {name}: zero read calls {zero} | last read call errored, none after {noretry}")
    print(f"   hidden-count words in model sentences: {len(hid)} {[k for k, _ in hid]}")
    print(f"   refused {ref} | flags {fl} | without timed-out: n {len(secs)} median {pct(secs, .5)} p90 {pct(secs, .9)}")
