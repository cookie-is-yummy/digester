"""Every limit sentence (wide) sent in a run, marked wanted / unwanted. usage: LIM_TREE=.. python3 listlim.py DIR"""
import glob, json, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lim28 as L  # noqa: E402
from m28 import WANTED, NOT_LIMIT  # noqa: E402
for f in sorted(glob.glob(os.path.join(sys.argv[1], "N*.json"))):
    r = json.load(open(f))
    k, a = r["key"], r.get("answer") or {}
    cls = "WANTED" if k in WANTED else "n/a" if k in NOT_LIMIT else "unwanted"
    if r["lead_source"].startswith("model") and L.is_limit(a.get("lead")):
        print(f"{cls:8} lead  {k}: {a['lead']}")
    for p in a.get("points") or []:
        if L.is_limit(p):
            print(f"{cls:8} point {k}: {p}")
