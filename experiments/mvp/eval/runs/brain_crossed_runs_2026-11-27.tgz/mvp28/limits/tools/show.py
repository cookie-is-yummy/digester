"""Print one message's record compactly: python3 show.py <run_dir> <key> [result_chars]"""
import json, sys
d = json.load(open(f"{sys.argv[1]}/{sys.argv[2]}.json"))
n = int(sys.argv[3]) if len(sys.argv) > 3 else 1200
print("MSG", d["message"], "| lead_source", d["lead_source"], "| s", d["seconds"], "| err", d["error"])
for c in d["calls"]:
    print("CALL", c["name"], json.dumps(c["args"], ensure_ascii=False)[:300])
    print("  RES", json.dumps(c.get("result"), ensure_ascii=False)[:n])
for i, f in enumerate(d["forms"]):
    print(f"FORM{i} lead:", f.get("lead"))
    for p in f.get("points") or []:
        print("   pt:", p)
    print("   items:", [x["ref"] for x in f.get("items") or []])
print("ANSWER:\n" + d["answer"]["text"])
