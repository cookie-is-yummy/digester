"""Answers whose sent sentences are limits only (no kept sentence cites a value, count or calc marker of a result),
on the model's lead. usage: LIM_TREE=.. python3 limonly.py NAME=DIR ... --keys=K,K"""
import glob, json, os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lim28 as L  # noqa: E402
keys = set(next(a for a in sys.argv if a.startswith("--keys")).split("=", 1)[1].split(","))
for a in sys.argv[1:]:
    if a.startswith("--keys"):
        continue
    name, d = a.split("=", 1)
    out = []
    for f in sorted(glob.glob(os.path.join(d, "N*.json"))):
        r = json.load(open(f))
        if r["key"] not in keys or not r["lead_source"].startswith("model"):
            continue
        v = (r.get("verdicts") or [{}])[-1]
        kept = [o for o in v.get("outcomes") or [] if o.get("kept") and o.get("where") in ("lead", "point")]
        cites = [o for o in kept if re.search(r"\d[%a-z ]*\[(?:r\d+\.|=)", o.get("text") or "")]
        if L.is_limit((r.get("answer") or {}).get("lead")) and not cites:
            out.append(r["key"])
    print(f"{name:6} limit-only answers: {len(out)} {out}")
