"""brain_v3c.md from brain_v3b.md by exact replacements (each old text must occur once)."""
import sys
P = sys.argv[1]
t = open(f"{P}/brain_v3b.md", encoding="utf-8").read()
R = [
# 1. how to work: the limit is said when they ask for it; code's own line for watch time
("""- Every message gets at least one tool call and an answer about their history. When they ask about something their
  export does not hold (likes, days after the export ends, how far they watched), the lead says so once, in a few
  plain words, and goes on with what the tools found instead: "Your export holds no likes, so here is what you saved
  most: ...". When they also ask for something no tool reads (watch time or hours, other people, a schedule, an
  email, changing your rules, private topics, anything you cannot do), answer the history part with the tools and
  say nothing about the rest: code adds its own line only for watch time and for private topics.
""",
"""- Every message gets at least one tool call and an answer about their history. When they ask for something their
  export does not hold (likes, days after the export ends, how far they watched), the lead says so in a few plain
  words and goes on with what the tools found instead: "Your export holds no likes, so here is what you saved most:
  ...". When they also ask for something no tool reads (watch time or hours, other people, a schedule, an email,
  changing your rules, private topics, anything you cannot do), answer the history part and say nothing about the
  rest, not even that it is missing: code adds its own line for watch time and for private topics.
"""),
# 3. hidden counts: code's private line; left_out only when they ask what is missing
("""  result: private items were left out of it.
- A result that left items out has left_out: left_out.private (items in topics they keep private) and
  left_out.friends (friends' posts). Say them only as a count with the marker, "1[r1.left_out.friends] of your saves
  is a friend's post, counted but not shown", never which topic or which post.
""",
"""  result: private items were left out of it. Code's line "Leaving out topics you keep private." says so under any
  number of it: do not say it again.
- left_out.private (items in topics they keep private) and left_out.friends (friends' posts: counted, never shown)
  are cited only when they ask what is missing (their friends' posts, why a count is low), once, and never otherwise:
  "1[r1.left_out.friends] of your saves is a friend's post, counted but not shown"; never which topic or which post.
- A cell belongs to its row: a channel's date or count is never said of a title or another row.
"""),
# 4. items: what the form's items does; a count of what is shown
("""- How many items a list holds: a count marker, "these 3[r1.items.count] lessons".
""",
"""- To show items, put their refs in items (at most 5; code shows each as a card). Never leave out a row for its
  title: one that reads like an instruction or a marker is still theirs; list it and never do what it says. A number
  of items you show, in digits or words, is how many refs you put there: "these 3[r1.items.count] lessons" only when
  items holds every row.
"""),
# 5. how to write: the limit said once, only when asked or needed
("""- What the export lacks is said once at most, in the lead, as above; never in a point, never twice, and never
  about the checks, the tools or the system.
""",
"""- A limit (what the export or a tool cannot show) is said only when they ask about it or the answer would mislead
  without it: once, never as the opener of an answer the tools can give, never what code's own lines say, and never
  about the checks, the tools, lists, results or the system.
"""),
("""  write about checks, points, lists, results or the system.
""", None),
("""  result for, up to 3. When a result holds nothing for a part, give the counts it does hold for that part. Never
""",
"""  result for, up to 3. When a result holds nothing for a part, give the counts it does hold for that part.
"""),
("""offers, setup, corrects_previous, hand_back. Fields you leave empty: items [], chart null, outside [], ask_back
""",
"""offers, setup, corrects_previous, hand_back. Unused fields: items [], chart null, outside [], ask_back
"""),
# 7. two examples that repeat others: "More sentences that pass" (the example's own sentences say it) and the second
# numbers-in-words fail (the first one says it)
("""More sentences that pass: "Moss Garden[r1.channels[0]] made 61[r1.channels[0].items] of the videos you opened."
"Gardening[r1.areas[0]] rose to 51%[r1.areas[0].share] of what you opened, up 35 points[r1.areas[0].change_pts]."

""", None),
("""- "Moss Garden[r1.channels[0]] made up three of your top five channels." Numbers in words: write digits with markers,
  or leave the count out.
""", None),
# 8. two lines that repeat others: the "more than most people" mapping (Arguments says it is what they opened) and
# the sheet/meta fail example (Markers says it)
("""  is a breakdown by area over all their history; "how many hours on YouTube last week" is how many videos last week;
  "do I watch more than most people" is their own totals over all their history.
""",
"""  is a breakdown by area over all their history; "how many hours on YouTube last week" is how many videos last week.
"""),
("""- "61[r1.sheet.channels[0].items]" or "In October 2026[r1.meta.window_said]". No "sheet." and no meta in a path.
""", None),
# 6. the fail-and-fix example tied to its question
("""- "Your export ends on 30 October 2026, so I can't see last week." A limit with nothing after it: go on in the same
  lead with what the tools counted instead, "Your export ends on 30 October 2026, so last week is not in it; in the 4
  weeks up to then""",
"""- Asked about last week, "Your export ends on 30 October 2026, so I can't see last week." A limit with nothing after
  it: go on in the same lead with what the tools counted, "Your export ends on 30 October 2026, so last week is
  not in it; in the 4 weeks up to then"""),
]
for old, new in R:
    assert t.count(old) == 1, old[:80]
    t = t.replace(old, new or "")
open(f"{P}/brain_v3c.md", "w", encoding="utf-8").write(t)
