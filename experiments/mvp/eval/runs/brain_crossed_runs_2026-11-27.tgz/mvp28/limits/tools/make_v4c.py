"""brain_v4c.md = brain_v3c.md with exactly the hunks that turn brain_v3b.md into brain_v4_meaning.md, applied as
(old block -> new block) replacements found once each; then the two diffs are compared hunk by hunk with the line
numbers taken out. usage: python3 make_v4c.py PROMPTS_DIR"""
import difflib, sys
P = sys.argv[1]
rd = lambda n: open(f"{P}/{n}.md", encoding="utf-8").read().splitlines(keepends=True)
b, m, c = rd("brain_v3b"), rd("brain_v4_meaning"), rd("brain_v3c")
def hunks(x, y):
    return [("".join(x[i1:i2]), "".join(y[j1:j2]), tag) for tag, i1, i2, j1, j2 in
            difflib.SequenceMatcher(None, x, y, autojunk=False).get_opcodes() if tag != "equal"]
H = hunks(b, m)
t = "".join(c)
for old, new, _tag in H:
    assert old and t.count(old) == 1, old[:80]
    t = t.replace(old, new)
open(f"{P}/brain_v4c.md", "w", encoding="utf-8").write(t)
H2 = hunks(c, t.splitlines(keepends=True))
print("hunks v3b->v4_meaning:", len(H), "| v3c->v4c:", len(H2), "| same:", H == H2)
for (o, n, tg), (o2, n2, tg2) in zip(H, H2):
    print("  ", tg, repr(o[:50]), "->", repr(n[:50]), "| equal" if (o, n) == (o2, n2) else "| DIFFER")
