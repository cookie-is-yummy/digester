#!/bin/bash
# usage: smoke.sh PROMPT STRICT  -- one smoke run on the merged tree: fresh half a, 4 messages, values check
S=/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad
P=$1; ST=$2; OUT=$S/mvp28/merge2/smoke_${P}_s${ST}
rm -rf "$OUT"
. $S/keys/anthropic.env
cd $S/mvp28/merge_tree/experiments
unset MVP_BRAIN_VALUES_RULES
env PYTHONDONTWRITEBYTECODE=1 MVP_BRAIN_PROMPT=$P MVP_BRAIN_STRICT=$ST MVP_LEDGER_HOME=/home/user/digester/data/mvp MVP_CLAUDE_CAP_USD=25 \
  python3 -m mvp.eval_brain run --set fresh --half a --limit 4 --check values --out "$OUT" --max-usd 0.02 2>&1 \
  | sed -E 's/sk-ant-[A-Za-z0-9_-]+/<key>/g' > "$OUT.log"
echo "exit ${PIPESTATUS[0]}" > "$OUT.exit"
