"""rules (mvp28): per-rule replay of this round's values rules (verify.VALUES_RULES_R28), for the record. On the
limits key's four saved sample runs (v3b fresh, v3c first = runs/v3c, v3c final = runs/v3c2, v4c) and the seven half A
runs, every saved form is checked with the default values mode (last round's rules) and with each r28 rule on alone,
on with its repair partners, and all r28 rules on. Every sentence whose verdict (kept or refused) flips against the
default is listed with its hand truth where one exists; a change of reasons only is listed apart. Modes are built with
verify.values_mode(rules=...), never the env. No model call. usage: python3 -B per_rule.py > per_rule.txt"""
import json
import os
import re
import lib28 as L
import attr28 as AT

V = L.V
S = L.S
LIM = {"v3b": os.path.join(S, "mvp28/limits/runs/v3b"), "v3c_first": os.path.join(S, "mvp28/limits/runs/v3c"),
       "v3c_final": os.path.join(S, "mvp28/limits/runs/v3c2"), "v4c": os.path.join(S, "mvp28/limits/runs/v4c")}
L.RUNS.update(LIM)
RUNS = tuple(LIM) + L.SEVEN
BASE = V.VALUES_RULES
R28 = sorted(V.VALUES_RULES_R28)
REPAIR = {"row_quote", "rows_before", "screen_uncited", "outcome_cited", "page_cited", "shown_said", "rows_kept"}
# the partners of each rule: the repair rules that narrow or complete it, and the rules a rule needs to act at all
# (read off the code's gates: rows_kept acts only with rows_shown; the shown rules act only with a count rule)
COUNT = {"item_count", "item_count_free", "cards_found"}
PARTNERS = {
    "item_count": {"shown_said", "rows_shown", "rows_kept"},
    "item_count_free": {"shown_said", "page_cited", "rows_shown", "rows_kept"},
    "cards_found": {"rows_before", "rows_shown", "rows_kept"},
    "rows_shown": COUNT | {"shown_said", "page_cited", "rows_before", "rows_kept"},
    "row_text": {"row_quote"},
    "screen_window": {"screen_uncited"},
    "cited_rows": {"rows_before"},
    "row_group": {"rows_before"},
    "outcome_you": {"outcome_cited"},
    "row_quote": {"row_text"},
    "rows_before": {"cited_rows", "row_group", "cards_found", "rows_shown", "rows_kept"},
    "screen_uncited": {"screen_window"},
    "outcome_cited": {"outcome_you"},
    "page_cited": {"item_count_free", "shown_said", "rows_shown", "rows_kept"},
    "shown_said": {"item_count", "item_count_free", "rows_shown", "rows_kept"},
    "rows_kept": COUNT | {"rows_shown", "shown_said", "page_cited", "rows_before"},
}
assert set(PARTNERS) == set(R28) and all(p <= V.VALUES_RULES_R28 for p in PARTNERS.values())
CONFIGS = [("default", BASE)]
for r in R28:
    CONFIGS.append((f"{r} alone", BASE | {r}))
    CONFIGS.append((f"{r} +partners", BASE | {r} | PARTNERS[r]))
CONFIGS.append(("all r28", BASE | V.VALUES_RULES_R28))
MODES = {n: V.values_mode(rules=rs) for n, rs in CONFIGS}
# the settled false sentences of mvp27/tally/report.txt 5a (both readers agree), by their quoted words
SETTLED_TEXT = {("base1", "N044.0"): "These 5 are the newest of the 72 food and cooking items",
                ("base2", "N044.0"): "here are 5 of the 72 food and cooking items",
                ("arm1", "N044.0"): "These 5 are from your 72 food and cooking items",
                ("base1", "N044.1"): "Here are the next 5 of the 72 food and cooking items",
                ("base2", "N048.1"): "Two of your saved sourdough items mention flour",
                ("base2", "N049.0"): "Your first open of a video with integrals in the title"}
MK = AT.marks()

# speed only: the full and cells checks a values check computes for its flags are the same under every rule set of a
# form, so they are computed once per form (flags are not compared here; kept and reasons never read them)
_CA = V.check_answer
_MEMO = {}


def _check_answer_memo(form, ledger, turn=None, mode=None):
    if mode is V.FULL or mode is V.CELLS:
        key = (mode.name, json.dumps(form.model_dump() if hasattr(form, "model_dump") else form, sort_keys=True,
                                     default=str), id(turn))
        if key not in _MEMO:
            _MEMO[key] = _CA(form, ledger, turn, mode=mode)
        return _MEMO[key]
    return _CA(form, ledger, turn, mode=mode)


V.check_answer = _check_answer_memo


def truth(run, key, fi, where, idx, text):
    tr, _ = L.truth_of(run, key, fi, where, idx) if run in L.TRUTH else (None, None)
    if tr:
        return f"{tr} (recount)"
    m = MK.get((run, key, fi, where, idx))
    if m:
        return f"{m} (marks28)"
    q = SETTLED_TEXT.get((run, key))
    if q is not None:
        return "F (settled 5a)" if q.lower() in V.strip_markers(text).lower() else "? (message settled false, not this sentence)"
    return "-"


def verdict(o):
    return "kept" if o.kept else "refused " + "+".join(o.reasons)


def main():
    flips, reason_only, per_cfg = {}, {}, {n: [0, 0] for n, _ in CONFIGS[1:]}
    n_forms = {}
    n_sent = {}
    for run in RUNS:
        n_forms[run] = n_sent[run] = 0
        for rec, t, results in L.inputs(run):
            vt = V.Turn.of(t)
            for fi, f in enumerate(rec.get("forms") or []):
                n_forms[run] += 1
                _MEMO.clear()
                vs = {n: V.check_answer(f, results, vt, mode=m) for n, m in MODES.items()}
                base = vs["default"]
                n_sent[run] += len(base.outcomes)
                for pos, ob in enumerate(base.outcomes):
                    k = (run, rec["key"], fi, ob.where, ob.index)
                    for n, _ in CONFIGS[1:]:
                        o = vs[n].outcomes[pos]
                        assert (o.where, o.index) == (ob.where, ob.index)
                        if o.kept != ob.kept:
                            flips.setdefault(k, {"text": ob.text, "default": verdict(ob), "by": []})["by"].append(
                                (n, verdict(o)))
                            per_cfg[n][0] += 1
                        elif o.reasons != ob.reasons:
                            reason_only.setdefault(k, {"text": ob.text, "default": verdict(ob), "by": []})["by"].append(
                                (n, verdict(o)))
                            per_cfg[n][1] += 1
    print(__doc__.split("usage")[0].strip())
    print()
    print("Default rules:", ", ".join(sorted(BASE)))
    print("Partners (each rule is also run with these on):")
    for r in R28:
        inert = " [inert alone by construction]" if r in REPAIR or r == "rows_shown" else ""
        print(f"  {r}: {', '.join(sorted(PARTNERS[r]))}{inert}")
    print()
    print("Saved forms and sentences per run:")
    for run in RUNS:
        print(f"  {run}: {n_forms[run]} forms, {n_sent[run]} sentences")
    print(f"  all: {sum(n_forms.values())} forms, {sum(n_sent.values())} sentences")
    print()
    print("Sentences flipped (kept <-> refused) against the default, per configuration (flips; reason-only changes):")
    for n, _ in CONFIGS[1:]:
        print(f"  {n:28s} {per_cfg[n][0]:3d} flips; {per_cfg[n][1]} reason-only")
    print()
    print("Flips by run:")
    for run in RUNS:
        ks = [k for k in flips if k[0] == run]
        print(f"  {run}: {len(ks)} sentences flip under some configuration")
    print()
    print("EVERY SENTENCE WHOSE VERDICT FLIPS (run message form place | hand truth | default -> configurations)")
    for k in sorted(flips, key=lambda k: (RUNS.index(k[0]), k[1:])):
        d = flips[k]
        run, key, fi, where, idx = k
        tr = truth(run, key, fi, where, idx, d["text"])
        print(f"\n{run} {key} f{fi} {where}{idx} | truth {tr} | default: {d['default']}")
        print(f"    {V.strip_markers(d['text'])[:220]}")
        groups = {}
        for n, vv in d["by"]:
            groups.setdefault(vv, []).append(n)
        for vv, ns in groups.items():
            print(f"    -> {vv}: {', '.join(ns)}")
    print()
    print("REASON-ONLY CHANGES (the verdict stays; the codes differ)")
    for k in sorted(reason_only, key=lambda k: (RUNS.index(k[0]), k[1:])):
        d = reason_only[k]
        run, key, fi, where, idx = k
        groups = {}
        for n, vv in d["by"]:
            groups.setdefault(vv, []).append(n)
        print(f"{run} {key} f{fi} {where}{idx} | default: {d['default']} | " +
              "; ".join(f"{vv}: {', '.join(ns)}" for vv, ns in groups.items()))


if __name__ == "__main__":
    main()
