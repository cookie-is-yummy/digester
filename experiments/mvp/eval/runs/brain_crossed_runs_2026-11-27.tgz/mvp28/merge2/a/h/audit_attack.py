"""attack 8: eval_claims.audit_ledger of the tip against the tree's on every sentence of every saved verdict (kept or
not, every form) of run1 and the seven runs, every row (ok or not). Also the in-run path (audit_sent) as audit28 does.
Prints each difference and whether the tip crashed on it."""
import glob, json, os, sys, collections
os.environ.setdefault("VALUES_TREE", "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/rules_tree")
import lib28 as L
from mvp import eval_brain as E
import mvp.eval_claims as ECR
ECT = L._load(os.path.join(L.HERE, "base", "eval_claims_tip.py"), "mvp.eval_claims_tip", pkg="mvp")
RUNS = {"run1": os.path.join(L.S, "mvp24/runa/run1")}
RUNS.update({k: L.RUNS[k] for k in L.SEVEN})
if "--r28" in sys.argv:
    import glob as _g
    RUNS = {os.path.relpath(d, L.S): d for d in sorted(_g.glob(os.path.join(L.S, "mvp28/limits/runs/*/")) +
            _g.glob(os.path.join(L.S, "mvp28/speed/arms/*/")) + _g.glob(os.path.join(L.S, "mvp28/speed/full/*/")) +
            _g.glob(os.path.join(L.S, "mvp28/merge/smoke_brain_v*/")))}


def rows_of(ec, lib, text, results, calls, q):
    try:
        return [{k: r.get(k) for k in ("audit", "kind", "where", "said", "recount", "ok", "severity", "note")}
                for r in ec.audit_ledger(lib, ec.cited_cells(text), results, calls, q, E.TODAY)]
    except Exception as e:  # noqa: BLE001
        return ("CRASH", type(e).__name__, str(e)[:80])


def main():
    h = L.harness()
    n = sents = 0
    kinds = collections.Counter()
    for run, d in RUNS.items():
        for p in sorted(glob.glob(os.path.join(d, "N*.json"))):
            rec = json.load(open(p))
            if "message" not in rec or "calls" not in rec:
                continue
            n += 1
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid")}
            calls = E.calls_of(rec)
            unlock = rec["unlock"] if "unlock" in rec else h.turn(rec["message"]).unlock
            lib = h.audit_lib_for(unlock)
            texts = []
            for v in rec.get("verdicts") or []:
                for o in v.get("outcomes") or []:
                    if o.get("text") and o["text"] not in texts:
                        texts.append(o["text"])
            for text in texts:
                sents += 1
                a = rows_of(ECT, lib, text, results, calls, rec["message"])
                b = rows_of(ECR, lib, text, results, calls, rec["message"])
                if json.dumps(a, default=str, sort_keys=True) != json.dumps(b, default=str, sort_keys=True):
                    crashed = isinstance(a, tuple)
                    kinds["tip crashed" if crashed else "tip completed, rows differ"] += 1
                    print(("CRASHED-ON-TIP " if crashed else "DIFF-NO-CRASH ") + run, rec["key"], "|", text[:160])
                    if not crashed:
                        sa = {json.dumps(x, sort_keys=True, default=str) for x in a}
                        sb = {json.dumps(x, sort_keys=True, default=str) for x in b}
                        for x in sorted(sa - sb): print("   tip only ", x)
                        for x in sorted(sb - sa): print("   tree only", x)
                    else:
                        print("   tip", a, "\n   tree", b)
    print(f"records {n}, sentences {sents}: {dict(kinds)}")


if __name__ == "__main__":
    main()
