"""rules (mvp28): the default values mode of the rules tree against the tip's (8b9440e, git show into base/) values
mode, on every saved form of run1 and the seven half A runs (look1/look2 not loaded). Compared per sentence: kept,
reasons, details, notes, sent, cells, flags, hidden_rank, layer; per form: repair, lead_ok, items, private_line,
outside, chart, form_error, repair_message. Then the default against the saved live verdicts of the six runs that ran
values live (kept and reasons). Env: VALUES_TREE (the tree), MVP_BRAIN_VALUES_RULES must be unset for the default.
With an argument OUT.json the default per-sentence verdicts are written. No model call."""
import json, os, sys
import lib28 as L

V, VT = L.V, L.VT
LIVE = ("runA", "runB", "base1", "base2", "arm1", "arm2")


def o_key(o):
    return {"where": o.where, "index": o.index, "text": o.text, "kept": o.kept, "reasons": list(o.reasons),
            "details": list(o.details), "notes": dict(o.notes), "sent": o.sent, "cells": dict(o.cells),
            "flags": list(o.flags), "hidden_rank": o.hidden_rank, "layer": o.layer, "rid": o.rid}


def v_key(mod, v):
    return {"outcomes": [o_key(o) for o in v.outcomes], "repair": v.repair, "lead_ok": v.lead_ok, "items": v.items,
            "private_line": v.private_line, "outside": v.outside, "chart": v.chart, "form_error": v.form_error,
            "check": v.check, "repair_message": mod.repair_message(v)}


def main():
    print("tree:", L.TREE, "| env:", repr(os.environ.get("MVP_BRAIN_VALUES_RULES")))
    print("V.VALUES.rules:", sorted(V.VALUES.rules))
    print("VT.VALUES.rules:", sorted(VT.VALUES.rules))
    forms = sents = diff_f = diff_s = 0
    live_n = live_d = 0
    live_diffs, out = [], {}
    for run in ("run1",) + L.SEVEN:
        rf = rs = df = ds = ln = ld = 0
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                vm = V.check_answer(f, results, V.Turn.of(t), mode="values")
                vt = VT.check_answer(f, results, VT.Turn.of(t), mode="values")
                a = json.dumps(v_key(V, vm), sort_keys=True, default=str)
                b = json.dumps(v_key(VT, vt), sort_keys=True, default=str)
                rf += 1
                rs += len(vm.outcomes)
                if a != b:
                    df += 1
                    for om, ot in zip(vm.outcomes, vt.outcomes):
                        if json.dumps(o_key(om), sort_keys=True, default=str) != \
                                json.dumps(o_key(ot), sort_keys=True, default=str):
                            ds += 1
                            print(f"  DIFF {run} {rec['key']} f{fi} {om.where}{om.index}: tip {ot.kept} {ot.reasons}"
                                  f" -> tree {om.kept} {om.reasons}")
                    if len(vm.outcomes) != len(vt.outcomes):
                        print(f"  DIFF {run} {rec['key']} f{fi}: outcome count {len(vt.outcomes)} -> {len(vm.outcomes)}")
                    elif ds == 0:
                        print(f"  DIFF {run} {rec['key']} f{fi}: form-level field")
                for o in vm.outcomes:
                    out[f"{run}|{rec['key']}|{fi}|{o.where}|{o.index}"] = [o.kept, list(o.reasons), o.text]
                if run in LIVE and rec.get("verdicts") and fi < len(rec["verdicts"]):
                    saved = {(o["where"], o["index"]): (o["kept"], list(o["reasons"]))
                             for o in rec["verdicts"][fi]["outcomes"]}
                    for o in vm.outcomes:
                        ln += 1
                        s = saved.get((o.where, o.index))
                        ot = next((x for x in vt.outcomes if (x.where, x.index) == (o.where, o.index)), None)
                        if s != (o.kept, list(o.reasons)):
                            ld += 1
                            live_diffs.append(f"  LIVE {run} {rec['key']} f{fi} {o.where}{o.index}: live {s} -> "
                                              f"default {(o.kept, list(o.reasons))}; tip gives "
                                              f"{(ot.kept, list(ot.reasons)) if ot else None}\n      {o.text[:160]}")
        print(f"{run}: forms {rf}, sentences {rs}, forms differing from tip {df}, sentences differing {ds}"
              + (f"; live sentences {ln}, differing from live {ld}" if run in LIVE else ""))
        forms += rf; sents += rs; diff_f += df; diff_s += ds; live_n += ln; live_d += ld
    print(f"TOTAL: forms {forms}, sentences {sents}; against the tip: forms differing {diff_f}, sentences differing "
          f"{diff_s}")
    print(f"LIVE (six runs that ran values live): sentences {live_n}, differing from the saved live verdict {live_d}")
    for x in live_diffs:
        print(x)
    if len(sys.argv) > 1:
        json.dump(out, open(sys.argv[1], "w"))


if __name__ == "__main__":
    main()
