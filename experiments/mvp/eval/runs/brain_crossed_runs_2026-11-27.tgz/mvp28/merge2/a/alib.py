"""attack (mvp28): one harness. V = the checker of the attack worktree (brain-r28-local abc2486), VT = the tip's
(experiments/search-loop 8b9440e, from `git show` into base/). Turns are built on the made-up library through the tools.
No model call."""
import importlib.util
import json
import os
import sys

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
TREE = os.environ.get("VALUES_TREE") or os.path.join(S, "mvp28", "merge_tree")
PIN = os.path.join(TREE, "experiments")
sys.path.insert(0, PIN)
import mvp.brain  # noqa: E402,F401
from mvp.brain import verify as V  # noqa: E402
assert V.__file__.startswith(PIN), V.__file__


def _load(path, name, pkg="mvp.brain"):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    m.__package__ = pkg
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


VT = _load(os.path.join(HERE, "base", "verify_tip.py"), "mvp.brain.verify_tip")
_H = None


def harness():
    global _H
    if _H is None:
        base = os.path.join(HERE, "_lib")
        os.makedirs(base, exist_ok=True)
        from mvp import eval_brain as E
        _H = E.Harness.scratch(base=base)
    return _H


def turn(message, calls, screen="", **kw):
    from mvp.brain import tools as TL
    t = harness().turn(message, screen=screen, **kw)
    for tool, args in calls:
        TL.call(t, tool, args)
    return t


def results(t):
    return {rid: r for rid, r in t.results.items()}


def check(mod, form, t, mode="values"):
    return mod.check_answer(form, results(t), mod.Turn.of(t), mode=mode)


def outcome(v, where):
    kind, _, n = where.partition(":")
    os_ = [o for o in v.outcomes if o.where == kind]
    if kind == "lead":
        return bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons}), \
            sorted({f.get("code") if isinstance(f, dict) else str(f) for o in os_ for f in (getattr(o, "flags", []) or [])})
    o = next((o for o in os_ if o.index == int(n or 0)), None)
    return bool(o and o.kept), (list(o.reasons) if o else ["missing"]), \
        sorted({f.get("code") if isinstance(f, dict) else str(f) for f in (getattr(o, "flags", []) or [])}) if o else []
