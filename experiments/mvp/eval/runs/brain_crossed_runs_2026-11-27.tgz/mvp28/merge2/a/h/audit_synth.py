import os, json
os.environ.setdefault("VALUES_TREE", "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/rules_tree")
import lib28 as L
from mvp import eval_brain as E
from mvp.brain import tools as TL
import mvp.eval_claims as ECR
ECT = L._load(os.path.join(L.HERE, "base", "eval_claims_tip.py"), "mvp.eval_claims_tip", pkg="mvp")
h = L.harness()
args = {"against": "previous", "level": "channel", "scope": {"how": "opened"}, "window": {"words": "this fall"}}
t = h.turn("new channels i picked up this fall")
TL.call(t, "changes", args)
res = t.results
calls = {"r1": {"tool": "changes", "args": args}}
lib = h.audit_lib_for(None)
for s in ("It was first opened on its first day[r1.new.small_channels[0].first_watched].",
          "It was first opened in the fall[r1.new.small_channels[0].first_watched].",
          "It was first opened on 12 October 2026[r1.new.small_channels[0].first_watched]."):
    for name, ec in (("tip", ECT), ("tree", ECR)):
        try:
            rows = [(r["kind"], r["ok"], r.get("severity")) for r in ec.audit_ledger(lib, ec.cited_cells(s), res, calls, "", E.TODAY)]
        except Exception as e:
            rows = ("CRASH", type(e).__name__)
        print(name, rows, "|", s)
