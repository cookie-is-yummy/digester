
### 30.8 The prep round before the blind run (mvp28: keys rules, limitonly, args, merge2)
Three branches from `brain-r28-local` (9ff2fba), merged in by merge commits: `brain-rules-local`,
`brain-limitonly-local` and `brain-args-local`. Evidence is in the scratchpad's `mvp28/rules/`, `mvp28/limitonly/`,
`mvp28/args/` and `mvp28/merge2/`, with a progress file for each key. Spend: rules $0, limitonly $0.302097, args
$0.022279, merge2 $0.035637 (point 5). The rule for the next run (prompt crossed with strict) is in DECISIONS.md, the section
of 26 Nov 2026 on experiments/search-loop. This part does not restate it.

**1. This round's values rules are off by default (key rules).** `verify.VALUES_RULES` is last round's four rules
again: `row_name`, `cell_found`, `day_typed`, `motive_you`. The 16 rules of 30.2 and 30.7 stay in the code as
`VALUES_RULES_R28` (`VALUES_RULES_ALL` is the union). `MVP_BRAIN_VALUES_RULES` switches them on: a comma list of rule
names, or `r28` for all. It is read once, at import; a name that is not a values rule raises. `item_count` is a refuse
code only when its rules are on (`VALUES_REFUSE_R28`). A values run of the eval writes `values_rules` and
`values_rules_r28` in its settings and on every record.
Why: on the v3c and v4c sample runs the rules changed no verdict, and the independent attack showed more false
sentences getting out with them and honest page counts refused (DECISIONS.md, 26 Nov). After the blind run each rule
is replayed alone on the saved forms and kept only if it flips a sentence the readers settled.
Measured, no model call: on every saved form of run1 and the seven half A runs (553 forms, 1,546 sentences) the
default verdicts equal the tip's values mode in every field, 0 differ. With `r28` they equal the merged build's
verdicts, 0 differ. Per rule on 11 runs, all r28 rules on flip 20 sentences: 13 refused become kept (12 marked true by
hand), 7 kept become refused (6 marked false by hand). One flip goes against the truth (`item_count_free` alone
refuses a true "next 5"). On v3c final and v4c no configuration flips anything. The truth marks of the limits runs are
one reader's; the half A runs are in sample.

**2. Limit-only answers: the cause was the loop (key limitonly).** In the records of ten runs (595 turns) the three
limit-only turns were the only turns with no read result in hand. Each had one read come back as an error, or its
first request alone ran to 7 s; code then refused the next read with "time is up, answer with the results you already
have". There were none. In one turn the model then said it "couldn't pull" the history, when code had refused the
read. The fix is in `brain/loop.py`, and one test decides it: is any call's result not an error.
- No result in hand, past the soft or deep deadline, before the hard stop: the round runs (event `first_result_late`).
- Out of rounds with no result in hand: the turn ends with code's lead, fallback's existing plain line (event
  `no_result`). No new text was written.
- With a result in hand nothing changed: the one time-up, the round limit, the call cap and the hard stop.
Two prompt lines of v3c and v4c changed, no example: a limit is "never as the opener unless they ask about it", and a
number of items shown is said "only when items holds every row ...; never over a longer list". The v3c to v4c diff is
still the four meaning hunks. On the same 52 messages (one run per prompt, in sample): limit-only answers 1 and 2
before, 0 and 0 after; unwanted limit answers 1 and 5 before, 4 and 4 after (noise: the same messages recur); medians
7.46 s (v3c) and 7.34 s (v4c), p90 10.27 s and 9.19 s. The late round costs time: one turn took 13.7 s and 15.1 s.
`no_result` fired 0 times in 208 live turns; only a fake-provider test covers it, and its plain line carries no limit
line (`answer.build` drops code's limit lines under it).

**3. The model's tool arguments are checked by code (key args).** With strict tool grammar off
(`MVP_BRAIN_STRICT=0`), nothing held the model to the schema, and the argument models silently defaulted a missing
key (39 of 358 bad cases) or coerced a value (33; `true` read as 1, so weekday `true` became Tuesday). A wrong scope
from a defaulted argument is a wrong answer no value check can see. Now `tools.call(..., sent=True)`, which the loop
uses for any provider that says its grammar (a `strict` attribute, on or off), checks the arguments against
`schema(name)`, the schema sent to the model. An unknown or missing key, a wrong type, a value outside an enum or a
string where a list is due is refused with one error that names every bad argument and what it allows
(`outside_schema`). The model can call again. A call inside the schema runs as before: on 1,188 saved calls replayed
in order, the only differences from the tip are 3 calls of the strict-off speed run, each a breakdown that left out
`order`, now refused. The offline fake providers have no `strict` attribute and are not held. Not closed:
`give_answer` (unknown keys dropped, fields defaulted), and integer bounds, which the sent schema does not carry (the
argument models still refuse them). The eval now counts tool errors by kind per record and per run (`tool_args`),
records `strict` for the read tools, and keeps a record with `audit_error` when the auditor raises (the run then exits
1). Live check: 12 half A messages, strict off, brain_v3b, $0.0223: one refusal (the left-out `order` again), the next
round sent it whole, about 1 s more on that turn.

**4. The merge's seam.** A call refused outside the schema is an error, so a turn whose only call was refused has no
result in hand. Past the soft deadline its next round now runs (`first_result_late`) instead of getting time-up. The
args key's counter `arg_error_then_time_up` would miss that case, so `tool_args` also counts `first_result_late` and
`no_result` per record and lists `arg_error_then_late` per run (an argument error with any of the three events). A
test pins the path with a held fake provider and a fake clock (`test_brain_r28_limitonly.py`). Nothing else changed
outside the three branches' own content but this section, the corrections in 30.2, 30.6 and 30.7, and the README.

**5. Checks on the merged tree.** All on the final tree, against experiments/search-loop. Its tip (cd0f7ba) differs from
8b9440e only in DECISIONS.md, so the tip copies of the code are the same files.
- Full and cells: the repair's differential without the held-out runs (look1, look2 and rc2 left out): 4,598
  verdicts, 0 differ; the code lead, both answer builds and `verdict_json`: 2,130 form-modes, 0 differ.
- Values, by default: on every saved form of run1 and the seven half A runs (553 forms, 1,546 sentences), 0 differ
  from the tip's values mode in any field. Against the saved live verdicts of the six runs that ran values live,
  3 of 1,119 differ, all in run B; the tip gives the same three (last round's rules came after run B ran).
- `python3 -m mvp.brain.planted` full, cells and values, and `eval_brain.py planted` with `MVP_BRAIN_CHECK` full,
  cells and values: byte for byte what the tip prints (eval_brain planted exits 1 in cells and values on both).
- Tool results: every saved call of the seven half A runs and the speed runs replayed in order through the model's
  path (1,188 calls): the seven runs' 612 calls give byte-same results. The only differences are the 3 strict-off calls
  of 3 above, now refused.
- Today's bot: the dry self-test, 164 of 164 steps, $0. Its output is the tip's but for the build id (2 lines), the
  fake sign-in's ids (2 lines) and the summary line. `demo/test_demo.py`: 10 passed.
- Live smokes, `--set fresh --half a --limit 4 --check values`, one per cell, $0.035637 in all. Each ran end to end,
  the audit completed with no `audit_error`, and the summary shows `strict` (true or false as set),
  `values_rules` (last round's four), `values_rules_r28` (empty) and the new `tool_args` counters. Every lead was the
  model's and every sentence was kept. Each run made 6 calls, with 1 tool error (a window after the export end) and
  0 argument or form errors. Seconds, median and p90, on 4 messages:

| | strict on | strict off |
|---|---|---|
| brain_v3c | 9.22 / 12.31 | 8.77 / 9.47 |
| brain_v4c | 10.36 / 13.32 | 7.79 / 10.74 |

  At n = 4 these say nothing about the bars.
- The whole suite in 4 shards: SUITE_LINE

**6. What the blind run will decide.**
- Prompt (v3c or v4c) and strict (on or off), by the rule written in DECISIONS.md before the runs.
- Whether false sentences fall with the rules off and the prompt's count line on. Nothing saved shows it.
- Which of this round's values rules come back: each replayed alone on the run's saved forms, kept only if it flips a
  sentence the readers settled as true or false.
- Whether a refused argument near the soft deadline costs speed or answers: the run counts every refused call.
- In sample: the limitonly figures (one run per prompt), the rules' truth marks, and the args table, built on the
  made-up library. The older ablation scripts in the scratchpad compute `VALUES_RULES - {...}`; on this branch that is
  the default set, so they would measure nothing. They need `VALUES_RULES_ALL`.
