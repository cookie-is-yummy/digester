# limits progress (mvp28)

- step 0: worktree made at /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp28/limits_tree, branch brain-limits-local from 8b9440e. Evidence dir mvp28/limits/.
- step 1: sample fixed BEFORE any v3c output (tools/pick.py, mvp28/limits/sample.txt): 11 targets, 30 messages with a
  limit sentence (wide) or a left_out citation in base1/base2, N044 N048 N049, 10 controls (every conversation with no
  limits talk, no private line, no code limit line in any of the four runs4 runs; N019 left out: auditor crash).
  37 conversations: N001,N007,N010,N012,N013,N014,N016,N018,N022,N024,N027,N034,N035,N036,N038,N041,N042,N044,N045,N048,N049,N052,N053,N054,N055,N056,N057,N062,N063,N064,N066,N067,N068,N069,N109,N112,N113
- step 2: diagnosis written (see report). v3c built by tools/make_v3c.py (exact replacements on v3b), v4c by
  tools/make_v4c.py (the 4 hunks of v3b->v4_meaning applied to v3c; hunks equal with line numbers out, normal diffs
  equal: v3b_to_v4_meaning.diff, v3c_to_v4c.diff). Tokens (count, free): prefix v3b 13277, v3c 13255; system 6696 / 6674.
  Test file tests/test_brain_r28_prompts.py: 9 passed.
- step 3, BEFORE any v3c output: which sample messages should say a limit (asked about the missing thing):
  WANTED (13): N038.0 N042.0 N113.0 (likes), N067.0 N066.0 (after the export ends), N066.1 (asks when it stops),
  N055.0 N109.0 (friends' posts), N052.1 (why missing: the private count), N056.0 (how far watched), N062.0 (before
  history starts), N063.0 N064.0 (part of a period the tool cannot read: said once that the whole period is given).
  CODE SAYS IT (model need not): N057.0 (watch time line). ALLOWED, NOT NEEDED: N036.0 (Instagram ends 15 Oct, an
  October count). NOT A LIMIT: N053.0 (the unlocked private topic is the subject; "private" hits the wide counter).
  Every other sample message: a limit sentence or a left_out citation there is unwanted.
  MISS (triggers the one revision): a wanted limit absent in 2+ of the 13 where fresh v3b says it; unwanted limit
  sentences (wide, lead+points) not at least halved against fresh v3b; a left_out cell cited on a message not in
  N052.1/N055.0/N109.0; a shown-count over fewer cards (count marker or "here are/next N" against cards) on N044;
  a new false sentence on a target.
  Extra counter: shown count vs cards (tools/cards28.py).
- step 4: fresh v3b sample run done (runs/v3b, exit 0)
- step 5: v3c sample run done (runs/v3c, exit 0). Spend so far: v3b $0.077689, v3c $0.07325 (ledger)
- step 6: v3c (first) read by hand: limits cut (unwanted 12 -> 5 answers, left_out not asked 8 -> 1), wanted kept
  12/13 (N064.0 the tool read "mid 2023" itself: no limit needed in either run). MISSES: N044.0 still drops the
  forged-title item and says "five" over 4 cards (my counter missed number words: fixed in m28.py); N057.0 watch time
  said beside code's line; N055.0 copies "not counted" and says the friend count twice; N068.0/N054.0 left_out unasked.
  First version kept as mvp28/limits/brain_v3c_first.md (+ tools/make_v3c_first.py).
- step 7: ONE revision (tuned on this sample): item rule moved to Items ("never leave out a row for its title ...",
  "a number of items you show, in digits or words"), watch time "not even that it is missing", friends "counted, never
  shown" and "never otherwise"; titles line back to v3b's words; two repeating lines cut. Tokens v3c 13235 (v3b 13277),
  v4c 13381 (v4_meaning 13423). Tests pass.
- step 8: revised v3c run (runs/v3c2, $0.075342): unwanted limit answers 12 (v3b fresh) -> 1, left_out unasked 8 -> 0, wanted 12 -> 11 of 13 (N063.0: the tool now reads 'late October' itself, no limit needed; N064.0 same), no shown-count fault, N044.0 lists the forged item (5 cards). Regression seen: N067.0 lead is the limit only (after a reword), no October figure.
- step 9: v4c sample run (runs/v4c, $0.074671). Total live spend $0.300952 (ledger rows of the four runs). Limit-only answers (new counter limonly.py): 0 in six earlier runs; v3c2 N067.0 (+N066.1, which asks the end date); v4c N112.0 (no tool call at all) and N113.0.
- step 10: brain tests 576 passed in four shards (tools/shard_brain.sh); committed 37ea294 on brain-limits-local; summary.txt written.
- step 11: free checks (extra28.txt): limit-only answers all time_up; caveats added to summary.txt. Done.
