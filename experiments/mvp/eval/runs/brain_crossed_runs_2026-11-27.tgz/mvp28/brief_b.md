# Brief B: the build made ready for the blind run (mvp28, prep round)

Read S/mvp28/brief.md first (S = /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad).
All its rules hold here. This file adds what the build round found and what was decided after it.

## What the build round gave (branch brain-r28-local, tip 9ff2fba, not pushed)
- Reports: S/mvp28/limits_progress.md, checks_progress.md, speed_progress.md, merge_progress.md, attack_progress.md,
  repair_progress.md, and experiments/mvp/DESIGN.md section 30 on that branch. Evidence under S/mvp28/<key>/.
- Prompts brain_v3c.md (limits talk cut, the items field explained) and brain_v4c.md (v3c plus the meaning hunks).
  On a 52-message half A sample: unwanted limit sentences 12 -> 1 (v3c), 5 (v4c); a shown count above the cards 1 -> 0.
- The auditor crash is fixed (eval_claims reads cells by value).
- Speed: requests are streamed with an exact wall clock; the eval warms the client. These do not move the bars.
  MVP_BRAIN_STRICT=0 (strict tool grammar off on the nine read tools) saves about 0.7 s a request and met both
  bars in one run (median 6.46 s, p90 9.46 s). It is off by default and needs the blind run.
- Values-mode rules added this round (item_count, item_count_free, cards_found, rows_shown, row_text, screen_window,
  cited_rows, row_group, outcome_you, then the repair's row_quote, rows_before, screen_uncited, outcome_cited,
  page_cited, shown_said, rows_kept).

## Decided after the round
1. This round's values rules do NOT go into the blind run switched on. Reasons: on the v3c and v4c sample runs they
   changed 0 verdicts; the independent attack showed leaks rising (false sentences out: 2 -> 15 of 42 on the
   row-text set, 4 -> 8 of 39 on the others) and 11 of 12 honest page counts refused; the repair was written
   against the attacker's own sets. The same pattern as the cells mode. So the values check of the run is last
   round's rule set (row_name, cell_found, day_typed, motive_you). The new rules stay in the code behind a switch,
   off by default. After the blind run each is replayed alone on the saved forms and kept only if it flips a
   sentence the readers settled as true or false. No exception for the marker form of the count check: it refuses
   honest page counts ("The list gave 5[r1.items.count]; the ones below ..." over 2 cards).
2. Limit-only answers block the run. Three turns answered with a limit alone after a tool error and the 7 s soft
   deadline (events hold time_up): N067.0 under v3c, N112.0 and N113.0 under v4c. N112.0 made no read call and said
   "I couldn't pull your Instagram history", which is false. None in the six runs before, though time_up fired there.
3. The next run crosses the prompt (v3c, v4c) with strict (on, off). Strict off is safe only if code itself refuses
   a tool argument outside the schema; a silently defaulted argument returns the wrong scope and no value check
   sees it.
4. The plans set's held-out half is out of sample for the prompt only. It was run live in mvp20 and S/mvp27/prep's
   lib27.py (and lib28 copies) load two of those runs (look1, look2) and the rc2 set built on them. Do not load
   them: use the repair's harness copy that drops them, or drop them yourself.

## Extra rules for this round
- Worktrees start from brain-r28-local (9ff2fba), not from experiments/search-loop:
  `git -C /home/user/digester worktree add -b <branch> <path> brain-r28-local`.
- Never run a recursive grep over experiments/mvp/eval or experiments/mvp/evalset, or over experiments/mvp as a
  whole, without `--exclude=brain_fresh_b.py --exclude=brain_fresh.jsonl`. Four agents slipped on this last round.
- Code comments and test names do not name eval messages (N044 and the like). Say the class of case instead.
