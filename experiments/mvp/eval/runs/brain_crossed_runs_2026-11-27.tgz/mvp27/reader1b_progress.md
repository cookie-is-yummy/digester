# reader1b progress
- step 1: read brief, rubric, DECISIONS; packet has 22 messages x 7 answers = 154. Next: facts script.
- step 2: facts.py/facts2.py written and run (facts.txt); read messages 1-20; marking in progress
- step 3: all 22 messages read; facts verified; writing marks.json via make_marks.py
- step 4: marks.json (154) and best_per_message.json written; grades 64 good / 50 acceptable / 40 poor. Next: advisor check, then report.
- step 5: advisor fixes applied (rules.txt, facts3.py/txt, best_worst.json); final 61 good / 53 acceptable / 40 poor; 1 false, 30 wrongly based in 29. Packet privacy grep 0; git status clean. Done.
