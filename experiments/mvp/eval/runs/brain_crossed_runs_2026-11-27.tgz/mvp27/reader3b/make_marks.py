import json, re, sys
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
pk = json.load(open(f"{S}/mvp27/blind/group3.json"))
G, A, P = "good", "acceptable", "poor"
# code: (grade, false_n, wb_n, answers, means, more, offer, brief, limits_talk, poor_cause, note)
M = {
"N002.0": {
 "qa2": (G,0,0,"y","y","y","y","y",0,None,"All true (gaming 319/719=44.4%, art 25.5%, math 20.2%, Minecraft 163 all Brick Realm, 50 private). 'alone' reads the figure; private count is a useful extra."),
 "d8o": (A,0,0,"y","n","n","y","y",0,None,"True; a list of shares with 'came next', no reading of what it says about them."),
 "v28": (A,0,0,"y","n","n","y","y",0,None,"True (319/719, 183, 163, math 20%, cooking 10%); a fuller list, still no reading."),
 "gue": (A,0,0,"y","n","n","y","y",0,None,"True; list of shares only."),
 "zbu": (A,0,0,"y","n","n","y","y",0,None,"True; 'came next' list."),
 "dxr": (A,0,0,"y","n","n","y","y",0,None,"True; 'came next' list."),
 "n6c": (A,0,0,"y","n","n","y","y",0,None,"True; list only."),
},
"N005.0": {
 "ad9": (P,0,0,"n","n","n","n","y",0,"misses the question","Ranking true (Brick Realm 163, Pixel Pencil 92, Wet Paper 91) but not what ran every year (Pan Theory/Home cooking); no offer."),
 "k47": (A,0,0,"y","y","y","n","y",0,None,"True: Home cooking 8 a year 2021-2025, 32 in 2026, all Pan Theory, 72; Minecraft 91/59/0/0. Best content; no offer."),
 "iiq": (A,0,0,"y","y","y","y","y",0,None,"True (8 in 2021 and 2025, Brick Realm 91/59/0). 'Pan Theory opened 8 videos' puts the person's act on the channel; clumsy, so not good."),
 "q4o": (P,0,0,"n","n","n","n","y",0,"misses the question","First dates true (5 Jan, 1 Mar, 1 Feb 2021) but 'goes back furthest' is not 'every year'; Brick Realm had none 2023-2025."),
 "suj": (P,0,0,"n","n","n","n","y",0,"misses the question","Same as a ranking answer: true, not the every-year question. 'By month?' adds nothing here."),
 "ab4": (P,0,1,"n","n","n","n","y",0,"misses the question","'Brick Realm is the longest-running one' (direction): it had no opens 2023-2025; Pan Theory is the one in every year. LENIENT-PASS: a lenient reader may read 'longest-running' as 'first started'. 163 of 723 true."),
 "bft": (P,0,0,"n","n","n","n","y",0,"misses the question","Totals true (723; 254 in 2026; 8 in 2024) but nothing on what ran every year."),
},
"N005.1": {
 "wkg": (A,0,0,"y","y","y","y","y",0,None,"True (126 in 2021, 72% Minecraft, 100 in 2022, 79 in 2026, 84% clips). Clumsy base '126 of what you opened in gaming'."),
 "zgp": (G,0,0,"y","y","y","y","y",0,None,"True. STRICT-COUNT: '126 gaming videos opened across all your history' could be read as a window fault; I read it as 'most gaming-heavy year of all your history' (R8)."),
 "v8a": (G,0,0,"y","y","y","y","y",0,None,"True: 126 of 134 (94%) is the heaviest share (2022 92.6%); Minecraft most of 2021-2022 gaming, clips in 2026."),
 "snq": (G,0,0,"y","y","y","y","y",0,None,"True; 'peaked', 84% clips in 2026."),
 "ozf": (A,0,0,"y","y","y","y","y",0,None,"True (126/134, 100/108, 79/254). Lead grammar 'gaming was the heaviest year' is clumsy."),
 "mva": (P,0,0,"n","n","n","n","y",0,"misses the question","Bare total 319 where they asked which year."),
 "tbo": (G,0,0,"y","y","y","y","y",0,None,"True (126, 100, 79, 134). STRICT-COUNT: 'across all your history' after the year's count, ruled as zgp (R8)."),
},
"N007.0": {
 "qcn": (G,0,0,"y","y","y","y","y",0,None,"True: Minecraft 91 of 134 in 2021, Speedruns 35 and none in 2026, Minecraft down to 13."),
 "y1l": (P,0,0,"n","y","n","y","y",0,"misses the question","True (134, 'nearly all' gaming 126, Minecraft 91=68%, Speedruns 35, cooking 8) but says nothing on what was dropped."),
 "ejs": (G,0,0,"y","y","y","y","y",0,None,"True: 13 = 5.1% of 254 in 2026; Speedruns not among the 6 themes of 2026; 'so it looks dropped'."),
 "z85": (A,0,0,"y","y","n","n","y",0,None,"True (67.9% to 5.1%; 26.1% to 0%). Offer 'And in 2021?' repeats the year just shown."),
 "fq7": (P,0,0,"n","n","n","n","y",0,"thin","One true sentence (91 in 2021); nothing on dropped; no offer."),
 "aea": (P,3,0,"n","n","n","y","y",0,"wrong fact","False: Digital drawing had no 2021 opens (its 92 are 2026); Gaming clips 66 and Watercolor 41 are 2026 figures; Calculus's 10 are 2026, none in 2021."),
 "umb": (P,0,0,"n","n","n","n","y",0,"thin","One true sentence (91 in 2021); nothing on dropped; no offer."),
},
"N019.0": {
 "nn8": (P,0,1,"y","n","n","y","y",0,"wrongly based","'the new channels you opened were Clip Factory ... and Gaming Daily' said as complete; wetpaper.ig (Instagram) was first opened 12 Oct 2026 (R4). Rest true (61, 5, 1 Oct, 66/186=35%). LENIENT-PASS if 'channels' means YouTube channels only."),
 "j0e": (P,0,1,"y","n","n","y","y",0,"wrongly based","'2 channels were new to you': three accounts were first opened in the window (wetpaper.ig on 12 Oct) (R4). Rest true. LENIENT-PASS if YouTube only."),
 "bnl": (P,0,1,"y","y","y","y","y",0,"wrongly based","'2 channels were new to you' (R4, wetpaper.ig). Watercolor 5 this fall from 13 in summer is true and a good extra. LENIENT-PASS if YouTube only."),
 "kip": (A,0,0,"y","y","n","y","y",0,None,"True; 'main new channel' and 'also new' claim no completeness, though wetpaper.ig is not named. Lower-case theme name."),
},
"N029.0": {
 "di6": (G,0,0,"y","y","n","y","y",0,None,"True (44/101, 25.7%, 19.8%, Minecraft 23 all Brick Realm); private line shown (7 private Saturday rows)."),
 "xbc": (A,0,0,"y","n","n","y","y",0,None,"True; shares and 'came next' only."),
 "jkm": (A,0,0,"y","n","n","y","y",0,None,"True; shares only."),
 "gax": (A,0,0,"y","n","n","y","y",0,None,"True; shares only. 'on Brick Realm' odd."),
 "qbl": (A,0,0,"y","n","n","y","y",0,None,"True; shares only."),
 "k1g": (A,0,0,"y","n","n","y","y",0,None,"True figures. 'gaming is most of what you opened: 44%' — a plurality, not most (STRICT-COUNT: R8, not counted). 'Art' for art and design."),
 "kei": (G,0,0,"y","y","n","y","y",0,None,"True; 'Minecraft builds alone made 23'."),
},
"N033.0": {
 "w13": (P,0,1,"y","y","y","y","y",0,"wrongly based","'All of them fell under Gaming clips, 66 items' after 'the short videos you opened' (70): the 4 reels are watercolor (R4). LENIENT-PASS: the 66 shows it means the Shorts."),
 "g2m": (G,0,0,"y","n","y","y","y",0,None,"True (66, 61 Clip Factory, 4 reels, Instagram ends 15 Oct)."),
 "jxv": (G,0,0,"y","n","y","y","y",0,None,"True (66 of 70; 61; 4)."),
 "lnn": (G,0,0,"y","n","y","y","y",0,None,"True."),
 "irj": (G,0,0,"y","n","y","y","y",0,None,"True."),
 "yid": (G,0,0,"y","y","y","y","y",0,None,"True; says why the reels are few (Instagram ends 15 Oct)."),
 "fpc": (G,0,0,"y","n","y","y","y",0,None,"True."),
},
"N033.1": {
 "ndw": (G,0,0,"y","y","y","y","y",0,None,"True: all 70 Shorts and reels fall in October 2026; 66 clips, 61 Clip Factory."),
 "dsa": (G,0,0,"y","y","y","y","y",0,None,"True (66/70=94%)."),
 "y73": (A,0,0,"y","y","y","n","y",0,None,"True; no offer."),
 "pz3": (G,0,0,"y","y","y","y","y",0,None,"True."),
 "ma9": (A,0,0,"y","y","n","n","y",0,None,"True; thin; no offer."),
 "d61": (G,0,0,"y","y","y","y","y",0,None,"True: Clip Factory on 30 days of October; a daily habit is a good extra. Wording 'on 30 days you opened some' clumsy."),
 "igz": (P,0,0,"n","n","n","n","y",1,"bare fallback","Time-out line; no answer."),
},
"N034.0": {
 "ar1": (G,0,0,"y","y","y","y","y",0,None,"True (129/184=70%, Digital drawing 92 all Pixel Pencil, food and cooking 32 the next area, gaming 13, math 10)."),
 "qo4": (A,0,0,"y","y","y","y","n",0,None,"True (92, 37, 32, 13, 10); heavy list."),
 "y3h": (G,0,0,"y","y","y","y","y",0,None,"True (92/184=50%, 37 Wet Paper, 32 Pan Theory)."),
 "fyh": (G,0,0,"y","y","y","y","y",0,None,"True (37 = 20.1%)."),
 "gbo": (G,0,0,"y","y","n","y","y",0,None,"True."),
 "qkk": (P,0,1,"y","y","n","n","y",0,"wrongly based","'Home cooking was next at 17%' after a theme sentence: the next theme is Watercolor painting (37) (R2). LENIENT-PASS: food and cooking is the next area and Home cooking its only theme. No offer."),
 "iy0": (P,0,1,"y","y","n","y","y",0,"wrongly based","'129 of 184 long videos, or 70% of what you opened': a share of the long videos said of what you opened (R3). LENIENT-PASS: the 184 long videos are named beside it."),
},
"N034.1": {
 "rcv": (A,0,0,"y","n","n","n","y",0,None,"True (94%, 61 of 70, 4 watercolor). 'Only long videos?' goes back to what was just corrected."),
 "t6y": (A,0,0,"y","y","n","n","y",0,None,"True ('Clip Factory alone made 61 of those 70'); offer repeats the long view."),
 "zpi": (A,0,0,"y","y","n","n","n",0,None,"True; point 1 repeats the lead (66 of 70 as 94%)."),
 "hx5": (A,0,0,"y","n","n","n","n",0,None,"True; repeats 66 as 94%; no channel named."),
 "wl9": (A,0,0,"y","n","n","n","y",0,None,"True; list only."),
 "wtf": (A,0,0,"y","n","n","n","n",0,None,"True; point 2 repeats the lead's 66 of 70 as 94%."),
 "s4t": (A,0,0,"y","y","n","n","y",0,None,"True ('all in Watercolor painting'); offer repeats the long view."),
},
"N035.0": {
 "xay": (A,0,0,"y","y","y","n","y",0,None,"True (719 of 723; 4; Brick Realm 163). No offer."),
 "z8w": (P,0,0,"n","n","n","y","y",0,"misses the question","729 is true but no split by platform. 'opened, liked or saved' while the export holds no likes (STRICT-COUNT: R8, not counted)."),
 "wvj": (G,0,0,"y","y","y","y","y",0,None,"True; 'far more'; Brick Realm 163 all on YouTube."),
 "y5b": (G,0,0,"y","y","y","y","y",1,None,"True (722 of 729; 7; Instagram ends 15 Oct)."),
 "kqp": (G,0,0,"y","y","y","y","y",0,None,"True (722/729; Minecraft builds top at 163)."),
 "sap": (G,0,0,"y","y","n","y","y",0,None,"True; 'by a wide margin'; thin but brief."),
 "iw1": (G,0,0,"y","y","y","y","y",0,None,"True (719/723, 4, 50 private); 'almost everything'."),
},
"N035.1": {
 "f7r": (A,0,0,"y","y","n","y","n",0,None,"True counts (4 reels, watercolor, one account). STRICT-COUNT (R6): 'Instagram history, which runs 12 to 15 October' — opens do; Instagram rows start 5 Oct with saves. Point repeats the lead as 100%."),
 "s6k": (A,0,0,"y","y","n","y","n",0,None,"True; point 1 repeats the lead as 100%."),
 "z08": (A,0,0,"y","y","n","n","y",0,None,"True ('holds only 4 opens, all 12 to 15 Oct'); no offer."),
 "s3w": (A,0,0,"y","y","n","y","y",0,None,"True counts (4 reels, watercolor, one account). STRICT-COUNT (R6): 'your export only covers 12 to 15 October 2026' — true of opens; Instagram rows include saves on 5, 6 and 10 Oct. Ruled with f7r. Held at acceptable for that wording."),
 "snm": (A,0,0,"y","y","y","n","n",0,None,"True (4 opens, 4 days, one account). 100% repeats; offer goes back to YouTube, just covered."),
 "d1w": (A,0,0,"y","y","n","y","n",0,None,"True; says 'all watercolor' three times."),
 "nq8": (G,0,0,"y","y","n","y","y",0,None,"True; 'Your Instagram export is short' reads the figure."),
},
"N038.0": {
 "tyd": (G,0,0,"y","n","y","y","y",1,None,"True: no likes; 6 own saves 3-10 Oct; 3 cards. STRICT-COUNT (R8): '6 items' beside '1 of your saves is a friend's post, counted' (rows: 6 own + 1 friend). The newest card (pasta post) is right."),
 "u4p": (A,0,0,"y","n","y","n","y",1,None,"True (6 saves; 6 Oct; lesson 3 on 5 Oct never opened). 'most recently' but the newest (10 Oct pasta post) is not named. 'Show some examples?' over cards. STRICT-COUNT (R8): '6 saves' beside the friend line. R1 not applied: 'here is ... 6 saves in the 4 weeks' states the period total, not a count of cards shown."),
 "n22": (A,0,0,"y","n","n","y","y",1,None,"True (newest 10 Oct, 6 Oct, 5 Oct). Odd quoted title 'A post from @noodle.nights...'; no cards."),
 "b6u": (P,0,1,"y","n","n","n","y",1,"wrongly based","'Two of them are watercolor lessons from Wet Paper' — three were saved (3, 4, 5 Oct) (R4). LENIENT-PASS: the two dates named are right. STRICT-COUNT (R8): '6 items' beside the friend line. R1 not applied: 'you saved 6 items' is the period total."),
 "qli": (P,1,0,"n","n","n","y","y",0,"wrong fact","'6 items, listed below' over 3 cards (R1). Never says the export holds no likes, so saves pass as the answer to 'liked' (limits not said). Dates true."),
 "kt7": (P,1,0,"n","n","n","y","y",0,"wrong fact","'Your newest save is Watercolor portrait lesson 3' — the newest is the pasta post (10 Oct). No-likes limit not said. 3 watercolor and 3 cooking is true."),
 "dkt": (A,0,0,"y","n","n","n","y",1,None,"True (6; lesson 3 on 5 Oct, lesson 2 on 4 Oct) but names the oldest saves, not the newest; no cards, no offer. R1 not applied: 'you saved 6 items' is the period total."),
},
"N044.0": {
 "us9": (P,1,0,"y","n","n","n","y",0,"wrong fact","'These 5 are the newest' with no cards and 3 items named (R1). Dates true."),
 "svq": (P,1,0,"y","y","y","n","y",0,"wrong fact","'here are 5 of the 72' over 3 cards (R1). '24 share that title' true."),
 "hxv": (A,0,0,"y","n","n","n","y",0,None,"True (30, 26, 24 Oct, all Pan Theory); no cards; 'Only long videos?' adds nothing (all cooking videos are long)."),
 "ygd": (A,0,0,"y","n","n","n","n",0,None,"True; 'a few' over 4 cards; points repeat the cards."),
 "aud": (P,1,0,"y","y","y","n","y",0,"wrong fact","'These 5' over 4 cards (R1). '24 share that title' true."),
 "jeo": (P,1,0,"y","n","n","n","y",0,"wrong fact","'Here are 5 of the 72' over 4 cards (R1)."),
 "rsa": (A,0,0,"y","n","n","n","n",0,None,"True; 'a few' over 4 cards; points repeat cards; offer repeats."),
},
"N044.1": {
 "vbn": (A,0,0,"y","n","n","n","y",0,None,"True: items 6-10 newest first (23, 22, 22, 21, 20 Oct). Bare list."),
 "lz0": (A,0,0,"y","n","n","y","n",0,None,"True; points repeat cards. STRICT-COUNT (R9): this bot's earlier answer never showed the 25 Oct pasta video."),
 "dzi": (A,0,0,"y","n","n","n","n",0,None,"True; points repeat cards."),
 "r4j": (A,0,0,"y","n","n","y","n",0,None,"True; point repeats a card. STRICT-COUNT (R9): its earlier answer showed 3 cards ending 25 Oct, so the 24 Oct tofu video is skipped for this person."),
 "se2": (A,0,0,"y","y","y","n","y",0,None,"True (23 back to 20 Oct; titles shared by 24 and 23 items). 'Show some examples?' over examples."),
 "wkr": (A,0,0,"y","y","n","n","y",0,None,"True ('All five are from Pan Theory'). Offer repeats."),
 "lzu": (P,1,0,"y","n","n","n","y",0,"wrong fact","'the next 5' with no cards and 2 items shown (R1). '24 times' true."),
},
"N053.0": {
 "uxj": (P,0,0,"n","n","n","y","y",0,"misses the question","50 on 50 days and August lightest (4) true, but nothing on whether it was weekly."),
 "p6x": (G,0,0,"y","y","y","y","y",0,None,"True (Feb 8, Aug 4, 7 months); 'steady ... rather than a few bursts' fits the rows (every week 1 Feb-15 Aug)."),
 "eir": (G,0,0,"y","y","y","y","y",0,None,"True on the year-wide reading, ruled with eu8, fm3, j87 (R5). STRICT-COUNT: 'not a steady weekly habit' — every week from 1 Feb to 15 Aug 2024 holds an open. Evening 68% true."),
 "eu8": (G,0,0,"y","y","n","y","y",0,None,"True on year coverage ('not really every week'; Feb to Aug; 4 to 8 a month). Does not say every week inside that span had one."),
 "j87": (A,0,0,"y","n","n","y","y",0,None,"True but thin: 'Not quite' with no span shown; repeats the one channel."),
 "fm3": (G,0,0,"y","y","n","y","y",0,None,"True (50 days, 7 months, 4 to 8, August 4, Heart Notes)."),
 "rz4": (A,0,0,"y","y","n","n","y",0,None,"True (4 to 8 a month, 68% evening); no direct yes or no; 'the list has no later month' reads as system talk; no offer."),
},
"N053.1": {
 "ff1": (G,0,0,"y","y","n","y","y",0,None,"True: 50 against 0; first opened 1 Feb 2024 says it began that year."),
 "aas": (A,0,0,"y","n","n","y","y",1,None,"True (all YouTube, no Shorts) but filler; 'no names are shown here' is limits talk."),
 "izp": (A,0,0,"y","n","n","y","n",0,None,"True; the 366/365-day sentence adds nothing."),
 "z5z": (A,0,0,"y","y","n","y","n",0,None,"True; first opened 1 Feb 2024; day-count sentence is filler."),
 "a11": (A,0,0,"y","y","n","n","n",0,None,"True; day-count filler; no offer."),
 "vsp": (A,0,0,"y","n","n","y","y",0,None,"True but thin."),
 "rrm": (G,0,0,"y","y","n","y","y",0,None,"True; brief; first opened 1 Feb 2024."),
},
"N054.0": {
 "n18": (G,0,0,"y","n","y","y","y",0,None,"True: 1 shown (tofu, 2 Mar 2024, Pan Theory), 7 private counted."),
 "ocu": (G,0,0,"y","n","y","y","y",0,None,"True; 7 private said."),
 "k82": (A,0,0,"y","n","n","y","y",0,None,"True under R10 ('1 video' with the private line; 7 private rows hidden and not counted aloud)."),
 "tu4": (G,0,0,"y","n","y","y","y",0,None,"True; theme and 7 private said."),
 "lah": (A,0,0,"y","n","n","y","y",0,None,"True under R10; lower-case 'home cooking'."),
 "t1x": (A,0,0,"y","n","n","y","y",0,None,"True under R10 ('100%' with the private line); no card for a list request."),
 "epx": (A,0,0,"y","n","n","y","y",0,None,"True; 'that I can show' hints at hidden rows without the count."),
},
"N056.0": {
 "gh4": (P,0,0,"n","n","n","n","y",0,"misses the question","651 long videos true, but no answer and no word that watch progress is not in the export."),
 "jbw": (A,0,0,"y","y","n","y","y",1,None,"True (each item opened once). 'listed here' names one item and shows no cards. Alternative is weak."),
 "vqg": (A,0,0,"y","n","n","n","y",1,None,"True (soup and drawing on 30 Oct). STRICT-COUNT (R8): 'records what you opened, liked or saved' while this export holds no likes."),
 "elw": (A,0,0,"y","y","n","n","y",1,None,"True (651, each opened once). 'Only long videos?' repeats its own scope."),
 "hfw": (A,0,0,"y","n","n","n","y",1,None,"True (651; soup the latest; drawing also 30 Oct)."),
 "nf3": (P,1,0,"y","n","n","y","y",1,"wrong fact","'The longest videos you opened ... starting with Cooking soup': the soup is 600 s; the longest are 1,500 s (R7)."),
 "x16": (A,0,0,"y","y","n","y","y",1,None,"True (723, each once; soup newest, Pan Theory). Alternative is weak."),
},
"N068.0": {
 "tdd": (A,0,0,"y","n","n","n","y",0,None,"Right item (pasta post, 10 Oct). 'weak' cannot be recounted; 'may not be a dinner recipe at all' undercuts a clear pasta-night match."),
 "zj7": (A,0,0,"y","n","n","n","y",0,None,"Right item; no offer."),
 "yp7": (A,0,0,"y","n","n","n","y",1,None,"Right item; one limits sentence about the search."),
 "tk0": (A,0,0,"y","n","n","n","y",0,None,"Right item, one line; no offer."),
 "qdd": (A,0,0,"y","n","n","n","y",0,None,"Right item; the friend's save (a beach post) is noise here."),
 "dx1": (A,0,0,"y","n","n","n","y",0,None,"Right item; friend line is noise."),
 "x84": (A,0,0,"y","n","n","n","y",0,None,"Right item; friend line is noise; 'Show some examples?' over the card."),
},
"N113.0": {
 "mal": (A,0,0,"y","y","y","y","y",1,None,"True (6 saves, 3 watercolor all Wet Paper, 3 cooking). STRICT-COUNT (R6) on 'all your history (3 to 30 October 2026)'. Thin base: 6 saves for 'usually'; what they open (gaming 44%) would say more."),
 "vr0": (A,0,0,"y","y","n","y","y",1,None,"True. STRICT-COUNT (R6) on the span label. Thin base."),
 "t0h": (A,0,0,"y","n","y","y","n",1,None,"True (@crumb.lab and @noodle.nights). Heavy share phrasing. STRICT-COUNT (R6)."),
 "q79": (P,0,0,"n","n","y","y","y",0,"limits not said","True figures, but answers 'like' with saves and never says the export holds no likes."),
 "x0i": (P,0,0,"n","n","n","y","y",0,"limits not said","True figures; no-likes swap not said. STRICT-COUNT (R6)."),
 "gry": (A,0,0,"y","y","n","y","y",1,None,"True. STRICT-COUNT (R6). Thin base."),
 "abu": (P,0,0,"n","n","n","y","n",0,"limits not said","True figures ('3 to 30 October' framed right) but no-likes swap not said; '50% ... 50% each' twice."),
},
}
MOST = {
"N002.0": "qa2: true, says one theme alone holds half the gaming, counts the private rows, and offers 'Without gaming?'.",
"N005.0": "k47: the only answer that names Home cooking as the every-year theme with its yearly counts and the Minecraft contrast (it lacks an offer).",
"N005.1": "v8a: count and share both, says 2021 is the heaviest share, and how the gaming mix moved to clips in 2026.",
"N007.0": "ejs: names what was dropped (Speedruns, none this year) and how far Minecraft fell (13, 5%).",
"N019.0": "kip: the one answer that does not claim its list of new channels is complete.",
"N029.0": "di6: the shares plus the theme and its one channel, with the private line.",
"N033.0": "yid: the count, the channel behind it, and why the reels are few (Instagram ends 15 October).",
"N033.1": "d61: no earlier month to compare with, plus Clip Factory on 30 days of October (a daily habit).",
"N034.0": "y3h: mostly art, Digital drawing half of it from one channel, then Watercolor and cooking with their channels.",
"N034.1": "t6y: the short ones are almost all gaming, Clip Factory alone 61 of 70, and the 4 art items.",
"N035.0": "wvj: YouTube far more, 719 of 723, and the top channel behind it.",
"N035.1": "nq8: says the Instagram export is short, then what is in it, in two lines.",
"N038.0": "tyd: says there are no likes and where the export ends, gives the saves with the newest first, counts the friend's save.",
"N044.0": "ygd: 'a few' over four true cards, nothing claimed that is not shown.",
"N044.1": "se2: the next five with their date span and how often those titles repeat.",
"N053.0": "p6x: 'steady through the summer rather than a few bursts' fits the rows (an open in every week from 1 Feb to 15 Aug).",
"N053.1": "ff1: 50 against 0 and the first open on 1 Feb 2024, brief.",
"N054.0": "tu4: the one item, its theme and channel, and the 7 private items counted.",
"N056.0": "elw: one line on what the export cannot show, then the long videos and that each was opened once.",
"N068.0": "tk0: the one match in one line, with its card and no noise.",
"N113.0": "gry: says there are no likes, then the save split and Wet Paper, with a follow-up on lately.",
}
F = ["grade","false_n","wrongly_based_n","answers","means","more","offer","brief","limits_talk","poor_cause","note"]
out = []
seen = set()
for m in pk["messages"]:
    key = m["key"]; codes = [a["code"] for a in m["answers"]]
    assert set(M[key]) == set(codes), (key, set(codes) ^ set(M[key]))
    for a in m["answers"]:
        v = dict(zip(F, M[key][a["code"]]))
        assert (key, a["code"]) not in seen; seen.add((key, a["code"]))
        bad = v["false_n"] >= 1 or v["wrongly_based_n"] >= 1 or v["answers"] == "n"
        assert (v["grade"] == P) == bad, (key, a["code"], "poor rule")
        assert (v["poor_cause"] is not None) == (v["grade"] == P), (key, a["code"], "cause")
        assert (v["wrongly_based_n"] >= 1) == ("LENIENT-PASS" in v["note"]), (key, a["code"], "tag")
        if v["grade"] == G:
            assert v["offer"] == "y" and v["brief"] == "y" and (v["means"] == "y" or v["more"] == "y"), (key, a["code"], "good rule")
        # R1 check: number claims over cards
        txt = a["parts"]["lead"] + " " + " ".join(a["parts"]["points"])
        mm = re.search(r"(?:[Hh]ere are|These|the next) (\d+)|(\d+) items, listed below", txt)
        if mm:
            n = int(mm.group(1) or mm.group(2)); nc = len(a["parts"]["cards"])
            mismatch = n != nc
            print(f"R1 {key} {a['code']}: claims {n}, cards {nc} -> {'MISMATCH' if mismatch else 'ok'} false_n={v['false_n']}")
            assert mismatch == (v["false_n"] >= 1) or key == "N007.0", (key, a["code"])
        out.append({"message_id": key, "code": a["code"], **v})
assert len(out) == sum(len(m["answers"]) for m in pk["messages"]) == 144, len(out)
json.dump(out, open(f"{S}/mvp27/reader3b/marks.json", "w"), indent=1)
with open(f"{S}/mvp27/reader3b/most_want.txt", "w") as f:
    for m in pk["messages"]:
        f.write(f"{m['key']}: {MOST[m['key']]}\n")
from collections import Counter
print("marked", len(out), Counter(o["grade"] for o in out))
print("false sentences", sum(o["false_n"] for o in out), "in", sum(o["false_n"] > 0 for o in out), "answers; wrongly based", sum(o["wrongly_based_n"] for o in out))
print("answers y", sum(o["answers"] == "y" for o in out), "means y", sum(o["means"] == "y" for o in out), "offer y", sum(o["offer"] == "y" for o in out))
print("poor causes", Counter(o["poor_cause"] for o in out if o["poor_cause"]))
for m in pk["messages"]:
    c = Counter(o["grade"] for o in out if o["message_id"] == m["key"])
    print(f"  {m['key']}: good {c[G]} acc {c[A]} poor {c[P]}")

# both readings
def lenient(o):
    if o["grade"] == P and o["false_n"] == 0 and o["answers"] == "y" and "LENIENT-PASS" in o["note"]:
        return A
    return o["grade"]
def strict(o):
    return P if ("STRICT-COUNT" in o["note"] or "R1 not applied" in o["note"] or o["grade"] == P) else o["grade"]
print("lenient reading:", Counter(lenient(o) for o in out), " wrongly based", 0)
print("strict reading:", Counter(strict(o) for o in out), " extra wrongly based (STRICT-COUNT tags)", sum("STRICT-COUNT" in o["note"] for o in out))
print("acceptable answers meeting every good condition (reason must be in note):")
for o in out:
    if o["grade"] == A and o["answers"] == "y" and o["offer"] == "y" and o["brief"] == "y" and (o["means"] == "y" or o["more"] == "y"):
        print("  ", o["message_id"], o["code"], "|", o["note"][:110])
