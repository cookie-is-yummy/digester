"""reader3b facts: counts straight from the library rows (no brain tools imported)."""
import sys
from collections import Counter, defaultdict
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as L  # rows only (imports r12_library rows)

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice(PRIVATE)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships(PRIVATE)"}
rows = L.rows()
ev = []  # one per event
for r in rows:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        ev.append(dict(id=r["id"], plat=r["platform"], kind=k, t=t, d=t.date(), theme=r["theme"], area=AREA[r["theme"]],
                       ch=r.get("channel") or r.get("handle"), title=r["caption"], length=r.get("length"),
                       friend=bool(r.get("friend")), private=r["theme"] == "da"))
def short(e):  # YouTube Short: length known and <= 60 s; IG reel = media reel
    if e["plat"] == "youtube":
        return e["length"] is not None and e["length"] <= 60
    return e["plat"] == "instagram" and e["id"].startswith("rig")
def longv(e):
    return e["plat"] == "youtube" and e["length"] is not None and e["length"] > 60
opened = [e for e in ev if e["kind"] == "watch"]
op = [e for e in opened if not e["private"]]
saves = [e for e in ev if e["kind"] in ("save", "playlist")]
def pc(a, b): return f"{a}/{b}={100*a/b:.1f}%" if b else f"{a}/0"
def C(es, key): return Counter(e[key] for e in es).most_common()
def hdr(s): print("\n=== " + s)

hdr("BASE")
print("opened all (incl private):", len(opened), " non-private:", len(op), " youtube np:", sum(e['plat']=='youtube' for e in op),
      " instagram:", sum(e['plat']=='instagram' for e in op), " private:", sum(e['private'] for e in opened))
print("saves own:", [(e['id'], str(e['d']), e['theme']) for e in sorted(saves, key=lambda e: e['t']) if not e['friend']])
print("friend saves:", [(e['id'], str(e['d'])) for e in saves if e['friend']])
print("first/last opened:", min(e['d'] for e in opened), max(e['d'] for e in opened))

hdr("N002 youtube all history")
yt = [e for e in op if e["plat"] == "youtube"]
n = len(yt); print("n", n)
for a, c in C(yt, "area"): print("  area", a, pc(c, n))
for t, c in C(yt, "theme"): print("  theme", THEME[t], c, dict(C([e for e in yt if e['theme'] == t], 'ch')))

hdr("N005.0 every year")
yrs = sorted({e['d'].year for e in opened}); print("years", yrs)
for key in ("ch", "theme"):
    every = []
    for v in {e[key] for e in op}:
        by = Counter(e['d'].year for e in op if e[key] == v)
        if all(by.get(y, 0) > 0 for y in yrs): every.append(v)
        if v in ("Pan Theory", "Brick Realm", "co", "mc", "Frame Perfect", "Wet Paper", "Limit Lane"):
            print("  ", key, v, dict(sorted(by.items())), "total", sum(by.values()))
    print(" every-year", key, every)
print("first opened per channel:", sorted([(min(e['d'] for e in op if e['ch'] == c), c) for c in {e['ch'] for e in op}]))
print("opened per year (non-private, all platforms):", dict(sorted(Counter(e['d'].year for e in op).items())))
print("channels total:", C(op, "ch"))

hdr("N005.1 gaming per year")
for y in yrs:
    ye = [e for e in op if e['d'].year == y]; g = [e for e in ye if e['area'] == 'gaming']
    print(" ", y, "gaming", pc(len(g), len(ye)), {THEME[t]: c for t, c in C(g, 'theme')},
          "mc share of gaming", pc(sum(e['theme'] == 'mc' for e in g), len(g)) if g else "",
          "cl share", pc(sum(e['theme'] == 'cl' for e in g), len(g)) if g else "")
print(" gaming total", sum(e['area'] == 'gaming' for e in op))

hdr("N007.0 2021 vs later")
y21 = [e for e in op if e['d'].year == 2021]
print(" 2021 themes", [(THEME[t], pc(c, len(y21))) for t, c in C(y21, 'theme')])
y26 = [e for e in op if e['d'].year == 2026]
print(" 2026 themes", [(THEME[t], pc(c, len(y26))) for t, c in C(y26, 'theme')], "n26", len(y26))
print(" 2026 youtube only n", sum(e['plat'] == 'youtube' for e in y26))
for t in ("mc", "sr", "co"):
    print("  ", THEME[t], "by year", dict(sorted(Counter(e['d'].year for e in op if e['theme'] == t).items())),
          "last", max(e['d'] for e in op if e['theme'] == t))

hdr("N019.0 fall 2026 new channels")
first = {}
for e in sorted(op, key=lambda e: e['t']): first.setdefault(e['ch'], e['d'])
for start in (date(2026, 9, 1), date(2026, 9, 22)):
    w = [e for e in op if start <= e['d'] <= date(2026, 10, 30)]
    newc = {c: d for c, d in first.items() if d >= start}
    print(" window from", start, "n", len(w), "new channels:", {c: (str(d), sum(e['ch'] == c for e in w)) for c, d in newc.items()})
    print("   themes", [(THEME[t], pc(c, len(w))) for t, c in C(w, 'theme')])
summ = [e for e in op if date(2026, 6, 1) <= e['d'] <= date(2026, 8, 31)]
print(" summer 2026 (Jun-Aug) n", len(summ), [(THEME[t], c) for t, c in C(summ, 'theme')])
print(" first opened Pixel Pencil", first['Pixel Pencil'], "wetpaper.ig", first.get('wetpaper.ig'))
print(" channels opened in window Sep1-Oct30 with first date:", {c: str(first[c]) for c in {e['ch'] for e in op if e['d'] >= date(2026,9,1)}})

hdr("N029.0 Saturdays")
sat = [e for e in op if e['d'].weekday() == 5]; n = len(sat)
print(" n", n, "private on Sat", sum(e['private'] and e['d'].weekday() == 5 for e in opened))
print("  areas", [(a, pc(c, n)) for a, c in C(sat, 'area')])
print("  themes", [(THEME[t], c) for t, c in C(sat, 'theme')])
print("  mc channels", C([e for e in sat if e['theme'] == 'mc'], 'ch'))

hdr("N033 Shorts")
sh = [e for e in op if short(e)]
print(" shorts+reels all history", len(sh), "by month", Counter((e['d'].year, e['d'].month) for e in sh))
oc = [e for e in sh if e['d'].year == 2026 and e['d'].month == 10]
print(" Oct 2026: yt shorts", sum(e['plat'] == 'youtube' for e in oc), "ig reels", sum(e['plat'] == 'instagram' for e in oc),
      "channels", C(oc, 'ch'), "themes", [(THEME[t], c) for t, c in C(oc, 'theme')])
print(" days with Clip Factory in Oct", len({e['d'] for e in oc if e['ch'] == 'Clip Factory'}),
      " days with any short", len({e['d'] for e in oc}))
print(" share gaming clips of 70", pc(sum(e['theme']=='cl' for e in oc), len(oc)))

hdr("N034 long/short 2026")
lg = [e for e in y26 if longv(e)]; n = len(lg)
print(" long n", n, [(a, pc(c, n)) for a, c in C(lg, 'area')])
print("  themes", [(THEME[t], pc(c, n), dict(C([e for e in lg if e['theme'] == t], 'ch'))) for t, c in C(lg, 'theme')])
s26 = [e for e in y26 if short(e)]; n = len(s26)
print(" short n", n, [(a, pc(c, n)) for a, c in C(s26, 'area')], [(THEME[t], c) for t, c in C(s26, 'theme')], C(s26, 'ch'))
print(" 2026 unknown length", sum(e['plat']=='youtube' and e['length'] is None for e in y26))

hdr("N035 platforms")
print(" opened by platform", C(op, 'plat'), " saves own by platform", C([e for e in saves if not e['friend']], 'plat'))
print(" opened+saved items", len({e['id'] for e in op} | {e['id'] for e in saves if not e['friend']}))
ig = [e for e in op if e['plat'] == 'instagram']
print(" IG opened", [(e['id'], str(e['d']), e['ch'], THEME[e['theme']]) for e in ig])
print(" IG all events dates", sorted(str(e['d']) for e in ev if e['plat'] == 'instagram'))

hdr("N038 saves recent (4 weeks to Oct 30)")
for e in sorted(saves, key=lambda e: e['t'], reverse=True):
    print("  ", e['id'], e['t'].strftime('%Y-%m-%d %H:%M'), e['plat'], e['ch'], THEME[e['theme']], "FRIEND" if e['friend'] else "",
          e['title'][:50], "| ever opened:", any(x['id'] == e['id'] and x['kind'] == 'watch' for x in ev))

hdr("N044 cooking opened newest first")
co = sorted([e for e in op if e['area'] == 'food and cooking'], key=lambda e: e['t'], reverse=True)
print(" n", len(co))
for i, e in enumerate(co[:14], 1): print("  ", i, e['id'], e['d'], e['title'][:45])
titles = Counter(e['title'].split(' #')[0] for e in co); print(" title counts", titles)

hdr("N053 dating 2024")
da = sorted([e for e in opened if e['private']], key=lambda e: e['t'])
print(" n", len(da), "years", Counter(e['d'].year for e in da), "distinct days", len({e['d'] for e in da}))
print(" first", da[0]['d'], "last", da[-1]['d'], "months", dict(sorted(Counter(e['d'].month for e in da).items())))
wk = Counter(e['d'].isocalendar()[1] for e in da)
allw = range(da[0]['d'].isocalendar()[1], da[-1]['d'].isocalendar()[1] + 1)
print(" ISO weeks spanned", len(allw), "weeks with >=1", sum(1 for w in allw if wk.get(w)), "missing", [w for w in allw if not wk.get(w)])
print(" hours NY", Counter(e['t'].hour for e in da), " 17-21h share", pc(sum(17 <= e['t'].hour < 21 for e in da), len(da)),
      " 18-22", pc(sum(18 <= e['t'].hour < 22 for e in da), len(da)))
print(" any 2023", sum(e['d'].year == 2023 for e in da), " shorts", sum(short(e) for e in da), " channels", C(da, 'ch'))

hdr("N054 March 2024")
m = [e for e in opened if e['d'].year == 2024 and e['d'].month == 3]
print(" n incl private", len(m), [(e['id'], str(e['d']), e['title'], 'PRIV' if e['private'] else '') for e in m if not e['private']],
      "private", sum(e['private'] for e in m))

hdr("N056 all the way through")
print(" long opened all history", sum(longv(e) for e in op), " watch events per item max",
      max(Counter(e['id'] for e in opened).values()))
lo = sorted([e for e in op if longv(e)], key=lambda e: e['t'], reverse=True)[:4]
print(" newest long", [(e['id'], e['t'].strftime('%m-%d %H:%M'), e['title'], e['length']) for e in lo])
print(" longest length", max(e['length'] for e in op if e['length']), " soup length", [e['length'] for e in op if e['id'] == 'rday4'])

hdr("N068 dinner in saves")
for e in saves: print("  ", e['id'], e['title'][:70], "FRIEND" if e['friend'] else "")

hdr("N113 saves by area/theme/channel (own)")
sv = [e for e in saves if not e['friend']]
print(" n", len(sv), C(sv, 'area'), [(THEME[t], c) for t, c in C(sv, 'theme')], C(sv, 'ch'),
      "span", min(e['d'] for e in sv), max(e['d'] for e in sv))
print(" opened areas all (for 'usually like' as taste)", [(a, pc(c, len(op))) for a, c in C(op, 'area')])

hdr("EXTRA: N038 4-week window and private rows per scope")
end = date(2026, 10, 30); start = end - timedelta(days=27)
print(" 4 weeks to export end:", start, "to", end, " own saves inside:",
      [e['id'] for e in saves if not e['friend'] and start <= e['d'] <= end], " friend inside:", [e['id'] for e in saves if e['friend'] and start <= e['d'] <= end])
print(" likes in the export:", sum(e['kind'] == 'like' for e in ev), " kinds:", Counter(e['kind'] for e in ev))
scopes = {
    "N002 youtube all": lambda e: e['plat'] == 'youtube',
    "N005 all history": lambda e: True,
    "N005.1/N007 2021": lambda e: e['d'].year == 2021,
    "N007 2026": lambda e: e['d'].year == 2026,
    "N019 fall Sep1-Oct30": lambda e: e['d'] >= date(2026, 9, 1),
    "N029 Saturdays": lambda e: e['d'].weekday() == 5,
    "N033 shorts": lambda e: short(e),
    "N034 long 2026": lambda e: e['d'].year == 2026 and longv(e),
    "N044 cooking": lambda e: e['area'] == 'food and cooking',
    "N054 March 2024": lambda e: e['d'].year == 2024 and e['d'].month == 3,
    "N056 long all": lambda e: longv(e),
}
for k, f in scopes.items():
    print(f"  private opened in scope {k}: {sum(1 for e in opened if e['private'] and f(e))}")
print(" N005.0 private channel years:", dict(Counter(e['d'].year for e in opened if e['private'])))
