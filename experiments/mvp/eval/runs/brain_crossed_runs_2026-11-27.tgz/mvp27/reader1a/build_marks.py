"""Builds marks.json from marks_src.py; limits_talk is computed by one rule over lead, points and limit_lines
(not the private line, scope line, cards or offers): a sentence counts if it states a limit of the data or the bot."""
import json, re, sys, collections
sys.path.insert(0, ".")
from marks_src import M, BEST
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27"
pk = json.load(open(S + "/blind/group1.json"))
PAT = re.compile(r"export ends|export leaves|not in it|no data|can't|cannot|can only|not counted|counted but not shown|"
                 r"counted in neither|keep private|not named here|search ranks|list tool|has no \"|not in this check|left out|not shown", re.I)
out, errs = [], []
for m in pk["messages"]:
    key = m["key"]; codes = [a["code"] for a in m["answers"]]
    got = {r[0]: r for r in M.get(key, [])}
    if set(got) != set(codes): errs.append((key, "codes", sorted(set(codes) ^ set(got))))
    by = collections.defaultdict(list)
    for a in m["answers"]:
        c = a["code"]; p = a["parts"]; r = got[c]
        _, g, f, wb, ans, means, more, offer, brief, _lim, cause, note = r
        lim = sum(1 for s in [p["lead"]] + p["points"] + p["limit_lines"] if s and PAT.search(s))
        d = dict(message_id=key, code=c, grade=g, false_n=f, wrongly_based_n=wb, answers=ans, means=means, more=more,
                 offer=offer, brief=brief, limits_talk=lim, poor_cause=cause, note=note)
        for k in ("answers", "means", "more", "offer", "brief"):
            if d[k] not in ("y", "n"): errs.append((key, c, k))
        if g not in ("good", "acceptable", "poor"): errs.append((key, c, "grade"))
        if f + wb > 0 and g != "poor": errs.append((key, c, "false but not poor"))
        if ans == "n" and g != "poor": errs.append((key, c, "answers n not poor"))
        if (g == "poor") != (cause is not None): errs.append((key, c, "cause"))
        if cause and cause not in ("wrong fact", "misses the question", "thin", "wrongly based", "limits not said",
                                   "says too much about limits", "bare fallback", "other"): errs.append((key, c, "cause value"))
        if g == "good" and not p["offers"] and not p["ask_back"]: errs.append((key, c, "good with no offer (cap rule)"))
        by[a["sent"]].append(json.dumps({k: v for k, v in d.items() if k not in ("code", "note")}))
        out.append(d)
    for t, v in by.items():
        if len(set(v)) > 1: errs.append((key, "identical texts marked differently"))
    if key not in BEST or BEST[key].split(" ")[0] not in codes: errs.append((key, "best line"))
print("errors:", errs); print("marks:", len(out), "messages:", len(pk["messages"]))
json.dump(out, open(S + "/reader1a/marks.json", "w"), indent=1)
with open(S + "/reader1a/best_per_message.txt", "w") as f:
    for m in pk["messages"]: f.write(f"{m['key']}: {BEST[m['key']]}\n")
G = collections.Counter(d["grade"] for d in out); print("grades", dict(G))
print("false_n", sum(d["false_n"] for d in out), "wrongly_based_n", sum(d["wrongly_based_n"] for d in out))
friend = [d for d in out if d["wrongly_based_n"] and d["message_id"] in ("N041.0", "N041.1", "N055.0") and "6" in d["note"] or (d["wrongly_based_n"] and d["code"] in ("ro4","qie","y56"))]
print("wb from friend's-save completeness rule:", len(friend), [d["code"] for d in friend])
print("wb from base-under-scope rule:", [d["code"] for d in out if d["code"] in ("x47","eyl","hf7","g8c")])
print("causes", dict(collections.Counter(d["poor_cause"] for d in out if d["poor_cause"])))
for k in ("answers", "means", "more", "offer", "brief"): print(k, "y:", sum(d[k] == "y" for d in out))
print("limits_talk total", sum(d["limits_talk"] for d in out), "answers with >=2:", sum(d["limits_talk"] >= 2 for d in out))
# best / worst with tie rule
def bscore(d): return (d["grade"] == "good", sum(d[k] == "y" for k in ("means", "more", "offer", "brief")), -d["limits_talk"],
                       BEST[d["message_id"]].startswith(d["code"] + " "))
def wscore(d): return (d["grade"] == "poor", d["false_n"], d["wrongly_based_n"], d["answers"] == "n",
                       -sum(d[k] == "y" for k in ("means", "more", "offer")))
def dedup(lst):
    seen, res = set(), []
    for d in lst:
        t = (d["message_id"], d["grade"], d["note"])
        if t in seen: continue
        seen.add(t); res.append(d)
    return res
best = dedup(sorted(out, key=bscore, reverse=True))
worst = dedup(sorted(out, key=wscore, reverse=True))
print("\nBEST candidates (top 20 by tie rule):")
for d in best[:20]: print(" ", d["message_id"], d["code"], bscore(d))
print("\nWORST candidates (top 20):")
for d in worst[:20]: print(" ", d["message_id"], d["code"], wscore(d), d["poor_cause"])
