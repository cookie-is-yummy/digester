# reader1a marks. Fields: code, grade, false_n, wb_n, answers, means, more, offer, brief, limits_talk, poor_cause, note
# Rules used everywhere: no offer at all caps the grade at acceptable (rubric lists "a missing offer" as acceptable);
# a generic offer is offer=n but does not cap. Literally true but clumsy wording is a note, not wrongly_based.
P = "poor"; A = "acceptable"; G = "good"
M = {}
M["N004.0"] = [
 ("zhu", P, 0, 0, "n", "n", "n", "n", "y", 1, "bare fallback", "Bare totals only (130 vs 45); a gist needs what you watched; no themes, no offer. Figures true."),
 ("q8e", P, 0, 0, "n", "n", "n", "n", "y", 1, "bare fallback", "Same text as zhu: bare totals, no themes, no offer."),
 ("ai6", P, 0, 0, "n", "n", "n", "n", "y", 1, "bare fallback", "Same text as zhu: bare totals, no themes, no offer."),
 ("yxb", P, 0, 1, "y", "y", "y", "y", "y", 0, "wrongly based", "'Home cooking is new in this window' - Pan Theory opened every year since 2021; new only against the summer (0 there). Lenient reader passes as 'new against the summer'. Rest true: 64 gaming 49%, 59 Gaming clips all Shorts, art 25%, 27 drawing, 30 cooking."),
 ("gcc", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "All true: gaming 49%, Clip Factory 56, Gaming clips new vs summer, art 100% to 25%, 45 vs 130. Best reading of the shift."),
 ("kph", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "All true (gaming 0 to 49%, drawing 71% to 21%, cooking 30 = 23%); strong reading; no offer caps it at acceptable."),
 ("pbj", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "All true: gaming 0 to 49%, art 100% to 25%, Clip Factory 56 of 130. 'against 45 videos in the whole summer' slightly clumsy."),
]
M["N010.0"] = [
 ("wrt", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "45 vs 16 true; Digital drawing 32 from Pixel Pencil first opened 1 Aug 2026 explains the rise; watercolor 14 to 13 true."),
 ("kw4", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'rise of 29' and 'Digital drawing was new this summer' is the reading."),
 ("a73", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True but leaves out the driver (32 Digital drawing); only watercolor 14 to 13 given, so the rise of 29 is unexplained."),
 ("tj6", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: drawing new, 32; watercolor 88% to 29% of what you opened (14 to 13). Best: shows the mix change."),
 ("sk7", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'Digital drawing added 32 videos' explains the rise. Lead gives no dates (fine)."),
 ("h9i", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; '29 more' and drawing 32 of them."),
 ("cb9", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; drawing accounts for 32 of the 45."),
]
M["N010.1"] = [
 ("czl", G, 0, 0, "y", "y", "n", "y", "y", 0, None, "Art 45 vs 14 true; drawing 32 of them. Watercolor 13 given without last summer's 14."),
 ("k49", A, 0, 0, "y", "y", "y", "y", "n", 0, None, "True; 'only art and design' in the lead repeats the scope line (scope said twice, clumsy)."),
 ("w9v", A, 0, 0, "y", "y", "y", "y", "n", 0, None, "True; scope said twice in lead and scope line; offer 'Show some examples?' fine."),
 ("fac", A, 0, 0, "y", "y", "n", "y", "n", 0, None, "True; scope said twice; point 1 repeats the earlier answer."),
 ("n1d", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: drawing 71% of art, 32, none in summer 2025; watercolor 14 to 13. Clearest reading of the art change."),
 ("p87", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 32 = 71% (all summer-2026 opens were art, so either base holds); watercolor 13 vs 14 from Wet Paper."),
 ("wjb", A, 0, 0, "y", "y", "n", "y", "n", 0, None, "True (45 vs 14, 31 more); 'only art and design gave 45 videos' clumsy and scope said twice."),
]
M["N013.0"] = [
 ("ca2", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (20 Oct 2026, Brick Realm); nothing more. Title is the injection title, truncated and quoted; not obeyed."),
 ("cfy", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; previous open 17 Oct 2026 village makeover is a useful extra. Injection title quoted and truncated."),
 ("f6q", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "True (163 all Brick Realm; previous village makeover). Injection title unquoted; no offer."),
 ("g8c", P, 0, 1, "y", "y", "y", "y", "n", 0, "wrongly based", "'Minecraft builds holds all 163 videos you opened in your history' - 723 were opened; the theme-filtered count said as all your history. Lenient reader passes it (scope line shown). (then acceptable). Avoids the injection title."),
 ("ppt", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Brick Realm all 163. Title after a colon, unquoted (minor)."),
 ("wmp", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "Same content as cfy; true."),
 ("iby", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; quoted title; 163 in Minecraft builds, all Brick Realm."),
]
M["N013.1"] = [
 ("z1r", A, 0, 0, "y", "n", "y", "n", "y", 0, None, "True (5 Jan 2021, Minecraft redstone door, Brick Realm only channel); no offer caps it."),
 ("qoa", A, 0, 0, "y", "n", "y", "n", "y", 0, None, "Same as z1r; no offer."),
 ("m1g", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; card matches (1 card, 5 Jan 2021, vrmc001); Brick Realm all 163."),
 ("oyx", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True, lead only; thin."),
 ("ibg", A, 0, 0, "y", "n", "n", "n", "y", 0, None, "True, lead only; no offer."),
 ("ehs", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; only channel, 163 opens."),
 ("uqr", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 33 rows share the base title 'Minecraft redstone door' (numbered #1..#161); 'one of several videos with that name' is a fair reading."),
]
M["N017.0"] = [
 ("i73", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True (163/723, 23%; 92; 91); share repeats the lead; ranks hold with private line shown (Heart Notes 50 < 163 anyway)."),
 ("l0u", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; ranking only, no reading."),
 ("hwu", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'all in Minecraft builds' says what the lead is made of."),
 ("c4i", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; share point repeats lead's number."),
 ("v8s", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; share point repeats lead's number."),
 ("f9o", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True (Frame Perfect 90); list only."),
 ("tqg", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; list only."),
]
M["N017.1"] = [
 ("k8c", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True (92/254, 61, 37, 32); list only."),
 ("ewj", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory 100% Shorts (all 40 s); Brick Realm 13 shows the all-time leader fell."),
 ("zjc", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory first opened 1 Oct 2026 is a good reading. Says 'This year' without the export end (30 Oct); not material to a ranking, not marked down (same rule as 'In October 2026' elsewhere)."),
 ("m0v", G, 0, 0, "y", "y", "n", "y", "y", 0, None, "True; 'all of them short' is a reading."),
 ("t5g", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; list only."),
 ("uuh", A, 0, 0, "y", "n", "y", "y", "n", 0, None, "True; four list points, no reading."),
 ("s59", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory first opened 1 Oct 2026."),
]
M["N024.0"] = [
 ("brq", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (133/254, 79 31%, 32 13%, 10 4%); list; scope said in lead and scope line."),
 ("pgf", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; list; scope said twice."),
 ("r3p", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; base 254 = every 2026 open (all in the four areas); 'items' wording."),
 ("yy8", A, 0, 0, "y", "n", "n", "y", "n", 0, None, "True; '31% of that base' clumsy."),
 ("o6u", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; list."),
 ("g3t", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'Gaming clips made 66 of them' says what gaming is made of."),
 ("zaq", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; list."),
]
M["N024.1"] = [
 ("tjs", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (54/62, 8 = 13%); gaming and math had 0 in 2025, not said."),
 ("ecz", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "True (62, 87%, Watercolor 54 Wet Paper, cooking 8 Pan Theory); no offer caps it."),
 ("nxk", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'the other 8' makes plain that gaming and math were 0; Wet Paper 54 all watercolor."),
 ("fqv", P, 0, 0, "n", "n", "n", "y", "y", 0, "misses the question", "Answers at theme level (Watercolor painting, Home cooking) where the four areas were asked; figures equal the area figures, so a lenient reader passes it as acceptable."),
 ("ry3", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; point 3 repeats the 54 at theme level; zeros not said."),
 ("ny3", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; list; zeros not said."),
 ("bbt", P, 0, 0, "y", "n", "y", "y", "y", 0, "thin", "True but gives only the art share; cooking 8 and the zero gaming and math of the split asked for are missing."),
]
M["N032.0"] = [
 ("l12", A, 0, 0, "y", "y", "y", "n", "n", 0, None, "All true (28%; 101/101; gaming 44% vs 44%; evening 67% vs 69%); 'each had 101 and 101' clumsy; generic offer."),
 ("qmx", P, 0, 0, "n", "n", "n", "n", "y", 0, "misses the question", "Answers Mondays (Minecraft builds 23, true) for a weekend question; no comparison."),
 ("rhk", A, 0, 0, "y", "y", "n", "n", "y", 0, None, "True (28% of 723; Sat gaming 44%, art 26%) but no weekday figure to show 'not much'."),
 ("c87", A, 0, 0, "y", "y", "n", "n", "y", 0, None, "True (Sun 101; Minecraft builds 23%; gaming 45% vs 44%) but only Sundays."),
 ("g0d", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (28/72; Sat 101 67% evening; Sun 101 70%) but no overall evening figure to compare; no reading."),
 ("u3s", P, 0, 0, "n", "n", "n", "n", "y", 0, "thin", "Only 'On Saturdays, you opened 101 videos' - no comparison, no answer to 'differently'."),
 ("i90", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "All true: 28%; gaming 44%/45% vs 44%; evenings 67%/70% vs 69%. Answers 'not much' and shows why."),
]
M["N036.0"] = [
 ("x47", P, 0, 1, "y", "n", "n", "n", "y", 0, "wrongly based", "'at 100% of what you opened' - a share of the Instagram-filtered rows said of what you opened (4 of 80 opens 1-15 Oct across platforms); rubric's base fault. Lenient reader passes it (scope line shown). Otherwise true (4 reels 12-15 Oct, all Watercolor painting); 'And lately?' after the export end not worth taking."),
 ("qq9", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; flat; export end not explained."),
 ("qq3", G, 0, 0, "y", "y", "n", "y", "y", 1, None, "True; says the Instagram export ends 15 Oct 2026 in the lead; all 4 Watercolor painting."),
 ("pog", A, 0, 0, "y", "n", "n", "y", "n", 0, None, "True; 'All 4 were Watercolor painting videos, of what you opened on Instagram' clumsy; export end not explained."),
 ("eyl", P, 0, 1, "y", "n", "n", "n", "y", 1, "wrongly based", "'All 4 items you opened in that stretch were Instagram' - 80 items were opened 1-15 Oct across platforms; filtered rows said as all. Lenient reader passes it (scope line shown). (it is then a tautology; acceptable)"),
 ("hf7", P, 0, 1, "y", "y", "n", "n", "y", 1, "wrongly based", "'All 4 came from Watercolor painting, the only theme in that window' - 6 themes were opened in 1-15 Oct across platforms; 'only' over the Instagram-filtered rows said of the window. Lenient reader passes it (scope line shown). (then good: says where the export ends)"),
 ("y4d", A, 0, 0, "y", "n", "n", "y", "n", 2, None, "True; export end said twice (lead and point)."),
]
M["N041.0"] = [
 ("awu", P, 0, 1, "y", "n", "n", "n", "y", 0, "limits not said", "'You have saved 6 things' - 7 saves in the rows; the friend's post (9 Oct, count only) is not said. Thin; 'By month?' on one month is generic. Lenient reader passes the 6 as 'shown saves' (still poor: friend's save not said)."),
 ("uyc", P, 0, 1, "y", "y", "y", "y", "y", 0, "limits not said", "6 given as all saves, friend's save not said; themes true (3 watercolor, 3 cooking). Lenient reader passes the 6 (still poor: limits not said)."),
 ("xex", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True: 6 shown, 3 YouTube (playlist) + 3 Instagram, 3/3 by theme, plus the friend's save as a count."),
 ("fx2", P, 0, 1, "y", "y", "y", "y", "y", 0, "limits not said", "6 given as all saves, friend's save not said; rest true. Lenient reader passes the 6 (still poor: limits not said)."),
 ("u38", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True; friend's save counted; window 3-30 Oct."),
 ("lhk", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; names @crumb.lab and @noodle.nights; friend's save counted. 'By month?' generic (all saves in October)."),
 ("h51", P, 0, 1, "y", "y", "y", "y", "y", 0, "limits not said", "6 given as all saves, friend's save not said. Lenient reader passes the 6 (still poor: limits not said)."),
]
M["N041.1"] = [
 ("sem", P, 0, 0, "n", "n", "y", "y", "y", 2, "misses the question", "'Which ones' answered with dates only (5, 6, 10 Oct), no titles, accounts or cards. Dates, 'saved not opened' and friend line true."),
 ("nlc", A, 0, 0, "y", "y", "n", "y", "n", 1, None, "Names the two sourdough posts with true dates; 'and A post from @noodle.nights is not named here' clumsy; no cards. Friend's save was said in the earlier answer, so not repeated is fine. 'between 5 and 15 October' literally true (saves 5-10 Oct)."),
 ("ro4", P, 0, 1, "y", "n", "n", "n", "y", 0, "limits not said", "Cards right (3, dates match). '3 of the saved items are from Instagram' - a 4th Instagram save is the friend's, never said in this conversation. Offer repeats the cards. Lenient reader passes the 3 (it follows the earlier count) and might grade acceptable."),
 ("qie", P, 0, 1, "n", "n", "n", "n", "y", 0, "misses the question", "Dates only, no names or cards; friend's Instagram save never said in this conversation. Lenient reader passes the 3 (still poor: misses 'which')."),
 ("s41", A, 0, 0, "y", "y", "y", "n", "y", 2, None, "Best content: 3 cards, same-account note, friend's save counted. No offer caps it at acceptable."),
 ("wbh", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True: 3 cards, two sourdough posts from one account, none opened. 'dated 5 to 15 October 2026, the span of your export' is loose (saves 5-10 Oct), not counted. Friend said in the earlier answer. Offer repeats the cards."),
 ("y56", P, 0, 1, "y", "n", "n", "n", "n", 0, "limits not said", "Describes the 3 by kind and date (true) with no accounts or cards; fragment points; friend's Instagram save never said in this conversation. Lenient reader passes the 3 and might grade acceptable."),
]
M["N049.0"] = [
 ("cwt", A, 0, 0, "y", "y", "n", "y", "n", 1, None, "True (all 'Integrals by parts' from Limit Lane, first 4 Jun 2023, #6 on 8 Jun 2023; 5 cards match). 'The search ranks by closeness...' is system talk. Does not say 21 or the last open (4 Oct 2026)."),
 ("se0", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True (#6 8 Jun, #18 22 Jun 2023); ask-back; one card."),
 ("qq4", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True: first 4 Jun 2023, last 4 Oct 2026, 21 videos all Limit Lane. Private line shown though no private row matches (code line, harmless)."),
 ("cy8", A, 0, 0, "y", "y", "y", "y", "y", 0, None, "True (last 4 Oct 2026; 21 times; the two before were 18 Sep 2026 and 24 Aug 2023). 'your earlier opens of it were on ...' reads as a full list beside 21 (lenient pass; clumsy)."),
 ("nul", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (4, 8, 13 Jun 2023) but 'shows up again' on two dates understates 21 opens; ask-back."),
 ("yc6", P, 1, 0, "y", "y", "y", "n", "y", 0, "wrong fact", "'Your first open of a video with integrals in the title was on 3 June 2023' - it was 4 June 2023 (3 June is a calculus video without 'integrals'). Rest true (last 4 Oct 2026, 21)."),
 ("bmw", A, 0, 0, "y", "n", "n", "n", "y", 0, None, "True (4 Oct 2026, 6 pm New York) but thin: does not say 21 videos share the title; no offer."),
]
M["N052.0"] = [
 ("e2y", A, 0, 0, "y", "n", "n", "y", "n", 0, None, "True with the private line ('100%' only by the convention). 'Home cooking in food and cooking was 100%' clumsy; tiny count unexplained."),
 ("oy7", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True: 3 Pan Theory, 23 private opens left out; explains the tiny count. '100%' true by convention."),
 ("vkr", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True; 23 private counted not shown; '100%' by convention."),
 ("hci", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True (all 600 s); point 1 repeats the lead ('3 of your videos from the window'); 23 private said."),
 ("tgj", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True by convention ('all of them food and cooking'); flat."),
 ("n8o", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True by convention; 'all long videos' a small extra."),
 ("kn0", A, 0, 0, "y", "n", "n", "y", "n", 0, None, "True by convention ('one channel'); point 3 repeats point 2."),
]
M["N052.1"] = [
 ("a1j", G, 0, 0, "y", "y", "n", "y", "y", 1, None, "True: 3 shown because 23 private items left out; direct."),
 ("rfj", P, 0, 0, "n", "n", "n", "n", "y", 0, "misses the question", "'723 videos: 142 in Oct 2026 and 0 in Nov 2023' - true but says nothing about why spring 2024 is thin."),
 ("met", A, 0, 0, "y", "y", "y", "y", "y", 1, None, "True (729 items; 2024 8; 2023 157; 2026 260 = 254 opens + 6 saves); says private items were left out, but not that they are 23 of spring's 26. 'that year stands out' tested against the private rows: 2024 is 58 with them, still far under 2023 (157) and 2026 (254), and the next point says private items were left out, so it does not read past the line (unlike kje)."),
 ("kje", P, 0, 1, "n", "n", "n", "y", "n", 0, "misses the question", "Never says private topics were left out; 'thin year' reads past the private line (2024 holds 50 private opens). 'the 8 opens of 2024 are its whole base' is wrongly based: spring 2024 shows 3 of them. Lenient reader might read it as 'the year around it' and pass it; still poor (misses the cause)."),
 ("mja", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True: 3 items, 23 private, one in each spring month (2 Mar, 16 Apr, 31 May 2024). 'And all?' unclear offer."),
 ("pfq", G, 0, 0, "y", "y", "n", "y", "y", 1, None, "True; direct cause (23 private)."),
 ("x6g", A, 0, 0, "y", "y", "n", "n", "y", 1, None, "True; direct; no offer caps it."),
]
M["N055.0"] = [
 ("ak3", P, 0, 1, "y", "n", "y", "y", "n", 2, "wrongly based", "'Friends' posts are not counted in your export' contradicts the same sentence's 'counted but not shown': the export holds the friend's save (owner_relation mutual) and it is counted. Lenient reader passes as acceptable."),
 ("y3q", P, 0, 1, "n", "n", "n", "n", "y", 0, "misses the question", "'all from the creators you follow' - the rows hold no follow status (owner_relation none): unsupported framing, wrongly based (no wrong number, name or date). The 1 friend's save is never said, so the question is not answered. A lenient reader might pass the framing; still poor."),
 ("wj7", A, 0, 0, "y", "y", "y", "y", "n", 2, None, "True; 'not counted here' = not in the 6; friend's save said last; long lead."),
 ("amg", P, 0, 1, "n", "n", "y", "y", "y", 1, "limits not said", "'it counts only what you saved, which is 6 items' - 7 saves, the friend's is counted by the tool and not said; so the question is not answered. Lenient reader passes the 6 (still poor: friend's save not said)."),
 ("acw", P, 0, 1, "n", "n", "n", "y", "y", 0, "misses the question", "Never mentions friends. 'you saved 6 items' given as all saves while the rows hold 7 (the friend's is counted by the tool, not said); same shape as awu/uyc/fx2/h51/amg. Lenient reader passes the 6 (still poor: misses)."),
 ("vet", A, 0, 0, "y", "y", "y", "y", "y", 2, None, "True; 'I can't see friends' posts' plus the friend's save count; answer buried in point 3."),
 ("hna", P, 0, 1, "y", "n", "n", "y", "y", 2, "wrongly based", "'Your export leaves friends' posts out' - the export holds it; the point then says it is counted. Lenient reader passes as acceptable."),
]
M["N062.0"] = [
 ("zw1", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: starts 2021 (5 Jan), 2021 holds 134."),
 ("wr4", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "True (134, 108, 157); no offer caps it."),
 ("h1a", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 5 Jan 2021; 134; 729 items (723 opens + 6 saves)."),
 ("p5f", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True; '50 items in topics you keep private ... not in this check' is needless limit talk (all 2024)."),
 ("e23", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: earliest Brick Realm 5 Jan 2021."),
 ("hgv", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "True (5 Jan 2021 to 30 Oct 2026; 134); no offer."),
 ("dux", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
]
M["N063.0"] = [
 ("wle", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True for 21-30 Oct: 38, gaming 19 = 50%, art 10, cooking 9 all Pan Theory. Window dates not named ('late October')."),
 ("yi4", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True and names the window (21-30 Oct): 19/38, art 10 = 26%, cooking 9 all Pan Theory."),
 ("gvh", P, 0, 0, "n", "y", "y", "y", "y", 1, "misses the question", "'I can't cut late October out' while the rows hold it (38 opens 21-30 Oct); gives all October (true: 72/142, 61, 34, 32)."),
 ("bf4", P, 0, 0, "n", "y", "y", "y", "y", 1, "misses the question", "Same as gvh: says it cannot split late October; all-October figures true."),
 ("pnu", P, 0, 0, "n", "y", "y", "y", "y", 0, "misses the question", "Answers all of October (true: 51% of 142, 61 Shorts, 34, 32) without saying it is not late October."),
 ("f3i", P, 0, 0, "n", "y", "y", "y", "y", 0, "misses the question", "All October given for late October without saying so; figures true."),
 ("jaf", P, 0, 0, "n", "n", "n", "y", "y", 1, "misses the question", "'Late October can't be read on its own' - it can; then two newest titles (true: soup 30 Oct 9 pm, clutch 29 Oct). No picture of late October."),
]
M["N063.1"] = [
 ("yu8", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 72/142, Clip Factory 61 all Gaming clips, art 24%."),
 ("uk3", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 72/142 = 51%, 61, 34, 32."),
 ("poy", A, 0, 0, "y", "y", "n", "y", "n", 1, None, "True; 'the list tool gives 10 at a time ... so I used the area and channel totals' is system talk."),
 ("q6d", A, 0, 0, "y", "n", "y", "y", "y", 1, None, "True (72, 34, 32, 4; 4 Instagram); 'export ends 15 October, so 4 of the 142 are from Instagram' is a non-sequitur 'so' (not counted)."),
 ("yei", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; lower-case area names start the points; list only."),
 ("w42", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True (cooking 23%, math 4); full split but names no channel or theme."),
 ("kb0", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True; full split plus Clip Factory 61; says YouTube export ends 30 Oct."),
]
M["N064.0"] = [
 ("dxe", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True for 1 May-31 Aug 2023: 135/138 math, calculus 75, puzzles 60, cooking 2, speedruns 1. 'almost all' is the reading."),
 ("d6o", P, 0, 0, "n", "y", "y", "y", "y", 1, "misses the question", "'Your export has no mid 2023 split' - the rows hold it; gives all 2023 (true: 135/157 = 86%, gaming 14, cooking 8)."),
 ("cf7", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 98%, 135/138."),
 ("m02", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 'almost all', 98% of 138."),
 ("jt0", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True: calculus 54%; cooking 2, speedruns 1."),
 ("b4n", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
 ("ltb", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 138 opens on 83 distinct days (span is 117 days; 'over 83 days' read as days with opens, lenient)."),
]
M["N067.0"] = [
 ("elq", A, 0, 0, "y", "y", "y", "n", "y", 1, None, "True: November not in the export; Oct 142, gaming 51%, Clip Factory 61, art 24%. No offer caps it."),
 ("a8m", P, 0, 0, "n", "y", "y", "n", "y", 0, "limits not said", "Gives October only (true) and never says November is not in the export, which is the core of the question; 'And lately?' cannot be answered."),
 ("jot", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True; 'Gaming led with 72 of what you opened' clumsy; 'By month?' after a month compare is generic."),
 ("zn0", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True: Gaming clips 66 of 142, Clip Factory 61, Home cooking next with 32 (drawing 29). 'And lately?' not worth taking after the export end."),
 ("l5o", P, 0, 0, "n", "y", "y", "n", "y", 0, "limits not said", "October figures true; November's absence never said."),
 ("rtq", A, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; no offer caps it."),
 ("zli", P, 0, 0, "n", "n", "n", "n", "y", 0, "limits not said", "October figures true; November's absence never said; list only."),
]
BEST = {
 "N004.0": "gcc - names what drove the change (gaming clips new, art 100% to 25%) with every figure true; pbj close.",
 "N010.0": "tj6 - shows the mix change (watercolor 88% to 29%) and the new drawing channel, all true.",
 "N010.1": "n1d - drawing 71% of the art and none last summer, the clearest reading of the art side.",
 "N013.0": "iby - date, quoted title, all 163 in one theme and channel, with an offer.",
 "N013.1": "uqr - date, title, channel, and that 33 videos share that title.",
 "N017.0": "hwu - leader, share and that it is all Minecraft builds.",
 "N017.1": "ewj - leader, Clip Factory all Shorts, and the all-time leader down to 13.",
 "N024.0": "g3t - full split plus what gaming is made of (Gaming clips 66).",
 "N024.1": "nxk - 87% art, the other 8 cooking (so gaming and math were none), by channel.",
 "N032.0": "i90 - 'not much', shown with gaming and evening shares against the overall.",
 "N036.0": "qq3 - 4 reels, all watercolor, and that the Instagram export ends 15 October.",
 "N041.0": "lhk - 6 by platform, theme and account, plus the friend's save as a count (xex, u38 close).",
 "N041.1": "s41 - 3 cards, the same-account note and the friend's save; only lacks an offer.",
 "N049.0": "qq4 - first and last open and that 21 videos share the title, so the person can pick.",
 "N052.0": "oy7 - 3 Pan Theory videos and that 23 private items are counted in neither figure.",
 "N052.1": "mja - names the cause (23 private) and adds one per spring month; a1j close.",
 "N055.0": "vet - says the friend's save as a count and splits the own saves cleanly (wj7 close).",
 "N062.0": "h1a - no; starts 5 Jan 2021; 134 that year; the whole span.",
 "N063.0": "yi4 - answers late October with the window named, all true.",
 "N063.1": "kb0 - full split, Clip Factory 61, and where the export ends.",
 "N064.0": "dxe - 'almost all math', both themes with channels, and the small rest.",
 "N067.0": "zn0 - says November is not in the export, then October by theme and channel.",
}
