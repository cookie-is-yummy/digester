# Loads the made-up library rows by executing the two library files' row code (no brain tools imported).
import sys, types, importlib.util
REPO = "/home/user/digester/experiments"
def load():
    spec = importlib.util.spec_from_file_location("r12", REPO + "/mvp/tests/r12_library.py")
    r12 = importlib.util.module_from_spec(spec); spec.loader.exec_module(r12)
    pkg = types.ModuleType("mvp"); tests = types.ModuleType("mvp.tests"); tests.r12_library = r12
    pkg.tests = tests
    sys.modules.setdefault("mvp", pkg); sys.modules["mvp.tests"] = tests; sys.modules["mvp.tests.r12_library"] = r12
    spec2 = importlib.util.spec_from_file_location("bl", REPO + "/mvp/tests/brain_library.py")
    bl = importlib.util.module_from_spec(spec2); spec2.loader.exec_module(bl)
    return bl
