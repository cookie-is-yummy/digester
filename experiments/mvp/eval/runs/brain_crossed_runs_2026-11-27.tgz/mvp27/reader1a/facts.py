"""reader1a facts: recount from the made-up library rows only (no brain tools). Prints the counts per message."""
import collections, re
from datetime import datetime, date
from zoneinfo import ZoneInfo
import rowload
NY = ZoneInfo("America/New_York")
bl = rowload.load()
ROWS = bl.rows()
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships (PRIVATE)"}
def chan(r): return r.get("channel") or "@" + r["handle"]
def base(t): return re.sub(r" #\d+$", "", t)
EV = []
for r in ROWS:
    for k, at in r["events"]:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r["id"], kind=k, t=t, d=t.date(), theme=r["theme"], area=AREA[r["theme"]], ch=chan(r),
                       plat=r["platform"], title=r["caption"], length=r["length"], friend=bool(r.get("friend")),
                       private=r["theme"] == "da"))
def opens(a, b, private=False, plat=None):
    return [e for e in EV if e["kind"] == "watch" and a <= e["d"] <= b and (private or not e["private"])
            and (plat is None or e["plat"] == plat)]
def pr(label, evs, keys=("area", "theme", "ch")):
    n = len(evs); print(f"  {label}: {n}")
    for k in keys:
        c = collections.Counter(THEME[e[k]] if k == "theme" else e[k] for e in evs)
        print(f"    by {k}: " + ", ".join(f"{x} {v} ({100*v/n:.1f}%)" for x, v in c.most_common()))
def priv(a, b):
    return len([e for e in EV if e["kind"] == "watch" and a <= e["d"] <= b and e["private"]])
D = date
ALL = (D(2000, 1, 1), D(2026, 11, 22))
def H(m): print("\n" + "=" * 20, m)

H("N004.0 last few weeks vs summer")
pr("4 weeks 3-30 Oct 2026", opens(D(2026, 10, 3), D(2026, 10, 30)))
print("   private in window", priv(D(2026, 10, 3), D(2026, 10, 30)))
pr("summer 2026 1 Jun-31 Aug", opens(D(2026, 6, 1), D(2026, 8, 31)))
w = opens(D(2026, 10, 3), D(2026, 10, 30)); print("   shorts (len<=60) in 4wk:", sum(1 for e in w if e["length"] and e["length"] <= 60))
print("   Pan Theory first open ever:", min(e["d"] for e in EV if e["ch"] == "Pan Theory" and e["kind"] == "watch"))
print("   Pan Theory opens 2026 before Oct:", len([e for e in opens(D(2026,1,1),D(2026,9,30)) if e['ch']=='Pan Theory']))

H("N010 summer 2026 vs summer 2025")
pr("summer 2026", opens(D(2026, 6, 1), D(2026, 8, 31)))
pr("summer 2025", opens(D(2025, 6, 1), D(2025, 8, 31)))
print("   Pixel Pencil first open:", min(e["d"] for e in EV if e["ch"] == "Pixel Pencil"))
print("   private summers:", priv(D(2026,6,1),D(2026,8,31)), priv(D(2025,6,1),D(2025,8,31)))

H("N013 minecraft first/last")
mc = sorted([e for e in EV if e["theme"] == "mc" and e["kind"] == "watch"], key=lambda e: e["t"])
for e in mc[:2] + mc[-3:]: print("  ", e["t"].isoformat(), e["title"], e["ch"])
print("   total mc opens", len(mc), "channels", collections.Counter(e["ch"] for e in mc))
print("   titles with base 'Minecraft redstone door':", sum(1 for e in EV if base(e["title"]) == "Minecraft redstone door"))
print("   any title with 'minecraft' outside mc theme:", [e["title"] for e in EV if 'minecraft' in e['title'].lower() and e['theme']!='mc'])

H("N017 channels")
pr("all history", opens(*ALL), keys=("ch",))
print("   private all:", priv(*ALL))
pr("2026 to 30 Oct", opens(D(2026, 1, 1), D(2026, 10, 30)), keys=("ch",))
cf = [e for e in opens(D(2026,1,1),D(2026,10,30)) if e['ch']=='Clip Factory']
print("   Clip Factory first open", min(e['t'] for e in cf), "all <=60s:", all(e['length']<=60 for e in cf))

H("N024 areas 2026 and 2025")
pr("2026", opens(D(2026, 1, 1), D(2026, 10, 30)), keys=("area", "theme"))
pr("2025", opens(D(2025, 1, 1), D(2025, 12, 31)), keys=("area", "theme", "ch"))
print("   private 2025/2026:", priv(D(2025,1,1),D(2025,12,31)), priv(D(2026,1,1),D(2026,12,31)))

H("N032 weekends (all history, private excluded)")
a = opens(*ALL); n = len(a)
def evening(e): return 17 <= e["t"].hour < 21
for name, f in [("Sat", lambda e: e["t"].weekday() == 5), ("Sun", lambda e: e["t"].weekday() == 6),
                ("weekend", lambda e: e["t"].weekday() >= 5), ("weekday", lambda e: e["t"].weekday() < 5),
                ("Mon", lambda e: e["t"].weekday() == 0), ("all", lambda e: True)]:
    s = [e for e in a if f(e)]
    ga = sum(1 for e in s if e["area"] == "gaming"); ar = sum(1 for e in s if e["area"] == "art and design")
    ev = sum(1 for e in s if evening(e))
    top = collections.Counter(THEME[e["theme"]] for e in s).most_common(2)
    print(f"  {name}: {len(s)} ({100*len(s)/n:.1f}% of {n}); gaming {ga} ({100*ga/max(len(s),1):.1f}%), art {ar} ({100*ar/max(len(s),1):.1f}%), evening 5-9pm {ev} ({100*ev/max(len(s),1):.1f}%), top themes {top}")
print("   by weekday:", collections.Counter(e["t"].strftime("%a") for e in a))
print("   hour dist all:", sorted(collections.Counter(e["t"].hour for e in a).items()))

H("N036 instagram october")
ig = opens(D(2026, 10, 1), D(2026, 10, 31), plat="instagram")
for e in ig: print("  ", e["d"], e["title"], THEME[e["theme"]])
print("   IG events of any kind in Oct:", collections.Counter((e['kind'], e['friend']) for e in EV if e['plat']=='instagram'))

H("N041/N055 saves")
sv = sorted([e for e in EV if e["kind"] in ("save", "playlist")], key=lambda e: e["t"])
for e in sv: print("  ", e["d"], e["kind"], e["plat"], e["ch"], THEME[e["theme"]], "FRIEND" if e["friend"] else "", e["title"][:50],
                   "opened" if any(x['id']==e['id'] and x['kind']=='watch' for x in EV) else "never opened")
print("   collections:", bl.COLLECTIONS)

H("N049 integrals")
ig2 = sorted([e for e in EV if "integral" in e["title"].lower() and e["kind"] == "watch"], key=lambda e: e["t"])
print("   n", len(ig2), "channels", collections.Counter(e["ch"] for e in ig2))
for e in ig2[:5] + ig2[-4:]: print("  ", e["t"].isoformat(), e["title"], e["length"])
ca = sorted([e for e in EV if e["theme"] == "ca"], key=lambda e: e["t"]); print("   first calculus open", ca[0]["t"], ca[0]["title"])

H("N052 spring 2024")
pr("spring 2024", opens(D(2024, 3, 1), D(2024, 5, 31)))
for e in opens(D(2024, 3, 1), D(2024, 5, 31)): print("  ", e["d"], e["title"], e["length"])
print("   private in spring 2024:", priv(D(2024, 3, 1), D(2024, 5, 31)))
for y in range(2020, 2027):
    print(f"   {y}: opens {len(opens(D(y,1,1),D(y,12,31)))}, private {priv(D(y,1,1),D(y,12,31))}, saves {len([e for e in EV if e['kind']!='watch' and e['d'].year==y and not e['friend']])}")
print("   total opens", len(opens(*ALL)), "plus own saves", len([e for e in EV if e['kind']!='watch' and not e['friend']]))
print("   Nov 2023 opens", len(opens(D(2023,11,1),D(2023,11,30))), "Oct 2026", len(opens(D(2026,10,1),D(2026,10,31))))

H("N062 2020")
print("   earliest event", min(EV, key=lambda e: e["t"])["t"], min(EV, key=lambda e: e["t"])["ch"])

H("N063 late october / all october")
pr("21-30 Oct", opens(D(2026, 10, 21), D(2026, 10, 31)))
pr("Oct 2026", opens(D(2026, 10, 1), D(2026, 10, 31)))
o = opens(D(2026, 10, 1), D(2026, 10, 31)); print("   IG in Oct", sum(1 for e in o if e['plat']=='instagram'))
for e in sorted(o, key=lambda e: e["t"])[-6:]: print("  ", e["t"].isoformat(), e["title"], e["ch"])
pr("16-31 Oct (second half)", opens(D(2026, 10, 16), D(2026, 10, 31)))

H("N064 mid 2023")
m = opens(D(2023, 5, 1), D(2023, 8, 31)); pr("1 May-31 Aug 2023", m)
print("   distinct days", len({e['d'] for e in m}), "span", min(e['d'] for e in m), max(e['d'] for e in m), (max(e['d'] for e in m)-min(e['d'] for e in m)).days+1)
pr("2023", opens(D(2023, 1, 1), D(2023, 12, 31)))
pr("Jun-Aug 2023", opens(D(2023, 6, 1), D(2023, 8, 31)), keys=("area",))

H("N067 Nov vs Oct")
print("   Nov 2026 events:", len([e for e in EV if e['d'] >= D(2026,11,1)]))

H("N036 extra: all-platform opens 1-15 Oct 2026")
pr("1-15 Oct all platforms", opens(D(2026, 10, 1), D(2026, 10, 15)), keys=("theme", "ch"))
print("   owner_relation of saved rows:", [(r['id'], 'mutual' if r.get('friend') else 'none') for r in ROWS if any(k in ('save','playlist') for k,_ in r['events'])])
print("   IG saves 1-15 Oct (own):", len([e for e in EV if e['plat']=='instagram' and e['kind']=='save' and not e['friend']]), "friend:", len([e for e in EV if e['friend']]))
