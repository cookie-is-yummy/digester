"""Reader 2b: marks for blind group 2, written from a table, with self-checks."""
import json
from collections import Counter

HERE = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader2b"
PACKET = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/blind/group2.json"

# Rules fixed before marking (applied to every code alike):
RULES = """
R1 N001.0: the person named the theme Gaming clips; every answer drops the whole gaming area (5 Minecraft builds too;
   base 66 not 71). Rubric: an area when they named a theme -> answers=n, poor, on all seven. The note gives the grade
   the answer would otherwise get.
R2 "all your history (3 to 30 October 2026)" (N042) and "all your history (12 to 15 October 2026)" (N112) give the
   span of the rows counted (saves; Instagram opens) under the system's own window label, which the code scope line
   also uses (N112). Ruled note-only, not wrongly based, for every code alike; a strict reader would count it (4 N042
   answers and N112 x4k), which would turn 4 good answers (oms, uwv, jkg, x4k) poor.
R3 Friend's post: what the tool counted is not in the packet, so "1 of your saves/matches is a friend's post" and the
   6-versus-7 saves are never counted false, for any code, whether it mentions the friend or not.
R4 A breakdown that silently drops rows that were asked for (months, small topics) is acceptable, not poor, unless a
   sentence becomes false.
R5 "Why ... all of a sudden" (N001.1): answers=y if it gives (a) the jump against before or (b) what drives it (the
   channel). Good needs both, true, and no motive guess.
R6 Rank across levels counts as wrongly based only when the rank is false at the level of the thing named.
R7 A sentence that says something about the record that the rows contradict (a false absence, "cut off in your
   history", "holds only 4 items") counts in false_n even when it is not a number. A hedge ("may exist") does not.
R8 N045 and N048.1: the rubric's cut is "bare total"; none of N045 is one, so all are answers=y and acceptable at best
   without the full list. N048.1 bt3 and kwt show the person the same "feed 50 g flour..." and get the same grade.
R10 When the whole window asked for (this week, today, November) falls after the export's end, the answer must say so;
   one that answers an earlier window without saying so is answers=n (rubric: "I can't see that" is y only when it says
   what it gives instead) and poor, "limits not said". "lately" (N001.0) is not wholly after the end: the last 4 weeks
   of the export is a fair reading, so it is not required there. Applies to N066.0 only in this packet.
R11 means=y when at least one sentence reads the figures rather than restating them: a superlative in time ("the most
   of any month", "biggest month"), a change said as such ("fell from 93% to 9%", "stopped", "jumped", "new"), a
   concentration ("all/mostly from one channel", "X alone", "came from two channels", math as 86% of the year), or an
   answer in words to a yes/no or either/or question ("most in the evening", "not at night", "yes"). Not: bare counts,
   shares, a rank among items, or a share repeating the lead. Applied through MEANS_Y below, which overrides the table.
R9 limits_talk: count every sent sentence, model or code limit line, whose content is what the bot or export cannot
   do, show or hold, or what is left out (private counts, friend "counted but not shown", "that I can show"). Not
   counted: the code private line and scope line, a small-sample caution, and a sentence that answers a question about
   the limit itself (N066.1).
"""

C = "misses the question"
T = [  # code, grade, false_n, wrongly_based_n, answers, means, more, offer, brief, limits_talk, poor_cause, note
 ("N001.0", [
  ("vj7", "poor", 0, 0, "n", "n", "y", "y", "y", 0, C, "R1. Otherwise good: every figure true, correct non-gaming base."),
  ("u33", "poor", 0, 0, "n", "n", "n", "y", "y", 0, C, "R1. Otherwise acceptable: thin, one point."),
  ("msp", "poor", 0, 0, "n", "y", "y", "y", "y", 1, C, "R1. Otherwise good: only answer with the change on the 4 weeks before (cooking +40 points from 5%, drawing -38 from 78% of non-gaming), both true."),
  ("tnk", "poor", 0, 1, "n", "n", "y", "y", "y", 0, C, "R1, and R6: 'Home cooking came next' after Digital drawing (27) ranks it second, but at theme level Home cooking (30) leads. A lenient reader passes it (Home cooking is all of food and cooking)."),
  ("n3v", "poor", 0, 0, "n", "n", "y", "y", "y", 0, C, "R1. Otherwise acceptable: '45% of what you opened' is of the non-gaming 66 (lead says without gaming), clumsy base."),
  ("ok1", "poor", 0, 0, "n", "n", "y", "y", "y", 0, C, "R1. Otherwise good."),
  ("zxh", "poor", 0, 0, "n", "n", "y", "y", "y", 1, C, "R1. Otherwise good; opens on the export end."),
 ]),
 ("N001.1", [
  ("a6b", "good", 0, 0, "y", "y", "y", "y", "y", 1, "", "30 vs 2, all Pan Theory, a channel opened since 1 Feb 2021; says the export does not say why (no guess)."),
  ("n4l", "acceptable", 0, 0, "y", "y", "n", "y", "y", 1, "", "Jump and channel true, 0 Shorts true. Point 3 (Gaming clips 45%, cooking 23%) is of all 130 opened while the scope line says only food and cooking: confusing. 'still' read as 'even so'."),
  ("l9d", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "R5: channel and 25 of 28 active days true, but nothing on 'all of a sudden' (no before figure). Hesitated with poor."),
  ("kmc", "good", 0, 0, "y", "y", "y", "y", "y", 1, "", "32 of all 72 cooking videos fall in October 2026 after 0 in September, one channel since 2021, export does not say why: all true."),
  ("czu", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "5% to 45% of non-gaming, 30 vs 2, first opened 2021, Sep 0 vs Oct 32: all true; nothing on why, no guess."),
  ("og0", "acceptable", 0, 0, "y", "y", "n", "y", "y", 0, "", "R5: jump true (2 to 30; 0 to 32 by month) but no channel; 'made up 30 of the cooking videos' is all of them."),
  ("u55", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "Jump, the one channel, the rise by month: all true."),
 ]),
 ("N008.0", [
  ("qo9", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "All true; lists without a reading (quiet to July, rise from August)."),
  ("dmi", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "R4: true, but February to June are never given in a month-by-month answer."),
  ("sjk", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "All true; no offer."),
  ("w7v", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "All true; 'By month?' repeats the ask."),
  ("h2e", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "Says what drives the rise: Digital drawing began Aug 2026, Gaming clips Oct 2026 (both true). Awkward 'together with the 142 October items'."),
  ("kq0", "poor", 0, 1, "y", "n", "y", "n", "y", 1, "wrongly based", "'Oct 2026 had 142, with 48% of them Shorts': 66 Shorts are 46.5% of 142; 48% is of the 138 YouTube videos. A lenient reader passes it as rounding. 'By month?' repeats the ask."),
  ("esr", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True; no total; 'Without art and design?' odd here."),
 ]),
 ("N008.1", [
  ("x5t", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "Gaming 72 = 51%, Gaming clips 66, Clip Factory 61, Pan Theory 32 next among channels: all true."),
  ("tw6", "acceptable", 0, 0, "y", "n", "y", "y", "n", 0, "", "All true; point 1 repeats the lead (72, then 51%); four parts."),
  ("v25", "poor", 0, 0, "n", "n", "n", "n", "y", 0, C, "Lists the 5 newest of 142 items (true) with no overview of what the month holds; 'from 29 October' sits beside a 30 October item."),
  ("hg3", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "All true; 'Without gaming?' fits."),
  ("htr", "poor", 0, 0, "n", "n", "n", "n", "y", 1, "bare fallback", "'could not get the breakdown of that month in time': nothing in it (provider timeout)."),
  ("kzm", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "Theme ranking 66, 32, 29 with channels: true."),
  ("i3s", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True but thin; no art and design."),
 ]),
 ("N012.0", [
  ("mkx", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "157 vs 108, math 0->86%, gaming 93->9% (-84), new themes, Minecraft 59 then 0: all true."),
  ("u3x", "good", 0, 0, "y", "y", "y", "n", "y", 0, "", "All true incl. Speedruns 41 -> 14; no offer."),
  ("zg1", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "All true."),
  ("xlz", "acceptable", 0, 0, "y", "y", "y", "y", "y", 0, "", "All true; lower-case 'math', 'gaming' opening points."),
  ("ym6", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; lower-case names; new themes not named."),
  ("o5h", "good", 0, 0, "y", "y", "y", "n", "y", 0, "", "All true; no offer."),
  ("vk3", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "True (first opened 3 June 2023); no totals, Number puzzles not named."),
 ]),
 ("N014.0", [
  ("aao", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True, card; nothing more, no offer."),
  ("y0e", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "True; no card, no channel; unasked export-end sentence first."),
  ("ey5", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True, card; nothing more, no offer."),
  ("n8u", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True, card; nothing more, no offer."),
  ("dg4", "acceptable", 0, 0, "y", "n", "y", "n", "y", 0, "", "True (Pan Theory, 1 of 72) but no card or link; generic offer."),
  ("cx6", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True, card; nothing more, no offer."),
  ("wvc", "good", 0, 0, "y", "y", "y", "n", "y", 0, "", "True; all 72 cooking opens are Pan Theory, so 'same channel as your other cooking videos' holds. Generic offer."),
 ]),
 ("N016.0", [
  ("v3q", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True, card, private line; nothing more."),
  ("dfv", "acceptable", 0, 0, "y", "n", "y", "n", "y", 1, "", "True; 'that I can show' hedge; no card."),
  ("td3", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "'title shared by 33 of your items' true (33 rows); odd extra but true."),
  ("uqb", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "3:00 pm New York true; card."),
  ("p28", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "R7: 'an earlier one may exist' - the 50 private rows are all 2024, none earlier; a hedge, not counted. No card."),
  ("ndi", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "True; a point spent on the private count; generic offer."),
  ("sn2", "acceptable", 0, 0, "y", "n", "n", "n", "y", 2, "", "'that I can see' and 'may not be your very first view' hedge against the rows; no card."),
 ]),
 ("N018.0", [
  ("u08", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "90, Speedruns, 35/41/14 by year: true. None says it stopped on 1 May 2023 or gives ~15 hours."),
  ("n2m", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; long videos, theme, years."),
  ("f5a", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; first 1 Mar 2021; lead names the history window as the span."),
  ("wnq", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True."),
  ("xdi", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True but thin: no years."),
  ("wcm", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; lower-case 'speedruns'."),
  ("fqq", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; ranks the years."),
 ]),
 ("N018.1", [
  ("i1e", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; 'only Brick Realm gave you 163' reads oddly (scope word); 2026's 13 left out."),
  ("ef4", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "163, 91/59, 0 in 2023, 13 in 2026: true. None compares with Frame Perfect's 90."),
  ("lb8", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; 67% evening = 109 of 163."),
  ("suw", "poor", 0, 1, "y", "n", "n", "y", "y", 0, "wrongly based", "'only Brick Realm shows up: 163 videos, 100% of what you opened': 100% is of the Brick Realm filter, said of all opened. A lenient reader passes it via the scope line."),
  ("ryq", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True."),
  ("ktm", "acceptable", 0, 0, "y", "n", "y", "y", "n", 0, "", "True (67% evening right) but point 1 restates the lead's 'all'; four parts."),
  ("f1n", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; system talk 'the only channel in this result'."),
 ]),
 ("N022.0", [
  ("e6f", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; Calculus 48% tucked into the Number puzzles point."),
  ("o9j", "acceptable", 0, 0, "y", "y", "y", "y", "y", 0, "", "R4: true; Home cooking (8) left out."),
  ("nig", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "Complete: math 86%, both themes, Odd Prime, gaming 14, cooking 8: true."),
  ("x6a", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "Complete and true, flat."),
  ("ns8", "good", 0, 0, "y", "y", "n", "y", "y", 0, "", "Complete and true; area share first."),
  ("wjd", "acceptable", 0, 0, "y", "y", "n", "y", "y", 0, "", "R4: Speedruns 14 and Home cooking 8 left out."),
  ("ptq", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "Complete and true with shares; no reading."),
 ]),
 ("N022.1", [
  ("i0r", "good", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; one channel per theme (R11 means). Upgraded after the means re-pass."),
  ("bre", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; Mon/Tue tie at 20 true (trivia)."),
  ("u99", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "Two channels, 75 of 135 = 56%: true."),
  ("uja", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "56/44 split, channels, weekday tie: true."),
  ("xan", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; lower-case theme names."),
  ("jk9", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "Adds math across all history: 145 = 135 in 2023 + 10 in 2026, none 2024-25 (true): shows a 2023 burst and a return. None says it was the summer (3 Jun to 25 Aug)."),
  ("l1x", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; mixes a channel lead and a theme share."),
 ]),
 ("N027.0", [
  ("ljo", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "'mostly in the evening, not at night': 498/723 = 69%, night 1, afternoon 219: true."),
  ("yjg", "good", 0, 0, "y", "n", "n", "n", "y", 0, "", "True; 'most ... in the evening', 'only 1' at night answers in words (R11). No offer. Upgraded after the means re-pass."),
  ("tb7", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "True; private count repeats the private line; 'Afternoon had 219 of what you opened' clumsy."),
  ("uh0", "poor", 0, 0, "n", "n", "n", "y", "y", 0, "bare fallback", "Only 'you opened 723 videos': nothing on time of day."),
  ("gfm", "acceptable", 0, 0, "y", "n", "n", "y", "y", 1, "", "True; private count repeats the private line."),
  ("ac0", "good", 0, 0, "y", "n", "y", "y", "y", 0, "", "True; busiest hour 4-5 pm = 179/723 = 25%."),
  ("nca", "good", 0, 0, "y", "n", "n", "y", "y", 0, "", "True, brief; 'most in the evening' answers in words (R11). Upgraded after the means re-pass."),
 ]),
 ("N042.0", [
  ("m64", "good", 0, 0, "y", "n", "y", "n", "y", 1, "", "No likes said once, then 6 saves by platform and theme: true. No offer."),
  ("bt5", "acceptable", 0, 0, "y", "n", "n", "y", "y", 1, "", "True but thin."),
  ("t3e", "good", 0, 0, "y", "n", "y", "n", "y", 1, "", "R2: 'saved 6 items from 3 to 30 October' passes (saves fall 3-10 Oct). 'And all your history?' adds nothing."),
  ("tlj", "poor", 0, 0, "n", "n", "n", "n", "y", 0, "limits not said", "Never says the export holds no likes, so the question goes unanswered. R2 note: 'all your history (3 to 30 October 2026)' (history starts 5 Jan 2021)."),
  ("oms", "good", 0, 0, "y", "n", "y", "n", "y", 2, "", "No likes said once, 6 saves by theme, friend's save as a count (R3). R2 note: 'In all your history (3 to 30 October 2026 ...)'; a strict reader marks it wrongly based. 'And in October?' adds nothing."),
  ("uwv", "good", 0, 0, "y", "n", "y", "y", "y", 1, "", "No likes said once; Wet Paper 3 of 6 true. R2 note: 'in all your history (3 to 30 October 2026 ...)'; a strict reader marks it wrongly based."),
  ("jkg", "good", 0, 0, "y", "n", "y", "n", "y", 2, "", "No likes, 6 saves by theme, friend's count (R3). R2 note: 'all your history, which runs 3 to 30 October 2026' is the plainest of the five; a strict reader marks it wrongly based. No offer."),
 ]),
 ("N045.0", [
  ("k91", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "R8: 6 true; 3 of the 6 as cards (newest three, dates right); 'By month?' generic on one month."),
  ("zfs", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "R8: 1 of 6 named, no cards. Hesitated with poor."),
  ("k2m", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "R8: 2 named (dates true); 'of the calculus lessons, 6 were from Limit Lane' implies others elsewhere (all are Limit Lane)."),
  ("dw8", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "R8: 1 named; 6 long videos on 6 days true."),
  ("i1j", "acceptable", 0, 0, "y", "n", "y", "y", "y", 0, "", "R8: 1 named; 6 days true."),
  ("wv7", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "R8: 2 named, true."),
  ("j5j", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "R8: 2 named, true."),
 ]),
 ("N048.0", [
  ("n1l", "good", 0, 0, "y", "n", "y", "n", "y", 1, "", "Right post, card, second save; friend 'match' not checkable (R3). No offer."),
  ("t90", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "Right post, card, second save: true."),
  ("fjh", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "Same as t90."),
  ("zob", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "Right post and card, nothing more."),
  ("m6g", "acceptable", 0, 0, "y", "n", "y", "n", "y", 1, "", "True but no card or link."),
  ("e2k", "acceptable", 0, 0, "y", "n", "y", "n", "y", 1, "", "'It is a clear match for your search' system talk."),
  ("lsi", "good", 0, 0, "y", "n", "y", "n", "y", 1, "", "Both cards; lead does not quote the title, the card does."),
 ]),
 ("N048.1", [
  ("bt3", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "R8: only the cut title 'feed 50 g flour...'; the caption goes on 'and 50 g water, wait 12 hours'."),
  ("l6z", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "Paraphrase true (flour and water, then wait) but drops 50 g and 12 hours; 'can't see more of the post's text' doubtful; no card."),
  ("pj0", "poor", 1, 0, "n", "n", "n", "n", "y", 1, "wrong fact", "'Two of your saved sourdough items mention flour': only the starter post does; never says what it said."),
  ("b2u", "poor", 0, 0, "n", "n", "n", "n", "y", 0, C, "Never says what the post said about flour; no card."),
  ("rib", "poor", 0, 0, "n", "n", "n", "n", "y", 0, "bare fallback", "'Here's what I found.' plus two cards."),
  ("kwt", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "R8: text says only that it mentions flour; the card shows 'feed 50 g flour...' (same as bt3). Generic offer."),
  ("r0k", "poor", 0, 0, "n", "n", "n", "n", "y", 0, "bare fallback", "'Here's what I found.' plus two cards."),
 ]),
 ("N057.0", [
  ("k0h", "acceptable", 0, 0, "y", "n", "y", "n", "n", 2, "", "126 on 28 days, Shorts 47%, evenings 71% (89/126) true; no-watch-time said twice (lead and code line); never 'about 4 to 5 a day'."),
  ("jht", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "True; no per-day figure."),
  ("yn2", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "True but thin."),
  ("yb9", "acceptable", 0, 0, "y", "n", "n", "y", "y", 1, "", "True; 'Only long videos?' fits."),
  ("icg", "acceptable", 0, 0, "y", "n", "n", "n", "n", 2, "", "True; limit said twice."),
  ("apy", "acceptable", 0, 0, "y", "n", "n", "y", "n", 2, "", "True; limit said twice."),
  ("pkn", "acceptable", 0, 0, "y", "n", "n", "n", "n", 2, "", "True; limit said twice; 'Clip Factory made 56 of them' after the Shorts point is ambiguous (56 of 59 Shorts or of 126), true either way."),
 ]),
 ("N066.0", [
  ("cew", "poor", 0, 0, "n", "n", "y", "y", "y", 0, "limits not said", "R10: figures true (24: 13/6/5) for 24-30 Oct, but this week (16-22 Nov) is wholly after the export's end and it never says so; answers=n by the rubric's 'can't see' clause. The person has to ask next."),
  ("kz2", "good", 0, 0, "y", "n", "y", "y", "y", 1, "", "Export end said once; 13 (54%), 6, 5: true."),
  ("gl2", "poor", 0, 0, "n", "n", "n", "y", "y", 0, "limits not said", "As cew; lower-case 'gaming clips'; channel after theme rank holds at channel level (R6, not counted)."),
  ("rco", "good", 0, 0, "y", "n", "y", "y", "y", 1, "", "True; Home cooking left out."),
  ("kuk", "good", 0, 0, "y", "n", "y", "y", "y", 1, "", "True."),
  ("nqq", "poor", 0, 0, "n", "n", "n", "y", "y", 0, "limits not said", "As cew."),
  ("h56", "good", 0, 0, "y", "n", "y", "y", "y", 1, "", "True; the date said twice in the lead."),
 ]),
 ("N066.1", [
  ("qmb", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "YouTube end only; Instagram's 15 Oct left out; thin."),
  ("wwv", "poor", 1, 0, "y", "n", "y", "n", "y", 0, "wrong fact", "R7: Instagram 'holds only 4 items': it holds 7 you can see (4 opened, 3 saved) plus a friend's post."),
  ("bxr", "good", 0, 0, "y", "y", "n", "n", "y", 0, "", "Both ends and 'nothing after' true; no offer."),
  ("xfz", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "Both ends; 7 of 729 Instagram true; 'And this year?' unrelated."),
  ("di3", "acceptable", 0, 0, "y", "n", "y", "n", "y", 0, "", "YouTube end only; newest item true."),
  ("tfw", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "Both ends, true, bare."),
  ("mu4", "good", 0, 0, "y", "y", "n", "n", "y", 0, "", "Both ends, says nothing later is there."),
 ]),
 ("N069.0", [
  ("jf6", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "Right video, channel, date, card; title quoted as data, not followed."),
  ("wnb", "acceptable", 0, 0, "y", "n", "n", "n", "y", 1, "", "System talk about how search matches."),
  ("c3d", "poor", 1, 0, "y", "n", "n", "n", "y", 1, "wrong fact", "R7: 'Its title is cut off in your history': the row holds the full title. No card."),
  ("ckt", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True; no card, no channel."),
  ("n6m", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "Lead does not name it; 'closest match to your search' system talk; card."),
  ("nvt", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True; no card."),
  ("ljc", "good", 0, 0, "y", "n", "y", "n", "y", 0, "", "Adds the other October watercolor opens, the 4 @wetpaper.ig reels 12-15 Oct: true."),
 ]),
 ("N109.0", [
  ("l1y", "acceptable", 0, 0, "y", "n", "n", "n", "n", 2, "", "Right (count only) but said twice."),
  ("o63", "acceptable", 0, 0, "y", "n", "n", "n", "n", 2, "", "Right but said twice."),
  ("y4f", "poor", 1, 0, "n", "n", "n", "n", "y", 0, "wrong fact", "R7 false absence: one friend's post is saved (9 Oct) and counted."),
  ("eku", "poor", 1, 0, "n", "n", "n", "n", "y", 0, "wrong fact", "R7 false absence; offer to search rests on it."),
  ("rer", "poor", 1, 0, "n", "n", "n", "n", "y", 0, "wrong fact", "R7 false absence."),
  ("k77", "acceptable", 0, 0, "y", "n", "y", "n", "y", 1, "", "'Your other saves are listed' with none shown (read as 'on record', not counted); lesson 2 saved 4 Oct true. Hesitated with poor."),
  ("o0w", "good", 0, 0, "y", "n", "y", "n", "y", 1, "", "Count only, then the two newest other saves (10 Oct, 6 Oct; the friend's 9 Oct skipped): true."),
 ]),
 ("N112.0", [
  ("xqn", "good", 0, 0, "y", "y", "y", "y", "y", 0, "", "'Yes': 4 reels, all 8 am, small sample: true."),
  ("hvt", "good", 0, 0, "y", "y", "y", "n", "y", 0, "", "'too few to call a habit'; 'And lately?' adds nothing."),
  ("l9l", "acceptable", 0, 0, "y", "n", "y", "y", "y", 1, "", "True; 'no times of day beyond those parts' muddled; 'hour 8'."),
  ("x4k", "good", 0, 0, "y", "y", "y", "n", "y", 0, "", "True; no offer. R2 note: 'all your history (12 to 15 October 2026 ...)'."),
  ("omh", "acceptable", 0, 0, "y", "n", "n", "n", "n", 1, "", "4-week framing though it is the whole Instagram history; heavy."),
  ("mo6", "acceptable", 0, 0, "y", "n", "n", "y", "y", 0, "", "True; '4 of them' repeats."),
  ("sf6", "acceptable", 0, 0, "y", "n", "n", "n", "y", 0, "", "True; 'on 4 items' clumsy. None notes the 4 saves were also mornings (11 am)."),
 ]),
]

BEST = {
 "N001.0": "msp: the only one that says what changed against the 4 weeks before (cooking up 40 points, drawing down 38); all marked poor by R1, this one would otherwise be good.",
 "N001.1": "kmc: 32 of all 72 cooking videos in one month after 0 in September, one channel since 2021, and honest that the export cannot say why.",
 "N008.0": "h2e: gives every month and says what drove the rise (Digital drawing from August, Gaming clips from October).",
 "N008.1": "hg3: gaming half the month, Gaming clips and Clip Factory, then art and cooking, with a fitting 'Without gaming?'.",
 "N012.0": "mkx: math took over from gaming, with the shares, the new themes and Minecraft stopping.",
 "N014.0": "wvc: the right video with its card, plus that all cooking comes from one channel.",
 "N016.0": "uqb: the first video, channel, date and time, card, no hedging.",
 "N018.0": "n2m: 90 videos, theme, long videos and the year split.",
 "N018.1": "lb8: 163 videos, the gap in 2023 and return in 2026, and the evening habit.",
 "N022.0": "nig: complete topic breakdown with the math share first and the channel behind Number puzzles.",
 "N022.1": "jk9: the 56/44 split plus math across all history (a 2023 burst, back in 2026).",
 "N027.0": "ljo: answers night-or-day in words (evening, not night) with the shares.",
 "N042.0": "m64: says once there are no likes, then what the saves are, with no wrong span.",
 "N045.0": "k91: the only one that shows videos (3 cards) as well as the count.",
 "N048.0": "t90: the right post with card and the second sourdough save, nothing extra.",
 "N048.1": "l6z: the only one that says what the post says (feed with flour and water, then wait), though it drops the amounts.",
 "N057.0": "k0h: says plainly it cannot give minutes, then counts, Shorts share and the evening habit (limit said twice, though).",
 "N066.0": "kz2: says this week is not in the export, then the last 7 days by theme.",
 "N066.1": "bxr: both export ends and that nothing after them is held.",
 "N069.0": "ljc: the right video with card, plus the other October watercolor reels.",
 "N109.0": "o0w: says the friend's post is counted only, once, then offers the newest saves it can show.",
 "N112.0": "xqn: a direct 'yes' with the count, the theme and that it is a small sample.",
}

MEANS_Y = {  # R11, one pass over every answer
 "N001.0": {"vj7", "u33", "msp", "tnk", "n3v", "ok1", "zxh"},
 "N001.1": {"a6b", "n4l", "l9d", "kmc", "czu", "og0", "u55"},
 "N008.0": {"dmi", "w7v", "h2e", "esr"},
 "N008.1": {"x5t", "tw6", "kzm"},
 "N012.0": {"mkx", "u3x", "zg1", "xlz", "ym6", "o5h", "vk3"},
 "N014.0": {"wvc"},
 "N016.0": set(),
 "N018.0": {"fqq"},
 "N018.1": set(),
 "N022.0": {"o9j", "nig", "ns8", "wjd"},
 "N022.1": {"i0r", "bre", "u99", "uja", "xan", "jk9", "l1x"},
 "N027.0": {"ljo", "yjg", "tb7", "gfm", "ac0", "nca"},
 "N042.0": {"uwv"},
 "N045.0": {"zfs", "dw8", "i1j", "wv7"},
 "N048.0": set(),
 "N048.1": set(),
 "N057.0": {"k0h", "icg"},
 "N066.0": {"cew", "gl2", "kuk", "h56"},
 "N066.1": {"bxr", "mu4"},
 "N069.0": set(),
 "N109.0": set(),
 "N112.0": {"xqn", "hvt", "l9l", "x4k", "omh", "mo6", "sf6"},
}

GR = {"good", "acceptable", "poor"}
CAUSES = {"wrong fact", "misses the question", "thin", "wrongly based", "limits not said", "says too much about limits",
          "bare fallback", "other"}
YN = {"y", "n"}

pk = json.load(open(PACKET))
want = {(m["key"], a["code"]) for m in pk["messages"] for a in m["answers"]}
out = []
for key, rows in T:
    for code, g, f, w, ans, me, mo, of, br, lt, cause, note in rows:
        assert g in GR and {ans, me, mo, of, br} <= YN and isinstance(f, int) and isinstance(w, int) and lt >= 0
        if g == "poor":
            assert cause in CAUSES, (key, code)
        else:
            assert cause == "", (key, code)
        if ans == "n" or f or w:
            assert g == "poor", (key, code)
        if g == "good":
            assert ans == "y" and f == 0 and w == 0, (key, code)
        me = "y" if code in MEANS_Y[key] else "n"
        out.append(dict(message_id=key, code=code, grade=g, false_n=f, wrongly_based_n=w, answers=ans, means=me,
                        more=mo, offer=of, brief=br, limits_talk=lt, poor_cause=cause or None, note=note))
got = [(r["message_id"], r["code"]) for r in out]
assert len(got) == len(set(got)), "duplicate"
assert set(got) == want, (want - set(got), set(got) - want)
assert set(BEST) == {m["key"] for m in pk["messages"]} == set(MEANS_Y)
for k, cs in MEANS_Y.items():
    assert cs <= {c for (m, c) in want if m == k}, k
for k, line in BEST.items():
    assert line.split(":")[0] in {c for (m, c) in want if m == k}, k
json.dump(out, open(f"{HERE}/marks.json", "w"), indent=1)
with open(f"{HERE}/best.txt", "w") as fh:
    for m in pk["messages"]:
        fh.write(f"{m['key']}  {BEST[m['key']]}\n")
open(f"{HERE}/rules.txt", "w").write(RULES)
print("answers marked:", len(out))
print("grades:", Counter(r["grade"] for r in out))
print("false sentences:", sum(r["false_n"] for r in out), "in", sum(1 for r in out if r["false_n"]), "answers")
print("wrongly based:", sum(r["wrongly_based_n"] for r in out), "in", sum(1 for r in out if r["wrongly_based_n"]), "answers")
print("poor causes:", Counter(r["poor_cause"] for r in out if r["grade"] == "poor"))
for k in ("answers", "means", "more", "offer", "brief"):
    print(k, "y:", sum(r[k] == "y" for r in out))
print("limits_talk total:", sum(r["limits_talk"] for r in out))
