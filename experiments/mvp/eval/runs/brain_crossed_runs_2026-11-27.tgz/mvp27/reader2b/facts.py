"""Reader 2b facts, printed per message. Run: python3 facts.py [MSGKEY ...]"""
import sys
from collections import Counter
from datetime import date, timedelta

sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader2b")
from lib import events, between, count, show, ROWS  # noqa: E402

W = events("watch")
YT = [e for e in W if e["platform"] == "youtube"]
IGW = [e for e in W if e["platform"] == "instagram"]
END = date(2026, 10, 30)
NOPRIV = lambda evs: [e for e in evs if "PRIVATE" not in e["area"]]  # noqa: E731


def hdr(k):
    print("\n" + "=" * 80 + "\n" + k)


def N001():
    hdr("N001.0  apart from gaming clips, lately")
    for d0 in (END - timedelta(days=27), END - timedelta(days=28)):
        w = between(W, d0, END)
        print(f" window {d0}..{END}: all opened {len(w)} (yt {sum(e['platform']=='youtube' for e in w)}, ig {sum(e['platform']=='instagram' for e in w)})")
        show("areas", count(w, "area"))
        ng = [e for e in w if e["area"] != "gaming"]
        show("areas without gaming", count(ng, "area"))
        show("themes without gaming", count(ng, "theme"))
        show("channels without gaming", count(ng, "channel"))
        nc = [e for e in w if e["theme"] != "Gaming clips"]
        show("themes without Gaming clips theme only", count(nc, "theme"))
        p0, p1 = d0 - timedelta(days=28), d0 - timedelta(days=1)
        pw = [e for e in between(W, p0, p1) if e["area"] != "gaming"]
        print(f"  prior 4w {p0}..{p1} without gaming: n={len(pw)}")
        show("prior areas w/o gaming", count(pw, "area"))
        show("prior themes w/o gaming", count(pw, "theme"))
    hdr("N001.1  why so much cooking")
    co = [e for e in W if e["theme"] == "Home cooking"]
    print(" all cooking opened:", len(co), " first:", co[0]["day"], co[0]["channel"])
    print(" cooking channels:", count(co, "channel"))
    bym = Counter((e["day"].year, e["day"].month) for e in co)
    print(" cooking by month 2026:", {k: v for k, v in sorted(bym.items()) if k[0] == 2026})
    print(" cooking by year:", Counter(e["day"].year for e in co))
    for d0 in (END - timedelta(days=27),):
        w = between(W, d0, END)
        c = [e for e in w if e["theme"] == "Home cooking"]
        p = [e for e in between(W, d0 - timedelta(days=28), d0 - timedelta(days=1)) if e["theme"] == "Home cooking"]
        print(f" 4w cooking {len(c)} of {len(w)} ({100*len(c)/len(w):.1f}%), prior 4w cooking {len(p)}")
        print(" days active in 4w:", len({e['day'] for e in w}), " days with cooking:", len({e['day'] for e in c}))
        pw = between(W, d0 - timedelta(days=28), d0 - timedelta(days=1))
        png = [e for e in pw if e["area"] != "gaming"]
        print(f" prior 4w cooking share of non-gaming {len(p)}/{len(png)}")
        print(" shorts among cooking:", sum(1 for e in c if (e['length'] or 999) <= 60))
        show("4w themes all", count(w, "theme"))
    sats = [r for r in ROWS if r["platform"] == "instagram" and r["theme"] == "co"]
    print(" instagram cooking rows (saved):", [(r["id"], r["events"]) for r in sats])


def N008():
    hdr("N008.0 month by month this year")
    y = [e for e in W if e["day"].year == 2026]
    print(" 2026 opened all:", len(y), " yt:", sum(e['platform'] == 'youtube' for e in y))
    print(" by month all:", sorted(Counter(e["day"].month for e in y).items()))
    print(" by month yt :", sorted(Counter(e["day"].month for e in y if e['platform'] == 'youtube').items()))
    print(" private in 2026:", sum("PRIVATE" in e["area"] for e in y))
    for m in range(1, 11):
        mm = [e for e in y if e["day"].month == m]
        print(f"  m{m}: {dict(count(mm,'theme'))}")
    hdr("N008.1 biggest month = Oct 2026")
    o = [e for e in y if e["day"].month == 10]
    show("Oct areas", count(o, "area"))
    show("Oct themes", count(o, "theme"))
    show("Oct channels", count(o, "channel"))
    sh = [e for e in o if e["length"] and e["length"] <= 60]
    print(" Oct shorts (<=60s):", len(sh), f"{100*len(sh)/len(o):.1f}% of all 142;", f"{100*len(sh)/sum(e['platform']=='youtube' for e in o):.1f}% of the YouTube-only base", sum(e['platform']=='youtube' for e in o))
    print(" newest:", [(e["caption"], str(e["day"])) for e in o[-6:]][::-1])
    print(" first Digital drawing:", min(e["day"] for e in W if e["theme"] == "Digital drawing"),
          " first Gaming clips:", min(e["day"] for e in W if e["theme"] == "Gaming clips"))


def N012():
    hdr("N012.0 2023 vs 2022")
    for yr in (2022, 2023):
        y = [e for e in W if e["day"].year == yr]
        print(f" {yr}: {len(y)}")
        show("areas", count(y, "area"))
        show("themes", count(y, "theme"))
        print("  first/last per theme:", {t: (min(e['day'] for e in y if e['theme'] == t), max(e['day'] for e in y if e['theme'] == t)) for t in set(e['theme'] for e in y)})
    for t in ("Calculus lessons", "Number puzzles", "Minecraft builds", "Speedruns"):
        ev = [e for e in W if e["theme"] == t]
        print(f" {t}: first {ev[0]['day']} last {ev[-1]['day']} by year {sorted(Counter(e['day'].year for e in ev).items())}")


ALL = [N001, N008, N012]
from mvp.tests import brain_library as B  # noqa: E402
if __name__ == "__main__":
    want = sys.argv[1:]
    for f in ALL:
        if not want or f.__name__ in want:
            f()


def part_of_day(h):
    return "morning 5-12" if 5 <= h < 12 else "afternoon 12-17" if 12 <= h < 17 else "evening 17-21" if 17 <= h < 21 else "night 21-5"


def N014_N016():
    hdr("N014.0 last cooking video")
    co = [e for e in W if e["theme"] == "Home cooking"]
    print(" last 3 cooking opened:", [(e["caption"], str(e["at_ny"]), e["channel"]) for e in co[-3:]])
    print(" cooking opened total:", len(co), "channels", count(co, "channel"))
    print(" instagram cooking saves (not opened):", [(e["caption"][:30], str(e["day"])) for e in events("save") if e["theme"] == "Home cooking"])
    hdr("N016.0 first thing ever")
    allv = events(include_friend=True)
    print(" first 3 events of any kind:", [(e["caption"], e["kind"], str(e["at_ny"]), e["channel"], e["length"]) for e in allv[:3]])
    priv = [e for e in W if "PRIVATE" in e["area"]]
    print(" private rows:", len(priv), "first", priv[0]["day"], "last", priv[-1]["day"])
    t0 = allv[0]["caption"].split(" #")[0]
    print(f" items with title starting '{t0}':", sum(1 for r in ROWS if r["caption"].startswith(t0)))


def N018():
    hdr("N018.0 / N018.1  Frame Perfect / Brick Realm")
    for ch in ("Frame Perfect", "Brick Realm"):
        ev = [e for e in W if e["channel"] == ch]
        print(f" {ch}: {len(ev)}, first {ev[0]['day']} last {ev[-1]['day']}, by year {sorted(Counter(e['day'].year for e in ev).items())}, themes {dict(count(ev,'theme'))}, lengths {set(e['length'] for e in ev)}")
        print("   part of day:", count(ev, "pod") if "pod" in ev[0] else Counter(part_of_day(e['at_ny'].hour) for e in ev))
        print("   hours of video:", sum(e['length'] or 0 for e in ev) / 3600)


def N022():
    hdr("N022.0 / N022.1  2023 by topic, math deeper")
    y = [e for e in W if e["day"].year == 2023]
    show("2023 themes", count(y, "theme"))
    m = [e for e in y if e["area"] == "math"]
    show("2023 math themes", count(m, "theme"))
    show("2023 math channels", count(m, "channel"))
    print(" math by month 2023:", sorted(Counter(e["day"].month for e in m).items()))
    print(" math weekdays 2023:", Counter(e["at_ny"].strftime("%a") for e in m).most_common())
    print(" all 2023 weekdays:", Counter(e["at_ny"].strftime("%a") for e in y).most_common())
    am = [e for e in W if e["area"] == "math"]
    print(" math all history:", len(am), sorted(Counter(e["day"].year for e in am).items()))
    print(" first/last math 2023:", m[0]["day"], m[-1]["day"])


def N027():
    hdr("N027.0  night or day (NY time, private left out)")
    np_ = NOPRIV(W)
    print(" opened non-private:", len(np_), " with private:", len(W))
    c = Counter(part_of_day(e["at_ny"].hour) for e in np_)
    show("part of day", c)
    print(" by hour:", sorted(Counter(e["at_ny"].hour for e in np_).items()))
    hc = Counter(e["at_ny"].hour for e in np_).most_common(1)[0]
    print(" busiest hour:", hc, f"{100*hc[1]/len(np_):.1f}%")
    print(" night items:", [(e["caption"], str(e["at_ny"])) for e in np_ if part_of_day(e["at_ny"].hour) == "night 21-5"])
    pv = [e for e in W if "PRIVATE" in e["area"]]
    print(" private part of day:", Counter(part_of_day(e["at_ny"].hour) for e in pv))
    y = [e for e in np_ if e["day"].year == 2026]
    print(" 2026 part of day:", Counter(part_of_day(e["at_ny"].hour) for e in y))


def N042():
    hdr("N042.0  likes vs saves")
    print(" event kinds in library:", Counter(k for r in ROWS for k, _ in r["events"]))
    s = events("save", include_friend=True) + events("playlist", include_friend=True)
    for e in sorted(s, key=lambda e: e["at_utc"]):
        print("  ", e["kind"], e["platform"], e["channel"], e["theme"], e["day"], "FRIEND" if e["friend"] else "", e["caption"][:40])
    nf = [e for e in s if not e["friend"]]
    print(" non-friend saves:", len(nf), dict(count(nf, "theme")), dict(count(nf, "platform")), dict(count(nf, "channel")))


def N045():
    hdr("N045.0  calculus Sept 2026")
    c = [e for e in W if e["theme"] == "Calculus lessons" and e["day"].year == 2026 and e["day"].month == 9]
    for e in c:
        print("  ", e["id"], e["caption"], e["day"], e["at_ny"].strftime("%H:%M"), e["channel"], e["length"])
    print(" n:", len(c), " days:", len({e['day'] for e in c}))
    o = [e for e in W if e["theme"] == "Calculus lessons" and e["day"].year == 2026 and e["day"].month == 10]
    print(" Oct 2026 calculus:", [(e['caption'], str(e['day'])) for e in o])


def N048():
    hdr("N048.0 / N048.1  sourdough")
    for r in ROWS:
        if "flour" in r["caption"].lower() or "sourdough" in r["caption"].lower() or r.get("friend"):
            print("  ", r["id"], r.get("handle"), r["events"], repr(r["caption"]), "FRIEND" if r.get("friend") else "")
    print(" collections:", B.COLLECTIONS)


def N057():
    hdr("N057.0  minutes a day")
    d0 = END - timedelta(days=27)
    w = [e for e in between(YT, d0, END)]
    print(" 4w yt opened:", len(w), " days active:", len({e['day'] for e in w}), " per day:", len(w) / 28)
    sh = [e for e in w if e["length"] and e["length"] <= 60]
    print(" shorts:", len(sh), f"{100*len(sh)/len(w):.1f}%", count(sh, "channel"))
    show("channels", count(w, "channel"))
    show("themes", count(w, "theme"))
    print(" part of day:", Counter(part_of_day(e["at_ny"].hour) for e in w))
    tot = sum(e["length"] or 0 for e in w)
    print(f" sum of lengths: {tot/60:.0f} min, per day over 28: {tot/60/28:.1f} min")
    alle = NOPRIV(YT)
    tot2 = sum(e["length"] or 0 for e in alle)
    span = (END - date(2021, 1, 5)).days + 1
    print(f" all history yt (no private): {len(alle)} videos, {tot2/60:.0f} min, per day {tot2/60/span:.1f}")


def N066():
    hdr("N066.0 / N066.1  this week / export end")
    w = between(W, END - timedelta(days=6), END)
    print(" 7d", END - timedelta(days=6), END, "n", len(w), count(w, "platform"))
    show("themes", count(w, "theme"))
    show("channels", count(w, "channel"))
    show("areas", count(w, "area"))
    ig = [r for r in ROWS if r["platform"] == "instagram"]
    print(" instagram rows:", len(ig), " non-friend:", sum(not r.get("friend") for r in ig), " opened:", len(IGW),
          " last ig event:", max(a for r in ig for _, a in r["events"]))
    nonpriv_items = [r for r in ROWS if r["theme"] != "da" and not r.get("friend")]
    print(" items non-private non-friend:", len(nonpriv_items), " all rows:", len(ROWS))
    print(" last yt event:", YT[-1]["caption"], YT[-1]["at_ny"])


def N069():
    hdr("N069.0  watercolor tips October")
    for e in events():
        if e["theme"] == "Watercolor painting" and e["day"].year == 2026 and e["day"].month == 10:
            print("  ", e["id"], e["kind"], e["platform"], e["channel"], e["day"], repr(e["caption"]))


def N109_N112():
    hdr("N109.0  friend's post")
    for r in ROWS:
        if r.get("friend"):
            print("  ", r)
    s = sorted([e for e in events("save") + events("playlist") if not e["friend"]], key=lambda e: e["at_utc"])
    print(" non-friend saves newest first:", [(e["channel"], str(e["day"]), e["caption"][:30]) for e in s[::-1]])
    hdr("N112.0  instagram mornings")
    for e in events(platform="instagram", include_friend=True):
        print("  ", e["kind"], e["at_ny"].strftime("%Y-%m-%d %H:%M"), part_of_day(e["at_ny"].hour), e["channel"], e["theme"], "FRIEND" if e["friend"] else "")


ALL += [N014_N016, N018, N022, N027, N042, N045, N048, N057, N066, N069, N109_N112]
if __name__ == "__main__" and sys.argv[1:] == ["rest"]:
    for f in ALL[3:]:
        f()
