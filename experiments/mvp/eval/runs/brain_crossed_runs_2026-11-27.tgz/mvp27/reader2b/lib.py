"""Reader 2b: plain facts from the made-up library rows. Reads rows only; imports no brain tool."""
import sys
from collections import Counter, defaultdict
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # noqa: E402  (rows only)

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships (PRIVATE)"}

ROWS = B.rows()


def events(kind=None, platform=None, include_friend=False):
    """Flat list of events: dict(id, kind, at_utc, at_ny, day, theme, area, channel, platform, length, caption)."""
    out = []
    for r in ROWS:
        if r.get("friend") and not include_friend:
            continue
        if platform and r["platform"] != platform:
            continue
        for k, at in r["events"]:
            if kind and k != kind:
                continue
            t = datetime.fromisoformat(at)
            ny = t.astimezone(NY)
            out.append(dict(id=r["id"], kind=k, at_utc=t, at_ny=ny, day=ny.date(), theme=THEME[r["theme"]],
                            area=AREA[r["theme"]], channel=r.get("channel") or "@" + r.get("handle", ""),
                            platform=r["platform"], length=r["length"], caption=r["caption"],
                            published=r["published"], friend=bool(r.get("friend"))))
    return sorted(out, key=lambda e: e["at_utc"])


def between(evs, d0, d1):
    return [e for e in evs if d0 <= e["day"] <= d1]


def count(evs, key):
    return Counter(e[key] for e in evs)


def show(title, c, base=None):
    tot = sum(c.values()) if base is None else base
    print(f"  {title} (n={tot}):")
    for k, v in c.most_common():
        print(f"     {k:28s} {v:5d}  {100 * v / tot:5.1f}%")
