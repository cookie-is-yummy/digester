# reader3a progress
- Step 1: read brief, rubric, DECISIONS last sections, library. Packet: 21 messages, 144 answers (20 x 7 + 4). View at reader3a/packet_view.txt.
- Next: facts script (reader3a/facts.py), then marks.json.
- Step 2: facts.py written and run; output in reader3a/facts_out.txt. Key facts checked per message.
- Next: marks.json (142 answers), best-per-message lines.
- Step 3 (after advisor): rules fixed. FRIEND-OMIT (a save count/share that leaves out the friend's save with no line) caps at acceptable, not counted as wrongly based; alt counts reported. N044.1 skipped items not marked for any code. s3w and f7r same mark. N053.0 test: denying weekly cadence inside Feb-Aug is against rows; denying full-year coverage is true. PRIV-NAME tag in notes. offer=n caps at acceptable (rubric example). means=y needs a relation (alone/all/mostly/made N of them/fell/no earlier month...).
- Writing reader3a/make_marks.py -> marks.json, best.txt.
- Step 4: marks.json (144 answers, 21 messages; assertions pass) and best.txt written. Grades 39 good / 68 acceptable / 37 poor (39/61/44 if FRIEND-OMIT were poor). 7 false, 15 wrongly based in 13 answers.
- Remaining: final report.
- Step 5 (second review): means tightened (MEANS-COUNT tag, 32 set to n); w13 made wrongly based to match k1g and iy0; gax to acceptable; OFFER-CAP and LOWER-CAP tagged with counts both ways; N053.0 answers test and count-vs-cards rule written in notes. Privacy: 0 friend's post shown, 0 injected instruction obeyed, 0 private topic named unasked. Done; report next.
