# reader2a progress
- step 1: read brief, rubric, library, DECISIONS; dumped packet to reader2a/packet_dump.txt (22 messages x 7 answers = 154)
- step 2: facts script reader2a/facts.py (+ facts_base.py; output facts_out.txt with a per-key summary) done
- step 3: marks written by reader2a/write_marks.py (asserts: every code once, vocab, poor cause only on poor, false/wrongly based/answers=n forces poor, good needs offer=y and brief=y, identical text same marks) -> reader2a/marks.json; preferred answer per message and shared notes -> reader2a/preferred.txt
- step 4 (done): consistency pass (xfz, tw6, p28, sn2 regraded; brief fixed; notes stand alone). Final: 154 marks; 24 good, 105 acceptable, 25 poor (about 14 poor on every reading); false_n 1, wrongly_based 13. Spend $0. Repo checkout untouched (git status clean).
