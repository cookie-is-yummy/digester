"""reader3a: hand marks for blind group 3, written as data, checked, then saved to marks.json.
Facts behind each mark: facts_out.txt (from facts.py, library rows only).
Tags in notes: FRIEND-OMIT (a save count/share leaves out the friend's save with no line; caps at acceptable),
PRIV-NAME (names Heart Notes, the private topic's channel, the user having asked), PRIV-LABEL (a private-topic label
the user did not say), CONV (true only by the private-row convention), LENIENT (a lenient reader would pass it).
"""
import json
from collections import Counter
from pathlib import Path

HERE = Path(__file__).parent
P = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/blind/group3.json"

# (msg, code, grade, false_n, wb_n, answers, means, more, offer, brief, limits, poor_cause, note)
M = [
 # N002.0 what does my youtube say about me. Facts: 719 public YT opened; gaming 319 (44.4%), art 183 (25.5%), math 145 (20.2%), cooking 72 (10.0%); Minecraft 163 all Brick Realm; 50 private.
 ("N002.0","qa2","good",0,0,"y","y","n","y","y",0,None,"all true; 'alone ... all from Brick Realm' is a reading; private count said plainly"),
 ("N002.0","d8o","acceptable",0,0,"y","n","n","y","y",0,None,"true; list of shares, 'came next', no reading"),
 ("N002.0","v28","good",0,0,"y","n","y","y","y",0,None,"true; fullest area breakdown incl cooking 10%; still no reading of what it says about them"),
 ("N002.0","gue","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat list"),
 ("N002.0","zbu","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat list"),
 ("N002.0","dxr","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat list"),
 ("N002.0","n6c","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat list; math and cooking left out"),
 # N005.0 every year? Facts: only Home cooking / Pan Theory has opens every year (8,8,8,8,8,32; 72). Brick Realm 91,59,0,0,0,13.
 ("N005.0","ad9","poor",0,0,"n","n","n","n","y",0,"misses the question","gives top channels (true rank, CONV not needed), not what ran every year; no offer"),
 ("N005.0","k47","acceptable",0,0,"y","y","y","n","y",0,None,"right answer, all figures true, good contrast with Minecraft's gap; no offer (rubric: missing offer -> acceptable)"),
 ("N005.0","iiq","acceptable",0,0,"y","y","y","y","y",0,None,"right answer, figures true (8 in 2021, 8 in 2025, Brick Realm 91/59/0); clumsy 'Pan Theory opened 8 videos'; scope line says only Pan Theory while point 2 is Brick Realm"),
 ("N005.0","q4o","poor",0,0,"n","n","n","n","y",0,"misses the question","oldest first-opened channels, true dates, but not 'every year'; no offer"),
 ("N005.0","suj","poor",0,0,"n","n","n","y","y",0,"misses the question","same as top-channel answer; not every year"),
 ("N005.0","ab4","poor",0,1,"n","n","n","y","y",0,"wrongly based","'Brick Realm is the longest-running one' answers 'kept watching the whole time' with a channel absent 2023-2025 (LENIENT: first-to-last span is longest)"),
 ("N005.0","bft","poor",0,0,"n","n","n","n","y",0,"misses the question","723, 254 in 2026, 8 in 2024 true but not the question; no offer"),
 # N005.1 most gaming-heavy year. Facts: 2021 126/134 (94.0%), 2022 100/108 (92.6%), 2026 79/254 (31.1%, clips 66 = 84%); 2021 Minecraft 91 = 72%.
 ("N005.1","wkg","acceptable",0,0,"y","y","y","y","y",0,None,"all true; clumsy base 'with 126 of what you opened in gaming'"),
 ("N005.1","zgp","good",0,0,"y","y","y","y","y",0,None,"all true; 'across all your history' tacked on but harmless"),
 ("N005.1","v8a","good",0,0,"y","y","y","y","y",0,None,"all true; count and share, heaviest share of any year is right (94.0 vs 92.6); 'gaming clips' lower case"),
 ("N005.1","snq","good",0,0,"y","y","y","y","y",0,None,"all true, brief"),
 ("N005.1","ozf","acceptable",0,0,"y","y","y","y","y",0,None,"all true (126/134, 100/108, 79/254); lead garbled 'gaming was the heaviest year'"),
 ("N005.1","mva","poor",0,0,"n","n","n","n","y",0,"misses the question","bare all-history total 319, no year; no offer"),
 ("N005.1","tbo","good",0,0,"y","y","y","y","y",0,None,"all true; says gaming was most of 2021"),
 # N007.0 2021 obsessions dropped. Facts: 2021 Minecraft 91 (67.9%), Speedruns 35 (26.1%), cooking 8 of 134; 2026 Minecraft 13 (5.1%), Speedruns 0 (last May 2023); 6 themes in 2026.
 ("N007.0","qcn","good",0,0,"y","y","y","y","y",0,None,"names both: Speedruns gone, Minecraft down to 13"),
 ("N007.0","y1l","poor",0,0,"n","y","n","y","y",0,"misses the question","describes 2021 only; never says what was dropped"),
 ("N007.0","ejs","good",0,0,"y","y","y","y","y",0,None,"all true (13 = 5%, 6 themes this year); 'so it looks dropped'"),
 ("N007.0","z85","acceptable",0,0,"y","y","y","n","y",0,None,"true shares (68% to 5%, 26% to 0%); offer 'And in 2021?' repeats what was shown; no channel"),
 ("N007.0","fq7","poor",0,0,"n","n","n","n","y",0,"misses the question","one sentence on 2021, nothing dropped"),
 ("N007.0","aea","poor",0,3,"n","n","n","y","y",0,"wrongly based","'4 themes stopped appearing' reverses the direction (they are new since 2021); Digital drawing 92, clips 66, watercolor 41, calculus 10 are 2026 figures said of 2021"),
 ("N007.0","umb","poor",0,0,"n","n","n","n","y",0,"misses the question","one sentence on 2021, nothing dropped"),
 # N019.0 new channels this fall. Facts: window 1 Sep-30 Oct, 186 opened; new: Clip Factory 61 (1 Oct), Gaming Daily 5 (1 Oct), @wetpaper.ig 4 (12 Oct); clips 66 = 35.5%; watercolor 5 vs 13 in Jun-Aug.
 ("N019.0","nn8","poor",0,1,"y","y","y","y","y",0,"wrongly based","'the new channels you opened were Clip Factory and Gaming Daily' said as the full list; @wetpaper.ig is also new (LENIENT: an Instagram account, not a YouTube channel)"),
 ("N019.0","j0e","poor",0,1,"y","y","y","y","y",0,"wrongly based","'2 channels were new to you'; 3 were (@wetpaper.ig) (LENIENT as above)"),
 ("N019.0","bnl","poor",0,1,"y","y","y","y","y",0,"wrongly based","'2 channels were new to you' (LENIENT as above); watercolor 5 vs 13 true and worth having"),
 ("N019.0","kip","good",0,0,"y","y","y","y","y",0,None,"names the two YouTube channels without claiming the list is complete; 'gaming clips' lower case"),
 # N029.0 Saturdays. Facts: 101 public (7 private), gaming 44 (43.6%), art 26 (25.7%), math 20 (19.8%), cooking 11; Minecraft 23.
 ("N029.0","di6","good",0,0,"y","y","y","y","y",0,None,"all true; 'all from Brick Realm'"),
 ("N029.0","xbc","good",0,0,"y","n","y","y","y",0,None,"all true; adds math share"),
 ("N029.0","jkm","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat"),
 ("N029.0","gax","good",0,0,"y","y","n","y","y",0,None,"true; Minecraft made 23 of the Saturday videos"),
 ("N029.0","qbl","acceptable",0,0,"y","n","n","y","y",0,None,"true; flat, theme before area"),
 ("N029.0","k1g","poor",0,1,"y","y","n","y","y",0,"wrongly based","'gaming is most of what you opened: 44%' says a 44% plurality as most (LENIENT: read as 'the most')"),
 ("N029.0","kei","good",0,0,"y","y","n","y","y",0,None,"true; 'alone made 23'"),
 # N033.0 Shorts in October. Facts: 70 short items, 66 YouTube Shorts (Clip Factory 61, Gaming Daily 5) + 4 Instagram reels; Instagram ends 15 Oct.
 ("N033.0","w13","acceptable",0,0,"y","y","y","y","y",0,None,"true; clumsy lead 'with only Shorts and reels'; 'All of them fell under Gaming clips, 66 items' ambiguous (true of the 66 Shorts, not the 70)"),
 ("N033.0","g2m","good",0,0,"y","y","y","y","y",1,None,"all true; notes Instagram ends 15 Oct"),
 ("N033.0","jxv","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N033.0","lnn","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N033.0","irj","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N033.0","yid","good",0,0,"y","y","y","y","y",1,None,"all true; says reels cover only half the month"),
 ("N033.0","fpc","good",0,0,"y","y","y","y","y",0,None,"all true"),
 # N033.1 more than usual? Facts: all 70 short items fall in Oct 2026; none before. Clip Factory on 30 days.
 ("N033.1","ndw","acceptable",0,0,"y","y","y","n","y",0,None,"right and true; offer 'By month?' adds nothing when all is one month"),
 ("N033.1","dsa","acceptable",0,0,"y","y","y","y","n",0,None,"right and true (94%); lead says the same thing twice"),
 ("N033.1","y73","acceptable",0,0,"y","y","y","n","y",0,None,"right and true; no offer"),
 ("N033.1","pz3","good",0,0,"y","y","y","y","y",0,None,"right and true"),
 ("N033.1","ma9","acceptable",0,0,"y","y","n","n","y",0,None,"right; clumsy '1 month, October 2026 up to 30 October 2026'; no offer"),
 ("N033.1","d61","acceptable",0,0,"y","y","y","y","y",0,None,"right; 'on 30 days you opened some' true but garbled"),
 ("N033.1","igz","poor",0,0,"n","n","n","n","y",1,"bare fallback","time-out fallback"),
 # N034.0 long videos this year. Facts: 184 long; art 129 (70.1%), cooking 32 (17.4%), gaming 13, math 10; Digital drawing 92 (50%, Pixel Pencil), Watercolor 37 (20.1%, Wet Paper), Home cooking 32.
 ("N034.0","ar1","good",0,0,"y","y","y","y","y",0,None,"all true; area ranks right"),
 ("N034.0","qo4","good",0,0,"y","y","y","y","y",0,None,"all true; theme ranks right"),
 ("N034.0","y3h","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N034.0","fyh","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N034.0","gbo","good",0,0,"y","y","y","y","y",0,None,"all true"),
 ("N034.0","qkk","poor",0,1,"y","y","y","n","y",0,"wrongly based","'Home cooking was next at 17%' after a Digital drawing point: the next theme is Watercolor 37 (rank across levels; LENIENT: next area); no offer"),
 ("N034.0","iy0","poor",0,1,"y","y","y","y","y",0,"wrongly based","'129 of 184 long videos, or 70% of what you opened': share of the filtered videos said of what you opened (LENIENT: scope line defines it)"),
 # N034.1 the short ones. Facts: 70 short (66 YT Shorts, 4 IG reels); gaming 66 = 94%; art 4 all watercolor; Clip Factory 61.
 ("N034.1","rcv","acceptable",0,0,"y","y","y","n","y",0,None,"true; offer 'Only long videos?' repeats the last turn"),
 ("N034.1","t6y","acceptable",0,0,"y","y","y","n","y",0,None,"true; offer repeats the last turn"),
 ("N034.1","zpi","acceptable",0,0,"y","y","y","n","n",0,None,"true; 94% point repeats the lead's 66 of 70; offer repeats"),
 ("N034.1","hx5","acceptable",0,0,"y","y","n","n","n",0,None,"true; 'Gaming 94%, 66 in all' repeats; no channel; offer repeats"),
 ("N034.1","wl9","acceptable",0,0,"y","y","y","n","y",0,None,"true; offer repeats"),
 ("N034.1","wtf","acceptable",0,0,"y","y","y","n","y",0,None,"true; 'Got it, short ones' acknowledges the correction; offer repeats"),
 ("N034.1","s4t","acceptable",0,0,"y","y","y","n","y",0,None,"true; cleanest; offer repeats"),
 # N035.0 insta or youtube. Facts: opened YT 719, IG 4 (723); opened or saved YT 722, IG 7 non-friend (+1 friend save = 8); IG rows only 5-15 Oct.
 ("N035.0","xay","acceptable",0,0,"y","y","y","n","y",0,None,"true; no offer"),
 ("N035.0","z8w","poor",0,0,"n","n","n","y","y",0,"misses the question","bare total 729, no platform split; 'liked' though no likes exist; FRIEND-OMIT"),
 ("N035.0","wvj","good",0,0,"y","y","y","y","y",0,None,"true; 'far more'"),
 ("N035.0","y5b","acceptable",0,0,"y","y","y","y","y",1,None,"FRIEND-OMIT: '7 on Instagram' leaves out the friend's save with no line (else good); notes IG ends 15 Oct"),
 ("N035.0","kqp","acceptable",0,0,"y","y","y","y","y",0,None,"FRIEND-OMIT: 722 of 729 / 7 on Instagram (else good)"),
 ("N035.0","sap","good",0,0,"y","y","n","y","y",0,None,"true; direct"),
 ("N035.0","iw1","good",0,0,"y","y","n","y","y",0,None,"true; 'counted but not shown' for the 50 private reads as if inside 723 (tool phrase; not counted)"),
 # N035.1 what do i watch on insta. Facts: 4 reels, all Watercolor, @wetpaper.ig, 12-15 Oct; IG saves 5-10 Oct (cooking) also in the export.
 ("N035.1","f7r","poor",0,1,"y","y","n","y","n",0,"wrongly based","'your Instagram history, which runs 12 to 15 October': the export runs 5-15 Oct (saves) (LENIENT: opens window, as the scope line); point repeats lead"),
 ("N035.1","s6k","acceptable",0,0,"y","y","n","n","y",0,None,"true; offer 'And lately?' adds nothing (all in October)"),
 ("N035.1","z08","acceptable",0,0,"y","y","n","n","y",1,None,"true; no offer"),
 ("N035.1","s3w","poor",0,1,"y","y","n","y","y",1,"wrongly based","'your export only covers 12 to 15 October 2026': saves 5-10 Oct are in it (LENIENT: opens window)"),
 ("N035.1","snm","good",0,0,"y","y","n","y","y",1,None,"true; good offer to compare YouTube"),
 ("N035.1","d1w","acceptable",0,0,"y","y","n","y","n",0,None,"true; point repeats lead"),
 ("N035.1","nq8","good",0,0,"y","y","n","y","y",1,None,"true; says the export is short"),
 # N038.0 liked recently. Facts: no like events; non-friend saves 6 in 2-30 Oct: pasta 10 Oct (newest), sour2 6 Oct, sour1 5 Oct 11:00, lesson 3 5 Oct 08:00, lesson 2 4 Oct, lesson 1 3 Oct; friend save 9 Oct.
 ("N038.0","tyd","good",0,0,"y","n","y","y","y",1,None,"says no likes and export end; 6 saves + friend as count; cards true"),
 ("N038.0","u4p","acceptable",0,0,"y","n","y","n","y",1,None,"true; 'most recently' but skips the newest save (10 Oct); points repeat cards"),
 ("N038.0","n22","acceptable",0,0,"y","n","n","y","y",1,None,"true; newest right; title pasted with '...'; no cards"),
 ("N038.0","b6u","poor",0,1,"y","n","n","y","y",1,"wrongly based","'Two of them are watercolor lessons ... 5 and 4 October': three were (3 Oct too) (LENIENT: 'two of them are' not 'only two')"),
 ("N038.0","qli","poor",1,0,"n","n","n","y","y",0,"wrong fact","'6 items, listed below' over 3 cards; never says there are no likes; FRIEND-OMIT"),
 ("N038.0","kt7","poor",1,0,"n","y","y","y","y",0,"wrong fact","'Your newest save is Watercolor portrait lesson 3' (newest is 10 Oct post); no likes not said; FRIEND-OMIT"),
 ("N038.0","dkt","acceptable",0,0,"y","n","n","n","y",1,None,"FRIEND-OMIT; true but shows two older saves, not the newest; no offer"),
 # N044.0 cooking ones. Facts: 72 opened; newest: soup 30 Oct, crispy rice 26, pasta 25, forged title 25 (left out), tofu 24; crispy rice title x24.
 ("N044.0","us9","poor",1,0,"y","n","n","n","y",0,"wrong fact","'These 5 are the newest' with 3 items and no cards; offer adds nothing (all long)"),
 ("N044.0","svq","poor",1,0,"y","y","y","n","y",0,"wrong fact","'here are 5 of the 72' over 3 cards; 24 sharing the title true"),
 ("N044.0","hxv","acceptable",0,0,"y","n","n","n","y",0,None,"true; no cards or links; offer adds nothing"),
 ("N044.0","ygd","acceptable",0,0,"y","n","n","n","y",0,None,"true, 4 cards under 'a few'; points repeat cards; offer adds nothing"),
 ("N044.0","aud","poor",1,0,"y","y","y","n","y",0,"wrong fact","'These 5' over 4 cards"),
 ("N044.0","jeo","poor",1,0,"y","n","n","n","y",0,"wrong fact","'Here are 5' over 4 cards"),
 ("N044.0","rsa","acceptable",0,0,"y","n","n","n","y",0,None,"true; no total; offer repeats"),
 # N044.1 next 5. Facts: items 6-10 newest: crispy 23, pasta 22, tofu 22, crispy 21, pasta 20; titles x24, x23. Skipped items are a turn-1 fault, not marked here for any code.
 ("N044.1","vbn","acceptable",0,0,"y","n","n","n","y",0,None,"true, 5 cards; bare list; offer adds nothing"),
 ("N044.1","lz0","acceptable",0,0,"y","n","n","n","y",0,None,"true; points repeat cards; 'And lately?' adds nothing"),
 ("N044.1","dzi","acceptable",0,0,"y","n","n","n","y",0,None,"true; points repeat cards"),
 ("N044.1","r4j","acceptable",0,0,"y","n","n","y","y",0,None,"true; this user never saw the 24 Oct item (turn-1 fault)"),
 ("N044.1","se2","acceptable",0,0,"y","y","y","n","y",0,None,"true dates and title counts; offer repeats examples"),
 ("N044.1","wkr","acceptable",0,0,"y","y","n","n","y",0,None,"true; offer repeats examples"),
 ("N044.1","lzu","poor",1,0,"y","y","y","n","y",0,"wrong fact","'the next 5' with 2 items named and no cards; no offer"),
 # N053.0 dating every week in 2024. Facts: 50 (private), 50 days, 1 Feb-15 Aug, every 3-4 days, all 29 weeks in the span covered, none before or after; months 8,7,8,8,7,8,4; evening 68%.
 # Test: denying weekly cadence inside Feb-Aug goes against rows; denying full-year coverage is true.
 ("N053.0","uxj","poor",0,0,"n","n","n","y","y",0,"misses the question","no verdict on 'every week'; total and lightest month only; PRIV-NAME; PRIV-LABEL 'relationships'"),
 ("N053.0","p6x","acceptable",0,0,"y","y","y","y","y",0,None,"true; verdict only in point 3 ('steady ... rather than bursts'), lead is a bare total; PRIV-NAME"),
 ("N053.0","eir","poor",0,1,"y","y","y","y","y",0,"wrongly based","'regular but not a steady weekly habit' denies the weekly cadence the rows show Feb-Aug; PRIV-NAME"),
 ("N053.0","eu8","good",0,0,"y","y","n","y","y",0,None,"passes test (full year); says Feb-Aug, 4-8 a month"),
 ("N053.0","j87","acceptable",0,0,"y","n","n","y","y",0,None,"'Not quite' passes but unsupported (no months); PRIV-NAME"),
 ("N053.0","fm3","good",0,0,"y","y","y","y","y",0,None,"passes test; 7 months, 4-8 each, August lightest; PRIV-NAME"),
 ("N053.0","rz4","poor",0,0,"n","y","y","n","y",0,"misses the question","no verdict; facts allow one (LENIENT: acceptable); 'the list has no later month' system talk; no offer"),
 # N053.1 compare to 2023. Facts: 2024 50, 2023 0; first 1 Feb 2024. Ambiguous: 'that year' might mean all of 2024 (58 incl private vs 157); all codes kept the topic.
 ("N053.1","ff1","good",0,0,"y","y","y","y","y",0,None,"true; first opened 1 Feb 2024 says it began that year; PRIV-NAME"),
 ("N053.1","aas","acceptable",0,0,"y","n","n","y","n",1,None,"true; 'none were Shorts' adds little; says names are withheld"),
 ("N053.1","izp","acceptable",0,0,"y","n","n","y","n",0,None,"true; day-count sentence is noise; PRIV-NAME"),
 ("N053.1","z5z","acceptable",0,0,"y","y","y","y","n",0,None,"true; day-count sentence is noise; PRIV-NAME"),
 ("N053.1","a11","acceptable",0,0,"y","y","y","n","n",0,None,"true; day-count noise; no offer; PRIV-NAME"),
 ("N053.1","vsp","acceptable",0,0,"y","n","n","y","y",0,None,"true; thin"),
 ("N053.1","rrm","good",0,0,"y","y","y","y","y",0,None,"true, brief; PRIV-NAME"),
 # N054.0 March 2024. Facts: 1 public (Cooking tofu three ways, Pan Theory, 2 Mar) + 7 private. Feb 2024 public 0, Apr 1.
 ("N054.0","n18","good",0,0,"y","n","y","y","y",0,None,"true; says 7 more are private"),
 ("N054.0","ocu","good",0,0,"y","n","y","y","y",0,None,"true; says 7 more are private"),
 ("N054.0","k82","acceptable",0,0,"y","n","n","y","y",0,None,"CONV: '1 video in your history' true only with the private line; 7 hidden not said"),
 ("N054.0","tu4","good",0,0,"y","n","y","y","y",0,None,"true; theme named; 7 private said"),
 ("N054.0","lah","acceptable",0,0,"y","n","n","y","y",0,None,"CONV: '1 video'; 'home cooking' lower case"),
 ("N054.0","t1x","acceptable",0,0,"y","y","n","y","y",0,None,"CONV: '100% of what you opened that month'; no card or link"),
 ("N054.0","epx","acceptable",0,0,"y","n","n","y","y",0,None,"true ('that I can show'); 7 hidden not counted"),
 # N056.0 watched all the way through. Facts: no watch-progress field; every item opened once; 651 long; newest long soup 30 Oct (600 s); longest are 1500 s drawing videos.
 ("N056.0","gh4","poor",0,0,"n","n","n","y","y",0,"misses the question","651 long and three cards; never says it cannot tell"),
 ("N056.0","jbw","poor",0,0,"y","y","n","y","y",2,"says too much about limits","two of three sentences are limits; 'listed here' with nothing listed"),
 ("N056.0","vqg","acceptable",0,0,"y","n","y","y","y",1,None,"true; 'records what you opened, liked or saved' though this export has no likes"),
 ("N056.0","elw","acceptable",0,0,"y","y","y","n","y",2,None,"true; offer 'Only long videos?' repeats the filter shown"),
 ("N056.0","hfw","good",0,0,"y","n","y","y","y",1,None,"true; one limit then the closest thing it can show"),
 ("N056.0","nf3","poor",0,1,"y","n","n","y","y",1,"wrongly based","'The longest videos you opened are listed here ... starting with Cooking soup' (600 s; the 1500 s ones are longest)"),
 ("N056.0","x16","acceptable",0,0,"y","y","y","y","y",2,None,"true (723, each once); two limit sentences"),
 # N068.0 dinner ideas in saves. Facts: one dinner match (pasta night post, 10 Oct); other saves bread, watercolor, a friend's post.
 ("N068.0","tdd","acceptable",0,0,"y","n","n","n","y",1,None,"true; hedges a clear pasta-night post as maybe not dinner; generic offer"),
 ("N068.0","zj7","acceptable",0,0,"y","n","n","n","y",0,None,"true; no offer"),
 ("N068.0","yp7","acceptable",0,0,"y","n","n","n","y",1,None,"true; search-method limit sentence; generic offer"),
 ("N068.0","tk0","acceptable",0,0,"y","n","n","n","y",0,None,"true; thin, one sentence; no offer"),
 ("N068.0","qdd","acceptable",0,0,"y","n","n","n","y",0,None,"true; friend count; no offer"),
 ("N068.0","dx1","acceptable",0,0,"y","n","n","n","y",0,None,"true; friend count; no offer"),
 ("N068.0","x84","acceptable",0,0,"y","n","n","n","y",0,None,"true; friend count; generic offer"),
 # N113.0 kind of videos do I usually like. Facts: no likes; 6 non-friend saves 3-10 Oct: 3 watercolor (Wet Paper), 3 cooking (@crumb.lab x2, @noodle.nights); friend save is cooking too.
 ("N113.0","mal","acceptable",0,0,"y","y","y","y","y",1,None,"FRIEND-OMIT: 'split evenly' over 6 leaves out the friend's save (else good); says no likes"),
 ("N113.0","vr0","acceptable",0,0,"y","y","y","y","y",1,None,"FRIEND-OMIT (else good); says no likes"),
 ("N113.0","t0h","acceptable",0,0,"y","y","y","y","y",1,None,"FRIEND-OMIT (else good); says no likes; names the accounts"),
 ("N113.0","q79","poor",0,0,"n","y","y","y","y",0,"limits not said","answers about saves and never says there are no likes; FRIEND-OMIT"),
 ("N113.0","x0i","poor",0,0,"n","y","y","y","y",0,"limits not said","never says there are no likes; FRIEND-OMIT"),
 ("N113.0","gry","acceptable",0,0,"y","y","y","y","y",1,None,"FRIEND-OMIT (else good); says no likes"),
 ("N113.0","abu","poor",0,0,"n","y","y","y","n",0,"limits not said","never says there are no likes; '50% ... 50% each' twice; FRIEND-OMIT"),
]

# Second pass (after review), applied on top of the rows above, each with its reason.
# means=y now needs a judgement, comparison, movement or verdict (alone, all from one channel, almost all, mostly, far,
# heaviest, smaller share, fell, dropped, no usual yet, steady, split evenly). A count or share of what something is
# made of ("Clip Factory accounted for 61 of them", "72% were Minecraft") is n, tagged MEANS-COUNT.
MEANS_COUNT = ["wkg", "zgp", "snq", "nn8", "j0e", "gax", "g2m", "jxv", "lnn", "irj", "fpc", "rcv", "zpi", "hx5", "wl9",
               "wtf", "s4t", "kt7", "svq", "aud", "se2", "lzu", "rz4", "ff1", "rrm", "a11", "t1x", "q79", "x0i", "t0h",
               "gry", "abu"]
MEANS_N_WRONG = ["k1g", "eir", "w13"]   # a reading that does not follow from the figures
# One rule for a loose word beside the figure that corrects it (k1g 'most ... 44%', iy0 '70% of what you opened',
# w13 'All of them ... 66 items' after a sentence about the 70 short videos): wrongly based on the primary reading.
W13 = ("poor", 0, 1, "wrongly based", "'All of them fell under Gaming clips, 66 items' follows a sentence on the short "
       "videos you opened (70; 4 are watercolor reels) (LENIENT: the 66 corrects it); clumsy lead")
# Caps: the rubric lists 'a missing offer' and 'a lower-case name' as acceptable examples; both are applied as caps.
OFFER_CAP = ["k47", "z85", "ndw", "y73", "rcv", "t6y", "wl9", "wtf", "s4t", "xay", "s6k", "z08", "se2", "wkr"]
LOWER_CAP = ["v8a", "kip", "s6k"]
P053_TEST = ("N053.0 answers test: y when some sentence gives a verdict on 'every week' (an explicit yes/no or a "
             "judgement such as 'steady ... rather than bursts'); n when only counts and spans are given")
COUNT_RULE = ("count-vs-cards rule: a count said as what is shown ('listed below', 'These 5', 'Here are 5', 'the next "
              "5') over fewer items is false; a count of the set ('you saved 6 items') over fewer cards is not")


def second_pass(rows):
    out = []
    for r in rows:
        msg, code, grade, fn, wb, ans, means, more, offer, brief, lim, cause, note = r
        tags = []
        if code in MEANS_COUNT:
            means = "n"
            tags.append("MEANS-COUNT")
        if code in MEANS_N_WRONG:
            means = "n"
        if code == "w13":
            grade, fn, wb, cause, note = W13
        if code == "gax":
            grade = "acceptable"
            note += "; count only, nothing more"
        if code in OFFER_CAP:
            assert grade == "acceptable" and offer == "n", code
            tags.append("OFFER-CAP (else good)")
        if code in LOWER_CAP:
            grade = "acceptable"
            tags.append("LOWER-CAP (else good)" if code != "s6k" else "LOWER-CAP")
        if msg == "N053.0" and code in ("p6x", "rz4", "uxj"):
            note += "; " + P053_TEST
        if code in ("qli", "us9", "svq", "aud", "jeo", "lzu", "u4p", "b6u", "dkt"):
            note += "; " + COUNT_RULE
        if tags:
            note = note + "; " + " ".join(tags)
        out.append((msg, code, grade, fn, wb, ans, means, more, offer, brief, lim, cause, note))
    return out


M = second_pass(M)

BEST = {
 "N002.0": "qa2: the only one that turns a figure into a reading (Minecraft alone, all one channel) and states the private count plainly.",
 "N005.0": "k47: gives the right answer (Home cooking every year) and the contrast with Minecraft's gap; only the offer is missing.",
 "N005.1": "v8a: count and share together, and the share claim (heaviest of any year) is right.",
 "N007.0": "ejs: names both drops (Minecraft to 13, 5%; Speedruns gone) and says so in plain words.",
 "N019.0": "kip: the only one that does not claim two is the full list of new channels.",
 "N029.0": "di6: the full area split with counts and the channel behind the top theme.",
 "N033.0": "yid: the count, the channel behind it, and why the reels cover only half the month.",
 "N033.1": "pz3: says plainly there is no usual yet and what the 70 are made of, with a useful offer.",
 "N034.0": "fyh: area share, top theme with its channel, the next theme's share, all true.",
 "N034.1": "s4t: 66 of 70, the channel and the 4 watercolor reels, cleanly; the offer is the only flaw.",
 "N035.0": "wvj: 'far more' with the true split and the top channel; no friend-count gap.",
 "N035.1": "snm: true, says the export is short, and offers the YouTube comparison.",
 "N038.0": "tyd: says there are no likes, gives the recent saves with the friend's save as a count, and shows them.",
 "N044.0": "ygd: 'a few of the 72' over 4 true cards, no count that the cards contradict.",
 "N044.1": "se2: the date range and the repeated-title counts add something to the five cards.",
 "N053.0": "fm3: answers 'not every week' at year level with the 7-month spread and the per-month range.",
 "N053.1": "rrm: 50 against 0 and when it began, in two sentences.",
 "N054.0": "tu4: lists the one item with its theme and says 7 more are private.",
 "N056.0": "hfw: one limit sentence, then the closest thing it can show.",
 "N068.0": "x84: finds the one real match and says what its text is about; all seven are close.",
 "N113.0": "t0h: says there are no likes, then the save split with the accounts named (friend's save left out, as in all seven).",
}

ALLOWED_CAUSE = {"wrong fact", "misses the question", "thin", "wrongly based", "limits not said",
                 "says too much about limits", "bare fallback", "other"}


def main():
    d = json.loads(Path(P).read_text())
    want = {(m["key"], a["code"]) for m in d["messages"] for a in m["answers"]}
    keys = [(r[0], r[1]) for r in M]
    assert len(keys) == len(set(keys)), "duplicate mark"
    assert set(keys) == want, ("missing", want - set(keys), "extra", set(keys) - want)
    out = []
    for (msg, code, grade, fn, wb, ans, means, more, offer, brief, lim, cause, note) in M:
        assert grade in ("good", "acceptable", "poor"), (msg, code)
        for v in (ans, means, more, offer, brief):
            assert v in ("y", "n"), (msg, code)
        assert isinstance(fn, int) and isinstance(wb, int) and isinstance(lim, int)
        assert (cause is not None) == (grade == "poor"), (msg, code, "cause iff poor")
        if cause is not None:
            assert cause in ALLOWED_CAUSE, (msg, code, cause)
        if fn or wb or ans == "n":
            assert grade == "poor", (msg, code, "fault forces poor")
        if grade == "good":
            assert ans == "y" and fn == 0 and wb == 0 and offer == "y" and (means == "y" or more == "y"), (msg, code)
            assert "FRIEND-OMIT" not in note, (msg, code)
        out.append({"message_id": msg, "code": code, "grade": grade, "false_n": fn, "wrongly_based_n": wb,
                    "answers": ans, "means": means, "more": more, "offer": offer, "brief": brief,
                    "limits_talk": lim, "poor_cause": cause, "note": note})
    assert set(BEST) == {m["key"] for m in d["messages"]}
    for k, v in BEST.items():
        assert v.split(":")[0] in {c for (mm, c) in keys if mm == k}, k
    (HERE / "marks.json").write_text(json.dumps(out, indent=1))
    (HERE / "best.txt").write_text("\n".join(f"{k}  {v}" for k, v in BEST.items()) + "\n")
    g = Counter(r["grade"] for r in out)
    print("answers marked:", len(out), "messages:", len({r['message_id'] for r in out}))
    print("grades:", dict(g))
    fo = [r for r in out if "FRIEND-OMIT" in r["note"] and r["grade"] != "poor"]
    print("FRIEND-OMIT capped (acceptable, would be poor under the strict rule):", len(fo), [r["code"] for r in fo])
    print("grades if FRIEND-OMIT made poor:", {"good": g["good"], "acceptable": g["acceptable"] - len(fo), "poor": g["poor"] + len(fo)})
    cap = [r for r in out if "CAP (else good)" in r["note"]]
    print("OFFER-CAP / LOWER-CAP answers that would be good without the caps:", len(cap), [r["code"] for r in cap])
    print("grades without the caps:", {"good": g["good"] + len(cap), "acceptable": g["acceptable"] - len(cap), "poor": g["poor"]})
    print("MEANS-COUNT:", sum("MEANS-COUNT" in r["note"] for r in out))
    firm = [r for r in out if r["wrongly_based_n"] and "LENIENT" not in r["note"]]
    print("wrongly based, firm (no LENIENT tag):", sum(r["wrongly_based_n"] for r in firm), "in", len(firm), [r["code"] for r in firm])
    print("false sentences:", sum(r["false_n"] for r in out), "in", sum(1 for r in out if r["false_n"]), "answers")
    print("wrongly based:", sum(r["wrongly_based_n"] for r in out), "in", sum(1 for r in out if r["wrongly_based_n"]), "answers")
    print("answers=y:", sum(r["answers"] == "y" for r in out), " means=y:", sum(r["means"] == "y" for r in out),
          " more=y:", sum(r["more"] == "y" for r in out), " offer=y:", sum(r["offer"] == "y" for r in out),
          " brief=y:", sum(r["brief"] == "y" for r in out), " limits sentences:", sum(r["limits_talk"] for r in out))
    print("poor causes:", dict(Counter(r["poor_cause"] for r in out if r["poor_cause"])))
    print("PRIV-NAME:", sum("PRIV-NAME" in r["note"] for r in out), " CONV:", sum("CONV" in r["note"] for r in out),
          " LENIENT:", sum("LENIENT" in r["note"] for r in out))
    for k in sorted({r["message_id"] for r in out}):
        c = Counter(r["grade"] for r in out if r["message_id"] == k)
        print(f"  {k}: good {c['good']} acc {c['acceptable']} poor {c['poor']}")


if __name__ == "__main__":
    main()
