"""reader3a: facts from the made-up library rows only (no brain tools imported).
Run from /home/user/digester/experiments: python3 S/mvp27/reader3a/facts.py
Conventions: dates in New York time; 'opened' = a watch event; private = theme 'da' (Heart Notes);
the friend's post (rx_friend) is left out of every list and only counted.
"""
import sys
from collections import Counter, defaultdict
from datetime import datetime, date
from zoneinfo import ZoneInfo

sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # rows only

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art", "dd": "art", "ca": "math", "np": "math",
        "co": "cooking", "da": "PRIVATE"}

rows = B.rows()
ev = []  # (row, kind, ny datetime)
for r in rows:
    for k, at in r["events"]:
        ev.append((r, k, datetime.fromisoformat(at).astimezone(NY)))


def chan(r):
    return r.get("channel") or "@" + r.get("handle", "?")


def is_short(r):
    return r["platform"] == "instagram" or (r["length"] is not None and r["length"] <= 60)


def is_long(r):
    return r["platform"] == "youtube" and r["length"] is not None and r["length"] > 60


opens = [(r, t) for r, k, t in ev if k == "watch" and not r.get("friend")]
pub = [(r, t) for r, t in opens if r["theme"] != "da"]
priv = [(r, t) for r, t in opens if r["theme"] == "da"]
saves = [(r, k, t) for r, k, t in ev if k in ("save", "playlist")]


def pct(a, b):
    return f"{a}/{b}={100*a/b:.1f}%" if b else f"{a}/0"


def show(title):
    print("\n" + "=" * 90 + "\n" + title)


def tally(items, key):
    c = Counter(key(r) for r, t in items)
    return c.most_common()


# N002.0
show("N002.0 what does my youtube say about me (YouTube, all history, opened)")
yt = [(r, t) for r, t in pub if r["platform"] == "youtube"]
n = len(yt)
print("YouTube opened, public:", n, " private:", sum(1 for r, t in priv if r["platform"] == "youtube"))
for a, c in tally(yt, lambda r: AREA[r["theme"]]):
    print("  area", a, pct(c, n))
for th, c in tally(yt, lambda r: THEME[r["theme"]]):
    print("  theme", th, c)
for ch, c in tally(yt, chan):
    print("  channel", ch, c)
print("  first/last:", min(t for r, t in yt).date(), max(t for r, t in yt).date())
by_year_area = defaultdict(Counter)
for r, t in yt:
    by_year_area[t.year][AREA[r["theme"]]] += 1
for y in sorted(by_year_area):
    print("  ", y, dict(by_year_area[y]), "total", sum(by_year_area[y].values()))

# N005.0 / N005.1 / N007.0
show("N005.0 every year? themes and channels by year (opened, public; private shown separately)")
years = range(2021, 2027)
by = defaultdict(Counter)
for r, t in opens:
    by[THEME[r["theme"]]][t.year] += 1
for th in by:
    print(f"  {th:28s}", [by[th][y] for y in years], "every year" if all(by[th][y] for y in years) else "")
byc = defaultdict(Counter)
firsts = {}
for r, t in opens:
    byc[chan(r)][t.year] += 1
    firsts[chan(r)] = min(firsts.get(chan(r), t), t)
for c in byc:
    print(f"  ch {c:16s}", [byc[c][y] for y in years], "first", firsts[c].date(), "total", sum(byc[c].values()))
tot_year = Counter(t.year for r, t in pub)
print("  public opened per year:", dict(sorted(tot_year.items())), "all", len(pub))
print("  private per year:", dict(Counter(t.year for r, t in priv)))

show("N005.1 gaming per year")
g = Counter(t.year for r, t in pub if AREA[r["theme"]] == "gaming")
for y in years:
    gm = Counter(THEME[r["theme"]] for r, t in pub if AREA[r["theme"]] == "gaming" and t.year == y)
    print(f"  {y}: gaming {g[y]} of {tot_year[y]} ({pct(g[y], tot_year[y])})", dict(gm))
print("  gaming all history:", sum(g.values()))

show("N007.0 2021 themes and this year (2026)")
for y in (2021, 2026):
    c = Counter(THEME[r["theme"]] for r, t in pub if t.year == y)
    print(f"  {y} (of {tot_year[y]}):", [(k, v, f"{100*v/tot_year[y]:.1f}%") for k, v in c.most_common()])
print("  Speedruns last opened:", max(t for r, t in pub if r["theme"] == "sr").date())
print("  Brick Realm 2026 first:", min(t for r, t in pub if r["theme"] == "mc" and t.year == 2026).date())

# N019.0
show("N019.0 new channels this fall (try windows)")
for start in (date(2026, 9, 1), date(2026, 9, 22)):
    win = [(r, t) for r, t in pub if start <= t.date() <= date(2026, 10, 30)]
    new = sorted({chan(r) for r, t in win if firsts[chan(r)].date() >= start})
    print(f"  window {start}..2026-10-30: {len(win)} opened; new channels: "
          + ", ".join(f"{c} ({sum(1 for r,t in win if chan(r)==c)}, first {firsts[c].date()})" for c in new))
    print("    themes:", [(k, pct(v, len(win))) for k, v in Counter(THEME[r['theme']] for r, t in win).most_common()])
summ = [(r, t) for r, t in pub if date(2026, 6, 1) <= t.date() <= date(2026, 8, 31)]
print("  summer 2026 (Jun-Aug) watercolor:", sum(1 for r, t in summ if r["theme"] == "wc"),
      "; summer (Jun 21-Sep 21):", sum(1 for r, t in pub if r["theme"] == "wc" and date(2026, 6, 21) <= t.date() <= date(2026, 9, 21)))
for start, end in ((date(2026, 9, 1), date(2026, 10, 30)), (date(2026, 9, 22), date(2026, 10, 30))):
    print(f"  watercolor {start}..{end}:", sum(1 for r, t in pub if r["theme"] == "wc" and start <= t.date() <= end),
          "(youtube only:", sum(1 for r, t in pub if r["theme"] == "wc" and r['platform'] == 'youtube' and start <= t.date() <= end), ")")

# N029.0
show("N029.0 Saturdays, all history")
sat = [(r, t) for r, t in pub if t.weekday() == 5]
print("  Saturday opened public:", len(sat), " private:", sum(1 for r, t in priv if t.weekday() == 5))
for a, c in tally(sat, lambda r: AREA[r["theme"]]):
    print("   area", a, pct(c, len(sat)))
for a, c in tally(sat, lambda r: THEME[r["theme"]]):
    print("   theme", a, c)
allw = Counter(t.weekday() for r, t in pub)
print("  opened by weekday (Mon=0):", dict(sorted(allw.items())))

# N033
show("N033.0/.1 Shorts and reels")
sh = [(r, t) for r, t in pub if is_short(r)]
print("  all short opened:", len(sh), "by month:", dict(Counter((t.year, t.month) for r, t in sh)))
octs = [(r, t) for r, t in sh if (t.year, t.month) == (2026, 10)]
print("  Oct 2026:", len(octs), "youtube:", sum(1 for r, t in octs if r['platform'] == 'youtube'),
      "instagram:", sum(1 for r, t in octs if r['platform'] == 'instagram'))
print("  by channel:", tally(octs, chan), " by theme:", tally(octs, lambda r: THEME[r['theme']]))
print("  Clip Factory distinct days:", len({t.date() for r, t in octs if chan(r) == 'Clip Factory'}),
      " all shorts distinct days:", len({t.date() for r, t in octs}))

# N034
show("N034.0/.1 this year, long and short")
ty = [(r, t) for r, t in pub if t.year == 2026]
lg = [(r, t) for r, t in ty if is_long(r)]
print("  2026 opened public:", len(ty), " long:", len(lg), " unknown length:", sum(1 for r, t in ty if not is_long(r) and not is_short(r)))
for a, c in tally(lg, lambda r: AREA[r["theme"]]):
    print("   long area", a, pct(c, len(lg)))
for a, c in tally(lg, lambda r: THEME[r["theme"]]):
    print("   long theme", a, pct(c, len(lg)))
for a, c in tally(lg, chan):
    print("   long channel", a, c)
st = [(r, t) for r, t in ty if is_short(r)]
print("  2026 short:", len(st), tally(st, lambda r: AREA[r['theme']]), tally(st, chan))

# N035
show("N035.0/.1 platforms")
for p in ("youtube", "instagram"):
    o = [x for x in pub if x[0]["platform"] == p]
    s = {r["id"] for r, k, t in saves if r["platform"] == p and not r.get("friend")}
    items = {r["id"] for r, t in o} | s
    print(f"  {p}: opened {len(o)}, saved (non-friend) {len(s)}, items opened or saved {len(items)}")
ig = [(r, t) for r, t in pub if r["platform"] == "instagram"]
print("  Instagram opened:", [(r['id'], chan(r), THEME[r['theme']], t.date().isoformat()) for r, t in ig])
print("  Instagram saves:", [(r['id'], chan(r), THEME[r['theme']], t.date().isoformat(), 'FRIEND' if r.get('friend') else '')
                             for r, k, t in saves if r['platform'] == 'instagram'])
print("  Instagram first/last any event:", min(t for r, k, t in ev if r['platform'] == 'instagram').date(),
      max(t for r, k, t in ev if r['platform'] == 'instagram').date())
print("  private (all YouTube):", len(priv))

# N038 / N068 / N113
show("N038.0/N068.0/N113.0 saves (no like events exist: kinds = %s)" % sorted({k for r, k, t in ev}))
for r, k, t in sorted(saves, key=lambda x: x[2], reverse=True):
    print(f"  {t.isoformat()}  {k:8s} {r['id']:9s} {chan(r):15s} {THEME[r['theme']]:20s} "
          f"{'FRIEND ' if r.get('friend') else ''}opened={any(kk=='watch' for kk,_ in r['events'])}  {r['caption'][:60]}")
ns = [x for x in saves if not x[0].get("friend")]
print("  non-friend saves:", len(ns), Counter(THEME[r['theme']] for r, k, t in ns), Counter(AREA[r['theme']] for r, k, t in ns))
print("  saves in 4 weeks to 30 Oct (2-30 Oct):", sum(1 for r, k, t in ns if date(2026, 10, 2) <= t.date() <= date(2026, 10, 30)))

# N044
show("N044.0/.1 cooking opened, newest first")
co = sorted([(r, t) for r, t in pub if AREA[r["theme"]] == "cooking"], key=lambda x: x[1], reverse=True)
print("  cooking opened:", len(co))
for i, (r, t) in enumerate(co[:12], 1):
    print(f"  {i:2d} {r['id']:9s} {t.isoformat()} {r['caption'][:50]}")
base = Counter(r["caption"].split(" #")[0] for r, t in co)
print("  title counts (without #n):", base.most_common(6))

# N053
show("N053.0/.1 private topic (Heart Notes) by year and month")
print("  by year:", dict(Counter(t.year for r, t in priv)))
p24 = [t for r, t in priv if t.year == 2024]
print("  2024:", len(p24), "distinct days", len({t.date() for t in p24}), "first", min(p24).date(), "last", max(p24).date())
print("  by month:", dict(sorted(Counter(t.month for t in p24).items())))
wk = {t.isocalendar()[1] for t in p24}
allwk = set(range(min(wk), max(wk) + 1))
print("  ISO weeks with any:", len(wk), "of span weeks", len(allwk), "missing in span:", sorted(allwk - wk))
gaps = sorted((b - a).days for a, b in zip(sorted(p24), sorted(p24)[1:]))
print("  gaps (days) min/max:", gaps[0], gaps[-1])
print("  hours NY:", dict(sorted(Counter(t.hour for t in p24).items())),
      " 17-21h share:", pct(sum(1 for t in p24 if 17 <= t.hour < 21), len(p24)),
      " 18-22h:", pct(sum(1 for t in p24 if 18 <= t.hour < 22), len(p24)),
      " 16-21h:", pct(sum(1 for t in p24 if 16 <= t.hour < 21), len(p24)))
print("  channels:", Counter(chan(r) for r, t in priv))

# N054
show("N054.0 March 2024")
m = [(r, t) for r, t in opens if (t.year, t.month) == (2024, 3)]
print("  public:", [(r['id'], r['caption'], chan(r), t.date().isoformat()) for r, t in m if r['theme'] != 'da'])
print("  private:", sum(1 for r, t in m if r["theme"] == "da"))
print("  Feb 2024 public:", sum(1 for r, t in pub if (t.year, t.month) == (2024, 2)),
      " Apr 2024 public:", sum(1 for r, t in pub if (t.year, t.month) == (2024, 4)))

# N056
show("N056.0 watched all the way through")
print("  watch-progress field in rows: none. events per item:", Counter(sum(1 for k, _ in r['events'] if k == 'watch') for r in rows if any(k == 'watch' for k, _ in r['events'])))
lgall = [(r, t) for r, t in pub if is_long(r)]
print("  long opened all history:", len(lgall), "; unknown length:", sum(1 for r, t in pub if r['platform'] == 'youtube' and r['length'] is None))
for r, t in sorted(lgall, key=lambda x: x[1], reverse=True)[:4]:
    print("   newest long:", r['id'], r['caption'], r['length'], t.isoformat())
print("  longest lengths:", Counter(r['length'] for r, t in lgall).most_common())
