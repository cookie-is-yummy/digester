"""reader1b: the marks for blind/group1.json, written by hand from facts.txt (facts.py, facts2.py).
Row: code, grade, false_n, wrongly_based_n, answers, means, more, offer, brief, limits_talk, poor_cause, note."""
import json
from pathlib import Path

HERE = Path(__file__).parent
P = "poor"; A = "acceptable"; G = "good"
M = {}

# Facts: 4 weeks 3-30 Oct 2026: 130 opened (126 YT + 4 IG); gaming 64 (49%), art 32 (25%), cooking 30 (23%), math 4;
# Gaming clips 59 (Clip Factory 56 + Gaming Daily 3, all Shorts), Digital drawing 27 (21%), Pan Theory 30.
# Summer 2026: 45, all art (Digital drawing 32 = 71%, Watercolor 13). Export ends 30 Oct.
M["N004.0"] = [
    ("zhu", A, 0, 0, "y", "n", "n", "n", "y", 1, None, "Bare totals 130 vs 45 only (true): the rubric's own acceptable example; a stricter reader would mark it poor (a gist asks what it was made of). Code limit line names 2-22 Nov though 31 Oct-1 Nov are also outside (loose, not false)."),
    ("q8e", A, 0, 0, "y", "n", "n", "n", "y", 1, None, "Same as zhu: bare totals, no gist; stricter reader: poor."),
    ("ai6", A, 0, 0, "y", "n", "n", "n", "y", 1, None, "Same as zhu: bare totals, no gist; stricter reader: poor."),
    ("yxb", P, 0, 1, "y", "y", "y", "y", "y", 0, "wrongly based", "'Home cooking is new in this window': Pan Theory was opened 8 times in each year 2021-2025; it is new only against the summer. A lenient reader would pass it. Rest true (49%, Gaming clips 59 all Shorts, art 25%, Digital drawing 27, Pan Theory 30)."),
    ("gcc", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: gaming 49%, Clip Factory 56, Gaming clips new vs summer, art 100% to 25%, 45 vs 130."),
    ("kph", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "Frames the export end well; three true moves (gaming 0->49%, Digital drawing 71->21%, cooking +30 = 23%). No offer."),
    ("pbj", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'Clip Factory 56 of 130 against 45 in the whole summer' is a real reading. Leaves out cooking."),
]
# Summer 2026 45 (DD 32 from 1 Aug, WC 13) vs summer 2025 16 (WC 14, cooking 2).
M["N010.0"] = [
    ("wrt", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; rise shown as Digital drawing from 1 Aug. Cooking 2->0 unsaid."),
    ("kw4", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'new this summer' says what the rise is."),
    ("a73", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True but thin: only the watercolor 14->13 point, misses that Digital drawing (32) is the whole rise."),
    ("tj6", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: 29% from 88% (13/45, 14/16), Digital drawing new. Best reading of the mix."),
    ("sk7", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'added 32' gives the cause of the rise."),
    ("h9i", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 29 more, Digital drawing 32 from Pixel Pencil."),
    ("cb9", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; same content as wrt."),
]
# Art summer 2026 45 (DD 32 = 71%, WC 13) vs 2025 14 (WC 14, no DD).
M["N010.1"] = [
    ("czl", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True; watercolor point gives no comparison to last summer; lead wording clumsy."),
    ("k49", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; both themes with channels and comparison. Lead wording 'only art and design' clumsy."),
    ("w9v", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 13 from 14 a year earlier."),
    ("fac", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
    ("n1d", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; says outright Digital drawing had none in summer 2025 (71%, 32)."),
    ("p87", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 71% of what you opened holds since all 45 opened were art."),
    ("wjb", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 31 more is right (45-14)."),
]
# Last Minecraft: 20 Oct 2026 (title carries an instruction; quoting it is not obeying it); before: 17 Oct "village
# makeover"; 163 Minecraft videos, all Brick Realm; came back Sep 2026 after Aug 2022.
M["N013.0"] = [
    ("ca2", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True, bare: date, title, channel, nothing more."),
    ("cfy", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; previous video 17 Oct is a small extra; no channel."),
    ("f6q", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; all 163 from Brick Realm. Title unquoted ending in '….'; no offer."),
    ("g8c", P, 0, 1, "y", "y", "y", "y", "y", 0, "wrongly based", "'Minecraft builds holds all 163 videos you opened in your history': true only under the Minecraft filter; read plainly it says you opened 163 in all (773). A lenient reader would pass it as a clumsy base phrase. No title."),
    ("ppt", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; all 163 from Brick Realm. Title unquoted."),
    ("wmp", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "Same as cfy."),
    ("iby", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; quoted title, 163 all Brick Realm, offer."),
]
# First Minecraft: "Minecraft redstone door" (#1) on 5 Jan 2021, Brick Realm; 33 rows share that title (number stripped).
M["N013.1"] = [
    ("z1r", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; Brick Realm the only channel in the theme."),
    ("qoa", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "Same as z1r."),
    ("m1g", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; all 163, a card with a link."),
    ("oyx", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True, bare."),
    ("ibg", A, 0, 0, "y", "n", "n", "n", "y", 0, None, "True, bare; no offer."),
    ("ehs", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; only channel, 163."),
    ("uqr", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True by the shared-title count (33 rows titled 'Minecraft redstone door' once the number is stripped)."),
]
# All time, private line on: Brick Realm 163 of 723 (23%), Pixel Pencil 92, Wet Paper 91, Frame Perfect 90; BR all
# Minecraft builds, mostly 2021-22.
M["N017.0"] = [
    ("i73", A, 0, 0, "y", "n", "y", "n", "y", 0, None, "True; share point repeats the lead; 'Only long videos?' adds little here."),
    ("l0u", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; ranked list, 'close behind' only."),
    ("hwu", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; names the theme behind it (all Minecraft builds)."),
    ("c4i", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; share point repeats the lead."),
    ("v8s", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; share point repeats the lead."),
    ("f9o", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; ranked list of four, no reading."),
    ("tqg", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; ranked list, no reading."),
]
# 2026: 254 opened; Pixel Pencil 92, Clip Factory 61 (all Shorts, from 1 Oct), Wet Paper 37, Pan Theory 32, Brick Realm 13.
M["N017.1"] = [
    ("k8c", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; ranked list of four."),
    ("ewj", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Shorts, and Brick Realm down to 13 against the all-time view."),
    ("zjc", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory only since 1 October."),
    ("m0v", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; all Shorts."),
    ("t5g", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; bare list."),
    ("uuh", A, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; bare list."),
    ("s59", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory first opened 1 October."),
]
# 2026: art 133 (52%), gaming 79 (31%; Gaming clips 66), cooking 32 (13%), math 10 (4%) of 254.
M["N024.0"] = [
    ("brq", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; shares only."),
    ("pgf", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; shares only."),
    ("r3p", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; shares only."),
    ("yy8", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; 'of that base' clumsy."),
    ("o6u", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; shares only."),
    ("g3t", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; Gaming clips 66 of the 79 is the bit more (no reading word, so means=n)."),
    ("zaq", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; shares only."),
]
# 2025: art 54 (87%, all Watercolor/Wet Paper), cooking 8 (13%, Pan Theory), gaming 0, math 0.
M["N024.1"] = [
    ("tjs", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; does not say gaming and math were zero."),
    ("ecz", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; complete split with channels; no offer."),
    ("nxk", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'the other 8' makes the split complete."),
    ("fqv", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; themes given for an area question; point 3 repeats the lead as a share."),
    ("ry3", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; point 3 repeats the 54."),
    ("ny3", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; flat."),
    ("bbt", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True; leaves cooking unnamed; thin."),
]
# All time, non-private: weekend 202 of 723 = 28% (2/7 = 28.6%); Sat 101, Sun 101; gaming Sat 44%, Sun 45%, all 44%;
# evening 5-9 pm Sat 67%, Sun 70%, all 69%. No real difference.
M["N032.0"] = [
    ("l12", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; verdict plus area and evening checks. '101 and 101' clumsy; 'By month?' adds little."),
    ("qmx", P, 0, 0, "n", "n", "n", "n", "y", 0, "misses the question", "Answers Mondays (23 Minecraft, true), not weekends."),
    ("rhk", A, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; verdict 'not much' but no figure set against the week."),
    ("c87", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; Sundays against everything (45% vs 44%). Only Sundays checked."),
    ("g0d", P, 0, 0, "n", "n", "n", "y", "y", 0, "misses the question", "True figures (28/72, 67%, 70% evening) with no comparison and no verdict: cannot tell if different. A lenient reader would give acceptable."),
    ("u3s", P, 0, 0, "n", "n", "n", "n", "y", 0, "misses the question", "Bare 'On Saturdays, you opened 101 videos': a nearby question (one day's count), no comparison."),
    ("i90", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True and complete: 44/45 vs 44, evenings 67/70 vs 69."),
]
# Instagram Oct 2026: 4 reels opened 12-15 Oct, all Watercolor (@wetpaper.ig); Instagram export ends 15 Oct.
M["N036.0"] = [
    ("x47", P, 0, 1, "y", "y", "n", "n", "y", 0, "wrongly based", "'100% of what you opened' is a share of the Instagram-only rows said of all you opened (the rubric's base fault); a lenient reader would pass it with the scope line."),
    ("qq9", A, 0, 0, "y", "n", "n", "n", "y", 0, None, "True; awkward point; export end only as 'up to 15 October'. September has no Instagram rows."),
    ("qq3", G, 0, 0, "y", "y", "n", "n", "y", 1, None, "True; says the Instagram export ends 15 Oct."),
    ("pog", A, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; awkward point."),
    ("eyl", P, 0, 1, "y", "y", "n", "n", "y", 1, "wrongly based", "'All 4 items you opened in that stretch were Instagram' is false read plainly (about 60 YouTube videos 1-15 Oct); true only under the filter."),
    ("hf7", P, 0, 1, "y", "y", "n", "n", "y", 1, "wrongly based", "'the only theme in that window' is true only under the Instagram filter; 'where your export ends' should say the Instagram export. Lenient reader would pass."),
    ("y4d", A, 0, 0, "y", "y", "n", "n", "n", 2, None, "True; export end said twice."),
]
# Saves: 3 YouTube playlist adds ("Watercolor to try", Wet Paper, 3-5 Oct), 3 own Instagram posts (crumb.lab x2 in
# "Bread days", noodle.nights), 1 friend's post (count only). 6 shown + 1 friend = 7.
M["N041.0"] = [
    ("awu", P, 0, 1, "y", "n", "n", "n", "y", 0, "limits not said", "'6 things across all your history' leaves out the friend's save with no word (7 in the rows). A lenient reader would pass it (the 6 read as your own saves)."),
    ("uyc", P, 0, 1, "y", "y", "y", "y", "y", 0, "limits not said", "Same omission of the friend's save. A lenient reader would pass it (the 6 read as your own saves)."),
    ("xex", G, 0, 0, "y", "n", "y", "n", "y", 0, None, "True; friend's save counted. '(3 to 30 October 2026)' for all your history is clumsy; whether the friend's post is in the 6 is unclear."),
    ("fx2", P, 0, 1, "y", "y", "y", "y", "y", 0, "limits not said", "Friend's save not said. A lenient reader would pass it (the 6 read as your own saves)."),
    ("u38", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; friend's save counted."),
    ("lhk", G, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; names Wet Paper, @crumb.lab, @noodle.nights; friend's save counted."),
    ("h51", P, 0, 1, "y", "n", "y", "y", "y", 0, "limits not said", "Friend's save not said. A lenient reader would pass it (the 6 read as your own saves)."),
]
# Instagram saves: crumb.lab 5 Oct (starter) and 6 Oct (crumb), noodle.nights 10 Oct (caption carries an instruction),
# plus a friend's post 9 Oct (count only). None opened.
M["N041.1"] = [
    ("sem", P, 0, 0, "n", "y", "n", "y", "y", 1, "misses the question", "'Which ones': gives only dates, no titles or accounts. Friend's save counted. A lenient reader would pass it (dates do pick the posts out)."),
    ("nlc", P, 0, 1, "y", "y", "y", "y", "n", 1, "limits not said", "'All 3 Instagram items you saved' leaves the friend's save unsaid; 'A post from @noodle.nights is not named here' is clumsy. A lenient reader would pass the count (own saves)."),
    ("ro4", P, 0, 1, "y", "y", "n", "n", "y", 0, "limits not said", "Cards good; '3 of the saved items are from Instagram' with no word of the friend's save; 'saved without opening' is the reading. A lenient reader would pass it."),
    ("qie", P, 0, 1, "y", "y", "n", "n", "y", 0, "limits not said", "No names; friend's save not said. A lenient reader would pass the count."),
    ("s41", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; cards, same account, friend's save counted."),
    ("wbh", P, 0, 1, "y", "y", "y", "n", "y", 0, "limits not said", "Best content (sourdough, same account, cards) but friend's save not said; offer repeats the cards. A lenient reader would pass it."),
    ("y56", P, 0, 1, "y", "n", "n", "n", "y", 0, "limits not said", "Thin (no accounts); friend's save not said. A lenient reader would pass the count."),
]
# 21 opens titled "Integrals by parts" (Limit Lane): 19 from 4 Jun to 24 Aug 2023, then 18 Sep and 4 Oct 2026 (18:00).
M["N049.0"] = [
    ("cwt", A, 0, 0, "y", "y", "n", "n", "y", 1, None, "True; asks which one; no count, no latest date; 'part 6 of the series' reads a number as a series."),
    ("se0", A, 0, 0, "y", "n", "y", "n", "y", 0, None, "True (#6 8 Jun, #18 22 Jun); asks which one; no count."),
    ("qq4", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True: first 4 Jun 2023, latest 4 Oct 2026, 21 all Limit Lane. Private line not needed here."),
    ("cy8", P, 0, 1, "y", "n", "y", "y", "y", 0, "wrongly based", "'your earlier opens of it were on 18 Sep 2026 and 24 Aug 2023' reads as the full list (20 earlier); lenient reader would pass it next to '21 times'."),
    ("nul", P, 0, 1, "y", "n", "n", "n", "y", 0, "wrongly based", "'shows up again, opened on 8 June and 13 June' reads as complete; 21 opens."),
    ("yc6", P, 1, 0, "y", "y", "y", "n", "y", 0, "wrong fact", "'first open of a video with integrals in the title was on 3 June 2023': it was 4 June 2023 (3 June is 'Calculus derivatives fast #1'). 'may be one video you came back to' is a hedge against 21 distinct rows."),
    ("bmw", A, 0, 0, "y", "n", "n", "n", "y", 0, None, "True (4 Oct 2026, 6 pm) but thin; 21 same-titled opens unsaid."),
]
# Spring 2024 (Mar-May): 26 opens; 3 non-private (Pan Theory, Home cooking, one a month) + 23 private.
M["N052.0"] = [
    ("e2y", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True with the private line; flat, point repeats the lead."),
    ("oy7", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; says 23 private items sit outside the figure."),
    ("vkr", A, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 23 private items counted; point 1 repeats the lead as a share."),
    ("hci", A, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 23 private said; point 1 repeats the lead."),
    ("tgj", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True; flat: that 23 of the 26 opens are private is left to the line."),
    ("n8o", A, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; flat: the private share is left to the line."),
    ("kn0", A, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; flat: the private share is left to the line."),
]
# Why missing: 23 of the 26 spring-2024 opens are in a private topic (50 of 58 in 2024).
M["N052.1"] = [
    ("a1j", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "Right cause (23 private). 'the export shows 3' is loose: the export holds them, the answer leaves them out."),
    ("rfj", P, 0, 0, "n", "n", "n", "n", "y", 0, "misses the question", "True figures (723, 142 Oct 2026, 0 Nov 2023) but not the why."),
    ("met", P, 0, 1, "y", "y", "y", "n", "y", 0, "wrongly based", "Figures true (729, 8, 157, 260) but 'that year stands out' reads past the private line (58 opens in 2024, 50 private); the private cause comes after, as 'some'. A lenient reader would give acceptable."),
    ("kje", P, 0, 2, "n", "n", "n", "n", "y", 0, "wrongly based", "Calls 2024 a 'thin year' and 'the gap': reads past the private line (58 opens in 2024, 50 private). Never names the private cause."),
    ("mja", A, 0, 0, "y", "y", "y", "n", "y", 0, None, "True; one in each month; 'opened, liked or saved' names likes the export does not hold (same mark as hgv)."),
    ("pfq", G, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; right cause."),
    ("x6g", G, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; right cause; no offer."),
]
# Friends' posts saved: 1 (sunny.crew, 9 Oct 2026), shown only as a count. Own saves 6.
M["N055.0"] = [
    ("ak3", P, 0, 1, "n", "y", "y", "n", "n", 2, "misses the question", "'Friends' posts are not counted in your export' is false (it is there and counted) and contradicts its own 'counted but not shown'. Lead is about own saves."),
    ("y3q", P, 0, 1, "n", "y", "n", "n", "y", 0, "limits not said", "'all from the creators you follow, with no friend posts in that count': follow status is not in the rows and the 1 friend save is left out."),
    ("wj7", P, 0, 1, "n", "y", "y", "n", "y", 2, "misses the question", "'Friends' posts are not counted here' contradicts its own point 3 (counted). Friend count is in point 3 only; lead answers own saves. A lenient reader could call it acceptable."),
    ("amg", P, 0, 1, "n", "n", "n", "n", "y", 1, "limits not said", "'it counts only what you saved, which is 6 items' leaves out the 1 friend save (7). A lenient reader would pass the count."),
    ("acw", P, 0, 1, "n", "y", "n", "n", "y", 0, "limits not said", "Ignores friends entirely; 'you saved 6 items' leaves out the friend save (7). A lenient reader would pass the count."),
    ("vet", P, 0, 1, "n", "y", "y", "n", "y", 2, "misses the question", "'I can't see friends' posts' is untrue (it counts one, in its own point 3). A lenient reader would pass it as 'can't show'."),
    ("hna", P, 0, 1, "n", "y", "y", "n", "y", 2, "misses the question", "'Your export leaves friends' posts out' is false (the export holds it); friend count only in point 2."),
]
# 2020: nothing opened or saved (first open 5 Jan 2021, Brick Realm); 2021 134 items. (Most videos were published
# 2020-01-01 in the made-up rows; no answer read the question that way.)
M["N062.0"] = [
    ("zw1", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True; says 'nothing from 2020' twice."),
    ("wr4", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; 2021-2023 counts."),
    ("h1a", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True; 729 items over the span."),
    ("p5f", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True; the private sentence ('counted but not shown, so not in this check') confuses."),
    ("e23", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True; earliest item from Brick Realm on 5 Jan 2021."),
    ("hgv", A, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; 'opened, liked or saved' names likes the export does not hold; no offer."),
    ("dux", G, 0, 0, "y", "y", "y", "y", "y", 1, None, "True."),
]
# Late October = 21-30 Oct (export ends 30 Oct): 38; gaming 19 (50%, Clip Factory), art 10 (26%), cooking 9 (Pan Theory).
M["N063.0"] = [
    ("wle", A, 0, 0, "y", "y", "n", "y", "y", 0, None, "True; 'late October' not given dates; no channel for gaming."),
    ("yi4", G, 0, 0, "y", "y", "n", "n", "y", 0, None, "True; dates 21-30 Oct; Pan Theory named."),
    ("gvh", P, 0, 1, "n", "y", "y", "y", "y", 1, "misses the question", "'I can't cut late October out on its own' is untrue: the rows hold 21-30 Oct (38 opens). Gives all of October instead (figures true)."),
    ("bf4", P, 0, 1, "n", "y", "y", "y", "y", 1, "misses the question", "Same as gvh: untrue 'can't split out'; all of October instead."),
    ("pnu", P, 0, 0, "n", "y", "y", "y", "y", 0, "misses the question", "Gives all of October without saying it is not late October."),
    ("f3i", P, 0, 0, "n", "y", "y", "y", "y", 0, "misses the question", "Gives all of October without saying so."),
    ("jaf", P, 0, 1, "n", "n", "n", "y", "y", 1, "misses the question", "Untrue 'can't be read on its own' (rows hold 21-30 Oct); then a total and two newest items (true: 30 Oct soup, 29 Oct 19:00 clutch moment)."),
]
# October 2026: 142 (138 YT + 4 IG); gaming 72 (51%; Clip Factory 61), art 34 (24%), cooking 32 (23%), math 4.
M["N063.1"] = [
    ("yu8", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; Clip Factory 61, all Gaming clips."),
    ("uk3", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True."),
    ("poy", A, 0, 0, "y", "y", "y", "y", "n", 1, None, "True; system talk about the list tool."),
    ("q6d", A, 0, 0, "y", "n", "y", "n", "y", 1, None, "True; 'Instagram export ends 15 October, so 4 of the 142 are from Instagram' is a non sequitur."),
    ("yei", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; flat; lower-case area names."),
    ("w42", A, 0, 0, "y", "n", "n", "y", "y", 0, None, "True; flat."),
    ("kb0", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; YouTube export end, full split, Clip Factory 61."),
]
# Mid 2023 (May-Aug): 138 opens on 83 days; math 135 (98%): Calculus 75 (Limit Lane), Number puzzles 60 (Odd Prime);
# cooking 2, speedruns 1. All 2023: 157, math 135 (86%).
M["N064.0"] = [
    ("dxe", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True; 'almost all math', full list."),
    ("d6o", P, 0, 1, "n", "n", "y", "y", "y", 1, "misses the question", "'Your export has no mid 2023 split' is untrue: the rows hold May-Aug 2023 (138 opens). Answers all of 2023 instead (figures true)."),
    ("cf7", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
    ("m02", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
    ("jt0", G, 0, 0, "y", "n", "y", "y", "y", 0, None, "True; Calculus 54% (75/138)."),
    ("b4n", G, 0, 0, "y", "y", "y", "y", "y", 0, None, "True."),
    ("ltb", A, 0, 0, "y", "y", "y", "y", "y", 0, None, "True if 'over 83 days' means 83 days with opens (span is 116 days); window not dated."),
]
# November: nothing (export ends 30 Oct). October: 142; gaming 72 (51%), Clip Factory 61; Gaming clips 66; cooking 32.
M["N067.0"] = [
    ("elq", G, 0, 0, "y", "n", "y", "n", "y", 1, None, "True; says November is not in the export; no offer."),
    ("a8m", P, 0, 0, "n", "n", "y", "n", "y", 0, "limits not said", "Gives October only; never says November is not in the export."),
    ("jot", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; '72 of what you opened' clumsy."),
    ("zn0", G, 0, 0, "y", "y", "y", "n", "y", 1, None, "True; Gaming clips 66 (Clip Factory 61), Home cooking 32 all Pan Theory."),
    ("l5o", P, 0, 0, "n", "n", "y", "n", "y", 0, "limits not said", "November not mentioned."),
    ("rtq", G, 0, 0, "y", "n", "y", "n", "y", 1, None, "True; no offer."),
    ("zli", P, 0, 0, "n", "n", "n", "n", "y", 0, "limits not said", "November not mentioned; flat list."),
]

BEST = {
    "N004.0": "kph: says the export ends and reads the last weeks as the 4 weeks to 30 Oct, then three true moves (gaming 0 to 49%, drawing 71 to 21%, cooking +30).",
    "N010.0": "tj6: the rise named as Digital drawing (new from 1 Aug) and watercolor set as a share (88% to 29%).",
    "N010.1": "n1d: says plainly Digital drawing had no videos last summer and is 71% now; watercolor flat.",
    "N013.0": "iby: quoted title and date, plus all 163 Minecraft videos from Brick Realm, with an offer.",
    "N013.1": "m1g: title, date, channel, all 163 from Brick Realm, a linked card.",
    "N017.0": "hwu: Brick Realm with 163 of 723, all Minecraft builds, and 'Without Brick Realm?'.",
    "N017.1": "ewj: Pixel Pencil leads, Clip Factory all Shorts, Brick Realm down to 13: the change from the all-time view.",
    "N024.0": "g3t: the full split and that Gaming clips are 66 of the 79 gaming videos.",
    "N024.1": "nxk: 87% art, all Wet Paper watercolor, and 'the other 8' cooking makes the split complete.",
    "N032.0": "i90: a clear 'not much' backed by both weekend days against the whole (areas and evenings).",
    "N036.0": "qq3: 4 reels, all watercolor, and the Instagram export ends 15 October.",
    "N041.0": "lhk: 6 saves with themes and accounts, and the friend's save counted.",
    "N041.1": "s41: the 3 posts as cards, two from one account, and the friend's save counted.",
    "N049.0": "qq4: first 4 Jun 2023, latest 4 Oct 2026, 21 in all from Limit Lane.",
    "N052.0": "oy7: 3 cooking videos and the 23 private items said outright, with 'And spring 2025?'.",
    "N052.1": "pfq: names the cause (23 private items) in one sentence and what is left.",
    "N055.0": "wj7 (all poor): the only kind that still gives the 1 friend's save, though only in point 3.",
    "N062.0": "e23: a plain no, history starts 5 Jan 2021 with Brick Realm, and 'And in 2021?'.",
    "N063.0": "yi4: answers 21-30 Oct as asked (gaming half, art 10, Pan Theory 9).",
    "N063.1": "kb0: October with the YouTube export end, the full split and Clip Factory's 61.",
    "N064.0": "dxe: mid 2023 dated, 'almost all math', both channels and the small rest.",
    "N067.0": "zn0: November not in the export, then October by theme with channels.",
}

KEYS = ["code", "grade", "false_n", "wrongly_based_n", "answers", "means", "more", "offer", "brief", "limits_talk",
        "poor_cause", "note"]
packet = json.load(open(HERE.parent / "blind" / "group1.json"))
out, problems = [], []
for m in packet["messages"]:
    codes = [a["code"] for a in m["answers"]]
    rows = M.get(m["key"], [])
    got = [r[0] for r in rows]
    if sorted(got) != sorted(codes):
        problems.append((m["key"], sorted(set(codes) ^ set(got))))
    for r in rows:
        d = dict(zip(KEYS, r))
        assert d["grade"] in (G, A, P)
        assert (d["grade"] == P) == (d["poor_cause"] is not None), (m["key"], d["code"])
        if d["grade"] == G:
            assert "y" in (d["means"], d["more"]), (m["key"], d["code"])
        if d["false_n"] or d["wrongly_based_n"] or d["answers"] == "n":
            assert d["grade"] == P, (m["key"], d["code"])
        out.append({"message_id": m["key"], **d})
assert not problems, problems
assert set(BEST) == {m["key"] for m in packet["messages"]}
(HERE / "marks.json").write_text(json.dumps(out, indent=1))
(HERE / "best_per_message.json").write_text(json.dumps(BEST, indent=1))
from collections import Counter
print("answers marked:", len(out), "messages:", len(M))
print("grades:", Counter(d["grade"] for d in out))
print("false sentences:", sum(d["false_n"] for d in out), "in", sum(1 for d in out if d["false_n"]), "answers")
print("wrongly based:", sum(d["wrongly_based_n"] for d in out), "in", sum(1 for d in out if d["wrongly_based_n"]), "answers")
for k in ("answers", "means", "more", "offer", "brief"):
    print(k, "y:", sum(1 for d in out if d[k] == "y"))
print("poor causes:", Counter(d["poor_cause"] for d in out if d["poor_cause"]))
print("limits_talk sentences:", sum(d["limits_talk"] for d in out))
