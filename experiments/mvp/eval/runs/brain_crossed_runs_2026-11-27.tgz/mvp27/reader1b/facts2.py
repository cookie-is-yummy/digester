"""reader1b facts, part 2: weekday splits and evening shares, non-private rows (New York local)."""
import sys
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader1b")
from facts import EV, FIELD, THEME
from collections import Counter
ev = [e for e in EV if e[1] == "watch" and e[2]["theme"] != "da"]
print("N032.0 non-private opens:", len(ev))
for name, f in (("Sat", lambda t: t.weekday() == 5), ("Sun", lambda t: t.weekday() == 6), ("weekend", lambda t: t.weekday() >= 5),
                ("weekday", lambda t: t.weekday() < 5), ("all", lambda t: True), ("Mon", lambda t: t.weekday() == 0)):
    sub = [e for e in ev if f(e[0])]
    n = len(sub)
    fl = Counter(FIELD[e[2]["theme"]] for e in sub)
    th = Counter(THEME[e[2]["theme"]] for e in sub)
    for lo, hi in ((17, 21), (18, 22), (16, 20)):
        evn = sum(1 for e in sub if lo <= e[0].hour < hi)
        print(f"  {name}: evening {lo}-{hi}h {evn}/{n} = {100*evn/n:.1f}%")
    print(f"  {name}: n={n} share={100*n/len(ev):.1f}% fields", {k: f"{v} ({100*v/n:.1f}%)" for k, v in fl.most_common()},
          "top theme", th.most_common(2), f"({100*th.most_common(1)[0][1]/n:.1f}%)")
