"""reader1b facts, part 3: the hand-worked facts, printed beside their message (rows only, New York local)."""
import contextlib, io, re, sys
sys.path.insert(0, "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader1b")
with contextlib.redirect_stdout(io.StringIO()):
    from facts import EV, ROWS, THEME, who
from collections import Counter
from datetime import date

strip = lambda s: re.sub(r"\s*#\s*\d+\s*$", "", s)
W = [e for e in EV if e[1] == "watch"]
print("N004.0 Home cooking (Pan Theory) opens by year:", sorted(Counter(e[0].year for e in W if e[2]['theme'] == 'co').items()))
print("N004.0/N017.1 cooking by month 2026:", sorted(Counter(e[0].month for e in W if e[2]['theme'] == 'co' and e[0].year == 2026).items()))
for ch in ("Pixel Pencil", "Clip Factory", "Gaming Daily"):
    f = [e for e in W if e[2].get("channel") == ch]
    print(f"N010/N017.1 first open of {ch}: {f[0][0]}  ({f[0][2]['caption']})")
print("N013.1 rows titled 'Minecraft redstone door' (number stripped):", sum(1 for e in W if strip(e[2]['caption']) == 'Minecraft redstone door'))
print("N013.0 Minecraft opens 2022-08-25..2026-09-01:", sum(1 for e in W if e[2]['theme'] == 'mc' and date(2022, 8, 25) <= e[0].date() <= date(2026, 9, 1)))
d = [e for e in W if e[0].date() == date(2023, 6, 3)]
print("N049.0 opens on 3 Jun 2023:", [(str(e[0]), e[2]['caption'], who(e[2])) for e in d])
print("N049.0 rows titled 'Integrals by parts' (number stripped):", sum(1 for e in W if strip(e[2]['caption']) == 'Integrals by parts'),
      "distinct ids:", len({e[2]['id'] for e in W if strip(e[2]['caption']) == 'Integrals by parts'}))
r = [e for e in W if e[2]['id'] == 'rca082'][0]
print("N049.0 rca082 local time:", r[0], r[2]['caption'])
print("N063.0 opens on 29 Oct 2026:", [(str(e[0].time()), e[2]['caption']) for e in W if e[0].date() == date(2026, 10, 29)])
print("N062.0 rows published in 2020:", sum(1 for x in ROWS if (x.get('published') or '').startswith('2020')), "of", len(ROWS),
      "| events in 2020:", sum(1 for e in EV if e[0].year == 2020))
print("N041/N055 save events (own, friend):", sum(1 for e in EV if e[1] in ('save', 'playlist') and not e[2].get('friend')),
      sum(1 for e in EV if e[1] in ('save', 'playlist') and e[2].get('friend')))
print("N041.0 save span:", min(e[0].date() for e in EV if e[1] in ('save', 'playlist')), "to", max(e[0].date() for e in EV if e[1] in ('save', 'playlist')))
print("N055.0 owner relation of saved rows: friend rows", [x['id'] for x in ROWS if x.get('friend')], "; no row carries a 'follow' field:",
      not any('follow' in x for x in ROWS))
print("N052.1 2024 opens all / private:", sum(1 for e in W if e[0].year == 2024), sum(1 for e in W if e[0].year == 2024 and e[2]['theme'] == 'da'))
print("N063.0 late October definition used: 21-30 Oct (export ends 30 Oct; 31 Oct has no rows:",
      sum(1 for e in EV if e[0].date() == date(2026, 10, 31)), ")")
print("N064.0 mid 2023 windows: Jun-Aug 137, May-Aug 138 (83 days with opens, span 116 days), all 2023 157 (see facts.txt)")
print("N032.0 evening = 17:00-21:00 local, which matches the answers' 67/70/69% (facts2 output)")
