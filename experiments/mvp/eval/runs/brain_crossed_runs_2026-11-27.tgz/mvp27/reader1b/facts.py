"""reader1b: facts from the made-up library rows only (no brain tools imported).
Run from /home/user/digester/experiments:  python3 -I <this file>
Dates are New York local dates (the library's clock)."""
import sys
sys.path.insert(0, "/home/user/digester/experiments")
from collections import Counter, defaultdict
from datetime import datetime, date
from zoneinfo import ZoneInfo

from mvp.tests import brain_library as L

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice (PRIVATE)"}
FIELD = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art", "dd": "art", "ca": "math", "np": "math",
         "co": "cooking", "da": "dating(PRIVATE)"}

ROWS = L.rows()
EV = []   # (local datetime, kind, row)
for r in ROWS:
    for k, at in r["events"]:
        EV.append((datetime.fromisoformat(at).astimezone(NY), k, r))
EV.sort(key=lambda e: e[0])


def who(r):
    return r.get("channel") or ("@" + r["handle"])


def sel(a, b, kinds=("watch",), plat=None, priv=True, friend=False):
    """events with local date in [a, b] inclusive."""
    out = []
    for t, k, r in EV:
        if k not in kinds or not (a <= t.date() <= b):
            continue
        if plat and r["platform"] != plat:
            continue
        if not priv and r["theme"] == "da":
            continue
        if not friend and r.get("friend"):
            continue
        out.append((t, k, r))
    return out


def show(label, ev):
    n = len(ev)
    print(f"  {label}: {n} events")
    if not n:
        return
    f = Counter(FIELD[r["theme"]] for _, _, r in ev)
    th = Counter(THEME[r["theme"]] for _, _, r in ev)
    ch = Counter(who(r) for _, _, r in ev)
    pl = Counter(r["platform"] for _, _, r in ev)
    np_ = n - sum(1 for _, _, r in ev if r["theme"] == "da")
    print("    platform:", dict(pl), "| non-private:", np_)
    print("    fields:", ", ".join(f"{k} {v} ({100*v/n:.0f}%; {100*v/np_:.0f}% of non-private)" if np_ else f"{k} {v}"
                                   for k, v in f.most_common()))
    print("    themes:", ", ".join(f"{k} {v}" for k, v in th.most_common()))
    print("    channels:", ", ".join(f"{k} {v}" for k, v in ch.most_common()))
    print("    span:", ev[0][0].date(), "to", ev[-1][0].date())


def D(s):
    return date.fromisoformat(s)


def head(k, q):
    print(f"\n=== {k}: {q}")


head("ALL", "whole library")
show("all watches (both platforms)", sel(D("2000-01-01"), D("2030-01-01")))
show("youtube watches", sel(D("2000-01-01"), D("2030-01-01"), plat="youtube"))
for y in range(2021, 2027):
    show(f"year {y} watches", sel(D(f"{y}-01-01"), D(f"{y}-12-31")))

head("N004.0", "last few weeks vs the summer")
show("4 weeks 3 Oct-30 Oct 2026", sel(D("2026-10-03"), D("2026-10-30")))
show("28 days 25 Oct-22 Nov 2026 (true last 4 weeks)", sel(D("2026-10-25"), D("2026-11-22")))
show("summer 2026 (1 Jun-31 Aug)", sel(D("2026-06-01"), D("2026-08-31")))
show("Sep 2026", sel(D("2026-09-01"), D("2026-09-30")))

head("N010.0", "this summer vs last summer")
show("summer 2026", sel(D("2026-06-01"), D("2026-08-31")))
show("summer 2025", sel(D("2025-06-01"), D("2025-08-31")))
show("summer 2024", sel(D("2024-06-01"), D("2024-08-31")))
head("N010.1", "just the art side")
for y in (2025, 2026):
    ev = [e for e in sel(D(f"{y}-06-01"), D(f"{y}-08-31")) if FIELD[e[2]["theme"]] == "art"]
    show(f"art summer {y}", ev)
    for m in (6, 7, 8):
        print(f"     month {y}-{m:02d}:", Counter(THEME[e[2]['theme']] for e in ev if e[0].month == m))

head("N013", "minecraft first / last")
mc = [e for e in EV if e[2]["theme"] == "mc" and e[1] == "watch"]
print("  minecraft watches:", len(mc), "first", mc[0][0], mc[0][2]["caption"], "| last", mc[-1][0], mc[-1][2]["caption"])
print("  last 3:", [(str(e[0].date()), e[2]["caption"]) for e in mc[-3:]])
print("  by year:", Counter(e[0].year for e in mc))
print("  2026 minecraft dates:", [str(e[0].date()) for e in mc if e[0].year == 2026])
mcw = [e for e in mc if e[0].year < 2026]
print("  last before 2026:", mcw[-1][0].date(), mcw[-1][2]["caption"])
other_mc_word = [e for e in EV if "inecraft" in e[2]["caption"] and e[2]["theme"] != "mc"]
print("  'minecraft' in caption off-theme:", len(other_mc_word))

head("N017", "channels most watched")
show("all time", sel(D("2000-01-01"), D("2030-01-01")))
show("2026", sel(D("2026-01-01"), D("2026-12-31")))
show("2025", sel(D("2025-01-01"), D("2025-12-31")))

head("N024", "split gaming/art/math/cooking")
show("2026", sel(D("2026-01-01"), D("2026-12-31")))
show("2025", sel(D("2025-01-01"), D("2025-12-31")))

head("N032.0", "weekends vs weekdays (all time, NY local)")
for lab, ev in (("all", sel(D("2000-01-01"), D("2030-01-01"))),):
    we = [e for e in ev if e[0].weekday() >= 5]
    wd = [e for e in ev if e[0].weekday() < 5]
    show("weekend", we)
    show("weekday", wd)
    print("  per day: weekend days share", f"{100*len(we)/len(ev):.1f}% of events; 2/7 = 28.6%")
    print("  by weekday:", Counter(e[0].strftime("%a") for e in ev))
    for nm, sub in (("weekend", we), ("weekday", wd)):
        hrs = Counter(e[0].hour for e in sub)
        print(f"  {nm} hours:", sorted(hrs.items()))
        ln = [e[2]["length"] for e in sub if e[2].get("length")]
        print(f"  {nm} mean length s: {sum(ln)/len(ln):.0f}  n={len(ln)}")
    for y in (2026,):
        sub = [e for e in ev if e[0].year == y]
        print(f"  {y}: weekend {sum(1 for e in sub if e[0].weekday()>=5)} weekday {sum(1 for e in sub if e[0].weekday()<5)}")

head("N036.0", "instagram reels in october")
for t, k, r in EV:
    if r["platform"] == "instagram":
        print("  ", t.date(), k, r["id"], r.get("media", "reel"), "@" + r["handle"], "friend" if r.get("friend") else "", r["caption"][:50])

head("N041", "saves")
for t, k, r in EV:
    if k in ("save", "playlist"):
        print("  ", t.date(), k, r["platform"], r["id"], who(r), "FRIEND" if r.get("friend") else "", L.COLLECTIONS.get(r["id"]), r["caption"][:60])

head("N049.0", "integrals video")
ig = [e for e in EV if "ntegral" in e[2]["caption"]]
print("  rows with 'integral' in title:", len(ig))
for t, k, r in ig:
    print("    ", t.date(), k, r["id"], r["caption"], "len", r["length"])

head("N052", "spring 2024")
show("spring 2024 (1 Mar-31 May)", sel(D("2024-03-01"), D("2024-05-31")))
show("spring 2024 non-private", sel(D("2024-03-01"), D("2024-05-31"), priv=False))
show("2024 all", sel(D("2024-01-01"), D("2024-12-31")))
show("spring 2023", sel(D("2023-03-01"), D("2023-05-31")))
show("spring 2025", sel(D("2025-03-01"), D("2025-05-31")))
da = [e for e in EV if e[2]["theme"] == "da"]
print("  dating span", da[0][0].date(), da[-1][0].date())
co24 = [str(e[0].date()) for e in EV if e[2]["theme"] == "co" and e[0].year == 2024]
print("  cooking 2024 dates:", co24)
for y in range(2021, 2027):
    print(f"  months of {y}:", sorted(Counter(e[0].month for e in sel(D(f'{y}-01-01'), D(f'{y}-12-31'))).items()))

head("N055.0", "friends' posts saved")
print("  friend rows:", [(r["id"], r["handle"], r["events"]) for r in ROWS if r.get("friend")])

head("N062.0", "anything from 2020")
print("  watches in 2020:", len(sel(D("2020-01-01"), D("2020-12-31"), kinds=("watch", "save", "playlist"))))
print("  first event:", EV[0][0], EV[0][2]["caption"], who(EV[0][2]))
pub = Counter(r.get("published") for r in ROWS)
print("  published dates:", pub)

head("N063", "late october / october")
show("21-30 Oct 2026", sel(D("2026-10-21"), D("2026-10-31")))
show("16-31 Oct 2026", sel(D("2026-10-16"), D("2026-10-31")))
show("Oct 2026 watches", sel(D("2026-10-01"), D("2026-10-31")))
show("Oct 2026 youtube watches", sel(D("2026-10-01"), D("2026-10-31"), plat="youtube"))
show("Oct 2026 all kinds incl saves", sel(D("2026-10-01"), D("2026-10-31"), kinds=("watch", "save", "playlist")))
show("Sep 2026", sel(D("2026-09-01"), D("2026-09-30")))
print("  30 Oct:", [(str(e[0]), e[2]["caption"]) for e in sel(D("2026-10-30"), D("2026-10-30"))])

head("N064.0", "mid 2023")
show("summer 2023 (Jun-Aug)", sel(D("2023-06-01"), D("2023-08-31")))
show("May-Aug 2023", sel(D("2023-05-01"), D("2023-08-31")))
show("Apr-Sep 2023", sel(D("2023-04-01"), D("2023-09-30")))
show("2023", sel(D("2023-01-01"), D("2023-12-31")))
show("H1 2023", sel(D("2023-01-01"), D("2023-06-30")))
for m in range(1, 13):
    print(f"  2023-{m:02d}:", Counter(THEME[e[2]['theme']] for e in sel(D(f'2023-{m:02d}-01'), D(f'2023-{m:02d}-28') if m == 2 else D(f'2023-{m:02d}-30') if m in (4,6,9,11) else D(f'2023-{m:02d}-31'))))
sr = [e for e in EV if e[2]["theme"] == "sr"]
print("  speedrun span", sr[0][0].date(), sr[-1][0].date())

head("N067.0", "november vs october so far")
show("Nov 2026", sel(D("2026-11-01"), D("2026-11-30")))
show("Oct 1-22 2026", sel(D("2026-10-01"), D("2026-10-22")))
show("Oct 2026", sel(D("2026-10-01"), D("2026-10-31")))
