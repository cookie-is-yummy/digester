import json, sys
d = json.load(open(sys.argv[1]))
lo, hi = int(sys.argv[2]), int(sys.argv[3])
for m in d['messages'][lo:hi]:
    print('#####', m['key'], '|', m['earlier_turns'], '|', m['message'])
    for a in m['answers']:
        e = a['earlier_answers_seen']
        print('--', a['code'], '| earlier:', [x.get('answer_sent', x)[:160].replace('\n', ' / ') if isinstance(x, dict) else x for x in e])
        print(a['sent'])
        p = a['parts']
        if p.get('ask_back'): print('   ASK_BACK:', p['ask_back'])
    print()
