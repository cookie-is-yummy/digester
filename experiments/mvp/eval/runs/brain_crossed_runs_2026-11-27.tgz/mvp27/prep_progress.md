# prep progress

- worktree made at S/mvp27/prep_tree on brain-r27-local from 650062c
- step 0: harness S/mvp27/prep/lib27.py (lib26 copy; base = 650062c verify/fallback/answer/loop in prep/base/), runs A, B added.
  Gate (gate.py): 650062c and tree values mode give runs A and B's saved live verdicts, 132 forms, 0 differ.
- step 1a: rule "row_name" in verify._values_marked (a claim found in the pool but held by no string of the cited row).
  measure27: true refused 12 -> 12 (all forms, six runs), faults 3 -> 4 (run B N038.0). attack27: misattached 626 -> 625
  (attack2 c06), made-up 10 -> 10.
- step 1b: rule "cell_found" (+ "day_typed"): figures only from numeric cells, row-list lengths, labels, message; window
  figures only with their unit; day counts not typed as item counts. Live: +1 true refused (run B N024.1 "four areas",
  the 4 came from an ISO date's month), +1 cannot_prove (N049.0 "part 6"). Attack sets: made-up 10 -> 10, policy 25 -> 24
  (f_length). Seam "92 videos" now refused, its true twin kept. Probe turns: 157 whole numbers no longer found (probes27.txt).
  Dates-from-cells variant (datesvar.py): 0 change live and on attacks, 4 dates fewer on probes: not adopted.
- step 2 (psych): verify._V_MOTIVE (values only, rule "motive_you"); planted psych 4/4 still refused; live forms: 0 hits
  for PSYCH, old _MOTIVE and new pattern on all six runs (psych27.py); made-up pairs psych_pairs.txt (9 true readings
  hit by the old, none by the new; 11 motives all hit by the new).
- diff27.py (base 650062c): full x3 + cells x2, 10570 verdicts 0 differ; answers 898 form-modes 0 differ.
- step 4 (left_out): tools._left_out after the size cut (sheet.left_out {private, friends}, >0 only, never under a
  title-word scope or words count); eval_claims._left_out_audit recounts it as meta.hidden (file outside my list);
  eval/brain_toolfix_ledger_diff.json regenerated (+16 entries, all "added left_out", 0 removed; outside my list);
  _no_toolfix_cells, test_brain_tools got.pop, eval_brain insight got.pop; test_brain_eval allows left_out where it
  allows meta.hidden.
- step 5 (screen): loop.SCREEN_DATA line in user_text; R.clean over the screen and over each plan's args.
- step 3/6 prompts: brain_v3b.md (diff prep/v3_to_v3b.diff), brain_v4_meaning.md (v3b + draft meaning diff, the same
  three hunks; prep/v3b_to_v4_meaning.diff). Examples: examples_all.txt (all new examples kept; the 16 v3 fragments
  refused on fixtures are the same in all three files). limits27.txt: 7 limit leads kept on run B ledgers; a turn with no
  result refuses "Your export ends on 30 October 2026" (unfound_date) before and after: open.
- tests/test_brain_r27.py (26 tests) pass; test_brain_values re-pinned (row_name); r26 seam test flipped (92 videos refused).
- checks: diff27 0 differ (10570 / 898); brain.planted full and --check cells byte-same as 650062c (git archive copy,
  removed), values 78/78 ok (f_length now refused); eval_brain planted with MVP_BRAIN_CHECK full/cells byte-same; dry
  selftest 164/164 on both, transcript differs only by build id and fake sign-in ids; demo 10 passed; cells/values/r27
  tests 148 passed under unset, cells, values. count tokens: v3 6464, v3b 6696, v4_meaning 6842 (system only).
- DESIGN 29 written; README edited (count pending the suite). Suite running (prep/shard.sh -> prep/suite_out).
- COMMITTED on brain-r27-local (not pushed); suite 6251 passed 2 skipped; scratch cleaned (suite_out, _lib, explore, tip copy, pycache)
- follow-up commit: loop test, title-word assertions, audit fix; 636 brain+auditor tests pass; README 6252
