"""mvp27 runs4: five columns (run B of mvp26, base1, base2, arm1, arm2), same definitions for all, from each run's
saved records and summary.json, plus marks_<run>.json (marks27.py) for the refusal marks. No model call.
usage: python3 summary27.py TREE NAME=DIR [NAME=DIR ...]"""
import glob
import json
import os
import re
import sys
from collections import Counter

TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import verify as V  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
COLS = [a.split("=", 1) for a in sys.argv[2:]]

# A limit sentence (one mechanical definition for every column): the checker's own LIMITS and _SELF_TALK patterns,
# plus the plain ways the tools' limits are said ("holds no likes", "nothing after", "not in your export", ...).
_EXTRA = re.compile(r"\b(?:holds? no|has no|no likes|nothing (?:after|past|from)|not in (?:your|the) (?:export|history|"
                    r"data)|isn'?t in (?:your|the)|aren'?t in (?:your|the)|does ?n[o']t hold|do ?n[o']t hold|"
                    r"(?:export|history|data) (?:only )?(?:goes|runs|stops|ends)|stops? (?:on|at) \d|ends? on \d|"
                    r"only (?:as )?(?:a )?counts?|friends?'?s? (?:post|save)s?|private|how far you watched|"
                    r"not (?:recorded|tracked|kept))", re.I)


_WIN = re.compile(r"(?:where|when) your (?:youtube |instagram )?export ends", re.I)


def unwin(s):
    """The checker's own step (verify 3.10): the window phrase 'where your export ends' is not a limit sentence."""
    return _WIN.sub(" ", s or "")


def narrow(s):
    return bool(s) and bool(V.LIMITS.search(unwin(s)) or V._SELF_TALK.search(unwin(s)))


def is_limit(s):
    return bool(s) and (narrow(s) or bool(_EXTRA.search(unwin(s))))


def pct(xs, q):
    xs = sorted(xs)
    if not xs:
        return None
    k = (len(xs) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(xs) - 1)
    return round(xs[lo] + (xs[hi] - xs[lo]) * (k - lo), 2)


def mean(xs):
    return round(sum(xs) / len(xs), 3) if xs else None


def load(d):
    d, _, sp = d.partition(":")
    recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(d, "N*.json"))]
    recs.sort(key=lambda r: (r["key"].split(".")[0], int(r["key"].split(".")[1])))
    s = json.load(open(sp or os.path.join(d, "summary.json"), encoding="utf-8"))
    return recs, s


def refusals(recs):
    rows = []
    for r in recs:
        for vi, v in enumerate(r.get("verdicts") or []):
            for o in v.get("outcomes") or []:
                if not o.get("kept"):
                    rows.append({"key": r["key"], "form": vi, "where": o["where"], "index": o["index"],
                                 "reasons": o.get("reasons") or [], "details": o.get("details") or [],
                                 "text": o.get("text")})
    return rows


def fig(name, d):
    recs, s = load(d)
    f, det = {}, {}
    ls = s["lead_source"]
    f["prompt version (settings)"] = s["settings"].get("prompt_version")
    f["check (settings)"] = s["settings"].get("check")
    f["messages / skipped"] = f"{s['messages']} / {s['skipped']}"
    for k in ("model", "model_after_repair", "code", "plain"):
        f[f"lead: {k}"] = ls.get(k, 0)
    g4 = s["G4_sentences"]
    f["sentences written / kept first pass / sent"] = f"{g4['written']} / {g4['kept_first_pass']} / {g4['kept_sent']}"
    f["  the same per message"] = "/".join(str(round(g4[k] / len(recs), 2)) for k in ("written", "kept_first_pass", "kept_sent"))
    npts = [len((r.get("answer") or {}).get("points") or []) for r in recs]
    f["points per answer mean"] = mean(npts)
    f["points per answer 0/1/2/3"] = "/".join(str(npts.count(i)) for i in range(4))
    f["rewords asked"] = s["repairs"]
    ref = refusals(recs)
    det["refused"] = ref
    f["sentences refused (all forms / first form)"] = f"{len(ref)} / {sum(1 for x in ref if x['form'] == 0)}"
    rc = Counter(c for x in ref for c in x["reasons"])
    f["refusals by code"] = ", ".join(f"{k} {v}" for k, v in sorted(rc.items(), key=lambda x: (-x[1], x[0]))) or "none"
    mp = os.path.join(HERE, f"marks_{name}.json")
    marks = None
    if os.path.exists(mp):
        m = json.load(open(mp, encoding="utf-8"))
        m = next(iter(m.values()))
        marks = {(x["key"], x["form"], x["where"], x["index"]): x["marks"] for x in m["refused"]}
        f["replay gate (forms, outcomes, differ)"] = f"{m['gate']['forms']}, {m['gate']['outcomes']}, {len(m['gate']['differ'])}"
        mc = Counter(t for v in marks.values() for t in v)
        f["refusals marked psych / row_name / cell_found / motive_you"] = " / ".join(
            f"{mc.get(r, 0)}" + (f" (+{mc[r + '(part)']} part)" if mc.get(r + "(part)") else "")
            for r in ("psych", "row_name", "cell_found", "motive_you"))
    else:
        f["replay gate (forms, outcomes, differ)"] = "n/a (older build)"
        f["refusals marked psych / row_name / cell_found / motive_you"] = (
            f"{sum(1 for x in ref if any(str(c).startswith('psych') for c in x['reasons']))} / n/a / n/a / n/a")
    det["marks"] = marks
    fl = [x for r in recs for x in r.get("flags") or []]
    fc = Counter(x["code"] for x in fl)
    f["flags logged (code@mode rows)"] = len(fl)
    f["flags: distinct sentences flagged"] = len({(r["key"], x.get("form", 0), x["where"], x["index"])
                                                  for r in recs for x in r.get("flags") or []})
    det["flags"] = Counter(f"{x['code']}@{x['mode']}" for x in fl)
    det["flags_code"] = fc
    secs = [r["seconds"] for r in recs]
    g5 = s["G5_seconds"]
    f["seconds median / p90 / max"] = f"{g5['median']} / {g5['p90']} / {g5['max']}"
    f["over 8 s / over 11 s"] = f"{sum(x > 8 for x in secs)} / {sum(x > 11 for x in secs)}"
    errs = {r["key"]: r["error"] for r in recs if r.get("error")}
    f["provider timeouts (messages)"] = f"{len(errs)} {sorted(errs)}"
    ev = s["events"]
    f["time_up / no_time_for_repair"] = f"{ev.get('time_up', 0)} / {ev.get('no_time_for_repair', 0)}"
    nreq = [r["n_requests"] for r in recs]
    f["requests total"] = sum(nreq)
    f["requests per message mean / median / max"] = f"{mean(nreq)} / {pct(nreq, .5)} / {max(nreq)}"
    costs = [100 * r["cost_usd"] for r in recs]
    f["cost per message mean / median / max (cents)"] = f"{mean(costs)} / {pct(costs, .5)} / {round(max(costs), 3)}"
    led = s.get("ledger") or {}
    f["cost by ledger ($), rows"] = f"{led.get('brain_eval_usd')}, {led.get('rows_added')}"
    q = s["requests"]
    n = sum(nreq)
    f["input tokens per request: uncached"] = round(q["input_tokens"] / n, 1)
    f["input tokens per request: cache read"] = round(q["cache_read_input_tokens"] / n, 1)
    f["input tokens per request: cache write"] = round(q["cache_creation_input_tokens"] / n, 1)
    f["input tokens per request: all three"] = round((q["input_tokens"] + q["cache_read_input_tokens"]
                                                      + q["cache_creation_input_tokens"]) / n, 1)
    f["output tokens per request"] = round(q["output_tokens"] / n, 1)
    f["output tokens total"] = q["output_tokens"]
    f["records (messages)"] = len(recs)
    f["output tokens per message mean"] = mean([r["tokens"]["output_tokens"] for r in recs])
    calls = [(r["key"], c) for r in recs for c in r["calls"]]
    f["tool calls per message mean"] = mean([len(r["calls"]) for r in recs])
    tc = Counter(c["name"] for _k, c in calls)
    f["tool calls by tool"] = ", ".join(f"{k} {v}" for k, v in sorted(tc.items(), key=lambda x: -x[1]))
    prev = [(k, c) for k, c in calls if c["name"] == "breakdown" and (c.get("args") or {}).get("compare") == "previous"]
    f["breakdowns with compare previous (calls / messages / all breakdowns)"] = (
        f"{len(prev)} / {len({k for k, _ in prev})} / {tc.get('breakdown', 0)}")
    terr = [(k, c) for k, c in calls if (c.get("result") or {}).get("is_error")]
    det["tool_errors"] = terr
    f["tool errors / read calls"] = f"{len(terr)} / {len(calls)}"
    code = [r for r in recs if r["lead_source"] not in ("model", "model_after_repair")]
    det["code"] = code
    f["NARROW (checker's LIMITS + _SELF_TALK): answers with a limit sentence in the lead"] = len(
        {r["key"] for r in recs if r["lead_source"].startswith("model") and narrow((r.get("answer") or {}).get("lead"))})
    nl = [(r["key"], p) for r in recs for p in ((r.get("answer") or {}).get("points") or []) if narrow(p)]
    f["NARROW: answers with a limit sentence in a point (sentences)"] = f"{len({k for k, _ in nl})} ({len(nl)})"
    lim_lead = [(r["key"], r["answer"]["lead"]) for r in recs if r["lead_source"].startswith("model")
                and is_limit((r.get("answer") or {}).get("lead"))]
    lim_pt = [(r["key"], p) for r in recs for p in ((r.get("answer") or {}).get("points") or []) if is_limit(p)]
    lim_code = [(r["key"], x) for r in recs for x in ((r.get("answer") or {}).get("limits") or [])]
    det["lim"] = (lim_lead, lim_pt, lim_code)
    f["WIDE (+ summary27._EXTRA): answers with a limit sentence in the model's lead"] = len({k for k, _ in lim_lead})
    f["WIDE: answers with a limit sentence in a point (sentences)"] = f"{len({k for k, _ in lim_pt})} ({len(lim_pt)})"
    lo = [(r["key"], o.get("sent")) for r in recs for v in (r.get("verdicts") or [])[-1:]
          for o in v.get("outcomes") or [] if o.get("kept") and ".left_out." in (o.get("text") or "")]
    f["sentences sent citing a left_out cell (by marker; answers)"] = f"{len(lo)} ({len({k for k, _ in lo})})"
    f["answers with code's limit line"] = len({k for k, _ in lim_code})
    f["code-lead answers with a limit word in the lead"] = sum(1 for r in code if is_limit((r.get("answer") or {}).get("lead")))
    f["private line / no offer"] = (f"{sum(1 for r in recs if (r.get('answer') or {}).get('private_line'))} / "
                                    f"{sum(1 for r in recs if not (r.get('answer') or {}).get('offers'))}")
    f["auditor hints (messages, hints)"] = f"{s['auditor_hints']['messages_with_hints']}, {s['auditor_hints']['hints']}"
    return f, det, recs


out = []
P = out.append
res = [(name, *fig(name, d)) for name, d in COLS]
w = max(len(k) for k in res[0][1])
cw = 24
P(f"{'':{w}}  " + "  ".join(f"{name:>{cw}}" for name, *_ in res))
for k in res[0][1]:
    vals = [str(f.get(k)) for _n, f, _d, _r in res]
    if max(len(v) for v in vals) > cw:
        P(f"{k}:")
        for (name, *_), v in zip(res, vals):
            P(f"    {name:>8}: {v}")
    else:
        P(f"{k:{w}}  " + "  ".join(f"{v:>{cw}}" for v in vals))
P("")
P("FLAGS BY CODE (code@mode rows; they refuse nothing)")
allf = sorted({k for _n, _f, d, _r in res for k in d["flags"]}, key=lambda k: -sum(d["flags"].get(k, 0) for _n, _f, d, _r in res))
P(f"{'':34s}" + "".join(f"{name:>10}" for name, *_ in res))
for k in allf:
    P(f"{k:34s}" + "".join(f"{d['flags'].get(k, 0):>10}" for _n, _f, d, _r in res))
for name, f, d, recs in res:
    P("")
    P(f"==================== {name}: REFUSED SENTENCES (every one, in full) ====================")
    P("  marks: psych = refused by a psych code; row_name = kept with the row_name rule off (the new row-name rule);")
    P("  cell_found = kept with cell_found and day_typed off (the cell-only found rule); motive_you = kept with it off")
    for x in d["refused"]:
        mk = "n/a (older build)" if d["marks"] is None else (d["marks"].get((x["key"], x["form"], x["where"], x["index"])) or [])
        if d["marks"] is None and any(str(c).startswith("psych") for c in x["reasons"]):
            mk = ["psych"]
        P(f"  {x['key']} form {x['form']} {x['where']} {x['index']}: {x['reasons']} marks {mk}")
        P(f"      details: {json.dumps(x['details'], ensure_ascii=False)}")
        P(f"      {x['text']}")
    if not d["refused"]:
        P("  none")
    P(f"---- {name}: TOOL ERRORS (every read call whose result is_error)")
    for k, c in d["tool_errors"]:
        res_ = c.get("result") or {}
        P(f"  {k} round {c['round']} {c['name']} args={json.dumps(c['args'], ensure_ascii=False)}")
        P(f"     error: {json.dumps({a: b for a, b in res_.items() if a != 'is_error'}, ensure_ascii=False)}")
    P(f"---- {name}: ANSWERS WHOSE LEAD IS NOT THE MODEL'S ({len(d['code'])}), in full")
    for r in d["code"]:
        P(f"  ==== {r['key']} | lead {r['lead_source']} | error {r.get('error')} | events {r.get('events')}")
        P(f"  message: {r['message']}")
        for line in ((r.get("answer") or {}).get("text") or "(nothing was sent)").split("\n"):
            P("    | " + line)
    lim_lead, lim_pt, lim_code = d["lim"]
    P(f"---- {name}: LIMIT SENTENCES SENT (definition: summary27.is_limit on answer.lead / answer.points)")
    for k, s_ in lim_lead:
        P(f"  lead  {k}{'' if narrow(s_) else ' (wide only)'}: {s_}")
    for k, s_ in lim_pt:
        P(f"  point {k}{'' if narrow(s_) else ' (wide only)'}: {s_}")
    for k, s_ in lim_code:
        P(f"  code's limit line {k}: {s_}")
print("\n".join(out))
