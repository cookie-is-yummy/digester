"""mvp27 runs4: replay the values check on every saved form of a live run (the tree's checker, made-up library, no
model call). Gate: the replay with all values rules must give the live verdicts (kept and reasons) exactly. Then each
refused sentence is replayed without each mvp27 rule, to mark which rule refused it:
  (a mark "<rule>(part)": with the rule off the sentence is still refused, but one of its reasons or details goes)
  row_name   - kept when "row_name" is off
  cell_found - kept when "cell_found" and "day_typed" are off (the refusal shows as unfound_*)
  motive_you - kept when "motive_you" is off (the old _MOTIVE) / refused by psych at all
usage: python3 -B marks27.py TREE RUN [RUN ...]  -> JSON on stdout"""
import glob
import json
import os
import sys

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
TREE = sys.argv[1]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp.brain import verify as V  # noqa: E402
from mvp import eval_brain as E  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
SCR = os.path.join(HERE, "_lib")
os.makedirs(SCR, exist_ok=True)
H = E.Harness.scratch(base=SCR)
ALL = V.values_mode()
NO = {"row_name": V.values_mode(rules=V.VALUES_RULES - {"row_name"}),
      "cell_found": V.values_mode(rules=V.VALUES_RULES - {"cell_found", "day_typed"}),
      "motive_you": V.values_mode(rules=V.VALUES_RULES - {"motive_you"})}


def turn_of(rec):
    kw = {}
    if rec.get("unlock_carried") and rec.get("unlock"):
        kw["carried_unlock"] = rec["unlock"]
    return H.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True), **kw)


def results_of(rec):
    return {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
            and not c["result"].get("is_error")}


out = {}
for run in sys.argv[2:]:
    gate = {"forms": 0, "outcomes": 0, "differ": []}
    refused = []
    for p in sorted(glob.glob(os.path.join(run, "N*.json"))):
        rec = json.load(open(p, encoding="utf-8"))
        t, res = turn_of(rec), results_of(rec)
        for fi, form in enumerate(rec.get("forms") or []):
            live = (rec.get("verdicts") or [])[fi] if fi < len(rec.get("verdicts") or []) else None
            if live is None:
                continue
            v = V.check_answer(form, res, V.Turn.of(t), mode=ALL)
            gate["forms"] += 1
            lo = {(o["where"], o["index"]): o for o in live.get("outcomes") or []}
            for o in v.outcomes:
                gate["outcomes"] += 1
                l_ = lo.get((o.where, o.index))
                if l_ is None or bool(l_.get("kept")) != bool(o.kept) or list(l_.get("reasons") or []) != list(o.reasons):
                    gate["differ"].append([rec["key"], fi, o.where, o.index, (l_ or {}).get("reasons"), list(o.reasons)])
            for o in v.outcomes:
                if o.kept:
                    continue
                marks = []
                for rule, mode in NO.items():
                    w = V.check_answer(form, res, V.Turn.of(t), mode=mode)
                    ow = next((x for x in w.outcomes if x.where == o.where and x.index == o.index), None)
                    # per reason: the rule is marked when, with it off, the sentence is kept, a reason goes, or a
                    # detail goes (a sentence refused for two reasons still shows which rule gave one of them)
                    if ow is not None and (ow.kept or set(o.reasons) - set(ow.reasons) or
                                           set(o.details) - set(ow.details)):
                        marks.append(rule if ow.kept else f"{rule}(part)")
                if any(str(c).startswith("psych") for c in o.reasons):
                    marks.append("psych")
                refused.append({"key": rec["key"], "form": fi, "where": o.where, "index": o.index,
                                "reasons": list(o.reasons), "details": list(o.details), "text": o.text,
                                "marks": marks, "message": rec["message"]})
    out[os.path.basename(os.path.normpath(run))] = {"gate": gate, "refused": refused}
print(json.dumps(out, indent=1, ensure_ascii=False))
