"""mvp27 runs4: blind marking packets. Seven arms, the same 65 messages of fresh half A (loaded with the eval's own
half-a loader, eval_brain.run_set). For each message: the user's message, the earlier turns of its conversation
(the user's earlier messages; each answer's own earlier answers, as that arm's user saw them), and the seven answers
exactly as sent (answer.text verbatim) with their parts, in a random order, each under a random code. Nothing that
could reveal the arm (timings, flags, prompt version, run paths, lead source, rids) is written.
Groups: the conversations split three ways (a conversation's messages stay together).
usage: python3 -B blind27.py TREE OUT_DIR        (seed: SEED below)"""
import glob
import json
import os
import random
import re
import string
import sys

SEED = 27011
TREE, OUT = sys.argv[1], sys.argv[2]
sys.path.insert(0, os.path.join(TREE, "experiments"))
from mvp import eval_brain as E  # noqa: E402
from mvp.brain import answer as A  # noqa: E402

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
ARMS = {"run2": f"{S}/mvp25/runa2/run1", "runA": f"{S}/mvp26/runs3/runA", "runB": f"{S}/mvp26/runs3/runB",
        "base1": f"{S}/mvp27/runs4/base1_raw", "base2": f"{S}/mvp27/runs4/base2_raw",
        "arm1": f"{S}/mvp27/runs4/arm1_raw", "arm2": f"{S}/mvp27/runs4/arm2_raw"}

rng = random.Random(SEED)
recs = {}
for arm, d in ARMS.items():
    rs = {}
    for f in glob.glob(os.path.join(d, "N*.json")):
        r = json.load(open(f, encoding="utf-8"))
        rs[r["key"]] = r
    recs[arm] = rs
convs = [p for p, _c in E.run_set("a", set_name="fresh")]
keys = [f"{p['id']}.{m['n']}" for p in convs for m in p["messages"] if m["tier"] == "plan"]
assert len(keys) == 65, len(keys)
missing = {}
for arm, rs in recs.items():
    assert set(rs) <= set(keys), (arm, sorted(set(rs) - set(keys)))
    missing[arm] = sorted(set(keys) - set(rs))
    for p in convs:
        for m in p["messages"]:
            k = f"{p['id']}.{m['n']}"
            if m["tier"] == "plan" and k in rs:
                assert rs[k]["message"] == m["text"], (arm, k)
                assert not rs[k].get("skipped"), (arm, k)


def parts(a):
    a = a or {}
    return {"lead": a.get("lead") or "",
            "points": list(a.get("points") or []),
            "limit_lines": list(a.get("limits") or []),
            "ask_back": A.ASK_LINE if a.get("ask") else None,
            "cards": [c.get("line") for c in (a.get("cards") or [])],
            "scope_line": a.get("scope_line") or None,
            "private_line": A.PRIVATE_LINE if a.get("private_line") else None,
            "offers": [o.get("label") for o in (a.get("offers") or [])]}


def sent(r):
    return (r.get("answer") or {}).get("text") or ""


used = set()


def code():
    while True:
        c = rng.choice(string.ascii_lowercase) + "".join(rng.choice(string.ascii_lowercase + string.digits)
                                                         for _ in range(2))
        if c not in used:
            used.add(c)
            return c


packets, key = {}, {}
arm_names = list(ARMS)
for p in convs:
    for m in p["messages"]:
        if m["tier"] != "plan":
            continue
        k = f"{p['id']}.{m['n']}"
        earlier = []
        if p.get("before"):
            earlier.append({"you": p["before"]["message"], "note": "set-up turn; its answer is not in the record"})
        prior = [x for x in p["messages"] if x["n"] < m["n"]]
        for x in prior:
            e = {"you": x["text"]}
            if x["tier"] != "plan":
                e["note"] = "not sent to the bot in this test (no answer)"
            earlier.append(e)
        order = list(arm_names)
        rng.shuffle(order)
        answers = []
        for arm in order:
            if k not in recs[arm]:
                continue   # (that run's record was never written: no answer, no placeholder)
            c = code()
            key[c] = {"arm": arm, "key": k}
            seen = [{"you": x["text"], "answer_sent": sent(recs[arm][f"{p['id']}.{x['n']}"])}
                    for x in prior if x["tier"] == "plan" and f"{p['id']}.{x['n']}" in recs[arm]]
            answers.append({"code": c, "earlier_answers_seen": seen, "sent": sent(recs[arm][k]),
                            "parts": parts(recs[arm][k].get("answer"))})
        packets[k] = {"key": k, "conversation": p["id"], "earlier_turns": earlier, "message": m["text"],
                      "answers": answers}

# three groups by conversation (balanced: each conversation, in a seeded order, to the group with fewest messages)
cids = [p["id"] for p in convs]
size = {p["id"]: sum(1 for m in p["messages"] if m["tier"] == "plan") for p in convs}
order = list(cids)
rng.shuffle(order)
groups = [[], [], []]
for cid in sorted(order, key=lambda c: -size[c]):
    g = min(range(3), key=lambda i: (sum(size[c] for c in groups[i]), i))
    groups[g].append(cid)
os.makedirs(OUT, exist_ok=True)
counts = []
for i, g in enumerate(groups):
    msgs = [packets[k] for k in keys if k.split(".")[0] in g]
    doc = {"group": i + 1, "how": ("Each message: the user's message, the earlier turns of its conversation, and "
                                   "up to seven answers (fewer where a run lost a record) in a random order under random codes. 'sent' is the answer exactly "
                                   "as the user saw it; 'parts' splits it; 'earlier_answers_seen' is what this same "
                                   "answer's bot had sent before in the conversation."),
           "messages": msgs}
    with open(os.path.join(OUT, f"group{i + 1}.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1, ensure_ascii=False)
    counts.append({"group": i + 1, "conversations": len(g), "messages": len(msgs),
                   "answers": sum(len(m["answers"]) for m in msgs),
                   "short": {m["key"]: len(m["answers"]) for m in msgs if len(m["answers"]) < len(ARMS)}})
with open(os.path.join(OUT, "KEY_do_not_open.json"), "w", encoding="utf-8") as f:
    json.dump({"seed": SEED, "script": os.path.abspath(__file__), "arms": ARMS,
               "groups": {f"group{i + 1}": g for i, g in enumerate(groups)}, "codes": key}, f, indent=1)

# self-tests: the key and the groups give back every answer.text byte for byte; no leak words in the group files
back = {}
for i in range(3):
    doc = json.load(open(os.path.join(OUT, f"group{i + 1}.json"), encoding="utf-8"))
    for m in doc["messages"]:
        assert sorted(a_["code"] for a_ in m["answers"]) == sorted(c for c, v in key.items() if v["key"] == m["key"])
        for a_ in m["answers"]:
            v = key[a_["code"]]
            back[(v["arm"], v["key"])] = a_["sent"]
            assert list(a_["parts"]) == ["lead", "points", "limit_lines", "ask_back", "cards", "scope_line",
                                         "private_line", "offers"]
assert len(back) == sum(len(rs) for rs in recs.values())
for arm, rs in recs.items():
    for k, r in rs.items():
        assert back[(arm, k)] == sent(r), (arm, k)
leak = re.compile(r"brain_v|prompt|seconds|flags?\b|lead_source|run2|runA|runB|base[12]|arm[12]|/tmp|scratchpad|"
                  r"mvp2|values|cells|model_after|rid\b|\"r\d\b", re.I)
for i in range(3):
    raw = open(os.path.join(OUT, f"group{i + 1}.json"), encoding="utf-8").read()
    hits = sorted({h.group(0) for h in leak.finditer(raw)})
    print(f"group{i + 1}: leak-pattern hits {hits}")
same = sum(1 for k in keys if len({sent(recs[a_][k]) for a_ in arm_names if k in recs[a_]})
           < sum(1 for a_ in arm_names if k in recs[a_]))
print(json.dumps({"seed": SEED, "counts": counts, "codes": len(key), "messages_with_two_arms_same_text": same,
                  "missing": missing,
                  "self_test": f"ok: {len(back)} answers give back answer.text byte for byte"}, indent=1))
