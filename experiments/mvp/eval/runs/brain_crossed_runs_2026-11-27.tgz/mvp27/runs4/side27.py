"""The first N answers (key order) of two runs, side by side, exactly as sent. usage: python3 side27.py A_DIR B_DIR N"""
import glob
import json
import os
import sys

a, b, n = sys.argv[1], sys.argv[2], int(sys.argv[3])


def load(d):
    return {r["key"]: r for r in (json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(d, "N*.json")))}


A, B = load(a), load(b)
keys = sorted(A, key=lambda k: (k.split(".")[0], int(k.split(".")[1])))[:n]
for k in keys:
    print(f"==== {k} | message: {A[k]['message']}")
    for name, R in ((os.path.basename(a.rstrip('/')), A), (os.path.basename(b.rstrip('/')), B)):
        print(f"  -- {name} (lead {R[k]['lead_source']}):")
        for line in ((R[k].get("answer") or {}).get("text") or "(nothing was sent)").split("\n"):
            print("    | " + line)
    print()
