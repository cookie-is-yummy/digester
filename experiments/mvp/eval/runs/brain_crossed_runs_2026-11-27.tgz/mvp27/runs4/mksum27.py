"""mvp27 runs4: the summary of a run whose eval crashed after the turns (the auditor's float() on a date, after
N019.0), built with the eval's own summarize() over the saved records (it gives base1's saved summary.json exactly,
'ledger' apart). Written beside the run folder, never into it. The settings are base1's with the prompt version that
was meant (confirmed from the first requests' input tokens, +146 for brain_v4_meaning) and the records' spend.
usage: python3 -B mksum27.py TREE RUN PROMPT TEMPLATE_SUMMARY OUT"""
import glob
import json
import os
import sys

tree, run, prompt, tmpl, out = sys.argv[1:6]
sys.path.insert(0, os.path.join(tree, "experiments"))
from mvp import eval_brain as E  # noqa: E402

order = {p["id"]: i for i, (p, _c) in enumerate(E.run_set("a", set_name="fresh"))}
recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(run, "N*.json"))]
recs.sort(key=lambda r: (order[r["id"]], r["n"]))
st = dict(json.load(open(tmpl, encoding="utf-8"))["settings"])
st.update(prompt_version=prompt, spent_usd=round(sum(r["cost_usd"] for r in recs), 6),
          requests=sum(r["n_requests"] for r in recs),
          reconstructed=("the run's summary.json was never written (eval auditor crash after N019.0); settings are "
                         "base1's with this prompt version; spend and requests are the saved records' (N019.0's not "
                         "included)"))
s = E.summarize(recs, st)
s["ledger"] = {"brain_eval_usd": None, "rows_added": None, "note": "not read: data/ is off limits"}
with open(out, "w", encoding="utf-8") as f:
    json.dump(s, f, indent=1, default=str, ensure_ascii=False)
print(out, len(recs), st["spent_usd"], st["requests"])
