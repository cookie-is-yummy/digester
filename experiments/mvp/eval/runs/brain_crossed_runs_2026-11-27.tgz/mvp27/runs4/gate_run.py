"""Gate one live run folder: 65 records, none skipped, all half a, prompt version and check as meant.
usage: python3 gate_run.py RUN PROMPT"""
import glob
import json
import os
import sys

run, want = sys.argv[1], sys.argv[2]
recs = [json.load(open(f, encoding="utf-8")) for f in glob.glob(os.path.join(run, "N*.json"))]
s = json.load(open(os.path.join(run, "summary.json"), encoding="utf-8"))
st = s["settings"]
ok = (len(recs) == 65 and not any(r.get("skipped") for r in recs) and {r.get("half") for r in recs} == {"a"}
      and st["prompt_version"] == want and st["check"] == "values" and {r.get("check") for r in recs} == {"values"})
print(json.dumps({"records": len(recs), "skipped": sum(1 for r in recs if r.get("skipped")),
                  "halves": sorted({str(r.get("half")) for r in recs}), "prompt_version": st["prompt_version"],
                  "check": st["check"], "spent_usd": st["spent_usd"], "ledger": s.get("ledger"),
                  "errors": {r["key"]: r["error"] for r in recs if r.get("error")}, "GATE_OK": ok}))
