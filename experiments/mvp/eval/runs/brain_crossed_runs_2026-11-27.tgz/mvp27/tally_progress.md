# tally progress
- step 1: read brief, rubric, summary.txt, key; marks complete for all 6 readers (452 answers x 2, no dup, no missing, key matches). Next: load + agreement script tally/tally.py.
- step 2: recount.py (rows only) on the 7 false-vs-wb disputes: all are label disputes, both readers call each sentence wrong; settled 1 false / 6 wb (recount_out.txt).
- step 3: tally.py -> tally_out.txt, tables_raw.json (agreement, per-arm, paired comparisons with sign test + conversation bootstrap seed 27, noise pairs, timeout/code-lead sensitivity, seconds, decision rule, targets). Decision rule: NOT adopted (means +7.0 on reader slot a < 7.9; slot b +10.5); other four conditions pass.
- step 4: false sentences of the four new runs traced to records (flags/verdicts); poor answers of the meaning arm listed (poor_arm.txt), wb list (wb_newruns.txt). Next: tables.json + report.txt.
- step 5: report.txt and tables.json written; N049.0 recount confirmed (first 'integrals' title 4 Jun 2023). Next: advisor check, then return.
- step 6: advisor fixes applied (5a both counts + N007.0/N066.1 in full, pairing robustness, 4b poor-cause evidence, full a/b rows, 5b groups A/A2, wording). DONE, $0.
