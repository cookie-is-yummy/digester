"""mvp27 differential (from mvp26/values/diff26.py): full and cells mode of this tree against the merged tip's checker
(650062c, prep/base/), byte for byte, on every form of every set (the six live runs); the code lead and both answer
builds against 650062c's fallback.py and answer.py; loop's verdict_json against 650062c's. No model call."""
import os, sys, dataclasses
import lib27 as L
V, VT = L.V, L.VT
OFIELDS = [f.name for f in dataclasses.fields(VT.Outcome)]


def vdump(v):
    out = {k: getattr(v, k) for k in ("items", "outside", "chart", "form_error", "private_line", "repair", "version",
                                      "check")}
    out["lead_ok"] = v.lead_ok
    out["outcomes"] = [{k: getattr(o, k) for k in OFIELDS} | {"kept": o.kept} for o in v.outcomes]
    return repr(out)


def forms():
    for c, k, f, led in L.planted_forms():
        yield f"planted:{c['id']}:{k}", f, led, ("p", c)
    for run in L.RUNS:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                yield f"{run}:{rec['key']}:{fi}", f, results, ("t", t)
    for c, sent, carrier, where, t in L.skeptic_inputs():
        f = {"lead": sent} if where == "L" else {"lead": carrier, "points": [sent]}
        yield f"skeptic:{c[0]}", f, t.results, ("t", t)
    import rc_cases_v2 as C2
    inp = L.look_lookup()
    for cid, look, key, where, truth, cls, text, recount, _r in C2.CASES:
        rec, t, results = inp[(look, key)]
        f = {"lead": text} if where == "L" else {"lead": rec["forms"][0].get("lead") or "", "points": [text]}
        yield f"rc2:{cid}", f, results, ("t", t)
    d = L.a2()
    for c in d["cases"]:
        led, car, tt = d["ledgers"][c["record"]], d["carriers"][c["record"]], d["turns"][c["record"]]
        yield f"a2:{c['id']}:P", {"lead": car, "points": [c["text"]]}, led, ("a2", tt)
        yield f"a2:{c['id']}:L", {"lead": c["text"], "points": []}, led, ("a2", tt)
    C, turns = L.check2_inputs()
    for cid, tid, truth, fam, s, note in C.CASES:
        t, results = turns[tid]
        yield f"c2:{cid}:P", {"lead": C.CARRIER[tid], "points": [s]}, results, ("t", t)
        yield f"c2:{cid}:L", {"lead": s, "points": []}, results, ("t", t)


def turn_of(mod, how):
    kind, x = how
    if kind == "p":
        return L._pturn(mod, x)
    if kind == "a2":
        return L.a2_turn(mod, x)
    return mod.Turn.of(x)


def main():
    n = bad = flagged = 0
    os.environ.pop(V.CHECK_ENV, None)
    for name, f, led, how in forms():
        for mode in ("full", "cells"):
            b = vdump(VT.check_answer(f, VT.Ledger(led), turn_of(VT, how), mode=mode))
            ways = [("arg", mode)] + ([("env_unset", None), ("env", "full")] if mode == "full" else [("env", "cells")])
            for wname, m in ways:
                if wname == "env":
                    os.environ[V.CHECK_ENV] = m
                    m = None
                v = V.check_answer(f, V.Ledger(led), turn_of(V, how), mode=m)
                os.environ.pop(V.CHECK_ENV, None)
                n += 1
                flagged += sum(1 for o in v.outcomes if o.flags)
                if vdump(v) != b:
                    bad += 1
                    if bad <= 5:
                        print("DIFF", name, mode, wname)
    print(f"checker differential (full x3 ways, cells x2 ways, against the tip's verify.py): {n} verdicts, {bad} differ, "
          f"{flagged} outcomes with flags")
    return bad


def answers():
    FBt = L._load(os.path.join(L.HERE, "base", "fallback_tip.py"), "mvp.brain.fallback_tip")
    FBt.V = VT
    At = L._load(os.path.join(L.HERE, "base", "answer_tip.py"), "mvp.brain.answer_tip")
    At.V = VT
    LPt = L._load(os.path.join(L.HERE, "base", "loop_tip.py"), "mvp.brain.loop_tip")
    from mvp.brain import fallback as FB, answer as A, loop as LP
    n = bad = 0
    for run in L.RUNS:
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                for mode in ("full", "cells"):
                    vb = VT.check_answer(f, results, VT.Turn.of(t), mode=mode)
                    vr = V.check_answer(f, results, V.Turn.of(t), mode=mode)
                    cb = FBt.answer(VT.Ledger(results), vb, VT.Turn.of(t), mode=mode)
                    cr = FB.answer(V.Ledger(results), vr, V.Turn.of(t), mode=mode)
                    ab = At.build(VT.Ledger(results), verdict=None, code=cb, form=f, also=[vb], mode=mode)
                    ar = A.build(V.Ledger(results), verdict=None, code=cr, form=f, also=[vr], mode=mode)
                    mb = At.build(VT.Ledger(results), verdict=vb, form=f, also=[vb], mode=mode)
                    mr = A.build(V.Ledger(results), verdict=vr, form=f, also=[vr], mode=mode)
                    jb, jr = LPt.verdict_json(vb), LP.verdict_json(vr)
                    n += 1
                    if repr((cb, ab, mb, jb)) != repr((cr, ar, mr, jr)):
                        bad += 1
                        if bad <= 5:
                            print("ANSWER DIFF", run, rec["key"], fi, mode)
    print(f"answers (code lead, code build, model build, verdict_json; full and cells, against the tip's fallback, "
          f"answer and loop): {n} form-modes, {bad} differ")
    return bad


if __name__ == "__main__":
    sys.exit(1 if (answers() if "--answers" in sys.argv else main()) else 0)
