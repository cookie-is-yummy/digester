"""Which keys of the results hold code-written strings with a figure in them (the cells of item 1b)."""
import json, re, sys
from collections import defaultdict
import lib27 as L
V = L.V
ex = defaultdict(list)
cnt = defaultdict(int)

def walk(o, path, key=None):
    if isinstance(o, dict):
        for k, v in o.items():
            walk(v, path + "." + k, k)
    elif isinstance(o, list):
        for v in o:
            walk(v, path + "[]", key)
    elif isinstance(o, str):
        if key in V._V_THIRD_PARTY:
            return
        if re.search(r"\d", o):
            p = re.sub(r"^r\d+", "r", path)
            cnt[p] += 1
            if len(ex[p]) < 2 and o not in ex[p]:
                ex[p].append(o)

for run in L.RUNS:
    for rec, t, results in L.inputs(run):
        for rid, env in results.items():
            walk(env, "r")
mr = json.load(open(L.S + "/mvp26/merge/results_merge.json"))
def walk_any(o):
    if isinstance(o, dict):
        if "rid" in o and "meta" in o:
            walk(o, "r"); return
        for v in o.values(): walk_any(v)
    elif isinstance(o, list):
        for v in o: walk_any(v)
walk_any(mr)
for p in sorted(cnt):
    print(f"{cnt[p]:5d} {p:60s} {ex[p][0][:110]!r}")
