"""Item 2: the old motive pattern (_MOTIVE, full and cells) against the values one (_V_MOTIVE) on readings the meaning
prompt invites (true) and on motives and states of mind (false). Patterns only, sentences made up."""
import lib27 as L
V = L.V
TRUE = ["2024 looks thin because you opened 8 videos that year.",
        "Gaming led because Clip Factory made 61 of its 142 videos.",
        "That share is high because one channel made 61 of the 142 videos.",
        "October stands out because you opened 142 videos in it, against 90 in September.",
        "The drop is because Moss Garden fell from 40 to 3 videos.",
        "It counts as new because you first opened it on 1 October 2026.",
        "Cooking grew because Pan Theory alone added 20 videos.",
        "Most of the gap is because your Instagram export starts on 5 October 2026.",
        "Your spring of 2024 is thin because you saved 3 posts in it."]
FALSE = ["Clip Factory led with 61 videos because you were bored.",
         "You opened 61 videos because you love cooking.",
         "That is because you wanted to relax after work.",
         "Gaming grew because it relaxes you.",
         "October was busy because of your stress at work.",
         "You must be into cooking, with 61 videos.",
         "You opened 40 of them because you're stressed.",
         "Because you were tired, you opened more Shorts.",
         "You watched them to unwind.",
         "You must love watercolor, with 13 videos.",
         "You saved them because you need new recipes."]
for name, xs in (("TRUE (should not be hit)", TRUE), ("FALSE (should be hit)", FALSE)):
    print("==", name)
    for s in xs:
        low = s.lower()
        old = bool(V.PSYCH.search(low) or V._MOTIVE.search(low))
        new = bool(V.PSYCH.search(low) or V._V_MOTIVE.search(low))
        print(f"  old={'hit' if old else '-':3s} new={'hit' if new else '-':3s} | {s}")
