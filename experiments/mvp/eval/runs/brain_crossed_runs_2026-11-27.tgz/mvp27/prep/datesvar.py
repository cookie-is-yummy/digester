"""Measurement only: the variant 'dates from cells only' (day-month and month-year dates read from labels, window words
and the message, not from notes or other prose), patched into this tree's pool for the run. Prints the measure27 and
attack27 tables for base+row_name+cell_found+day_typed with and without it."""
import re, sys
import lib27 as L
V = L.V
orig = V._Pool.__init__


def patched(self, ledger, message=""):
    orig(self, ledger, message)
    # rebuild the day-month and month-year dates from value and window strings only (plus ISO cells, kept)
    strs = []

    def walk(o, key=None):
        if isinstance(o, dict):
            for k, v in o.items():
                walk(v, k)
        elif isinstance(o, list):
            for v in o:
                walk(v, key)
        elif isinstance(o, str) and key in (V._V_VALUE_KEYS | V._V_WINDOW_KEYS):
            strs.append(o)
    for r in ledger.by_rid.values():
        walk(r.env)
    txt = "\n".join(strs).lower() + "\n" + self.message
    iso = set()
    def wiso(o):
        if isinstance(o, dict):
            for v in o.values(): wiso(v)
        elif isinstance(o, list):
            for v in o: wiso(v)
        elif isinstance(o, str):
            m = V._V_ISO.match(o.strip())
            if m: iso.add((int(m.group(1)), int(m.group(2)), int(m.group(3))))
    for r in ledger.by_rid.values():
        wiso(r.env)
    self.dates = set(iso)
    for m in re.finditer(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(" + V._V_MONTH + r")\w*\.?(?:,?\s+((?:19|20)\d\d))?\b", txt):
        mo = V._mon_i(m.group(2))
        if mo and 1 <= int(m.group(1)) <= 31:
            self.dates.add((int(m.group(3)) if m.group(3) else None, mo, int(m.group(1))))
    self.code_text = txt


if "--on" in sys.argv:
    V._Pool.__init__ = patched
    sys.argv.remove("--on")
import runpy
script = sys.argv.pop(1)
runpy.run_path(script, run_name="__main__")
