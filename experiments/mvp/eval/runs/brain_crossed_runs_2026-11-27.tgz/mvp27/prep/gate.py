"""Gate: the base (650062c) values mode and this tree's values mode on runs A and B's saved forms against their saved
live verdicts (kept, reasons per sentence)."""
import sys
import lib27 as L
for name, mod in (("base 650062c", L.VT), ("tree", L.V)):
    n = bad = 0
    for run in ("runA", "runB"):
        for rec, t, results in L.inputs(run):
            for fi, f in enumerate(rec.get("forms") or []):
                v = mod.check_answer(f, results, mod.Turn.of(t), mode="values")
                sv = rec["verdicts"][fi]
                got = [(o.where, o.index, o.kept, list(o.reasons)) for o in v.outcomes]
                want = [(o["where"], o["index"], o["kept"], list(o["reasons"])) for o in sv["outcomes"]]
                n += 1
                if got != want or v.repair != sv["repair"]:
                    bad += 1
                    print("DIFF", name, run, rec["key"], fi, got, want)
    print(f"{name}: {n} forms, {bad} differ from the saved live verdicts")
