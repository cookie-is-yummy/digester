"""mvp27 prep: values mode on every hand-judged sentence of the six live runs (all forms and first forms), base
(650062c) against this tree, optionally with rule variants: true refused, faults refused, model lead kept.
usage: python3 -B measure27.py [variant ...]   (a variant is a CheckMode built by variants.py)"""
import json
import sys
from collections import Counter
import lib27 as L

RUNS = ("look1", "look2", "run1", "run2", "runA", "runB")


def checkers():
    import variants
    out = [("base", L.VT, "values")]
    for name in (sys.argv[1:] or ["tree"]):
        out.append((name, L.V, variants.mode(name)))
    return out


def lead_paths(run, mod, mode):
    n = first = sent = rew = 0
    for rec, t, results in L.inputs(run):
        forms = rec.get("forms") or []
        n += 1
        if not forms:
            continue
        v1 = L.check(mod, forms[0], results, t, mode)
        first += v1.lead_ok
        rew += v1.repair
        if v1.lead_ok:
            sent += 1
        elif len(forms) > 1 and L.check(mod, forms[1], results, t, mode).lead_ok:
            sent += 1
    return {"n": n, "lead_first": first, "lead_sent": sent, "rewords": rew}


def main():
    res, lists = {}, {}
    cks = checkers()
    for cname, mod, mode in cks:
        for run in RUNS:
            rs = L.rows(run, mod, mode)
            d = {}
            for scope, sel in (("first", lambda r: r["fi"] == 0), ("all", lambda r: True)):
                T = [r for r in rs if sel(r) and r["truth"] == "T"]
                F = [r for r in rs if sel(r) and r["truth"] == "F"]
                d[scope] = {"T": len(T), "T_ref": sum(not r["kept"] for r in T), "F": len(F),
                            "F_ref": sum(not r["kept"] for r in F)}
            d.update(lead_paths(run, mod, mode))
            res[(cname, run)] = d
            lists[(cname, run)] = {(r["key"], r["fi"], r["where"], r["index"]): r for r in rs}
    P = print
    for scope in ("all", "first"):
        P(f"== {scope} forms: true refused/true, faults refused/faults")
        P(f"{'checker':22s}" + "".join(f"{r:>14s}" for r in RUNS) + f"{'total':>16s}")
        for cname, _m, _x in cks:
            tot = Counter()
            cells = []
            for run in RUNS:
                d = res[(cname, run)][scope]
                cells.append(f"{d['T_ref']}/{d['T']} {d['F_ref']}/{d['F']}")
                tot.update(d)
            P(f"{cname:22s}" + "".join(f"{c:>14s}" for c in cells) + f"{tot['T_ref']:>6d}/{tot['T']} {tot['F_ref']}/{tot['F']}")
    P("== answers: model lead kept on the first form / model lead sent (first or saved reword) / rewords asked, of n")
    for cname, _m, _x in cks:
        tot = Counter()
        cells = []
        for run in RUNS:
            d = res[(cname, run)]
            cells.append(f"{d['lead_first']}/{d['lead_sent']}/{d['rewords']} of {d['n']}")
            tot.update({k: d[k] for k in ("lead_first", "lead_sent", "rewords", "n")})
        P(f"{cname:22s}" + "".join(f"{c:>16s}" for c in cells) +
          f"   total {tot['lead_first']}/{tot['lead_sent']}/{tot['rewords']} of {tot['n']}")
    base = cks[0][0]
    for cname, _m, _x in cks[1:]:
        P(f"== {cname} against {base}: every sentence whose verdict changed (truth, before -> after)")
        for run in RUNS:
            a, b = lists[(base, run)], lists[(cname, run)]
            for k in sorted(a):
                ra, rb = a[k], b[k]
                if ra["kept"] != rb["kept"] or ra["reasons"] != rb["reasons"]:
                    P(f"  {run} {k[0]} f{k[1]} {k[2]}{k[3]} truth={rb['truth']} {ra['reasons']} -> {rb['reasons']}"
                      f" | {'; '.join(rb['details'])[:160]}")
                    P(f"      {rb['text'][:240]}")
        P(f"== {cname}: every hand-judged sentence it refuses")
        for run in RUNS:
            for k, r in sorted(lists[(cname, run)].items()):
                if r["truth"] in ("T", "F") and not r["kept"]:
                    P(f"  {run} {k[0]} f{k[1]} {k[2]}{k[3]} truth={r['truth']} {r['reasons']} | {r['text'][:200]}")
        P(f"== {cname}: refused sentences with no truth label")
        for run in RUNS:
            for k, r in sorted(lists[(cname, run)].items()):
                if r["truth"] not in ("T", "F") and not r["kept"]:
                    P(f"  {run} {k[0]} f{k[1]} {k[2]}{k[3]} truth={r['truth']} {r['reasons']} | {r['text'][:200]}")


if __name__ == "__main__":
    main()
