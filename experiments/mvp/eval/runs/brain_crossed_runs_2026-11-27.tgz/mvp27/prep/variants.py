"""Rule variants of this tree's values mode, for measuring (names -> CheckMode)."""
import lib27 as L
V = L.V


def mode(name):
    if name == "tree":
        return "values"
    rules = V.VALUES_RULES
    want = set(name.split("+")) - {"base"}
    return V.values_mode(rules=frozenset(want))
