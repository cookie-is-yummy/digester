"""Item 3: limit leads the baseline prompt asks for, written by hand in its words on run B's saved results (N038.0
likes, N042.0 likes, N056.0 how far, N066.0 this week, N067.0 November), and one with no result at all; values mode
of 650062c and of this tree, as a lead and as a point. Made-up library; no model call."""
import lib27 as L
V = L.V
S = {
 "N038.0": ["Your export holds no likes, so here is what you saved instead: in the 4 weeks up to 30 October 2026, "
            "you saved 6[r2.totals.items] items.",
            "Your export holds no likes; in the 4 weeks up to 30 October 2026 you saved 6[r2.totals.items] items, "
            "3[r2.channels[0].items] of them from Wet Paper[r2.channels[0]]."],
 "N042.0": ["Your export holds no likes, so there is nothing to set your saves against: you saved "
            "6[r1.totals.items] items from 3 to 30 October 2026."],
 "N056.0": ["Your export does not say how far you watched a video, only that you opened it; across all your "
            "history you opened 723[r1.totals.items] videos."],
 "N066.0": ["Your export ends on 30 October 2026, so this week is not in it; in the last 7 days up to then you "
            "opened 24[r1.totals.items] videos."],
 "N067.0": ["Your export ends on 30 October 2026, so November is not in it; in October 2026 you opened "
            "142[r1.totals.items] videos, 61[r1.channels[0].items] of them from Clip Factory[r1.channels[0]].",
            "There is nothing after 30 October 2026 in your export, so November cannot be set against October: in "
            "October 2026 you opened 142[r1.totals.items] videos."],
}
for rec, t, res in L.inputs("runB"):
    for s in S.get(rec["key"], []):
        for name, mod in (("650062c", L.VT), ("tree", L.V)):
            lead = mod.check_answer({"lead": s, "points": []}, res, mod.Turn.of(t), mode="values").outcomes
            pt = mod.check_answer({"lead": rec["forms"][0]["lead"], "points": [s]}, res, mod.Turn.of(t),
                                  mode="values").outcomes[-1]
            print(f"{rec['key']} {name:8s} lead kept={all(o.kept for o in lead)} {[o.reasons for o in lead]} "
                  f"point kept={pt.kept} {pt.reasons}")
        print("    ", s)
# a turn whose every call was refused: no result holds the export's end
t = L.harness().turn("what did i watch in november")
for name, mod in (("650062c", L.VT), ("tree", L.V)):
    v = mod.check_answer({"lead": "Your export ends on 30 October 2026, so November is not in it.", "points": []},
                         {}, mod.Turn.of(t), mode="values")
    print(f"no result {name}: kept={v.lead_ok} {[o.reasons for o in v.outcomes]}")
