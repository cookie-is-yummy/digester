"""On the 22 probe turns of the merge (mvp26/merge/results_merge.json: today's tools), the whole numbers values mode
counts as found: today (every number of code's strings) against rule "cell_found" (cells only; window figures only
with their unit). Made-up library only."""
import json
import lib27 as L
V = L.V
b = {t["tid"]: t for t in json.load(open(L.S + "/mvp26/merge/results_merge.json"))}
tot_gone = tot_kept = 0
for tid, t in b.items():
    rb = {c["rid"]: c["result"] for c in t["calls"] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
    p = V._Pool(V.Ledger(rb), t["message"])
    allw = {x for x in p.nums if x == int(x) and 0 <= x < 10000}
    cellw = {x for x in p.cell_nums if x == int(x) and 0 <= x < 10000}
    gone = sorted(allw - cellw)
    tot_gone += len(gone); tot_kept += len(cellw & allw)
    print(f"{tid}: found today {len(allw)}, by cells {len(cellw & allw)}; no longer found {len(gone)}: "
          f"{[int(x) for x in gone][:25]}; window units {sorted((int(n), u) for n, u in p.win_units)[:6]}")
print(f"total whole numbers no longer found: {tot_gone}; still found: {tot_kept}")
