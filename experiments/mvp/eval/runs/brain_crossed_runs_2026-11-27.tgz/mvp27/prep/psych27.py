"""Item 2: the motive pattern. Every sentence of the planted and attack sets and of every form of the six live runs
that PSYCH or the old _MOTIVE or the new values pattern hits; which planted cases expect psych and what catches them."""
import json, re, sys
import lib27 as L
V = L.V
rows = []
for r in L.run_planted(L.VT, "values") + L.run_skeptic(L.VT, "values") + L.run_rc(L.VT, "values") + \
        L.run_a2(L.VT, "values") + L.run_check2(L.VT, "values"):
    rows.append((r["set"], r["id"], r["truth"], r.get("class") or r.get("family"), r.get("text") or "", r["reasons"]))
for run in L.RUNS:
    for rec, t, results in L.inputs(run):
        for fi, f in enumerate(rec.get("forms") or []):
            sents = V._split(f.get("lead") or "") + list(f.get("points") or [])
            for k, s in enumerate(sents):
                tr, _lab = L.truth_of(run, rec["key"], fi, "lead" if k < len(V._split(f.get("lead") or "")) else
                                      "point", k if k < len(V._split(f.get("lead") or "")) else
                                      k - len(V._split(f.get("lead") or "")))
                rows.append((run, f"{rec['key']} f{fi} s{k}", tr, None, s, None))
NEW = getattr(V, "_V_MOTIVE", None)
print("== planted/attack cases whose class or reasons say psych, and what catches them (P=PSYCH, M=old _MOTIVE, "
      "N=new values motive)")
for st, i, tr, cls, s, rs in rows:
    if rs is None:
        continue
    low = V.strip_markers(" ".join(s.split())).lower()
    p, m, n = bool(V.PSYCH.search(low)), bool(V._MOTIVE.search(low)), bool(NEW and NEW.search(low))
    if (cls and "psych" in str(cls).lower()) or "psych" in (rs or []) or p or m or n:
        print(f"  {st} {i} truth={tr} class={cls} P={p} M={m} N={n} base_reasons={rs} | {s[:160]}")
print("== live forms (all six runs, every form): sentences the old or new motive pattern or PSYCH hits")
for st, i, tr, cls, s, rs in rows:
    if rs is not None:
        continue
    low = V.strip_markers(" ".join(s.split())).lower()
    p, m, n = bool(V.PSYCH.search(low)), bool(V._MOTIVE.search(low)), bool(NEW and NEW.search(low))
    if p or m or n:
        print(f"  {st} {i} truth={tr} P={p} M={m} N={n} | {s[:200]}")
