# reader1a progress
- step 1: started, read brief
- step 2: facts.py written and run (facts_out.txt); marking next
- step 3: marks written: reader1a/marks.json (154 marks, checks pass), reader1a/best_per_message.txt, source reader1a/marks_src.py
  grades 53 good / 67 acceptable / 34 poor; false_n 2, wrongly_based_n 13 (primary reading)
- rules: no offer at all caps at acceptable; friend's save not said on a count = wrongly based + limits not said
  (N041.1 conversation-aware); export end not said is poor only where it is the core (N067); clumsy-but-true is a note.
- step 4: consistency pass after review: base-under-scope rule applied to x47/eyl/hf7/g8c (wb 1, lenient pass);
  acw gets wb 1 (friend rule); y3q moved from false_n to wrongly_based; zjc to good (materiality rule);
  limits_talk now coded by one rule (build_marks.py). Final: 154 marks, 53 good / 64 acceptable / 37 poor;
  false_n 1, wrongly_based_n 18 (9 friend's-save rule, 4 base-under-scope; lenient reading about 0-2).
  best_worst.txt written. Done; $0 spent.
