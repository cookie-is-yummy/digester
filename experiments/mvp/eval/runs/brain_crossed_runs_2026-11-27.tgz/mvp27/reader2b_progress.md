# reader2b progress
- Read brief, rubric, library. Packet dumped to reader2b/packet_dump.txt.
- Facts script reader2b/facts.py (+lib.py, rows only), output reader2b/facts_out.txt (all 22 keys present).
- Rules fixed before marking: R1-R11, in reader2b/rules.txt and at the top of reader2b/make_marks.py.
- DONE: reader2b/marks.json (154 answers, self-checked by make_marks.py), reader2b/best.txt (one line per message).
- Final grades: good 57, acceptable 72, poor 25. False sentences 6 (6 answers); wrongly based 3 (3 answers).
- Poors that hang on one rule: R1 (N001.0 scope) 7, 6 of them on R1 alone; R10 (N066.0 export end not said) 3;
  R2 is note-only (a strict reader would add 4 poors: N042 oms, uwv, jkg, N112 x4k).
- No model call, $0.
