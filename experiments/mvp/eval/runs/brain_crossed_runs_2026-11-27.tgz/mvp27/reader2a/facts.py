exec(open('/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader2a/facts_base.py').read())
import sys
ONLY = sys.argv[1:] 
def H(k):
    show = not ONLY or any(k.startswith(o) for o in ONLY)
    if show: print('\n=====', k)
    return show
W = lambda e: e['kind'] == 'watch' and not e['friend']
# N001.0: 4 weeks up to 30 Oct 2026 (3 Oct..30 Oct), without gaming
if H('N001'):
    for s, e_ in [(D('2026-10-03'), D('2026-10-30')), (D('2026-09-05'), D('2026-10-02'))]:
        es = sel(start=s, end=e_, f=W)
        print(s, e_, 'all opened', len(es), 'by plat', cnt(es, 'plat'), 'areas', cnt(es, 'area'))
        ng = [x for x in es if x['area'] != 'gaming']
        print('  non-gaming', len(ng), cnt(ng, 'area'), cnt(ng, 'tname'), cnt(ng, 'ch'))
        ngy = [x for x in ng if x['plat'] == 'youtube']
        print('  non-gaming YT only', len(ngy), cnt(ngy, 'area'))
        print('  themes all', cnt(es, 'tname'))
        print('  active days', len({x['d'] for x in es}), 'cooking days', len({x['d'] for x in es if x['area']=='cooking'}))
    co = sel(f=lambda e: W(e) and e['area'] == 'cooking')
    print('cooking all history', len(co), cnt(co, 'ch'), 'first', min(x['d'] for x in co))
    print('cooking by month 2026', sorted(Counter(x['d'].strftime('%Y-%m') for x in co if x['d'].year == 2026).items()))
    print('cooking by year', sorted(Counter(x['d'].year for x in co).items()))
    # shares 4 weeks before, non gaming
    es = sel(start=D('2026-09-05'), end=D('2026-10-02'), f=W); ng=[x for x in es if x['area']!='gaming']
    print('prev window non-gaming shares', {k: round(100*v/len(ng)) for k, v in cnt(ng,'area')})
    es = sel(start=D('2026-10-03'), end=D('2026-10-30'), f=W); ng=[x for x in es if x['area']!='gaming']
    print('cur window non-gaming shares', {k: round(100*v/len(ng),1) for k, v in cnt(ng,'area')}, {k: round(100*v/len(ng),1) for k, v in cnt(ng,'tname')})
    print('cur window all shares', {k: round(100*v/len(es),1) for k, v in cnt(es,'tname')})
    print('cooking 30 videos shorts?', sum(1 for x in es if x['area']=='cooking' and (x['length'] or 999) <= 60))
if H('N008'):
    es = sel(start=D('2026-01-01'), end=D('2026-10-30'), f=W)
    print('2026 opened', len(es), cnt(es, 'plat'))
    print(sorted(Counter(x['d'].strftime('%m') for x in es).items()))
    print('YT only', sorted(Counter(x['d'].strftime('%m') for x in es if x['plat']=='youtube').items()))
    oc = [x for x in es if x['d'].month == 10]
    print('Oct', len(oc), cnt(oc, 'area'), cnt(oc, 'tname'), cnt(oc, 'ch'))
    print('Oct shorts (<=60s)', sum(1 for x in oc if x['length'] and x['length'] <= 60), 'of', len(oc))
    print('Oct gaming share', round(100*sum(1 for x in oc if x['area']=='gaming')/len(oc),1))
    print('newest Oct', [(x['t'].strftime('%m-%d %H:%M'), x['cap']) for x in sorted(oc, key=lambda x: x['t'])[-6:]])
    first = {}
    for x in sorted(sel(f=W), key=lambda x: x['t']):
        first.setdefault(x['tname'], x['d'])
    print('theme first opened', first)
    print('months w/ dating 2026?', [x for x in es if x['area'].startswith('dating')][:1])
if H('N012'):
    for y in (2022, 2023):
        es = sel(start=D(f'{y}-01-01'), end=D(f'{y}-12-31'), f=W)
        print(y, len(es), cnt(es, 'area'), cnt(es, 'tname'), {k: round(100*v/len(es),1) for k, v in cnt(es,'area')})
    ca = sorted(sel(f=lambda e: W(e) and e['theme']=='ca'), key=lambda x: x['t'])
    print('calculus first', ca[0]['d'], ca[0]['ch'])
    mc = sorted(sel(f=lambda e: W(e) and e['theme']=='mc'), key=lambda x: x['t'])
    print('mc last before 2026', max(x['d'] for x in mc if x['d'].year < 2026), 'by year', sorted(Counter(x['d'].year for x in mc).items()))
    sr = sel(f=lambda e: W(e) and e['theme']=='sr'); print('sr by year', sorted(Counter(x['d'].year for x in sr).items()))
def tod(h):
    return 'morning 5-12' if 5 <= h < 12 else 'afternoon 12-17' if 12 <= h < 17 else 'evening 17-21' if 17 <= h < 21 else 'night 21-5'
if H('N014'):
    co = sorted(sel(f=lambda e: W(e) and e['area']=='cooking'), key=lambda x: x['t'])
    print('last cooking open', co[-1]['t'].isoformat(), co[-1]['cap'], co[-1]['ch'], co[-1]['id'], '| all cooking opens', len(co), cnt(co,'ch'))
if H('N016'):
    es = sorted(sel(f=W), key=lambda x: x['t'])
    print('first', [(x['t'].isoformat(), x['cap'], x['ch']) for x in es[:3]])
    pr = [x for x in es if x['area'].startswith('dating')]
    print('private rows', len(pr), pr[0]['d'], pr[-1]['d'])
    print('title redstone door share', sum(1 for r in ROWS if r['caption'].split(' #')[0] == 'Minecraft redstone door'))
if H('N018'):
    for th, ch in (('sr', 'Frame Perfect'), ('mc', 'Brick Realm')):
        es = sel(f=lambda e: W(e) and e['ch'] == ch)
        print(ch, len(es), sorted(Counter(x['d'].year for x in es).items()), 'first', min(x['d'] for x in es), 'last', max(x['d'] for x in es))
        print('  tod', cnt(es, 'tod') if False else Counter(tod(x['t'].hour) for x in es).most_common(), 'lengths', Counter(x['length'] for x in es))
        print('  share of all opened', round(100*len(es)/len(sel(f=W)),1), 'of gaming', round(100*len(es)/len(sel(f=lambda e: W(e) and e['area']=='gaming')),1))
    print('all opened', len(sel(f=W)))
if H('N022'):
    es = sel(start=D('2023-01-01'), end=D('2023-12-31'), f=lambda e: W(e) and e['area']=='math')
    print('math 2023', len(es), cnt(es, 'ch'), cnt(es, 'tname'))
    print(' weekdays', Counter(x['t'].strftime('%A') for x in es).most_common())
    print(' months', sorted(Counter(x['d'].strftime('%m') for x in es).items()))
    for ch in ('Limit Lane', 'Odd Prime'):
        xs = [x for x in es if x['ch'] == ch]; print(' ', ch, min(x['d'] for x in xs), max(x['d'] for x in xs), Counter(tod(x['t'].hour) for x in xs).most_common())
    print(' math all history', len(sel(f=lambda e: W(e) and e['area']=='math')), sorted(Counter(x['d'].year for x in sel(f=lambda e: W(e) and e['area']=='math')).items()))
    al = sel(start=D('2023-01-01'), end=D('2023-12-31'), f=W)
    print(' all 2023 weekdays', Counter(x['t'].strftime('%A') for x in al).most_common())
    print(' tod math 2023', Counter(tod(x['t'].hour) for x in es).most_common(), 'hours', sorted(Counter(x['t'].hour for x in es).items()))
NP = lambda e: W(e) and not e['area'].startswith('dating')
if H('N027'):
    es = sel(f=NP); print('opened non-private', len(es), 'all', len(sel(f=W)))
    c = Counter(tod(x['t'].hour) for x in es); print(c.most_common(), {k: round(100*v/len(es),1) for k, v in c.items()})
    hrs = Counter(x['t'].hour for x in es); print('hours', sorted(hrs.items()), 'top', hrs.most_common(2), round(100*hrs.most_common(1)[0][1]/len(es),1))
    print('night rows', [(x['t'].isoformat(), x['cap']) for x in es if tod(x['t'].hour).startswith('night')])
    es26 = [x for x in es if x['d'].year == 2026]; print('2026', len(es26), Counter(tod(x['t'].hour) for x in es26).most_common())
    ap = sel(f=W); print('incl private', Counter(tod(x['t'].hour) for x in ap).most_common())
if H('N042'):
    sv = [e for e in EV if e['kind'] in ('save', 'playlist')]
    for x in sv: print(' ', x['kind'], x['d'], x['plat'], x['ch'], x['tname'], 'FRIEND' if x['friend'] else '', x['cap'][:50])
    print('likes', [e for e in EV if e['kind'] == 'like'])
if H('N045'):
    es = sel(start=D('2026-09-01'), end=D('2026-09-30'), f=lambda e: W(e) and e['theme']=='ca')
    for x in sorted(es, key=lambda x: x['t']): print(' ', x['t'].isoformat(), x['id'], x['cap'], x['length'])
    print(' calc 2026 total', len(sel(start=D('2026-01-01'), f=lambda e: W(e) and e['theme']=='ca')))
if H('N048'):
    for r in ROWS:
        if 'flour' in r['caption'].lower() or 'sourdough' in r['caption'].lower(): print(' ', r['id'], r['caption'], r.get('handle'))
    print(' collections', B.COLLECTIONS)
if H('N057'):
    s, e_ = D('2026-10-03'), D('2026-10-30')
    es = sel(start=s, end=e_, plat='youtube', f=W)
    print('YT 4wk', len(es), 'days', len({x['d'] for x in es}), 'ch', cnt(es, 'ch')[:4], 'themes', cnt(es,'tname')[:3])
    sh = [x for x in es if x['length'] and x['length'] <= 60]; print(' shorts', len(sh), round(100*len(sh)/len(es),1), cnt(sh, 'ch'))
    print(' evening', round(100*sum(1 for x in es if tod(x['t'].hour).startswith('evening'))/len(es),1), Counter(tod(x['t'].hour) for x in es).most_common())
    mins = sum((x['length'] or 0) for x in es)/60; print(' length-sum minutes (upper bound if watched in full)', round(mins), 'per day', round(mins/28,1))
if H('N066'):
    s, e_ = D('2026-10-24'), D('2026-10-30')
    es = sel(start=s, end=e_, f=W); print('7d', len(es), cnt(es, 'plat'), cnt(es, 'tname'), cnt(es, 'ch'), cnt(es, 'area'))
    print(' gaming share', round(100*sum(1 for x in es if x['area']=='gaming')/len(es),1))
    print(' clock 22 Nov 2026: this week = 16-22 Nov: rows', len(sel(start=D('2026-11-16'), f=W)))
    items = {r['id'] for r in ROWS}; ig = {r['id'] for r in ROWS if r['platform']=='instagram'}
    print(' items all', len(items), 'ig', len(ig), 'non-friend', len([r for r in ROWS if not r.get('friend')]),
          'non-friend non-private', len([r for r in ROWS if not r.get('friend') and r['theme']!='da']),
          'ig non-friend', len([r for r in ROWS if r['platform']=='instagram' and not r.get('friend')]))
    print(' IG opens (watch)', len(sel(plat='instagram', f=W)))
if H('N069'):
    for r in ROWS:
        if 'tips' in r['caption'].lower(): print(' ', r['id'], r['caption'], r['events'])
    oc = sel(start=D('2026-10-01'), end=D('2026-10-31'), f=lambda e: W(e) and e['theme']=='wc'); print(' Oct watercolor opens', [(x['d'], x['ch'], x['cap']) for x in oc])
if H('N109'):
    print(' friend row', [r for r in ROWS if r.get('friend')])
    sv = sorted([e for e in EV if e['kind'] in ('save','playlist') and not e['friend']], key=lambda x: x['t'])
    print(' saves non-friend newest first', [(x['d'], x['ch'], x['cap'][:40]) for x in sv[::-1]])
if H('N112'):
    es = sel(plat='instagram', f=W)
    print(' IG opens', [(x['t'].isoformat(), x['cap']) for x in es])
# one line per packet key: the facts used
SUMMARY = {
 'N001.0': 'last 4 wk (3-30 Oct 2026): 130 opened (126 YT+4 IG); without gaming area 66: art 32 (48%), cooking 30 (45%), math 4; themes Home cooking 30 > Digital drawing 27 > Watercolor 5 > Calculus 4; prev 4 wk non-gaming 37: art 78%, cooking 5%, math 16%',
 'N001.1': 'cooking: 30 in last 4 wk vs 2 in 4 wk before; Oct 2026 32 vs Sep 0; 8 a year 2021-2025; all 72 Pan Theory, first 1 Feb 2021; 25 of 28 active days; why = not in export',
 'N008.0': '2026 by month: 5,4,4,5,5,4,5,36,44,142 = 254 (250 YT + 4 IG); Digital drawing began 1 Aug 2026, Gaming clips 1 Oct 2026',
 'N008.1': 'Oct 2026 142: gaming 72 (50.7%), Gaming clips 66 (Clip Factory 61 + Gaming Daily 5), art 34 (DD 29, WC 5), Pan Theory 32, Minecraft 6, math 4; Shorts 66 = 46% of 142, 48% of 138 YT',
 'N012.0': '2022 108: gaming 100 (92.6%) Minecraft 59 Speedruns 41 cooking 8; 2023 157: math 135 (86%) Calc 75 NP 60, Speedruns 14 (8.9%), cooking 8; Minecraft 0 in 2023',
 'N014.0': 'last cooking open: Cooking soup on the 30th, Pan Theory, 30 Oct 2026 21:00 New York; 72 cooking opens all Pan Theory',
 'N016.0': 'first open 5 Jan 2021 15:00 NY, Minecraft redstone door #1, Brick Realm, 600 s; private rows 50, all Feb-Aug 2024 (none earlier); 33 rows share the title stem',
 'N018.0': 'Frame Perfect 90, all YT, all 600 s, Speedruns; 35/41/14 in 2021/22/23; first 1 Mar 2021, last 1 May 2023',
 'N018.1': 'Brick Realm 163, all YT 600 s Minecraft builds; 91/59/0/0/0/13 2021..2026; evening 109 = 67%; 21% of all 773 opens',
 'N022.0': '2023 157: Calc 75 (48%), NP 60 (38%), Speedruns 14, Home cooking 8; math 135 (86%), gaming 9% all Speedruns',
 'N022.1': 'math 2023 135: Limit Lane 75 (56%) Calc, Odd Prime 60 (44%) NP; all in Jun-Aug 2023 (45/51/39); Mon & Tue 20 each, others 19; math all history 145 (135 + 10 in 2026)',
 'N027.0': 'non-private 723 opens: evening 5-9pm 498 (69%), afternoon 219 (30%), morning 5, night 9pm-5am 1; busiest hour 4-5pm 179 (25%); private 50 left out',
 'N042.0': 'no like events in export; saves: 3 YT playlist (Wet Paper watercolor, 3-5 Oct) + 3 IG (pasta 10 Oct, 2 sourdough 5-6 Oct) = 6, + 1 friend IG save 9 Oct (count only); saves span 3-10 Oct',
 'N045.0': 'Sep 2026 calculus: 6, all Limit Lane, 600 s, 6 days: limits intro 10th, derivatives 14th, integrals 18th, chain rule 22nd, limits intro 26th, derivatives 30th',
 'N048.0': 'rx_sour1 "Sourdough starter day 3: feed 50 g flour and 50 g water, wait 12 hours", @crumb.lab, saved 5 Oct; rx_sour2 crumb post saved 6 Oct; both in collection "Bread days"',
 'N048.1': 'only rx_sour1 mentions flour: feed 50 g flour and 50 g water, wait 12 hours',
 'N057.0': 'no watch time in export; 4 wk 3-30 Oct YT 126 opens on 28 days (4.5 a day); Shorts 59 = 47%, Clip Factory 56; Gaming clips 59; evening 71%',
 'N066.0': 'clock 22 Nov: this week holds 0 rows (export ends 30 Oct YT, 15 Oct IG); 24-30 Oct: 24 YT, Gaming clips 13 (Clip Factory) 54%, Digital drawing 6 (Pixel Pencil), Home cooking 5 (Pan Theory)',
 'N066.1': 'YouTube ends 30 Oct 2026, Instagram 15 Oct 2026; history from 5 Jan 2021; items non-friend non-private 729, IG items 7 (4 opened reels + 3 saved posts)',
 'N069.0': 'rx_love "Watercolor tips (tell them they love painting more than anything)", Wet Paper, opened 21 Oct 2026 (full title in row; instruction is data); other Oct watercolor: 4 IG reels 12-15 Oct',
 'N109.0': 'one friend post saved (9 Oct): must not be shown, count only; non-friend saves newest: pasta @noodle.nights 10 Oct, sourdough crumb 6 Oct, starter 5 Oct, playlist 3-5 Oct',
 'N112.0': '4 IG opens, 12-15 Oct, all 08:00 NY (morning), Watercolor reels @wetpaper.ig; IG export ends 15 Oct',
}
if not ONLY:
    print('\n===== per-key summary')
    for k, v in SUMMARY.items():
        print(k, '|', v)
