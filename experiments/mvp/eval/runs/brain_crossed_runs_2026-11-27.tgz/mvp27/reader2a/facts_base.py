import sys
sys.path.insert(0, '/home/user/digester/experiments')
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from collections import Counter, defaultdict
from mvp.tests import brain_library as B

NY = ZoneInfo('America/New_York')
AREA = {'mc': 'gaming', 'sr': 'gaming', 'cl': 'gaming', 'wc': 'art', 'dd': 'art', 'ca': 'math', 'np': 'math',
        'co': 'cooking', 'da': 'dating(PRIVATE)'}
THEME = {'mc': 'Minecraft builds', 'sr': 'Speedruns', 'cl': 'Gaming clips', 'wc': 'Watercolor painting',
         'dd': 'Digital drawing', 'ca': 'Calculus lessons', 'np': 'Number puzzles', 'co': 'Home cooking',
         'da': 'Dating advice(PRIVATE)'}
ROWS = B.rows()
EV = []  # one per event
for r in ROWS:
    for k, at in r['events']:
        t = datetime.fromisoformat(at).astimezone(NY)
        EV.append(dict(id=r['id'], kind=k, t=t, d=t.date(), plat=r['platform'], ch=r.get('channel') or r.get('handle'),
                       theme=r['theme'], area=AREA[r['theme']], tname=THEME[r['theme']], cap=r['caption'],
                       length=r['length'], friend=bool(r.get('friend'))))
def sel(kind=None, plat=None, start=None, end=None, f=None):
    out = []
    for e in EV:
        if kind and e['kind'] != kind: continue
        if plat and e['plat'] != plat: continue
        if start and e['d'] < start: continue
        if end and e['d'] > end: continue
        if f and not f(e): continue
        out.append(e)
    return out
def cnt(es, key):
    return Counter(e[key] for e in es).most_common()
def D(s):
    return datetime.fromisoformat(s).date()
