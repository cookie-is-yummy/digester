exec(open('/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader2a/facts_base.py').read())
print(len(ROWS), len(EV), cnt(EV,'kind'), cnt(EV,'plat'))
print(min(e['d'] for e in EV if e['plat']=='youtube'), max(e['d'] for e in EV if e['plat']=='youtube'))
print(min(e['d'] for e in EV if e['plat']=='instagram'), max(e['d'] for e in EV if e['plat']=='instagram'))
