import json, sys
d = json.load(open(sys.argv[1]))
for m in d['messages']:
    print('=========', m['key'], '|', m['message'])
    for t in m['earlier_turns']:
        print('  EARLIER YOU:', t.get('you'))
    for a in m['answers']:
        print('---', a['code'])
        for s in a['earlier_answers_seen']:
            print('   [seen before]:', s.get('answer_sent', '').replace('\n', ' / ')[:700])
        print(a['sent'])
        p = a['parts']
        if p['cards']:
            print('  CARDS:')
            for c in p['cards']:
                print('    *', c)
        if p['limit_lines']:
            print('  LIMIT_LINES:', p['limit_lines'])
        if p['ask_back']:
            print('  ASK_BACK:', p['ask_back'])
