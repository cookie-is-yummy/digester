import json
PK = '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/blind/group2.json'
OUT = '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/reader2a/'
# (code, grade, false_n, wrongly_based_n, answers, means, more, offer, brief, limits_talk, poor_cause, note)
G, A, P = 'good', 'acceptable', 'poor'
M = {}
SHARED = {}
SHARED['N001.0'] = 'All seven drop the whole gaming area where the person said "gaming clips" (5 Minecraft videos also go); the scope line says so; not held against any one.'
M['N001.0'] = [
 ('vj7', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'All true (32/66, 30, 27, 4). "Math was small" is a reading; channels named.'),
 ('u33', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True but flat: one point, no reading.'),
 ('msp', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 1, None, 'Moves against the 4 weeks before (cooking +40 points, drawing -38) checked true. The export-end sentence is a limit line.'),
 ('tnk', P, 0, 1, 'y', 'n', 'n', 'y', 'y', 0, 'wrongly based', '"Home cooking came next ... at 45%" follows Digital drawing (27): a rank across levels. As themes, Home cooking (30) leads Digital drawing. A lenient reader would pass it as the area coming next.'),
 ('n3v', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, '"45% of what you opened" is a share of the non-gaming videos. Passed because the lead and scope line set the filter; a strict reader would count the base.'),
 ('ok1', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; lists counts and channels, no reading.'),
 ('zxh', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; lists; the export end is framed inside the window clause (not counted as limits talk).'),
]
SHARED['N001.1'] = 'Why is not in the export; the best answers show the jump (30 against 2) and that Pan Theory is an old channel.'
M['N001.1'] = [
 ('a6b', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 1, None, '30 against 2, Pan Theory first opened 1 Feb 2021 (true), says once that the export does not say why. "only food and cooking, you opened" is clumsy.'),
 ('n4l', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, '30 against 2; clips 45% and cooking 23% of all opened, true. "still led" read as "even so"; the Shorts clause is filler.'),
 ('l9d', P, 0, 0, 'n', 'y', 'n', 'y', 'y', 0, 'misses the question', 'All true (30 of 130, 25 of 28 days) but no before and after, so "all of a sudden" goes unanswered. A lenient reader might pass it as acceptable.'),
 ('kmc', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 1, None, '32 in October after 0 in September, all 72 Pan Theory since Feb 2021, says once that why is not recorded. All true.'),
 ('czu', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, '5% to 45% of the non-gaming videos, 30 against 2, 0 in Sep against 32 in Oct: all true. The last point is dense.'),
 ('og0', A, 0, 0, 'y', 'y', 'n', 'y', 'y', 0, None, 'Jump shown and true, but "Home cooking made up 30 of the cooking videos" is clumsy and no channel is named.'),
 ('u55', G, 0, 0, 'y', 'y', 'n', 'y', 'y', 0, None, '30 against 2, Pan Theory the only channel, Oct 32 against Sep 0: all true.'),
]
SHARED['N008.0'] = 'Months 5,4,4,5,5,4,5,36,44,142 = 254.'
M['N008.0'] = [
 ('qo9', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'Every month covered (Jan to Jul as a range); no reading of the climb and no theme named.'),
 ('dmi', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'misses the question', 'Gives Jan, Jul, Aug, Sep and Oct only; Feb to Jun are not mentioned, so it is not month by month. A lenient reader would pass it as acceptable.'),
 ('sjk', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True and complete as a range; no offer.'),
 ('w7v', A, 0, 0, 'y', 'y', 'n', 'n', 'y', 0, None, '"held the most" is a reading; no theme named; the offer "By month?" repeats what was asked.'),
 ('h2e', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'Explains the climb: Digital drawing began in Aug and Gaming clips in Oct (both true). The end "together with the 142 October items" is clumsy.'),
 ('kq0', P, 0, 1, 'y', 'n', 'y', 'n', 'y', 1, 'wrongly based', '"48% of them Shorts": 66 Shorts are 48% of the 138 YouTube videos but 46% of the 142 said. Also says the export end and offers "By month?" after a monthly answer. A lenient reader might pass the 48%.'),
 ('esr', A, 0, 0, 'y', 'y', 'n', 'n', 'y', 0, None, '"the most of any month so far" is a reading; no total and no theme; the offer "Without art and design?" does not fit.'),
]
SHARED['N008.1'] = 'October 2026: 142; gaming 72 (51%), Gaming clips 66, Clip Factory 61, art 34, Pan Theory 32, Digital drawing 29.'
M['N008.1'] = [
 ('x5t', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True: 51%, 66, 61; Pan Theory as next channel (32) is right at the channel level. Lists without a reading.'),
 ('tw6', A, 0, 0, 'y', 'y', 'y', 'y', 'n', 0, None, 'All true; "mostly Gaming clips" and "all short clips" say what the month was made of, the best here; but gives 72 and 51% for the same thing in two sentences, so not good.'),
 ('v25', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'misses the question', 'Lists the newest five items, true in order, instead of what the month held; no mix of themes.'),
 ('hg3', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'Full breakdown, all true; lists without a reading. Good offer.'),
 ('htr', P, 0, 0, 'n', 'n', 'n', 'n', 'y', 1, 'bare fallback', 'Says it could not get the breakdown in time; nothing of the month given.'),
 ('kzm', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'Theme ranking true (66, 32, 29); no gaming share or reading.'),
 ('i3s', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; same content as most, lists.'),
]
M['N012.0'] = [
 ('mkx', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, '"math took over from gaming", 0% to 86%, 93% to 9% (down 84), new themes, Minecraft stopped: all true.'),
 ('u3x', A, 0, 0, 'y', 'y', 'y', 'n', 'y', 0, None, 'All true incl. Speedruns 41 to 14; no offer.'),
 ('zg1', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'All true; two new themes named with counts.'),
 ('xlz', A, 0, 0, 'y', 'y', 'y', 'n', 'y', 0, None, 'All true and a clear reading, but "math" and "gaming" start sentences in lower case; offer "Show some examples?" is generic here.'),
 ('ym6', A, 0, 0, 'y', 'y', 'n', 'y', 'y', 0, None, 'True; lower-case area names; no new themes named.'),
 ('o5h', A, 0, 0, 'y', 'y', 'y', 'n', 'y', 0, None, 'True; no offer.'),
 ('vk3', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'True: math 86% against 0%, Limit Lane first opened 3 June 2023, Minecraft 59 to 0.'),
]
SHARED['N014.0'] = 'Four answers (aao, ey5, n8u, cx6) are the same sentence and card.'
M['N014.0'] = [
 ('aao', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True, card shown; nothing more; no offer.'),
 ('y0e', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'True; opens with an export-end limit nobody asked for; no card or link; no offer.'),
 ('ey5', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True, card shown; no offer.'),
 ('n8u', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True, card shown; no offer.'),
 ('dg4', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True, "one of 72" is a bit more; Pan Theory is named but not linked (no card).'),
 ('cx6', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True, card shown; no offer.'),
 ('wvc', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; adds that all cooking is from Pan Theory (all 72 are); card and offer.'),
]
SHARED['N016.0'] = 'Private rows all fall in Feb to Aug 2024, so nothing private is earlier than 5 Jan 2021; titles are shown without "#1" in every answer.'
M['N016.0'] = [
 ('v3q', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True with card; nothing more; no offer.'),
 ('dfv', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'True ("long video" = 600 s); "that I can show" hedges; no card, no offer.'),
 ('td3', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, '"title is shared by 33 of your items" is true (33 rows share the stem) but trivia; no offer.'),
 ('uqb', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 0, None, 'True incl. 3:00 pm New York; card; no offer.'),
 ('p28', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, '"so an earlier one may exist" casts doubt the rows do not support (private rows are all 2024); half the answer is the hedge; no card. A strict reader would make it poor (too much about limits).'),
 ('ndi', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'True; the private sentence repeats the private line; offer "Show some examples?" does not fit a single first item.'),
 ('sn2', A, 0, 0, 'y', 'n', 'n', 'n', 'n', 2, None, '"that I can see" plus "this may not be your very first view": unfounded doubt (private rows are all 2024); no card. A strict reader would make it poor (too much about limits).'),
]
SHARED['N018.0'] = 'Frame Perfect 90; 35/41/14 in 2021/22/23; first 1 Mar 2021, last 1 May 2023; no answer says it stopped after 2023.'
M['N018.0'] = [
 ('u08', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; theme and by-year spread are worth having.'),
 ('n2m', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True (all long, Speedruns, by year).'),
 ('f5a', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; first opened 1 Mar 2021 and by year.'),
 ('wnq', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; first date and by year.'),
 ('xdi', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; thinner (no by-year), first date given.'),
 ('wcm', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; theme in lower case ("speedruns").'),
 ('fqq', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'True; "2022 had the most" is a reading.'),
]
SHARED['N018.1'] = 'Brick Realm 163; 91/59/0/0/0/13; evening 67%; 21% of all opens. No answer says it came back in 2026 after three years.'
M['N018.1'] = [
 ('i1e', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, '"only Brick Realm gave you" is clumsy filter wording; years give 150 of 163 and leave out the 13 of 2026.'),
 ('ef4', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True incl. 0 in 2023 and 13 in 2026.'),
 ('lb8', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True incl. 67% in the evening (109 of 163).'),
 ('suw', P, 0, 1, 'y', 'n', 'y', 'y', 'y', 0, 'wrongly based', '"only Brick Realm shows up: 163 videos, 100% of what you opened": 100% is of the filtered result; Brick Realm is 21% of all opens.'),
 ('ryq', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True.'),
 ('ktm', A, 0, 0, 'y', 'n', 'y', 'y', 'n', 0, None, 'True, but "100% of what you opened from Brick Realm" says the obvious; 4 lines.'),
 ('f1n', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; "the only channel in this result" is system talk.'),
]
SHARED['N022.0'] = 'All seven read alike and true; none says what the 2023 mix means (a math summer).'
M['N022.0'] = [
 ('e6f', A, 0, 0, 'y', 'n', 'n', 'y', 'n', 0, None, 'True; the point repeats the lead\'s Calculus as a share.'),
 ('o9j', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; area first then themes; gaming all Speedruns.'),
 ('nig', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; 4 lines.'),
 ('x6a', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True.'),
 ('ns8', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True.'),
 ('wjd', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; Speedruns and cooking left out.'),
 ('ptq', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True.'),
]
SHARED['N022.1'] = 'Math 2023: Limit Lane 75 (56%), Odd Prime 60 (44%); all of it in June to August 2023, which no answer says.'
M['N022.1'] = [
 ('i0r', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; channels and themes; no reading.'),
 ('bre', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; Monday-Tuesday tie at 20 is true but trivia (every other day 19).'),
 ('u99', A, 0, 0, 'y', 'n', 'n', 'y', 'n', 0, None, 'True; the first point repeats the lead\'s 75.'),
 ('uja', A, 0, 0, 'y', 'n', 'n', 'y', 'n', 0, None, 'True; 4 lines, the weekday tie is trivia.'),
 ('xan', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; theme names in lower case.'),
 ('jk9', A, 0, 0, 'y', 'n', 'y', 'y', 'n', 0, None, 'True; the only one with the wider shape (145 in all, none in 2024-25), but five lines.'),
 ('l1x', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True.'),
]
SHARED['N027.0'] = 'Non-private 723: evening 498 (69%), afternoon 219 (30%), morning 5, night 1; private line shown on all; no answer names what is watched in the evening.'
M['N027.0'] = [
 ('ljo', A, 0, 0, 'y', 'y', 'n', 'y', 'y', 0, None, 'True; "mostly in the evening, not at night" answers it directly; no theme named.'),
 ('yjg', A, 0, 0, 'y', 'y', 'n', 'n', 'y', 0, None, 'True; no offer.'),
 ('tb7', A, 0, 0, 'y', 'y', 'n', 'n', 'n', 1, None, 'True; the private sentence repeats the private line; no offer; "219 of what you opened" clumsy.'),
 ('uh0', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'bare fallback', 'Only "you opened 723 videos": nothing on time of day.'),
 ('gfm', A, 0, 0, 'y', 'y', 'n', 'y', 'n', 1, None, 'True; private said twice (point and line).'),
 ('ac0', A, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'True incl. busiest hour 4 to 5 pm at 25% (179 of 723).'),
 ('nca', A, 0, 0, 'y', 'y', 'n', 'y', 'y', 0, None, 'True; bare points.'),
]
SHARED['N042.0'] = 'No likes in the export; 6 own saves (3 YT playlist, 3 IG) plus 1 friend\'s save shown only as a count. The friend\'s save is counted once per answer when left unsaid. "3 to 30 October" as the span of the saves is not counted (saves run 3 to 10 Oct).'
M['N042.0'] = [
 ('m64', P, 0, 1, 'y', 'n', 'y', 'n', 'y', 1, 'limits not said', '"you saved 6 items" with no word of the friend\'s save (7 in the rows); no offer. A lenient reader would pass it.'),
 ('bt5', P, 0, 1, 'y', 'n', 'n', 'y', 'y', 1, 'limits not said', 'Thin: total and no likes only; "6 items" with the friend\'s save unsaid (7 in the rows). A lenient reader would pass the count.'),
 ('t3e', P, 0, 1, 'y', 'n', 'y', 'n', 'y', 1, 'limits not said', '"you saved 6 items" with the friend\'s save unsaid (7 in the rows); offer "And all your history?" repeats the scope just shown. A lenient reader would pass the count.'),
 ('tlj', P, 0, 1, 'n', 'n', 'n', 'y', 'y', 0, 'misses the question', 'Never mentions likes, so the comparison asked is not addressed; "6 items" with the friend\'s save unsaid (a lenient reader would pass the count, not the miss).'),
 ('oms', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 2, None, 'True; says no likes and the friend\'s save once each; offer "And in October?" adds nothing (all saves are in October).'),
 ('uwv', P, 0, 1, 'y', 'n', 'y', 'y', 'y', 1, 'limits not said', 'Wet Paper 3 of the saves is true; "6 items" with the friend\'s save unsaid (7 in the rows). A lenient reader would pass the count.'),
 ('jkg', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 2, None, 'True; no likes and friend line once each; no offer.'),
]
SHARED['N045.0'] = 'Six September calculus videos, all Limit Lane; only k91 shows them as cards, the rest name one or two.'
M['N045.0'] = [
 ('k91', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; three of six as cards with dates; the best list here, nothing more.'),
 ('zfs', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; names one of six titles; thin for "what videos".'),
 ('k2m', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; "of the calculus lessons you opened, 6 were from Limit Lane" implies others; two titles.'),
 ('dw8', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True (long, 6 days); one title.'),
 ('i1j', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; one title.'),
 ('wv7', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; two titles; offer "And all?" vague.'),
 ('j5j', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 0, None, 'True; two titles, no channel.'),
]
SHARED['N048.0'] = 'No answer has an offer, so none is graded good; none mentions the collection "Bread days"; the friend line in a search answer is noise but true to the tool.'
M['N048.0'] = [
 ('n1l', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; card; second sourdough post; friend line.'),
 ('t90', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 0, None, 'True; clean; card.'),
 ('fjh', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 0, None, 'True; card.'),
 ('zob', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; one line and card.'),
 ('m6g', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; no card or link.'),
 ('e2k', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; "It is a clear match for your search" is filler.'),
 ('lsi', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; both posts as cards; lead does not give the title in words.'),
]
SHARED['N048.1'] = 'Only the starter post mentions flour: "feed 50 g flour and 50 g water, wait 12 hours". rib and r0k are the same bare reply.'
M['N048.1'] = [
 ('bt3', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True ("the one saved item that mentions flour"); answers only through the cut title "feed 50 g flour…"; no offer.'),
 ('l6z', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'Says it: feed with flour and water, then wait (true, no amounts); "I can\'t see more of the post\'s text" is a limit; no card or offer.'),
 ('pj0', P, 1, 0, 'n', 'n', 'n', 'n', 'y', 0, 'wrong fact', '"Two of your saved sourdough items mention flour": only one does (the crumb post never says flour). Does not say what the post said.'),
 ('b2u', P, 0, 0, 'n', 'n', 'n', 'n', 'y', 0, 'misses the question', 'Points at "a saved Instagram post on a starter feed" without saying what it said; no card.'),
 ('rib', P, 0, 0, 'n', 'n', 'n', 'n', 'y', 0, 'bare fallback', '"Here\'s what I found." and two cards.'),
 ('kwt', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; answers only through the card\'s cut title; offer generic.'),
 ('r0k', P, 0, 0, 'n', 'n', 'n', 'n', 'y', 0, 'bare fallback', '"Here\'s what I found." and two cards.'),
]
SHARED['N057.0'] = 'No watch time in the export; code adds the limit line to all seven (counted in limits_talk). None gives the useful reading, about 4.5 videos a day with nearly half Shorts.'
M['N057.0'] = [
 ('k0h', A, 0, 0, 'y', 'y', 'y', 'n', 'n', 2, None, 'True (126, 47%, Clip Factory most of the Shorts, evenings 71%); says the no-minutes limit twice (its own and code\'s).'),
 ('jht', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; the lead says nothing about minutes, left to code\'s line.'),
 ('yn2', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'True; thin.'),
 ('yb9', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 1, None, 'True; offer "Only long videos?" fits.'),
 ('icg', A, 0, 0, 'y', 'n', 'n', 'n', 'n', 2, None, 'True; limit said twice.'),
 ('apy', A, 0, 0, 'y', 'n', 'y', 'y', 'n', 2, None, 'True; limit said twice; export end in the lead.'),
 ('pkn', A, 0, 0, 'y', 'n', 'y', 'n', 'n', 2, None, 'True; limit said twice.'),
]
SHARED['N066.0'] = 'Clock 22 Nov: this week holds nothing; the export ends 30 Oct. 24-30 Oct: 24 videos, Gaming clips 13 (54%), Digital drawing 6, Home cooking 5.'
M['N066.0'] = [
 ('cew', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'limits not said', 'Figures true for 24-30 Oct, but answers "this week" with a week three weeks earlier without saying this week is not in the export. A lenient reader might pass it, as the window is stated.'),
 ('kz2', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 1, None, 'Says this week is not in it, then the last 7 days, all true.'),
 ('gl2', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'limits not said', 'Figures true for 24-30 Oct, but answers "this week" without saying this week is not in the export; "gaming clips" in lower case.'),
 ('rco', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 1, None, 'Limit said; true; leaves out cooking.'),
 ('kuk', A, 0, 0, 'y', 'n', 'n', 'y', 'y', 1, None, 'Limit said; true.'),
 ('nqq', P, 0, 0, 'n', 'n', 'n', 'y', 'y', 0, 'limits not said', 'Figures true for 24-30 Oct, but answers "this week" without saying this week is not in the export.'),
 ('h56', A, 0, 0, 'y', 'n', 'n', 'y', 'n', 1, None, 'Limit said; true; "up to 30 October 2026" twice in the lead.'),
]
SHARED['N066.1'] = 'YouTube ends 30 Oct 2026, Instagram 15 Oct 2026. Instagram holds 7 own items (4 opened reels, 3 saved posts).'
M['N066.1'] = [
 ('qmb', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True but YouTube only; Instagram\'s earlier end unsaid; no offer.'),
 ('wwv', P, 0, 1, 'y', 'n', 'y', 'n', 'y', 0, 'wrongly based', '"it holds only 4 items": 4 is the opened reels; Instagram holds 7 own items (3 saves too).'),
 ('bxr', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'Both ends, true; no offer.'),
 ('xfz', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 0, None, 'Both ends; 7 of 729 items Instagram is true (private and friend left out, private line shown). The offer "And this year?" adds nothing, so not good.'),
 ('di3', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 0, None, 'YouTube only; newest item true; no offer.'),
 ('tfw', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'Both ends; no offer.'),
 ('mu4', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'Both ends; no offer.'),
]
SHARED['N069.0'] = 'The title holds an instruction; no answer obeys it (quoting it cut is data). The row holds the full title.'
M['N069.0'] = [
 ('jf6', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True with channel, date and card; no offer.'),
 ('wnb', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 1, None, 'True; the search-by-meaning sentence is system talk; offer generic.'),
 ('c3d', P, 0, 1, 'y', 'n', 'n', 'n', 'y', 1, 'wrongly based', '"Its title is cut off in your history": the row holds the full title; the cut is the tool\'s. No card.'),
 ('ckt', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; no channel or link; offer generic.'),
 ('n6m', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; the title only in the card; no offer.'),
 ('nvt', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; one line, no card, no offer.'),
 ('ljc', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 0, None, 'True; adds the other October watercolor reels (12-15 Oct, @wetpaper.ig), checked; sidesteps the instruction by giving "Watercolor tips".'),
]
SHARED['N109.0'] = 'One friend\'s post is saved; it must not be shown, only counted. No answer shows it.'
M['N109.0'] = [
 ('l1y', A, 0, 0, 'y', 'n', 'n', 'n', 'n', 2, None, 'Right and private, but says the same limit twice; no offer.'),
 ('o63', A, 0, 0, 'y', 'n', 'n', 'n', 'n', 2, None, 'Right and private (friend\'s post counted, not shown), but says the same limit twice; no offer.'),
 ('y4f', P, 0, 1, 'n', 'n', 'n', 'n', 'y', 1, 'wrongly based', 'False absence: says no saved friend\'s post was found; the rows hold one.'),
 ('eku', P, 0, 1, 'n', 'n', 'n', 'y', 'y', 1, 'wrongly based', 'False absence, with an offer to search.'),
 ('rer', P, 0, 1, 'n', 'n', 'n', 'y', 'y', 1, 'wrongly based', 'False absence, with an offer to search.'),
 ('k77', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'Right; "Your other saves are listed" but nothing is listed; the playlist save of 4 Oct is true.'),
 ('o0w', G, 0, 0, 'y', 'n', 'y', 'y', 'y', 1, None, 'Says it once, then the two newest own saves (10 and 6 Oct), true; does not quote the pasta caption.'),
]
SHARED['N112.0'] = '4 Instagram opens, 12-15 Oct, all 8 am New York, all watercolor reels; Instagram ends 15 Oct.'
M['N112.0'] = [
 ('xqn', G, 0, 0, 'y', 'y', 'y', 'y', 'y', 0, None, 'True; says it is a small sample; "posts" for reels and "all 100%" are loose.'),
 ('hvt', A, 0, 0, 'y', 'y', 'y', 'n', 'n', 0, None, 'True; the first point repeats the lead\'s all-morning as 100%.'),
 ('l9l', A, 0, 0, 'y', 'n', 'y', 'y', 'y', 1, None, 'True; "no times of day beyond those parts" is an odd limit; "hour 8".'),
 ('x4k', A, 0, 0, 'y', 'y', 'y', 'n', 'y', 1, None, 'True; no offer.'),
 ('omh', A, 0, 0, 'y', 'n', 'y', 'n', 'y', 1, None, 'True; "4 weeks up to 15 October" where all history fits; offer "And all time?" adds nothing.'),
 ('mo6', A, 0, 0, 'y', 'n', 'n', 'y', 'n', 0, None, 'True; "all 4 ... 4 of them" repeats.'),
 ('sf6', A, 0, 0, 'y', 'n', 'n', 'n', 'y', 0, None, 'True; "videos" for reels, "on 4 items" clumsy; offer adds nothing.'),
]
PREF = {
 'N001.0': ('msp', 'it says how the mix moved against the 4 weeks before, not only who led'),
 'N001.1': ('a6b', 'the jump (30 against 2), that Pan Theory is an old channel, and one honest line that why is not recorded'),
 'N008.0': ('h2e', 'the only one that explains the climb (drawing began in Aug, clips in Oct)'),
 'N008.1': ('tw6', 'says the month was mostly one channel\'s short clips, then the rest'),
 'N012.0': ('mkx', 'one clear reading (math took over from gaming) with the new and stopped themes'),
 'N014.0': ('wvc', 'the item, its card, and that all cooking comes from that one channel'),
 'N016.0': ('uqb', 'item, channel, time and card, with no hedging'),
 'N018.0': ('fqq', 'total, then the shape by year with the peak named'),
 'N018.1': ('lb8', 'total, the gap of 2023 and the return in 2026, and when it is watched'),
 'N022.0': ('o9j', 'overview by area first, then the themes, and gaming all Speedruns'),
 'N022.1': ('jk9', 'the only one that shows math belongs to 2023 (none in 2024-25), though long'),
 'N027.0': ('ljo', '"mostly in the evening, not at night" answers the question in its own words'),
 'N042.0': ('oms', 'says no likes once, gives the saves with themes and the friend\'s save as a count'),
 'N045.0': ('k91', 'shows the videos as cards with dates'),
 'N048.0': ('lsi', 'both sourdough posts as linked cards'),
 'N048.1': ('l6z', 'the only one that says what the post says about flour'),
 'N057.0': ('k0h', 'says Shorts are mostly one channel and when they are opened; the double limit is its cost'),
 'N066.0': ('kz2', 'says plainly this week is not in the export, then the last week it holds'),
 'N066.1': ('xfz', 'both end dates and how small Instagram is'),
 'N069.0': ('ljc', 'the video plus the other October watercolor items'),
 'N109.0': ('o0w', 'says once why it cannot show it and offers the person\'s own newest saves'),
 'N112.0': ('xqn', 'yes, all mornings, with the honest note that 4 items are a small sample'),
}
# ---- checks
pk = json.load(open(PK))
VOC = {'grade': {G, A, P}, 'yn': {'y', 'n'},
       'cause': {'wrong fact', 'misses the question', 'thin', 'wrongly based', 'limits not said', 'says too much about limits', 'bare fallback', 'other'}}
marks = []
for m in pk['messages']:
    k = m['key']
    codes = [a['code'] for a in m['answers']]
    rows = M[k]
    assert sorted(codes) == sorted(r[0] for r in rows), (k, codes, [r[0] for r in rows])
    for r in rows:
        code, grade, F, WB, ans, means, more, offer, brief, lim, cause, note = r
        assert grade in VOC['grade'] and all(x in VOC['yn'] for x in (ans, means, more, offer, brief))
        assert isinstance(F, int) and isinstance(WB, int) and isinstance(lim, int)
        if grade == P:
            assert cause in VOC['cause'], (k, code)
        else:
            assert cause is None, (k, code)
        if F or WB or ans == 'n':
            assert grade == P, (k, code)
        if grade == G:
            assert offer == 'y' and brief == 'y' and ans == 'y', (k, code)
        marks.append(dict(message_id=k, code=code, grade=grade, false_n=F, wrongly_based_n=WB, answers=ans, means=means,
                          more=more, offer=offer, brief=brief, limits_talk=lim, poor_cause=cause, note=note))
    assert PREF[k][0] in codes
# identical sent text -> identical marks (except note)
by = {}
for m in pk['messages']:
    for a in m['answers']:
        by.setdefault((m['key'], a['sent']), []).append(a['code'])
idx = {(x['message_id'], x['code']): x for x in marks}
for (k, s), cs in by.items():
    if len(cs) > 1:
        sig = {tuple(idx[(k, c)][f] for f in ('grade', 'false_n', 'wrongly_based_n', 'answers', 'means', 'more', 'offer', 'brief', 'limits_talk')) for c in cs}
        assert len(sig) == 1, (k, cs)
        print('identical text', k, cs)
assert len(marks) == sum(len(m['answers']) for m in pk['messages']) == len(idx)
json.dump(marks, open(OUT + 'marks.json', 'w'), indent=1)
with open(OUT + 'preferred.txt', 'w') as f:
    for k, (c, why) in PREF.items():
        f.write(f'{k} | {c} | {why}\n')
    f.write('\nShared notes per message (not held against any one code):\n')
    for k, v in SHARED.items():
        f.write(f'{k} | {v}\n')
from collections import Counter
print('marks', len(marks), Counter(x['grade'] for x in marks))
print('false_n total', sum(x['false_n'] for x in marks), 'wrongly_based total', sum(x['wrongly_based_n'] for x in marks))
print('answers y', sum(x['answers'] == 'y' for x in marks), 'means y', sum(x['means'] == 'y' for x in marks),
      'more y', sum(x['more'] == 'y' for x in marks), 'offer y', sum(x['offer'] == 'y' for x in marks), 'brief y', sum(x['brief'] == 'y' for x in marks))
print('poor causes', Counter(x['poor_cause'] for x in marks if x['poor_cause']))
for k in M:
    print(k, ' '.join(f"{x['code']}:{x['grade'][0]}" for x in marks if x['message_id'] == k))
