# reader3b progress
- step 1: read brief, rubric, library. Packet group3: 21 messages, 144 answers.
- step 2: read all 144 answers (readable.txt in reader3b/), noted claims. Next: facts script facts.py.
- step 3: facts.py written and run (facts_out.txt). Key: 719 YT/723 opened, Pan Theory every year (8/yr, 32 in 2026), gaming 2021 126/134, new fall channels Clip Factory, Gaming Daily AND wetpaper.ig (12 Oct), Sat 101, Shorts 66+4 all Oct, long 2026 184, saves 6 own + friend, newest save pasta 10 Oct, cooking newest list, dating 50 Feb1-Aug15 every ISO week, March 2024 1+7 private, long 651.
- Next: write marks.json.
- step 4: advisor consulted; rulings settled (rulings.md). Writing make_marks.py with assertions.
- step 5: marks.json written (144 marks, all assertions pass), most_want.txt written. Grades 35 good / 75 acceptable / 34 poor. 11 false sentences in 9 answers; 10 wrongly based (each with a LENIENT-PASS note). Done except the return.
- step 6 (final): second advisor pass applied. Twins ruled alike (s3w with f7r; eir with eu8/fm3/j87), naming condition dropped, R1 period-total rule written, limits rule set, tags split (LENIENT-PASS on counted only, asserted; STRICT-COUNT on passed). Final: 144 marks, 39 good / 73 acceptable / 32 poor; 11 false sentences in 9 answers; 8 wrongly based. Lenient reading 39/80/25; strict 35/61/48. Files: marks.json, most_want.txt, rulings.md, facts.py, facts_out.txt, make_marks.py. Spend $0.
