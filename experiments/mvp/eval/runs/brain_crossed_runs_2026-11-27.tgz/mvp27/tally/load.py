import json, collections
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27'
KEY=json.load(open(f'{S}/blind/KEY_do_not_open.json'))['codes']
ARMS=['run2','runA','runB','base1','base2','arm1','arm2']
def packets():
    P={}
    for g in (1,2,3):
        d=json.load(open(f'{S}/blind/group{g}.json'))
        for m in d['messages']:
            m['group']=g; P[m['key']]=m
    return P
def marks():
    rows=[]
    for g in (1,2,3):
        for r in 'ab':
            for x in json.load(open(f'{S}/reader{g}{r}/marks.json')):
                x=dict(x); x['group']=g; x['reader']=r; x['arm']=KEY[x['code']]['arm']; rows.append(x)
    return rows
