"""Tally of the six blind readers' marks (mvp27). Reads marks, packets, key and run records. No model call."""
import json, glob, random, statistics, collections, math, sys
sys.path.insert(0, '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp27/tally')
from load import S, KEY, ARMS, packets, marks

OUT = f'{S}/tally'
P = packets()
R = marks()
ARMDIR = json.load(open(f'{S}/blind/KEY_do_not_open.json'))['arms']
BIN = ['answers', 'means', 'more', 'offer', 'brief']
GR = ['good', 'acceptable', 'poor']
GV = {'good': 2, 'acceptable': 1, 'poor': 0}

# ---- settled labels for the 7 false-vs-wrongly-based disputes (recount.py / recount_out.txt) ----
# Both readers call every one of these sentences wrong; the row recount confirms it. The label follows the rubric's
# list of framing faults (window, base, scope, direction, only/all, rank, false absence) = wrongly based; a claim the
# rows contradict outright that is on no such list = false.
SETTLED = {
    ('N007.0', 'aea'): (0, 3, 'a', "window (2026 figures said of 2021) and direction ('stopped' for themes that began later): framing faults on the rubric's list -> wrongly based"),
    ('N056.0', 'nf3'): (0, 1, 'a', "rank: 'the longest videos' over videos known to be long (600 s) while 92 opens are 1,500 s -> wrongly based (a rank fault)"),
    ('N066.1', 'wwv'): (0, 1, 'a', "base: 4 opened reels said as all the Instagram export holds (7 own items) -> wrongly based"),
    ('N069.0', 'c3d'): (1, 0, 'b', "'Its title is cut off in your history': the row holds the full title; a claim about the rows that they contradict, on no framing list -> false"),
    ('N109.0', 'eku'): (0, 1, 'a', "false absence of the friend's saved post: on the rubric's framing list -> wrongly based"),
    ('N109.0', 'rer'): (0, 1, 'a', "false absence -> wrongly based"),
    ('N109.0', 'y4f'): (0, 1, 'a', "false absence -> wrongly based"),
}
NORM = {'misses the question': 'misses the question', 'limits not said': 'limits not said',
        'wrongly based': 'false or wrongly based', 'wrong fact': 'false or wrongly based',
        'bare fallback': 'bare fallback or thin', 'thin': 'bare fallback or thin',
        'says too much about limits': 'too much limits talk'}

# ---- records ----
REC = {}
for arm, d in ARMDIR.items():
    for f in glob.glob(d + '/N*.json'):
        r = json.load(open(f))
        REC[(arm, r['key'])] = r
def rec_info(arm, key):
    r = REC.get((arm, key))
    if r is None:
        return None
    return dict(seconds=r['seconds'], timeout=bool(r.get('error')), lead_source=r.get('lead_source'),
                out_tokens=(r.get('tokens') or {}).get('output_tokens'))

# ---- index marks ----
M = collections.defaultdict(dict)          # (key, arm) -> reader slot -> mark
BYCODE = collections.defaultdict(dict)     # (key, code) -> slot -> mark
for x in R:
    M[(x['message_id'], x['arm'])][x['reader']] = x
    BYCODE[(x['message_id'], x['code'])][x['reader']] = x
KEYS = sorted(P)                            # 65 message keys
CONV = {k: k.split('.')[0] for k in KEYS}
GROUP = {k: P[k]['group'] for k in KEYS}
COMMON = [k for k in KEYS if all((k, a) in M for a in ARMS)]   # 64 (N019.0 out)

def settled_false(key, arm):
    code = M[(key, arm)]['a']['code']
    if (key, code) in SETTLED:
        return SETTLED[(key, code)][0]
    a, b = M[(key, arm)]['a']['false_n'], M[(key, arm)]['b']['false_n']
    assert a == b, (key, arm)
    return a

def val(x, f):
    if f in BIN:
        return 1 if x[f] == 'y' else 0
    if f in GR:
        return 1 if x['grade'] == f else 0
    if f == 'false_n':
        return x['false_n']
    if f == 'wb':
        return x['wrongly_based_n']
    if f == 'wrong':
        return x['false_n'] + x['wrongly_based_n']
    if f == 'limits_talk':
        return x['limits_talk']
    if f == 'gradev':
        return GV[x['grade']]
    raise KeyError(f)

# ================= 1. completeness =================
lines = []
def p(*a):
    lines.append(' '.join(str(x) for x in a))
p('1. COMPLETENESS')
for g in (1, 2, 3):
    pk = {(m['key'], a['code']) for m in json.load(open(f'{S}/blind/group{g}.json'))['messages'] for a in m['answers']}
    for r in 'ab':
        mk = [(x['message_id'], x['code']) for x in R if x['group'] == g and x['reader'] == r]
        c = collections.Counter(mk)
        bad = [x for x in R if x['group'] == g and x['reader'] == r and (
            x['grade'] not in GR or any(x[f] not in 'yn' for f in BIN) or not isinstance(x['false_n'], int)
            or not isinstance(x['wrongly_based_n'], int) or not isinstance(x['limits_talk'], int)
            or (x['grade'] == 'poor') != (x['poor_cause'] is not None))]
        p(f'  reader{g}{r}: {len(mk)} marks for {len(pk)} answers in {len({k for k, _ in pk})} messages; '
          f'missing {len(pk - set(mk))}, extra {len(set(mk) - pk)}, duplicates {sum(v > 1 for v in c.values())}, '
          f'out-of-vocabulary or poor_cause inconsistent {len(bad)}' + (f' {[(b["message_id"], b["code"]) for b in bad]}' if bad else ''))
p(f'  messages 65; answers 452 (N019.0 has 4: base2, arm1, arm2 lost its record); common to all 7 arms: {len(COMMON)} messages')

# ================= 2. agreement =================
def kappa(pairs, cats):
    n = len(pairs)
    if n == 0:
        return None
    po = sum(a == b for a, b in pairs) / n
    ca = collections.Counter(a for a, _ in pairs); cb = collections.Counter(b for _, b in pairs)
    pe = sum(ca[c] * cb[c] for c in cats) / n / n
    return None if pe == 1 else (po - pe) / (1 - pe)
def wkappa(pairs, cats):  # linear weights, ordered cats
    n = len(pairs); k = len(cats); idx = {c: i for i, c in enumerate(cats)}
    w = lambda i, j: 1 - abs(i - j) / (k - 1)
    po = sum(w(idx[a], idx[b]) for a, b in pairs) / n
    ca = collections.Counter(a for a, _ in pairs); cb = collections.Counter(b for _, b in pairs)
    pe = sum(w(idx[a], idx[b]) * ca[a] * cb[b] for a in cats for b in cats) / n / n
    return (po - pe) / (1 - pe)
AGREE = {}
p('\n2. READER AGREEMENT (pairs = the same answer marked by reader a and reader b of its group)')
for scope in ['group1', 'group2', 'group3', 'all']:
    items = [v for (k, c), v in BYCODE.items() if scope == 'all' or GROUP[k] == int(scope[-1])]
    res = {}
    gp = [(v['a']['grade'], v['b']['grade']) for v in items]
    res['grade'] = dict(n=len(gp), exact=sum(a == b for a, b in gp) / len(gp), kappa=kappa(gp, GR),
                        kappa_linear=wkappa(gp, ['poor', 'acceptable', 'good']),
                        table={f'{a}|{b}': sum(1 for x in gp if x == (a, b)) for a in GR for b in GR})
    for f in ['answers', 'means', 'offer', 'more', 'brief']:
        pr = [(v['a'][f], v['b'][f]) for v in items]
        res[f] = dict(n=len(pr), exact=sum(a == b for a, b in pr) / len(pr), kappa=kappa(pr, 'yn'),
                      table={f'{a}{b}': sum(1 for x in pr if x == (a, b)) for a in 'yn' for b in 'yn'})
    for name, fn in [('false>0', lambda x: 'y' if x['false_n'] > 0 else 'n'),
                     ('false+wb>0', lambda x: 'y' if x['false_n'] + x['wrongly_based_n'] > 0 else 'n'),
                     ('wb>0', lambda x: 'y' if x['wrongly_based_n'] > 0 else 'n')]:
        pr = [(fn(v['a']), fn(v['b'])) for v in items]
        res[name] = dict(n=len(pr), exact=sum(a == b for a, b in pr) / len(pr), kappa=kappa(pr, 'yn'),
                         table={f'{a}{b}': sum(1 for x in pr if x == (a, b)) for a in 'yn' for b in 'yn'})
    AGREE[scope] = res
    p(f'  {scope} ({len(items)} answers)')
    for f, r in res.items():
        k = r['kappa']; extra = f", linear-weighted kappa {r['kappa_linear']:.2f}" if f == 'grade' else ''
        p(f"    {f:11s} exact {100 * r['exact']:5.1f}%  kappa {k if k is None else round(k, 2)}{extra}   counts a|b {r['table']}")

# false disputes
p('\n  False-sentence disputes (one reader false_n > 0, the other 0, or counts differ): 7; all are label disputes')
for (k, c), (fs, ws, right, why) in sorted(SETTLED.items()):
    a, b = BYCODE[(k, c)]['a'], BYCODE[(k, c)]['b']
    p(f"    {k} {c} ({KEY[c]['arm']}): reader {GROUP[k]}a false {a['false_n']} wb {a['wrongly_based_n']}; reader {GROUP[k]}b false {b['false_n']} wb {b['wrongly_based_n']}. "
      f"Settled false {fs} wb {ws}: reader {GROUP[k]}{right} has the label right. {why}")

# twins: identical sent text in one message, same reader, different marks
p('\n  Twin texts (same sent text in one message, different arms): marks that differ by the same reader')
tw_n = 0; tw_diff = []
for k in KEYS:
    by = collections.defaultdict(list)
    for a in P[k]['answers']:
        by[a['sent']].append(a['code'])
    for t, cs in by.items():
        if len(cs) < 2:
            continue
        tw_n += 1
        for r in 'ab':
            ms = [BYCODE[(k, c)][r] for c in cs]
            sig = lambda x: (x['grade'], x['answers'], x['means'], x['more'], x['offer'], x['brief'], x['false_n'], x['wrongly_based_n'])
            if len({sig(x) for x in ms}) > 1:
                tw_diff.append((k, r, cs, [sig(x) for x in ms]))
p(f'    {tw_n} twin sets; sets where one reader marked twins differently: {len(tw_diff)}')
for t in tw_diff:
    p(f'      {t[0]} reader {GROUP[t[0]]}{t[1]} codes {t[2]} ({[KEY[c]["arm"] for c in t[2]]}): {t[3]}')

# ================= 3. per-arm tables =================
FIELDS = ['good', 'acceptable', 'poor', 'answers', 'means', 'more', 'offer', 'brief', 'false_n', 'wb', 'wrong', 'limits_talk']
def arm_counts(arm, slot, keys):
    xs = [M[(k, arm)][slot] for k in keys if (k, arm) in M]
    d = {f: sum(val(x, f) for x in xs) for f in FIELDS}
    d['n'] = len(xs)
    d['poor_causes'] = dict(collections.Counter(NORM[x['poor_cause']] for x in xs if x['grade'] == 'poor'))
    d['poor_causes_raw'] = dict(collections.Counter(x['poor_cause'] for x in xs if x['grade'] == 'poor'))
    return d
def settled_false_total(arm, keys):
    return sum(settled_false(k, arm) for k in keys if (k, arm) in M)
TABLE = {}
p('\n3. PER ARM (unblinded). a = readers 1a+2a+3a, b = readers 1b+2b+3b, avg = mean of a and b.')
for keys, label in [(KEYS, 'all messages each arm has (65; 64 for base2, arm1, arm2)'), (COMMON, 'the 64 messages all arms share')]:
    p(f'  -- over {label}')
    p('  ' + f"{'arm':6s} {'rd':3s} {'n':>3s} " + ' '.join(f'{f[:7]:>7s}' for f in FIELDS) + '  settled_false')
    tab = {}
    for arm in ARMS:
        tab[arm] = {}
        for slot in ['a', 'b']:
            tab[arm][slot] = arm_counts(arm, slot, keys)
        tab[arm]['avg'] = {f: (tab[arm]['a'][f] + tab[arm]['b'][f]) / 2 for f in FIELDS + ['n']}
        tab[arm]['settled_false'] = settled_false_total(arm, keys)
        for slot in ['a', 'b', 'avg']:
            d = tab[arm][slot]
            p('  ' + f"{arm:6s} {slot:3s} {d['n']:>3.0f} " + ' '.join(f'{d[f]:>7.1f}' if slot == 'avg' else f'{d[f]:>7d}' for f in FIELDS)
              + (f"  {tab[arm]['settled_false']}" if slot == 'avg' else ''))
    TABLE['all' if keys is KEYS else 'common64'] = tab
p('  poor causes (normalised; over all messages each arm has), reader a | reader b:')
for arm in ARMS:
    p(f"    {arm:6s} a {TABLE['all'][arm]['a']['poor_causes']} | b {TABLE['all'][arm]['b']['poor_causes']}")
p('  per reader (each reader alone, over their group), good/acc/poor and means=y per arm:')
PER_READER = {}
for g in (1, 2, 3):
    for slot in 'ab':
        ks = [k for k in KEYS if GROUP[k] == g]
        row = {}
        for arm in ARMS:
            d = arm_counts(arm, slot, ks)
            row[arm] = d
        PER_READER[f'{g}{slot}'] = row
        p(f'    reader{g}{slot}: ' + '; '.join(f"{arm} {row[arm]['good']}/{row[arm]['acceptable']}/{row[arm]['poor']} m{row[arm]['means']} (n{row[arm]['n']})" for arm in ARMS))

# ================= 4. paired comparisons =================
rng = random.Random(27)
def per_msg(f, A, Bs, slot, keys):
    """d_m = mean over arms in A - mean over arms in Bs, for one reader slot ('a','b') or 'avg'."""
    out = {}
    for k in keys:
        if not all((k, x) in M for x in A + Bs):
            continue
        def mv(arms):
            if slot == 'avg':
                return statistics.mean((val(M[(k, x)]['a'], f) + val(M[(k, x)]['b'], f)) / 2 for x in arms)
            return statistics.mean(val(M[(k, x)][slot], f) for x in arms)
        out[k] = mv(A) - mv(Bs)
    return out
def sign_test(ds):
    pos = sum(d > 0 for d in ds); neg = sum(d < 0 for d in ds); n = pos + neg
    if n == 0:
        return pos, neg, 1.0
    k = min(pos, neg)
    pr = sum(math.comb(n, i) for i in range(0, k + 1)) / 2 ** n
    return pos, neg, min(1.0, 2 * pr)
def boot(dm, B=10000):
    convs = collections.defaultdict(list)
    for k, d in dm.items():
        convs[CONV[k]].append(d)
    cl = list(convs.values()); tot = []
    for _ in range(B):
        s = 0.0
        for _ in range(len(cl)):
            s += sum(rng.choice(cl))
        tot.append(s)
    tot.sort()
    return tot[int(0.025 * B)], tot[int(0.975 * B) - 1]
def flips(f, x, y, slot, keys):
    return sum(1 for k in keys if (k, x) in M and (k, y) in M and val(M[(k, x)][slot], f) != val(M[(k, y)][slot], f))
def excluded(keys, arms):
    """messages where any of the arms timed out or sent a code lead"""
    bad = set()
    for k in keys:
        for a in arms:
            i = rec_info(a, k)
            if i and (i['timeout'] or i['lead_source'] == 'code'):
                bad.add(k)
    return bad
COMP = {}
def compare(name, A, Bs, keys, fields, noise_pairs):
    res = {}
    allarms = A + Bs
    ex = excluded(keys, allarms)
    for sens, ks in [('all', keys), ('no_timeout_or_code_lead', [k for k in keys if k not in ex])]:
        res[sens] = {'n_messages': len([k for k in ks if all((k, x) in M for x in allarms)]), 'excluded': sorted(ex) if sens != 'all' else []}
        for f in fields:
            r = {}
            for slot in ['a', 'b', 'avg']:
                dm = per_msg(f, A, Bs, slot, ks)
                tot = sum(dm.values())
                pos, neg, pv = sign_test(list(dm.values()))
                lo, hi = boot(dm, 4000 if sens != 'all' or slot != 'avg' else 10000)
                r[slot] = dict(diff=round(tot, 2), sign=f'+{pos}/-{neg}', p=round(pv, 3), ci95=(round(lo, 2), round(hi, 2)))
            nz = {}
            for x, y in noise_pairs:
                dm = per_msg(f, [x], [y], 'avg', ks)
                lo, hi = boot(dm, 4000)
                nz[f'{x}-{y}'] = dict(diff=round(sum(dm.values()), 2), ci95=(round(lo, 2), round(hi, 2)),
                                      flips_a=flips(f, x, y, 'a', ks), flips_b=flips(f, x, y, 'b', ks))
            r['noise'] = nz
            res[sens][f] = r
    COMP[name] = res
    return res
CF = ['good', 'poor', 'means', 'more', 'answers', 'offer', 'brief', 'false_n', 'wb', 'wrong', 'limits_talk', 'gradev']
NOISE = [('base1', 'base2'), ('arm1', 'arm2'), ('runA', 'runB')]
p('\n4. PAIRED COMPARISONS. diff = sum over messages of (mean of first arms - mean of second arms); a / b reader slot; avg = both readers averaged.')
p('   sign = messages up / down (ties dropped), p = two-sided sign test; ci95 = bootstrap over conversations (seed 27).')
p('   noise = the same statistic between two runs of one build (avg of readers) and the count of messages whose mark flips (reader a, reader b).')
specs = [
    ('4a values vs cells: (runA+runB)/2 - run2', ['runA', 'runB'], ['run2'], KEYS),
    ('4a values vs cells: runA - run2', ['runA'], ['run2'], KEYS),
    ('4a values vs cells: runB - run2', ['runB'], ['run2'], KEYS),
    ('4b baseline fixes: (base1+base2)/2 - (runA+runB)/2', ['base1', 'base2'], ['runA', 'runB'], COMMON),
    ('4c meaning prompt: (arm1+arm2)/2 - (base1+base2)/2', ['arm1', 'arm2'], ['base1', 'base2'], COMMON),
    ('4c single runs: arm1 - base1', ['arm1'], ['base1'], COMMON),
    ('4c single runs: arm2 - base2', ['arm2'], ['base2'], COMMON),
    ('4c single runs: arm1 - base2', ['arm1'], ['base2'], COMMON),
    ('4c single runs: arm2 - base1', ['arm2'], ['base1'], COMMON),
]
for name, A, Bs, ks in specs:
    res = compare(name, A, Bs, ks, CF, NOISE)
    for sens in ['all', 'no_timeout_or_code_lead']:
        rr = res[sens]
        p(f"  {name}   [{sens}: {rr['n_messages']} messages" + (f", out: {' '.join(rr['excluded'])}" if rr['excluded'] else '') + ']')
        for f in CF:
            r = rr[f]
            nz = '; '.join(f"{k} {v['diff']:+} [{v['ci95'][0]:+},{v['ci95'][1]:+}] flips {v['flips_a']}/{v['flips_b']}" for k, v in r['noise'].items())
            p(f"    {f:11s} a {r['a']['diff']:+6.1f} ({r['a']['sign']} p{r['a']['p']})  b {r['b']['diff']:+6.1f} ({r['b']['sign']} p{r['b']['p']})"
              f"  avg {r['avg']['diff']:+6.2f} ci[{r['avg']['ci95'][0]:+},{r['avg']['ci95'][1]:+}] ({r['avg']['sign']} p{r['avg']['p']})   noise: {nz}")

# per-group view of the meaning prompt's means / good
p('\n  4c per group (each reader alone): (arm1+arm2)/2 - (base1+base2)/2 on means and good, over the shared messages of the group')
PG = {}
for g in (1, 2, 3):
    ks = [k for k in COMMON if GROUP[k] == g]
    for slot in 'ab':
        for f in ['means', 'good', 'poor']:
            dm = per_msg(f, ['arm1', 'arm2'], ['base1', 'base2'], slot, ks)
            PG[f'{g}{slot}:{f}'] = round(sum(dm.values()), 2)
    p(f"    group{g} ({len(ks)} msgs): " + '  '.join(f"reader{g}{s} means {PG[f'{g}{s}:means']:+} good {PG[f'{g}{s}:good']:+} poor {PG[f'{g}{s}:poor']:+}" for s in 'ab'))

# ---- seconds and output tokens (records) ----
p('\n  Seconds and output tokens per message, from the records (paired by message over the 64 shared)')
SEC = {}
for arm in ARMS:
    s = [rec_info(arm, k)['seconds'] for k in COMMON]
    o = [rec_info(arm, k)['out_tokens'] for k in COMMON]
    SEC[arm] = dict(median_s=round(statistics.median(s), 2), mean_out_tokens=round(statistics.mean(o), 1),
                    timeouts=[k for k in COMMON if rec_info(arm, k)['timeout']],
                    code_leads=[k for k in COMMON if rec_info(arm, k)['lead_source'] == 'code'])
    p(f"    {arm:6s} median s {SEC[arm]['median_s']:5.2f}  mean output tokens {SEC[arm]['mean_out_tokens']:7.1f}  timeouts {SEC[arm]['timeouts']}  code leads {SEC[arm]['code_leads']}")
def pair_med(A, Bs, keys, fld='seconds'):
    dm = [statistics.mean(rec_info(a, k)[fld] for a in A) - statistics.mean(rec_info(b, k)[fld] for b in Bs) for k in keys]
    meds = []
    for _ in range(4000):
        smp = [rng.choice(dm) for _ in dm]
        meds.append(statistics.median(smp))
    meds.sort()
    return round(statistics.median(dm), 2), (round(meds[100], 2), round(meds[3899], 2)), sign_test(dm)
SECCMP = {}
for nm, A, Bs in [('arm-base', ['arm1', 'arm2'], ['base1', 'base2']), ('base1-base2', ['base1'], ['base2']), ('arm1-arm2', ['arm1'], ['arm2'])]:
    exk = excluded(COMMON, A + Bs)
    for sens, ks in [('all', COMMON), ('no_timeout_or_code_lead', [k for k in COMMON if k not in exk])]:
        md, ci, st = pair_med(A, Bs, ks)
        mo, cio, sto = pair_med(A, Bs, ks, 'out_tokens')
        medA = statistics.median(statistics.mean(rec_info(a, k)['seconds'] for a in A) for k in ks)
        medB = statistics.median(statistics.mean(rec_info(b, k)['seconds'] for b in Bs) for k in ks)
        SECCMP[f'{nm}:{sens}'] = dict(n=len(ks), median_of_paired_diff_s=md, ci95=ci, sign=f'+{st[0]}/-{st[1]} p{round(st[2], 3)}',
                                      median_first=round(medA, 2), median_second=round(medB, 2),
                                      out_tokens_median_paired_diff=mo, out_tokens_ci95=cio)
        p(f"    {nm:12s} [{sens}, {len(ks)}] median of per-message seconds: {medA:.2f} vs {medB:.2f}; paired median diff {md:+} s ci{ci} sign +{st[0]}/-{st[1]} p{round(st[2], 3)};"
          f" output tokens paired median diff {mo:+} ci{cio}")

# ================= decision rule =================
p('\n  DECISION RULE (written before looking): adopt the meaning prompt if, over the 64 shared messages,')
p('  means=y rises by >= 8 (of 65; 7.9 of 64) over the baseline average on BOTH readers, good does not fall,')
p('  false sentences do not rise, wrongly based rise by <= 2 per 65 answers, median seconds rise by <= 0.5.')
c = COMP['4c meaning prompt: (arm1+arm2)/2 - (base1+base2)/2']['all']
tabc = TABLE['common64']
DEC = {}
DEC['means_a'] = c['means']['a']['diff']; DEC['means_b'] = c['means']['b']['diff']
DEC['means_ok'] = DEC['means_a'] >= 8 * 64 / 65 and DEC['means_b'] >= 8 * 64 / 65
DEC['good_avg'] = c['good']['avg']['diff']; DEC['good_a'] = c['good']['a']['diff']; DEC['good_b'] = c['good']['b']['diff']
DEC['good_ok'] = DEC['good_avg'] >= 0
sf_arm = (tabc['arm1']['settled_false'] + tabc['arm2']['settled_false']) / 2
sf_base = (tabc['base1']['settled_false'] + tabc['base2']['settled_false']) / 2
DEC['false_settled_arm_avg'] = sf_arm; DEC['false_settled_base_avg'] = sf_base; DEC['false_ok'] = sf_arm <= sf_base
DEC['false_a'] = c['false_n']['a']['diff']; DEC['false_b'] = c['false_n']['b']['diff']
DEC['wb_avg_per65'] = round(c['wb']['avg']['diff'] * 65 / 64, 2); DEC['wb_a'] = c['wb']['a']['diff']; DEC['wb_b'] = c['wb']['b']['diff']
DEC['wb_ok'] = DEC['wb_avg_per65'] <= 2
DEC['wrong_avg_per65'] = round(c['wrong']['avg']['diff'] * 65 / 64, 2)
ma = (statistics.median([rec_info('arm1', k)['seconds'] for k in COMMON]) + statistics.median([rec_info('arm2', k)['seconds'] for k in COMMON])) / 2
mb = (statistics.median([rec_info('base1', k)['seconds'] for k in COMMON]) + statistics.median([rec_info('base2', k)['seconds'] for k in COMMON])) / 2
DEC['median_s_arm_avg'] = round(ma, 2); DEC['median_s_base_avg'] = round(mb, 2); DEC['seconds_ok'] = ma - mb <= 0.5
DEC['adopt'] = all(DEC[k] for k in ['means_ok', 'good_ok', 'false_ok', 'wb_ok', 'seconds_ok'])
for k, v in DEC.items():
    p(f'    {k}: {v}')

# ================= 4b target messages =================
TGT = ['N038.0', 'N042.0', 'N113.0', 'N067.0', 'N055.0', 'N109.0', 'N052.0', 'N052.1', 'N054.0', 'N019.0', 'N049.0', 'N056.0']
p('\n  4b target messages: grade a/b (g=good, A=acceptable, p=poor), answers a/b, poor cause (a|b)')
abbr = {'good': 'g', 'acceptable': 'A', 'poor': 'p'}
TG = {}
for k in TGT:
    row = {}
    for arm in ARMS:
        if (k, arm) not in M:
            row[arm] = None; continue
        a, b = M[(k, arm)]['a'], M[(k, arm)]['b']
        row[arm] = dict(grade=(a['grade'], b['grade']), answers=(a['answers'], b['answers']), means=(a['means'], b['means']),
                        cause=(a['poor_cause'], b['poor_cause']), false=settled_false(k, arm), wb=(a['wrongly_based_n'], b['wrongly_based_n']))
    TG[k] = row
    p(f'    {k}: ' + '  '.join(f"{arm} " + (f"{abbr[row[arm]['grade'][0]]}{abbr[row[arm]['grade'][1]]} ans {''.join(row[arm]['answers'])}" if row[arm] else '--') for arm in ARMS))
def tgt_score(arm):
    xs = [(M[(k, arm)]['a'], M[(k, arm)]['b']) for k in TGT if (k, arm) in M]
    return dict(n=len(xs), good=sum((a['grade'] == 'good') + (b['grade'] == 'good') for a, b in xs) / 2,
                poor=sum((a['grade'] == 'poor') + (b['grade'] == 'poor') for a, b in xs) / 2,
                answers=sum((a['answers'] == 'y') + (b['answers'] == 'y') for a, b in xs) / 2)
p('    totals over the targets present (avg of readers): ' + '; '.join(f"{arm} n{tgt_score(arm)['n']} good {tgt_score(arm)['good']} poor {tgt_score(arm)['poor']} answers {tgt_score(arm)['answers']}" for arm in ARMS))
TGT11 = [k for k in TGT if k != 'N019.0']
def tgt11(arm):
    xs = [(M[(k, arm)]['a'], M[(k, arm)]['b']) for k in TGT11]
    return dict(good=sum((a['grade'] == 'good') + (b['grade'] == 'good') for a, b in xs) / 2,
                poor=sum((a['grade'] == 'poor') + (b['grade'] == 'poor') for a, b in xs) / 2,
                answers=sum((a['answers'] == 'y') + (b['answers'] == 'y') for a, b in xs) / 2)
p('    over the 11 targets all arms share: ' + '; '.join(f"{arm} good {tgt11(arm)['good']} poor {tgt11(arm)['poor']} answers {tgt11(arm)['answers']}" for arm in ARMS))

# ================= 4c meaning-prompt target subset (promptdraft targets.txt, 21 messages) =================
T21 = 'N002.0 N017.0 N017.1 N018.1 N022.0 N024.0 N024.1 N029.0 N033.0 N034.0 N034.1 N035.1 N036.0 N041.0 N045.0 N052.0 N054.0 N063.1 N066.0 N001.0 N063.0'.split()
p('\n  4c on the 21 messages the meaning prompt was drafted to move (promptdraft/targets.txt), means=y count, a / b:')
T21R = {}
for arm in ARMS:
    a = sum(val(M[(k, arm)]['a'], 'means') for k in T21); b = sum(val(M[(k, arm)]['b'], 'means') for k in T21)
    ga = sum(val(M[(k, arm)]['a'], 'good') for k in T21); gb = sum(val(M[(k, arm)]['b'], 'good') for k in T21)
    T21R[arm] = dict(means_a=a, means_b=b, good_a=ga, good_b=gb)
    p(f'    {arm:6s} means {a:2d} / {b:2d}   good {ga:2d} / {gb:2d}')
dm = per_msg('means', ['arm1', 'arm2'], ['base1', 'base2'], 'avg', T21)
p(f'    arm avg - base avg on means (both readers averaged): {sum(dm.values()):+.2f}, sign {sign_test(list(dm.values()))}')

# ---- lists for item 5 ----
NEW = ['base1', 'base2', 'arm1', 'arm2']
FALSE_LIST = []
for k in KEYS:
    for arm in NEW:
        if (k, arm) in M and settled_false(k, arm) > 0:
            a, b = M[(k, arm)]['a'], M[(k, arm)]['b']
            ans = [x for x in P[k]['answers'] if x['code'] == a['code']][0]
            FALSE_LIST.append(dict(key=k, arm=arm, code=a['code'], message=P[k]['message'], sent=ans['sent'], note_a=a['note'], note_b=b['note']))
WB_LIST = []
for k in KEYS:
    for arm in NEW:
        if (k, arm) in M:
            a, b = M[(k, arm)]['a'], M[(k, arm)]['b']
            if a['wrongly_based_n'] or b['wrongly_based_n'] or (a['code'] in [c for (_, c) in SETTLED] and SETTLED.get((k, a['code']), (0, 0))[1]):
                WB_LIST.append(dict(key=k, arm=arm, code=a['code'], wb_a=a['wrongly_based_n'], wb_b=b['wrongly_based_n'], note_a=a['note'], note_b=b['note']))
POOR_LIST = []
for k in KEYS:
    for arm in ['arm1', 'arm2']:
        if (k, arm) in M:
            a, b = M[(k, arm)]['a'], M[(k, arm)]['b']
            if 'poor' in (a['grade'], b['grade']):
                i = rec_info(arm, k)
                POOR_LIST.append(dict(key=k, arm=arm, code=a['code'], both=a['grade'] == b['grade'] == 'poor', grades=[a['grade'], b['grade']],
                                      cause_raw=[a['poor_cause'], b['poor_cause']], cause=[NORM.get(a['poor_cause']), NORM.get(b['poor_cause'])],
                                      lead_source=i['lead_source'], timeout=i['timeout'], message=P[k]['message'], note_a=a['note'], note_b=b['note']))
open(f'{OUT}/tally_out.txt', 'w').write('\n'.join(lines) + '\n')
json.dump(dict(agreement=AGREE, settled=[dict(key=k, code=c, arm=KEY[c]['arm'], false=v[0], wb=v[1], right_reader=f'{GROUP[k]}{v[2]}', why=v[3]) for (k, c), v in SETTLED.items()],
               twins=dict(sets=tw_n, differ=[dict(key=t[0], reader=f'{GROUP[t[0]]}{t[1]}', codes=t[2], arms=[KEY[c]['arm'] for c in t[2]], marks=t[3]) for t in tw_diff]),
               per_arm=TABLE, per_reader=PER_READER, comparisons=COMP, per_group_4c=PG, seconds=SEC, seconds_compare=SECCMP,
               decision=DEC, targets_4b=TG, targets_4c_21=T21R, common_messages=COMMON,
               false_sentences_new_runs=FALSE_LIST, wrongly_based_new_runs=WB_LIST, poor_meaning_prompt=POOR_LIST),
          open(f'{OUT}/tables.json', 'w'), indent=1, default=str)
print('\n'.join(lines))
