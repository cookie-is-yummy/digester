"""Tally: recount the disputed false sentences from the made-up library rows only (no brain tool imported)."""
import sys
from collections import Counter
from datetime import datetime
from zoneinfo import ZoneInfo
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # rows only

NY = ZoneInfo("America/New_York")
TH = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
      "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking", "da": "Dating advice"}
rows = B.rows()
def ev(kind=None, plat=None, friend=False):
    out = []
    for r in rows:
        if r.get("friend") and not friend: continue
        if plat and r["platform"] != plat: continue
        for k, at in r["events"]:
            if kind and k != kind: continue
            d = datetime.fromisoformat(at).astimezone(NY)
            out.append((d, k, r))
    return sorted(out, key=lambda e: e[0])

print("== N007.0 aea: 2021 themes vs 2026 figures (opened, YouTube+IG, private left out for display)")
for y in (2021, 2026):
    c = Counter(TH[r["theme"]] for d, k, r in ev("watch") if d.year == y)
    print(y, dict(c.most_common()))
first = {}
for d, k, r in ev("watch"):
    first.setdefault(TH[r["theme"]], d.date())
print("first open per theme", first)
print("themes in 2021 with no opens 2022-10-30..2026:", )
later = Counter(TH[r["theme"]] for d, k, r in ev("watch") if d.year >= 2022)
c21 = Counter(TH[r["theme"]] for d, k, r in ev("watch") if d.year == 2021)
print("  ", [t for t in c21 if later[t] == 0])

print("== N056.0 nf3: longest videos opened")
L = sorted({(r["length"], r["id"], r["caption"][:40]) for d, k, r in ev("watch") if r["length"]}, reverse=True)
print(" top lengths", Counter(l for l, _, _ in L).most_common(5))
soup = [x for x in L if x[2].startswith("Cooking soup on the 30th")]
print(" soup", soup)

print("== N066.1 wwv: Instagram items")
ig = [r for r in rows if r["platform"] == "instagram"]
print(" own IG items", sum(1 for r in ig if not r.get("friend")), "friend", sum(1 for r in ig if r.get("friend")))
print(" kinds", Counter(k for r in ig if not r.get("friend") for k, _ in r["events"]))
print(" IG last event", max(ev(plat="instagram", friend=True))[0].date())

print("== N069.0 c3d: watercolor tips title in the row")
for r in rows:
    if "Watercolor tips" in r["caption"]: print(" ", r["id"], repr(r["caption"]), r["events"])

print("== N109.0: a friend's saved post")
for r in rows:
    if r.get("friend"): print(" ", r["id"], r["handle"], r["events"])
