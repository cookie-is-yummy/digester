# tools agent progress
Worktree: S/mvp22/tools_tree, branch brain-toolfix-local from experiments/search-loop (1163b7b).
Evidence: S/mvp22/tools/
## Steps
- [ ] read code and evidence
- [x] read code and evidence; repro dump S/mvp22/tools/repro_before.json (from S/mvp22/tools/test_repro.py)
Findings so far:
- F1: dating theme (id 8) is sensitive:true with no name/category in the theme build; canon leaves it out, so
  facts.theme=-1 and area=-1 for the 50 Heart Notes items; unlocked turn counts them in totals and channels only.
- F2: names._themes/_area_words skip sensitive; "dating advice" -> no_match even when unlock=relationships.
- F3: run_items day kind keeps time order (oldest first), meta.order = a.order.
- F4: Scope.totals.shorts is YouTube only; scope_mask length=short takes reels.
- F5: compare autumn: a = 1 Sep-30 Oct 2026 (clipped), b = 1 Sep-30 Nov 2025.
- F6: find no_match row has no cell.
- F7: libview Item.creator for IG is "@handle" even when owner_name exists (Item drops owner_name).
- F8: facts sheet hidden.friends = view.friends (whole library). Friend items are dropped from the view with events.
  eval_claims.py:3340 checks hid["friends"] == lib.friends (will flag after the fix).
- F9: insight.SHOW periods cap 24 (first 24 kept); breakdown has no offset (top goes to 25).
- Freeze tests: test_brain_fix (attack ledgers) and test_brain_step1_fix (audit ledgers) compare frozen planted
  ledgers to today's tools; any change of a result will fail them.
- [x] baselines on 1163b7b: S/mvp22/tools/plans_before.{txt,json} (exit 1: recount_not_true B05,C13,G06, pre-existing),
  planted_before.txt (332/332, 78/78), brain_tests_before.txt (243 passed)
- [x] test_brain_toolfix.py written: 20 failed / 9 passed before any fix (toolfix_before.txt)
- [x] fixes in facts.py (hide_sensitive branch only), libview.py (new attributes), brain/names.py, tools.py, results.py
- [x] wip commit on brain-toolfix-local; new tests 29 passed
- [ ] run all brain tests; freeze-test diff (do NOT re-freeze planted json); plans after; verifier replay of new cells
- [x] brain tests 272 passed (243 + 29 new); planted unchanged (diff of planted_before/after empty)
- [x] freeze tests pin today's difference from the frozen ledgers: eval/brain_toolfix_ledger_diff.json (62 ledgers, 365 entries)
- [x] auditor (eval_claims.py) taught: reels, friends in window, topic ref, unlocked rows, items_with_words
- [ ] verifier replay of new cells; non-brain tests touching facts/libview; plans after; repro_after diff; final commit
- [x] verifier replay: S/mvp22/tools/verify_replay.json (test_verify_replay.py). Needs verifier learning: topic word
  'relationships' dropped as sensitive on an unlocked turn; totals.reels dropped as platform_word.
- [x] words-count leak closed: find/unresolved with items_with_words carry meta.hidden constant (sensitive 1)
- [x] non-brain related files: 663 passed (nonbrain_tests.txt); brain tests 273 passed; planted unchanged
- [x] plans before/after: plans_before.json / plans_after.json (I02 lead code_form -> template; shape finding F11 gone;
  plan_findings 5 -> 4; numbers 8721 -> 8905, recounted 8698 -> 8882)
- [ ] final advisor check, report
- [x] FINAL on 76d83ba: brain tests 274 passed; planted unchanged; plans_final.json (same diff as plans_after);
  test_brain_toolfix.py on base 1163b7b: 22 failed, 9 passed (toolfix_on_base.txt; the 9 are guards)
- [x] unlocked rows renamed "the topic you asked about" (topic word in `topic`): insight's sensitive check refused
  'relationships' through a row; with the label, true sentences are kept (verify_replay.json)
- report: returned in the final answer
