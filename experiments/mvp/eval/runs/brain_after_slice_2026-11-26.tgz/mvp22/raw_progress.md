# raw progress (read-only recounter)

Files under mvp22/raw/: lib.py (copy of mvp20/recount/lib.py pointed at the main checkout, plus ev2 shorts filter),
rc.py (helpers), jcore.py (judgment store), j1.py (look 1 judgments), assemble.py (joins forms, verdicts, judgments
into sentences.json), dump.py and look1_dump.txt (readable dump).

Look 1: 137 first-form sentences, 64 repair-form sentences, 53 records, 79 forms.

Rules fixed:
- shares: said equals recount rounded half up.
- rank words hold at the level the sentence names; a tie for "biggest/top" without "tied" is wrongly based (framing).
- an unnamed "before" in a sentence where the call compared the 4 weeks before is true.
- Shorts = YouTube of known length <= 60 s; Instagram reels apart.
- borderline sentences carry a lenient reading in "borderline"; truth is the strict one.
- denominator: all sentences with a claim (true, false, wrongly based, cannot prove); also reported without cannot prove.

Done: A01.0 to B05.0 in j1.py. Next: B07.0 onward (look1_dump.txt line 311).

Update: look 1 fully judged (201 of 201; j1.py; overrides at the end of j1.py). Private rule fixed: primary truth on
the product base (private topic out unless the turn unlocked it); strict reading in "borderline".
Look 1 first forms: 137 = 126 true, 7 wrongly based, 1 false, 1 cannot prove, 2 no claim.
Cross-check vs mvp20/recount claims_out: agree on F05 p2, F11 p0, I02 p0; C04 p1 differs (model form vs code lead).
Next: answers.json (founder reading of each first form), then look 2 (mvp20/fix/heldout_run).

Correction to the rules above: "truth" is my best reading as a person; "borderline" holds the other reading, marked
"strict:" (would be wrongly based) or "lenient:" (would be true). Rates are given three ways (primary, strict, lenient).

DONE (all files under mvp22/raw/):
- sentences.json: 387 rows (look1 201: 137 first + 64 repair; look2 186: 139 first + 47 repair), every one judged,
  with recount checks, verifier verdict, repeat_of_first for repair rows.
- answers.json: 106 readings (53 first forms per look).
- numbers.txt: the rates, 2x2 tables, fault lists, borderlines, reason classes of true sentences dropped.
- j1.py, j2.py: the executable recount (python3 assemble.py look1 look2 rebuilds sentences.json; then rerun the
  repeat_of_first step in the tally.py, which is recorded in numbers.txt's generator above).
Not done: nothing outstanding. No git change, no model call.
