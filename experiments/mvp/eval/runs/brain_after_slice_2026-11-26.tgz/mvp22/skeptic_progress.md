# skeptic progress (read only; no git change, no model call)
Evidence: S/mvp22/skeptic/. Verdict and must-change list: skeptic/verdict.txt.
- [x] read brief, paper_progress, comparison.txt, speed.txt, frame.py, c5sim.py, taxonomy.py
- [x] harness common.py (paper's verify_c1 + frame.py, no paper script run); repro.py: 387/387 equal c5_all.json (C1a, C1d)
- [x] 1 sample: sample25.json (seed 22) + 23 wrongly based -> sample_judge.py -> sample_judged.txt
- [x] 2 scen.py (12 real tool scenarios), myrc.py (own recount), cases.py (48 F + 20 T), run_cases.py -> cases_out.json,
      final.py -> cases_final.txt/json; keep_test.py -> keep_test.json (cost of keeping exact codes)
- [x] 3 worked examples recounted (myrc) and read
- [x] 4 speed/cost recomputed from records (prices fitted exactly)
- [x] 5 probe proposal + gate in verdict.txt
- [x] advisor final; exact_on_cases.py (exact codes on own set, I02.0 detail); firm split in final.py; verdict: does not hold as specified
- DONE: returned in StructuredOutput
Note: keep_test base gives attack false out 51 vs paper's 50 (private-line handling of a kept form differs); looks equal.
