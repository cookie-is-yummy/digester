# paper progress (key: paper; read only for the repo; no model call)

S = /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad. Evidence: S/mvp22/paper/.
The table: S/mvp22/paper/comparison.txt.

## Steps (all done)
- [x] replay.py: today's verify.py (main checkout) on every form of both looks, against the recorded results, and on
  the planted attack and audit cases -> outcomes.json. Look 2 differs from its recorded verdicts in 5 rows, all from
  fix 3 and fix 5, which were made after that run.
- [x] make_c1.py -> src/verify_c1.py: a copy of verify.py with an OFF set and an INSIGHT switch (rules switched off at
  the source, not sorted afterwards). The copy with nothing off equals today's checker row for row (387 of 387 held-out
  rows, 290 of 290 planted rows).
- [x] taxonomy.py: cell, policy, framing and doubtful codes, written before any C1 count.
- [x] sim.py -> sim.json (C0 and C1a to C1d); tally.py -> tally.txt.
- [x] frame.py: C5's closed rules, written and tuned on LOOK 1 ONLY (two passes), frozen (frame.sha256) before the run
  on look 2, the attack and the audit. c5sim.py, c5tally.py -> c5_all.json, c5tally_all.txt; c2tally.py -> C2.
- [x] setb.py -> setb.json: the 8 sent-false answers rebuilt with today's answer.build under C0, C1a, C1d.
- [x] speed.py -> speed.txt: seconds and sizes from the records (estimates).

## What is simulated and what is judged
- Simulated by code: C0 (as run and today), C1 (four settings), C5's M bound and C2's M bound on all four sets,
  repairs due, first-pass lead kept, speed from recorded request times.
- Judged: the H bound of C2 and C5 (the record states what the text means; it uses the recounter's fault labels for
  sets a and b and a class map for the attack); whether C1's frame line makes a sent fault harmless (all faults of a
  and b, and every 4th of the 89 attack sentences C1a lets out: 23); C3 and C4 throughout; own lead after one repair.
- Not fresh: today's checker on sets a, b and c is in sample (the fix passes were written from these sentences).
  frame.py is in sample on look 1 and out of sample on look 2, the attack and the audit. Look 2 is not fresh either
  (read by the fix pass), but frame.py was not written from it.

## Results (numbers in comparison.txt)
1. Cells hold. On look 1, switching every framing rule off (C1) cuts true sentences lost from 54 to 18-27 of 126 and
   lets 5 of 8 faults out. The frame line makes none of them harmless (each sentence's own words contradict or go
   past the line), and only 1 of 23 sampled attack sentences.
2. Three of the 8 sent-false sentences exist only because a code lead replaced the model's lead (B03.0's code
   template, C04.0's 'came next', E04.0's 'That is 8 fewer'). Under any candidate that keeps the model's lead more
   often, and never re-reads model points under a code lead, they do not arise.
3. The I02 pair are tool faults (find and the themes list cannot see the unlocked topic). No framing design fixes
   them; the tools branch does.
4. C5 M sent 0 of 9 look 2 faults (code only; the I02 lead aside), but by layer that is thin: cell and policy checks
   drop 6 of the 9; frame.py catches I01.0 for the reason it was written (time words in a point), B14.0 p0 by a sum
   rule written with B14's pattern known (in sample, although frame.py's header says look 1 only), and F15.0 by
   accident ('most recent' read as a rank; its fault is scope). B05.0 and K03.0 repeat look 1 faults (same messages).
   It loses 27-31 of 128 true sentences, 10-15 to its own time and base rules: sentences where the model wrote a window
   or base itself, which C5 tells it not to. C2's word list alone lets I01.0 out.
5. On the attack, C5 M lets 50-65 of 166 out; 10 are corrected by the frame slot; 30 are scope, base, platform and
   period words the look 1 rules never listed (broadening words, 'of your long videos', 'Instagram reels', 'on every
   day of the week', a lead with no comma such as "Since 2021 you opened 134 videos."). Read by hand under compliance
   (the model writes no frame words, the record is honest), 8 to 9 stay out: dates and weekdays ('a Sunday', 'watched it
   the same day'), the verb of the base, 'usually', a find total, R03. The M-to-H gap is the open question: will the
   model leave the frame to code. Only a live run says.
5b. Today's private 'all' check, added to C5, costs 4 true sentences on look 1 and 2 on look 2 (4 of them borderline)
   and catches no fault on either look or the attack: left off, the private line always printed instead.
6. The true sentences C5 still loses are mostly marker bookkeeping, not framing: unmarked names, titles trimmed of
   '#n', "all on YouTube[cell]" after a word, limits lines. They cap own lead near 75-87%.
7. 33 of 45 (look 1) and 34 of 46 (look 2) model leads already contain code's window words; 27 and 28 open with
   them. Code writing the window changes little in how a lead reads.
8. The poor answers are planning faults (B05, B11, F14, F15, F11, F08 in answers.json). No candidate gets credit for
   them.

## Candidates against the founder's rules, cost and failure
- C1: brief text, but code prints a frame line under every answer, which breaks "scope is said only when the result was
  filtered" and "be brief". It sends framing faults by design. Build: half a day. Fails on any framing fault, unbounded.
- C2: the model words all; record checked exactly; word list refuses contradictions. Needs code to compare the
  model's window and base words with the record: the English matching that did not converge. Build: 3 to 4 days.
  Fails when the record is copied from meta (then it is C1 for window and base).
- C3: claims are true by construction if the renderer is right, but about 130 of 137 sentences become code's words,
  own lead about 13%, and B03.0 shows code wording can itself be false. Code-lead answers read 0 of 17 good; nothing
  here shows rendered claims would read better. Build: 5 days or more (renderers for compound claims).
- C4: one more small-model request after the answer (about +1.6 s, median about 8.9 s), about +0.05 to 0.08 cents.
  It cannot be measured here. To measure: its false-pass and false-drop rates on these 387 + 226 + 61 labelled
  sentences, its run-to-run agreement on the same sentence, its time, and its behaviour on titles that carry
  instructions. It is a model judging a model; nothing proves it.
- C5 (below): the model words the sentence; code writes the frame; a small record for rank, list and move is checked
  against the rows; a closed list refuses framing words without a record. Build: 3 to 4 days (record, checks,
  renderer for the frame slot, prompt), and about 2,000 lines of framing rules can go.

## Recommendation: C5, "the model words it, code frames it"
It does not meet its own gate on paper. Own lead is about 75-83% (M) to 79-87% (H) against 85%; true sentences lost
are 21-31% against 15%. The cause is marker bookkeeping, not framing: of the leads C5 drops on first pass, 15 of 17
(look 1) and 9 of 15 (look 2) fail a cell, marker or policy check (unmarked names, titles trimmed of '#n', a marker
after a word, limits lines). Closing that gap is unmeasured. Under rule 5 below, about 9 to 13 of 53 answers (17-25%)
would go out as a bare code lead (first-pass lead failures 12-17, of which a repair rescued about a quarter in the
records), and code-lead answers read 0 of 17 good: this is the largest reading risk.
It is still the pick because it is the only candidate that keeps the model's wording and sends none of the six
non-tool sent-false sentences, and because its rules refuse words rather than try to understand them.
Not yet in frame.py and not tested here (to be written and frozen before the live run): scope and broadening words
('overall', 'in total', 'with or without', 'of any length', 'on every day'), the wider base phrase ('of your <word>
videos'), platform and length words on a count, the verb of the base, 'only', 'all', 'every' with no complete list,
rank words with no rank record, and leads with no comma (the time rule now skips text before the first comma and
checks nothing in a lead without one). The drafted form has no window, base or scope field by design: the bound H
here means "the model writes no frame words", not "the record states the frame".
Each sentence: the model's text with cell markers as today, plus a small record. Code:
1. writes the frame: the lead's window at its opening (the model leaves it out), the base after a share of a scoped
   result or of a list inside a row or period, the scope words, the private line, and the window of a point on
   another result;
2. checks the record against the rows exactly: rank (place, tie, the list it ranks, a least list must be complete,
   the level is named when the sentence before ranked another level), list (complete means every row), 'the other N'
   (sums to the total), 'new' (rows of a new list), private (an 'all' word on a result with private items left out);
3. refuses, from a closed list, window, base and scope words in the model's text, and 'still', 'ever', 'all-time',
   'no longer', rank words with no rank record, 'only', 'all', 'every', 'the rest' with no complete list;
4. keeps today's cell, marker, name, calculation and policy checks;
5. on a failed lead: one repair; if it fails again, code's lead goes out alone, with no model point under it.

### Draft give_answer form (JSON schema; field descriptions only, not a prompt)
{"type": "object", "additionalProperties": false, "required": ["lead"],
 "properties": {
  "understood": {"type": "string"},
  "lead": {"$ref": "#/$defs/sentence", "description": "1 or 2 sentences; no window words: code opens with them"},
  "points": {"type": "array", "maxItems": 3, "items": {"$ref": "#/$defs/sentence"}},
  "items": "as today", "chart": "as today", "outside": "as today", "ask_back": "as today", "offers": "as today",
  "setup": "as today", "corrects_previous": "as today", "hand_back": "as today"},
 "$defs": {
  "sentence": {"type": "object", "additionalProperties": false, "required": ["text", "kind"],
   "properties": {
    "text": {"type": "string", "maxLength": 220, "description": "the sentence with cell markers"},
    "kind": {"enum": ["count", "share", "rank", "move", "first_last", "list", "none"]},
    "rows": {"type": "array", "items": {"type": "string", "pattern": "^r\\d+\\.[A-Za-z_.\\[\\]0-9]+$"},
             "description": "the rows it ranks, lists or moves"},
    "order": {"enum": ["most", "least"], "description": "rank only"},
    "place": {"type": "integer", "minimum": 1, "description": "rank only: 1 first, 2 second"},
    "after": {"type": "string", "description": "rank only: the row it comes after, cited earlier in the answer"},
    "complete": {"enum": ["all", "top", "some"], "description": "list only"},
    "against": {"enum": ["previous", "period"], "description": "move only"},
    "own_frame": {"type": "boolean", "default": false,
                  "description": "true: a cell of another window than the lead's; code prints that window"}}}}}
Size: about 25 to 40 more output tokens a sentence (about +0.3 to 0.8 s); the prompt grows by the field list and the
closed word list (estimate +600 to +900 tokens, cached). Requests stay 2 to 3; repairs should fall to about a third.

### Three worked examples (look 1 messages; hand-written: no renderer ran)
1. F05.0 "am i addicted to gaming clips" (r1 breakdown, all history, only gaming; r2 timeline by year).
   Model: lead {"text": "Gaming clips[r1.themes[2]] are 66[r1.themes[2].items] of the 319[r1.totals.items], and
   100%[r1.themes[2].shorts_share] of them were Shorts.", "kind": "count", "rows": ["r1.themes[2]"]} (code renders the
   base noun of a total cell: "319 gaming videos you opened");
   point 3 {"text": "Minecraft builds[r1.themes[0]] is still the largest gaming theme, at 51%[r1.themes[0].share] of
   what you opened.", "kind": "rank", "rows": ["r1.themes[0]"], "order": "most", "place": 1}.
   Code: rank place 1 and no tie: ok. 'still' and 'of what you opened' on a scoped share: refused; repair asks for the
   sentence without them. Repaired: "Minecraft builds[r1.themes[0]] is the largest gaming theme, at
   51%[r1.themes[0].share]." Sent: "In all your history (5 January 2021 to 30 October 2026): Gaming clips
   are 66 of the 319 gaming videos you opened, and 100% of them were Shorts. / Clip Factory supplies 61 of them, first
   opened on 1 October 2026. / In 2026, gaming clips were 84% of your 79 gaming videos, with 0 in 2024 and 0 in 2025. /
   Minecraft builds is the largest gaming theme, at 51% of the gaming videos you opened." As run, a code lead ("you
   opened 319 videos (only gaming)") went out with the false point.
2. F11.0 "was october my biggest month ever" (r2 months of 2026, r3 years). Lead {"text": "In October 2026 you opened
   142[r2.periods[9].items] videos, against 44[r2.periods[8].items] in September 2026 and 36[r2.periods[7].items] in
   August 2026.", "kind": "count", "own_frame": true}: period labels beside their cells, kept. Point {"text": "Your full
   years before 2026 were 134[r3.periods[0].items] in 2021, 108[r3.periods[1].items] in 2022 and 157[r3.periods[2].items]
   in 2023.", "kind": "list", "rows": [the three], "complete": "all"}: r3 has 2024 and 2025 before 2026: refused
   (list_incomplete); repair: list every row or say 'the top'. Sent: the model's own lead plus a complete or 'top' list,
   with the private line (2024 leaves the private topic out). As run, a code lead went out with the incomplete list.
   Not fixed by C5: the answer still does not say "biggest of all months"; the monthly result caps at 24 periods
   (tool fault F9). That is planning and tools.
3. B03.0 "only the long ones" (r1 breakdown, lately, long only). Lead {"text": "food and cooking[r1.areas[0]] led with
   30[r1.areas[0].items] of 67[r1.totals.items] videos.", "kind": "rank", "rows": ["r1.areas[0]"], "order": "most",
   "place": 1}: first and no tie (30 against 28): kept. Point {"text": "Art and design[r1.areas[1]] came next with
   28[r1.areas[1].items] videos, 42%[r1.areas[1].share].", "kind": "rank", "place": 2, "after": "r1.areas[0]"}: kept.
   Sent: "In the 4 weeks up to 30 October 2026, long videos only: food and cooking led with 30 of 67 videos. / Art and
   design came next with 28 videos, 42% of the long videos. / Gaming had 5 videos and math had 4." As run, today's
   checker dropped the true lead and code's template sent the false "Home cooking led what you opened, with 30 long
   videos".

### The 8 sent false sentences under C5
B03.0 code lead: does not arise (model lead kept). C04.0 'came next': refused by the level rule (it follows a theme
point; cost: the sentence is borderline true under the model's own lead). F05.0: refused ('still', base phrase).
F11.0: refused (list incomplete). I02.0 point (look 1): a tool fault; C5 M drops it only by accident; the fix is in
the tools. E04.0 'That is 8 fewer': does not arise (model lead kept, and no model point under a code lead). I02.0
lead (look 2): a tool fault; dropped by today's 'limits' self-talk rule if kept on. I01.0 'not opened in 2024':
refused (time words on a library cell, M); H: the record says library, code compares.

### Ten true sentences today's checker dropped (look 1 as run), under C5
Back: A01.0 p0 "Gaming clips was the top theme with 59 videos, mostly from Clip Factory with 56"; A01.5 p0 "Pixel Pencil
came next with 29 videos"; B03.0 lead and B03.0 p0 (above); C04.0 lead "On Sundays, ... gaming led ... at 45%" (the
opening is code's slot); F05.0 lead "Gaming clips are 66 of the 319 gaming videos you opened"; F11.0 lead (period
labels); I01.0 lead "In 2024, you opened 8 videos ..." with the private line (borderline: lost if the private 'all'
check stays on). Still lost: A01.0 p1 "Art came next at 25%" (level rule: after a theme sentence it must say
'among areas'); D07.0 lead "... all on YouTube[cell]" (a marker after a word: marker grammar, not framing).

### The gate for the live run (fresh half B, run once, checker frozen and hashed before it)
- 0 false or wrongly based sentences sent, by an independent hand recount of every sent sentence; tool faults count.
- Raw rate of the model's own sentences (recount of every first form) reported beside it, with the frame-word
  compliance: frame words the model wrote in points, at most 5% of sentences.
- Own lead (model words, code frame) at least 85% after one repair; model sentences missing after one repair at most
  15%; a code lead never carries a model point.
- Reading: good plus acceptable at least as high as look 1's first forms (43 of 53), and the share that says what the
  numbers mean reported.
- Speed: median at most 8 s and p90 at most 11 s (the 6 s bar needs fewer requests, not a checker).
- The planted line holds; the attack replayed on the frozen rules: 0 out in every class a record field or the frozen
  word list covers; the rest reported by class (diagnostic).

## Not done
- The code-lead path (fallback) was not rebuilt for set b under each candidate; setb.py shows only whether the model's
  lead is kept.
- The H bound is an assumption; C3 and C4 were not simulated; repair forms were not re-run under new repair messages
  (the recorded repairs answer today's messages).
- Look 2 is the same 53 messages as look 1, so it is not an independent sample of messages.

## What the paper test cannot tell
- Whether the small model leaves window, base and scope words to code, and fills the record honestly (the M to H
  gap: on the attack, 50-65 against 6-7 sentences out).
- How code's frame slot reads inside the model's sentence, and whether answers read better or worse to the founder.
- New phrasings: frame.py's list was written from 8 look 1 faults; the attack shows classes it misses.
- Speed and cost of the larger form; repair behaviour under new repair messages.
- Anything about fresh messages: only a live run on half B can say.

## Open questions for the founder
- May code write the frame (window, base, scope, private) inside the model's sentence? (DECISIONS asks this.)
- Is 8 s median acceptable, since no checker change brings 2 to 3 requests under 6 s?
- When the lead fails twice, is code's lead alone (no model points) acceptable, given 0 of 17 such answers read good?

No git change, no model call, no key read. The repo's verify.py is untouched; the copy is in paper/src/.
