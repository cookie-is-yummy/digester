"""Rebuild: python3 assemble.py look1 look2 && python3 tally.py > numbers.txt"""
import json
import re
from collections import Counter

strip = lambda t: re.sub(r'\[[^\[\]]*(?:\[[^\]]*\][^\[\]]*)*\]', '', t or '').strip()  # noqa: E731
rows = json.load(open('sentences.json'))
first_txt = {(r['look'], r['key'], strip(r['text'])) for r in rows if r['form'] == 'first'}
for r in rows:
    r['repeat_of_first'] = r['form'] == 'repair' and (r['look'], r['key'], strip(r['text'])) in first_txt
json.dump(rows, open('sentences.json', 'w'), indent=1, default=str)
BAD = ('false', 'wrongly_based')
strict = lambda r: 'wrongly_based' if r['truth'] == 'true' and (r.get('borderline') or '').startswith('strict') else r['truth']  # noqa: E731
lenient = lambda r: 'true' if r['truth'] in BAD and (r.get('borderline') or '').startswith('lenient') else r['truth']  # noqa: E731
CAT = {}
for k in ('filter_dropped insight_rewrite shorts_left_out bound_global window_missing base_missing wrong_window no_base base').split():
    CAT[k] = 'scope or window said elsewhere in the answer'
for k in ('uncited_name uncited_number uncited_claim typed_name bad_marker free_number bad_ref unknown_name two_results garbled calc wrong_value').split():
    CAT[k] = 'marker bookkeeping'
for k in ('previous own_shorts_share unnamed_owner not_top rank spread least no_direction direction_unbound tie share_of_topic first_last not_stopped scope_broadened length_word').split():
    CAT[k] = 'word rule (rank, mostly, direction, tie)'
CAT.update(wrong_name='title or name match', private_total='private total', outside_in_history='outside_in_history',
           limits='limits', filler='filler', too_long='too long')


def table(R, label):
    claims = [r for r in R if r['truth'] != 'no_claim']
    bad = [r for r in claims if r['truth'] in BAD]
    fc = Counter(r['fault_class'] for r in bad)
    T = Counter((r['truth'] in BAD, r['verifier_kept']) for r in claims if r['truth'] != 'cannot_prove')
    cp = Counter(r['verifier_kept'] for r in claims if r['truth'] == 'cannot_prove')
    nn = Counter(r['verifier_kept'] for r in R if r['truth'] == 'no_claim')
    ns, nl = sum(strict(r) in BAD for r in claims), sum(lenient(r) in BAD for r in claims)
    nc = len(claims)
    print(f"{label}: {len(R)} sentences {dict(Counter(r['truth'] for r in R))}; recounted by rows {sum(1 for r in R if r['recounted_by_rows'])}, not {sum(1 for r in R if not r['recounted_by_rows'])}")
    print(f"   raw false rate {len(bad)}/{nc} = {100*len(bad)/nc:.1f}%  [lenient {nl}/{nc} = {100*nl/nc:.1f}%, strict {ns}/{nc} = {100*ns/nc:.1f}%]"
          f"; false {sum(r['truth']=='false' for r in bad)}, wrongly based {sum(r['truth']=='wrongly_based' for r in bad)}; cell {fc['cell']}, framing {fc['framing']}")
    print(f"   verifier x truth: true kept {T[(False,True)]}, true dropped {T[(False,False)]}, false kept {T[(True,True)]}, false dropped {T[(True,False)]}"
          f"; cannot-prove kept/dropped {cp[True]}/{cp[False]}; no-claim kept/dropped {nn[True]}/{nn[False]}")
    pb = [r for r in claims if r['private_base']]
    print(f"   rest on a private-out base: {len(pb)}, of them with no private line on the form: {sum(1 for r in pb if not r['private_line_on_form'])}")
    td = [r for r in claims if r['truth'] == 'true' and r['verifier_kept'] is False]
    cats = Counter(x for r in td for x in {CAT.get(y, y) for y in r['verifier_reasons']})
    print(f"   true dropped {len(td)} by reason class (a sentence can carry several): {cats.most_common()}")


for look in ('look1', 'look2'):
    for form in ('first', 'repair'):
        R = [r for r in rows if r['look'] == look and r['form'] == form]
        table(R, f"{look} {form}")
        if form == 'repair':
            table([r for r in R if not r['repeat_of_first']], f"{look} repair, new text only")
print('\n== false or wrongly based ==')
for r in rows:
    if r['truth'] in BAD:
        print(f"{r['look']} {r['key']} {r['form']}{'(repeat)' if r['repeat_of_first'] else ''} {r['where']}{r['index']} | {r['truth']} {r['fault_class']} | kept={r['verifier_kept']} {r['verifier_reasons']} | {strip(r['text'])}\n     fault: {r['fault']}")
print('\n== borderline ==')
for r in rows:
    if r.get('borderline'):
        print(f"{r['look']} {r['key']} {r['form']} {r['where']}{r['index']} {r['truth']} kept={r['verifier_kept']} | {r['borderline']}")
print('\n== not recounted by rows ==')
for r in rows:
    if not r['recounted_by_rows']:
        print(f"{r['look']} {r['key']} {r['form']} {r['where']}{r['index']} {r['truth']} | {strip(r['text'])}")
ans = json.load(open('answers.json'))
for look in ('look1', 'look2'):
    A = [a for a in ans if a['look'] == look]
    print(f"\nreadings {look}: {dict(Counter(a['reading'] for a in A))}; says what numbers mean {sum(a['says_what_numbers_mean'] for a in A)}/{len(A)}; "
          f"offer {sum(a['carries_offer'] for a in A)}/{len(A)}; answers the question {sum(a['answers_question'] for a in A)}/{len(A)}")
