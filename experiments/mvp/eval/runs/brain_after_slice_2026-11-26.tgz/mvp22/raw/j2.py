"""Look 2 judgments (mvp20/fix/heldout_run). Reuses look 1's recount helpers; own store."""
import jcore
import j1 as P1  # noqa: F401  (loads look 1 into its own dict first)
from j1 import (L, P, O, NG, G, LG, NM, SU, Y, SR, WC, GCs, CO, CA, MC, y22, y24, y25, p25, o30, maxopen, stopped_y,
                ca_long, wp_oct, day_of, PRIV)
from rc import n, c, s, rank, ranks, D, ev2
jcore.J = {}
J = jcore.J
j, same = jcore.j, jcore.same
# A
j("A01.0",0,"lead",0,[("top area",'gaming',rank(L,'area')),("share",49,s(L,'area','gaming')),("n",64,c(L,'area','gaming')),("base",130,n(L))])
j("A01.0",0,"point",0,[("GC",59,c(L,'theme','Gaming clips')),("CF",56,c(L,'channel','Clip Factory'))])
j("A01.0",0,"point",1,[("2nd theme",'Home cooking',rank(L,'theme',1)),("HC",30,c(L,'theme','Home cooking'))])
j("A01.1",0,"lead",0,[("top theme",'Gaming clips',rank(L,'theme')),("n",59,c(L,'theme','Gaming clips')),("base",130,n(L))])
j("A01.1",0,"point",0,[("2nd",'Home cooking',rank(L,'theme',1)),("n",30,c(L,'theme','Home cooking')),("before",2,c(P,'theme','Home cooking'))])
j("A01.1",0,"point",1,[("now",21,s(L,'theme','Digital drawing')),("before",57,s(P,'theme','Digital drawing'))])
j("A01.3",0,"lead",0,[("top",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
j("A01.3",0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("PT",32,c(O,'channel','Pan Theory')),("PP",29,c(O,'channel','Pixel Pencil'))])
j("A01.3",0,"point",1,[("BR",6,c(O,'channel','Brick Realm')),("GD",5,c(O,'channel','Gaming Daily'))])
j("A01.4",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**NG)),("n",32,c(O,'channel','Pan Theory',**NG)),("base",70,n(O,**NG))])
j("A01.4",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**NG)),("n",29,c(O,'channel','Pixel Pencil',**NG))])
j("A01.5",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**LG)),("n",32,c(O,'channel','Pan Theory',**LG)),("base",66,n(O,**LG))])
j("A01.5",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**LG)),("n",29,c(O,'channel','Pixel Pencil',**LG))])
j("A01.5",0,"point",1,[("channels in the filtered window",4,len(ranks(O,'channel',**LG)))])
j("A03.0",0,"lead",0,[("top theme",'Gaming clips',rank(L,'theme')),("n",59,c(L,'theme','Gaming clips')),("base",130,n(L))])
j("A03.0",0,"point",0,[("2nd",'Home cooking',rank(L,'theme',1)),("n",30,c(L,'theme','Home cooking'))])
j("A03.0",0,"point",1,[("DD",27,c(L,'theme','Digital drawing'))])
j("A05.0",0,"lead",0,[("top",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
j("A05.0",0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("n",32,c(O,'channel','Pan Theory'))])
j("A05.0",0,"point",1,[("3rd",'Pixel Pencil',rank(O,'channel',2)),("n",29,c(O,'channel','Pixel Pencil'))])
j("A06.0",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**NG)),("n",32,c(O,'channel','Pan Theory',**NG)),("base",70,n(O,**NG))])
j("A06.0",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**NG)),("n",29,c(O,'channel','Pixel Pencil',**NG))])
j("A06.0",0,"point",1,[("art w/o gaming",49,s(O,'area','art and design',**NG))])
OL = dict(length="long")
j("A07.0",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**OL)),("n",32,c(O,'channel','Pan Theory',**OL)),("base",72,n(O,**OL))])
j("A07.0",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**OL)),("n",29,c(O,'channel','Pixel Pencil',**OL))])
j("A07.0",0,"point",1,[("3rd",'Brick Realm',rank(O,'channel',2,**OL)),("n",6,c(O,'channel','Brick Realm',**OL))])
# B
j("B01.0",0,"lead",0,[("top",'gaming',rank(L,'area')),("n",64,c(L,'area','gaming')),("base",130,n(L))])
j("B01.0",0,"point",0,[("GC",59,c(L,'theme','Gaming clips')),("CF",56,c(L,'channel','Clip Factory'))])
j("B01.0",0,"point",1,[("2nd area",'art and design',rank(L,'area',1)),("share",25,s(L,'area','art and design'))])
j("B02.0",0,"lead",0,[("top",'art and design',rank(L,'area',**NG)),("share",48,s(L,'area','art and design',**NG))])
j("B02.0",0,"point",0,[("2nd",'food and cooking',rank(L,'area',1,**NG)),("share",45,s(L,'area','food and cooking',**NG)),("n",30,c(L,'area','food and cooking',**NG))])
j("B02.0",0,"point",1,[("math",4,c(L,'area','math',**NG)),("base",66,n(L,**NG))])
LL_ = dict(length="long")
for f in (0,1):
    j("B03.0",f,"lead",0,[("top",'food and cooking',rank(L,'area',**LL_)),("n",30,c(L,'area','food and cooking',**LL_)),("base",67,n(L,**LL_))])
    j("B03.0",f,"point",0,[("2nd",'art and design',rank(L,'area',1,**LL_)),("n",28,c(L,'area','art and design',**LL_)),("share",42,s(L,'area','art and design',**LL_))])
stopped_l = sorted({x for x,_ in ranks(P,'channel')} - {x for x,_ in ranks(L,'channel')})
drops = sorted(((c(L,'channel',x)-v), x) for x,v in ranks(P,'channel'))
for f in (0,1):
    j("B05.0",f,"lead",0,[("channels stopped",[],stopped_l)])
j("B05.0",0,"point",0,[("PP before",29,c(P,'channel','Pixel Pencil')),("PP now",27,c(L,'channel','Pixel Pencil')),("ctx: drops by count",'PP -2',str(drops[:3]))],
  truth="wrongly_based",fc="framing",fault="rank tie: 'the largest drop in items' is shared with Brick Realm (7 to 5) and Limit Lane (6 to 4)")
j("B05.0",0,"point",1,[("LL before",6,c(P,'channel','Limit Lane')),("LL now",4,c(L,'channel','Limit Lane'))])
j("B05.0",1,"point",0,[("PP before",29,c(P,'channel','Pixel Pencil')),("PP now",27,c(L,'channel','Pixel Pencil'))])
j("B05.0",1,"point",1,[("LL before",6,c(P,'channel','Limit Lane')),("LL now",4,c(L,'channel','Limit Lane'))])
wc_first = sorted(ev2("all",**WC), key=lambda e: e["dt"])[0]
for f in (0,1):
    j("B07.0",f,"lead",0,[("first wc day",'2025-01-10',str(wc_first['day'])),("title",'Watercolor wet on wet',wc_first['title'].split(' #')[0]),("channel",'Wet Paper',wc_first['channel'])])
    j("B07.0",f,"point",0,[("wc all",95,n('all',**WC)),("WP",91,c('all','channel','Wet Paper',**WC))])
l7 = (D(2026,10,24), D(2026,10,30))
j("B11.0",0,"lead",0,[("top",'Clip Factory',rank(l7,'channel')),("n",13,c(l7,'channel','Clip Factory')),("base",24,n(l7))])
j("B11.0",0,"point",0,[("2nd",'Pixel Pencil',rank(l7,'channel',1)),("n",6,c(l7,'channel','Pixel Pencil'))])
j("B11.0",0,"point",1,[("PT",5,c(l7,'channel','Pan Theory'))])
import statistics as _st
for f in (0,1):
    j("B14.0",f,"lead",0,[("shorts",66,n('all',shorts='yt_short')),("opened",723,n('all')),("share of opened",9,100*n('all',shorts='yt_short')/n('all'))],note=PRIV)
    j("B14.0",f,"point",0,[("long",651,n('all',shorts='yt_long')),("median long min",10,_st.median(e['length'] for e in ev2('all',shorts='yt_long'))/60),("ctx: 723 minus 66",657,n('all')-n('all',shorts='yt_short'))],
      truth="wrongly_based",fc="framing",fault="completeness: 'the other 651' are not the rest of the 723: 657 remain (651 long, 4 Instagram reels, 2 of unknown length)",
      borderline="lenient: true (651 long and the 10-minute median are right)")
j("B14.0",0,"point",1,[("all Shorts in Gaming clips",66,n('all',shorts='yt_short',**GCs)),("Shorts channels",['Clip Factory'],[x for x,_ in ranks('all','channel',shorts='yt_short')])],
  truth="wrongly_based",fc="framing",fault="only/all: 'Clip Factory is its channel' while Gaming Daily also holds 5 of the 66 Shorts")
# C
j("C01.0",0,"lead",0,[("least",'Wet Paper',ranks(O,'channel')[-1][0]),("n",1,c(O,'channel','Wet Paper')),("base",142,n(O))])
j("C01.0",0,"point",0,[("LL",4,c(O,'channel','Limit Lane'))])
j("C01.0",0,"point",1,[("GD",5,c(O,'channel','Gaming Daily')),("BR",6,c(O,'channel','Brick Realm'))])
j("C02.0",0,"lead",0,[("top",'gaming',rank(L,'area',**NM)),("n",59,c(L,'area','gaming',**NM)),("base",125,n(L,**NM))])
j("C02.0",0,"point",0,[("art",32,c(L,'area','art and design',**NM))])
j("C02.0",0,"point",1,[("food",30,c(L,'area','food and cooking',**NM))])
j("C04.0",0,"lead",0,[("top",'gaming',rank('all','area',**SU)),("share",45,s('all','area','gaming',**SU))],note=PRIV)
j("C04.0",0,"point",0,[("top theme",'Minecraft builds',rank('all','theme',**SU)),("n",23,c('all','theme','Minecraft builds',**SU)),("BR",23,c('all','channel','Brick Realm',**SU))])
j("C04.0",0,"point",1,[("2nd",'art and design',rank('all','area',1,**SU)),("share",25,s('all','area','art and design',**SU))],
  borderline="strict: wrongly based (rank across levels): 'came next' right after a theme point")
GA = dict(only=[("area","gaming"),("area","art and design")])
j("C06.0",0,"lead",0,[("top",'art and design',rank(Y,'area',**GA)),("n",133,c(Y,'area','art and design',**GA)),("base",212,n(Y,**GA)),("share",63,s(Y,'area','art and design',**GA))])
j("C06.0",0,"point",0,[("gaming",79,c(Y,'area','gaming',**GA)),("share",37,s(Y,'area','gaming',**GA))])
j("C06.0",0,"point",1,[("top theme",'Digital drawing',rank(Y,'theme',**GA)),("DD",92,c(Y,'theme','Digital drawing')),("GC",66,c(Y,'theme','Gaming clips'))])
sr_last = sorted(ev2("all",**SR), key=lambda e: e["dt"])
j("C08.0",0,"lead",0,[("last day",'2023-05-01',str(sr_last[-1]['day'])),("title",'Speedrun glitch explained',sr_last[-1]['title'].split(' #')[0])])
j("C08.0",0,"point",0,[("FP",90,c('all','channel','Frame Perfect',**SR)),("its channel",'Frame Perfect',sr_last[-1]['channel'])])
for f in (0,1):
    j("C09.0",f,"lead",0,[("max opens",1,maxopen)])
    j("C09.0",f,"point",0,[("max opens",1,maxopen)])
# D
for k in ("D01.0","D03.0","A05.0"):
    if k == "A05.0": continue
    j(k,0,"lead",0,[("top",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
    j(k,0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("n",32,c(O,'channel','Pan Theory'))])
    j(k,0,"point",1,[("3rd",'Pixel Pencil',rank(O,'channel',2)),("n",29,c(O,'channel','Pixel Pencil'))])
j("D01.1",0,"lead",0,[("top",'Pixel Pencil',rank('sep','channel')),("n",31,c('sep','channel','Pixel Pencil')),("base",44,n('sep'))])
j("D01.1",0,"point",0,[("2nd",'Brick Realm',rank('sep','channel',1)),("n",7,c('sep','channel','Brick Realm'))])
j("D01.1",0,"point",1,[("LL",6,c('sep','channel','Limit Lane')),("PP share",70,s('sep','channel','Pixel Pencil'))])
j("D03.1",0,"lead",0,[("Oct",142,n(O))])
j("D03.1",0,"point",0,[("day",'2026-10-30',day_of("Cooking soup on the 30th")),("channel",'Pan Theory',next(e['channel'] for e in ev2('all') if e['title']=="Cooking soup on the 30th"))])
j("D03.1",0,"point",1,[("day",'2026-10-29',day_of("Gaming clutch moment #60"))])
j("D03.2",0,"lead",0,[("Oct gaming",72,n(O,**G))],note="'without anything else' is odd wording")
j("D04.0",0,"lead",0,[("share",93,s(y22,'area','gaming')),("n",100,c(y22,'area','gaming')),("base",108,n(y22))])
j("D04.0",0,"point",0,[("top gaming theme",'Minecraft builds',rank(y22,'theme',**G)),("n",59,c(y22,'theme','Minecraft builds')),("all BR",59,c(y22,'channel','Brick Realm'))])
j("D04.0",0,"point",1,[("2nd",'Speedruns',rank(y22,'theme',1)),("n",41,c(y22,'theme','Speedruns')),("FP",41,c(y22,'channel','Frame Perfect'))])
j("D04.0",0,"point",2,[("food",8,c(y22,'area','food and cooking')),("PT",8,c(y22,'channel','Pan Theory'))])
j("D04.1",0,"lead",0,[("Instagram 2022",0,n(y22,platform='instagram',kind=None,unlock=True))])
from collections import Counter as _C
_days = _C(e['day'] for e in ev2('all'))
j("D07.0",0,"lead",0,[("30 Oct",4,len(o30)),("YouTube",4,sum(e['platform']=='youtube' for e in o30))])
j("D07.0",0,"point",0,[("DD",2,c('oct30','theme','Digital drawing')),("PP",2,c('oct30','channel','Pixel Pencil'))])
j("D07.0",0,"point",1,[("median per active day, all history",1,_st.median(_days.values()))],note="median over active days; over calendar days it is 0", borderline="strict: wrongly based (base): over calendar days the median is 0")
for f in (0,1):
    j("D07.1",f,"lead",0,[("second card",'Gaming clip on the 30th',o30[1]['title']),("channel",'Clip Factory',o30[1]['channel'])],
      borderline="strict: wrongly based if 'the second one' means the second point sent, not the second card")
j("D08.0",0,"lead",0,[("cooking 2026",32,n(Y,**CO)),("PT",32,c(Y,'channel','Pan Theory',**CO))])
j("D08.0",0,"point",0,[("HC",32,c(Y,'theme','Home cooking',**CO)),("YouTube",32,n(Y,shorts='yt',**CO))])
j("D08.0",0,"point",1,[("days",26,len({e['day'] for e in ev2(Y,**CO)}))])
j("D08.0",1,"lead",0,[("cooking 2026",32,n(Y,**CO)),("PT",32,c(Y,'channel','Pan Theory',**CO))])
j("D08.0",1,"point",0,[("YouTube",32,n(Y,shorts='yt',**CO))])
j("D08.1",0,"lead",0,[("cooking 2025",8,n(y25,**CO))])
j("D08.1",0,"point",0,[("PT",8,c(y25,'channel','Pan Theory',**CO)),("HC",8,c(y25,'theme','Home cooking',**CO))])
j("D10.0",0,"lead",0,[("top",'gaming',rank(L,'area')),("share",49,s(L,'area','gaming')),("base",130,n(L))])
j("D10.0",0,"point",0,[("2nd",'art and design',rank(L,'area',1)),("share",25,s(L,'area','art and design'))])
j("D10.0",0,"point",1,[("food",23,s(L,'area','food and cooking')),("PT",30,c(L,'channel','Pan Theory'))])
for f in (0,1):
    j("D10.1",f,"lead",0,[("share",49,s(L,'area','gaming'))])
    j("D10.1",f,"point",0,[("GC",59,c(L,'theme','Gaming clips')),("base",130,n(L)),("CF",56,c(L,'channel','Clip Factory'))])
    j("D10.1",f,"point",1,[("GC Shorts share",100,100*n(L,shorts='yt_short',**GCs)/c(L,'theme','Gaming clips'))])
# E, F
for f in (0,1):
    j("E04.0",f,"lead",0,[("fell vs Jan-Oct 2025",['Wet Paper'],sorted(x for x,v in ranks(p25,'channel') if c(Y,'channel',x) < v)),("WP 2026",37,c(Y,'channel','Wet Paper')),("WP 2025",45,c(p25,'channel','Wet Paper'))])
    j("E04.0",f,"point",0,[("diff",8,c(p25,'channel','Wet Paper')-c(Y,'channel','Wet Paper')),("wc 2025",87,s(p25,'theme','Watercolor painting')),("wc 2026",16,s(Y,'theme','Watercolor painting'))])
j("E04.0",0,"point",1,[("PP 2026",92,c(Y,'channel','Pixel Pencil')),("CF 2026",61,c(Y,'channel','Clip Factory')),("new vs 2025",True,{'Pixel Pencil','Clip Factory'} <= set(stopped_y) or not ({'Pixel Pencil','Clip Factory'} & {x for x,_ in ranks(p25,'channel')}))],
  note="'so they add to the total rather than replace Wet Paper' is a reading of the numbers, not a count")
j("F02.0",0,"lead",0,[("30 Oct",4,len(o30)),("YouTube",4,sum(e['platform']=='youtube' for e in o30))])
j("F02.0",0,"point",0,[("DD",2,c('oct30','theme','Digital drawing')),("PP",2,c('oct30','channel','Pixel Pencil'))])
j("F02.0",0,"point",1,[("rest",['Gaming clips','Home cooking'],sorted(x for x,_ in ranks('oct30','theme') if x!='Digital drawing')),("their channels",['Clip Factory','Pan Theory'],sorted(x for x,_ in ranks('oct30','channel') if x!='Pixel Pencil'))])
j("F03.0",0,"lead",0,[("2019 rows",0,n('2019',kind=None,unlock=True))])
for f in (0,1):
    j("F04.0",f,"lead",0,[("last day",'2023-05-01',str(sr_last[-1]['day'])),("title",'Speedrun glitch explained',sr_last[-1]['title'].split(' #')[0])])
    j("F04.0",f,"point",0,[("FP",90,c('all','channel','Frame Perfect',**SR)),("first",'2021-03-01',str(sr_last[0]['day']))])
    j("F04.0",f,"point",1,[("second last",'Any% speedrun route',sr_last[-2]['title'].split(' #')[0]),("its day",'2023-04-22',str(sr_last[-2]['day']))])
gc_all = ev2('all',**GCs)
j("F05.0",0,"lead",0,[("GC",66,len(gc_all)),("all in Oct 2026",66,sum(1 for e in gc_all if (e['day'].year,e['day'].month)==(2026,10))),("ctx: YouTube export span (days)",30,(D(2026,10,30)-D(2021,1,5)).days+1)],
  truth="wrongly_based",fc="framing",fault="window: 'in the 30 days your YouTube export covers' reads as the export covering 30 days; it covers 5 January 2021 to 30 October 2026 (October has 30 days up to the end)",
  borderline="lenient: true if read as 'the 30 days of October the export covers'")
j("F05.0",0,"point",0,[("CF",61,c('all','channel','Clip Factory',**GCs)),("GD",5,c('all','channel','Gaming Daily',**GCs))])
j("F05.0",0,"point",1,[("all Shorts",66,n('all',shorts='yt_short',**GCs)),("days",30,len({e['day'] for e in gc_all}))])
j("F05.0",1,"lead",0,[("GC",66,len(gc_all)),("all in Oct 2026",66,sum(1 for e in gc_all if (e['day'].year,e['day'].month)==(2026,10)))])
j("F05.0",1,"point",0,[("CF",61,c('all','channel','Clip Factory',**GCs))])
j("F05.0",1,"point",1,[("GD",5,c('all','channel','Gaming Daily',**GCs))])
for f in (0,1):
    j("F06.0",f,"lead",0,[("gaming lately",64,n(L,**G)),("before",14,n(P,**G))])
    j("F06.0",f,"point",0,[("GC",59,c(L,'theme','Gaming clips')),("CF",56,c(L,'channel','Clip Factory'))])
    j("F06.0",f,"point",1,[("top gaming theme all",'Minecraft builds',rank('all','theme',**G)),("MC",163,c('all','theme','Minecraft builds')),("all BR",163,c('all','channel','Brick Realm',**MC))])
j("F08.0",0,"lead",0,[("BR any kind",163,len([e for e in ev2('all',kind=None) if e['channel']=='Brick Realm']))])
for f in (0,1):
    j("F09.0",f,"lead",0,[("MC channels YouTube",['Brick Realm'],[x for x,_ in ranks('all','channel',platform='youtube',**MC)]),("BR",163,c('all','channel','Brick Realm',**MC))])
    j("F09.0",f,"point",0,[("channels",1,len(ranks('all','channel',platform='youtube',**MC))),("BR share",100,s('all','channel','Brick Realm',platform='youtube',**MC))])
for f in (0,1):
    j("F10.0",f,"lead",0,[("top",'gaming',rank(L,'area')),("share",49,s(L,'area','gaming'))])
    j("F10.0",f,"point",0,[("top theme",'Gaming clips',rank(L,'theme')),("n",59,c(L,'theme','Gaming clips')),("base",130,n(L))])
    j("F10.0",f,"point",1,[("2nd",'Home cooking',rank(L,'theme',1)),("HC",30,c(L,'theme','Home cooking')),("DD",27,c(L,'theme','Digital drawing'))])
import collections as _co
_m26 = _co.Counter(e['day'].month for e in ev2(Y))
for f in (0,1):
    j("F11.0",f,"lead",0,[("biggest month of 2026",10,_m26.most_common(1)[0][0]),("Oct",142,_m26[10]),("Sep",44,_m26[9])])
j("F11.0",0,"point",0,[("Oct",142,n(O)),("2026",254,n(Y)),("Shorts of Oct YouTube",48,100*n(O,shorts='yt_short')/n(O,shorts='yt')),("ctx: Shorts of all Oct (ctx)",46,100*n(O,shorts='yt_short')/n(O))],
  truth="wrongly_based",fc="framing",fault="base: 48% is of October's YouTube videos (66 of 138); said of October's videos (142, with 4 Instagram reels) it is 46%",
  borderline="lenient: true (a 2-point base slip)")
j("F11.0",0,"point",1,[("2026",254,n(Y)),("2023",157,n((D(2023,1,1),D(2023,12,31))))])
j("F11.0",1,"point",0,[("Oct",142,n(O)),("2026",254,n(Y))])
j("F14.0",0,"lead",0,[("gaming all",319,n('all',**G))],note="true, but the question named the channel Gaming Daily")
j("F14.0",0,"point",0,[("top",'Minecraft builds',rank('all','theme',**G)),("MC",163,c('all','theme','Minecraft builds'))])
j("F14.0",0,"point",1,[("channels named 'daily'",['Gaming Daily'],[x for x,_ in ranks('all','channel',**G) if 'daily' in x.lower()]),("GD",5,c('all','channel','Gaming Daily'))])
for f in (0,1):
    j("F15.0",f,"lead",0,truth="cannot_prove",note="a claim about what the system holds ('no video durations'); the rows do hold lengths (all 83 long calculus videos are 600 s, so no ranking by length is possible anyway)")
j("F15.0",0,"point",0,[("ctx: calculus opened",85,n('all',**CA)),("long calculus",83,len(ca_long)),("most recent long",'Calculus derivatives fast',ca_long[0]['title'].split(' #')[0]),("day",'2026-10-16',str(ca_long[0]['day']))],
  truth="wrongly_based",fc="framing",fault="scope: 'the 83 calculus videos you opened' are the long ones; 85 calculus videos were opened (2 of unknown length)")
j("F15.0",0,"point",1,[("next by recency",['Calculus limits intro','Calculus chain rule'],[e['title'].split(' #')[0] for e in ca_long[1:3]])])
j("F15.0",1,"point",0,[("most recent long",'Calculus derivatives fast',ca_long[0]['title'].split(' #')[0]),("day",'2026-10-16',str(ca_long[0]['day']))])
j("F15.0",1,"point",1,[("next",'Calculus limits intro',ca_long[1]['title'].split(' #')[0]),("day",'2026-10-12',str(ca_long[1]['day']))])
for f in (0,1):
    j("G03.0",f,"lead",0,[("WP Oct",1,len(wp_oct)),("day",'2026-10-21',str(wp_oct[0]['day']))],note="title shortened to 'Watercolor tips' in form 0")
# I, K
saved_co = [e for e in jcore.__dict__.get('_x', [])]
from lib import EVENTS as _EV
_saved = [e for e in _EV if e['kind'] != 'watch' and e['theme_key'] == 'co' and not e['friend']]
for f in (0,1):
    j("I01.0",f,"lead",0,[("2024 shown",8,n(y24)),("food share shown",100,s(y24,'area','food and cooking')),("ctx: 2024 all rows (ctx)",58,n(y24,unlock=True))],
      borderline="strict: wrongly based (only/all): the hidden topic (50) outranks food and cooking; the private line was on the form",note=PRIV)
    j("I01.0",f,"point",0,[("HC",8,c(y24,'theme','Home cooking')),("PT",8,c(y24,'channel','Pan Theory'))])
    j("I01.0",f,"point",1,[("saved cooking not opened",3,len(_saved)),("ctx: their save dates",'2024',str(sorted(str(e['day']) for e in _saved)))],
      truth="wrongly_based",fc="framing",fault="window: the 3 saved cooking posts were saved in October 2026 (5, 6 and 10 Oct, Instagram); 'not opened in 2024' ties them to a year they are not from")
for f in (0,1):
    j("I02.0",f,"lead",0,[("Dating advice rows in 2024 (Heart Notes)",0,c(y24,'channel','Heart Notes',unlock=True))],
      truth="wrongly_based",fc="framing",fault="other (false absence): no wrong number, name or date; it says no dating advice theme or channel exists, which is true of the name lookup but reads false: the rows hold the private theme Dating advice, Heart Notes, 50 of the 58 videos of 2024")
    j("I02.0",f,"point",0,[("2024",58,n(y24,unlock=True)),("YouTube",58,n(y24,unlock=True,shorts='yt'))])
j("I02.0",0,"point",1,[("HN",50,c(y24,'channel','Heart Notes',unlock=True)),("largest",'Heart Notes',rank(y24,'channel',unlock=True))])
j("I02.0",1,"point",1,[("HN",50,c(y24,'channel','Heart Notes',unlock=True))])
for f in (0,1):
    j("I03.0",f,"lead",0,[("food share shown",100,s(y24,'area','food and cooking')),("2024 shown",8,n(y24))],
      borderline="strict: wrongly based (only/all), lenient by 'what else'",note=PRIV)
    j("I03.0",f,"point",0,[("PT",8,c(y24,'channel','Pan Theory')),("all HC",8,c(y24,'theme','Home cooking'))])
new_th = sorted({x for x,_ in ranks(Y,'theme')} - {x for x,_ in ranks(p25,'theme')})
j("K03.0",0,"lead",0,[("2026",254,n(Y)),("top",'Digital drawing',rank(Y,'theme')),("DD",92,c(Y,'theme','Digital drawing'))])
j("K03.0",0,"point",0,[("art",52,s(Y,'area','art and design')),("gaming",31,s(Y,'area','gaming'))])
j("K03.0",0,"point",1,[("top ch",'Pixel Pencil',rank(Y,'channel')),("PP",92,c(Y,'channel','Pixel Pencil')),("2nd",'Clip Factory',rank(Y,'channel',1)),("CF",61,c(Y,'channel','Clip Factory'))])
j("K03.0",0,"point",2,[("new themes vs Jan-Oct 2025",['Gaming clips'],new_th),("GC",66,c(Y,'theme','Gaming clips')),("stopped themes",0,len({x for x,_ in ranks(p25,'theme')}-{x for x,_ in ranks(Y,'theme')})),("stopped channels",0,len(stopped_y))],
  truth="wrongly_based",fc="framing",fault="completeness of a list: 'New this year: Gaming clips' leaves out Digital drawing (92, first watched August 2026, the year's top theme), and Minecraft builds and Calculus lessons are also new against Jan-Oct 2025")
j("K04.0",0,"lead",0,truth="cannot_prove",note="a claim about the learned tool's output")
