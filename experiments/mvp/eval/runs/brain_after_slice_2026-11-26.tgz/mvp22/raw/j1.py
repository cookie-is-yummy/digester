from jcore import j, same, J  # noqa: F401
from rc import n, c, s, rank, ranks, NG, G, D, ev2  # noqa: F401
L, P, O = "lately", "prev4", "oct"
# A01.0
j("A01.0",0,"lead",0,[("top area",'gaming',rank(L,'area')),("gaming share",49,s(L,'area','gaming'))])
j("A01.0",0,"point",0,[("top theme",'Gaming clips',rank(L,'theme')),("Gaming clips",59,c(L,'theme','Gaming clips')),
  ("Clip Factory",56,c(L,'channel','Clip Factory')),("mostly: CF share of Gaming clips >50%",True,c(L,'channel','Clip Factory')/c(L,'theme','Gaming clips')>0.5)])
j("A01.0",0,"point",1,[("2nd area",'art and design',rank(L,'area',1)),("art share",25,s(L,'area','art and design')),
  ("top theme in art",'Digital drawing',rank(L,'theme',only=[('area','art and design')]))])
j("A01.0",1,"lead",0,[("top area",'gaming',rank(L,'area')),("gaming share",49,s(L,'area','gaming'))])
j("A01.0",1,"point",0,[("Gaming clips",59,c(L,'theme','Gaming clips')),("Clip Factory",56,c(L,'channel','Clip Factory'))])
j("A01.0",1,"point",1,[("2nd area",'art and design',rank(L,'area',1)),("art share",25,s(L,'area','art and design')),
  ("largest theme in art",'Digital drawing',rank(L,'theme',only=[('area','art and design')]))])
# A01.1
j("A01.1",0,"lead",0,[("top theme",'Gaming clips',rank(L,'theme')),("n",59,c(L,'theme','Gaming clips')),("base",130,n(L))])
j("A01.1",0,"point",0,[("2nd theme",'Home cooking',rank(L,'theme',1)),("n",30,c(L,'theme','Home cooking')),("before",2,c(P,'theme','Home cooking'))])
j("A01.1",0,"point",1,[("now",21,s(L,'theme','Digital drawing')),("before",57,s(P,'theme','Digital drawing'))],note="before period unnamed in the sentence; the call compared the 4 weeks before")
# A01.3
j("A01.3",0,"lead",0,[("top ch",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
j("A01.3",0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("PT",32,c(O,'channel','Pan Theory')),("PP",29,c(O,'channel','Pixel Pencil'))])
j("A01.3",0,"point",1,[("GD",5,c(O,'channel','Gaming Daily')),("BR",6,c(O,'channel','Brick Realm')),
  ("both in top five",True,{'Gaming Daily','Brick Realm'} <= {x for x,_ in ranks(O,'channel')[:5]})])
# A01.4
j("A01.4",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**NG)),("n",32,c(O,'channel','Pan Theory',**NG)),("base",70,n(O,**NG))])
j("A01.4",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**NG)),("n",29,c(O,'channel','Pixel Pencil',**NG))])
# A01.5
LG = dict(exclude=[("area","gaming")], length="long")
for f in (0,1):
    j("A01.5",f,"lead",0,[("top",'Pan Theory',rank(O,'channel',**LG)),("n",32,c(O,'channel','Pan Theory',**LG)),("base",66,n(O,**LG))])
    j("A01.5",f,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**LG)),("n",29,c(O,'channel','Pixel Pencil',**LG)),("ctx: n any length",29,c(O,'channel','Pixel Pencil'))])
    j("A01.5",f,"point",1,[("n long",4,c(O,'channel','Limit Lane',**LG)),("ctx: n any length",4,c(O,'channel','Limit Lane'))])
# A03.0 (repair form identical to the first)
j("A03.0",0,"lead",0,[("top theme",'Gaming clips',rank(L,'theme')),("share",45,s(L,'theme','Gaming clips')),("base",130,n(L))])
j("A03.0",0,"point",0,[("2nd",'Home cooking',rank(L,'theme',1)),("now",23,s(L,'theme','Home cooking')),("before",4,s(P,'theme','Home cooking'))])
j("A03.0",0,"point",1,[("now",21,s(L,'theme','Digital drawing')),("points",-36,s(L,'theme','Digital drawing')-s(P,'theme','Digital drawing'))])
for w,i in (("lead",0),("point",0),("point",1)): same("A03.0",1,w,i)
# A05.0
j("A05.0",0,"lead",0,[("top",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
j("A05.0",0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("n",32,c(O,'channel','Pan Theory'))])
j("A05.0",0,"point",1,[("3rd",'Pixel Pencil',rank(O,'channel',2)),("n",29,c(O,'channel','Pixel Pencil'))])
# A06.0
j("A06.0",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**NG)),("n",32,c(O,'channel','Pan Theory',**NG)),("base",70,n(O,**NG))])
j("A06.0",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**NG)),("n",29,c(O,'channel','Pixel Pencil',**NG))])
j("A06.0",0,"point",1,[("Calculus",4,c(O,'theme','Calculus lessons',**NG)),("ctx: fewest theme w/o gaming",'Calculus lessons',ranks(O,'theme',**NG)[-1][0]),
  ("ctx: fewest channel w/o gaming",'Wet Paper',ranks(O,'channel',**NG)[-1][0])],
  truth="wrongly_based",fc="framing",fault="rank across levels: a theme called 'the fewest' in a channel ranking; Wet Paper had 1 and @wetpaper.ig 4, so a reader of the channel list reads it as the fewest channel",
  borderline="lenient: true (Calculus lessons is the fewest theme, with or without gaming)")
# A07.0
OL = dict(length="long")
j("A07.0",0,"lead",0,[("top",'Pan Theory',rank(O,'channel',**OL)),("n",32,c(O,'channel','Pan Theory',**OL)),("base",72,n(O,**OL))])
j("A07.0",0,"point",0,[("2nd",'Pixel Pencil',rank(O,'channel',1,**OL)),("n",29,c(O,'channel','Pixel Pencil',**OL))])
j("A07.0",0,"point",1,[("share of long",44,s(O,'channel','Pan Theory',**OL))])
# B01.0
j("B01.0",0,"lead",0,[("top",'gaming',rank(L,'area')),("share",49,s(L,'area','gaming')),("n",64,c(L,'area','gaming')),("base",130,n(L))])
j("B01.0",0,"point",0,[("Gaming clips",59,c(L,'theme','Gaming clips')),("CF",56,c(L,'channel','Clip Factory'))])
j("B01.0",0,"point",1,[("2nd area",'art and design',rank(L,'area',1)),("share",25,s(L,'area','art and design')),
  ("top in art",'Digital drawing',rank(L,'theme',only=[('area','art and design')])),("DD",27,c(L,'theme','Digital drawing'))])
# B02.0
j("B02.0",0,"lead",0,[("top",'art and design',rank(L,'area',**NG)),("share",48,s(L,'area','art and design',**NG))])
j("B02.0",0,"point",0,[("2nd",'food and cooking',rank(L,'area',1,**NG)),("share",45,s(L,'area','food and cooking',**NG)),("n",30,c(L,'area','food and cooking',**NG)),("base",66,n(L,**NG))])
j("B02.0",0,"point",1,[("math",4,c(L,'area','math'))])
# B03.0
LL_ = dict(length="long")
for f in (0,1):
    j("B03.0",f,"lead",0,[("top",'food and cooking',rank(L,'area',**LL_)),("n",30,c(L,'area','food and cooking',**LL_)),("base",67,n(L,**LL_))])
j("B03.0",0,"point",0,[("2nd",'art and design',rank(L,'area',1,**LL_)),("n",28,c(L,'area','art and design',**LL_)),("share",42,s(L,'area','art and design',**LL_))])
j("B03.0",0,"point",1,[("gaming long",5,c(L,'area','gaming',**LL_)),("math long",4,c(L,'area','math',**LL_))])
j("B03.0",1,"point",0,[("2nd",'art and design',rank(L,'area',1,**LL_)),("n",28,c(L,'area','art and design',**LL_))])
# B05.0
stopped = sorted({x for x,_ in ranks(P,'channel')} - {x for x,_ in ranks(L,'channel')})
drops = sorted(((c(L,'channel',x)-v), x) for x,v in ranks(P,'channel'))
for f in (0,1):
    j("B05.0",f,"lead",0,[("channels stopped lately vs 4 weeks before",[],stopped)])
j("B05.0",0,"point",0,[("PP before",29,c(P,'channel','Pixel Pencil')),("PP now",27,c(L,'channel','Pixel Pencil')),("ctx: drops by count",'PP -2',str(drops[:3]))],
  truth="wrongly_based",fc="framing",fault="rank tie: 'the biggest drop' is shared with Brick Realm (7 to 5) and Limit Lane (6 to 4)")
j("B05.0",1,"point",0,[("PP before",29,c(P,'channel','Pixel Pencil')),("PP now",27,c(L,'channel','Pixel Pencil'))])
# ---- B07.0 to K04.0
WC = dict(only=[("theme","Watercolor painting")])
wc_first = sorted(ev2("all",**WC), key=lambda e: e["dt"])[0]
for f in (0,1):
    j("B07.0",f,"lead",0,[("first wc day",str(D(2025,1,10)),str(wc_first["day"])),("title",'Watercolor wet on wet',wc_first["title"].split(" #")[0]),("channel",'Wet Paper',wc_first["channel"])],
      note="the title is 'Watercolor wet on wet #1': the model left off the number; the verifier dropped it as wrong_name")
    j("B07.0",f,"point",0,[("wc all history",95,n("all",**WC)),("Wet Paper",91,c("all","channel","Wet Paper",**WC))])
l7 = (D(2026,10,24), D(2026,10,30))
j("B11.0",0,"lead",0,[("top",'Clip Factory',rank(l7,'channel')),("n",13,c(l7,'channel','Clip Factory')),("base",24,n(l7))])
j("B11.0",0,"point",0,[("2nd",'Pixel Pencil',rank(l7,'channel',1)),("n",6,c(l7,'channel','Pixel Pencil'))])
j("B11.0",0,"point",1,[("PT",5,c(l7,'channel','Pan Theory'))])
j("B14.0",0,"lead",0,[("shorts",66,n("all",shorts="yt_short")),("opened",723,n("all")),("share of YouTube",9,100*n("all",shorts="yt_short")/n("all",shorts="yt"))])
j("B14.0",0,"point",0,[("long",651,n("all",shorts="yt_long")),("largest long theme",'Minecraft builds',rank("all","theme",length="long")),("MC",163,c("all","theme","Minecraft builds",length="long")),
  ("ctx: largest long theme incl. private",'Minecraft builds',rank("all","theme",length="long",unlock=True))])
GCs = dict(only=[("theme","Gaming clips")])
j("B14.0",0,"point",1,[("Gaming clips",66,n("all",**GCs)),("of them Shorts",66,n("all",shorts="yt_short",**GCs))])
j("C01.0",0,"lead",0,[("least",'Wet Paper',ranks(O,'channel')[-1][0]),("n",1,c(O,'channel','Wet Paper')),("base",142,n(O))])
j("C01.0",0,"point",0,[("LL",4,c(O,'channel','Limit Lane')),("GD",5,c(O,'channel','Gaming Daily'))],note="@wetpaper.ig (4) not named; no list is said as complete")
NM = dict(exclude=[("theme","Minecraft builds")])
for f in (0,1):
    j("C02.0",f,"lead",0,[("top",'gaming',rank(L,'area',**NM)),("share",47,s(L,'area','gaming',**NM)),("base",125,n(L,**NM))])
j("C02.0",0,"point",0,[("art share",26,s(L,'area','art and design',**NM)),("points",-40,s(L,'area','art and design',**NM)-s(P,'area','art and design',**NM)),
  ("ctx: art share with Minecraft in",25,s(L,'area','art and design'))],
  borderline="strict: wrongly based (scope); the sentence carries no 'without Minecraft builds' and on the whole base art is 25% (down 32 points); the lead says the scope and the person asked for it")
j("C02.0",0,"point",1,[("food share",24,s(L,'area','food and cooking',**NM)),("points",19,s(L,'area','food and cooking',**NM)-s(P,'area','food and cooking',**NM))],
  borderline="strict: wrongly based (scope); on the whole base food is 23%, up 19 points")
j("C02.0",1,"point",0,[("art share",26,s(L,'area','art and design',**NM)),("points",-40,s(L,'area','art and design',**NM)-s(P,'area','art and design',**NM))])
j("C02.0",1,"point",1,[("food share",24,s(L,'area','food and cooking',**NM)),("points",19,s(L,'area','food and cooking',**NM)-s(P,'area','food and cooking',**NM))])
SU = dict(weekday=6)
for f in (0,1):
    j("C04.0",f,"lead",0,[("top on Sundays",'gaming',rank('all','area',**SU)),("share",45,s('all','area','gaming',**SU)),("base",101,n('all',**SU)),
      ("ctx: top on Sundays incl. private",'gaming',rank('all','area',unlock=True,**SU))])
    j("C04.0",f,"point",0,[("top theme Sundays",'Minecraft builds',rank('all','theme',**SU)),("n",23,c('all','theme','Minecraft builds',**SU)),
      ("all from Brick Realm",23,c('all','channel','Brick Realm',only=[("theme","Minecraft builds")],**SU))])
    j("C04.0",f,"point",1,[("2nd",'art and design',rank('all','area',1,**SU)),("share",25,s('all','area','art and design',**SU))])
Y = (D(2026,1,1), D(2026,10,30))
j("C06.0",0,"lead",0,[("top",'art and design',rank(Y,'area')),("n",133,c(Y,'area','art and design')),("base",254,n(Y)),("share",52,s(Y,'area','art and design'))])
j("C06.0",0,"point",0,[("2nd",'gaming',rank(Y,'area',1)),("n",79,c(Y,'area','gaming')),("share",31,s(Y,'area','gaming'))])
j("C06.0",0,"point",1,[("top theme",'Digital drawing',rank(Y,'theme')),("DD",92,c(Y,'theme','Digital drawing')),("GC",66,c(Y,'theme','Gaming clips'))])
SR = dict(only=[("theme","Speedruns")])
sr_last = sorted(ev2("all",**SR), key=lambda e: e["dt"])[-1]
j("C08.0",0,"lead",0,[("last day",str(D(2023,5,1)),str(sr_last["day"])),("title",'Speedrun glitch explained',sr_last["title"].split(" #")[0])],note="title is 'Speedrun glitch explained #90'")
j("C08.0",0,"point",0,[("speedruns",90,n("all",**SR)),("all Frame Perfect",90,c("all","channel","Frame Perfect",**SR))])
from collections import Counter as _C
maxopen = max(_C(e["id"] for e in ev2("all",unlock=True)).values())
for f in (0,1):
    j("C09.0",f,"lead",0,[("most opens of any item",1,maxopen)])
    j("C09.0",f,"point",0,[("Cooking soup on the 30th opens",1,sum(1 for e in ev2("all") if e["title"]=="Cooking soup on the 30th"))])
j("C09.0",0,"point",1,[("most opens of any item",1,maxopen)])
for k in ("D01.0","D03.0"):
    j(k,0,"lead",0,[("top",'Clip Factory',rank(O,'channel')),("n",61,c(O,'channel','Clip Factory')),("base",142,n(O))])
    j(k,0,"point",0,[("2nd",'Pan Theory',rank(O,'channel',1)),("PT",32,c(O,'channel','Pan Theory')),("PP",29,c(O,'channel','Pixel Pencil'))])
j("D03.0",0,"point",1,[("BR",6,c(O,'channel','Brick Realm')),("GD",5,c(O,'channel','Gaming Daily'))])
SE = "sep"
j("D01.1",0,"lead",0,[("top",'Pixel Pencil',rank(SE,'channel')),("n",31,c(SE,'channel','Pixel Pencil')),("base",44,n(SE))])
j("D01.1",0,"point",0,[("2nd",'Brick Realm',rank(SE,'channel',1)),("n",7,c(SE,'channel','Brick Realm'))])
j("D01.1",0,"point",1,[("art share",70,s(SE,'area','art and design'))])
def day_of(title):
    return str(next(e["day"] for e in ev2("all") if e["title"] == title))
for f in (0,1):
    j("D03.1",f,"lead",0,truth="no_claim")
    j("D03.1",f,"point",0,[("day (New York)",'2026-10-30',day_of("Cooking soup on the 30th"))],note="01:00 UTC 31 Oct = 21:00 New York 30 Oct")
    j("D03.1",f,"point",1,[("day (New York)",'2026-10-30',day_of("Digital art colour on the 30th"))])
j("D03.2",0,"lead",0,[("Oct gaming",72,n(O,**G))])
j("D03.2",0,"point",0,[("day",'2026-10-30',day_of("Gaming clip on the 30th"))])
j("D03.2",0,"point",1,[("day",'2026-10-29',day_of("Gaming clutch moment #60")),("ctx: opens per item (all tie)",1,maxopen)],
  truth="wrongly_based",fc="framing",fault="rank over a tie: 'one of the top five' when every one of the 72 gaming videos was opened once",
  borderline="lenient: true (it is in the first five rows of the list)")
y22 = (D(2022,1,1), D(2022,12,31))
j("D04.0",0,"lead",0,[("share",93,s(y22,'area','gaming')),("n",100,c(y22,'area','gaming')),("base",108,n(y22))])
j("D04.0",0,"point",0,[("top theme",'Minecraft builds',rank(y22,'theme')),("n",59,c(y22,'theme','Minecraft builds')),("BR",59,c(y22,'channel','Brick Realm'))])
j("D04.0",0,"point",1,[("2nd",'Speedruns',rank(y22,'theme',1)),("n",41,c(y22,'theme','Speedruns')),("FP",41,c(y22,'channel','Frame Perfect'))])
j("D04.0",0,"point",2,[("HC",8,c(y22,'theme','Home cooking')),("PT",8,c(y22,'channel','Pan Theory'))])
j("D04.1",0,"lead",0,truth="no_claim",note="acknowledgement only; Instagram 2022 holds 0 rows (Instagram starts 12 Oct 2026) and the form never says so")
j("D04.1",1,"lead",0,truth="no_claim",note="as form 0")
o30 = sorted(ev2("oct30"), key=lambda e: e["dt"])
for f in (0,1):
    j("D07.0",f,"lead",0,[("30 Oct",4,len(o30)),("YouTube",4,sum(e['platform']=='youtube' for e in o30))])
    j("D07.0",f,"point",0,[("first",'Digital drawing on the 30th',o30[0]['title']),("PP",'Pixel Pencil',o30[0]['channel'])])
j("D07.0",0,"point",1,[("GC is a Short",True,o30[1]['length']<=60),("GC channel",'Clip Factory',o30[1]['channel']),("last",'Cooking soup on the 30th',o30[-1]['title']),("PT",'Pan Theory',o30[-1]['channel'])])
j("D07.0",1,"point",1,[("last",'Cooking soup on the 30th',o30[-1]['title']),("PT",'Pan Theory',o30[-1]['channel'])])
for f in (0,1):
    j("D07.1",f,"lead",0,[("second card shown in D07.0 (r1.items[1])",'Gaming clip on the 30th','Gaming clip on the 30th'),("its channel",'Clip Factory',o30[1]['channel']),("a Short",True,o30[1]['length']<=60)],
      note="second card = r1.items[1] of the D07.0 result (the model named it there); by time it is also the second of the day")
CO = dict(only=[("area","food and cooking")])
j("D08.0",0,"lead",0,[("cooking 2026",32,n(Y,**CO)),("all PT",32,c(Y,'channel','Pan Theory',**CO))])
j("D08.0",0,"point",0,[("long",32,n(Y,length='long',**CO)),("Home cooking",32,c(Y,'theme','Home cooking',**CO))])
y25 = (D(2025,1,1), D(2025,12,31))
j("D08.1",0,"lead",0,[("cooking 2025",8,n(y25,**CO)),("PT share",100,s(y25,'channel','Pan Theory',**CO))])
j("D08.1",0,"point",0,[("HC share of area",100,s(y25,'theme','Home cooking',**CO))])
j("D10.0",0,"lead",0,[("share",49,s(L,'area','gaming')),("base",130,n(L))])
j("D10.0",0,"point",0,[("CF",56,c(L,'channel','Clip Factory'))])
j("D10.0",0,"point",1,[("art",25,s(L,'area','art and design')),("DD",21,s(L,'theme','Digital drawing'))])
for f in (0,1):
    j("D10.1",f,"lead",0,[("share",49,s(L,'area','gaming'))])
    j("D10.1",f,"point",0,[("all share",44,s('all','area','gaming')),("top area all",'gaming',rank('all','area')),("ctx: top area all incl. private",'gaming',rank('all','area',unlock=True))])
    j("D10.1",f,"point",1,[("CF",56,c(L,'channel','Clip Factory'))])
p25 = (D(2025,1,1), D(2025,10,30))
stopped_y = sorted({x for x,_ in ranks(p25,'channel')} - {x for x,_ in ranks(Y,'channel')})
for f in (0,1):
    j("E04.0",f,"lead",0,[("channels stopped 2026 vs Jan-Oct 2025",[],stopped_y)])
j("E04.0",0,"point",0,[("WP 2026",37,c(Y,'channel','Wet Paper')),("WP Jan-Oct 2025",45,c(p25,'channel','Wet Paper')),
  ("channels that fell",['Wet Paper'],sorted(x for x,v in ranks(p25,'channel') if c(Y,'channel',x) < v))])
j("E04.0",1,"point",0,[("WP 2026",37,c(Y,'channel','Wet Paper')),("WP Jan-Oct 2025",45,c(p25,'channel','Wet Paper'))])
for f in (0,1):
    j("F02.0",f,"lead",0,[("last YouTube day",'2026-10-30',str(max(e['day'] for e in ev2('all',shorts='yt')))),("30 Oct",4,len(o30)),("YouTube",4,sum(e['platform']=='youtube' for e in o30))])
    j("F02.0",f,"point",0,[("DD",2,c('oct30','theme','Digital drawing')),("top",'Digital drawing',rank('oct30','theme')),("PP",2,c('oct30','channel','Pixel Pencil'))])
j("F02.0",0,"point",1,[("GC",1,c('oct30','theme','Gaming clips')),("HC",1,c('oct30','theme','Home cooking'))])
j("F03.0",0,"lead",0,[("2019 rows, any kind",0,n('2019',kind=None,unlock=True))])
for f in (0,1):
    j("F04.0",f,"lead",0,[("speedruns 2026",0,n(Y,**SR))])
    j("F04.0",f,"point",0,[("speedruns",90,n('all',**SR)),("FP",90,c('all','channel','Frame Perfect',**SR)),("first",'2021-03-01',str(min(e['day'] for e in ev2('all',**SR))))])
for f in (0,1):
    j("F05.0",f,"lead",0,[("GC",66,c('all','theme','Gaming clips',**G)),("gaming",319,n('all',**G))]+([("Shorts share",100,100*n('all',shorts='yt_short',**GCs)/n('all',**GCs))] if f==0 else []))
    j("F05.0",f,"point",0,[("CF",61,c('all','channel','Clip Factory',**G)),("CF first",'2026-10-01',str(min(e['day'] for e in ev2('all') if e['channel']=='Clip Factory')))])
    j("F05.0",f,"point",1,[("GC share of 2026 gaming",84,s(Y,'theme','Gaming clips',**G)),("2026 gaming",79,n(Y,**G)),("2024 gaming",0,n((D(2024,1,1),D(2024,12,31)),**G)),("2025 gaming",0,n(y25,**G))])
    j("F05.0",f,"point",2,[("MC share of gaming, all history",51,s('all','theme','Minecraft builds',**G)),("ctx: MC share of all opened",23,s('all','theme','Minecraft builds')),
      ("ctx: largest gaming theme in 2026",'Gaming clips',rank(Y,'theme',**G))],
      truth="wrongly_based",fc="framing",fault="base and direction: 51% is of gaming videos but said 'of what you opened' (it is 23% of all opened); 'still the largest' is all-history, while in 2026 Gaming clips (66) lead Minecraft builds (13)")
# ---- F06.0 to K04.0
for f in (0,1):
    j("F06.0",f,"lead",0,[("now",49,s(L,'area','gaming')),("before",27,s(P,'area','gaming'))])
    j("F06.0",f,"point",0,[("n",64,c(L,'area','gaming')),("base",130,n(L)),("points",22,s(L,'area','gaming')-s(P,'area','gaming'))])
j("F06.0",0,"point",1,[("CF",56,c(L,'channel','Clip Factory')),("all Gaming clips",56,sum(1 for e in ev2(L) if e['channel']=='Clip Factory' and e['theme']=='Gaming clips')),
  ("all Shorts",56,sum(1 for e in ev2(L,shorts='yt_short') if e['channel']=='Clip Factory'))])
j("F06.0",1,"point",1,[("CF",56,c(L,'channel','Clip Factory'))])
j("F08.0",0,"lead",0,[("Brick Realm rows, any kind",163,len([e for e in ev2('all',kind=None) if e['channel']=='Brick Realm']))])
MC = dict(only=[("theme","Minecraft builds")])
j("F09.0",0,"lead",0,[("Minecraft channels",['Brick Realm'],[x for x,_ in ranks('all','channel',platform='youtube',**MC)]),("BR",163,c('all','channel','Brick Realm',**MC))])
j("F09.0",0,"point",0,[("Minecraft channels count",1,len(ranks('all','channel',**MC)))])
j("F10.0",0,"lead",0,[("share",49,s(L,'area','gaming')),("base",130,n(L))],note="'I can't predict next week' is a limit line, no history claim")
j("F10.0",1,"lead",0,[("share",49,s(L,'area','gaming')),("base",130,n(L))])
for f in (0,1):
    j("F10.0",f,"point",0,[("CF",56,c(L,'channel','Clip Factory'))])
j("F10.0",0,"point",1,[("2nd channel",'Pan Theory',rank(L,'channel',1)),("PT",30,c(L,'channel','Pan Theory')),("all Home cooking",30,sum(1 for e in ev2(L) if e['channel']=='Pan Theory' and e['theme']=='Home cooking'))])
j("F10.0",1,"point",1,[("2nd channel",'Pan Theory',rank(L,'channel',1)),("PT",30,c(L,'channel','Pan Theory'))])
mon = lambda y, m: n((D(y,m,1), D(y,m,30 if m in (9,) else 31)))
j("F11.0",0,"lead",0,[("Oct 2026",142,n(O)),("Sep 2026",44,n('sep')),("Aug 2026",36,mon(2026,8)),("biggest month ever",'2026-10','2026-10')],
  note="it never says October is the biggest month (it is: 142, next July 2023 with 52)")
yrs = {y: n((D(y,1,1),D(y,12,31))) for y in range(2021,2026)}
j("F11.0",0,"point",0,[("2021",134,yrs[2021]),("2022",108,yrs[2022]),("2023",157,yrs[2023]),("full years before 2026 listed",[2021,2022,2023],sorted(yrs))],
  truth="wrongly_based",fc="framing",fault="completeness of a list: 'your full years before 2026 were' 2021, 2022 and 2023 leaves out 2024 (8 shown, 58 with the private topic) and 2025 (62)")
j("F14.0",0,"lead",0,[("gaming all",319,n('all',**G))],note="true, but the question named the channel Gaming Daily")
j("F14.0",1,"lead",0,[("gaming all",319,n('all',**G))])
j("F14.0",0,"point",0,[("GC",66,c('all','theme','Gaming clips')),("mostly CF",True,c('all','channel','Clip Factory',**GCs)/n('all',**GCs)>0.5)])
j("F14.0",1,"point",0,[("GC",66,c('all','theme','Gaming clips',**G))])
for f in (0,1):
    j("F14.0",f,"point",1,[("GD",5,c('all','channel','Gaming Daily')),("no theme named daily",True,not any('daily' in t.lower() for t in {e['theme'] for e in ev2('all',unlock=True)}))])
CA = dict(only=[("theme","Calculus lessons")])
ca_long = sorted(ev2('all',length='long',**CA), key=lambda e: e['dt'], reverse=True)
for f in (0,1):
    j("F15.0",f,"lead",0,[("long calculus",83,len(ca_long)),("latest (first on the list)",'Calculus derivatives fast',ca_long[0]['title'].split(' #')[0]),("its day",'2026-10-16',str(ca_long[0]['day']))]+([("channel",'Limit Lane',ca_long[0]['channel'])] if f==0 else []),
      borderline="strict: wrongly based; asked for the longest, 'the first on the list' can read as the longest, while all 83 are 600 s")
    j("F15.0",f,"point",0,[("Integrals by parts #82 long, opened once",True,any(e['title']=='Integrals by parts #82' for e in ca_long)),("Calculus limits intro #84",True,any(e['title']=='Calculus limits intro #84' for e in ca_long)),("max opens",1,maxopen)])
wp_oct = [e for e in ev2(O) if e['channel']=='Wet Paper']
for f in (0,1):
    j("G03.0",f,"lead",0,[("Wet Paper Oct",1,len(wp_oct))],note="@wetpaper.ig (4 reels in October) is another handle")
    j("G03.0",f,"point",0,[("day",'2026-10-21',str(wp_oct[0]['day'])),("YouTube",'youtube',wp_oct[0]['platform'])],
      note="form 0 quotes the title, which carries an instruction; it is quoted as data, not followed")
y24 = (D(2024,1,1), D(2024,12,31))
for f in (0,1):
    j("I01.0",f,"lead",0,[("2024 shown (private out)",8,n(y24)),("ctx: 2024 opened, all rows",58,n(y24,unlock=True)),("food share shown",100,s(y24,'area','food and cooking'))],
      truth="wrongly_based",fc="framing",fault="only/all with the private topic left out: 'you opened 8 videos' and '100% of what you opened' while 58 were opened (50 in the private topic, which outranks Home cooking)",
      borderline="lenient: true when 'Leaving out topics you keep private.' is printed beside it (code printed it on the sent answer)")
    j("I01.0",f,"point",0,[("HC",8,c(y24,'theme','Home cooking')),("PT",8,c(y24,'channel','Pan Theory'))])
for f in (0,1):
    j("I02.0",f,"lead",0,[("Dating advice rows in 2024 (Heart Notes)",0,c(y24,'channel','Heart Notes',unlock=True))],
      truth="wrongly_based",fc="framing",fault="other (false absence): no wrong number, name or date; it says no dating advice theme or channel exists, which is true of the name lookup but reads false: the rows hold the private theme Dating advice, Heart Notes, 50 of the 58 videos of 2024")
    j("I02.0",f,"point",0,[("2024 opened (turn unlocked)",58,n(y24,unlock=True)),("HC",8,c(y24,'theme','Home cooking',unlock=True)),("top theme 2024",'Home cooking',rank(y24,'theme',unlock=True))],
      truth="wrongly_based",fc="framing",fault="rank with the private theme left out of the rank but in the base: 'the top theme was Home cooking with 8' of 58, while Dating advice had 50")
j("I02.0",0,"point",1,[("HN",50,c(y24,'channel','Heart Notes',unlock=True)),("base",58,n(y24,unlock=True))],note="'so check which channel your partner means' is advice, no claim")
j("I02.0",1,"point",1,[("HN",50,c(y24,'channel','Heart Notes',unlock=True)),("base",58,n(y24,unlock=True))])
for f in (0,1):
    j("I03.0",f,"lead",0,[("2024 shown (private out)",8,n(y24)),("ctx: 2024 opened, all rows",58,n(y24,unlock=True)),("food share shown",100,s(y24,'area','food and cooking'))],
      truth="wrongly_based",fc="framing",fault="only/all with the private topic left out: 'In 2024 you opened 8 videos ... 100% of what you opened', right after the previous answer said 58",
      borderline="lenient: true; the person asked 'what else', so the 50 private videos are out by the question")
    j("I03.0",f,"point",0,[("themes shown",['Home cooking'],[x for x,_ in ranks(y24,'theme')]),("channels shown",['Pan Theory'],[x for x,_ in ranks(y24,'channel')]),("PT",8,c(y24,'channel','Pan Theory'))],
      note="'only theme' holds for what else besides the dating advice just discussed")
j("K03.0",0,"lead",0,[("2026",254,n(Y)),("top theme",'Digital drawing',rank(Y,'theme')),("share",36,s(Y,'theme','Digital drawing'))])
j("K03.0",0,"point",0,[("2nd theme",'Gaming clips',rank(Y,'theme',1)),("GC",66,c(Y,'theme','Gaming clips')),("top channel",'Pixel Pencil',rank(Y,'channel')),("PP",92,c(Y,'channel','Pixel Pencil'))])
new_ch = sorted({x for x,_ in ranks(Y,'channel')} - {x for x,_ in ranks(p25,'channel')})
new_th = sorted({x for x,_ in ranks(Y,'theme')} - {x for x,_ in ranks(p25,'theme')})
first_seen = {x: str(min(e['day'] for e in ev2('all') if e['theme']==x)) for x in ('Minecraft builds','Calculus lessons')}
j("K03.0",0,"point",1,[("new channels vs Jan-Oct 2025",['Clip Factory','Gaming Daily','Pixel Pencil'],new_ch),("new themes vs Jan-Oct 2025",['Calculus lessons','Minecraft builds'],new_th),
  ("ctx: first seen",'2026',str(first_seen))],
  truth="wrongly_based",fc="framing",fault="completeness and base of 'new': new only against Jan-Oct 2025, and the lists leave out Brick Realm, Limit Lane, @wetpaper.ig, Digital drawing and Gaming clips; Minecraft builds (since 2021) and Calculus lessons (since 2023) read as first seen this year. Names and numbers otherwise right")
j("K03.0",0,"point",2,[("wc Jan-Oct 2025",87,s(p25,'theme','Watercolor painting')),("wc 2026",16,s(Y,'theme','Watercolor painting'))])
j("K03.0",0,"point",3,[("themes stopped",[],sorted({x for x,_ in ranks(p25,'theme')}-{x for x,_ in ranks(Y,'theme')})),("channels stopped",[],stopped_y)])
j("K04.0",0,"lead",0,truth="cannot_prove",note="a claim about the learned tool's output (no checked points), not about the rows")
# ---- overrides after the private-base rule was fixed (product base leaves the private topic out unless the turn
# unlocked it; the private line is code's; primary truth is on that base, strict reading in 'borderline')
PRIV = "private base: the private topic (Dating advice, 50 in 2024) is out of the base as the product's rule says; "
for f in (0,1):
    j("I01.0",f,"lead",0,[("2024 shown (private out)",8,n(y24)),("food share shown",100,s(y24,'area','food and cooking')),("ctx: 2024 opened, all rows (ctx)",58,n(y24,unlock=True))],
      borderline="strict: wrongly based (only/all): 'you opened 8 videos ... 100% of what you opened' while 58 were opened and the hidden topic outranks; the private line was on the form",
      note=PRIV+"the verifier dropped it (private_total)")
    j("I03.0",f,"lead",0,[("2024 shown (private out)",8,n(y24)),("food share shown",100,s(y24,'area','food and cooking')),("ctx: 2024 opened, all rows (ctx)",58,n(y24,unlock=True))],
      borderline="strict: wrongly based (only/all): says 8 opened right after the answer that said 58; the person asked 'what else', so the lenient reading holds",
      note=PRIV+"the verifier dropped it (private_total)")
for f in (0,1):
    j("C04.0",f,"point",1,[("2nd area",'art and design',rank('all','area',1,**SU)),("share",25,s('all','area','art and design',**SU))],
      borderline="strict: wrongly based (rank across levels): 'came next' sits right after a theme point (Minecraft builds, 23); it is next after the lead's area (gaming). In the sent answer code replaced the lead with Minecraft builds and the prior recount marked it false there")
    j("D07.1",f,"lead",0,[("second card shown in D07.0 (r1.items[1])",'Gaming clip on the 30th','Gaming clip on the 30th'),("its channel",'Clip Factory',o30[1]['channel']),("a Short",True,o30[1]['length']<=60)],
      borderline="strict: wrongly based; the prior recount read 'the second one' as the second point sent (Cooking soup, Pan Theory); the cards were shown in time order, second = Gaming clip")
j("D10.1",0,"point",0,[("all share (private out)",44,s('all','area','gaming')),("top area all",'gaming',rank('all','area')),("ctx: share with private in (ctx)",41,s('all','area','gaming',unlock=True)),("ctx: top area incl. private",'gaming',rank('all','area',unlock=True))],
  note=PRIV+"no private line on this form", borderline="strict: wrongly based (base): all-history share with the private topic out and no private line on the form; with it in, gaming is 41%")
j("D10.1",1,"point",0,[("all share (private out)",44,s('all','area','gaming')),("top area all",'gaming',rank('all','area'))],note=PRIV+"no private line on this form",
  borderline="strict: wrongly based (base): all-history share with the private topic out and no private line on the form; with it in, gaming is 41%")
