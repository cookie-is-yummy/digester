"""Join every lead and point of every form with its verdict and its judgment; write sentences.json."""
import glob
import importlib
import json
import re
import sys

S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/"
LOOKS = {"look1": (S + "mvp20/tune/heldout/", "j1"), "look2": (S + "mvp20/fix/heldout_run/", "j2")}


def sentences(look):
    d, mod = LOOKS[look]
    try:
        J = importlib.import_module(mod).J
    except ModuleNotFoundError:
        J = {}
    out, missing = [], []
    for p in sorted(glob.glob(d + "*.json")):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        hid = {c["rid"]: ((c.get("result") or {}).get("meta", {}).get("hidden") or {}).get("sensitive") or 0
               for c in rec["calls"] if c.get("rid")}
        for fi, f in enumerate(rec["forms"]):
            v = rec["verdicts"][fi] if fi < len(rec["verdicts"]) else {"outcomes": []}
            sl = ([("lead", 0, f["lead"])] if f.get("lead") else []) + [("point", i, t) for i, t in enumerate(f.get("points") or [])]
            for where, idx, text in sl:
                o = next((x for x in v["outcomes"] if x["where"] == where and x["index"] == idx), None)
                jd = J.get((rec["key"], fi, where, idx))
                if jd is None:
                    missing.append((rec["key"], fi, where, idx))
                    jd = {}
                out.append({"key": rec["key"], "look": look, "form": "first" if fi == 0 else "repair", "form_index": fi,
                            "where": where, "index": idx, "text": text, "truth": jd.get("truth"),
                            "fault_class": jd.get("fault_class"), "fault": jd.get("fault"), "recount": jd.get("recount"),
                            "recounted_by_rows": jd.get("by_rows"), "borderline": jd.get("borderline"),
                            "note": jd.get("note"),
                            "verifier_kept": o["kept"] if o else None, "verifier_reasons": o["reasons"] if o else None,
                            "verifier_details": o["details"] if o else None,
                            "private_base": any(hid.get(x, 0) > 0 for x in set(re.findall(r"\b(r\d+)\.", text))),
                            "private_line_on_form": v.get("private_line")})
    return out, missing


if __name__ == "__main__":
    allrows = []
    for look in sys.argv[1:]:
        rows, missing = sentences(look)
        print(look, "sentences", len(rows), "judged", len(rows) - len(missing), "missing", len(missing))
        if missing:
            print("  first missing:", missing[:6])
        allrows += rows
    json.dump(allrows, open(S + "mvp22/raw/sentences.json", "w"), indent=1, default=str)
