import json, glob, sys, os
d = sys.argv[1]
ev = {}
for l in open('/home/user/digester/experiments/mvp/evalset/brain_core.jsonl'):
    pass
for p in sorted(glob.glob(d + '/*.json')):
    if p.endswith('summary.json'): continue
    r = json.load(open(p))
    print('=' * 100)
    print(r['key'], '|', r['message'])
    for c in r['calls']:
        a = dict(c['args'])
        res = c.get('result') or {}
        m = res.get('meta', {})
        print('  CALL', c['rid'], c['name'], json.dumps(a)[:400])
        print('     window:', m.get('window_said'), '| base:', m.get('base'), '| filters:', m.get('filters_said'), '| hidden:', m.get('hidden'), '| complete:', m.get('complete'), '| err:', res.get('error'))
    for fi, (f, v) in enumerate(zip(r['forms'], r['verdicts'])):
        print('  FORM', fi, 'understood:', f.get('understood'))
        for o in v['outcomes']:
            print('    [%s %d] kept=%s %s %s' % (o['where'], o['index'], o['kept'], o['reasons'], o['details']))
            print('       ', o['text'])
            print('        cells:', o['cells'])
        print('    offers:', [(x['kind'], x.get('ref')) for x in f.get('offers') or []], 'items:', len(f.get('items') or []), 'outside:', f.get('outside'), 'ask_back:', f.get('ask_back'), 'hand_back:', f.get('hand_back'), 'chart:', bool(f.get('chart')))
        if v.get('items') or v.get('outside'): print('    v.items/outside:', v.get('items'), v.get('outside'))
    if len(r['forms']) != len(r['verdicts']): print('  !! forms', len(r['forms']), 'verdicts', len(r['verdicts']))
    print('  lead_source:', r['lead_source'], 'code_lead:', r.get('code_lead'))
    print('  SENT:', (r.get('answer') or {}).get('text'))
