# evaltools progress
Worktree: S/mvp22/evaltools_tree, branch brain-evaltools-local from experiments/search-loop (1163b7b).
Evidence: S/mvp22/evaltools/
## Steps
- [x] worktree made
- [ ] read eval_brain.py, eval_claims audit, evidence
- [x] baseline on 1163b7b: brain tests 243 passed (evaltools/brain_tests_before.txt), planted_before.txt
- [x] copies of held-out looks: evaltools/look1 (mvp20/tune/heldout), evaltools/look2 (mvp20/fix/heldout_run)
- plan: G2 scorer readings + first counting round required + none in any breakdown + finer timeline unit +
  first_last scope normalized + same-results guard (non-empty, model scope = hand + extra); auditor two fixes then
  measure, demote to hints; fresh set path; read sheet + marks; rubric; tests
- [x] auditor measured before (evaltools/auditor_before.json) and after two fixes (auditor_after.json), script
  evaltools/scripts/measure_auditor.py. Fixes in eval_claims.py: _rank_count_gap binding, said_scope (filt base).
  sent 110: false flagged 2/5 -> 1/5; true flagged 23/105 -> 2/105 (style only). Still misses 4/5: demote to hints.
- [x] scorer: RULES in eval_brain (first_round, first_last_scope, total_in_breakdown, finer_unit, same_counts on counts
  only), readings, g2_of with verdict_strict; measured evaltools/scorer.json (scripts/measure_scorer.py):
  look1 41 -> 44 of 52; vs reader 44 -> 47 of 52 (lenient and strict). Flips on tune runs hand-read: I04.0, F07.0 ok.
- [x] fresh set path (run --set fresh --half a|b, --set-file), read and marks modes, summary G1_false_sent/auditor_hints/reading
- [ ] rubric, tests, run brain tests, planted, commit
- [x] rubric, tests (26 new), brain tests + auditor tests 357 passed (evaltools/brain_tests_after.txt), planted
  unchanged, plans summary identical to base; committed on brain-evaltools-local
- [ ] advisor final check, report
- [x] review fixes committed f534fb9 (reading_errors, no_hand_plan_list, set file from settings, hint note figures,
  docstrings); brain + auditor tests 357 passed (brain_tests_final.txt); planted unchanged; scorer figures unchanged
  (scorer_report.txt). Sheet of look 1: evaltools/look1_reaudit/reading_sheet.txt
- DONE: report returned in the final answer
