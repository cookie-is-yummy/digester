"""Replay today's verify.py (main checkout, read only) on:
  look1 / look2: every form the model wrote on the held-out half, against the recorded tool results;
  attack / attack_true / audit_true: the planted cases (eval/brain_planted.json, frozen ledgers).
Writes outcomes.json: one row per sentence with today's reasons (all reasons, nothing short-circuited but
structural ones), private_line, and the recorded reasons for the held-out rows. No model call.
    python3 replay.py            (any directory; it imports from the main checkout)"""
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
REPO = "/home/user/digester/experiments"
sys.path.insert(0, REPO)

from mvp.brain import verify as V  # noqa: E402
from mvp.brain import planted as P  # noqa: E402

LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}


def orow(o):
    return {"where": o.where, "index": o.index, "text": o.text, "kept": o.kept, "reasons": list(o.reasons),
            "details": [str(d)[:200] for d in o.details][:4], "hidden_rank": o.hidden_rank, "rid": o.rid,
            "layer": o.layer, "sent": o.sent}


def heldout(h):
    from mvp.brain import tools as TL
    out = []
    for look, d in LOOKS.items():
        for p in sorted(glob.glob(os.path.join(d, "*.json"))):
            if p.endswith("summary.json"):
                continue
            rec = json.load(open(p))
            t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
            vt = V.Turn.of(t)
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                       and not c["result"].get("is_error")}
            for fi, form in enumerate(rec.get("forms") or []):
                v = V.check_answer(form, results, vt)
                recv = (rec.get("verdicts") or [None] * (fi + 1))[fi] if fi < len(rec.get("verdicts") or []) else None
                rec_by = {(o["where"], o["index"]): o for o in (recv or {}).get("outcomes", [])}
                for o in v.outcomes:
                    r = orow(o)
                    ro = rec_by.get((o.where, o.index)) or {}
                    r.update(set=look, key=rec["key"], form=("first" if fi == 0 else "repair"), form_index=fi,
                             private_line=v.private_line, lead_ok=v.lead_ok, repair=v.repair,
                             rec_kept=ro.get("kept"), rec_reasons=ro.get("reasons"),
                             unlock=getattr(t, "unlock", None))
                    out.append(r)
    return out


def planted_rows():
    data = P.load()
    led = data["ledgers"]
    out = []
    for c in data["cases"]:
        if c.get("source") not in ("attack", "attack_true", "audit_true", "audit", "new", "insight_v5"):
            continue
        forms = c.get("forms") or [c["form"]]
        per = []
        for f in forms:
            kept, reasons, v = P.outcome(dict(c, form=f, forms=None), led)
            tgt = c.get("target") or "point:0"
            kind, _, n = tgt.partition(":")
            if kind == "lead":
                os_ = [o for o in v.outcomes if o.where == "lead"]
            else:
                os_ = [o for o in v.outcomes if o.where == kind and o.index == int(n or 0)]
            lead_os = [o for o in v.outcomes if o.where == "lead"]
            per.append({"kept": kept, "reasons": reasons, "private_line": v.private_line,
                        "carrier_kept": all(o.kept for o in lead_os) if kind != "lead" else None,
                        "carrier_reasons": sorted({r for o in lead_os for r in o.reasons}) if kind != "lead" else None,
                        "hidden_rank": any(o.hidden_rank for o in os_),
                        "target_text": " ".join(o.text for o in os_)})
        out.append({"set": c["source"], "id": c["id"], "class": c.get("class"), "expect": c["expect"],
                    "target": c.get("target"), "forms": per, "turn": c.get("turn")})
    return out


if __name__ == "__main__":
    from mvp import eval_brain as E
    base = os.path.join(HERE, "_lib")
    if os.path.isdir(base):
        import shutil
        shutil.rmtree(base)
    os.makedirs(base)
    h = E.Harness.scratch(base=base)
    rows = heldout(h)
    pl = planted_rows()
    json.dump({"heldout": rows, "planted": pl}, open(os.path.join(HERE, "outcomes.json"), "w"), indent=0,
              default=str)
    # reproduction check: today's verdict against the recorded one
    for look in LOOKS:
        rs = [r for r in rows if r["set"] == look and r["rec_kept"] is not None]
        same = sum(1 for r in rs if r["kept"] == r["rec_kept"])
        same_r = sum(1 for r in rs if sorted(r["reasons"]) == sorted(r["rec_reasons"] or []))
        print(look, "rows", len(rs), "same kept", same, "same reasons", same_r)
    import collections
    print(collections.Counter(r["set"] for r in pl))
