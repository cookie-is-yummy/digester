"""C5's closed framing rules, as code would run them on a sentence and the record behind it. WRITTEN FROM LOOK 1's
FAULTS ONLY (A06.0, B05.0, D03.2, F05.0, F11.0, I02.0, K03.0, and C04.0 under the code lead) and frozen by sha256
(frame.sha256) before any run on look 2, the attack or the audit set.

The design these rules stand for (C5): the model words the sentence; code writes the frame (the window at the lead's
opening, the base after a share of a scoped result, the scope, the private line); the model's record says the kind
(rank, list, move, ...) and the row; code checks the record against the rows exactly. A rule here never tries to
accept a variant: framing words are refused unless the rows prove the record they need.

Each rule is (name, test) where test(ctx) returns a reason or None. ctx: sentence text (markers in), plain text,
markers (verify.parse), the cited result, the answer's earlier sentences (their ranked levels), where (lead|point),
the answer's cited cells. Two settings:
  compliant=True  the model left the frame to code: time and base phrases that are the cell's own frame are code's
                  (not refused); this is the bound where the record states what the text means.
  compliant=False the model words as it did in the held-out runs: any time or base phrase it wrote is checked as
                  written (refused unless it is a period label or a date cell)."""
import re

RANK_MOST = re.compile(r"\b(?:led|leads|leading|top|most|biggest|largest|main|highest|busiest|number one|first place)\b",
                       re.I)
RANK_LEAST = re.compile(r"\b(?:fewest|least|smallest|lowest)\b", re.I)
NEXT = re.compile(r"\b(?:came next|comes next|next came|was next|is next|then came|followed by|second|third|runner-up)\b",
                  re.I)
TOP_N = re.compile(r"\b(?:one of the top|top (?:\d+|two|three|four|five|ten))\b", re.I)
TIED = re.compile(r"\b(?:tied|joint|level with|shared|equal)\b", re.I)
MOVE = re.compile(r"\b(?:drop\w*|fell|fall\w*|declin\w*|slow\w*|gain\w*|grew|rose|rise\w*|jump\w*|increas\w*|"
                  r"decreas\w*)\b", re.I)
LEVEL_NOUN = {"themes": r"themes?", "channels": r"channels?", "areas": r"areas?|topics?|kinds?",
              "fields": r"areas?|topics?|kinds?", "periods": r"years?|months?|weeks?|periods?",
              "items": r"videos?|items?|posts?|reels?"}
LIST_FRAME = re.compile(r":\s|\b(?:were|are)\b", re.I)   # must stand before the first row it lists
LIST_SOME = re.compile(r"\b(?:top|including|such as|like|for example|among|some|a few)\b", re.I)
REST = re.compile(r"\b(?:the other|the rest|the remaining|everything else)\b", re.I)
PERSIST = re.compile(r"\b(?:still|ever|all[- ]time|no longer|any ?more|so far)\b", re.I)
NEW = re.compile(r"\b(?:new|first time|for the first time)\b", re.I)
BASE_PH = re.compile(r"\bof (?:what you (?:opened|watched|saved|liked)|everything|all (?:your|the) videos|your videos)\b",
                     re.I)
_MON = r"(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|" \
       r"Jul|Aug|Sep|Sept|Oct|Nov|Dec)"
TIME = re.compile(r"\b(?:(?:19|20)\d\d|" + _MON + r"|this (?:year|month|week|autumn|spring|summer|winter)|last (?:year|"
                  r"month|week|autumn|spring|summer|winter)|lately|recently|right now|these days|since|before|after|"
                  r"until|up to|between|in the (?:\d+|last|past) (?:weeks?|days?|months?)|weeks? before|month before|"
                  r"export covers|days? (?:your|the) export)\b", re.I)


def _rows(res, lst):
    from mvp.brain import verify as V
    try:
        x = V._resolve(res.sheet, lst)
    except (KeyError, AttributeError, TypeError, IndexError):
        return None
    return x if isinstance(x, list) and all(isinstance(r, dict) for r in x) else None


def _rank_marker(markers):
    for mk in markers:
        if mk.kind in ("row", "value") and mk.owner and re.search(r"\[\d+\]$", mk.owner):
            return mk
    return None


def _key_val(row, key):
    v = row.get(key)
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) else None


def _ranked_key(plain, mk, rows):
    """The key a rank word ranks by: a move's size for 'biggest drop', else the cited cell's own key, else items."""
    if MOVE.search(plain) and rows and all(_key_val(r, "previous_items") is not None and _key_val(r, "items")
                                           is not None for r in rows):
        return "delta"
    k = (mk.key or "") if mk.kind == "value" else ""
    if k and all(_key_val(r, k) is not None for r in rows):
        return k
    for k in ("items", "share", "n", "times_opened"):
        if all(_key_val(r, k) is not None for r in rows):
            return k
    return None


def _vals(rows, key, plain):
    if key == "delta":
        d = [r["items"] - r["previous_items"] for r in rows]
        return [-x for x in d] if re.search(r"\b(?:drop\w*|fell|fall\w*|declin\w*|slow\w*|decreas\w*)\b", plain,
                                            re.I) else d
    return [_key_val(r, key) for r in rows]


def r_rank(ctx):
    plain, mk, res = ctx["plain"], ctx["rank_mk"], ctx["res"]
    most, least, topn = RANK_MOST.search(plain), RANK_LEAST.search(plain), TOP_N.search(plain)
    if not (most or least or topn) or mk is None or res is None:
        return None
    from mvp.brain import verify as V
    lst, i = V._list_and_index(mk.owner)
    rows = _rows(res, lst) if lst else None
    if not rows or len(rows) < 2:
        return None
    key = _ranked_key(plain, mk, rows)
    if key is None:
        return None
    vals = _vals(rows, key, plain)
    if any(v is None for v in vals):
        return None
    mine = vals[i]
    if topn:
        n = re.search(r"\d+|two|three|four|five|ten", topn.group(0))
        n = {"two": 2, "three": 3, "four": 4, "five": 5, "ten": 10}.get(n.group(0), int(n.group(0)) if n and
                                                                        n.group(0).isdigit() else 5) if n else 5
        srt = sorted(vals, reverse=True)
        if len(srt) > n and srt[n - 1] == srt[n]:
            return "rank_tie"
        return None
    if least and not most:
        if (res.meta or {}).get("complete") is not True:
            return "rank_incomplete"
        if mine != min(vals):
            return "rank_place"
        if vals.count(mine) > 1 and not TIED.search(plain):
            return "rank_tie"
        return None
    if NEXT.search(plain):
        return None   # an ordinal is checked by r_level and today's cell checks
    if mine != max(vals):
        return "rank_place"
    if vals.count(mine) > 1 and not TIED.search(plain):
        return "rank_tie"
    return None


def r_level(ctx):
    """A rank or 'next' word on a row of one level right after a sentence that ranked another level, with no level
    noun: the reader places it in the earlier list (A06.0 'the fewest', C04.0 'came next' under the code lead)."""
    plain, mk = ctx["plain"], ctx["rank_mk"]
    if mk is None or not (RANK_MOST.search(plain) or RANK_LEAST.search(plain) or NEXT.search(plain)):
        return None
    from mvp.brain import verify as V
    lst, _i = V._list_and_index(mk.owner)
    prev = ctx.get("prev_level")
    lv = _level(lst)
    if prev and lst and prev != lv and not re.search(r"\b(?:" + LEVEL_NOUN.get(lv, "themes?") + r")\b", plain, re.I):
        return "rank_level"
    return None


def _level(lst):
    return re.sub(r"^.*?\b(themes|channels|areas|fields|periods|items)\b.*$", r"\1", lst or "")


def r_list(ctx):
    """Two or more rows of one list said as the list (a colon, or 'were'/'are'), with no 'top', 'including' or
    'such as': the rows cited must be every row of that list (F11.0's years, K03.0's new themes)."""
    text, plain, markers, res = ctx["text"], ctx["plain"], ctx["markers"], ctx["res"]
    if ctx["compliant"]:
        return "list_incomplete" if ctx.get("bad_list") else None
    if res is None or LIST_SOME.search(plain):
        return None
    from mvp.brain import verify as V
    rowmk = [mk for mk in markers if mk.kind in ("row", "value") and mk.owner and mk.rid == res.rid]
    fr = LIST_FRAME.search(text)
    if not fr or not rowmk:
        return None
    after = [mk for mk in rowmk if mk.start >= fr.end()]
    if not after or any(mk.start < fr.start() for mk in rowmk if V._list_and_index(mk.owner)[0] ==
                        V._list_and_index(after[0].owner)[0]):
        return None
    lst = V._list_and_index(after[0].owner)[0]
    ix = {V._list_and_index(mk.owner)[1] for mk in rowmk if V._list_and_index(mk.owner)[0] == lst}
    rows = _rows(res, lst)
    if len(ix) >= 2 and rows and len(ix) < len(rows):
        return "list_incomplete"
    return None


def r_rest(ctx):
    """'the other N', 'the rest': N plus a count cited elsewhere in the answer is the result's total (B14 class)."""
    plain, markers, res = ctx["plain"], ctx["markers"], ctx["res"]
    m = REST.search(plain)
    if not m or res is None:
        return None
    tot = ((res.sheet or {}).get("totals") or {}).get("items")
    nums = [mk.value for mk in markers if mk.kind == "value" and isinstance(mk.value, (int, float))
            and not isinstance(mk.value, bool)]
    if not isinstance(tot, (int, float)) or not nums:
        return None
    others = [v for v in ctx.get("answer_counts", []) if isinstance(v, (int, float))]
    if any(abs(n + o - tot) < 0.5 for n in nums for o in others):
        return None
    return "rest_sum"


def r_persist(ctx):
    """'still', 'ever', 'all-time', 'no longer': a claim across two windows code did not count (F05.0's 'still')."""
    return "persist_word" if PERSIST.search(ctx["plain"]) else None


def r_new(ctx):
    """'new': the rows cited are rows of a new list (K03.0 cited r3.channels as new)."""
    plain, markers = ctx["plain"], ctx["markers"]
    if not NEW.search(plain):
        return None
    rows = [mk for mk in markers if mk.kind in ("row", "value") and mk.owner]
    if rows and any(not re.search(r"(?:^|\.)(?:new|since_new|arrived)\b", mk.owner) for mk in rows):
        return "new_list"
    return None


def r_base(ctx):
    """A base phrase written by the model on a share of a scoped result, or of a list inside a row or a period
    (F05.0's '51% of what you opened' of gaming only): the base is code's to write."""
    plain, markers, res = ctx["plain"], ctx["markers"], ctx["res"]
    if res is None or not BASE_PH.search(plain):
        return None
    shares = [mk for mk in markers if mk.kind == "value" and "share" in (mk.key or "")]
    if not shares:
        return None
    scoped = bool((res.meta or {}).get("filters_said"))
    inner = any(re.search(r"\]\.(?:themes|channels|areas)\[", mk.rest or "") for mk in shares)
    if (scoped or inner) and not ctx["compliant"]:
        return "base_phrase"
    if (scoped or inner) and ctx["compliant"] and ctx.get("bad_base"):
        return "base_phrase"
    return None


def r_time(ctx):
    """A time phrase the model wrote in a point (or in a lead, past its opening): code writes the window. Allowed:
    a period cell's own label next to it, a date cell's own words. compliant=True: the phrase is taken as code's slot
    when the recount found the sentence true of its cells' own windows (the record-states-meaning bound)."""
    text, plain, markers = ctx["text"], ctx["plain"], ctx["markers"]
    body = plain
    if ctx["where"] == "lead":
        body = plain.split(",", 1)[1] if "," in plain else ""
    hits = [m for m in TIME.finditer(body)]
    if not hits:
        return None
    if ctx["compliant"]:
        return "time_phrase" if ctx.get("bad_window") else None
    # period labels and date cells: their own words
    allowed = set()
    for mk in markers:
        if mk.kind == "value" and isinstance(mk.value, str) and re.search(r"\d{4}", mk.value):
            allowed |= {w.lower() for w in re.findall(r"\w+", mk.said or "")}
        if mk.kind == "value" and re.search(r"(?:^|\.)periods\[\d+\]", mk.rest or ""):
            allowed |= {w.lower() for w in re.findall(r"\w+", text[max(0, mk.mstart - 40):mk.end + 25])}
    for m in hits:
        if m.group(0).lower() not in allowed and not all(w.lower() in allowed for w in re.findall(r"\w+", m.group(0))):
            return "time_phrase"
    return None


RULES = [("rank", r_rank), ("level", r_level), ("list", r_list), ("rest", r_rest), ("persist", r_persist),
         ("new", r_new), ("base", r_base), ("time", r_time)]


def check(text, ledger, where, prev_level, answer_counts, compliant, bad_window=False, bad_base=False,
          bad_list=False):
    from mvp.brain import verify as V
    raw = " ".join(str(text or "").split())
    markers, _bad = V.parse(raw, ledger)
    rids = sorted({mk.rid for mk in markers if mk.rid})
    res = ledger.get(rids[0]) if rids else None
    ctx = {"text": raw, "plain": V.strip_markers(raw), "markers": markers, "res": res, "where": where,
           "rank_mk": _rank_marker(markers), "prev_level": prev_level, "answer_counts": answer_counts,
           "compliant": compliant, "bad_window": bad_window, "bad_base": bad_base, "bad_list": bad_list}
    out = []
    for name, f in RULES:
        try:
            r = f(ctx)
        except Exception as e:  # noqa: BLE001
            r = "rule_error:" + type(e).__name__
        if r:
            out.append(r)
    mk = ctx["rank_mk"]
    lvl = None
    if mk is not None and (RANK_MOST.search(ctx["plain"]) or RANK_LEAST.search(ctx["plain"]) or
                           NEXT.search(ctx["plain"])):
        lvl = _level(V._list_and_index(mk.owner)[0])
    return out, lvl, [mk.value for mk in markers if mk.kind == "value" and isinstance(mk.value, (int, float))
                      and not isinstance(mk.value, bool)]
