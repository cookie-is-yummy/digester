"""Speed and form size from the look 1 records (requests[].seconds and usage), and the time a candidate would save or
add: an answer whose first form needs no repair under the candidate loses its repair request; a bigger form adds
output tokens at the measured seconds per output token of give_answer requests. Estimates, not measurements."""
import glob
import json
import os
import statistics as st

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
D = os.path.join(S, "mvp20/tune/heldout")
sim = json.load(open(os.path.join(HERE, "sim.json")))
c5 = json.load(open(os.path.join(HERE, "c5tally_all.json")))
c5raw = json.load(open(os.path.join(HERE, "c5_all.json")))

recs = []
for p in sorted(glob.glob(os.path.join(D, "*.json"))):
    if p.endswith("summary.json"):
        continue
    recs.append(json.load(open(p)))


def ga_requests(r):
    out = []
    for q in r["requests"]:
        if any(b.get("name") == "give_answer" for b in q.get("blocks") or [] if isinstance(b, dict)):
            out.append(q)
    return out


tot = [r["seconds"] for r in recs]
nreq = [r["n_requests"] for r in recs]
rep = [r for r in recs if len(r.get("forms") or []) > 1]
ga = [q for r in recs for q in ga_requests(r)]
sec_per_out = [q["seconds"] / max(1, q["usage"]["output_tokens"]) for q in ga if q["usage"]["output_tokens"] > 50]
ga_out = [q["usage"]["output_tokens"] for q in ga]
form_chars = [len(json.dumps(f)) for r in recs for f in (r.get("forms") or [])[:1]]
inp = [q["usage"].get("input_tokens", 0) + q["usage"].get("cache_read_input_tokens", 0) +
       q["usage"].get("cache_creation_input_tokens", 0) for r in recs for q in r["requests"][:1]]
lines = [f"look 1: {len(recs)} messages; seconds median {st.median(tot):.2f}, p90 {sorted(tot)[int(0.9 * len(tot)) - 1]:.2f}",
         f"requests per message: median {st.median(nreq)}, mean {st.mean(nreq):.2f}; answers with a repair form: {len(rep)}",
         f"give_answer requests: {len(ga)}, output tokens median {st.median(ga_out)}, seconds per output token median "
         f"{st.median(sec_per_out):.4f}",
         f"first form size: median {st.median(form_chars)} characters of JSON; prompt (first request input, cached "
         f"included): median {st.median(inp)} tokens"]


def repair_seconds(r):
    """The seconds of the requests after the first give_answer (the repair round)."""
    seen, s = False, 0.0
    for q in r["requests"]:
        if seen:
            s += q["seconds"]
        if any(b.get("name") == "give_answer" for b in q.get("blocks") or [] if isinstance(b, dict)):
            seen = True
    return s


def sim_median(repair_due_keys, extra_tokens=0, extra_requests_s=0.0):
    out = []
    for r in recs:
        t = r["seconds"]
        if len(r.get("forms") or []) > 1 and r["key"] not in repair_due_keys:
            t -= repair_seconds(r)
        if len(r.get("forms") or []) == 1 and r["key"] in repair_due_keys:
            t += st.median([repair_seconds(x) for x in rep]) if rep else 0
        n_ga = 1 + (r["key"] in repair_due_keys)
        t += n_ga * extra_tokens * st.median(sec_per_out) + extra_requests_s
        out.append(t)
    return st.median(out), sorted(out)[int(0.9 * len(out)) - 1]


def due_from_sim(cfg):
    return {r["key"] for r in sim[cfg]["heldout"] if r["set"] == "look1" and r["form_index"] == 0 and r["repair"]}


def due_from_c5(tag):
    rows = [r for r in c5raw[tag]["heldout"] if r["set"] == "look1" and r["form_index"] == 0]
    keys = {r["key"] for r in rows}
    out = set()
    for k in keys:
        rs = [r for r in rows if r["key"] == k]
        lead_ok = all(r["kept"] for r in rs if r["where"] == "lead")
        failed = sum(1 for r in rs if not r["kept"])
        if not lead_ok or failed * 2 > len(rs):
            out.add(k)
    return out


res = {}
for name, due, extra in (("as run (recorded)", {r["key"] for r in rep}, 0), ("C0 today", due_from_sim("C0"), 0),
                         ("C1a", due_from_sim("C1a"), 0), ("C1d", due_from_sim("C1d"), 0),
                         ("C2/C5 M, record +60 tokens per sentence", due_from_c5("C5_C1a_M"), 180),
                         ("C5 H, record +60 tokens per sentence", due_from_c5("C5_C1a_H"), 180),
                         ("C5 H, compact record +25 tokens per sentence", due_from_c5("C5_C1a_H"), 75)):
    m, p90 = sim_median(due, extra)
    res[name] = {"repairs": len(due), "median_s": round(m, 2), "p90_s": round(p90, 2)}
    lines.append(f"{name}: repairs {len(due)} of {len(recs)}, median {m:.2f} s, p90 {p90:.2f} s")
# C4: one more small-model request after the answer form (no repair counted beyond C1a's)
m, p90 = sim_median(due_from_sim("C1a"), 0, extra_requests_s=1.6)
lines.append(f"C4 (C1a + one framing read of ~1.6 s, the median non-answer request): median {m:.2f} s, p90 {p90:.2f} s")
oth = [q["seconds"] for r in recs for q in r["requests"] if q not in ga_requests(r)]
lines.append(f"median seconds of a request that is not give_answer: {st.median(oth):.2f}; of give_answer: "
             f"{st.median([q['seconds'] for q in ga]):.2f}")
json.dump(res, open(os.path.join(HERE, "speed.json"), "w"), indent=1)
open(os.path.join(HERE, "speed.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
