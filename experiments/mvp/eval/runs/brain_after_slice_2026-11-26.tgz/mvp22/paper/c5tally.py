"""Counts for c5_<which>.json, the same lines as tally.py. python3 c5tally.py look1|all"""
import json
import os
import re
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
which = sys.argv[1] if len(sys.argv) > 1 else "look1"
d = json.load(open(os.path.join(HERE, f"c5_{which}.json")))
lab = json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))
LAB = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in lab}
lines = [f"frame.py sha256 {d['frame_sha256']}"]
res = {}
for tag, o in d.items():
    if tag == "frame_sha256":
        continue
    res[tag] = {}
    for look in ("look1", "look2"):
        rows = [r for r in o["heldout"] if r["set"] == look and r["form_index"] == 0]
        if not rows:
            continue
        c = Counter()
        outs, lost_frame = [], []
        for r in rows:
            L = LAB.get((look, r["key"], 0, r["where"], r["index"]))
            if not L or L["truth"] == "no_claim":
                continue
            if L["truth"] in ("wrongly_based", "false"):
                c["bad"] += 1
                if r["kept"]:
                    c["bad_out"] += 1
                    outs.append(f"{r['key']} {r['where']}{r['index']}: {L['text'][:110]}")
            elif L["truth"] == "true":
                c["true"] += 1
                if not r["kept"]:
                    c["true_lost"] += 1
                    if r["cells_kept"]:
                        c["true_lost_by_frame"] += 1
                        lost_frame.append(f"{r['key']} {r['where']}{r['index']} {r['frame']}: {L['text'][:100]}")
        leads = [r for r in rows if r["where"] == "lead" and r["index"] == 0]
        leadk = {}
        for r in rows:
            if r["where"] == "lead":
                leadk.setdefault(r["key"], True)
                leadk[r["key"]] &= r["kept"]
        c["answers"] = len(leads)
        c["lead_kept"] = sum(leadk.values())
        # repair due: the lead failed, or more than half of the sentences
        rep = 0
        for key in leadk:
            rs = [r for r in rows if r["key"] == key]
            failed = sum(1 for r in rs if not r["kept"])
            rep += (not leadk[key]) or failed * 2 > len(rs)
        c["repair_due"] = rep
        res[tag][look] = dict(c)
        lines.append(f"== {tag} {look} first: bad out {c['bad_out']}/{c['bad']}, true lost {c['true_lost']}/{c['true']}"
                     f" (by frame rules {c['true_lost_by_frame']}), lead kept {c['lead_kept']}/{c['answers']}, repair"
                     f" due {rep}/{c['answers']}")
        lines += ["    OUT " + x for x in outs]
        lines += ["    LOST " + x for x in lost_frame]
    if o.get("planted"):
        pl = o["planted"]
        sent = {}
        for r in pl:
            if r["set"] == "attack":
                sid = re.sub(r"_(?:L|P)$", "", r["id"])
                sent[sid] = sent.get(sid, False) or r["kept"]
        at = [r for r in pl if r["set"] == "attack_true"]
        au = [r for r in pl if r["set"] == "audit_true"]
        fr = Counter(x for r in pl if r["set"] == "attack" and r["cells_kept"] for x in r["frame"])
        data = json.load(open("/home/user/digester/experiments/mvp/eval/brain_planted.json"))
        cls = {c["id"]: (c.get("class") or "").split(":")[0] for c in data["cases"]}
        # the frame slot: a lead's opening window phrase is replaced by code's, and a point on another result gets
        # its window from code: those false sentences go out corrected (judged by class, read one by one in the write-up)
        corr = sorted(k for k, v in sent.items() if v and cls.get("attack_" + k.split("_", 1)[1] if False else k) in
                      ("lead_window", "two_results"))
        res[tag]["planted"] = None
        res[tag]["planted"] = {"attack_false_out": sum(sent.values()), "attack_false": len(sent),
                               "attack_false_out_corrected_by_slot": len(corr),
                               "attack_false_out_classes": dict(Counter(cls.get(k) for k, v in sent.items() if v)),
                               "attack_true_kept": sum(r["kept"] for r in at), "attack_true": len(at),
                               "audit_true_kept": sum(r["kept"] for r in au), "audit_true": len(au)}
        lines.append(f"== {tag} attack false out {sum(sent.values())}/{len(sent)}, attack true kept "
                     f"{sum(r['kept'] for r in at)}/{len(at)}, audit true kept {sum(r['kept'] for r in au)}/{len(au)}"
                     f" (of the false out, {len(corr)} are lead-window or other-result sentences the frame slot corrects)"
                     f"; frame reasons on attack false the cells kept: {dict(fr)}")
        lines += ["    TRUE LOST BY FRAME " + f"{r['id']} {r['frame']}" for r in at + au
                  if r["cells_kept"] and not r["kept"]]
json.dump(res, open(os.path.join(HERE, f"c5tally_{which}.json"), "w"), indent=1)
open(os.path.join(HERE, f"c5tally_{which}.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
