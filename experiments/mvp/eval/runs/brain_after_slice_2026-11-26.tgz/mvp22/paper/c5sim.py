"""C5 = C1's cell, marker, name, calc and policy checks (sim.json, setting C1a or C1d) + frame.py's closed rules.
    python3 c5sim.py look1            (development: the set the rules were written from)
    python3 c5sim.py all              (after frame.sha256 is written: look2, attack, audit too)
A sentence goes out when the C1 setting keeps it and frame.py refuses nothing. Two bounds (frame.py's docstring):
compliant=False (today's wording, record copied from meta) is code only; compliant=True uses the recounter's fault
labels for window and base faults (the record-states-meaning assumption): judged, not measured."""
import glob
import hashlib
import importlib.util
import json
import os
import re
import sys
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, "/home/user/digester/experiments")
sys.path.insert(0, HERE)
from mvp.brain import verify as V  # noqa: E402  (parse and helpers only; no check is run with it)
from mvp.brain import planted as P  # noqa: E402
import frame as F  # noqa: E402

LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
sim = json.load(open(os.path.join(HERE, "sim.json")))
lab = json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))
LAB = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in lab}
WIN_FAULT = re.compile(r"\bwindow\b|scope|'new'|not opened in 2024|30 days", re.I)
BASE_FAULT = re.compile(r"\bbase\b", re.I)
LIST_FAULT = re.compile(r"complete|only/all|incomplete", re.I)
# attack classes whose fault is the window or the base said (the record would state it, code would compare)
ATT_WIN = {"change_period", "period_label", "lead_window", "move_frame", "compare_frame", "from_to", "pct", "fell_into",
           "hour", "dates"}
ATT_LIST = {"private", "cut_count", "share_sum", "least"}
ATT_BASE = {"of_videos_frame", "platform", "scope_words", "waiver", "base_verbs", "bare_clause"}
# not a field of the record (left to C1's cell and policy checks): motive, outside, outside_theme, number_word, title,
# two_results, measure, owner, find, calc_rows


def sha():
    return hashlib.sha256(open(os.path.join(HERE, "frame.py"), "rb").read()).hexdigest()


def form_sentences(form):
    lead = V._split(form.get("lead") or "")
    out = [("lead", k, s) for k, s in enumerate(lead)]
    for k, p in enumerate(form.get("points") or []):
        out.append(("point", k, p))
    return out


def run_form(form, ledger, cells_kept, labels, compliant):
    """cells_kept: {(where, index): kept by the C1 setting}; labels: {(where, index): label row or None}."""
    sents = form_sentences(form)
    counts = []
    for _w, _k, s in sents:
        mks, _b = V.parse(" ".join(s.split()), ledger)
        counts += [mk.value for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                   and not isinstance(mk.value, bool)]
    out, prev = {}, None
    for w, k, s in sents:
        L = labels.get((w, k))
        fault = (L or {}).get("fault") or ""
        bw = bool(L and L["truth"] in ("wrongly_based", "false") and WIN_FAULT.search(fault))
        bb = bool(L and L["truth"] in ("wrongly_based", "false") and BASE_FAULT.search(fault))
        bl = bool(L and L["truth"] in ("wrongly_based", "false") and LIST_FAULT.search(fault))
        rs, lvl, mine_counts = F.check(s, ledger, w, prev, [], compliant, bw, bb, bl)
        others = list(counts)
        for v in mine_counts:
            if v in others:
                others.remove(v)
        rs, lvl, _ = F.check(s, ledger, w, prev, others, compliant, bw, bb, bl)
        if compliant and (bw or bb or bl):
            rs = rs + ["record_mismatch"]   # the H bound: the record states the meaning; code compares it exactly
        kept = bool(cells_kept.get((w, k), False)) and not rs
        out[(w, k)] = (kept, rs)
        if cells_kept.get((w, k), False):
            prev = lvl or prev
    return out


def heldout(look, base_cfg, compliant):
    from mvp import eval_brain as E  # noqa: F401
    cells = {(r["key"], r["form_index"], r["where"], r["index"]): r for r in sim[base_cfg]["heldout"]
             if r["set"] == look}
    rows = []
    for p in sorted(glob.glob(os.path.join(LOOKS[look], "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        led = V.Ledger(results)
        for fi, form in enumerate(rec.get("forms") or []):
            ck = {(w, i): cells[(rec["key"], fi, w, i)]["kept"] for (k_, f_, w, i) in cells
                  if k_ == rec["key"] and f_ == fi}
            labels = {(w, i): LAB.get((look, rec["key"], fi, w, i)) for (w, i) in ck}
            res = run_form(form, led, ck, labels, compliant)
            for (w, i), (kept, rs) in res.items():
                rows.append({"set": look, "key": rec["key"], "form_index": fi, "where": w, "index": i, "kept": kept,
                             "frame": rs, "cells_kept": ck.get((w, i))})
    return rows


def planted(base_cfg, compliant):
    data = P.load()
    cells = {r["id"]: r for r in sim[base_cfg]["planted"]}
    rows = []
    for c in data["cases"]:
        if c.get("source") not in ("attack", "attack_true", "audit_true"):
            continue
        led = V.Ledger(data["ledgers"][c["ledger"]])
        cls = (c.get("class") or "").split(":")[0]
        bad = c["source"] == "attack"
        bw, bb = bad and cls in ATT_WIN, bad and cls in ATT_BASE
        bl = bad and cls in ATT_LIST
        best = None
        for f in (c.get("forms") or [c["form"]]):
            tgt = c.get("target") or "point:0"
            where = "lead" if tgt.startswith("lead") else "point"
            sents = form_sentences(f)
            counts = []
            for _w, _k, s in sents:
                mks, _b = V.parse(" ".join(s.split()), led)
                counts += [mk.value for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                           and not isinstance(mk.value, bool)]
            prev = None
            got = None
            for w, k, s in sents:
                rs, lvl, mine = F.check(s, led, w, prev, [], compliant, bw if w == where else False,
                                        bb if w == where else False, bl if w == where else False)
                others = list(counts)
                for v in mine:
                    if v in others:
                        others.remove(v)
                rs, lvl, _ = F.check(s, led, w, prev, others, compliant, bw if w == where else False,
                                     bb if w == where else False, bl if w == where else False)
                if w == where and (where == "lead" or k == int(tgt.split(":")[1] if ":" in tgt else 0)):
                    got = rs
                prev = lvl or prev
            got = list(got or [])
            if compliant and (bw or bb or bl):
                got.append("record_mismatch")
            r = (not got, got)
            if best is None or (r[0] and not best[0]):
                best = r
        kept = bool(cells[c["id"]]["kept"]) and best[0]
        if c["expect"] == "private_line" and cells[c["id"]]["private_line"]:
            kept = False
        rows.append({"set": c["source"], "id": c["id"], "kept": kept, "frame": best[1],
                     "cells_kept": cells[c["id"]]["kept"]})
    return rows


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "look1"
    if which == "all":
        frozen = open(os.path.join(HERE, "frame.sha256")).read().split()[0]
        assert frozen == sha(), "frame.py changed after it was frozen"
    out = {"frame_sha256": sha()}
    for base in ("C1a", "C1d"):
        for comp in (False, True):
            tag = f"C5_{base}_{'H' if comp else 'M'}"
            o = {"heldout": heldout("look1", base, comp)}
            if which == "all":
                o["heldout"] += heldout("look2", base, comp)
                o["planted"] = planted(base, comp)
            out[tag] = o
            print(tag, "done")
    json.dump(out, open(os.path.join(HERE, f"c5_{which}.json"), "w"), indent=0)
