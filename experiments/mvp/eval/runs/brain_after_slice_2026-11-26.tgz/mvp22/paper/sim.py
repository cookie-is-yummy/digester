"""Run today's checker (C0) and the cells-only checker (C1, four settings) on the held-out forms (both looks) and the
planted attack and audit sets. The checker is paper/src/verify_c1.py (make_c1.py), loaded in place of nothing: the
repo's own verify.py is untouched. Writes sim.json. No model call."""
import glob
import importlib.util
import json
import os
import sys
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, "/home/user/digester/experiments")
sys.path.insert(0, HERE)
import taxonomy as T  # noqa: E402
import mvp.brain  # noqa: E402,F401
from mvp.brain import planted as P  # noqa: E402

spec = importlib.util.spec_from_file_location("mvp.brain.verify_c1", os.path.join(HERE, "src", "verify_c1.py"))
V = importlib.util.module_from_spec(spec)
V.__package__ = "mvp.brain"
sys.modules["mvp.brain.verify_c1"] = V
spec.loader.exec_module(V)

LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
CONFIGS = {
    "C0": (set(), "on"),
    "C1a": (T.off_set(False), "on"),
    "C1b": (T.off_set(True), "on"),
    "C1c": (T.off_set(False), "off"),
    "C1d": (T.off_set(True), "off"),
}


def setcfg(name):
    off, ins = CONFIGS[name]
    V.OFF.clear()
    V.OFF.update(off)
    V.INSIGHT = ins


def heldout_inputs(h):
    out = []
    for look, d in LOOKS.items():
        for p in sorted(glob.glob(os.path.join(d, "*.json"))):
            if p.endswith("summary.json"):
                continue
            rec = json.load(open(p))
            t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
            vt = V.Turn.of(t)
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                       and not c["result"].get("is_error")}
            out.append((look, rec, vt, results))
    return out


def run_heldout(inputs):
    rows = []
    for look, rec, vt, results in inputs:
        for fi, form in enumerate(rec.get("forms") or []):
            v = V.check_answer(form, results, vt)
            for o in v.outcomes:
                rows.append({"set": look, "key": rec["key"], "form_index": fi, "where": o.where, "index": o.index,
                             "kept": o.kept, "reasons": list(o.reasons), "hidden_rank": o.hidden_rank,
                             "private_line": v.private_line, "lead_ok": v.lead_ok, "repair": v.repair})
    return rows


def planted_one(case, ledgers, form):
    led = V.Ledger(ledgers[case["ledger"]])
    t = case.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    turn = V.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today, names=list(t.get("names") or []),
                  sensitive_names=list(t.get("sensitive_names") or []))
    v = V.check_answer(form, led, turn)
    tgt = case.get("target") or "point:0"
    kind, _, n = tgt.partition(":")
    if kind == "lead":
        os_ = [o for o in v.outcomes if o.where == "lead"]
        return bool(os_) and all(o.kept for o in os_), sorted({r for o in os_ for r in o.reasons}), v.private_line
    o = next((o for o in v.outcomes if o.where == kind and o.index == int(n or 0)), None)
    return bool(o and o.kept), (list(o.reasons) if o else ["missing"]), v.private_line


def run_planted(data):
    rows = []
    for c in data["cases"]:
        if c.get("source") not in ("attack", "attack_true", "audit_true"):
            continue
        best = None
        for f in (c.get("forms") or [c["form"]]):
            r = planted_one(c, data["ledgers"], f)
            if best is None or (r[0] and not best[0]):
                best = r
        rows.append({"set": c["source"], "id": c["id"], "expect": c["expect"], "kept": best[0], "reasons": best[1],
                     "private_line": best[2]})
    return rows


if __name__ == "__main__":
    from mvp import eval_brain as E
    base = os.path.join(HERE, "_lib")
    if os.path.isdir(base):
        import shutil
        shutil.rmtree(base)
    os.makedirs(base)
    h = E.Harness.scratch(base=base)
    inputs = heldout_inputs(h)
    data = P.load()
    out = {}
    for name in CONFIGS:
        setcfg(name)
        out[name] = {"heldout": run_heldout(inputs), "planted": run_planted(data)}
        print(name, "done")
    setcfg("C0")
    json.dump(out, open(os.path.join(HERE, "sim.json"), "w"), indent=0, default=str)
    # the copy with nothing switched off must be today's checker, row for row
    ref = json.load(open(os.path.join(HERE, "outcomes.json")))["heldout"]
    c0 = out["C0"]["heldout"]
    same = sum(1 for a, b in zip(ref, c0) if a["kept"] == b["kept"] and sorted(a["reasons"]) == sorted(b["reasons"]))
    print("C0 copy vs today's verify.py, held-out rows:", same, "of", len(ref), len(c0))
    pref = {r["id"]: r for r in json.load(open(os.path.join(HERE, "outcomes.json")))["planted"]}
    pc0 = out["C0"]["planted"]
    same_p = sum(1 for r in pc0 if any(f["kept"] == r["kept"] for f in pref[r["id"]]["forms"]) and
                 (r["kept"] == any(f["kept"] for f in pref[r["id"]]["forms"])))
    print("C0 copy vs today's verify.py, planted rows:", same_p, "of", len(pc0))
