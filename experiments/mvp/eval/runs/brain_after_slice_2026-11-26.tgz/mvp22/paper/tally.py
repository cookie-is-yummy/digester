"""Counts from sim.json and the recounter's labels (raw/sentences.json). Writes tally.json and tally.txt."""
import json
import os
import re
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
sim = json.load(open(os.path.join(HERE, "sim.json")))
lab = json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))
LAB = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in lab}
BAD = ("wrongly_based", "false")
out, lines = {}, []


def p(*a):
    lines.append(" ".join(str(x) for x in a))


def held(cfg, look, first_only=True):
    rows = [r for r in sim[cfg]["heldout"] if r["set"] == look and (r["form_index"] == 0 or not first_only)]
    j = []
    for r in rows:
        L = LAB.get((look, r["key"], r["form_index"], r["where"], r["index"]))
        if L is None:
            continue
        j.append((r, L))
    return j


def held_stats(cfg, look):
    j = held(cfg, look)
    c = Counter()
    bad_out, true_lost = [], []
    for r, L in j:
        t = L["truth"]
        if t == "no_claim":
            c["no_claim"] += 1
            continue
        if t in BAD:
            c["bad"] += 1
            if r["kept"]:
                c["bad_kept"] += 1
                bad_out.append(f'{r["key"]} {r["where"]}{r["index"]} pl={r["private_line"]}: {L["text"][:150]}')
        elif t == "true":
            c["true"] += 1
            if not r["kept"]:
                c["true_lost"] += 1
                true_lost.append((r["key"], r["where"], r["index"], r["reasons"]))
        else:
            c[t] += 1
            c[t + "_kept"] += r["kept"]
    forms = {}
    for r, _L in j:
        forms.setdefault(r["key"], r)
    leads = [r for r in sim[cfg]["heldout"] if r["set"] == look and r["form_index"] == 0 and r["where"] == "lead"
             and r["index"] == 0]
    c["answers"] = len(leads)
    c["lead_kept_first"] = sum(1 for r in leads if r["lead_ok"])
    c["repair_due"] = sum(1 for r in leads if r["repair"])
    return c, bad_out, true_lost


def recorded_stats(look):
    c = Counter()
    for L in lab:
        if L["look"] != look or L["form"] != "first":
            continue
        t = L["truth"]
        if t == "no_claim":
            continue
        if t in BAD:
            c["bad"] += 1
            c["bad_kept"] += bool(L["verifier_kept"])
        elif t == "true":
            c["true"] += 1
            c["true_lost"] += not L["verifier_kept"]
    return c


def planted_stats(cfg):
    rows = sim[cfg]["planted"]
    c = Counter()
    # attack false: per sentence (the 3 'B' cases are tried as lead and as point: out if either keeps it)
    sent = {}
    for r in rows:
        if r["set"] != "attack":
            continue
        sid = re.sub(r"_(?:L|P)$", "", r["id"])
        out_ = r["kept"] and not (r["expect"] == "private_line" and r["private_line"])
        sent[sid] = sent.get(sid, False) or out_
    c["attack_false"] = len(sent)
    c["attack_false_out"] = sum(sent.values())
    at = [r for r in rows if r["set"] == "attack_true"]
    c["attack_true"] = len(at)
    c["attack_true_kept"] = sum(r["kept"] for r in at)
    au = [r for r in rows if r["set"] == "audit_true"]
    c["audit_true"] = len(au)
    c["audit_true_kept"] = sum(r["kept"] for r in au)
    outs = sorted(k for k, v in sent.items() if v)
    return c, outs


for look in ("look1", "look2"):
    rc = recorded_stats(look)
    p(f"== {look} first forms, recorded verdicts as run: bad kept {rc['bad_kept']}/{rc['bad']}, true lost "
      f"{rc['true_lost']}/{rc['true']}")
    out[f"recorded_{look}"] = dict(rc)
for cfg in sim:
    o = {}
    for look in ("look1", "look2"):
        c, bad_out, lost = held_stats(cfg, look)
        o[look] = dict(c)
        o[look + "_bad_out"] = bad_out
        o[look + "_true_lost"] = lost
        p(f"== {cfg} {look} first: bad kept {c['bad_kept']}/{c['bad']}, true lost {c['true_lost']}/{c['true']}, "
          f"cannot_prove kept {c.get('cannot_prove_kept', 0)}/{c.get('cannot_prove', 0)}; lead kept first "
          f"{c['lead_kept_first']}/{c['answers']}, repair due {c['repair_due']}/{c['answers']}")
        for b in bad_out:
            p("    OUT", b)
        rs = Counter(x for _k, _w, _i, rr in lost for x in rr)
        p("    true lost by reason:", dict(rs.most_common(12)))
    c, outs = planted_stats(cfg)
    o["planted"] = dict(c)
    o["attack_false_out_ids"] = outs
    p(f"== {cfg} attack false out {c['attack_false_out']}/{c['attack_false']}, attack true kept "
      f"{c['attack_true_kept']}/{c['attack_true']}, audit true kept {c['audit_true_kept']}/{c['audit_true']}")
    out[cfg] = o
json.dump(out, open(os.path.join(HERE, "tally.json"), "w"), indent=1)
open(os.path.join(HERE, "tally.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
