"""Copy today's verify.py into paper/src/verify_c1.py with switches (no rule added; rules only switched off):
  OFF: a set of reason codes that are never added (check_sentence's add, the lead's window rule, the points' binding
       to the lead); INSIGHT: "on" (insight's codes in OFF ignored: its first reason only, so a framing code first can
       hide a later cell code), or "off" (insight's step not run at all).
With OFF empty and INSIGHT "on", the copy is today's checker (checked row for row in sim.py)."""
import os

SRC = "/home/user/digester/experiments/mvp/brain/verify.py"
HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "src", "verify_c1.py")

s = open(SRC, encoding="utf-8").read()


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (old, s.count(old))
    s = s.replace(old, new)


sub('VERIFY_VERSION = "brain_verify_v1"',
    'VERIFY_VERSION = "brain_verify_v1"\nOFF = set()      # paper test: codes never added\nINSIGHT = "on"   # paper test')
sub("""    def add(r, d=None):
        if r not in fail:""",
    """    def add(r, d=None):
        if r in OFF or str(r).split(":")[0] in OFF:
            return
        if r not in fail:""")
sub('''def insight_check(raw, markers, plain_names, cited_names, res, where, unlock=None):
    """None or (reason, detail): the sentence through insight's own checks against the cited result's sheet."""''',
    '''def insight_check(raw, markers, plain_names, cited_names, res, where, unlock=None):
    """paper test wrapper"""
    if INSIGHT == "off":
        return None
    why = _insight_check0(raw, markers, plain_names, cited_names, res, where, unlock)
    if why and (why[0] in OFF or str(why[0]).split(":")[0] in OFF):
        return None
    return why


def _insight_check0(raw, markers, plain_names, cited_names, res, where, unlock=None):
    """None or (reason, detail): the sentence through insight's own checks against the cited result's sheet."""''')
sub('''    lead_os = [o for o in v.outcomes if o.where == "lead"]
    lead_ok = bool(lead_os) and all(o.kept for o in lead_os)
    lead_rows = set()''',
    '''    if "rank" in OFF and "window_missing" in OFF:
        return
    lead_os = [o for o in v.outcomes if o.where == "lead"]
    lead_ok = bool(lead_os) and all(o.kept for o in lead_os)
    lead_rows = set()''')
sub('''    if lead_os and all(o.kept for o in lead_os):
        rid = next((o.rid for o in lead_os if o.rid), None)
        if not _lead_names_window(f.lead, ledger, rid):''',
    '''    if lead_os and all(o.kept for o in lead_os) and "window_missing" not in OFF:
        rid = next((o.rid for o in lead_os if o.rid), None)
        if not _lead_names_window(f.lead, ledger, rid):''')
os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, "w", encoding="utf-8").write(s)
print("wrote", OUT)
