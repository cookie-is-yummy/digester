"""Which of today's reason codes are framing rules (switched off in C1) and which are cell, marker, name, calculation
or policy checks (kept on). Written before any C1 count was made. DOUBT holds the codes whose placement can be argued;
C1 is run with them on and with them off, and both figures are reported."""

# cell, marker, name and calculation checks: the number, the name, the date or the sum the sentence cites
CELL = {
    "bad_marker", "bad_ref", "two_results", "uncited_number", "free_number", "number", "wrong_value", "date",
    "wrong_measure", "count_as_share", "count_of_videos", "wrong_name", "typed_name", "bound_to_other", "calc", "ratio",
    "made_up_difference", "unknown_name", "uncited_name", "other_name", "wrong_group", "wrong_area",
    "channel_not_in_theme", "not_item", "link", "about_not_cited", "source", "marker", "repeat", "garbled",
    "too_long", "language", "point_text", "insight_error",
}
# policy: what a history sentence may hold at all (not framing): outside knowledge, feelings, outcomes, watch time,
# sensitive topics, filler, talk of the system's limits
POLICY = {"outside_in_history", "psych", "outcome", "sensitive", "watch_time", "filler", "second_person",
          "generic_claim", "weak_fit"}
# framing: window, base, scope, direction words, only/all, rank and level, completeness, private totals
FRAMING = {
    "wrong_window", "window_missing", "filter_dropped", "scope_broadened", "base", "base_missing", "no_base",
    "insight_rewrite", "rank", "not_top", "tie", "least", "spread", "mostly", "mix", "previous",
    "direction_unbound", "no_direction", "small_move", "vague", "one_value", "first_last", "private_total",
    "platform_word", "length_word", "shorts_left_out", "own_shorts_share", "shorts_as_long", "share_of_topic",
    "weekpart", "weekday", "year", "hour", "time_of_day", "not_close", "not_new", "not_stopped", "order",
    "gap_words", "median_of_window", "number_run",
}
# arguable placements: run both ways
DOUBT = {
    "direction": "the sign of a move against its own cell: a cell check; but it reads direction words (framing)",
    "uncited_claim": "a claim with no marker: marker bookkeeping; from _bare_clause it is a clause-scope rule",
    "limits": "policy (code writes limits lines); the I02 and K04 self-talk rule was added from held-out sentences",
    "unnamed_owner": "a number with no row name beside it: binding (cell) or framing of whose number it is",
    "bound_global": "a total said next to a row name: binding (cell) or base (framing)",
}


def klass(code):
    c = str(code).split(":")[0]
    if code.startswith("name:") or code.startswith("word:"):
        return "cell"
    if c in DOUBT:
        return "doubt"
    if c in CELL:
        return "cell"
    if c in POLICY:
        return "policy"
    if c in FRAMING:
        return "framing"
    return "unknown"


def off_set(doubt_off):
    """The codes C1 switches off: every framing code, and the doubtful ones when doubt_off."""
    return set(FRAMING) | (set(DOUBT) if doubt_off else set())
