"""C2's lower bound (record copied from meta, model writes its own frame words): C5_M's rows with the two rules that
refuse model-written frame words (time_phrase, base_phrase) taken out; the contradiction words stay."""
import json, os, re
from collections import Counter
HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
d = json.load(open(os.path.join(HERE, "c5_all.json")))
lab = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))}
OFFR = {"time_phrase", "base_phrase"}
out = {}
for base in ("C1a", "C1d"):
    o = d[f"C5_{base}_M"]
    res = {}
    for look in ("look1", "look2"):
        c = Counter(); outs = []
        rows = [r for r in o["heldout"] if r["set"] == look and r["form_index"] == 0]
        leadk = {}
        for r in rows:
            kept = r["cells_kept"] and not (set(r["frame"]) - OFFR)
            if r["where"] == "lead":
                leadk[r["key"]] = leadk.get(r["key"], True) and kept
            L = lab.get((look, r["key"], 0, r["where"], r["index"]))
            if not L or L["truth"] == "no_claim":
                continue
            if L["truth"] in ("wrongly_based", "false"):
                c["bad"] += 1; c["bad_out"] += kept
                if kept: outs.append(f"{r['key']} {r['where']}{r['index']}: {L['text'][:100]}")
            elif L["truth"] == "true":
                c["true"] += 1; c["true_lost"] += not kept
        c["lead_kept"] = sum(leadk.values()); c["answers"] = len(leadk)
        res[look] = dict(c); res[look + "_out"] = outs
    pl = o["planted"]; sent = {}
    for r in pl:
        if r["set"] == "attack":
            sid = re.sub(r"_(?:L|P)$", "", r["id"])
            sent[sid] = sent.get(sid, False) or (r["cells_kept"] and not (set(r["frame"]) - OFFR))
    at = [r for r in pl if r["set"] == "attack_true"]; au = [r for r in pl if r["set"] == "audit_true"]
    res["planted"] = {"attack_false_out": sum(sent.values()), "attack_true_kept": sum(1 for r in at if r["cells_kept"] and not (set(r["frame"]) - OFFR)),
                      "audit_true_kept": sum(1 for r in au if r["cells_kept"] and not (set(r["frame"]) - OFFR))}
    out[f"C2_{base}_M"] = res
json.dump(out, open(os.path.join(HERE, "c2tally.json"), "w"), indent=1)
print(json.dumps(out, indent=1))
