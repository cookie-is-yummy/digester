"""Set (b): the 8 answers that sent a false sentence, rebuilt by today's answer.build from the LAST form the model
wrote (as the run did after its one repair), under today's checker (C0) and under C1a (cells only). Prints the text
that would go out. answer.build is today's (code lead and template included)."""
import glob, json, os, sys, importlib.util
HERE = os.path.dirname(os.path.abspath(__file__)); S = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, "/home/user/digester/experiments"); sys.path.insert(0, HERE)
import sim as SM  # noqa (loads verify_c1 as SM.V)
from mvp.brain import answer as A
from mvp import eval_brain as E
base = os.path.join(HERE, "_lib")
h = E.Harness.scratch(base=base)
WANT = [("look1", "B03.0"), ("look1", "C04.0"), ("look1", "F05.0"), ("look1", "F11.0"), ("look1", "I02.0"),
        ("look2", "E04.0"), ("look2", "I02.0"), ("look2", "I01.0")]
out = {}
for look, key in WANT:
    rec = json.load(open(os.path.join(SM.LOOKS[look], key + ".json")))
    t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
    vt = SM.V.Turn.of(t)
    results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
    led = SM.V.Ledger(results)
    for cfg in ("C0", "C1a", "C1d"):
        SM.setcfg(cfg)
        f0 = rec["forms"][0]
        v0 = SM.V.check_answer(f0, results, vt)
        form = f0 if not v0.repair or len(rec["forms"]) == 1 else rec["forms"][-1]
        v = SM.V.check_answer(form, results, vt)
        try:
            b = A.build(results, verdict=v) if v.lead_ok else {"text": "(lead failed: a code lead takes its place; model points re-checked under it)"}
            txt = b["text"]
        except Exception as e:  # noqa
            txt = f"(answer.build failed: {type(e).__name__}: {e})"
        out[f"{look} {key} {cfg}"] = {"repair_used": form is not f0, "lead_ok": v.lead_ok, "text": txt}
        print(f"== {look} {key} {cfg} repair={form is not f0} lead_ok={v.lead_ok}\n{txt}\n")
SM.setcfg("C0")
json.dump(out, open(os.path.join(HERE, "setb.json"), "w"), indent=1)
