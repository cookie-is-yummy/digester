"""Final outcomes of the skeptic's sentences: M (simulated, cases_out.json) and the spec under compliance (hand,
SPEC below: one label per case, with the deciding rule). Writes cases_final.json and cases_final.txt."""
import json
import os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
rows = json.load(open(os.path.join(HERE, "cases_out.json")))
# spec label under compliance + honest record: (C1a base, C1d base, deciding rule). out/caught for F; kept/lost for T;
# fixed = the fault is a frame word a compliant model would not write (M-only); dep = depends on an unspecified detail.
SPEC = {
    "K01": ("dep", "dep", "out if the record says rank (true: gaming is top); caught if it says share ('most' with no rank record)"),
    "K02": ("caught", "out", "C1a: uncited_claim (DOUBT); C1d: no rule for 'mostly'"),
    "K03": ("caught", "caught", "cells: 'half' read as a number (ratio / uncited_number)"),
    "K04": ("caught", "caught", "C1a uncited_claim; C1d: closed list, 'most' with no rank record"),
    "K05": ("out", "out", "'dominated' not a listed rank word; record kind count"),
    "K06": ("out", "out", "'go-to' not a listed rank word"),
    "K07": ("out", "out", "'trailed' not listed; top-5 result, meta.complete true"),
    "K08": ("caught", "caught", "rank record place 2 against rows (place 3), or 'came next' with no rank record"),
    "K09": ("caught", "out", "C1a: wrong_area (cell); C1d: 'then' is no rank or level word"),
    "K10": ("out", "out", "'always' not on the persist list; rank record true of r2"),
    "K11": ("out", "out", "'used to', 'mostly': no rule"),
    "K12": ("out", "out", "move record; no previous-rank check for 'held its place'"),
    "K13": ("fixed", "fixed", "frame word ('over the summer'): compliance"),
    "K14": ("fixed", "fixed", "scope word ('at the weekend'): compliance"),
    "K15": ("fixed", "fixed", "follow-up frame word ('that month'): compliance"),
    "K16": ("fixed", "fixed", "lead with no comma: the spec lists it as to be written"),
    "K17": ("caught", "fixed", "C1a: 'month' cell check; else code writes the opening"),
    "K18": ("dep", "dep", "out if 'complete' is the sheet's rows (5 of 5); caught if against meta.rows_of (8)"),
    "K19": ("caught", "caught", "'all' with no list record (kind count) is refused; out if the record lists the 6 items as complete"),
    "K20": ("caught", "caught", "'all' with 2 of 5 rows"),
    "K21": ("out", "out", "'only' with a complete list (1 of 1 areas); rows cover 8 of 58"),
    "K22": ("out", "out", "rank record true of the rows; tool fault the spec cannot see (coverage)"),
    "K23": ("out", "out", "rank check ignores meta.hidden.rank_hidden_above"),
    "K24": ("out", "out", "'all' with a complete list (1 of 1); private 'all' check dropped from C5"),
    "K25": ("out", "out", "'barely anything': no rule; private line printed but the sentence goes past it"),
    "K26": ("caught", "out", "C1a: 'direction' (DOUBT); C1d: 'bigger than' is no rank word"),
    "K27": ("caught", "caught", "window word in a point ('this month') and policy outside_in_history"),
    "K28": ("out", "out", "'of them' binds to the lead's result; code frames r2's window, the anaphora stays"),
    "K29": ("out", "out", "size words: no rule"),
    "K30": ("caught", "caught", "cells: 'doubled' read as a ratio"),
    "K31": ("out", "out", "the spec checks rank, list, other-N, new exactly; not a move's sign. Today's 'direction' did not fire"),
    "K32": ("out", "out", "'held up': no direction lexicon"),
    "K33": ("out", "out", "row is in the new list; 'new' carries no 'against what'"),
    "K34": ("out", "out", "same"),
    "K35": ("out", "out", "'arrived' not in NEW"),
    "K36": ("fixed", "fixed", "base phrase: compliance"),
    "K37": ("out", "out", "median of long videos said of Shorts: no base slot for medians"),
    "K38": ("fixed", "fixed", "platform word: compliance (here also a repeat of the lead's 142)"),
    "K39": ("caught", "fixed", "C1a: unnamed_owner; else compliance + code's base after an inner share"),
    "K40": ("out", "out", "'overtaken': no comparison lexicon"),
    "K41": ("caught", "out", "C1a: uncited_claim (DOUBT); C1d: no rule for 'evening'"),
    "K42": ("caught", "out", "C1a: uncited_claim; C1d: 'any year' not on the persist list"),
    "K43": ("out", "out", "'your gaming day': a cross-day claim on a one-day result"),
    "K44": ("caught", "dep", "C1a: uncited_claim; C1d: a rank record over no list is unspecified"),
    "K45": ("caught", "caught", "cells: 'twice' read as a number"),
    "K46": ("caught", "caught", "cells: 'five times' read as a number"),
    "K47": ("caught", "caught", "list record complete all with 5 of 6 periods"),
    "K48": ("out", "out", "'nearly stopped': no rule over hidden rows"),
    "T01": ("kept", "kept", "own_frame on previous_items; code writes the opening (M drops it: time_phrase)"),
    "T02": ("lost", "lost", "'almost all' trips the 'all' rule (C1a also unnamed_owner)"),
    "T03": ("kept", "kept", ""),
    "T04": ("kept", "kept", "rank record place 3 is true; 'first place' unchecked (the same gap lets K12 out)"),
    "T05": ("kept", "kept", ""),
    "T06": ("lost", "lost", "a cross-window comparison needs window words in a point; 'overall' is on the scope list"),
    "T07": ("lost", "kept", "C1a: uncited_claim"),
    "T08": ("lost", "kept", "C1a: uncited_claim, unnamed_owner"),
    "T09": ("lost", "lost", "'still' (persist list)"),
    "T10": ("kept", "kept", ""),
    "T11": ("lost", "lost", "window words in a point; with them stripped, 'neither was there' has no window"),
    "T12": ("kept", "kept", ""),
    "T13": ("kept", "kept", "own_frame (M drops it: time_phrase)"),
    "T14": ("kept", "kept", "record complete 'some' (M drops it: list_incomplete)"),
    "T15": ("lost", "lost", "'every' with no complete list"),
    "T16": ("lost", "lost", "cells: 112 has no cell"),
    "T17": ("kept", "kept", ""),
    "T18": ("lost", "lost", "'the rest' with no N and a window the result does not hold"),
    "T19": ("lost", "lost", "cells: 'two' read as an uncited number, so 'top two' cannot be said"),
    "T20": ("kept", "kept", ""),
}
# my own split of the 48: firm false, cannot prove from the result, borderline (arguable)
FIRM = {"K09": "borderline", "K23": "borderline", "K25": "borderline", "K32": "borderline", "K43": "borderline",
        "K48": "borderline", "K41": "cannot_prove", "K42": "cannot_prove"}
exact = json.load(open(os.path.join(HERE, "exact_on_cases.json")))
out = []
lines = []
for r in rows:
    a, d, why = SPEC[r["id"]]
    r["spec_C1a"], r["spec_C1d"], r["spec_rule"] = a, d, why
    for k_ in ("spec", "spec_why", "rule_needed"):
        r.pop(k_, None)
    r["firmness"] = FIRM.get(r["id"], "firm") if r["truth"] == "F" else "true"
    out.append(r)
    lines.append(f"{r['id']} {r['truth']} {r['firmness']:<12} {r['class']:<16} M: C1a {'OUT ' if r['M_C1a']['kept'] else 'drop'} "
                 f"C1d {'OUT ' if r['M_C1d']['kept'] else 'drop'} | spec: C1a {a:<6} C1d {d:<6} | {why}")
    lines.append(f"     {r['sentence']}")
    lines.append(f"     recount: {r['recount']}")
F = [r for r in out if r["truth"] == "F"]
T = [r for r in out if r["truth"] == "T"]
summ = {}
for base in ("C1a", "C1d"):
    summ[f"M_{base}_false_out"] = sum(r[f"M_{base}"]["kept"] for r in F)
    summ[f"M_{base}_true_kept"] = sum(r[f"M_{base}"]["kept"] for r in T)
    summ[f"spec_{base}_false"] = dict(Counter(r[f"spec_{base}"] for r in F))
    summ[f"spec_{base}_true"] = dict(Counter(r[f"spec_{base}"] for r in T))
summ["n_false"], summ["n_true"] = len(F), len(T)
FF = [r for r in F if r["firmness"] == "firm"]
summ["n_firm"] = len(FF)
for base, xb in (("C1a", "X"), ("C1d", "Xd")):
    summ[f"firm_M_{base}_out"] = sum(r[f"M_{base}"]["kept"] for r in FF)
    summ[f"firm_spec_{base}"] = dict(Counter(r[f"spec_{base}"] for r in FF))
    summ[f"firm_M_{base}_plus_exact_out"] = sum(exact[r["id"]][xb]["kept"] for r in FF)
    summ[f"true_M_{base}_plus_exact_kept"] = sum(exact[r["id"]][xb]["kept"] for r in T)
summ["firm_C0_out"] = sum(r["C0_today"]["kept"] for r in FF)
summ["C0_false_out"] = sum(r["C0_today"]["kept"] for r in F)
summ["C0_true_kept"] = sum(r["C0_today"]["kept"] for r in T)
json.dump({"summary": summ, "rows": out}, open(os.path.join(HERE, "cases_final.json"), "w"), indent=1)
head = ["SKEPTIC SENTENCES on real tool results (scen.py, tests/brain_library.py). M = simulated (common.c5: paper's",
        "verify_c1 copy + frame.py, compliant=False). spec = hand outcome of C5 as specified, compliant model, honest record.",
        json.dumps(summ), ""]
open(os.path.join(HERE, "cases_final.txt"), "w").write("\n".join(head + lines) + "\n")
print(json.dumps(summ, indent=1))
