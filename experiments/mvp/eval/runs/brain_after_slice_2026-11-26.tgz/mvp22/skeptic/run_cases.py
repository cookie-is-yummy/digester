"""Run every skeptic sentence through C5 M (C1a and C1d bases + frame.py, compliant=False) and today's C0."""
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402
import scen  # noqa: E402
import cases as K  # noqa: E402

built = {}
rows = []
for c in K.CASES + K.TRUE:
    cid, sk, where, truth, cls, sent, why, spec, spec_why, rule = c
    if sk not in built:
        t, _ = scen.build(sk)
        built[sk] = (t.results, C.V.Turn.of(t))
    results, vt = built[sk]
    form = {"lead": sent} if where == "L" else {"lead": K.CARRIER[sk], "points": [sent]}
    tgt = ("lead", 0) if where == "L" else ("point", 0)
    out = {}
    for base in ("C1a", "C1d"):
        o, v = C.c5(form, results, vt, base)
        kept, cr, fr = o.get(tgt, (False, ["missing"], []))
        carrier_ok = where == "L" or o.get(("lead", 0), (False,))[0]
        out[base] = {"kept": kept, "cells": cr, "frame": fr, "carrier_kept": carrier_ok, "private_line": v.private_line}
    C.setcfg("C0")
    v0 = C.V.check_answer(form, results, vt)
    o0 = next((o for o in v0.outcomes if (o.where, o.index) == tgt), None)
    out["C0"] = {"kept": bool(o0 and o0.kept), "reasons": list(o0.reasons) if o0 else ["missing"]}
    rows.append({"id": cid, "scen": sk, "where": where, "truth": truth, "class": cls, "sentence": sent, "recount": why,
                 "M_C1a": out["C1a"], "M_C1d": out["C1d"], "C0_today": out["C0"], "spec": spec, "spec_why": spec_why,
                 "rule_needed": rule})
    m = "OUT" if out["C1a"]["kept"] else "drop"
    d = "OUT" if out["C1d"]["kept"] else "drop"
    print(cid, truth, cls, "| M C1a", m, out["C1a"]["cells"][:3], out["C1a"]["frame"], "| M C1d", d,
          out["C1d"]["cells"][:3], out["C1d"]["frame"], "| C0", out["C0"]["kept"], out["C0"]["reasons"][:3],
          "| carrier", out["C1a"]["carrier_kept"], out["C1d"]["carrier_kept"], "| spec", spec)
json.dump(rows, open(os.path.join(C.HERE, "cases_out.json"), "w"), indent=1, default=str)
