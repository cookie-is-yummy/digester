"""Item 1: the paper's C5 figures on my sample (25 seeded-random true rows + every wrongly based or cannot-prove row,
all forms). M = my reproduction of the paper's code path (repro.json, 387/387 equal to paper/c5_all.json).
spec = my hand outcome for C5 as specified, compliant model, honest record (what the model believes)."""
import json
import os
HERE = os.path.dirname(os.path.abspath(__file__))
lab = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r
       for r in json.load(open(os.path.join(HERE, "..", "raw", "sentences.json")))}
rep = json.load(open(os.path.join(HERE, "repro.json")))["rows"]
paper = json.load(open(os.path.join(HERE, "..", "paper", "c5_all.json")))
M = {b: {(r["set"], r["key"], r["form_index"], r["where"], r["index"]): r for r in rep[b]} for b in ("C1a", "C1d")}
PH = {b: {(r["set"], r["key"], r["form_index"], r["where"], r["index"]): r for r in paper[f"C5_{b}_H"]["heldout"]}
      for b in ("C1a", "C1d")}
SPEC_TRUE = {  # sample order (sample25.json); (C1a, C1d, why)
    0: ("lost", "lost", "level rule: 'came next' after a sentence that ranked another level (paper agrees)"),
    1: ("lost", "lost", "'still' (persist list); a repair may save it"),
    2: ("kept", "kept", "code writes the opening and the scope"),
    3: ("kept", "kept", ""),
    4: ("lost", "kept", "C1a uncited_claim (DOUBT)"),
    5: ("kept", "kept", ""),
    6: ("kept", "kept", "compliant: no base or window words; code writes the base and the previous window"),
    7: ("kept", "kept", ""),
    8: ("kept", "kept", ""),
    9: ("kept", "kept", "rank record place 1, no tie (30 against 28)"),
    10: ("kept", "kept", ""),
    11: ("kept", "kept", "period labels beside their cells"),
    12: ("kept", "kept", "compliant: code writes 'of what you opened' and 'on the 4 weeks before'"),
    13: ("lost", "lost", "cells: 'Limit Lane' unmarked (marker bookkeeping)"),
    14: ("kept", "kept", ""),
    15: ("kept", "kept", "date cell"),
    16: ("kept", "kept", "'all 8' and 'all in' with one-row lists: complete (my reading of the spec)"),
    17: ("kept", "kept", "same"),
    18: ("kept", "kept", "compliant: code writes the base"),
    19: ("kept", "kept", "compliant: code writes the previous window"),
    20: ("kept", "kept", "compliant: own_frame on previous_items"),
    21: ("kept", "kept", ""),
    22: ("kept", "kept", ""),
    23: ("lost", "lost", "'all 100%': 'all' with no list record is refused by the spec's closed list (a repair may save it)"),
    24: ("lost", "lost", "cells: uncited name 'daily'"),
}
SPEC_FALSE = {  # (look, key, form, where, index) -> (C1a, C1d, why)
    ("look1", "A06.0", 0, "point", 1): ("caught", "caught", "level rule"),
    ("look1", "B05.0", 0, "point", 0): ("caught", "caught", "rank record: tie"),
    ("look1", "D03.2", 0, "point", 1): ("caught", "caught", "cells"),
    ("look1", "F05.0", 0, "point", 2): ("caught", "caught", "'still' refused; base written by code"),
    ("look1", "F05.0", 1, "point", 2): ("caught", "caught", "same"),
    ("look1", "F11.0", 0, "point", 0): ("caught", "caught", "list record complete all: 3 of 6 periods (if the model fills 'all')"),
    ("look1", "I02.0", 0, "lead", 0): ("caught", "caught", "cells: uncited name"),
    ("look1", "I02.0", 0, "point", 0): ("out", "out", "compliant: 'You opened 58 videos, and the top theme was Home cooking with 8.' rank record true of rows; today's coverage check ('rank': 50 of 58 in no row) would catch it but C5 switches 'rank' off"),
    ("look1", "I02.0", 1, "lead", 0): ("caught", "caught", "cells: uncited name"),
    ("look1", "I02.0", 1, "point", 0): ("out", "out", "same as form 0"),
    ("look1", "K03.0", 0, "point", 1): ("caught", "caught", "cells"),
    ("look2", "B05.0", 0, "point", 0): ("caught", "caught", "rank record: tie"),
    ("look2", "B14.0", 0, "point", 0): ("caught", "caught", "r_rest: 651 + 66 is not 723"),
    ("look2", "B14.0", 0, "point", 1): ("caught", "caught", "cells"),
    ("look2", "B14.0", 1, "point", 0): ("caught", "caught", "r_rest"),
    ("look2", "F05.0", 0, "lead", 0): ("caught", "caught", "cells (uncited number); compliance removes the window words"),
    ("look2", "F11.0", 0, "point", 0): ("caught", "caught", "cells; base slot if code knows shorts_share's base"),
    ("look2", "F15.0", 0, "point", 0): ("caught", "caught", "compliant: code writes 'long videos only'; scope fixed (paper: caught by accident)"),
    ("look2", "I01.0", 0, "point", 1): ("out", "out", "compliant: '3 saved Home cooking posts were not opened.' under code's 'In 2024,' opening: the library cell has no 2024 window; own_frame is false because the model believes it is 2024; no library field in the record"),
    ("look2", "I01.0", 1, "point", 1): ("out", "out", "same"),
    ("look2", "I02.0", 0, "lead", 0): ("caught", "out", "C1a: 'limits' self-talk (DOUBT); C1d: out"),
    ("look2", "I02.0", 1, "lead", 0): ("caught", "out", "same"),
    ("look2", "K03.0", 0, "point", 2): ("caught", "caught", "cells; list record"),
}
smp = [tuple(k) for k in json.load(open(os.path.join(HERE, "sample25.json")))]
rows, lines = [], []
for i, k in enumerate(smp):
    L = lab[k]
    a, d, why = SPEC_TRUE[i]
    r = {"row": list(k), "truth": "true", "text": L["text"], "M_C1a": M["C1a"][k]["kept"], "M_C1d": M["C1d"][k]["kept"],
         "paper_H_C1a": PH["C1a"][k]["kept"], "paper_H_C1d": PH["C1d"][k]["kept"], "spec_C1a": a, "spec_C1d": d,
         "why": why}
    rows.append(r)
for k, (a, d, why) in SPEC_FALSE.items():
    L = lab[k]
    rows.append({"row": list(k), "truth": L["truth"], "text": L["text"], "fault": L["fault"],
                 "M_C1a": M["C1a"][k]["kept"], "M_C1d": M["C1d"][k]["kept"], "paper_H_C1a": PH["C1a"][k]["kept"],
                 "paper_H_C1d": PH["C1d"][k]["kept"], "spec_C1a": a, "spec_C1d": d, "why": why})
T = [r for r in rows if r["truth"] == "true"]
F = [r for r in rows if r["truth"] != "true"]
s = {"true_n": len(T),
     "true_lost_M": [sum(not r["M_C1a"] for r in T), sum(not r["M_C1d"] for r in T)],
     "true_lost_paperH": [sum(not r["paper_H_C1a"] for r in T), sum(not r["paper_H_C1d"] for r in T)],
     "true_lost_spec": [sum(r["spec_C1a"] == "lost" for r in T), sum(r["spec_C1d"] == "lost" for r in T)],
     "false_n": len(F),
     "false_out_M": [sum(r["M_C1a"] for r in F), sum(r["M_C1d"] for r in F)],
     "false_out_paperH": [sum(r["paper_H_C1a"] for r in F), sum(r["paper_H_C1d"] for r in F)],
     "false_out_spec": [sum(r["spec_C1a"] == "out" for r in F), sum(r["spec_C1d"] == "out" for r in F)]}
for r in rows:
    lines.append(f"{'/'.join(map(str, r['row']))} {r['truth']}: M {r['M_C1a']}/{r['M_C1d']} paperH {r['paper_H_C1a']}/"
                 f"{r['paper_H_C1d']} spec {r['spec_C1a']}/{r['spec_C1d']} | {r['why']}\n    {r['text']}")
json.dump({"summary": s, "rows": rows}, open(os.path.join(HERE, "sample_judged.json"), "w"), indent=1)
open(os.path.join(HERE, "sample_judged.txt"), "w").write(json.dumps(s) + "\n" + "\n".join(lines) + "\n")
print(json.dumps(s, indent=1))
