"""Skeptic harness: loads the paper's cells-only checker copy (paper/src/verify_c1.py) and frame.py WITHOUT running
any paper script, builds a scratch library under skeptic/_lib, and runs C5 M (C1a or C1d base + frame.py,
compliant=False) on any form. Read only for the repo and for paper/. No model call."""
import importlib.util
import json
import os
import sys
from datetime import date

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
PAPER = os.path.join(S, "mvp22", "paper")
sys.path.insert(0, "/home/user/digester/experiments")
sys.path.insert(0, PAPER)
import mvp.brain  # noqa: E402,F401
from mvp.brain import verify as VR  # noqa: E402

_spec = importlib.util.spec_from_file_location("mvp.brain.verify_c1", os.path.join(PAPER, "src", "verify_c1.py"))
V = importlib.util.module_from_spec(_spec)
V.__package__ = "mvp.brain"
sys.modules["mvp.brain.verify_c1"] = V
_spec.loader.exec_module(V)
import taxonomy as T  # noqa: E402
import frame as F  # noqa: E402

CONFIGS = {"C0": (set(), "on"), "C1a": (T.off_set(False), "on"), "C1d": (T.off_set(True), "off")}


def setcfg(name):
    off, ins = CONFIGS[name]
    V.OFF.clear()
    V.OFF.update(off)
    V.INSIGHT = ins


def form_sentences(form):
    lead = V._split(form.get("lead") or "")
    out = [("lead", k, s) for k, s in enumerate(lead)]
    for k, p in enumerate(form.get("points") or []):
        out.append(("point", k, p))
    return out


def c5(form, results, vturn, base="C1a"):
    """{(where, index): (kept, cell_reasons, frame_reasons)} for C5 M on the C1 base `base`, plus the verdict."""
    setcfg(base)
    v = V.check_answer(form, results, vturn)
    ck = {(o.where, o.index): (o.kept, list(o.reasons)) for o in v.outcomes}
    led = VR.Ledger(results) if not isinstance(results, VR.Ledger) else results
    sents = form_sentences(form)
    counts = []
    for _w, _k, s in sents:
        mks, _b = VR.parse(" ".join(s.split()), led)
        counts += [mk.value for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                   and not isinstance(mk.value, bool)]
    out, prev = {}, None
    for w, k, s in sents:
        _rs, _lvl, mine = F.check(s, led, w, prev, [], False)
        others = list(counts)
        for x in mine:
            if x in others:
                others.remove(x)
        rs, lvl, _ = F.check(s, led, w, prev, others, False)
        kept_cells = ck.get((w, k), (False, ["missing"]))
        out[(w, k)] = (kept_cells[0] and not rs, kept_cells[1], rs)
        if kept_cells[0]:
            prev = lvl or prev
    setcfg("C0")
    return out, v


_H = None


def harness():
    global _H
    if _H is None:
        base = os.path.join(HERE, "_lib")
        if not os.path.isdir(base):
            os.makedirs(base)
        from mvp import eval_brain as E
        _H = E.Harness.scratch(base=base)
    return _H


def call(t, tool, args):
    from mvp.brain import tools as TL
    return TL.call(t, tool, args)
