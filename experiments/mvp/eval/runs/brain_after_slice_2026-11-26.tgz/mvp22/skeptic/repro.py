"""Reproduce the paper's C5 M rows on both held-out looks from the records, and diff against paper/c5_all.json."""
import glob
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

LOOKS = {"look1": os.path.join(C.S, "mvp20/tune/heldout"), "look2": os.path.join(C.S, "mvp20/fix/heldout_run")}
ref = json.load(open(os.path.join(C.PAPER, "c5_all.json")))
h = C.harness()
mine = {"C1a": [], "C1d": []}
for look, d in LOOKS.items():
    for p in sorted(glob.glob(os.path.join(d, "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        vt = C.V.Turn.of(t)
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        for fi, form in enumerate(rec.get("forms") or []):
            for base in ("C1a", "C1d"):
                o, _v = C.c5(form, results, vt, base)
                for (w, i), (kept, cr, fr) in o.items():
                    mine[base].append({"set": look, "key": rec["key"], "form_index": fi, "where": w, "index": i,
                                       "kept": kept, "frame": fr, "cell_reasons": cr})
diff = {}
for base in ("C1a", "C1d"):
    R = {(r["set"], r["key"], r["form_index"], r["where"], r["index"]): r for r in ref[f"C5_{base}_M"]["heldout"]}
    M = {(r["set"], r["key"], r["form_index"], r["where"], r["index"]): r for r in mine[base]}
    d = [k for k in R if k not in M or M[k]["kept"] != R[k]["kept"] or sorted(M[k]["frame"]) != sorted(R[k]["frame"])]
    diff[base] = {"ref": len(R), "mine": len(M), "differ": len(d), "rows": [list(k) for k in d][:20]}
    print(base, diff[base]["ref"], diff[base]["mine"], "differ", len(d), d[:10])
json.dump({"diff": diff, "rows": mine}, open(os.path.join(C.HERE, "repro.json"), "w"), indent=0, default=str)
