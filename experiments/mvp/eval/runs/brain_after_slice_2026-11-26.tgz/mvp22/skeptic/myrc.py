"""My own recount over tests/brain_library.py rows() (main checkout). Opened = 'watch'; saved = 'save'/'playlist';
New York dates; friend's post left out; the sensitive theme 'da' left out unless sensitive=True.
Short = YouTube of known length <= 60 s (Instagram reels counted apart)."""
import sys
from collections import Counter
from datetime import date as D, datetime
from zoneinfo import ZoneInfo
sys.dont_write_bytecode = True
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B  # noqa: E402

NY = ZoneInfo("America/New_York")
THEME = {"mc": "Minecraft builds", "sr": "Speedruns", "cl": "Gaming clips", "wc": "Watercolor painting",
         "dd": "Digital drawing", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking",
         "da": "Dating advice"}
AREA = {"mc": "gaming", "sr": "gaming", "cl": "gaming", "wc": "art and design", "dd": "art and design",
        "ca": "math", "np": "math", "co": "food and cooking", "da": "relationships"}
ROWS = B.rows()


def chan(r):
    return r["channel"] if r["platform"] == "youtube" else "@" + r["handle"]


def items(a=None, b=None, how="opened", sensitive=False, pred=None):
    kinds = {"opened": {"watch"}, "saved": {"save", "playlist"}, "any": {"watch", "save", "playlist", "like"}}[how]
    out = {}
    for r in ROWS:
        if r.get("friend") or (not sensitive and r["theme"] == "da"):
            continue
        if pred and not pred(r):
            continue
        for k, at in r["events"]:
            t = datetime.fromisoformat(at).astimezone(NY)
            if k in kinds and (a is None or a <= t.date()) and (b is None or t.date() <= b):
                if r["id"] not in out or t < out[r["id"]][1]:
                    out[r["id"]] = (r, t)
    return list(out.values())


def by(key, a=None, b=None, **kw):
    f = {"area": lambda r: AREA[r["theme"]], "theme": lambda r: THEME[r["theme"]], "channel": chan,
         "platform": lambda r: r["platform"], "weekday": None}[key]
    if key == "weekday":
        return Counter(t.strftime("%A") for r, t in items(a, b, **kw))
    return Counter(f(r) for r, _t in items(a, b, **kw))


def short(r):
    return r["platform"] == "youtube" and r["length"] is not None and r["length"] <= 60


def long_(r):
    return r["platform"] == "youtube" and r["length"] is not None and r["length"] > 60


OCT = (D(2026, 10, 1), D(2026, 10, 30)); LATELY = (D(2026, 10, 3), D(2026, 10, 30))
PREV4 = (D(2026, 9, 5), D(2026, 10, 2)); YTD = (D(2026, 1, 1), D(2026, 10, 30))
WEEK = (D(2026, 10, 24), D(2026, 10, 30)); SEP = (D(2026, 9, 1), D(2026, 9, 30))
Y = {y: (D(y, 1, 1), D(y, 12, 31)) for y in range(2021, 2027)}
