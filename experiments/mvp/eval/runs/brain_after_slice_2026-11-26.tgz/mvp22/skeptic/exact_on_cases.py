"""C5 M plus today's exact codes (rank, spread, mostly, least, tie) on the skeptic's own 68 sentences (fresh for those
codes), beside plain C5 M. Also today's checker on I02.0 look 1 (details printed)."""
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402
import scen  # noqa: E402
import cases as K  # noqa: E402

C.CONFIGS["X"] = (C.T.off_set(False) - {"rank", "spread", "mostly", "least", "tie"}, "on")
C.CONFIGS["Xd"] = (C.T.off_set(True) - {"rank", "spread", "mostly", "least", "tie"}, "off")
built, out = {}, {}
for c in K.CASES + K.TRUE:
    cid, sk, where = c[0], c[1], c[2]
    if sk not in built:
        t, _ = scen.build(sk)
        built[sk] = (t.results, C.V.Turn.of(t))
    results, vt = built[sk]
    form = {"lead": c[5]} if where == "L" else {"lead": K.CARRIER[sk], "points": [c[5]]}
    tgt = ("lead", 0) if where == "L" else ("point", 0)
    r = {}
    for base in ("C1a", "X", "C1d", "Xd"):
        o, _v = C.c5(form, results, vt, base)
        k = o.get(tgt, (False, ["missing"], []))
        r[base] = {"kept": k[0], "cells": k[1], "frame": k[2]}
    out[cid] = r
json.dump(out, open(os.path.join(C.HERE, "exact_on_cases.json"), "w"), indent=1)
F = [c[0] for c in K.CASES]
T = [c[0] for c in K.TRUE]
for a, b in (("C1a", "X"), ("C1d", "Xd")):
    newly_caught = [i for i in F if out[i][a]["kept"] and not out[i][b]["kept"]]
    newly_lost = [i for i in T if out[i][a]["kept"] and not out[i][b]["kept"]]
    print(a, "->", b, "false newly caught", len(newly_caught), newly_caught, "| true newly lost", len(newly_lost),
          [(i, out[i][b]["cells"]) for i in newly_lost])
# I02.0 look 1, today's checker
rec = json.load(open(os.path.join(C.S, "mvp20/tune/heldout/I02.0.json")))
h = C.harness()
t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
           and not c["result"].get("is_error")}
C.setcfg("C0")
v = C.V.check_answer(rec["forms"][0], results, C.V.Turn.of(t))
for o in v.outcomes:
    print("I02.0 look1 form0", o.where, o.index, o.kept, o.reasons, getattr(o, "details", None))
print("as-run verdicts:", json.dumps(rec["verdicts"], default=str)[:700])
