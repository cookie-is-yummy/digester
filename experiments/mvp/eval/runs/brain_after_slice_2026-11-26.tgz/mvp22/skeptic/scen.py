"""Scenarios: real brain/tools.py calls on tests/brain_library.py (scratch library under skeptic/_lib)."""
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

W = {"preset": None, "same_as": None, "words": None}
SC = {"exclude": [], "how": "opened", "length": "any", "only": [], "platforms": [], "weekday": None}


def win(**kw):
    return dict(W, **kw)


def sc(**kw):
    return dict(SC, **kw)


SCEN = {
    # key: (message, [(tool, args)], last_window)
    "LATELY": ("what have i been into lately", [("breakdown", {"by": "theme", "window": win(preset="lately"),
               "scope": sc(), "compare": "previous", "top": 6})], None),
    "OCT_CH": ("which channels did i watch most in october", [("breakdown", {"by": "channel",
               "window": win(words="in October"), "scope": sc(), "compare": "none", "top": 5})], None),
    "YEARS": ("how has my watching changed over the years", [("timeline", {"unit": "year", "window": win(preset="all"),
              "scope": sc()})], None),
    "Y2024": ("what was i into in 2024", [("breakdown", {"by": "theme", "window": win(words="in 2024"), "scope": sc(),
              "compare": "none"})], None),
    "Y2024U": ("did i watch a lot of dating advice in 2024", [("breakdown", {"by": "channel",
               "window": win(words="in 2024"), "scope": sc(), "compare": "none"})], None),
    "TWO": ("what did i watch in october and how does that compare with my whole history",
            [("breakdown", {"by": "area", "window": win(words="in October"), "scope": sc(), "compare": "none"}),
             ("breakdown", {"by": "area", "window": win(preset="all"), "scope": sc(), "compare": "none"})], None),
    "FOLLOW": ("and just the art ones?", [("breakdown", {"by": "channel", "window": win(same_as="last"),
               "scope": sc(only=["art"]), "compare": "previous"})], "lately"),
    "YTD_CH": ("my channels this year", [("breakdown", {"by": "channel", "window": win(preset="this_year"),
               "scope": sc(), "compare": "none", "top": 8})], None),
    "CHG": ("what changed this year", [("changes", {"against": "same_last_year", "level": "theme",
            "window": win(preset="this_year"), "scope": sc()})], None),
    "SAT": ("what do i watch on saturdays in october", [("breakdown", {"by": "area",
            "window": win(words="in October"), "scope": sc(weekday=5), "compare": "none"})], None),
    "MONTHS": ("my months this year", [("timeline", {"unit": "month", "window": win(preset="this_year"),
               "scope": sc()})], None),
    "SAVED": ("what did i save in october", [("items", {"window": win(words="in October"), "scope": sc(how="saved"),
              "order": "newest", "limit": 10})], None),
}


def build(key):
    msg, calls, last = SCEN[key]
    h = C.harness()
    lw = None
    if last:
        from mvp.brain import windows as WN  # noqa: F401
        t0 = h.turn("what have i been into lately")
        C.call(t0, "breakdown", {"by": "area", "window": win(preset="lately"), "scope": sc(), "compare": "none"})
        lw = t0.windows.get("r1")
    t = h.turn(msg, last_window=lw) if lw is not None else h.turn(msg)
    outs = [C.call(t, tool, args) for tool, args in calls]
    return t, outs


if __name__ == "__main__":
    which = sys.argv[1:] or list(SCEN)
    dump = {}
    for k in which:
        t, outs = build(k)
        dump[k] = {"message": SCEN[k][0], "results": t.results, "windows": {r: [str(w.start), str(w.end)] for r, w in
                                                                         t.windows.items()}, "unlock": t.unlock}
        for rid, res in t.results.items():
            m = res.get("meta") or {}
            sh = res.get("sheet") or {}
            print("=====", k, rid, res.get("tool"), "|", m.get("window_said"), "|", m.get("filters_said"), "|",
                  m.get("hidden"), "| complete", m.get("complete"), "| unlock", t.unlock)
            print("  totals", json.dumps(sh.get("totals"))[:400])
            for lv in ("areas", "themes", "channels", "periods", "items"):
                rows = sh.get(lv) or []
                if rows:
                    print("  ", lv, json.dumps([{kk: vv for kk, vv in r.items() if kk not in ("ref", "link", "url")}
                                                for r in rows], default=str)[:1400])
            for extra in ("library", "change", "new", "stopped", "when"):
                if sh.get(extra):
                    print("  ", extra, json.dumps(sh[extra], default=str)[:900])
    json.dump(dump, open(os.path.join(C.HERE, "scen_results.json"), "w"), indent=0, default=str)
