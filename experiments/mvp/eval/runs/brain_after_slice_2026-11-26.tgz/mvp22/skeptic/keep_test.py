"""What C5 throws away: re-enable one of today's exact framing codes at a time on top of C5 M (C1a base + frame.py),
and count true sentences lost and false sentences caught on both looks (first forms), the attack and the audit set."""
import glob
import json
import os
import sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402
from mvp.brain import planted as P  # noqa: E402

LOOKS = {"look1": os.path.join(C.S, "mvp20/tune/heldout"), "look2": os.path.join(C.S, "mvp20/fix/heldout_run")}
lab = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r
       for r in json.load(open(os.path.join(C.S, "mvp22/raw/sentences.json")))}
KEEP = ["rank", "spread", "mostly", "private_total", "least", "tie", "not_top", "direction_unbound", "no_direction"]
h = C.harness()
inputs = []
for look, d in LOOKS.items():
    for p in sorted(glob.glob(os.path.join(d, "*.json"))):
        if p.endswith("summary.json"):
            continue
        rec = json.load(open(p))
        t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
        results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                   and not c["result"].get("is_error")}
        inputs.append((look, rec, C.V.Turn.of(t), results))
data = P.load()
pl = [c for c in data["cases"] if c.get("source") in ("attack", "attack_true", "audit_true")]


def run(extra_on):
    base = C.T.off_set(False) - set(extra_on)
    C.CONFIGS["X"] = (base, "on")
    res = {"look_true_lost": 0, "look_false_out": 0, "attack_false_out": 0, "attack_true_kept": 0,
           "audit_true_kept": 0}
    for look, rec, vt, results in inputs:
        form = (rec.get("forms") or [None])[0]
        if not form:
            continue
        o, _v = C.c5(form, results, vt, "X")
        for (w, i), (kept, _cr, _fr) in o.items():
            L = lab.get((look, rec["key"], 0, w, i))
            if not L:
                continue
            if L["truth"] == "true" and not kept:
                res["look_true_lost"] += 1
            if L["truth"] == "wrongly_based" and kept:
                res["look_false_out"] += 1
    for c in pl:
        led = C.VR.Ledger(data["ledgers"][c["ledger"]])
        tt = c.get("turn") or {}
        from datetime import date
        vt = C.V.Turn(message=tt.get("message", ""), unlock=tt.get("unlock"),
                      today=date.fromisoformat(tt["today"]) if tt.get("today") else None,
                      names=list(tt.get("names") or []), sensitive_names=list(tt.get("sensitive_names") or []))
        tgt = c.get("target") or "point:0"
        kind, _, n = tgt.partition(":")
        best = False
        pline = False
        for f in (c.get("forms") or [c["form"]]):
            o, v = C.c5(f, data["ledgers"][c["ledger"]], vt, "X")
            if kind == "lead":
                k = all(x[0] for (w, i), x in o.items() if w == "lead") and any(w == "lead" for (w, i) in o)
            else:
                k = o.get((kind, int(n or 0)), (False,))[0]
            if k:
                best = True
                pline = v.private_line
        if c["expect"] == "private_line" and pline:
            best = False
        if c["source"] == "attack":
            res["attack_false_out"] += best
        elif c["source"] == "attack_true":
            res["attack_true_kept"] += best
        else:
            res["audit_true_kept"] += best
    return res


out = {"C5M_C1a": run([])}
print("C5M_C1a", out["C5M_C1a"], flush=True)
for k in KEEP:
    out["+" + k] = run([k])
    print("+" + k, out["+" + k], flush=True)
out["+exact_set"] = run(["rank", "spread", "mostly", "least", "tie"])
print("+exact_set", out["+exact_set"], flush=True)
json.dump(out, open(os.path.join(C.HERE, "keep_test.json"), "w"), indent=1)
