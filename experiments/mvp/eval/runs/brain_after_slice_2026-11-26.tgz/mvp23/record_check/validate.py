"""Reproduce designs.json D2_H/d, D2w_H/d, D2_Mc/a kept flags on look 1 and look 2 first forms with harness.py's parts."""
import json, os, sys
sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import harness as Hn
S = '/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
D = json.load(open(S + '/mvp23/record/designs.json'))
HR = json.load(open(S + '/mvp23/record/records_h.json'))
ref = {}
for d in ("D2_H/d", "D2w_H/d", "D2_Mc/a", "D2w_Mc/a"):
    for r in D[d]["heldout"]:
        if r["form_index"] == 0:
            ref[(d, r["set"], r["key"], r["where"], r["index"])] = r["kept"]
agree = tot = 0
bad = []
for (look, key), (rec, vt, results) in Hn.inputs().items():
    form = rec["forms"][0]
    led = Hn.L.V1.Ledger(results)
    ac = Hn.answer_cells(form, led)
    cv = {b: Hn.cells(form, results, vt, b)[0] for b in ("a", "d")}
    for w, k, s in Hn.sentences(form):
        nd = Hn.RC.needs(s, led)
        h = Hn.RC.check_records(s, HR.get(f"{look}|{key}|{w}|{k}", []), led) if nd else []
        mc, _ = Hn.RC.copy_check(s, led, ac)
        ww = Hn.W.check(s, led, vt)
        for d, base, rr, wide in (("D2_H/d", "d", h, False), ("D2w_H/d", "d", h, True), ("D2_Mc/a", "a", mc, False),
                                  ("D2w_Mc/a", "a", mc, True)):
            mine = bool(cv[base][(w, k)][0] and not rr and not (wide and ww))
            tot += 1
            if mine == ref[(d, look, key, w, k)]:
                agree += 1
            else:
                bad.append((d, look, key, w, k))
print("agree", agree, "of", tot, bad[:10])
