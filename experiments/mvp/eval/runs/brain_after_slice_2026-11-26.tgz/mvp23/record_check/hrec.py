import json,sys
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
H=json.load(open(S+'/mvp23/record/records_h.json'))
V=json.load(open(S+'/mvp23/record/verdicts.json'))
LAB={(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in json.load(open(S+'/mvp22/raw/sentences.json'))}
keys=sys.argv[1:] or list(H)
for k in keys:
    look,key,w,i=k.split('|')
    lab=LAB.get((look,key,0,w,int(i)),{})
    v=V['heldout'].get(f"{look}|{key}|0|{w}|{i}",{})
    print('==',k,lab.get('truth'),lab.get('fault'),'\n  ',lab.get('text'),'\n   H=',json.dumps(H.get(k)),'\n   needs',v.get('needs'),'h->',v.get('h'),'mc->',v.get('mc'),'mcrec',json.dumps(v.get('mc_rec')))
