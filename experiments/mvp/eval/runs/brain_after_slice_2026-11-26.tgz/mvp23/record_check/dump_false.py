import json,sys,os
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
D=json.load(open(S+'/mvp23/record/designs.json'))
V=json.load(open(S+'/mvp23/record/verdicts.json'))
LAB={(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in json.load(open(S+'/mvp22/raw/sentences.json'))}
from collections import Counter
print(Counter(r['truth'] for r in LAB.values()))
for r in D['D2w_H/d']['heldout']:
    lab=LAB.get((r['set'],r['key'],r['form_index'],r['where'],r['index']))
    if not lab or r['form_index']!=0: continue
    if lab['truth']!='true':
        k=f"{r['set']}|{r['key']}|0|{r['where']}|{r['index']}"
        v=V['heldout'].get(k,{})
        others={d:D[d]['heldout'] for d in ('D1b/d','D2_H/d','D2_Mc/d')}
        print(lab['truth'],lab.get('fault_class'),k,'D2wHd kept',r['kept'],r['reasons'][:4],'| needs',v.get('needs'),'h',v.get('h'),'w',v.get('w'))
        print('   ',lab['text'][:200])
