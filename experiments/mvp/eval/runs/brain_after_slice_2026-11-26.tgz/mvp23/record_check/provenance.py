"""For each alternative of record.py WORDS / GENERIC_TIME and d2w.py BASE_PH and its 'the same X of YEAR' words,
count hits in look 1 first forms vs look 2 first forms, the attack/planted texts and the skeptic's texts."""
import json, re, sys, os
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
sys.path.insert(0, S+'/mvp23/record_check/rerun'); sys.path.insert(0,'/home/user/digester/experiments')
sys.dont_write_bytecode=True
import record as RC
def alts(rx):
    # split top-level alternatives of each (?:...) group at depth 1 and outer
    out=[]; 
    for part in split(rx, 0):
        m=re.fullmatch(r'\\b\(\?:(.*)\)(.*)', part)
        if m:
            for a in split(m.group(1),0): out.append(r'\b(?:'+a+')'+m.group(2))
        else: out.append(part)
    return out
def split(s, _):
    d=0; cur=''; res=[]
    i=0
    while i<len(s):
        c=s[i]
        if c=='\\': cur+=s[i:i+2]; i+=2; continue
        if c=='(': d+=1
        if c==')': d-=1
        if c=='|' and d==0: res.append(cur); cur=''
        else: cur+=c
        i+=1
    res.append(cur); return res
strip=lambda t: re.sub(r'\[[^\]]*\]','',t)
sent=json.load(open(S+'/mvp22/raw/sentences.json'))
L1=[strip(r['text']) for r in sent if r['look']=='look1' and r['form_index']==0]
L2=[strip(r['text']) for r in sent if r['look']=='look2' and r['form_index']==0]
from mvp.brain import planted as P
d=P.load(); AT=[]
for c in d['cases']:
    for f in (c.get('forms') or [c.get('form') or {}]):
        AT.append(strip(' '.join([f.get('lead') or '']+list(f.get('points') or []))))
import importlib.util
sp=importlib.util.spec_from_file_location('skcases',S+'/mvp22/skeptic/cases.py'); K=importlib.util.module_from_spec(sp); sp.loader.exec_module(K)
SK=[strip(c[5]) for c in K.CASES+K.TRUE]
rows=[]
srcs=[('record.WORDS:'+g, rx.pattern) for g,rx in RC.WORDS]+[('record.GENERIC_TIME', RC.GENERIC_TIME.pattern)]
import d2w as W
srcs.append(('d2w.BASE_PH', W.BASE_PH.pattern))
srcs.append(('d2w.same_X_of', r"\bthe same (?:span|part|period|stretch|weeks|time|months?) of (?:19|20)\d\d\b"))
for name,pat in srcs:
    for a in alts(pat):
        try: rx=re.compile(a, re.I)
        except re.error: rx=re.compile(re.escape(a), re.I)
        c=[sum(1 for t in T if rx.search(t)) for T in (L1,L2,AT,SK)]
        rows.append((name,a,c))
for name,a,c in rows:
    flag='  <-- never in look 1' if c[0]==0 and sum(c[1:])>0 else ('  (nowhere)' if sum(c)==0 else '')
    print(f"{name:26s} L1 {c[0]:3d} L2 {c[1]:3d} planted {c[2]:4d} skeptic {c[3]:3d}  {a[:90]}{flag}")
