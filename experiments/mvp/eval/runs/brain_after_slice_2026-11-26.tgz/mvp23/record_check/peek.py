import show,json,sys
KEEP=('name','title','label','items','share','previous_items','previous_share','change_vs_previous','change_pts','when','first_watched','last_watched','n','times_opened','channel','theme','new_in_window','status','shorts_share','days','theme_share')
for arg in sys.argv[1:]:
    look,key,rid=arg.split(':')
    rec,res=show.results(look,key); r=res[rid]; sh=r['sheet']; m=r['meta']
    print(f"## {look}:{key}:{rid} '{rec['message']}' tool={r['tool']} kind={sh.get('kind')} win={(sh.get('window') or {}).get('words')!r} filt={ {k:v for k,v in (sh.get('filters') or {}).items() if v} } order={m.get('order')} complete={m.get('complete')} rows_of={m.get('rows_of')} hidden={m.get('hidden')} base={m.get('base')} said={m.get('filters_said')}")
    print('   totals',json.dumps(sh.get('totals')),'| previous',json.dumps(sh.get('previous'))[:300])
    for k,v in sh.items():
        if isinstance(v,list) and v and isinstance(v[0],dict):
            print('  ',k+':', ' | '.join(f"[{i}]"+','.join(f"{kk}={x[kk]}" for kk in KEEP if kk in x) for i,x in enumerate(v)))
        elif isinstance(v,dict) and k in ('new','stopped','library','when'):
            print('  ',k, json.dumps(v)[:600])
    if sh.get('periods'): pass
