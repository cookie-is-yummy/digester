"""Show a held-out sentence with its cited result(s) in compact form, for hand recount. Reads saved records only."""
import json,sys,os,re,glob
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
LOOKS = {"look1": S+"/mvp20/tune/heldout", "look2": S+"/mvp20/fix/heldout_run"}
LAB={(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r for r in json.load(open(S+'/mvp22/raw/sentences.json'))}
def results(look,key):
    rec=json.load(open(f"{LOOKS[look]}/{key}.json"))
    return rec, {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result") and not c["result"].get("is_error")}
def compact(res, lists=None):
    sh=res.get('sheet',{}); m=res.get('meta',{})
    out={'tool':res.get('tool'),'kind':sh.get('kind'),'window':(sh.get('window') or {}).get('words'),'w':[(sh.get('window') or {}).get('start'),(sh.get('window') or {}).get('end')],
         'filters':sh.get('filters'),'order':m.get('order'),'complete':m.get('complete'),'rows_of':m.get('rows_of'),'hidden':m.get('hidden'),'base':m.get('base'),
         'totals':sh.get('totals'),'previous':sh.get('previous')}
    for k,v in sh.items():
        if isinstance(v,list) and v and isinstance(v[0],dict):
            out[k]=[{kk:vv for kk,vv in x.items() if kk in ('name','title','items','share','previous_items','previous_share','change_vs_previous','when','first_watched','last_watched','n','times_opened','channel','label','private','new_in_window','status','shorts_share','days','start','end')} for x in v]
        elif k not in ('totals','previous','window','filters','question','kind') :
            out[k]=v
    return out
if __name__=='__main__':
    for arg in sys.argv[1:]:
        look,key,fi,w,i=arg.split('|')
        lab=LAB.get((look,key,int(fi),w,int(i)),{})
        rec,res=results(look,key)
        print('=====',arg,lab.get('truth'),'| msg:',rec['message'])
        print('S:',lab.get('text'))
        print('recount:',lab.get('recount'))
        rids=sorted(set(re.findall(r'\[(r\d+)\.',lab.get('text',''))))
        for r in rids:
            print(' ',r,json.dumps(compact(res[r]),ensure_ascii=False)[:int(os.environ.get("CUT","2500"))])
