"""record_check harness: one sentence (in a form) through D1b cells (base a = C1a, base d = C1d, D1b's kept
loosenings), the frozen record check (record.py) under a given record list, the copy bound (Mc), no record (M0),
and the frozen D2w check (d2w.py). Uses the rerun copy (hashes asserted). Saved tool results only."""
import hashlib, json, os, sys
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
R = os.path.join(HERE, "rerun")
sys.path.insert(0, R)
fro = {l.split()[1]: l.split()[0] for l in open(os.path.join(R, "frozen.sha256")) if len(l.split()) == 2 and l[:1].isalnum()}
for f in ("record.py", "d2w.py"):
    assert hashlib.sha256(open(os.path.join(R, f), "rb").read()).hexdigest() == fro[f], f
import lib as L  # noqa
import record as RC  # noqa
import d2w as W  # noqa
VB = L.load_checker(os.path.join(R, "src", "verify_d1b.py"), "verify_d1b")
KEEP = {"title_quote", "item_channel", "short_word", "platform_all"}
_IN = None


def inputs():
    global _IN
    if _IN is None:
        _IN = {(look, rec["key"]): (rec, vt, results) for look, rec, vt, results in L.heldout_inputs()}
    return _IN


def setbase(base):
    off, ins = L.CONFIGS["C1a" if base == "a" else "C1d"]
    VB.OFF.clear(); VB.OFF.update(off); VB.INSIGHT = ins
    VB.LOOSE.clear(); VB.LOOSE.update(KEEP)


def sentences(form):
    V = L.V1
    return [("lead", k, s) for k, s in enumerate(V._split(form.get("lead") or ""))] + \
        [("point", k, p) for k, p in enumerate(form.get("points") or [])]


def answer_cells(form, led):
    out = []
    for _w, _k, s in sentences(form):
        mks, _ = L.V1.parse(" ".join(s.split()), led)
        out += [mk.path for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                and not isinstance(mk.value, bool)]
    return out


def cells(form, results, vt, base):
    setbase(base)
    v = VB.check_answer(form, results, vt)
    return {(o.where, o.index): (o.kept, list(o.reasons)) for o in v.outcomes}, v


def run(look, key, sentence, where="P", records=None, carrier=None):
    """Returns dict of verdicts for one new sentence placed as point 0 (where P) under the record's own first-form
    lead (or carrier), or as the lead (where L)."""
    rec, vt, results = inputs()[(look, key)]
    lead0 = carrier if carrier is not None else (rec["forms"][0].get("lead") or "")
    form = {"lead": sentence} if where == "L" else {"lead": lead0, "points": [sentence]}
    tgt = ("lead", 0) if where == "L" else ("point", 0)
    led = L.V1.Ledger(results)
    out = {}
    for base in ("a", "d"):
        cv, v = cells(form, results, vt, base)
        if where == "L":
            ks = [cv[k] for k in cv if k[0] == "lead"]
            out["cells_" + base] = (all(x[0] for x in ks), sorted({r for x in ks for r in x[1]}))
        else:
            out["cells_" + base] = cv.get(tgt, (False, ["missing"]))
            lk = [cv[k] for k in cv if k[0] == "lead"]
            out["carrier_" + base] = all(x[0] for x in lk)
    nd = RC.needs(sentence, led)
    out["needs"] = [g for g, _h, _k in nd]
    out["m0"] = ["no_record:" + g for g, _h, _k in nd]
    why, recs = RC.copy_check(sentence, led, answer_cells(form, led))
    out["mc"], out["mc_rec"] = why, recs
    out["h"] = RC.check_records(sentence, records or [], led) if nd else []
    out["w"] = W.check(sentence, led, vt)
    return out


def kept(o, base, mode, wide):
    c = o["cells_" + base][0]
    r = {"m0": o["m0"], "mc": o["mc"], "h": o["h"]}[mode]
    return bool(c and not r and not (wide and o["w"]))
