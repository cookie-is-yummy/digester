"""Recount from the made-up library rows (experiments/mvp/tests/brain_library.py). Read only. New York dates."""
import sys
from datetime import datetime, date
from zoneinfo import ZoneInfo
from collections import Counter
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.tests import brain_library as B
NY = ZoneInfo("America/New_York")
TH = {"cl": "Gaming clips", "dd": "Digital drawing", "wc": "Watercolor painting", "mc": "Minecraft builds",
      "sr": "Speedruns", "ca": "Calculus lessons", "np": "Number puzzles", "co": "Home cooking", "da": "PRIVATE"}
ROWS = B.rows()
def events(kind="watch", start=None, end=None, friend=False):
    out = []
    for r in ROWS:
        if r.get("friend") and not friend:
            continue
        for k, at in r["events"]:
            if k != kind:
                continue
            d = datetime.fromisoformat(at).astimezone(NY).date()
            if (start and d < date.fromisoformat(start)) or (end and d > date.fromisoformat(end)):
                continue
            out.append((r, d))
    return out
def who(r):
    return r.get("channel") or "@" + r.get("handle", "")
def length(r):
    if r["platform"] == "instagram":
        return "reel"
    if r.get("length") is None:
        return "unknown"
    return "short" if r["length"] <= 60 else "long"
def count(start=None, end=None, by="channel", kind="watch", private=True):
    ev = events(kind, start, end)
    if not private:
        ev = [(r, d) for r, d in ev if r["theme"] != "da"]
    f = {"channel": lambda r: who(r), "theme": lambda r: TH[r["theme"]], "length": length,
         "platform": lambda r: r["platform"]}[by]
    return Counter(f(r) for r, _d in ev), len(ev)
