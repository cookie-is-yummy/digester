"""Run cases.py (hash asserted) through harness.py. Writes cases_out.json and cases_out.txt."""
import hashlib, json, os, sys
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
h = open(os.path.join(HERE, "cases.sha256")).read().split()[0]
assert hashlib.sha256(open(os.path.join(HERE, "cases.py"), "rb").read()).hexdigest() == h, "cases.py changed after freeze"
import harness as Hn  # noqa
import cases as C  # noqa
DUP = {"N04", "N08", "N22", "T06", "T11", "T12", "T13"}   # dedupe.py: >= 0.93 to an attack, audit, skeptic or look text
out, lines = [], []
for cid, look, key, where, truth, cls, text, recount, rec in C.CASES:
    o = Hn.run(look, key, text, where, rec)
    row = {"id": cid, "look": look, "key": key, "truth": truth, "class": cls, "text": text, "recount": recount,
           "rec": rec, "dup": cid in DUP, **{k: v for k, v in o.items() if k != "mc_rec"}, "mc_rec": o["mc_rec"]}
    for base in ("a", "d"):
        row[f"D1b/{base}"] = o[f"cells_{base}"][0]
        for mode, mn in (("m0", "M0"), ("h", "R"), ("mc", "Mc")):
            row[f"D2_{mn}/{base}"] = Hn.kept(o, base, mode, False)
            row[f"D2w_{mn}/{base}"] = Hn.kept(o, base, mode, True)
    out.append(row)
json.dump(out, open(os.path.join(HERE, "cases_out.json"), "w"), indent=1, default=str)
cols = ["D1b/d", "D2_M0/d", "D2_R/d", "D2_Mc/d", "D2w_R/d", "D2w_Mc/d", "D1b/a", "D2_R/a", "D2w_R/a"]
lines.append("id    truth class                          " + " ".join(f"{c:>8s}" for c in cols) + "  | cells_d reasons | needs | rec verdict | mc | d2w")
for r in out:
    k = lambda c: "KEPT" if r[c] else "-"
    lines.append(f"{r['id']:5s} {r['truth']}{'*' if r['dup'] else ' '}   {r['class'][:30]:30s} " + " ".join(f"{k(c):>8s}" for c in cols) +
                 f"  | {r['cells_d'][1][:3]} car={r.get('carrier_d','lead')} | {r['needs']} | {r['h']} | {r['mc'][:2]} | {r['w']}")
open(os.path.join(HERE, "cases_out.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
