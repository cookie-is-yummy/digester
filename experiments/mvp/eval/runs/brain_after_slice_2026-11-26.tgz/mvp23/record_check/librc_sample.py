"""Library recount of the 20 sampled true-kept sentences and two caught ones (F11.0 l2 p0, D03.2). Read only."""
import sys; sys.path.insert(0, '.')
import librc as L
from collections import Counter
def ev(s, e, priv=False, long_only=False):
    out = []
    for r, d in L.events('watch', s, e):
        if r['theme'] == 'da' and not priv: continue
        if long_only and L.length(r) != 'long': continue
        out.append(r)
    return out
def by(rs, f): return Counter(f(r) for r in rs)
ch = L.who; th = lambda r: L.TH[r['theme']]
res = []
def chk(name, said, got): res.append((name, said, got, said == got)); 
a = ev(None, None, long_only=True); chk('B14.0 l1 p0 long all history', 651, len(a)); chk('  Minecraft builds long', 163, by(a, th)['Minecraft builds'])
a = ev('2024-01-01', '2024-12-31'); chk('I01.0 l1 2024 shown (private out)', 8, len(a)); chk('  food share', 8, by(a, th)['Home cooking'])
a = ev('2025-01-01', '2025-12-31'); c = by(a, th); chk('D08.1 2025 cooking', 8, c['Home cooking']); chk('  Pan Theory of cooking', 8, sum(1 for r in a if r['theme'] == 'co' and ch(r) == 'Pan Theory'))
chk('  (2025 total, for the 8-of-8 reading)', 62, len(a))
a = [r for r in ev('2026-10-03', '2026-10-30') if r['theme'] not in ('cl', 'mc', 'sr')]; c = by(a, th)
chk('B02.0 l2 without gaming lately: art', 32, c['Digital drawing'] + c['Watercolor painting']); chk('  base', 66, len(a))
a = [r for r in ev('2026-10-03', '2026-10-30') if r['theme'] != 'mc']; c = by(a, th); chk('C02.0 l1 without MB: gaming', 59, c['Gaming clips'] + c['Speedruns']); chk('  base', 125, len(a))
a = ev('2026-01-01', '2026-10-30'); m = Counter(r for r in [None]); 
mon = Counter(d.month for r, d in L.events('watch', '2026-01-01', '2026-10-30') if r['theme'] != 'da')
chk('F11.0 l2 Oct 2026', 142, mon[10]); chk('  Sep 2026', 44, mon[9]); chk('  Oct is the top month of 2026', 10, max(mon, key=mon.get))
a = ev('2026-10-01', '2026-10-30'); c = by(a, ch); chk('C01.0 Limit Lane Oct', 4, c['Limit Lane']); chk('  Gaming Daily Oct', 5, c['Gaming Daily'])
a = ev('2026-01-01', '2026-10-30'); chk('F04.0 speedruns 2026', 0, by(a, th)['Speedruns'])
a = [r for r in ev('2026-10-01', '2026-10-30') if r['theme'] not in ('cl', 'mc', 'sr')]; c = by(a, ch).most_common(2)
chk('A06.0 Oct without gaming: second', ('Pixel Pencil', 29), c[1])
a = ev('2026-01-01', '2026-10-30'); c = by(a, ch).most_common(2); chk('K03.0 l2 p1 2026 top two channels', [('Pixel Pencil', 92), ('Clip Factory', 61)], c)
a = ev('2026-10-01', '2026-10-30', long_only=True); c = by(a, ch).most_common(2); chk('A07.0 Oct long: second', ('Pixel Pencil', 29), c[1])
a = ev('2026-10-03', '2026-10-30'); chk('D10.1 Clip Factory lately', 56, by(a, ch)['Clip Factory'])
d30 = [r['caption'] for r, d in L.events('watch', '2026-10-30', '2026-10-30')]; chk('D03.1 Cooking soup opened 30 Oct (NY)', True, 'Cooking soup on the 30th' in d30)
a = ev('2026-09-01', '2026-09-30'); c = by(a, ch); chk('D01.1 Sep 2026 Pixel Pencil', 31, c['Pixel Pencil']); chk('  base', 44, len(a)); chk('  top', 'Pixel Pencil', c.most_common(1)[0][0])
a = [r for r in ev('2026-10-01', '2026-10-30') if L.length(r) not in ('short', 'reel')]; chk('A01.5 Oct without shorts/reels: Limit Lane', 4, by(a, ch)['Limit Lane'])
a = ev('2026-01-01', '2026-10-30'); c = by(a, th).most_common(2); chk('C06.0 2026 top theme and second', [('Digital drawing', 92), ('Gaming clips', 66)], c)
a = ev('2026-10-01', '2026-10-30'); yt = [r for r in a if r['platform'] == 'youtube']
chk('F11.0 l2 p0 Oct Shorts of YouTube (48%)', 48, round(100 * sum(L.length(r) == 'short' for r in yt) / len(yt)))
chk('  Oct Shorts of all opened (claim says of October videos)', 46, round(100 * sum(L.length(r) == 'short' for r in a) / len(a)))
g = [r for r in a if r['theme'] in ('cl', 'mc', 'sr')]; chk('D03.2 gaming Oct', 72, len(g))
cnt = Counter(r['id'] for r, d in L.events('watch', '2026-10-01', '2026-10-30')); chk('  every Oct video opened once', 1, max(cnt.values()))
for n, s, g, ok in res: print(('OK ' if ok else 'XX ') + f"{n}: said {s} counted {g}")
