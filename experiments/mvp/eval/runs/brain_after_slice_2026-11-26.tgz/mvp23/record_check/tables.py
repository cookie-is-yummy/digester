import json
out={r['id']:r for r in json.load(open('cases_v2_out.json'))}
v1={r['id']:r for r in json.load(open('cases_out.json'))}
KIND={"rank":"N01 N02 N03 N07 N34 N39 RT2","tie":"N04 N05 N06 RT4","list":"N08 N09 N13 N44 RT1 RT5",
 "rest / most of":"N17 N18 N19 N20 RT6","new":"N13 N21 N22 N23 RT1","move":"N24 N25 N28 N29 N30 N31",
 "direction":"N26 N27 N29 RT4","period":"N32 N33 N34 RT2 RT3","base":"N35 N36 RT7","scope":"N37 N38 N39",
 "only/all":"N10 N11 N12 N14 N15 N16 N38","dates (first, last, order)":"N40 N41 N42 N43"}
L=[]
L.append("COVERAGE (v2 run; F sentences; * = near-duplicate of an existing set, c = control expected caught)")
L.append(f"{'kind':28s} {'n':>3s} {'D1b/d':>6s} {'D2_R/d':>7s} {'D2w_R/d':>8s} {'D2w_Mc/d':>9s} {'D2w_R/a':>8s}  ids out under D2w_R/d")
for k,ids in KIND.items():
    ids=ids.split()
    def n(d): return sum(1 for i in ids if out[i][d])
    L.append(f"{k:28s} {len(ids):3d} {n('D1b/d'):6d} {n('D2_R/d'):7d} {n('D2w_R/d'):8d} {n('D2w_Mc/d'):9d} {n('D2w_R/a'):8d}  {[i for i in ids if out[i]['D2w_R/d']]}")
L.append("")
L.append("EVERY NEW SENTENCE (v2: lone lead; R = the careless record for F, the honest record for T; KEPT = let out)")
cols=["D1b/d","D2_M0/d","D2_R/d","D2_Mc/d","D2w_R/d","D2w_Mc/d","D1b/a","D2_R/a","D2w_R/a"]
L.append(f"{'id':5s} {'t':2s} "+" ".join(f"{c:>8s}" for c in cols)+"  why caught (d) | v1 placement")
for i,r in out.items():
    why=[]
    if not r['cells_d'][0]: why.append('cells:'+','.join(r['cells_d'][1]))
    if r['h']: why.append('record:'+','.join(r['h']))
    if r['w']: why.append('d2w:'+','.join(r['w']))
    a=[] if r['cells_a'][0] else ['a-cells:'+','.join(r['cells_a'][1])]
    tag=('*' if r['dup'] else '')+('c' if 'control' in r['class'] else '')
    L.append(f"{i:5s} {r['truth']+tag:3s}"+" ".join(f"{('KEPT' if r[c] else '-'):>8s}" for c in cols)+f"  {'; '.join(why+a) or '-'} | v1 cells_d {v1[i]['cells_d'][1] or 'ok'}")
    L.append(f"      {r['text']}")
    L.append(f"      rows: {r['recount']}   record: {json.dumps(r['rec'])}")
open('tables.txt','w').write("\n".join(L)+"\n")
print("\n".join(L[:16]))
