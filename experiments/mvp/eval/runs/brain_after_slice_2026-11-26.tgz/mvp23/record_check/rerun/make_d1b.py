"""D1b: copy the paper's cells-only checker (mvp22/paper/src/verify_c1.py) into record/src/verify_d1b.py with a LOOSE
set of marker-bookkeeping loosenings, each a switch (nothing else changes). With LOOSE empty the copy is verify_c1.py
(checked row for row in d1b.py). Loosenings:
  title_quote   a title in quotes before its row marker ('"Watercolor wet on wet"[r1.items[0]]'), or trimmed of '#n'
  item_channel  an item's own channel name before the item's row marker ('1 video from Wet Paper[r1.items[0]]')
  short_word    'a short' / 'a long video' before an item's row marker, when the item's length is that
  platform_all  'on YouTube[r1.totals.by_platform.youtube]' (a marker after a word, no number) when that cell equals
                the result's totals.items (every item is on that platform)
  num_noun      'N days[cell]': a number, one word, then the marker, when N equals the cell
  limits_off    the limits rule and the self-talk rule off
  limits_regex  only the LIMITS word list off (the self-talk rule stays)
  too_long      SENT_MAX raised by 60 characters
  repeat_off    the 'same cells said again' rule off
  uname_row     an unmarked name passes when it equals a row name of any of the turn's results
  uname_nonum   as uname_row, but only when no number follows the name within its clause
  (filler and typed_name are insight's codes: switched off through OFF in d1b.py)"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join('/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad', "mvp22", "paper", "src", "verify_c1.py")
OUT = os.path.join(HERE, "src", "verify_d1b.py")
s = open(SRC, encoding="utf-8").read()


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:80], s.count(old))
    s = s.replace(old, new)


sub('INSIGHT = "on"   # paper test', 'INSIGHT = "on"   # paper test\nLOOSE = set()    # mvp23 record: D1b loosenings')
# title_quote, item_channel, short_word (row markers)
sub("""            names = _row_names(v, rest)
            low = _low(prefix)
            hit = next((n for n in sorted(names, key=len, reverse=True) if low.endswith(_low(n))), None)""",
    """            names = _row_names(v, rest)
            pfx = prefix
            if "title_quote" in LOOSE:
                pfx = re.sub(r"[\\"“”]\\s*$", "", prefix)
                names = names + [re.sub(r"\\s*#\\s*\\d+\\s*$", "", n) for n in names if re.search(r"#\\s*\\d+\\s*$", n)]
            if "item_channel" in LOOSE and re.match(r"^items\\[\\d+\\]$", rest) and isinstance(v.get("channel"), str):
                names = names + [v["channel"]]
            if "short_word" in LOOSE and re.match(r"^items\\[\\d+\\]$", rest) and v.get("length") in ("short", "long"):
                names = names + (["a short", "a Short"] if v["length"] == "short" else ["a long video", "a long one"])
            low = _low(pfx)
            hit = next((n for n in sorted(names, key=len, reverse=True) if low.endswith(_low(n))), None)""")
sub("""                mt = re.search(r"\\s+".join(re.escape(w) for w in hit.split()) + r"\\s*$", prefix, re.I)""",
    """                mt = re.search(r"\\s+".join(re.escape(w) for w in hit.split()) + r"\\s*$", pfx, re.I)""")
# num_noun (value markers)
sub("""        else:
            t = NUM_TAIL.search(prefix)
            if t:
                mk.start, mk.said = prev_end + t.start(), t.group(0).strip()
                mk.num, mk.unit = _num_of(t.group("num")), (t.group("unit") or "").strip().lower()
                mk.hedge = (t.group("hedge") or "").lower()
                mk.sign = t.group("sign") or ""
        out.append(mk)""",
    """        else:
            t = NUM_TAIL.search(prefix)
            if t:
                mk.start, mk.said = prev_end + t.start(), t.group(0).strip()
                mk.num, mk.unit = _num_of(t.group("num")), (t.group("unit") or "").strip().lower()
                mk.hedge = (t.group("hedge") or "").lower()
                mk.sign = t.group("sign") or ""
            elif "num_noun" in LOOSE and isinstance(v, (int, float)) and not isinstance(v, bool):
                t2 = re.search(r"(?<![\\w.])(?P<num>\\d{1,3}(?:,\\d{3})*|\\d+)\\s+(?P<unit>[A-Za-z]+)\\s*$", prefix)
                if t2 and float(t2.group("num").replace(",", "")) == float(v):
                    mk.start, mk.said = prev_end + t2.start(), t2.group(0).strip()
                    mk.num, mk.unit = float(t2.group("num").replace(",", "")), t2.group("unit").lower()
        out.append(mk)""")
# platform_all
sub("""            if mk.kind == "value" and not mk.said and _measure(mk.rest, mk.value)[1] not in ("name",):""",
    """            if mk.kind == "value" and not mk.said and "platform_all" in LOOSE and \\
                    re.search(r"(?:^|\\.)by_platform\\.(youtube|instagram)$", mk.rest or "") and \\
                    re.search(r"\\bon (?:youtube|instagram)\\s*$", raw[:mk.start], re.I) and \\
                    re.search(mk.rest.rsplit(".", 1)[1], raw[max(0, mk.start - 12):mk.start], re.I) and \\
                    isinstance(((ledger.get(mk.rid).sheet or {}).get("totals") or {}).get("items"), (int, float)) and \\
                    mk.value == ((ledger.get(mk.rid).sheet or {}).get("totals") or {}).get("items"):
                continue   # mvp23 D1b: 'all on YouTube[cell]', the cell being every item of the result
            if mk.kind == "value" and not mk.said and _measure(mk.rest, mk.value)[1] not in ("name",):""")
# limits
sub("""    if LIMITS.search(no_win):
        add("limits")
    elif _SELF_TALK.search(plain):""",
    """    if "limits_off" in LOOSE:
        pass
    elif LIMITS.search(no_win) and "limits_regex" not in LOOSE:
        add("limits")
    elif _SELF_TALK.search(plain):""")
# too_long
sub("""    if len(strip_markers(raw)) > SENT_MAX:
        out.reasons.append("too_long")""",
    """    if len(strip_markers(raw)) > SENT_MAX + (60 if "too_long" in LOOSE else 0):
        out.reasons.append("too_long")""")
# repeat
sub("""        if key and any(key <= c for c in claimed):""",
    """        if key and "repeat_off" not in LOOSE and any(key <= c for c in claimed):""")
# uncited names
sub("""        if base_n in cited_names or base_n in allowed_scope:
            plain_names.append((a, b, base_n))
            continue""",
    """        if base_n in cited_names or base_n in allowed_scope:
            plain_names.append((a, b, base_n))
            continue
        if ("uname_row" in LOOSE or "uname_nonum" in LOOSE) and base_n in names_idx:
            tail = re.split(r"[,;.:()]|\\band\\b|\\bbut\\b", blank2[b:], maxsplit=1)[0]
            if "uname_row" in LOOSE or not re.search(r"\\d", tail):
                plain_names.append((a, b, base_n))
                continue""")
os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, "w", encoding="utf-8").write(s)
print("wrote", OUT)
