import sys,re,difflib,json
S='/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad'
sys.path.insert(0,'/home/user/digester/experiments'); sys.dont_write_bytecode=True
import cases as C
strip=lambda t: re.sub(r'\[[^\]]*\]','',t).lower()
from mvp.brain import planted as P
d=P.load(); other=[]
for c in d['cases']:
    for f in (c.get('forms') or [c.get('form') or {}]):
        for s in [f.get('lead') or '']+list(f.get('points') or []): other.append(('planted:'+c['id'],strip(s)))
import importlib.util
sp=importlib.util.spec_from_file_location('skcases',S+'/mvp22/skeptic/cases.py'); K=importlib.util.module_from_spec(sp); sp.loader.exec_module(K)
other+= [('skeptic:'+c[0],strip(c[5])) for c in K.CASES+K.TRUE]
other+= [('look:'+r['key'],strip(r['text'])) for r in json.load(open(S+'/mvp22/raw/sentences.json'))]
mx=0
for c in C.CASES:
    t=strip(c[6]); best=max(other,key=lambda o: difflib.SequenceMatcher(None,t,o[1]).ratio())
    r=difflib.SequenceMatcher(None,t,best[1]).ratio(); mx=max(mx,r)
    if r>0.8: print(c[0], round(r,2), best[0], '|', best[1][:100])
print('max similarity', round(mx,2), 'n', len(C.CASES), 'F', sum(c[4]=='F' for c in C.CASES), 'T', sum(c[4]=='T' for c in C.CASES))
