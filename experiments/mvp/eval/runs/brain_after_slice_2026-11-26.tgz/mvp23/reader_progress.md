# reader progress (key: reader; no repo change; live calls to claude-haiku-5-5 only; cap $3.00)
Files: S/mvp23/reader/. Spend is summed from Reply.cost_usd in reader/calls.jsonl (the ledger under data/ is not read).

## Steps
- [x] 0 read brief, paper notes, comparison.txt, provider.py, llm.py, eval_brain.py run path, loop.present, planted.py
- [x] 1 build.py -> sets.json (dev: look 1 first forms + even attack; test: look 2 first forms + odd attack + audit
      + skeptic if complete), cells-only marks (C1a = D1, C1d = range) from paper/sim.json
- [x] 2 prompt written from classes, look 1, even attack only; freeze prompt + tool schema + layout code + setting
- [x] 3 dev runs: thinking off (forced tool) vs adaptive low (auto + strict tool); pick one
- [x] 4 test runs x2 (frozen)
- [x] 5 safety probe (~10 calls)
- [x] 6 tables: table.txt, missed.txt, false_alarms.txt

## Notes
- Units: reader/units.json (dev 160, test 236) + reader/units_skeptic.json (68, test; skeptic complete at 00:38).
- Dev: v1 off, v1 adaptive, v2 adaptive (runs/dev_*). Picked adaptive low with prompt v2. Frozen in reader/freeze.txt
  (prompt sha256 bf42207871f7...) before any test call. Scoring rules: reader/scoring_rules.txt.
- Test runs test_r1, test_r2 done (frozen; 304 units each incl. skeptic). Probe: runs/probe*.jsonl, probe_summary.txt.
- Class map for look 2, odd-only attack prefix (owner) and skeptic classes added to classes.py AFTER the freeze.
- Diagnostic after the test (not pre-registered): audit units with a window lead (audit_lead.py, auditlead_r1/r2).
- Outputs: reader/table.txt, missed.txt, false_alarms.txt, reader_prompt_v2.md + reader_prompt_v2.sha256, freeze.txt.
- DONE apart from the final report.

## Running spend
$1.02 total, 1,371 requests (reader/calls.jsonl); cap $3.00 not reached. Last: dev_off_v2 (dev only, after the test), timing.py.
