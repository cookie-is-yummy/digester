# reader_check progress (key: reader_check; refute the reader's claims; live calls claude-haiku-5-5 only; cap $0.75)
Files: S/mvp23/reader_check/. Spend summed from my own calls log reader_check/calls.jsonl.

## Steps
- [x] 0 read brief, reader files (prompt, reader.py, build.py, score.py, classes.py, scoring_rules, make_tables)
- [x] 1 recompute table from raw replies (recompute.py): all headline counts match; rows/sid/n consistent; no missing verdicts. dedupe by text: look2 true 107 rows = 101 texts, flags unchanged (no double count of flags). Attack twins: 91 of 92 odd attack false have an even dev case of the same class prefix, 50 on the same ledger
- [x] 2 freshness: hashes match freeze.txt; calls.jsonl order dev->test; prompt mtime 00:36:53 < freeze 00:38:38 < test_r1 end 00:42:18. Ledger not read (data/ off limits). Prompt words test-only: 'overall','in total','nothing else','until','the other N' (from brief)
- [x] 3 hand-read 30 (hand30.txt): reason right 29, partly 1 (F15), wrong 0; caught flags only
- [x] 4 cases.py (42 F incl 4 borderline, 25 T; +10 long-layout copies), labels frozen labels_frozen.txt 01:08:16Z before calls; C1a marks (build_new.py); runs new_r1,new_r2 (their reader.py, HERE swapped); new_table.txt
- [x] 5 probes.py: title instruction (3 + 2 reverse) and flattery (3), 3 runs each + clean_3: no obedience (probe_table.txt)
- [x] 6 report.txt written; advisor fixes done: make_tables/timing re-run in regen/ (identical), mapping check (overlap test), all 30 cited figures checked (hand30_cellcheck.txt), private items located in library (50 in 2024; friend = IG save 9 Oct 2026), carriers by distinct text 4/29 (5/29)
- [x] 7 batch 2 (cases2.py, frozen 01:21:19, after batch 1): new2_r1/r2: cells-kept false 5/5 both, true 2/5 (1/5); new2_table.txt
- DONE

## Running spend
$0.1885 (220 requests, reader_check/calls.jsonl); cap $0.75
