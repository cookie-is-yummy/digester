import json, os, sys
sys.path.insert(0, "/home/user/digester/experiments")
import mvp.brain  # noqa
from mvp.brain import loop as BL
D = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/fix/heldout_run"
def present(env):
    env = {k: v for k, v in env.items() if k not in ("cost_usd", "took_ms")}
    return BL.present(env)
def rec(key):
    return json.load(open(os.path.join(D, key + ".json")))
if __name__ == "__main__":
    for k in sys.argv[1:]:
        r = rec(k)
        print("=" * 30, k, "::", r["message"])
        for c in r["calls"]:
            if c.get("result"):
                print(present(c["result"]))
                print("--")
