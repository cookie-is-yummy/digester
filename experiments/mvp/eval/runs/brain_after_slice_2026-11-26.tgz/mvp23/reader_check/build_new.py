"""Build reader units from cases.py (their unit shape, their layout) and mark cells-only (C1a) with paper verify_c1.
Planted-style Turn (message, screen, today 2026-11-22; no name index): differs from the held-out harness turn."""
import hashlib, importlib.util, json, os, sys
from datetime import date
HERE = os.path.dirname(os.path.abspath(__file__))
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
PAPER = os.path.join(S, "mvp22", "paper")
sys.path.insert(0, "/home/user/digester/experiments"); sys.path.insert(0, PAPER); sys.path.insert(0, HERE)
sys.dont_write_bytecode = True
import taxonomy as T
import mvp.brain  # noqa
from mvp.brain import loop as BL
spec = importlib.util.spec_from_file_location("mvp.brain.verify_c1", os.path.join(PAPER, "src", "verify_c1.py"))
V = importlib.util.module_from_spec(spec); V.__package__ = "mvp.brain"; sys.modules["mvp.brain.verify_c1"] = V
spec.loader.exec_module(V)
V.OFF.clear(); V.OFF.update(T.off_set(False)); V.INSIGHT = "on"   # C1a
import cases as CS
D = os.path.join(S, "mvp20/fix/heldout_run")

def present(env):
    return BL.present({k: v for k, v in env.items() if k not in ("cost_usd", "took_ms")})

def unit(c, points, uid, layout):
    rec = json.load(open(os.path.join(D, c["rec"] + ".json")))
    results = {x["rid"]: x["result"] for x in rec["calls"] if x.get("rid") and x.get("result") and not x["result"].get("is_error")}
    turn = V.Turn(message=rec["message"], screen=json.dumps(rec.get("screen") or {}, sort_keys=True), today=date(2026, 11, 22))
    form = {"understood": "", "lead": c["lead"], "points": points, "items": [], "chart": None, "outside": [],
            "ask_back": None, "offers": [], "setup": None, "corrects_previous": False, "hand_back": None}
    v = V.check_answer(form, results, turn)
    kind, _, n = c["target"].partition(":")
    ss = []
    for o in v.outcomes:
        if o.where not in ("lead", "point") or not (o.text or "").strip():
            continue
        is_t = o.where == kind and (kind == "lead" or o.index == int(n or 0))
        ss.append({"sid": f"{uid}:{o.where}{o.index}", "where": o.where, "index": o.index, "text": o.text,
                   "label": ({"F": "false", "T": "true"}[c["label"]] if is_t else "none"),
                   "target": is_t, "cells_c1a": o.kept, "c1a_reasons": list(o.reasons),
                   "cls": c["cls"], "diff": c["diff"], "tier": c["tier"], "listword": c["listword"], "why": c["why"]})
    return {"uid": uid, "case": c["id"], "layout": layout, "set": "new", "split": "new", "kind": "planted",
            "user": BL.user_text(rec["message"], rec.get("screen") or {}),
            "results": [present(x["result"]) for x in rec["calls"] if x.get("result")], "sentences": ss,
            "private_line": v.private_line}

units = []
for c in CS.C:
    units.append(unit(c, list(c["points"]), "new_" + c["id"], "short"))
    if c["id"] in CS.LONG:
        units.append(unit(c, list(c["points"]) + CS.LONG[c["id"]], "newL_" + c["id"], "long"))
json.dump(units, open(os.path.join(HERE, "units_new.json"), "w"), indent=0, ensure_ascii=False)
for u in units:
    t = [s for s in u["sentences"] if s["target"]]
    assert len(t) == 1, u["uid"]
    car = [s for s in u["sentences"] if not s["target"]]
    print(u["uid"], t[0]["label"], "c1a_kept" if t[0]["cells_c1a"] else "C1A_DROP " + ",".join(t[0]["c1a_reasons"][:3]),
          "| carriers dropped:" + ",".join(f"{s['where']}{s['index']}:{s['c1a_reasons'][:2]}" for s in car if not s["cells_c1a"]))
h = hashlib.sha256(open(os.path.join(HERE, "cases.py"), "rb").read()).hexdigest()
print("cases.py sha256", h)
