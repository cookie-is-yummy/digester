"""Run THEIR frozen reader (reader/reader.py, prompt reader_prompt_v2.md) on my units, with calls and the spend cap
in my folder. Usage: python3 run_reader.py RUN UNITS_FILE"""
import hashlib, os, sys
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
THEIRS = os.path.join(os.path.dirname(HERE), "reader")
sys.path.insert(0, THEIRS)
import reader as R
assert hashlib.sha256(open(R.PROMPT_FILE, "rb").read()).hexdigest().startswith("bf42207871f7aaadcad72df5db3497b4"), "prompt changed"
assert hashlib.sha256(open(os.path.join(THEIRS, "reader.py"), "rb").read()).hexdigest().startswith("5fb9eec8eed82f80"), "reader.py changed"
R.HERE = HERE
R.SPEND_CAP = 0.75
run, units = sys.argv[1], sys.argv[2]
R.main([run, "adaptive", "new", "", "--units", units])
