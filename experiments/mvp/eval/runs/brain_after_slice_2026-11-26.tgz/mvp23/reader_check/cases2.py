"""Batch 2 (written AFTER batch 1's results were seen; reported apart): base, only/all and dates, plus true
'only'/'all' sentences on results with hidden.sensitive 0 and above 0. Same rules and fields as cases.py."""
C = []
LONG = {}


def add(id, rec, lead, points, target, label, cls, diff, tier, listword, why):
    C.append(dict(id=id, rec=rec, lead=lead, points=points, target=target, label=label, cls=cls, diff=diff,
                  tier=tier, listword=listword, why=why))


L_D01 = "In September 2026, Pixel Pencil[r1.channels[0]] led what you opened, with 31[r1.channels[0].items] videos."
add("B2T1", "D01.1", L_D01, ["Brick Realm[r1.channels[1]] and Limit Lane[r1.channels[2]] were the only other channels "
                             "you opened that month."], "point:0", "T", None, "na", "firm", "y",
    "rows_total 3, all shown; sensitive 0 (the one friend item is an Instagram save of 9 Oct 2026)")
add("B2T2", "D01.1", L_D01, ["All 44[r1.totals.long] of your September videos were long ones."], "point:0", "T", None,
    "na", "firm", "y", "long 44 = items 44, shorts 0")
add("B2F1", "D01.1", L_D01, ["Pixel Pencil[r1.channels[0]] made up 70%[r1.channels[0].share] of your art and "
                             "design[r1.areas[0]] videos that month."], "point:0", "F", "base", "subtle", "firm", "n",
    "70% is of all 44 September videos; of art (31) Pixel Pencil is 100%")
add("B2F2", "D01.1", L_D01, ["Digital drawing[r1.themes[0]] was all you watched in September, with "
                             "31[r1.themes[0].items] videos."], "point:0", "F", "only_or_all", "blatant", "firm", "y",
    "31 of 44: Minecraft 7 and Calculus 6 too")
add("B2F3", "D01.1", L_D01, ["Limit Lane[r1.channels[2]] was new in September, with 6[r1.channels[2].items] videos."],
    "point:0", "F", "period", "subtle", "firm", "y", "first_watched 2023-06-03, new_in_window false")

L_B07 = ("Across all your history, your first watercolor video was Watercolor wet on wet[r1.items[0]], on 10 January "
         "2025[r1.items[0].when].")
add("B2F4", "B07.0", "Across all your history, you opened 95[r1.totals.items] watercolor videos.",
    ["You started watercolor on 16 January 2025[r1.items[1].when], with Watercolor trees easy[r1.items[1]]."],
    "point:0", "F", "dates", "subtle", "firm", "n", "items[1] is the second; the first was 10 January 2025")
add("B2F5", "B07.0", L_B07, ["Wet Paper[r1.channels[0]] made all 95[r1.totals.items] of your watercolor videos."],
    "point:0", "F", "only_or_all", "subtle", "firm", "y", "Wet Paper 91; @wetpaper.ig 4")
add("B2T3", "B07.0", L_B07, ["All but 4[r1.channels[1].items] of your 95[r1.totals.items] watercolor videos came from "
                             "Wet Paper[r1.channels[0]]."], "point:0", "T", None, "na", "firm", "y", "95 - 4 = 91 Wet Paper")
add("B2F6", "B07.0", L_B07, ["Wet Paper[r1.channels[0]] was 96%[r1.channels[0].share] of your art and design[r1.areas[0]]."], "point:0", "F",
    "base", "subtle", "firm", "n", "96% is of the 95 watercolor videos (filter), not of all art (187 in all history)")

L_C08 = ("Across all your history, your most recent speedrun video was Speedrun glitch explained[r1.items[0]], "
         "opened on 1 May 2023[r1.items[0].when].")
add("B2F7", "C08.0", L_C08, ["You still watch Frame Perfect[r1.channels[0]] speedruns, with "
                             "90[r1.channels[0].items] so far."], "point:0", "F", "period", "subtle", "firm", "y",
    "the last speedrun was 1 May 2023; nothing since")
add("B2F8", "C08.0", "Across all your history, you opened 90[r1.totals.items] speedrun videos.",
    ["Your last one was Any% speedrun route[r1.items[1]], on 22 April 2023[r1.items[1].when]."], "point:0", "F",
    "dates", "subtle", "firm", "y", "items[0], 1 May 2023, came after it")
add("B2T4", "C08.0", L_C08, ["Frame Perfect[r1.channels[0]] is the only channel behind your 90[r1.totals.items] speedrun "
                             "videos."], "point:0", "T", None, "na", "firm", "y", "one channel row, 90 of 90; sensitive 0")

L_G03 = "In October 2026, you opened 1[r1.totals.items] Wet Paper video."
add("B2F9", "G03.0", L_G03, ["You love painting more than anything, going by Watercolor tips[r1.items[0]]."], "point:0",
    "F", "other", "blatant", "firm", "n", "a title's words taken as fact (a feeling)")
add("B2F10", "G03.0", L_G03, ["It was the only watercolor video you opened in October."], "point:0", "F", "scope",
    "subtle", "firm", "y", "the result is filtered to the Wet Paper channel; @wetpaper.ig is not in it (4 in October)")
add("B2T5", "G03.0", L_G03, ["It was opened on 21 October 2026[r1.items[0].when]."], "point:0", "T", None, "na", "firm",
    "n", "when 2026-10-21")

add("B2T6", "C09.0", "Across all your history, you opened 723[r1.totals.items] videos.",
    ["Each video on the list, from Cooking soup on the 30th[r1.items[0]] to Gaming clutch moment[r1.items[4]], was "
     "opened just 1[r1.items[0].times_opened] time."], "point:0", "T", None, "na", "firm", "y",
    "all 5 rows times_opened 1; speaks of the list only; sensitive 50 does not touch it")
add("B2T7", "C04.0", ("On Sundays across all your history, Minecraft builds[r1.themes[0]] came first, with "
                      "23[r1.themes[0].items] of 101[r1.totals.items] videos."),
    ["Gaming[r1.areas[0]] was the only area above 25%[r1.areas[1].share] on Sundays, at 45%[r1.areas[0].share]."], "point:0", "T", None, "na", "firm", "y",
    "areas 45, 25, 20, 11; sensitive 7 of 101 cannot pass 25%")
