"""Independent recount of the reader's table from its raw run rows. Written from scratch; reads units and runs only."""
import json, collections, sys, os
R = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp23/reader"
U = json.load(open(f"{R}/units.json")) + json.load(open(f"{R}/units_skeptic.json"))
UB = {u["uid"]: u for u in U}

def raw(name):
    rows = [json.loads(x) for x in open(f"{R}/runs/{name}.jsonl") if x.strip()]
    return rows

def check_rows(name):
    rows = raw(name)
    per = collections.Counter(r["uid"] for r in rows)
    probs = []
    dup = [k for k, v in per.items() if v > 1]
    if dup: probs.append(f"units with >1 row: {dup[:5]} ({len(dup)})")
    notok = [r["uid"] for r in rows if not r.get("ok")]
    if notok: probs.append(f"not ok: {notok}")
    for r in rows:
        u = UB[r["uid"]]
        if len(r["sentences"]) != len(u["sentences"]):
            probs.append(f"{r['uid']} sentence count {len(r['sentences'])} vs {len(u['sentences'])}")
        for i, (a, b) in enumerate(zip(r["sentences"], u["sentences"]), 1):
            if a["sid"] != b["sid"] or a["n"] != i:
                probs.append(f"{r['uid']} sid/n mismatch at {i}")
        miss = [s for s in r["sentences"] if s["verdict"] == "missing"]
        if miss: probs.append(f"{r['uid']} missing verdicts {len(miss)}")
        # verdict 'problem' with class none or ok with a class
        for s in r["sentences"]:
            if s["verdict"] == "problem" and s["class"] == "none": probs.append(f"{s['sid']} problem/none")
            if s["verdict"] == "ok" and s["class"] not in ("none", None): probs.append(f"{s['sid']} ok/{s['class']}")
    return rows, probs

def flags(rows):
    return {s["sid"]: s for r in rows for s in r["sentences"]}

def tally(name, split, se, base="cells_c1a"):
    rows, _ = check_rows(name)
    f = flags(rows)
    F = T = Fth = Tth = caught = fa = 0
    for u in U:
        if u["split"] != split or u["set"] != se: continue
        for s in u["sentences"]:
            if not s["target"]: continue
            fl = f.get(s["sid"], {}).get("verdict") == "problem"
            if s["label"] == "false":
                F += 1
                if s[base]: Fth += 1; caught += fl
            elif s["label"] == "true":
                T += 1
                if s[base]: Tth += 1; fa += fl
    return dict(F=F, Fth=Fth, caught=caught, T=T, Tth=Tth, fa=fa, false_out=Fth-caught, true_lost=T-Tth+fa)

if __name__ == "__main__":
    for n in ("test_r1", "test_r2", "dev_ad_v2"):
        rows, probs = check_rows(n)
        print(n, "rows", len(rows), "problems:", probs[:10], len(probs))
    for se in ("look2", "attack", "audit", "skeptic"):
        for n in ("test_r1", "test_r2"):
            print(se, n, tally(n, "test", se))
    for se in ("look1", "attack"):
        print("dev", se, tally("dev_ad_v2", "dev", se))
    # agreement
    a, b = flags(raw("test_r1")), flags(raw("test_r2"))
    for se in ("look2", "attack", "audit", "skeptic"):
        th = [s for u in U if u["set"] == se and u["split"] == "test" for s in u["sentences"] if s["target"] and s["cells_c1a"]]
        print("agree", se, sum((a[s["sid"]]["verdict"] == "problem") == (b[s["sid"]]["verdict"] == "problem") for s in th), "of", len(th))
