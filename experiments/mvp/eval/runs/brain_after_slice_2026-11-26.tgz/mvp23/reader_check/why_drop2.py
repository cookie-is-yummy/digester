import sys, json, os
sys.dont_write_bytecode = True
sys.argv = [sys.argv[0]]
import importlib
src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_new2.py")).read()
src = src.split("units = []")[0]
exec(src)
for c in CS.C:
    for pts, lay in ((list(c["points"]), "short"), (list(c["points"]) + CS.LONG.get(c["id"], []), "long")):
        if lay == "long" and c["id"] not in CS.LONG: continue
        rec = json.load(open(os.path.join(D, c["rec"] + ".json")))
        results = {x["rid"]: x["result"] for x in rec["calls"] if x.get("rid") and x.get("result") and not x["result"].get("is_error")}
        turn = V.Turn(message=rec["message"], screen=json.dumps(rec.get("screen") or {}, sort_keys=True), today=date(2026, 11, 22))
        form = {"understood": "", "lead": c["lead"], "points": pts, "items": [], "chart": None, "outside": [], "ask_back": None, "offers": [], "setup": None, "corrects_previous": False, "hand_back": None}
        v = V.check_answer(form, results, turn)
        for o in v.outcomes:
            if o.reasons:
                print(c["id"], lay, c["label"], o.where, o.index, o.reasons, "|", " / ".join(o.details)[:300])
