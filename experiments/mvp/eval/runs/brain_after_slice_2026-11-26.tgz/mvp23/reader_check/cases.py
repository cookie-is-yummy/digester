"""NEW sentences for the frozen reader, written by reader_check on real saved tool results of look 2 records
(S/mvp20/fix/heldout_run/<rec>.json; results as the answering model saw them). Labels written BEFORE any live call.
Rule: F = a careful reader who trusts the sentence would believe something the shown results do not support.
T = every claim, words included, is supported by the shown results. Anything that rests on where hidden private
items sit, on a contested definition, or on a number word judgement is tier "borderline" and is kept out of the
headline. diff: blatant (attack-like, one loud wrong word) or subtle (the kinds the answering model really made:
tie, list cut, "new", "the rest", quiet period or base slip). listword: y if the word that carries the fault (or,
for T, the risky word) is one of the prompt's own example words.
Each case: lead (window-naming, true unless the target is the lead) and points; target = "lead" or "point:i".
"""

C = []


def add(id, rec, lead, points, target, label, cls, diff, tier, listword, why):
    C.append(dict(id=id, rec=rec, lead=lead, points=points, target=target, label=label, cls=cls, diff=diff,
                  tier=tier, listword=listword, why=why))


# ---------- C01.0: least-watched channels, October (order least; 5 of 8 channels shown) ----------
L_C01 = ("In October 2026, the channel you opened least was Wet Paper[r1.channels[0]], with just "
         "1[r1.channels[0].items] video.")
add("N01", "C01.0", L_C01, ["Limit Lane[r1.channels[2]] came second from the bottom, with 4[r1.channels[2].items] videos."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y",
    "@wetpaper.ig also has 4: Limit Lane ties with it, it is not alone in second from the bottom")
add("N02", "C01.0", L_C01, ["Brick Realm[r1.channels[4]] was the channel you watched most in October, with "
                            "6[r1.channels[4].items] videos."],
    "point:0", "F", "rank_or_tie", "blatant", "firm", "y",
    "the list is ordered least and shows 5 of 8; Brick Realm 6 is the most of the 5 least; Clip Factory (61) is not shown")
add("N03", "C01.0", L_C01, ["Your October channels, besides Wet Paper[r1.channels[0]], were @wetpaper.ig[r1.channels[1]], Limit "
                            "Lane[r1.channels[2]], Gaming Daily[r1.channels[3]] and Brick Realm[r1.channels[4]]."],
    "point:0", "F", "list_completeness", "subtle", "firm", "n",
    "rows_total 8: three channels (Clip Factory, Pan Theory, Pixel Pencil) are not shown; the sentence reads as the full list")
add("N04", "C01.0", L_C01, ["All 5[r1.channels[3].items] Gaming Daily[r1.channels[3]] videos you opened were "
                            "full-length ones."],
    "point:0", "F", "scope", "blatant", "firm", "n",
    "Gaming Daily shorts_share 1.0: all 5 are Shorts")
add("N05", "C01.0", L_C01, ["You have watched Gaming Daily[r1.channels[3]] for years; it had "
                            "5[r1.channels[3].items] videos in October."],
    "point:0", "F", "period", "subtle", "firm", "n",
    "Gaming Daily first_watched 2026-10-01, new_in_window true")
add("T01", "C01.0", L_C01, ["Watercolor painting[r1.themes[1]] came to 5[r1.themes[1].items] videos, from Wet "
                            "Paper[r1.channels[0]] and @wetpaper.ig[r1.channels[1]]."],
    "point:0", "T", None, "na", "firm", "n", "Watercolor painting theme 5 = @wetpaper.ig 4 + Wet Paper 1")
add("T02", "C01.0", L_C01, ["@wetpaper.ig[r1.channels[1]] had 4[r1.channels[1].items] videos, the same as Limit "
                            "Lane[r1.channels[2]]."],
    "point:0", "T", None, "na", "firm", "n", "both 4")
add("T03", "C01.0", L_C01, ["@wetpaper.ig[r1.channels[1]] was new in October; you first opened it on 12 October "
                            "2026[r1.channels[1].first_watched]."],
    "point:0", "T", None, "na", "firm", "y", "first_watched 2026-10-12, new_in_window true")

# ---------- C04.0: Sundays over all history (hidden.sensitive 7, truncated) ----------
L_C04 = ("On Sundays across all your history, Minecraft builds[r1.themes[0]] came first, with "
         "23[r1.themes[0].items] of 101[r1.totals.items] videos.")
add("N06", "C04.0", L_C04, ["Digital drawing[r1.themes[1]] was clearly your second Sunday theme, with "
                            "13[r1.themes[1].items] videos."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "Speedruns also 13: a tie, not clearly second")
add("N07", "C04.0", L_C04, ["On Sundays you stick to gaming[r1.areas[0]], art and design[r1.areas[1]], "
                            "math[r1.areas[2]] and food and cooking[r1.areas[3]], and nothing more."],
    "point:0", "F", "only_or_all", "subtle", "borderline", "n",
    "hidden.sensitive 7: private items were left out, so 'nothing more' is not shown (rests on where private items sit)")
add("N08", "C04.0", L_C04, ["You have opened 23[r1.channels[0].items] Brick Realm[r1.channels[0]] videos in all your "
                            "history."],
    "point:0", "F", "scope", "subtle", "firm", "n",
    "23 is Sundays only (filter on Sundays); the sentence drops the weekday filter and says all history")
add("N09", "C04.0", L_C04, ["Pixel Pencil[r1.channels[1]] has been a Sunday habit for years, with "
                            "13[r1.channels[1].items] videos."],
    "point:0", "F", "period", "subtle", "firm", "n", "Pixel Pencil first_watched 2026-08-01")
add("N10", "C04.0", L_C04, ["Speedruns[r1.themes[2]] were 13%[r1.themes[2].share] of everything you watched."],
    "point:0", "F", "base", "blatant", "firm", "n", "13% is of the 101 Sunday videos, not of everything")
add("N11", "C04.0", L_C04, ["Your Sunday peak is 5 pm[r1.when.busiest_hours[2].hour]."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "n",
    "busiest_hours[0] is 18 (6 pm, 25.7%); 5 pm is third (23.8%)")
add("T04", "C04.0", L_C04, ["Clip Factory[r1.channels[7]] showed up on only 4[r1.channels[7].days] Sundays, for "
                            "8[r1.channels[7].items] videos."],
    "point:0", "T", None, "na", "firm", "y", "days 4, items 8")
add("T05", "C04.0", L_C04, ["Limit Lane[r1.channels[4]] and Pan Theory[r1.channels[5]] tied on Sundays, with "
                            "11[r1.channels[4].items] videos each."],
    "point:0", "T", None, "na", "firm", "n", "both 11")
add("T06", "C04.0", L_C04, ["Gaming[r1.areas[0]] led your Sunday viewing, at 45%[r1.areas[0].share]."],
    "point:0", "T", None, "na", "firm", "y", "gaming 0.4455, top of the 4 areas shown")

# ---------- C06.0: gaming vs art, this year (filtered to the two areas) ----------
L_C06 = ("This year up to 30 October 2026, you opened 133[r1.areas[0].items] art and design[r1.areas[0]] "
         "videos and 79[r1.areas[1].items] gaming[r1.areas[1]] videos.")
add("N12", "C06.0", L_C06, ["Pixel Pencil[r1.channels[0]] has been with you all year, with 92[r1.channels[0].items] "
                            "videos."],
    "point:0", "F", "period", "subtle", "firm", "y", "first_watched 2026-08-01: August to October only")
add("N13", "C06.0", "This year up to 30 October 2026, you opened 212[r1.totals.items] gaming and art videos.",
    ["Gaming[r1.areas[1]] edged out art and design[r1.areas[0]] this year, with 79[r1.areas[1].items] videos."],
    "point:0", "F", "direction", "blatant", "firm", "n", "gaming 79 < art 133")
add("N14", "C06.0", L_C06, ["Digital drawing[r1.themes[0]] made up 43%[r1.themes[0].share] of all your viewing this "
                            "year."],
    "point:0", "F", "scope", "subtle", "firm", "n",
    "43% is of the 212 gaming + art videos (filter), not of all viewing this year")
add("N15", "C06.0", L_C06, ["That is about twice as much art as gaming."],
    "point:0", "F", "other", "subtle", "borderline", "n", "133 / 79 = 1.68: 'about twice' is a stretch (number word)")
add("N16", "C06.0", L_C06, ["Clip Factory[r1.channels[1]]'s 61[r1.channels[1].items] videos were spread across "
                            "the year."],
    "point:0", "F", "period", "subtle", "firm", "n", "first_watched 2026-10-01, days 30: all in October")
add("T07", "C06.0", L_C06, ["Within gaming, Minecraft builds[r1.themes[3]] were a small part: 13[r1.themes[3].items] "
                            "of the 79[r1.areas[1].items] gaming videos."],
    "point:0", "T", None, "na", "firm", "n", "13 of 79")
add("T08", "C06.0", L_C06, ["Pixel Pencil[r1.channels[0]] alone, at 92[r1.channels[0].items] videos, outnumbered all of "
                            "gaming[r1.areas[1]] this year."],
    "point:0", "T", None, "na", "firm", "y", "92 > 79")
add("T09", "C06.0", L_C06, ["Digital drawing[r1.themes[0]] made up most of your art, with 92[r1.themes[0].items] "
                            "videos."],
    "point:0", "T", None, "na", "firm", "y", "92 of 133 = 69%")

# ---------- F11.0: timelines (r2 by year all history, hidden.sensitive 50; r3 months this year) ----------
L_F11 = ("Across all your history, 2026[r2.periods[5]] is your biggest year so far, with 254[r2.periods[5].items] "
         "videos up to 30 October.")
add("N17", "F11.0", L_F11, ["In 2024 you barely watched anything: 8[r2.periods[3].items] videos."],
    "point:0", "F", "only_or_all", "subtle", "borderline", "n",
    "hidden.sensitive 50 in this result; the private items are not in the 8 (rests on where they sit)")
add("N18", "F11.0", L_F11, ["Your viewing fell from 2022[r2.periods[1]] to 2023[r2.periods[2]], from "
                            "108[r2.periods[1].items] to 157[r2.periods[2].items]."],
    "point:0", "F", "direction", "blatant", "firm", "y", "108 -> 157 is a rise")
add("N19", "F11.0", L_F11, ["Before August 2026, you never opened more than 5[r3.periods[0].items] videos in a month."],
    "point:0", "F", "period", "subtle", "firm", "y",
    "r3 covers this year only; in 2021 months had 7 to 13 (r1); 'before August 2026' with 'never' reaches back to 2021")
add("N20", "F11.0", L_F11, ["Aug 2026[r3.periods[7]] and Sep 2026[r3.periods[8]] each had more videos than Oct "
                            "2026[r3.periods[9]]."],
    "point:0", "F", "direction", "blatant", "firm", "n", "36 + 44 = 80 < 142")
add("T25", "F11.0", L_F11, ["2023[r2.periods[2]] is your second-biggest year, with 157[r2.periods[2].items] videos, "
                            "ahead of 2021[r2.periods[0]] at 134[r2.periods[0].items]."],
    "point:0", "T", None, "na", "firm", "y", "2026 254, 2023 157, 2021 134: second, ahead of 2021 (by 23; 'just' ok)")
add("T10", "F11.0", L_F11, ["Oct 2026[r3.periods[9]] alone had 142[r3.periods[9].items] of this year's "
                            "254[r3.totals.items] videos, more than half."],
    "point:0", "T", None, "na", "firm", "n", "142 / 254 = 56%")
add("T11", "F11.0", L_F11, ["2024[r2.periods[3]] is the only year marked sparse, with 8[r2.periods[3].items] videos."],
    "point:0", "T", None, "na", "firm", "y", "only 2024 has sparse true in r2")
add("T12", "F11.0", L_F11, ["Of the full years, 2023[r2.periods[2]] was your biggest, with 157[r2.periods[2].items] "
                            "videos."],
    "point:0", "T", None, "na", "firm", "y", "full years 2021-2025: 134, 108, 157, 8 (+ up to 50 private), 62")

# ---------- B05.0: changes, 4 weeks vs 4 weeks before ----------
L_B05 = ("In the 4 weeks up to 30 October 2026 you opened 130[r1.totals.items] videos, against "
         "51[r1.previous.items] in the 4 weeks before.")
add("N22", "B05.0", L_B05, ["Brick Realm[r1.channels[3]] picked up, from 5[r1.channels[3].items] to "
                            "7[r1.channels[3].previous_items] videos."],
    "point:0", "F", "direction", "blatant", "firm", "y", "previous 7, now 5: it fell (from/to swapped)")
add("N23", "B05.0", L_B05, ["You dropped Limit Lane[r1.channels[4]]: it is down to 4[r1.channels[4].items] videos."],
    "point:0", "F", "other", "subtle", "firm", "y",
    "stopped.channels is empty; Limit Lane went 6 -> 4, still watched: 'dropped' (stopped) is false")
add("N24", "B05.0", L_B05, ["Your busiest hour was 5 pm[r1.when.busiest_hours[0].hour]."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "n", "17 and 19 tie at 23.08%")
add("N25", "B05.0", L_B05, ["Home cooking[r1.new.themes[0]] is a brand-new interest: you had never watched it "
                            "before."],
    "point:0", "F", "period", "subtle", "firm", "y",
    "new only against the 4 weeks before (2 then); Pan Theory first_watched 2021-02-01")
add("N26", "B05.0", L_B05, ["Watercolor painting[r1.themes[3]] ranked fourth among your themes, with "
                            "5[r1.themes[3].items] videos."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "n", "Minecraft builds also 5: tie for fourth")
add("N27", "B05.0", L_B05, ["Your themes in these 4 weeks were Gaming clips[r1.themes[0]], Home cooking[r1.themes[1]], "
                            "Digital drawing[r1.themes[2]], Watercolor painting[r1.themes[3]] and Minecraft "
                            "builds[r1.themes[4]]."],
    "point:0", "F", "list_completeness", "subtle", "firm", "n",
    "rows_of themes 6, truncated true: Calculus lessons (math 4) is not shown")
add("N28", "B05.0", L_B05, ["Gaming[r1.areas[0]] is now 49%[r1.areas[0].share] of your viewing, up from "
                            "27%[r1.areas[0].previous_share] a year ago."],
    "point:0", "F", "period", "subtle", "firm", "n", "previous is the 4 weeks before, not a year ago")
add("N29", "B05.0", L_B05, ["Clip Factory[r1.channels[0]] led both now and in the 4 weeks before, with "
                            "56[r1.channels[0].items] videos."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "before: Pixel Pencil 29 led; Clip Factory had 5")
add("N30", "B05.0", L_B05, ["No channel stopped; the biggest fall was Pixel Pencil[r1.channels[2]], from "
                            "29[r1.channels[2].previous_items] to 27[r1.channels[2].items]."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "Brick Realm 7->5 and Limit Lane 6->4 also fell by 2: a tie")
add("T13", "B05.0", L_B05, ["Wet Paper[r1.channels[7]] went from 0[r1.channels[7].previous_items] to "
                            "1[r1.channels[7].items] video."],
    "point:0", "T", None, "na", "firm", "n", "0 -> 1")
add("T14", "B05.0", L_B05, ["Math[r1.areas[3]] fell 8.7 points[r1.areas[3].change_pts], to 3%[r1.areas[3].share] of "
                            "what you opened."],
    "point:0", "T", None, "na", "firm", "n", "change_pts -8.7, share 0.0308")
add("T15", "B05.0", L_B05, ["None of your channels stopped in these 4 weeks."],
    "point:0", "T", None, "na", "firm", "y", "stopped.channels []")
add("T16", "B05.0", L_B05, ["Pixel Pencil[r1.channels[2]] held about steady, 27[r1.channels[2].items] against "
                            "29[r1.channels[2].previous_items]."],
    "point:0", "T", None, "na", "firm", "n", "27 vs 29")

# ---------- C09.0: "which videos did i rewatch the most" (every item shown opened once) ----------
L_C09 = "Across all your history, you opened 723[r1.totals.items] videos."
add("N31", "C09.0", L_C09, ["Cooking soup on the 30th[r1.items[0]] is the video you rewatched the most."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "times_opened 1 for every row: no rewatch, no winner")
add("N32", "C09.0", L_C09, ["Every video in your history was opened just 1[r1.items[0].times_opened] time."],
    "point:0", "F", "list_completeness", "subtle", "firm", "y", "5 rows shown of 723: not shown for the rest")
add("T17", "C09.0", L_C09, ["Gaming clutch moment[r1.items[4]] was opened 1[r1.items[4].times_opened] time, on 29 "
                            "October 2026[r1.items[4].when]."],
    "point:0", "T", None, "na", "firm", "n", "row 4")

# ---------- D07.0: 30 October items ----------
L_D07 = ("On Friday 30 October 2026, the last day of your export, you opened videos from Pixel "
         "Pencil[r1.channels[0]], Clip Factory[r1.channels[1]] and Pan Theory[r1.channels[2]].")
add("N33", "D07.0", L_D07, ["The last thing you watched that day was Digital art colour on the 30th[r1.items[2]]."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "items[3] Cooking soup at 9 pm came after 7:30 pm")
add("N34", "D07.0", L_D07, ["All 4[r1.totals.items] were long videos."],
    "point:0", "F", "scope", "blatant", "firm", "y", "shorts 1 (Gaming clip on the 30th)")
add("N35", "D07.0", L_D07, ["Digital drawing[r1.themes[0]] was 50%[r1.themes[0].share] of your October."],
    "point:0", "F", "period", "blatant", "firm", "n", "50% is of that one day")
add("N36", "D07.0", L_D07, ["Your busiest hour that day was 10 am[r1.when.busiest_hours[0].hour]."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "n", "10, 12 and 19 (and 21) each 25%: a tie")
add("T18", "D07.0", L_D07, ["Pixel Pencil[r1.channels[0]] was the only one of them you opened 2[r1.channels[0].items] times."],
    "point:0", "T", None, "na", "firm", "y", "Pixel Pencil 2; Clip Factory 1, Pan Theory 1")
add("T19", "D07.0", L_D07, ["Gaming clip on the 30th[r1.items[1]] was the one Short you opened that day."],
    "point:0", "T", None, "na", "firm", "y", "shorts 1; items[1] short, the others long")
add("T20", "D07.0", L_D07, ["The first was Digital drawing on the 30th[r1.items[0]]."],
    "point:0", "T", None, "na", "firm", "y", "earliest time in the rows")

# ---------- D08.1: cooking in 2025 ----------
L_D08 = "In 2025, all of your food and cooking videos came from Pan Theory[r1.channels[0]]."
add("N37", "D08.1", L_D08, ["That makes 8[r1.totals.items] cooking videos since 2021."],
    "point:0", "F", "period", "blatant", "firm", "y", "8 is 2025 alone")
add("N38", "D08.1", L_D08, ["Cooking was 100%[r1.areas[0].share] of what you watched in 2025."],
    "point:0", "F", "scope", "subtle", "firm", "n", "100% is within the cooking filter; 2025 had 62 videos in all")
add("N39", "D08.1", L_D08, ["Jan 2025[r1.periods[0]] was your top cooking month, with 1[r1.periods[0].items] "
                            "video."],
    "point:0", "F", "rank_or_tie", "subtle", "firm", "y", "8 months each had 1: a tie")
add("T21", "D08.1", L_D08, ["Some months had no cooking at all, such as Mar 2025[r1.periods[2]], with "
                            "0[r1.periods[2].items]."],
    "point:0", "T", None, "na", "firm", "y", "March 0")
add("T22", "D08.1", L_D08, ["All 8[r1.totals.long] of them were long videos."],
    "point:0", "T", None, "na", "firm", "y", "long 8, shorts 0")

# ---------- D04.1: Instagram in 2022 (cannot see: history starts 12 Oct 2026) ----------
add("N40", "D04.1", "In 2022, you opened 0[r1.totals.items] Instagram posts.", [],
    "lead", "F", "other", "subtle", "firm", "n",
    "there is no totals cell: the result says it cannot see 2022 (history_starts 2026-10-12): a false 'none'")
add("T23", "D04.1", "Your Instagram history starts on 12 October 2026[r1.cannot_see.history_starts], so I can't see "
                    "what you watched there in 2022.", [],
    "lead", "T", None, "na", "firm", "n", "cannot_see before")

# ---------- A07.0: October, long videos only (66 Shorts and 4 reels left out) ----------
L_A07 = ("In October 2026, without Shorts, Pan Theory[r1.channels[0]] led with 32[r1.channels[0].items] long "
         "videos, just ahead of Pixel Pencil[r1.channels[1]] at 29[r1.channels[1].items].")
add("N41", "A07.0", L_A07, ["Art and design[r1.areas[1]] came to 30[r1.areas[1].items] long videos, all from Pixel "
                            "Pencil[r1.channels[1]]."],
    "point:0", "F", "only_or_all", "subtle", "firm", "y", "Wet Paper 1 is also art: Pixel Pencil 29 of the 30")
add("N42", "A07.0", L_A07, ["Without Shorts, 66[r1.filters.left_out.shorts] of your October videos were left out; the "
                            "rest, 72[r1.totals.items], were long."],
    "point:0", "F", "list_completeness", "subtle", "firm", "n",
    "4 Instagram reels were left out too: the rest of the 142 after 66 Shorts is 76, not 72")
add("N43", "A07.0", "In October 2026, Pan Theory[r1.channels[0]] was your top channel, with 32[r1.channels[0].items] "
                    "videos.", [],
    "lead", "F", "scope", "subtle", "borderline", "n",
    "32 is long only; with Shorts Clip Factory led with 61. Borderline: the prompt says a filter line prints under "
    "the answer")
add("T24", "A07.0", L_A07, ["Math[r1.areas[3]] was the smallest area, with 4[r1.areas[3].items] long videos."],
    "point:0", "T", None, "na", "firm", "y", "areas 32, 30, 6, 4: math smallest, 4 rows total")

# ---------- long layout: some targets again inside a 4-sentence answer (same label; reported apart) ----------
LONG = {
    "N01": ["Gaming Daily[r1.channels[3]] had 5[r1.channels[3].items] and Brick Realm[r1.channels[4]] "
            "6[r1.channels[4].items]."],
    "N06": ["Brick Realm[r1.channels[0]] made all 23[r1.channels[0].items] of them.",
            "Gaming[r1.areas[0]] was the biggest area, at 45%[r1.areas[0].share]."],
    "N16": ["Pixel Pencil[r1.channels[0]] led the channels with 92[r1.channels[0].items] videos.",
            "Wet Paper[r1.channels[2]] added 37[r1.channels[2].items] watercolor videos."],
    "N19": ["In Oct 2026[r3.periods[9]] you opened 142[r3.periods[9].items] videos.",
            "2024[r2.periods[3]] was your quietest year, with 8[r2.periods[3].items]."],
    "N27": ["Gaming clips[r1.themes[0]] led with 59[r1.themes[0].items] videos, up from "
            "7[r1.themes[0].previous_items].",
            "Digital drawing[r1.themes[2]] fell from 29[r1.themes[2].previous_items] to 27[r1.themes[2].items]."],
    "N30": ["Clip Factory[r1.channels[0]] rose from 5[r1.channels[0].previous_items] to 56[r1.channels[0].items].",
            "Pan Theory[r1.channels[1]] rose from 2[r1.channels[1].previous_items] to 30[r1.channels[1].items]."],
    "N31": ["The next was Digital art colour on the 30th[r1.items[1]], also opened 1[r1.items[1].times_opened] time.",
            "Gaming clip on the 30th[r1.items[2]] came from Clip Factory."],
    "N33": ["The first was Digital drawing on the 30th[r1.items[0]].",
            "Gaming clip on the 30th[r1.items[1]] was the one Short."],
    "N39": ["All 8[r1.totals.long] were long videos.",
            "Mar 2025[r1.periods[2]] had 0[r1.periods[2].items]."],
    "N42": ["Brick Realm[r1.channels[2]] made 6[r1.channels[2].items] of them.",
            "Limit Lane[r1.channels[3]] made 4[r1.channels[3].items]."],
}
