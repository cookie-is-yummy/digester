import json, collections, sys
U = json.load(open("units_new.json")); UB = {u["uid"]: u for u in U}
def run(n):
    out = {}
    for x in open(f"runs/{n}.jsonl"):
        r = json.loads(x)
        if r.get("ok") or r["uid"] not in out: out[r["uid"]] = r
    return {s["sid"]: s for r in out.values() for s in r["sentences"]}, out
r1, o1 = run("new_r1"); r2, o2 = run("new_r2")
bad = [u for u, r in list(o1.items()) + list(o2.items()) if not r.get("ok")]
print("failed units", bad, "missing verdicts", sum(s["verdict"] == "missing" for s in list(r1.values()) + list(r2.values())))
rows = []
for u in U:
    for s in u["sentences"]:
        rows.append(dict(s, uid=u["uid"], layout=u["layout"], case=u["case"], f1=r1[s["sid"]]["verdict"] == "problem",
                         f2=r2[s["sid"]]["verdict"] == "problem", c1=r1[s["sid"]]["class"], why1=r1[s["sid"]]["reason"],
                         c2=r2[s["sid"]]["class"], why2=r2[s["sid"]]["reason"]))
json.dump(rows, open("new_rows.json", "w"), indent=0, ensure_ascii=False)
T = [r for r in rows if r["target"]]
def line(name, sel):
    F = [r for r in sel if r["label"] == "false"]; Tr = [r for r in sel if r["label"] == "true"]
    return (f"{name:<52} false {sum(r['f1'] for r in F)}/{len(F)} flagged (run2 {sum(r['f2'] for r in F)}); "
            f"true {sum(r['f1'] for r in Tr)}/{len(Tr)} flagged (run2 {sum(r['f2'] for r in Tr)})")
S = [r for r in T if r["layout"] == "short"]
print(line("HEADLINE short, firm, cells-only keeps", [r for r in S if r["tier"] == "firm" and r["cells_c1a"]]))
print(line("  subtle only", [r for r in S if r["tier"] == "firm" and r["cells_c1a"] and r["diff"] in ("subtle", "na")]))
print(line("  subtle, fault word not in prompt lists", [r for r in S if r["tier"] == "firm" and r["cells_c1a"] and ((r["diff"] == "subtle" and r["listword"] == "n") or r["label"] == "true")]))
print(line("  blatant only", [r for r in S if r["tier"] == "firm" and r["cells_c1a"] and (r["diff"] == "blatant" or r["label"] == "true")]))
print(line("short, firm, all (cells or not)", [r for r in S if r["tier"] == "firm"]))
print(line("short, borderline tier", [r for r in S if r["tier"] == "borderline"]))
print(line("long layout (same targets in 3-4 sentences)", [r for r in T if r["layout"] == "long"]))
L = {r["case"]: r for r in T if r["layout"] == "long"}
print("  same targets in the short layout:", sum(r["f1"] for r in S if r["case"] in L), "of", len(L), "(run2", sum(r["f2"] for r in S if r["case"] in L), ")")
car = [r for r in rows if not r["target"]]
print(f"carriers (true leads and filler points, not scored): flagged run1 {sum(r['f1'] for r in car)}/{len(car)}, run2 {sum(r['f2'] for r in car)}")
print("  carriers cells keeps:", sum(r['f1'] for r in car if r['cells_c1a']), "/", sum(r['cells_c1a'] for r in car))
# by class
print("by class, short firm cells-keeps false: run1 (run2)")
cc = collections.defaultdict(lambda: [0, 0, 0])
for r in S:
    if r["tier"] == "firm" and r["cells_c1a"] and r["label"] == "false":
        cc[r["cls"]][0] += r["f1"]; cc[r["cls"]][1] += r["f2"]; cc[r["cls"]][2] += 1
for k, (a, b, n) in sorted(cc.items()): print(f"   {k:<18} {a}/{n} ({b})")
ag = [r for r in S if r["tier"] == "firm" and r["cells_c1a"]]
print("agreement run1/run2 on headline targets:", sum(r["f1"] == r["f2"] for r in ag), "of", len(ag))
print("\nMISSES (false, run1 or run2 not flagged), short layout:")
for r in T:
    if r["label"] == "false" and not (r["f1"] and r["f2"]):
        print(f"- {r['case']} [{r['layout']},{r['tier']},{r['diff']},{r['cls']},cells {'keep' if r['cells_c1a'] else 'DROP'}] r1 {'flag' if r['f1'] else 'MISS'} r2 {'flag' if r['f2'] else 'MISS'}")
        print("    S:", r["text"]); print("    why false:", r["why"]); print("    reader:", r["why1"] if not r["f1"] else r["why2"])
print("\nFALSE ALARMS (true flagged in run1 or run2):")
for r in T:
    if r["label"] == "true" and (r["f1"] or r["f2"]):
        print(f"- {r['case']} [cells {'keep' if r['cells_c1a'] else 'DROP'}] r1 {'FLAG '+str(r['c1']) if r['f1'] else 'ok'} r2 {'FLAG '+str(r['c2']) if r['f2'] else 'ok'}")
        print("    S:", r["text"]); print("    reader:", r["why1"] if r["f1"] else r["why2"])
print("\nCARRIERS FLAGGED:")
for r in car:
    if r["f1"] or r["f2"]:
        print(f"- {r['sid']} r1 {'FLAG' if r['f1'] else 'ok'} r2 {'FLAG' if r['f2'] else 'ok'}: {r['text']}\n    reader: {r['why1'] if r['f1'] else r['why2']}")
