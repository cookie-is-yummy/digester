"""Per-answer time with the reader (no model call). For each held-out answer: the recorded seconds of the turn plus the
reader's own seconds for that answer (measured), and an estimate that swaps the recorded repair for a reword round
whenever a sentence fails cells-only (C1a) or is flagged by the reader. Writes timing.txt."""
import json
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad"
sys.path.insert(0, HERE)
import score as SC  # noqa: E402

LOOKS = {"look1": (os.path.join(S, "mvp20/tune/heldout"), ["dev_ad_v2"]),
         "look2": (os.path.join(S, "mvp20/fix/heldout_run"), ["test_r1", "test_r2"])}
calls = [json.loads(x) for x in open(os.path.join(HERE, "calls.jsonl")) if x.strip()]


def ga(q):
    return any(isinstance(b, dict) and b.get("name") == "give_answer" for b in q.get("blocks") or [])


def p90(xs):
    xs = sorted(xs)
    return xs[int(0.9 * (len(xs) - 1))]


units = SC.all_units()
lines = []
for look, (d, runs) in LOOKS.items():
    recs = {}
    for p in sorted(os.listdir(d)):
        if p.endswith(".json") and p != "summary.json":
            r = json.load(open(os.path.join(d, p)))
            if r.get("forms"):
                recs[f"{look}:{r['key']}"] = r
    rep_s = []
    for r in recs.values():
        g = [q for q in r["requests"] if ga(q)]
        rep_s += [q["seconds"] for q in g[1:]]
    reword = st.median(rep_s) if rep_s else 0.0
    for run in runs:
        rows = SC.rows(units, SC.load_run(run))
        rsec = {}
        for c in calls:
            if c["run"] == run and c["uid"] in recs:
                rsec[c["uid"]] = c["seconds"]
        a, b, b2, n_need = [], [], [], 0
        base = []
        for uid, r in recs.items():
            if uid not in rsec:
                continue
            g = [q for q in r["requests"] if ga(q)]
            rec_rep = sum(q["seconds"] for q in g[1:])
            sents = [x for x in rows if x["uid"] == uid]
            need = any((not x["cells_c1a"]) or x["flag"] for x in sents if x["label"] != "none" or True)
            n_need += need
            base.append(r["seconds"])
            a.append(r["seconds"] + rsec[uid])
            t = r["seconds"] - rec_rep + rsec[uid] + (reword if need else 0.0)
            b.append(t)
            b2.append(t + (rsec[uid] if need else 0.0))
        lines.append(f"{look} [{run}] {len(a)} answers; recorded turn (as run, with its repairs): median "
                     f"{st.median(base):.2f} s, p90 {p90(base):.2f}")
        lines.append(f"   measured sum, recorded turn + reader: median {st.median(a):.2f} s, p90 {p90(a):.2f}, max "
                     f"{max(a):.2f}")
        lines.append(f"   answers with a sentence that fails cells-only or is flagged (each pays a reword round): "
                     f"{n_need} of {len(a)}")
        lines.append(f"   estimate, recorded repairs swapped for one reword round ({reword:.2f} s, the median recorded "
                     f"repair request) when needed: median {st.median(b):.2f} s, p90 {p90(b):.2f}; with a second "
                     f"reader call on the reworded answer: median {st.median(b2):.2f} s, p90 {p90(b2):.2f}")
lines.append("Founder's bar: 8 s median, 11 s at the slow end. The recorded turns are the as-run checker's (C0), not")
lines.append("cells-only; the paper's estimate for C1a alone was 7.28 s / 10.05 s on look 1.")
open(os.path.join(HERE, "timing.txt"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
