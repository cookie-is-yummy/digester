# record progress (key: record; no model call; $0)
S = /tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad. Files: S/mvp23/record/.
## Steps
- [ ] orient: read paper test (S/mvp22/paper), sentences.json, skeptic state
- [x] orient; lib.py (loader, own scratch library record/_lib), run_cells.py -> cells_C0/C1a/C1d.json: reproduce the
  paper's sim.json row for row (387/387 held-out, 290/290 planted); skeptic cells 68/68 against their cases_out.
- [x] tally.py (own copy of the paper's counting). D1 = C1a..C1d rows (as paper).
- [x] D1b: make_d1b.py -> src/verify_d1b.py (LOOSE switches; empty = verify_c1 row for row); d1b.py -> d1b.txt,
  d1b.json, cells_D1b.json (C1a base), cells_D1bd.json (C1d base). Kept: title_quote, item_channel, short_word,
  platform_all (no false out on either base). Dropped: uname_* (8-18 false out), limits_off (I02 lead), filler_off
  (attack_L04), repeat_off (new:r_repeat); limits_regex, too_long, num_noun, typed_off gain nothing. IN SAMPLE.
- [ ] record.py (closed word list + record checks) and d2w.py: written from look 1 only, frozen (sha256) before look 2
- [x] record.py (closed word list + record checks + copy-records for the M bound) and d2w.py (period, base, library
  rules) written and tuned on LOOK 1 FIRST FORMS ONLY (dev_look1.py), then FROZEN: record/frozen.sha256. Look 1
  tuning: 'made up', 'dropped out', 'the latest day I can show', 'in all' (=in total) not listed words; least on a
  least-ordered complete result; 'all' backed by share cells of 100%; d2w: window-before words said with 'in', 'the
  same span of 2025' of a changes result; base phrase exempt only when the scope is said as a scope. D2w on look 1
  refuses 3 true (C02.0 p0, p1; D08.1 p0) and F05.0 p2. Caveat: look 2 faults, attack classes and the skeptic's
  words were SEEN this session before the freeze (in the paper test's files); the rules were not written from them.
- [ ] class map (classmap.py), hand records H (records_h.json, hashed), run_designs.py, table.txt, still_out.txt
- [x] classmap.py (17 look faults: R 9, P 5, T 3; attack and skeptic classes; the 8 sent) written before D2 runs.
- [x] records_h.py -> records_h.json (180 hand records: 88 look 1 + 92 look 2 first-form sentences with a listed
  word), sha256 in records_h.sha256, written before run_designs.py ran the row check on them.
- [ ] run_designs.py -> designs.json; table.txt; still_out.txt; speed
- [x] run_designs.py -> designs.json, verdicts.json (asserts frozen hashes). report.py -> table.txt, still_out.txt,
  report.json (speed via paper/speed.py's method, copied; tokens from look 1's hand records).
  Incident: two early runs imported paper/tally.py by name (the skeptic's common.py puts paper/ first on sys.path)
  and so re-ran it: paper/tally.json and tally.txt were rewritten from unchanged inputs (same sizes; deterministic).
  Fixed (lib appends paper/; this folder's tally imported first).
- [x] advisor review: D2w relabelled in sample (period rule = today's _window_check, library rule = today's
  _library_window); per-rule split, planted-true losses by reason, compact records (180/180 same verdicts, measured
  tokens), one merged still_out.txt (appendix keeps per-design lists), caveats in the table header; attack
  two_results relabelled C -> P (window of another result). Skeptic set complete (their progress says DONE;
  cases.py hash unchanged). git status of the repo clean.
- DONE: returned in StructuredOutput. Re-run order if needed: run_cells.py C0 C1a C1d; d1b.py; run_designs.py;
  report.py; extra.py.
