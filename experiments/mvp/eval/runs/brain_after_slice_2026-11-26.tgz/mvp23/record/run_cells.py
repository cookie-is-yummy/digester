"""Cell-level verdicts of one checker copy and setting on every set. Writes cells_<tag>.json.
    python3 run_cells.py C1a C1d C0          (paper copy, verify_c1.py)
Each row: set, id/key, where, index, kept, reasons, private_line, lead_ok, repair (held-out)."""
import json
import os
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402


def run_heldout(V, inputs):
    rows = []
    for look, rec, vt, results in inputs:
        for fi, form in enumerate(rec.get("forms") or []):
            v = V.check_answer(form, results, vt)
            for o in v.outcomes:
                rows.append({"set": look, "key": rec["key"], "form_index": fi, "where": o.where, "index": o.index,
                             "text": o.text, "kept": o.kept, "reasons": list(o.reasons), "private_line": v.private_line,
                             "lead_ok": v.lead_ok, "repair": v.repair})
    return rows


def planted_one(V, case, ledgers, form):
    led = V.Ledger(ledgers[case["ledger"]])
    v = V.check_answer(form, led, L.planted_turn(V, case))
    tgt = case.get("target") or "point:0"
    kind, _, n = tgt.partition(":")
    lead_os = [o for o in v.outcomes if o.where == "lead"]
    carrier = bool(lead_os) and all(o.kept for o in lead_os)
    if kind == "lead":
        return carrier, sorted({r for o in lead_os for r in o.reasons}), v.private_line, True
    o = next((o for o in v.outcomes if o.where == kind and o.index == int(n or 0)), None)
    return bool(o and o.kept), (list(o.reasons) if o else ["missing"]), v.private_line, carrier


def run_planted(V, data):
    rows = []
    for c in data["cases"]:
        if c.get("source") not in L.PLANTED_SOURCES:
            continue
        best, per = None, []
        for fi, f in enumerate(c.get("forms") or [c["form"]]):
            r = planted_one(V, c, data["ledgers"], f)
            per.append(r)
            if best is None or (r[0] and not best[0]):
                best = r + (fi,)
        rows.append({"set": c["source"], "id": c["id"], "expect": c["expect"], "class": c.get("class"),
                     "target": c.get("target"), "kept": best[0], "reasons": best[1], "private_line": best[2],
                     "carrier_kept": best[3], "best_form": best[4], "forms_kept": [x[0] for x in per]})
    return rows


def run_skeptic(V, sk):
    rows = []
    for c, form, tgt, results, vt in sk:
        v = V.check_answer(form, results, vt)
        o = next((o for o in v.outcomes if (o.where, o.index) == tgt), None)
        lead_os = [x for x in v.outcomes if x.where == "lead"]
        rows.append({"set": "skeptic", "id": c[0], "truth": c[3], "class": c[4], "where": c[2],
                     "kept": bool(o and o.kept), "reasons": list(o.reasons) if o else ["missing"],
                     "private_line": v.private_line, "carrier_kept": bool(lead_os) and all(x.kept for x in lead_os)})
    return rows


def run_all(V, inputs, data, sk):
    return {"heldout": run_heldout(V, inputs), "planted": run_planted(V, data), "skeptic": run_skeptic(V, sk)}


if __name__ == "__main__":
    inputs = L.heldout_inputs()
    data = L.planted_data()
    sk = L.skeptic_inputs(L.V1)
    for cfg in sys.argv[1:]:
        L.setcfg(L.V1, cfg)
        out = run_all(L.V1, inputs, data, sk)
        json.dump(out, open(os.path.join(L.HERE, f"cells_{cfg}.json"), "w"), indent=0, default=str)
        print(cfg, len(out["heldout"]), len(out["planted"]), len(out["skeptic"]))
    L.setcfg(L.V1, "C0")
