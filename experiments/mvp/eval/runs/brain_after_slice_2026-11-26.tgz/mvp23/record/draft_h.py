"""Lists every look 1 and look 2 FIRST-FORM sentence with a listed word, with the copy record as a starting draft and
the rows it cites, so the honest record can be written by hand (records_h.json). Prints only; writes
records_draft.json. The record check is NOT run here beyond the copy's own pick."""
import json
import os
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402
import record as RC  # noqa: E402

which = sys.argv[1] if len(sys.argv) > 1 else "look1"
out = {}
for look, rec, vt, results in L.heldout_inputs():
    if look != which:
        continue
    led = L.V1.Ledger(results)
    form = rec["forms"][0]
    sents = [("lead", k, s) for k, s in enumerate(L.V1._split(form.get("lead") or ""))] + \
        [("point", k, p) for k, p in enumerate(form.get("points") or [])]
    for w, k, s in sents:
        nd = RC.needs(s, led)
        if not nd:
            continue
        combos = RC.copy_records(s, led, [])
        draft = combos[0] if combos else []
        key = f"{look}|{rec['key']}|{w}|{k}"
        out[key] = {"text": s, "needs": [g for g, _h, _k in nd], "draft": draft}
        print(f"== {key} need={[(g, h) for g, h, _k in nd]}\n   {s}")
        print(f"   draft {json.dumps(draft)}")
json.dump(out, open(os.path.join(L.HERE, f"records_draft_{which}.json"), "w"), indent=1)
