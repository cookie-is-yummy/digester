"""All designs on all sets. Asserts the frozen hashes of record.py, d2w.py and records_h.json first.
Cell verdicts come from cells_*.json (run_cells.py, d1b.py). Record and D2w verdicts are computed here once per
sentence and ANDed with each cell base. Writes designs.json (verdict tables) and verdicts.json (per sentence).
Designs:  D1 (C1a | C1d)  D1b (D1b | D1bd)  D2_M0 strict (no record: a listed word is refused)  D2_Mc (copy record)
          D2_H (hand record; looks only)  and D2w_* = D2_* plus d2w.check.
Cell base of D2/D2w: D1b (C1a-based) and D1bd (C1d-based)."""
import copy
import hashlib
import json
import os
import sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def _sha(p):
    return hashlib.sha256(open(os.path.join(HERE, p), "rb").read()).hexdigest()


frozen = {l.split()[1]: l.split()[0] for l in open(os.path.join(HERE, "frozen.sha256")) if l[:1].isalnum() and
          len(l.split()) == 2}
assert frozen["record.py"] == _sha("record.py"), "record.py changed after it was frozen"
assert frozen["d2w.py"] == _sha("d2w.py"), "d2w.py changed after it was frozen"
assert open(os.path.join(HERE, "records_h.sha256")).read().split()[0] == _sha("records_h.json")

import lib as L  # noqa: E402
import tally as T  # noqa: E402  (this folder's tally.py: imported before the skeptic's common.py puts paper/ first)
import record as RC  # noqa: E402
import d2w as W  # noqa: E402

V = L.V1
H = json.load(open(os.path.join(HERE, "records_h.json")))


def sentences(form):
    return [("lead", k, s) for k, s in enumerate(V._split(form.get("lead") or ""))] + \
        [("point", k, p) for k, p in enumerate(form.get("points") or [])]


def answer_cells(form, led):
    out = []
    for _w, _k, s in sentences(form):
        mks, _ = V.parse(" ".join(s.split()), led)
        out += [mk.path for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                and not isinstance(mk.value, bool)]
    return out


def verdict(s, led, turn, cells, hkey=None):
    nd = RC.needs(s, led)
    v = {"needs": [g for g, _h, _k in nd]}
    v["m0"] = ["no_record:" + g for g, _h, _k in nd]
    why, recs = RC.copy_check(s, led, cells)
    v["mc"] = why
    v["mc_rec"] = recs
    if hkey is not None:
        v["h"] = RC.check_records(s, H.get(hkey, []), led) if nd else []
    v["w"] = W.check(s, led, turn)
    return v


def heldout_verdicts():
    out = {}
    for look, rec, vt, results in L.heldout_inputs():
        led = V.Ledger(results)
        for fi, form in enumerate(rec.get("forms") or []):
            cells = answer_cells(form, led)
            for w, k, s in sentences(form):
                hk = f"{look}|{rec['key']}|{w}|{k}" if fi == 0 else None
                out[f"{look}|{rec['key']}|{fi}|{w}|{k}"] = verdict(s, led, vt, cells, hk)
    return out


def target_text(form, tgt):
    kind, _, n = (tgt or "point:0").partition(":")
    ss = sentences(form)
    if kind == "lead":
        return [s for w, _k, s in ss if w == "lead"]
    return [s for w, k, s in ss if w == "point" and k == int(n or 0)]


def planted_verdicts(data):
    out = {}
    for c in data["cases"]:
        if c.get("source") not in L.PLANTED_SOURCES:
            continue
        led = V.Ledger(data["ledgers"][c["ledger"]])
        turn = L.planted_turn(V, c)
        per = []
        for f in (c.get("forms") or [c["form"]]):
            cells = answer_cells(f, led)
            vs = [verdict(s, led, turn, cells) for s in target_text(f, c.get("target"))]
            per.append(vs)
        out[c["id"]] = per
    return out


def skeptic_verdicts():
    out = {}
    for c, form, tgt, results, vt in L.skeptic_inputs(V):
        led = V.Ledger(results)
        cells = answer_cells(form, led)
        s = [x for w, k, x in sentences(form) if (w, k) == tgt]
        out[c[0]] = verdict(s[0], led, vt, cells) if s else None
    return out


def ok(v, mode, wide):
    if v is None:
        return False
    r = v["m0"] if mode == "m0" else v["mc"] if mode == "mc" else v.get("h")
    if r is None:   # no hand record outside the two looks' first forms: the copy record stands in
        r = v["mc"]
    if r:
        return False
    return not (wide and v["w"])


def reasons(v, mode, wide):
    if v is None:
        return ["missing"]
    r = list(v["m0"] if mode == "m0" else v["mc"] if mode == "mc" else (v.get("h") if v.get("h") is not None
                                                                          else v["mc"]))
    if wide:
        r += v["w"]
    return r


def combine(cells, hv, pv, sv, mode, wide):
    t = copy.deepcopy(cells)
    for r in t["heldout"]:
        v = hv.get(f"{r['set']}|{r['key']}|{r['form_index']}|{r['where']}|{r['index']}")
        rr = reasons(v, mode, wide)
        r["reasons"] = list(r["reasons"]) + rr
        r["kept"] = bool(r["kept"]) and not rr
    for r in t["planted"]:
        per = pv.get(r["id"]) or []
        fk = r.get("forms_kept") or [r["kept"]]
        kept_any = False
        why = []
        for i, vs in enumerate(per):
            rec_ok = bool(vs) and all(ok(v, mode, wide) for v in vs)
            if i < len(fk) and fk[i] and rec_ok:
                kept_any = True
            if not rec_ok:
                why += [x for v in vs for x in reasons(v, mode, wide)]
        r["kept"] = kept_any
        r["reasons"] = list(r["reasons"]) + sorted(set(why))
    for r in t["skeptic"]:
        v = sv.get(r["id"])
        rr = reasons(v, mode, wide)
        r["reasons"] = list(r["reasons"]) + rr
        r["kept"] = bool(r["kept"]) and not rr
    return t


if __name__ == "__main__":
    hv = heldout_verdicts()
    data = L.planted_data()
    pv = planted_verdicts(data)
    sv = skeptic_verdicts()
    json.dump({"heldout": hv, "planted": pv, "skeptic": sv}, open(os.path.join(HERE, "verdicts.json"), "w"),
              indent=0, default=str)
    designs = {}
    for name in ("C1a", "C1d", "D1b", "D1bd"):
        designs[{"C1a": "D1/a", "C1d": "D1/d", "D1b": "D1b/a", "D1bd": "D1b/d"}[name]] = \
            json.load(open(os.path.join(HERE, f"cells_{name}.json")))
    for base, tag in (("D1b", "a"), ("D1bd", "d")):
        cells = json.load(open(os.path.join(HERE, f"cells_{base}.json")))
        for mode, mname in (("m0", "M0"), ("mc", "Mc"), ("h", "H")):
            for wide in (False, True):
                designs[f"{'D2w' if wide else 'D2'}_{mname}/{tag}"] = combine(cells, hv, pv, sv, mode, wide)
    json.dump(designs, open(os.path.join(HERE, "designs.json"), "w"), indent=0, default=str)
    for k, t in designs.items():
        print(T.line(k, T.summary(t)))
