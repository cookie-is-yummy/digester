"""Counting, as paper/tally.py counts (no import of it: it writes files). A verdict table is
{"heldout": rows, "planted": rows, "skeptic": rows}; each row has `kept` (the design's final say on that sentence)."""
import re
from collections import Counter

import lib as L

BAD = ("wrongly_based", "false")


def held(rows, look, first=True):
    out = []
    for r in rows:
        if r["set"] != look or (first and r["form_index"] != 0):
            continue
        lab = L.LAB.get((look, r["key"], r["form_index"], r["where"], r["index"]))
        out.append((r, lab))
    return out


def held_stats(rows, look):
    c = Counter()
    bad_out, true_lost = [], []
    for r, lab in held(rows, look):
        if lab is None or lab["truth"] == "no_claim":
            continue
        t = lab["truth"]
        if t in BAD:
            c["bad"] += 1
            if r["kept"]:
                c["bad_out"] += 1
                bad_out.append(f'{r["key"]} {r["where"]}{r["index"]}')
        elif t == "true":
            c["true"] += 1
            if not r["kept"]:
                c["true_lost"] += 1
                true_lost.append((f'{r["key"]} {r["where"]}{r["index"]}', r.get("reasons") or []))
        else:
            c[t] += 1
            c[t + "_kept"] += bool(r["kept"])
    leads = {}
    sents = {}
    for r in rows:
        if r["set"] == look and r["form_index"] == 0 and r["where"] in ("lead", "point"):
            sents.setdefault(r["key"], []).append(r)
            if r["where"] == "lead":
                leads[r["key"]] = leads.get(r["key"], True) and bool(r["kept"])
    c["answers"] = len(sents)
    c["lead_kept"] = sum(1 for k in sents if leads.get(k, False))
    c["repair_due"] = sum(1 for k, rs in sents.items() if not leads.get(k, False) or
                          sum(not x["kept"] for x in rs) * 2 > len(rs))
    return c, bad_out, true_lost


def repair_keys(rows, look):
    sents, leads = {}, {}
    for r in rows:
        if r["set"] == look and r["form_index"] == 0 and r["where"] in ("lead", "point"):
            sents.setdefault(r["key"], []).append(r)
            if r["where"] == "lead":
                leads[r["key"]] = leads.get(r["key"], True) and bool(r["kept"])
    return {k for k, rs in sents.items() if not leads.get(k, False) or sum(not x["kept"] for x in rs) * 2 > len(rs)}


def lead_kept(rows, look, fi):
    leads = {}
    for r in rows:
        if r["set"] == look and r["form_index"] == fi and r["where"] == "lead":
            leads[r["key"]] = leads.get(r["key"], True) and bool(r["kept"])
    return leads


def sid(i):
    return re.sub(r"_(?:L|P)$", "", i)


def planted_stats(rows):
    c = Counter()
    att = {}
    outs = {"attack": [], "builder": []}
    for r in rows:
        out_ = bool(r["kept"]) and not (r["expect"] == "private_line" and r["private_line"])
        if r["set"] == "attack":
            att[sid(r["id"])] = att.get(sid(r["id"]), False) or out_
        elif r["set"] in ("attack_true", "audit_true"):
            c[r["set"]] += 1
            c[r["set"] + "_kept"] += bool(r["kept"])
        else:
            if r["expect"] == "kept":
                c["builder_true"] += 1
                c["builder_true_kept"] += bool(r["kept"])
            else:
                c["builder_false"] += 1
                if out_:
                    c["builder_false_out"] += 1
                    outs["builder"].append(r["id"])
    c["attack"] = len(att)
    c["attack_out"] = sum(att.values())
    outs["attack"] = sorted(k for k, v in att.items() if v)
    return c, outs


def skeptic_stats(rows):
    c = Counter()
    outs = []
    for r in rows:
        if r["truth"] == "F":
            c["F"] += 1
            if r["kept"]:
                c["F_out"] += 1
                outs.append(r["id"])
        else:
            c["T"] += 1
            c["T_kept"] += bool(r["kept"])
    return c, outs


def summary(tab):
    s = {}
    for look in ("look1", "look2"):
        c, b, t = held_stats(tab["heldout"], look)
        s[look] = dict(c)
        s[look + "_bad_out"] = b
        s[look + "_true_lost"] = t
    c, o = planted_stats(tab["planted"])
    s["planted"] = dict(c)
    s["attack_out_ids"] = o["attack"]
    s["builder_out_ids"] = o["builder"]
    if tab.get("skeptic"):
        c, o = skeptic_stats(tab["skeptic"])
        s["skeptic"] = dict(c)
        s["skeptic_out_ids"] = o
    # look faults in repair forms too
    rb = []
    for r in tab["heldout"]:
        if r["form_index"] > 0:
            lab = L.LAB.get((r["set"], r["key"], r["form_index"], r["where"], r["index"]))
            if lab and lab["truth"] in BAD and r["kept"]:
                rb.append(f'{r["set"]} {r["key"]}.f{r["form_index"]} {r["where"]}{r["index"]}')
    s["repair_bad_out"] = rb
    return s


def line(name, s):
    a, b, p = s["look1"], s["look2"], s["planted"]
    sk = s.get("skeptic") or {}
    return (f"{name:28s} L1 bad {a.get('bad_out', 0)}/{a['bad']} lost {a.get('true_lost', 0)}/{a['true']} lead "
            f"{a['lead_kept']}/{a['answers']} rep {a['repair_due']} | L2 bad {b.get('bad_out', 0)}/{b['bad']} lost "
            f"{b.get('true_lost', 0)}/{b['true']} lead {b['lead_kept']}/{b['answers']} rep {b['repair_due']} | att "
            f"{p['attack_out']}/{p['attack']} at_true {p['attack_true_kept']}/{p['attack_true']} audit "
            f"{p['audit_true_kept']}/{p['audit_true']} | bld F {p.get('builder_false_out', 0)}/{p['builder_false']} T "
            f"{p['builder_true_kept']}/{p['builder_true']} | skep F {sk.get('F_out', 0)}/{sk.get('F', 0)} T "
            f"{sk.get('T_kept', 0)}/{sk.get('T', 0)}")
