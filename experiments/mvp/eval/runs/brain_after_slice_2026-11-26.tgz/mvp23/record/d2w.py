"""D2w: a NARROW contradiction check on period, base and scope words. It only refuses; it never writes a word.
WRITTEN FROM LOOK 1 ONLY (first forms; tuned only on look 1 true sentences it refused); frozen (d2w.sha256) before any
run on look 2, the attack, the audit set or the skeptic's set.
  period   an explicit year, month, day date, season or named period ('this year', 'last month', 'lately') in the
           sentence must agree with the window of a result the sentence cites (or its window before, when it cites a
           previous or change cell), or with a period label of that result when it cites period cells. The test is
           today's verify._window_check (the same date reading), run on the cited result(s) only.
  base     a base phrase ('of what you opened', 'of everything', 'of all your videos', 'of your videos') on a share or
           count of a filtered or scoped result is refused, unless the same sentence says the scope in the result's
           own label words
  library  a time word on a library cell (saved and never opened: it has no window) is refused"""
import re

BASE_PH = re.compile(r"\bof (?:what you (?:opened|watched|saved|liked)|everything(?: you opened)?|all (?:your|the) "
                     r"videos|your videos|all you opened)\b", re.I)


def _V():
    import lib
    return lib.V1


def _wtext(raw, markers, V):
    w = list(raw)
    for mk in markers:
        dated = mk.kind == "value" and isinstance(mk.value, str) and V._measure(mk.rest, mk.value)[1] == "date"
        for i in range(mk.start if dated else mk.mstart, mk.end):
            w[i] = " "
    return "".join(w)


def check(text, ledger, turn):
    V = _V()
    raw = " ".join(str(text or "").split())
    markers, _bad = V.parse(raw, ledger)
    rids = sorted({mk.rid for mk in markers if mk.rid} | {p.split(".", 1)[0] for mk in markers if mk.kind == "calc"
                                                         for p in (mk.a, mk.b)})
    if not rids:
        return []
    out = []
    # period: agree with one cited result
    cites_prev = any((mk.rest.startswith("previous.") or (mk.key or "").startswith("previous_") or
                      mk.key in ("change_vs_previous", "change_pts", "change")) for mk in markers
                     if mk.kind == "value")
    period_cells = any(re.match(r"^(?:periods|eras|change|areas_change|seasonal)\b", p.split(".", 1)[1])
                       for mk in markers for p in ([mk.path] if mk.kind != "calc" else [mk.a, mk.b]) if "." in p)
    wt = _wtext(raw, markers, V)
    bad = []
    for rid in rids:
        res = ledger.get(rid)
        if res is None:
            continue
        # the window before's own words, said with 'in' for 'from', and 'the same span of 2025' of a result whose
        # window before is in 2025, are that window's words (look 1 K03.0 p2, p3)
        wt2 = wt
        pw = str((res.sheet.get("previous") or {}).get("words") or "").strip()
        if pw:
            core = re.sub(r"^(?:from|in|over)\s+", "", pw, flags=re.I)
            wt2 = re.sub(r"\b(?:from|in|over)?\s*" + re.escape(core), lambda m: " " * len(m.group(0)), wt2, flags=re.I)
            for y in re.findall(r"(?:19|20)\d\d", pw):
                wt2 = re.sub(r"\bthe same (?:span|part|period|stretch|weeks|time|months?) of " + y + r"\b",
                             lambda m: " " * len(m.group(0)), wt2, flags=re.I)
        bad.append(V._window_check(wt2, res, cites_prev or res.tool == "changes", turn, period_cells))
    if bad and all(bad):
        out.append("d2w_period")
    # base
    plain = V.strip_markers(raw)
    if BASE_PH.search(plain):
        for rid in rids:
            res = ledger.get(rid)
            if res is None:
                continue
            parts = V.scope_parts(res)
            if not parts:
                continue
            words = {w for p in parts for w in (p.get("words") or [])}
            low = plain.lower()
            # the scope is said as a scope: 'without gaming', 'only gaming', 'gaming only', or right after the base
            # phrase ('of what you opened on Sundays'); a scope word used otherwise ('the largest gaming theme') is
            # not the base (look 1: B02.0 l0, C04.0 p1 kept; F05.0 p2 refused)
            ends = [m.end() for m in BASE_PH.finditer(plain)]
            said = False
            for w in words:
                wr = re.escape(w) + r"\w*"
                if re.search(r"\b(?:without|only|except|excluding)\s+(?:\w+\s+){0,2}?" + wr + r"\b", low) or \
                        re.search(r"\b" + wr + r"\s+only\b", low) or \
                        any(re.match(r"^[^,.;]{0,25}?\b" + wr + r"\b", low[e:]) for e in ends):
                    said = True
            if not said:
                out.append("d2w_base")
                break
    # library
    for rid in rids:
        res = ledger.get(rid)
        if res is not None and V._library_window(raw, markers, res, turn):
            out.append("d2w_library")
            break
    return out
