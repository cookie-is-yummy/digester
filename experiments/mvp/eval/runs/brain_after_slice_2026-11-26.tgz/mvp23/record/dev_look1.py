"""Development of record.py and d2w.py on LOOK 1 FIRST FORMS ONLY (no other set is read here)."""
import json
import os
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lib as L  # noqa: E402
import record as RC  # noqa: E402
import d2w as W  # noqa: E402

inputs = [x for x in L.heldout_inputs() if x[0] == "look1"]
n = c_need = 0
for look, rec, vt, results in inputs:
    led = L.V1.Ledger(results)
    form = rec["forms"][0]
    sents = [("lead", k, s) for k, s in enumerate(L.V1._split(form.get("lead") or ""))] + \
        [("point", k, p) for k, p in enumerate(form.get("points") or [])]
    cells = []
    for _w, _k, s in sents:
        mks, _ = L.V1.parse(" ".join(s.split()), led)
        cells += [mk.path for mk in mks if mk.kind == "value" and isinstance(mk.value, (int, float))
                  and not isinstance(mk.value, bool)]
    for w, k, s in sents:
        lab = L.LAB.get((look, rec["key"], 0, w, k)) or {}
        nd = RC.needs(s, led)
        why, recs = RC.copy_check(s, led, cells)
        dw = W.check(s, led, vt)
        n += 1
        c_need += bool(nd)
        tag = (lab.get("truth") or "?")[:4]
        if nd or dw:
            print(f"{rec['key']} {w[0]}{k} {tag} need={[g for g, _h, _k in nd]} copy={'ok' if not why else why} "
                  f"d2w={dw} | {L.V1.strip_markers(s)[:120]}")
print("sentences", n, "with a listed word", c_need)
