"""The table, the still-out list and speed, from designs.json, verdicts.json and the records. No model call.
Writes table.txt, still_out.txt, report.json."""
import glob
import json
import os
import re
import statistics as st
import sys
from collections import Counter

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lib as L  # noqa: E402
import tally as T  # noqa: E402
import classmap as CM  # noqa: E402
import record as RC  # noqa: E402

D = json.load(open(os.path.join(HERE, "designs.json")))
VD = json.load(open(os.path.join(HERE, "verdicts.json")))
H = json.load(open(os.path.join(HERE, "records_h.json")))
DATA = L.planted_data()
CASES = {c["id"]: c for c in DATA["cases"]}
sys.path.append(L.SKEP)
import cases as K  # noqa: E402
SK = {c[0]: c for c in K.CASES + K.TRUE}

ORDER = ["D1/a", "D1/d", "D1b/a", "D1b/d", "D2_M0/a", "D2_Mc/a", "D2_H/a", "D2w_M0/a", "D2w_Mc/a", "D2w_H/a",
         "D2_M0/d", "D2_Mc/d", "D2_H/d", "D2w_M0/d", "D2w_Mc/d", "D2w_H/d"]
NAMES = {"M0": "M strict (no record)", "Mc": "M copy (record copied from rows)", "H": "H hand record (looks; copy elsewhere)"}


def plain(s):
    return L.V1.strip_markers(" ".join(str(s or "").split()))


def lead_rows(tab, look, fi=0):
    out = {}
    for r in tab["heldout"]:
        if r["set"] == look and r["form_index"] == fi and r["where"] == "lead":
            out.setdefault(r["key"], []).append(r)
    return out


def own_lead_after_repair(tab, look):
    """(low, high): first-pass kept, plus failed leads rescued. Low: the recorded repair form's lead passes this design
    (records copied from rows). High: also counted rescued when the first lead failed only for want of a record
    (no_record:*), which a repair that adds the record fixes. Estimates."""
    first = lead_rows(tab, look, 0)
    rep = lead_rows(tab, look, 1)
    kept = sum(1 for k, rs in first.items() if all(r["kept"] for r in rs))
    lo = hi = kept
    for k, rs in first.items():
        if all(r["kept"] for r in rs):
            continue
        rr = rep.get(k)
        r_ok = bool(rr) and all(r["kept"] for r in rr)
        only_rec = all(all(x.startswith("no_record") for x in r["reasons"]) for r in rs if not r["kept"])
        lo += r_ok
        hi += r_ok or only_rec
    return kept, lo, hi, len(first)


def look_false(tab, look):
    out = []
    for r in tab["heldout"]:
        if r["set"] != look or r["form_index"] != 0:
            continue
        lab = L.LAB.get((look, r["key"], 0, r["where"], r["index"]))
        if lab and lab["truth"] in T.BAD and r["kept"]:
            cls = CM.LOOKS.get((look, r["key"], r["where"], r["index"]), ("?", ""))
            out.append((cls[0], f"{look} {r['key']} {r['where']} {r['index']}", plain(lab["text"]), cls[1]))
    return out


def attack_out(tab):
    seen = {}
    for r in tab["planted"]:
        if r["set"] != "attack":
            continue
        out_ = bool(r["kept"]) and not (r["expect"] == "private_line" and r["private_line"])
        sid = T.sid(r["id"])
        if out_ and sid not in seen:
            c = CASES[r["id"]]
            tgt = c.get("target") or "point:0"
            f = c["form"]
            s = f["lead"] if tgt.startswith("lead") else (f.get("points") or [""])[int(tgt.split(":")[1])]
            cls = (c.get("class") or "").split(":")[0]
            seen[sid] = (CM.attack_class(cls), f"attack {sid} ({cls})", plain(s),
                         (c.get("class") or "")[len(cls) + 1:].strip())
    return list(seen.values())


def skeptic_out(tab):
    out = []
    for r in tab["skeptic"]:
        if r["truth"] == "F" and r["kept"]:
            c = SK[r["id"]]
            out.append((CM.skeptic_class(c[4]), f"skeptic {c[0]} ({c[4]})", plain(c[5]), c[6]))
    return out


def by_class(items):
    c = Counter(x[0] for x in items)
    return " ".join(f"{k}{c[k]}" for k in ("R", "P", "T", "C", "Y", "?") if c[k]) or "0"


def lost_reasons(tab, look, n=6):
    s = T.held_stats(tab["heldout"], look)[2]
    c = Counter()
    for _i, rr in s:
        for x in set(rr):
            c[re.sub(r":.*", "", x) if not x.startswith("no_record") else "no_record"] += 1
    return ", ".join(f"{k} {v}" for k, v in c.most_common(n))


def sent8(tab, name):
    """Per sent sentence: 'out' / 'caught' / 'does not arise' and the reason; with and without the two rules."""
    res = []
    first = {lk: lead_rows(tab, lk, 0) for lk in ("look1", "look2")}
    rep = {lk: lead_rows(tab, lk, 1) for lk in ("look1", "look2")}

    def lead_after(lk, key):
        f = first[lk].get(key) or []
        if f and all(r["kept"] for r in f):
            return "kept first"
        rr = rep[lk].get(key) or []
        only_rec = all(all(x.startswith("no_record") for x in r["reasons"]) for r in f if not r["kept"])
        if rr and all(r["kept"] for r in rr):
            return "kept after repair"
        return "kept after repair (if the repair adds the record)" if only_rec and f else "fails: code lead"

    def sent_kept(lk, key, where, idx, fi=0):
        for r in tab["heldout"]:
            if (r["set"], r["key"], r["form_index"], r["where"], r["index"]) == (lk, key, fi, where, idx):
                return r["kept"], r["reasons"]
        return None, []
    for lk, key, kind, words in CM.SENT8:
        if kind == "code lead":
            la = lead_after(lk, key)
            st_ = "does not arise (model lead " + la + ")" if not la.startswith("fails") else "OUT (code lead)"
            res.append((lk, key, kind, st_, st_))
            continue
        if kind == "point under code lead":
            la = lead_after(lk, key)
            if la.startswith("fails"):
                res.append((lk, key, kind, "OUT if a code lead may carry model points", "does not arise"))
            else:
                res.append((lk, key, kind, f"does not arise (model lead {la})", "does not arise"))
            continue
        where, idx = {"F05.0": ("point", 2), "F11.0": ("point", 0), "I01.0": ("point", 1)}.get(key, (None, None))
        if key == "I02.0":
            where, idx = ("point", 0) if lk == "look1" else ("lead", 0)
        k0, r0 = sent_kept(lk, key, where, idx, 0)
        k1, r1 = sent_kept(lk, key, where, idx, 1)
        st_ = ("OUT" if k0 else "caught: " + ",".join(sorted(set(r0))[:3])) + \
            (f"; repair form: {'OUT' if k1 else 'caught'}" if k1 is not None else "")
        tool = "tool fault" in kind
        res.append((lk, key, kind, st_, "removed (tool fault fixed)" if tool else st_))
    return res


def count_remaining(rows):
    return sum(1 for r in rows if r[4].startswith("OUT"))


# ------------------------------------------------------------------ speed (paper/speed.py's method, copied)
def speed(design_keys):
    D_ = os.path.join(L.S, "mvp20/tune/heldout")
    recs = [json.load(open(p)) for p in sorted(glob.glob(os.path.join(D_, "*.json"))) if not p.endswith("summary.json")]

    def ga(r):
        return [q for q in r["requests"] if any(isinstance(b, dict) and b.get("name") == "give_answer"
                                                for b in q.get("blocks") or [])]
    gas = [q for r in recs for q in ga(r)]
    spo = st.median([q["seconds"] / max(1, q["usage"]["output_tokens"]) for q in gas if q["usage"]["output_tokens"] > 50])
    rep = [r for r in recs if len(r.get("forms") or []) > 1]

    def rep_s(r):
        seen, s = False, 0.0
        for q in r["requests"]:
            if seen:
                s += q["seconds"]
            if q in ga(r):
                seen = True
        return s
    med_rep = st.median([rep_s(x) for x in rep])
    out = {}
    for name, (due, extra) in design_keys.items():
        ts = []
        for r in recs:
            t = r["seconds"]
            if len(r.get("forms") or []) > 1 and r["key"] not in due:
                t -= rep_s(r)
            if len(r.get("forms") or []) == 1 and r["key"] in due:
                t += med_rep
            t += (1 + (r["key"] in due)) * extra * spo
            ts.append(t)
        out[name] = (len(due), round(st.median(ts), 2), round(sorted(ts)[int(0.9 * len(ts)) - 1], 2))
    tot = [r["seconds"] for r in recs]
    base = (round(st.median(tot), 2), round(sorted(tot)[int(0.9 * len(tot)) - 1], 2), len(rep))
    return out, spo, base


def record_tokens():
    """Added output tokens: the hand records of look 1 in their compact JSON, per sentence and per form."""
    n_sent = sum(1 for k in L.LAB if k[0] == "look1" and k[2] == 0)
    recs = [r for k, v in H.items() if k.startswith("look1|") for r in v]
    chars = sum(len(json.dumps(r, separators=(",", ":"))) for r in recs)
    wrap = 8 * sum(1 for k, v in H.items() if k.startswith("look1|") and v)   # ',"r":[ ... ]' per sentence
    out = {}
    for cpt in (2.5, 3.0, 3.5):
        tok = (chars + wrap) / cpt
        out[cpt] = (round(tok / n_sent, 1), round(tok / 53, 1), round(chars / max(1, len(recs)) / cpt, 1))
    return out, len(recs), n_sent


if __name__ == "__main__":
    lines, still, rep = [], [], {}
    P = lines.append
    P("RECORD DESIGNS ON THE SAVED ANSWERS (mvp23/record). No model call; $0. S = the scratchpad. Made-up data only.")
    P("The model words every sentence; code checks, refuses and asks for one reword; code words nothing.")
    P("Frozen before look 2, the attack, the audit and the skeptic's set: record.py 5956cf8e..., d2w.py 1a03d5cf...")
    P("(frozen.sha256); the hand records records_h.json e1eda25a... (records_h.sha256) before the row check ran on them.")
    P("")
    P("DESIGNS. Cell base 'a' = C1a (doubtful codes on), 'd' = C1d (doubtful codes off), as in the paper test.")
    P("  D1   cells only: today's cell, marker, name, date, calc and policy checks; every framing rule off (paper C1).")
    P("  D1b  D1 + the marker loosenings that let no false sentence out on any set: title_quote, item_channel,")
    P("       short_word, platform_all (d1b.txt). IN SAMPLE: chosen by reading the looks' lost true sentences.")
    P("  D2   D1b + a typed record for each listed word, checked exactly against the rows (record.py).")
    P("  D2w  D2 + a narrow period / base / library contradiction check (d2w.py), written from look 1 only.")
    P("  Bounds of D2/D2w: M0 = the saved forms carry no record, so every listed word is refused (repair load);")
    P("  Mc = the record is filled mechanically from the rows the sentence cites (code): the sentence passes if ANY")
    P("  of up to 64 fillings passes, one cited cell may stand as another's total; NOT a bound either way (it can")
    P("  pass what an honest record refuses: attack P01); H = an honest record written by")
    P("  hand for the 180 look 1 and look 2 first-form sentences with a listed word (J: an ASSUMPTION that only a")
    P("  live run can test). H exists for the looks only; on the attack, audit and skeptic sets H shows Mc.")
    P("  S = simulated by code; J = hand-written input; E = estimate.")
    P("CAVEATS. (1) Look 2's faults, the attack's classes and the skeptic's words were seen this session (in the paper")
    P("  test's files) before record.py and d2w.py were frozen; the rules were not written from them, but nothing here")
    P("  is fresh. (2) D2w is NOT out of sample: its period rule is today's verify._window_check switched back on and")
    P("  its library rule is today's _library_window (written from look 2's I01.0); today's checker is in sample on")
    P("  both looks, the attack and the audit. Only its base rule is new (tuned on look 1). (3) D1b: each kept")
    P("  loosening had only 2 or 3 false cases held back by its own code alone, so 'lets none out' is lightly")
    P("  tested; the loosenings the task named first were rejected or gained nothing: unmarked names let 7 to 18 false")
    P("  sentences out; limits off let the I02 lead out; filler and repeat each let one out; too long, limits words")
    P("  only, num_noun and typed_name gave no true sentence back. (4) The skeptic's set is complete (DONE).")
    P("")
    P("CLASSES of a false or wrongly based sentence (classmap.py): R record kind (rank, tie, place, level, list")
    P("completeness, the other N, new, most of, a move's direction); P period, base or scope words; T tool fault;")
    P("C cell, name, calc or binding; Y policy (outside knowledge, motive, a title's text).")
    P("")
    hdr = (f"{'design':10s} {'L1 false out':>13s} {'L1 true lost':>13s} {'L1 lead 1st':>11s} {'L1 rep':>6s} "
           f"{'L1 own lead E':>13s} | {'L2 false out':>13s} {'L2 true lost':>13s} {'L2 lead 1st':>11s} "
           f"{'L2 rep':>6s} {'L2 own lead E':>13s}")
    P("SETS a, a': LOOK 1 and LOOK 2 FIRST FORMS (look 1: 126 true, 8 false; look 2: 128 true, 9 false; 53 answers)")
    P(hdr)
    for k in ORDER:
        t = D[k]
        row = [f"{k:10s}"]
        rep[k] = {}
        for lk in ("look1", "look2"):
            c, _b, _t = T.held_stats(t["heldout"], lk)
            lf = look_false(t, lk)
            kept, lo, hi, n = own_lead_after_repair(t, lk)
            row.append(f"{c.get('bad_out', 0):>2d}/{c['bad']} {by_class(lf):>8s} {c.get('true_lost', 0):>3d}/{c['true']} "
                       f"({100 * c.get('true_lost', 0) / c['true']:>2.0f}%) {kept:>5d}/{n} {c['repair_due']:>6d} "
                       f"{lo:>3d}-{hi:<2d}/{n}")
            rep[k][lk] = {"false_out": c.get("bad_out", 0), "false_by_class": by_class(lf), "true_lost":
                          c.get("true_lost", 0), "lead_first": kept, "repairs": c["repair_due"],
                          "own_lead_after_repair": [lo, hi], "lost_by_reason": lost_reasons(t, lk)}
        P(" ".join(row[:1]) + " " + row[1] + " | " + row[2])
    P("  true lost by reason (look 1 | look 2):")
    for k in ORDER:
        P(f"    {k:10s} {rep[k]['look1']['lost_by_reason']} | {rep[k]['look2']['lost_by_reason']}")
    P("")
    # M0 repair load
    n1 = sum(1 for kk in VD["heldout"] if kk.startswith("look1|") and kk.split("|")[2] == "0" and VD["heldout"][kk]["needs"])
    n2 = sum(1 for kk in VD["heldout"] if kk.startswith("look2|") and kk.split("|")[2] == "0" and VD["heldout"][kk]["needs"])
    a1 = len({kk.split("|")[1] for kk in VD["heldout"] if kk.startswith("look1|") and kk.split("|")[2] == "0" and
              VD["heldout"][kk]["needs"]})
    l1 = len({kk.split("|")[1] for kk in VD["heldout"] if kk.startswith("look1|") and kk.split("|")[2] == "0" and
              kk.split("|")[3] == "lead" and VD["heldout"][kk]["needs"]})
    l2 = len({kk.split("|")[1] for kk in VD["heldout"] if kk.startswith("look2|") and kk.split("|")[2] == "0" and
              kk.split("|")[3] == "lead" and VD["heldout"][kk]["needs"]})
    P(f"M0 REPAIR LOAD: first-form sentences with a listed word: look 1 {n1} of 137, look 2 {n2} of 139; leads with")
    P(f"one: {l1} and {l2} of 53; answers touched: {a1} of 53 (look 1). With no record each needs a repair.")
    gw = Counter(g for kk, v in VD["heldout"].items() if kk.split("|")[2] == "0" for g in v["needs"])
    P(f"  which words (both looks, first forms): {dict(gw.most_common())}")
    P("")
    P("SET (b): THE 8 SENT FALSE SENTENCES (status on the first form; 'repair form' = the recorded repair, where one")
    P("exists). Right column: a code lead never carries a model point, and tool faults are fixed.")
    s8 = {}
    for k in ORDER:
        rows = sent8(D[k], k)
        s8[k] = rows
        rem = count_remaining(rows)
        rem_any = sum(1 for r in rows if r[3].startswith("OUT"))
        P(f"  {k:10s} out as the rules stand today: {rem_any} of 8; with the two rules: {rem} of 8")
        for lk, key, kind, a, b in rows:
            P(f"      {lk} {key:6s} {kind:26s} {a[:70]:70s} | {b[:60]}")
    P("")
    P("SET (c) THE ATTACK (166 false, 60 true), SET (d) THE AUDIT (61 true), the builder's planted (332 false, 78 true),")
    P("SET (e) THE SKEPTIC'S (48 false, 20 true; cases.py sha256 e83d4fb8..., unchanged since 00:23 UTC; their progress")
    P("file now says DONE, so the set is complete)")
    P(f"{'design':10s} {'attack out':>10s} {'by class':>22s} {'att true':>8s} {'audit':>6s} {'bld F out':>9s} "
      f"{'bld T':>6s} | {'skep F out':>10s} {'by class':>14s} {'skep T':>6s}")
    for k in ORDER:
        t = D[k]
        c, _o = T.planted_stats(t["planted"])
        ao = attack_out(t)
        so = skeptic_out(t)
        sc, _ = T.skeptic_stats(t["skeptic"])
        P(f"{(k + ('=Mc' if '_H/' in k else '')):10s} {c['attack_out']:>4d}/{c['attack']} {by_class(ao):>22s} {c['attack_true_kept']:>4d}/60 "
          f"{c['audit_true_kept']:>3d}/61 {c.get('builder_false_out', 0):>5d}/332 {c['builder_true_kept']:>3d}/78 | "
          f"{sc.get('F_out', 0):>6d}/48 {by_class(so):>14s} {sc.get('T_kept', 0):>3d}/20")
        rep[k]["attack_out"] = c["attack_out"]
        rep[k]["attack_by_class"] = by_class(ao)
        rep[k]["skeptic_out"] = sc.get("F_out", 0)
        rep[k]["skeptic_by_class"] = by_class(so)
        still.append((k, look_false(t, "look1") + look_false(t, "look2"), ao, so))
    P("")
    # tokens and speed
    rt, nrec, nsent = record_tokens()
    P(f"RECORD SIZE (E): look 1's {nrec} hand records as written (defaults spelled out; {nsent} first-form sentences).")
    P("Added output")
    P("tokens at 2.5 / 3.0 / 3.5 characters a token: per sentence " + " / ".join(str(rt[c][0]) for c in rt) +
      "; per form " + " / ".join(str(rt[c][1]) for c in rt) + "; per record " + " / ".join(str(rt[c][2]) for c in rt))
    P("  (the compact form, defaults stripped, is measured under COMPACT RECORDS at the end; speed below uses this")
    P("  fuller form, about 10 tokens a form more: +0.05 s)")
    due = {}
    for k in ORDER:
        keys = T.repair_keys(D[k]["heldout"], "look1")
        extra = rt[3.0][1] if k.startswith("D2") else 0
        due[k] = (keys, extra)
    sp, spo, base = speed(due)
    P(f"SPEED (E; paper/speed.py's method on look 1's records): as run median {base[0]} s, p90 {base[1]} s, {base[2]} "
      f"repair forms; {spo:.4f} s per output token. Bar: 8 s median, 11 s slow end.")
    for k in ORDER:
        n, m, p90 = sp[k]
        P(f"  {k:10s} repairs {n:>2d}/53  median {m:5.2f} s  p90 {p90:5.2f} s  {'meets' if m <= 8 and p90 <= 11 else 'MISSES'}")
    P("  (M0 is the worst case: every listed word costs a repair round; H is the design's own speed if the model writes")
    P("  honest records on the first pass.)")
    P("")
    P("THE 17 LOOK FAULTS BY LAYER (base d; base a differs only where noted). cells = D1b's cell checks; record = H;")
    P("d2w = the narrow check. In sample: F05.0 p2 (d2w base rule tuned on look 1); I01.0 p1's rule comes from the task.")
    import classmap as _CM
    cells_d = {(r["set"], r["key"], r["where"], r["index"]): r for r in json.load(open(os.path.join(HERE,
               "cells_D1bd.json")))["heldout"] if r["form_index"] == 0}
    cells_a = {(r["set"], r["key"], r["where"], r["index"]): r for r in json.load(open(os.path.join(HERE,
               "cells_D1b.json")))["heldout"] if r["form_index"] == 0}
    for (lk, key, w, i), (cls, why) in _CM.LOOKS.items():
        v = VD["heldout"][f"{lk}|{key}|0|{w}|{i}"]
        cd, ca = cells_d[(lk, key, w, i)], cells_a[(lk, key, w, i)]
        lay = []
        if not cd["kept"]:
            lay.append("cells")
        if v.get("h"):
            lay.append("record(" + ",".join(v["h"]) + ")")
        if v["w"]:
            lay.append("d2w(" + ",".join(v["w"]) + ")")
        note = "" if cd["kept"] == ca["kept"] else f" [base a: cells {'keep' if ca['kept'] else 'drop'}]"
        P(f"  [{cls}] {lk} {key} {w}{i}: {'caught by ' + ' + '.join(lay) if lay else 'OUT under D2w H'}{note}  -- {why}")
    P("  Holes the honest record does not close (looks): A06.0 'the fewest' (a true least among themes, read after a")
    P("  channel ranking: the level); K03.0 p2 'New this year: Gaming clips' (a colon list claims completeness with no")
    P("  listed word); D03.2 'one of the top five' passes the record on a list cut at five (the row check cannot see")
    P("  the tie beyond the cut; cells catch it); F15.0 p0 (scope words, unchecked by design); the I02 pair (tool).")
    P("")
    P("ATTACK UNDER AN HONEST RECORD (J, by hand, for the 14 R-class sentences Mc lets out on base d): P01 'made up most'")
    P("  (25% + 23%) would be refused; the other 13 stay out: R01, R02, R05 to R11 'only, all, nothing else, smallest, just 4' over rows")
    P("  that leave out the private topic (the row check does not read meta.hidden), P02 and P03 'together' (no listed")
    P("  word), X02 and X03 'went from A to B' swapped (no listed move word). The P class (54 on base d) is left")
    P("  unchecked by design in D2; D2w's three rules catch 7 more of them than D2.")
    P("")
    P("CLOSED WORD LIST (record.py WORDS, frozen): 98 entries (word forms counted apart) in 9 groups:")
    for g, rx in RC.WORDS:
        P(f"  {g:9s} -> {'/'.join(sorted(RC.NEED[g]))}: {rx.pattern}")
    open(os.path.join(HERE, "table.txt"), "w").write("\n".join(lines) + "\n")
    # still out
    so_lines = ["SENTENCES STILL OUT, by design (false or wrongly based; class R record kind, P period/base/scope, "
                "T tool fault, C cell/binding, Y policy). Text with markers taken out. H rows are the looks only.", ""]
    for k, lf, ao, so in still:
        so_lines.append(f"=== {k}: looks {len(lf)} ({by_class(lf)}), attack {len(ao)} ({by_class(ao)}), skeptic "
                        f"{len(so)} ({by_class(so)})")
        for grp, items in (("looks (first forms)", lf), ("attack", ao), ("skeptic", so)):
            if not items:
                continue
            so_lines.append(f"  -- {grp}")
            for cls, wid, text, why in sorted(items):
                so_lines.append(f"  [{cls}] {wid}: \"{text}\"  -- {why}")
        so_lines.append("")
    open(os.path.join(HERE, "still_out.txt"), "w").write("\n".join(so_lines) + "\n")
    json.dump({"designs": rep, "sent8": s8, "speed": sp, "tokens": rt}, open(os.path.join(HERE, "report.json"), "w"),
              indent=1, default=str)
    print("\n".join(lines))
