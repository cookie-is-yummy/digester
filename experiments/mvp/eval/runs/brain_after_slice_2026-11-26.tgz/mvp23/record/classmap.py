"""Every false sentence's class, written before any D2 run on look 2, the attack, the audit or the skeptic's set.
  R = record kind: rank, tie, place, level, list completeness, 'the other N', 'new', 'most of', a move's direction
  P = period, base or scope words (window, dates, weekdays, hours, base phrase, platform, scope, persist words)
  T = tool fault (the rows the tool returned leave out what the sentence needs)
  C = cell, name, calc or marker binding;  Y = policy (outside knowledge, motive, a title's text)"""

LOOKS = {
    # look 1 (8)
    ("look1", "A06.0", "point", 1): ("R", "rank across levels: 'the fewest' after a channel ranking"),
    ("look1", "B05.0", "point", 0): ("R", "rank tie: 'the biggest drop' shared by three channels"),
    ("look1", "D03.2", "point", 1): ("R", "rank over a tie: 'one of the top five' when all were opened once"),
    ("look1", "F05.0", "point", 2): ("P", "base and persist: '51% of what you opened' is of gaming only; 'still'"),
    ("look1", "F11.0", "point", 0): ("R", "list completeness: 'your full years before 2026' leaves out 2024, 2025"),
    ("look1", "I02.0", "lead", 0): ("T", "false absence: the find and themes list cannot see the unlocked topic"),
    ("look1", "I02.0", "point", 0): ("T", "rank with the private theme left out of the rows (Dating advice 50)"),
    ("look1", "K03.0", "point", 1): ("R", "'new' and completeness: the new lists are cut, 'new' against Jan-Oct 2025"),
    # look 2 (9)
    ("look2", "B05.0", "point", 0): ("R", "rank tie: 'the largest drop in items' shared by three channels"),
    ("look2", "B14.0", "point", 0): ("R", "'the other 651' are not the rest of the 723 (657 remain)"),
    ("look2", "B14.0", "point", 1): ("R", "only/all: 'Clip Factory is its channel' while Gaming Daily holds 5"),
    ("look2", "F05.0", "lead", 0): ("P", "window: 'the 30 days your YouTube export covers'"),
    ("look2", "F11.0", "point", 0): ("P", "base: 48% is of October's YouTube videos, said of October's videos"),
    ("look2", "F15.0", "point", 0): ("P", "scope: 'the 83 calculus videos you opened' are the long ones"),
    ("look2", "I01.0", "point", 1): ("P", "window on a library cell: 'not opened in 2024' of saves made in 2026"),
    ("look2", "I02.0", "lead", 0): ("T", "false absence: the tools cannot see the unlocked topic"),
    ("look2", "K03.0", "point", 2): ("R", "list completeness of 'new': leaves out Digital drawing"),
}

ATTACK = {
    "least": "R", "fell_into": "R", "cut_count": "R", "share_sum": "R", "private": "R", "from_to": "R",
    "change_period": "P", "period_label": "P", "lead_window": "P", "move_frame": "P", "compare_frame": "P",
    "dates": "P", "hour": "P", "waiver": "P", "scope_words": "P", "of_videos_frame": "P", "platform": "P",
    "base_verbs": "P", "bare_clause": "P", "pct": "P", "find": "P",
    # two_results: relabelled C -> P after the first table (each is a point of another result's window under a lead
    # that names a different one, e.g. "Clip Factory led with 13 videos" under an October lead: a window fault)
    "number_word": "C", "two_results": "P", "title": "Y", "calc_rows": "C", "owner": "C", "measure": "C",
    "outside": "Y", "outside_theme": "Y", "motive": "Y",
}

SKEPTIC = {
    "mostly": "R", "rank_verb": "R", "private": "R", "new_list": "R", "direction": "R", "rank_next": "R",
    "level": "R", "list_trunc": "R", "all_pred": "R", "list_some": "R", "small_move": "R", "size_word": "R",
    "weekday_rank": "R", "private_series": "R", "series": "R",
    "persist": "P", "time_open": "P", "follow_up": "P", "lead_no_comma": "P", "lead_opening": "P", "anaphora": "P",
    "base_word": "P", "median_base": "P", "platform": "P", "inner_share": "P", "weekday": "P", "free": "P",
    "coverage": "T", "two_results": "C", "ratio_word": "C", "number_word": "C",
}

# the 8 sent false sentences (answers.json): which are code's own words or a model point under a code lead
SENT8 = [
    ("look1", "B03.0", "code lead", "code's template lead 'Home cooking led what you opened, with 30 long videos' "
                                     "(false: Home cooking is a theme; food and cooking led)"),
    ("look1", "C04.0", "point under code lead", "'art and design came next' read after code's lead"),
    ("look1", "F05.0", "model point", "F05.0 p2 'still the largest gaming theme, at 51% of what you opened'"),
    ("look1", "F11.0", "model point", "F11.0 p0 'Your full years before 2026 were 2021, 2022 and 2023'"),
    ("look1", "I02.0", "model point (tool fault)", "I02.0 p0 'the top theme was Home cooking with 8'"),
    ("look2", "E04.0", "point under code lead", "'That is 8 fewer videos' read after code's lead"),
    ("look2", "I02.0", "model lead (tool fault)", "I02.0 l0 'I found no dating advice theme or channel'"),
    ("look2", "I01.0", "model point", "I01.0 p1 '3 saved Home cooking posts were not opened in 2024'"),
]


def attack_class(cls):
    return ATTACK.get((cls or "").split(":")[0], "?")


def skeptic_class(cls):
    return SKEPTIC.get(cls, "?")
