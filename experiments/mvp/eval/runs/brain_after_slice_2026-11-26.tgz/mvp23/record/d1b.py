"""D1b: each marker-bookkeeping loosening alone on the D1 (C1a) base, then the kept ones together; also on the C1d base.
Counts true gained and false let out against D1 on: look 1 and look 2 (first and repair forms), the attack (166), the
attack's true (60), the audit true (61), the builder's planted cases (new, audit, insight_v5). The skeptic's set is
counted but never used to keep or drop a loosening. IN SAMPLE: the loosenings were chosen by reading look 1 and look 2's
lost true sentences. Writes d1b.json, d1b.txt, cells_D1b.json, cells_D1bd.json."""
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
subprocess.run([sys.executable, os.path.join(HERE, "make_d1b.py")], check=True)
import lib as L  # noqa: E402
import run_cells as R  # noqa: E402
import tally as T  # noqa: E402

VB = L.load_checker(os.path.join(HERE, "src", "verify_d1b.py"), "verify_d1b")
VARIANTS = {
    "title_quote": ({"title_quote"}, set()), "item_channel": ({"item_channel"}, set()),
    "short_word": ({"short_word"}, set()), "platform_all": ({"platform_all"}, set()),
    "num_noun": ({"num_noun"}, set()), "limits_off": ({"limits_off"}, set()),
    "limits_regex": ({"limits_regex"}, set()), "too_long": ({"too_long"}, set()), "filler_off": (set(), {"filler"}),
    "repeat_off": ({"repeat_off"}, set()), "uname_row": ({"uname_row"}, set()),
    "uname_row+typed_off": ({"uname_row"}, {"typed_name"}), "uname_nonum": ({"uname_nonum"}, set()),
    "uname_nonum+typed_off": ({"uname_nonum"}, {"typed_name"}), "typed_off": (set(), {"typed_name"}),
}


def setv(base, loose, extra_off):
    off, ins = L.CONFIGS[base]
    VB.OFF.clear()
    VB.OFF.update(set(off) | set(extra_off))
    VB.INSIGHT = ins
    VB.LOOSE.clear()
    VB.LOOSE.update(loose)


def outs(tab):
    """(set of false-out ids, set of true-kept ids) over every set used for gating, skeptic apart."""
    fo, tk = set(), set()
    for r in tab["heldout"]:
        lab = L.LAB.get((r["set"], r["key"], r["form_index"], r["where"], r["index"]))
        if not lab:
            continue
        i = f'{r["set"]}:{r["key"]}.f{r["form_index"]}.{r["where"]}{r["index"]}'
        if lab["truth"] in T.BAD and r["kept"]:
            fo.add(i)
        if lab["truth"] == "true" and r["kept"]:
            tk.add(i)
    for r in tab["planted"]:
        i = f'{r["set"]}:{T.sid(r["id"]) if r["set"] == "attack" else r["id"]}'
        if r["expect"] == "kept":
            if r["kept"]:
                tk.add(i)
        elif r["kept"] and not (r["expect"] == "private_line" and r["private_line"]):
            fo.add(i)
    sk_f = {r["id"] for r in tab["skeptic"] if r["truth"] == "F" and r["kept"]}
    sk_t = {r["id"] for r in tab["skeptic"] if r["truth"] == "T" and r["kept"]}
    return fo, tk, sk_f, sk_t


def held_back(tab, code_words):
    """False cases dropped on the base that carry one of the codes this loosening touches, and those where those
    codes are the only reasons (the cases the loosening could let out: 0 means 'let none out' is untested)."""
    n = sole = 0
    rows = [r for r in tab["heldout"] if (lambda lab: lab and lab["truth"] in T.BAD)(
        L.LAB.get((r["set"], r["key"], r["form_index"], r["where"], r["index"])))]
    rows += [r for r in tab["planted"] if r["expect"] != "kept"]
    for r in rows:
        if not r["kept"] and any(c in code_words for c in r["reasons"]):
            n += 1
            sole += all(c in code_words for c in r["reasons"])
    return f"{n}, sole {sole}"


CODES = {"title_quote": {"wrong_name"}, "item_channel": {"wrong_name"}, "short_word": {"wrong_name"},
         "platform_all": {"bad_marker"}, "num_noun": {"bad_marker", "uncited_number"}, "limits_off": {"limits"},
         "limits_regex": {"limits"}, "too_long": {"too_long"}, "filler_off": {"filler"}, "repeat_off": {"repeat"},
         "uname_row": {"uncited_name"}, "uname_row+typed_off": {"uncited_name", "typed_name"},
         "uname_nonum": {"uncited_name"}, "uname_nonum+typed_off": {"uncited_name", "typed_name"},
         "typed_off": {"typed_name"}}

if __name__ == "__main__":
    inputs = L.heldout_inputs()
    data = L.planted_data()
    sk = L.skeptic_inputs(VB)
    res, lines = {}, []
    for base in ("C1a", "C1d"):
        setv(base, set(), set())
        b = R.run_all(VB, inputs, data, sk)
        ref = json.load(open(os.path.join(HERE, f"cells_{base}.json")))
        same = sum(1 for x, y in zip(ref["heldout"], b["heldout"]) if x["kept"] == y["kept"] and
                   sorted(x["reasons"]) == sorted(y["reasons"]))
        samep = sum(1 for x, y in zip(ref["planted"], b["planted"]) if x["kept"] == y["kept"])
        lines.append(f"{base}: copy with LOOSE empty vs verify_c1: held-out {same}/{len(b['heldout'])}, planted "
                     f"{samep}/{len(b['planted'])}")
        bf, bt, bsf, bst = outs(b)
        kept = []
        for name, (loose, extra) in VARIANTS.items():
            setv(base, loose, extra)
            t = R.run_all(VB, inputs, data, sk)
            f, tk, sf, st = outs(t)
            row = {"true_gained": sorted(tk - bt), "true_lost_new": sorted(bt - tk), "false_out_new": sorted(f - bf),
                   "held_back_on_base": held_back(b, CODES[name]), "skeptic_false_new": sorted(sf - bsf),
                   "skeptic_true_gained": sorted(st - bst)}
            res[f"{base}:{name}"] = row
            ok = not row["false_out_new"] and bool(row["true_gained"])
            if ok:
                kept.append(name)
            lines.append(f"  {base} {name:22s} true +{len(row['true_gained'])} -{len(row['true_lost_new'])}  false out "
                         f"+{len(row['false_out_new'])}  (false held back by its codes on the base: "
                         f"{row['held_back_on_base']})  skeptic F +{len(row['skeptic_false_new'])} T "
                         f"+{len(row['skeptic_true_gained'])}  {'KEEP' if ok else 'drop'}")
            lines.append(f"      gained: {row['true_gained'][:12]}")
            if row["false_out_new"]:
                lines.append(f"      FALSE OUT: {row['false_out_new'][:12]}")
        res[f"{base}:base"] = b
        res[f"{base}:kept_alone"] = kept
    KEEP = [k for k in VARIANTS if not res[f"C1a:{k}"]["false_out_new"] and not res[f"C1d:{k}"]["false_out_new"]
            and (res[f"C1a:{k}"]["true_gained"] or res[f"C1d:{k}"]["true_gained"])]
    lines.append(f"kept (no false out on either base, a true gain on one): {KEEP}")
    for base in ("C1a", "C1d"):
        b = res.pop(f"{base}:base")
        bf, bt, bsf, bst = outs(b)
        kept = KEEP
        # the kept ones together (variants that are supersets of others: take the widest kept of each family)
        fam = {}
        for k in kept:
            fam.setdefault(k.split("+")[0].replace("_nonum", "_row").replace("limits_regex", "limits_off"), []).append(k)
        loose, extra = set(), set()
        for k in kept:
            loose |= VARIANTS[k][0]
            extra |= VARIANTS[k][1]
        if "uname_row" in loose:
            loose.discard("uname_nonum")
        if "limits_off" in loose:
            loose.discard("limits_regex")
        setv(base, loose, extra)
        t = R.run_all(VB, inputs, data, sk)
        f, tk, sf, st = outs(t)
        res[f"{base}:together"] = {"loose": sorted(loose), "off": sorted(extra), "true_gained": sorted(tk - bt),
                                   "false_out_new": sorted(f - bf), "skeptic_false_new": sorted(sf - bsf)}
        lines.append(f"  {base} TOGETHER {sorted(loose)} off {sorted(extra)}: true +{len(tk - bt)}, false out "
                     f"+{len(f - bf)} {sorted(f - bf)}; skeptic F +{len(sf - bsf)}")
        tag = "D1b" if base == "C1a" else "D1bd"
        json.dump(t, open(os.path.join(HERE, f"cells_{tag}.json"), "w"), indent=0, default=str)
        lines.append("  " + T.line(tag, T.summary(t)))
    json.dump(res, open(os.path.join(HERE, "d1b.json"), "w"), indent=1)
    open(os.path.join(HERE, "d1b.txt"), "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))
