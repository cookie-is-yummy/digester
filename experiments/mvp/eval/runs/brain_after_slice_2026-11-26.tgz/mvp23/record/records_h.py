"""D2's H bound: the honest record of every look 1 and look 2 FIRST-FORM sentence with a listed word, written BY HAND
from the sentence's text and its rows (what the sentence claims), not from the recount's truth or fault columns.
Conventions (decided once): 'led/top/largest' rank most place 1 by the cell said (share or items); 'came next' or
'second' place 2, 'third' place 3; 'then X' after 'came next' place 3; 'mostly from X' rest/most of X's count against
the parent's count; 'all from X' rest/all of X's count against the parent's count (or list/all when the sentence says
X is the only row); 'all on YouTube' rest/all of the platform cell against the total; 'all of them Shorts' rest/all of
a share cell of 100%; 'first/last/most recent' rank by date, or by list place when the sentence says 'on the list' or
'the second one'; 'top five' list/top of five rows; a listed word used in another sense ('fell on 26 days', 'fall in
Oct 2026', 'the full history', 'the only channel with that name') gets NO record: an honest model cannot back it and
is refused. Writes records_h.json; its sha256 goes in records_h.sha256 before run_designs.py reads it."""
import hashlib
import json
import os


def rk(rows, o="most", p=1, by=None, tie=False):
    r = {"k": "rank", "rows": rows, "o": o, "p": p, "tie": tie}
    if by:
        r["by"] = by
    return r


def ls(rows, c):
    return {"k": "list", "rows": rows, "c": c}


def rs(parts, total, says):
    return {"k": "rest", "parts": parts, "total": total, "says": says}


def nw(rows):
    return {"k": "new", "rows": rows}


def mv(now, before, d):
    return {"k": "move", "now": now, "before": before, "dir": d}


def mvc(change, d):
    return {"k": "move", "change": change, "dir": d}


def ch(i, r="r1"):
    return f"{r}.channels[{i}]"


def th(i, r="r1"):
    return f"{r}.themes[{i}]"


def ar(i, r="r1"):
    return f"{r}.areas[{i}]"


def it(i, r="r1"):
    return f"{r}.items[{i}]"


L1 = {
    "A01.0|lead|0": [rk([ar(0)], by="share")],
    "A01.0|point|0": [rk([th(0)], by="items"), rs(["r1.channels[0].items"], "r1.themes[0].items", "most")],
    "A01.0|point|1": [rk(["r1.fields[1]"], p=2, by="share"), rk(["r1.areas[1].themes[0]"])],
    "A01.1|lead|0": [rk([th(0)], by="items")],
    "A01.1|point|0": [rk([th(1)], p=2, by="items"), mv("r1.themes[1].items", "r1.themes[1].previous_items", "up")],
    "A01.1|point|1": [mv("r1.themes[2].share", "r1.themes[2].previous_share", "down")],
    "A01.3|lead|0": [rk([ch(0)], by="items")],
    "A01.3|point|0": [rk([ch(1)], p=2, by="items")],
    "A01.3|point|1": [ls([ch(i) for i in range(5)], "top")],
    "A01.4|lead|0": [rk([ch(0)], by="items")],
    "A01.4|point|0": [rk([ch(1)], p=2, by="items")],
    "A01.5|lead|0": [rk([ch(0)], by="items")],
    "A01.5|point|0": [rk([ch(1)], p=2, by="items")],
    "A03.0|lead|0": [rk([th(0)], by="share")],
    "A03.0|point|0": [rk([th(1)], p=2, by="share"), mv("r1.themes[1].share", "r1.themes[1].previous_share", "up")],
    "A03.0|point|1": [mvc("r1.themes[2].change_vs_previous", "down")],
    "A05.0|lead|0": [rk([ch(0)], by="items")],
    "A05.0|point|0": [rk([ch(1)], p=2, by="items")],
    "A05.0|point|1": [rk([ch(2)], p=3, by="items")],
    "A06.0|lead|0": [rk([ch(0)], by="items")],
    "A06.0|point|0": [rk([ch(1)], p=2, by="items")],
    "A06.0|point|1": [rk([th(3)], o="least", by="items")],
    "A07.0|lead|0": [rk([ch(0)], by="items")],
    "A07.0|point|0": [rk([ch(1)], p=2, by="items")],
    "B01.0|lead|0": [rk([ar(0)], by="share")],
    "B01.0|point|1": [rk([ar(1)], p=2, by="share"), rk(["r1.areas[1].themes[0]"])],
    "B02.0|lead|0": [rk([ar(0)], by="share")],
    "B02.0|point|0": [rk([ar(1)], p=2, by="share")],
    "B03.0|lead|0": [rk([ar(0)], by="items")],
    "B03.0|point|0": [rk([ar(1)], p=2, by="items")],
    "B05.0|point|0": [rk([ch(2)], by="drop"), mv("r1.channels[2].items", "r1.channels[2].previous_items", "down")],
    "B07.0|lead|0": [rk([it(0)], o="first")],
    "B11.0|lead|0": [rk([ch(0)], by="items")],
    "B11.0|point|0": [rk([ch(1)], p=2, by="items")],
    "B14.0|point|0": [rk([th(0)], by="items")],
    "B14.0|point|1": [rs(["r1.themes[6].shorts_share"], None, "all")],
    "C01.0|lead|0": [rk([ch(0)], o="least", by="items")],
    "C02.0|lead|0": [rk([ar(0)], by="share")],
    "C02.0|point|0": [mvc("r1.areas[1].change_pts", "down")],
    "C02.0|point|1": [mvc("r1.areas[2].change_pts", "up")],
    "C04.0|lead|0": [rk([ar(0)], by="share")],
    "C04.0|point|0": [rk([th(0)], by="items"), rs(["r1.channels[0].items"], "r1.themes[0].items", "all")],
    "C04.0|point|1": [rk([ar(1)], p=2, by="share")],
    "C06.0|lead|0": [rk([ar(0)], by="items")],
    "C06.0|point|0": [rk([ar(1)], p=2, by="items")],
    "C06.0|point|1": [rk([th(0)], by="items")],
    "C08.0|lead|0": [rk([it(0)], o="last")],
    "C08.0|point|0": [rs(["r1.channels[0].items"], "r1.themes[0].items", "all")],
    "C09.0|lead|0": [rk([it(0)], by="times_opened", tie=True)],
    "C09.0|point|1": [rk([it(4)], o="list", p=5)],
    "D01.0|lead|0": [rk([ch(0)], by="items")],
    "D01.0|point|0": [rk([ch(1)], p=2, by="items")],
    "D01.1|lead|0": [rk([ch(0)], by="items")],
    "D01.1|point|0": [rk([ch(1)], p=2, by="items")],
    "D03.0|lead|0": [rk([ch(0)], by="items")],
    "D03.0|point|0": [rk([ch(1)], p=2, by="items"), rk([ch(2)], p=3, by="items")],
    "D03.2|point|1": [ls([it(i) for i in range(5)], "top")],
    "D04.0|point|0": [rk([th(0)], by="items")],
    "D04.0|point|1": [rk([th(1)], p=2, by="items")],
    "D07.0|lead|0": [rs(["r1.totals.by_platform.youtube"], "r1.totals.items", "all")],
    "D07.0|point|0": [rk([it(0)], o="first")],
    "D07.0|point|1": [rk([it(3)], o="last")],
    "D08.0|lead|0": [rs(["r1.channels[0].items"], "r1.totals.items", "all")],
    "D08.0|point|0": [rs(["r1.totals.long"], "r1.totals.items", "all"), rs(["r1.themes[0].items"], "r1.totals.items", "all")],
    "D10.0|lead|0": [rk([ar(0)], by="share")],
    "D10.1|point|0": [rk([ar(0, "r2")], by="share")],
    "E04.0|point|0": [rk([ch(2)], by="drop"), mv("r1.channels[2].items", "r1.channels[2].previous_items", "down")],
    "F02.0|lead|0": [rs(["r1.totals.by_platform.youtube"], "r1.totals.items", "all")],
    "F02.0|point|0": [rk([th(0)], by="items")],
    "F04.0|point|0": [rs(["r1.channels[0].items"], "r1.totals.items", "all")],
    "F05.0|lead|0": [rs(["r1.themes[2].shorts_share"], None, "all")],
    "F05.0|point|2": [rk([th(0)], by="share")],
    "F06.0|lead|0": [mv("r1.areas[0].share", "r1.areas[0].previous_share", "up")],
    "F06.0|point|0": [mvc("r1.areas[0].change_pts", "up")],
    "F06.0|point|1": [rs(["r1.channels[0].theme_share", "r1.channels[0].shorts_share"], None, "all")],
    "F09.0|point|0": [ls(["r2.channels[0]"], "all")],
    "F10.0|point|1": [rk([ch(1)], p=2, by="items"), rs(["r1.channels[1].theme_share"], None, "all")],
    "F11.0|point|0": [ls(["r3.periods[0]", "r3.periods[1]", "r3.periods[2]"], "all")],
    "F14.0|point|0": [rs(["r2.themes[2].channels[0].items"], "r2.themes[2].items", "most")],
    "F15.0|lead|0": [rk([it(0)], o="list", p=1)],
    "I01.0|point|0": [rs(["r1.channels[0].items"], "r1.themes[0].items", "all")],
    "I02.0|point|0": [rk([th(0, "r2")], by="items")],
    "I03.0|lead|0": [rs(["r1.areas[0].items"], "r1.totals.items", "all")],
    "I03.0|point|0": [ls([th(0)], "all"), ls([ch(0)], "all")],
    "K03.0|lead|0": [rk([th(0)], by="share")],
    "K03.0|point|0": [rk([th(1)], p=2, by="items"), rk([ch(0, "r2")], by="items")],
    "K03.0|point|1": [nw(["r3.channels[0]", "r3.channels[1]", "r3.channels[2]", "r3.new.themes[2]", "r3.new.themes[3]"])],
    "K03.0|point|2": [mv("r3.themes[2].share", "r3.themes[2].previous_share", "down")],
}

L2 = {
    "A01.0|lead|0": [rk(["r1.fields[0]"], by="share")],
    "A01.0|point|1": [rk([th(1)], p=2, by="items")],
    "A01.1|lead|0": [rk([th(0)], by="items")],
    "A01.1|point|0": [rk([th(1)], p=2, by="items"), mv("r1.themes[1].items", "r1.themes[1].previous_items", "up")],
    "A01.1|point|1": [mv("r1.themes[2].share", "r1.themes[2].previous_share", "down")],
    "A01.3|lead|0": [rk([ch(0)], by="items")],
    "A01.3|point|0": [rk([ch(1)], p=2, by="items"), rk([ch(2)], p=3, by="items")],
    "A01.4|lead|0": [rk([ch(0)], by="items")],
    "A01.4|point|0": [rk([ch(1)], p=2, by="items")],
    "A01.5|lead|0": [rk([ch(0)], by="items")],
    "A01.5|point|0": [rk([ch(1)], p=2, by="items")],
    "A01.5|point|1": [ls([ch(i) for i in range(4)], "all")],
    "A03.0|lead|0": [rk([th(0)], by="items")],
    "A03.0|point|0": [rk([th(1)], p=2, by="items")],
    "A05.0|lead|0": [rk([ch(0)], by="items")],
    "A05.0|point|0": [rk([ch(1)], p=2, by="items")],
    "A06.0|lead|0": [rk([ch(0)], by="items")],
    "A06.0|point|0": [rk([ch(1)], p=2, by="items")],
    "A07.0|lead|0": [rk([ch(0)], by="items")],
    "A07.0|point|0": [rk([ch(1)], p=2, by="items")],
    "A07.0|point|1": [rk([ch(2)], o="list", p=3)],
    "B01.0|lead|0": [rk([ar(0)], by="items")],
    "B01.0|point|1": [rk(["r1.fields[1]"], p=2, by="share")],
    "B02.0|lead|0": [rk([ar(0)], by="share")],
    "B02.0|point|0": [rk([ar(1)], p=2, by="share")],
    "B03.0|lead|0": [rk([ar(0)], by="items")],
    "B03.0|point|0": [rk([ar(1)], p=2, by="items")],
    "B05.0|point|0": [rk([ch(2)], by="drop"), mv("r1.channels[2].items", "r1.channels[2].previous_items", "down")],
    "B07.0|lead|0": [rk([it(0)], o="first")],
    "B11.0|lead|0": [rk([ch(0)], by="items")],
    "B11.0|point|0": [rk([ch(1)], p=2, by="items")],
    "B14.0|point|0": [rs(["r1.totals.long", "r1.totals.shorts"], "r1.totals.items", "rest")],
    "C01.0|lead|0": [rk([ch(0)], o="least", by="items")],
    "C02.0|lead|0": [rk([ar(0)], by="items")],
    "C02.0|point|0": [rk([ar(1)], p=2, by="items")],
    "C04.0|lead|0": [rk([ar(0)], by="share")],
    "C04.0|point|0": [rk([th(0)], by="items")],
    "C04.0|point|1": [rk([ar(1)], p=2, by="share")],
    "C06.0|lead|0": [rk([ar(0)], by="items")],
    "C06.0|point|0": [rk([ar(1)], p=2, by="items")],
    "C06.0|point|1": [rk([th(0)], by="items")],
    "C08.0|lead|0": [rk([it(0)], o="last")],
    "C09.0|lead|0": [rk([it(0)], by="times_opened", tie=True)],
    "C09.0|point|0": [rk([it(4)], by="times_opened", tie=True), ls([it(i) for i in range(5)], "all")],
    "D01.0|lead|0": [rk([ch(0)], by="items")],
    "D01.0|point|0": [rk([ch(1)], p=2, by="items")],
    "D01.0|point|1": [rk([ch(2)], p=3, by="items")],
    "D01.1|lead|0": [rk([ch(0)], by="items")],
    "D01.1|point|0": [rk([ch(1)], p=2, by="items")],
    "D03.0|lead|0": [rk([ch(0)], by="items")],
    "D03.0|point|0": [rk([ch(1)], p=2, by="items")],
    "D03.0|point|1": [rk([ch(2)], p=3, by="items")],
    "D04.0|point|0": [rk([th(0)], by="items"), rs(["r1.channels[0].items"], "r1.themes[0].items", "all")],
    "D04.0|point|1": [rk([th(1)], p=2, by="items")],
    "D04.0|point|2": [rs(["r1.channels[2].items"], "r1.areas[1].items", "all")],
    "D07.1|lead|0": [rk([it(1)], o="list", p=2)],
    "D08.0|lead|0": [rs(["r1.channels[0].items"], "r1.totals.items", "all")],
    "D08.0|point|0": [rs(["r1.themes[0].items"], "r1.totals.items", "all"),
                      rs(["r1.totals.by_platform.youtube"], "r1.totals.items", "all")],
    "D08.0|point|1": [],
    "D08.1|point|0": [rs(["r1.channels[0].items"], "r1.totals.items", "all"),
                      rs(["r1.themes[0].items"], "r1.totals.items", "all")],
    "D10.0|lead|0": [rk([ar(0)], by="share")],
    "D10.0|point|0": [rk([ar(1)], p=2, by="share")],
    "D10.1|point|0": [rs(["r1.channels[0].items"], "r1.themes[0].items", "most")],
    "D10.1|point|1": [rs(["r1.themes[0].shorts_share"], None, "all")],
    "E04.0|lead|0": [mv("r1.channels[2].items", "r1.channels[2].previous_items", "down")],
    "E04.0|point|0": [mv("r1.themes[2].share", "r1.themes[2].previous_share", "down")],
    "E04.0|point|1": [nw([ch(0), ch(1)])],
    "F02.0|point|0": [rk([th(0)], by="items")],
    "F02.0|point|1": [rs(["r1.themes[0].items", "r1.themes[1].items", "r1.themes[2].items"], "r1.totals.items", "rest")],
    "F04.0|lead|0": [rk([it(0, "r2")], o="last")],
    "F04.0|point|0": [rs(["r1.channels[0].items"], "r1.totals.items", "all")],
    "F05.0|lead|0": [rs(["r1.periods[0].items"], "r1.totals.items", "all")],
    "F05.0|point|1": [rs(["r1.totals.shorts"], "r1.totals.items", "all")],
    "F06.0|lead|0": [mv("r2.totals.items", "r2.previous.items", "up")],
    "F06.0|point|1": [rk([th(0)], by="items"), rs(["r1.channels[0].items"], "r1.themes[0].items", "all")],
    "F09.0|point|0": [ls(["r2.channels[0]"], "all")],
    "F10.0|lead|0": [rk([ar(0)], by="share")],
    "F10.0|point|0": [rk([th(0)], by="items")],
    "F10.0|point|1": [rk([th(1)], p=2, by="items")],
    "F11.0|lead|0": [rk(["r3.periods[9]"], by="items")],
    "F11.0|point|1": [],
    "F14.0|point|0": [rk([th(0, "r2")], by="items")],
    "F14.0|point|1": [],
    "F15.0|point|0": [rk([it(0)], o="last")],
    "F15.0|point|1": [rk([it(1)], o="list", p=2), rk([it(2)], o="list", p=3)],
    "I01.0|lead|0": [rk([ar(0)], by="share")],
    "I02.0|point|0": [rs(["r2.totals.by_platform.youtube"], "r2.totals.items", "all")],
    "I02.0|point|1": [rk([ch(0, "r2")], by="items")],
    "I03.0|point|0": [rs(["r1.themes[0].items"], "r1.channels[0].items", "all")],
    "K03.0|lead|0": [rk([th(0)], by="items")],
    "K03.0|point|1": [rk([ch(0, "r2")], by="items"), rk([ch(1, "r2")], p=2, by="items")],
    "K03.0|point|2": [nw(["r3.new.themes[1]"])],
}

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    out = {}
    for look, d in (("look1", L1), ("look2", L2)):
        for k, v in d.items():
            out[f"{look}|{k}"] = v
    p = os.path.join(here, "records_h.json")
    json.dump(out, open(p, "w"), indent=1, sort_keys=True)
    h = hashlib.sha256(open(p, "rb").read()).hexdigest()
    open(os.path.join(here, "records_h.sha256"), "w").write(f"{h}  records_h.json\n")
    print(len(out), "records;", h)
