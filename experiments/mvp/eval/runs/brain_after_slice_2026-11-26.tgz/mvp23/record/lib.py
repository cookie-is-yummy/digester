"""Shared loader for mvp23/record. Read only for the repo and for mvp22. No model call.
Loads a checker copy (mvp22/paper/src/verify_c1.py, or record/src/verify_d1b.py) as a module, builds a scratch library
under record/_lib, and rebuilds every input set: look 1 and look 2 forms (recorded tool results), the planted cases
(attack, attack_true, audit_true, and the builder's new/audit/insight_v5), and the skeptic's sentences (their
scenarios rebuilt on real tools here)."""
import glob
import importlib.util
import json
import os
import sys
from datetime import date

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
PAPER = os.path.join(S, "mvp22", "paper")
SKEP = os.path.join(S, "mvp22", "skeptic")
sys.path.insert(0, "/home/user/digester/experiments")
sys.path.append(PAPER)   # after this folder: paper/tally.py must never be imported (it writes files)
import mvp.brain  # noqa: E402,F401
from mvp.brain import planted as P  # noqa: E402
import taxonomy as T  # noqa: E402  (paper/taxonomy.py: data only)

LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
LAB = {(r["look"], r["key"], r["form_index"], r["where"], r["index"]): r
       for r in json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))}


def load_checker(path, name):
    spec = importlib.util.spec_from_file_location("mvp.brain." + name, path)
    m = importlib.util.module_from_spec(spec)
    m.__package__ = "mvp.brain"
    sys.modules["mvp.brain." + name] = m
    spec.loader.exec_module(m)
    return m


V1 = load_checker(os.path.join(PAPER, "src", "verify_c1.py"), "verify_c1")
CONFIGS = {"C0": (set(), "on"), "C1a": (T.off_set(False), "on"), "C1d": (T.off_set(True), "off")}


def setcfg(V, name):
    off, ins = CONFIGS[name]
    V.OFF.clear()
    V.OFF.update(off)
    V.INSIGHT = ins


_H = None


def harness():
    global _H
    if _H is None:
        base = os.path.join(HERE, "_lib")
        os.makedirs(base, exist_ok=True)
        from mvp import eval_brain as E
        _H = E.Harness.scratch(base=base)
    return _H


def heldout_inputs():
    h = harness()
    out = []
    for look, d in LOOKS.items():
        for p in sorted(glob.glob(os.path.join(d, "*.json"))):
            if p.endswith("summary.json"):
                continue
            rec = json.load(open(p))
            t = h.turn(rec["message"], screen=json.dumps(rec.get("screen") or {}, ensure_ascii=False, sort_keys=True))
            vt = V1.Turn.of(t)
            results = {c["rid"]: c["result"] for c in rec["calls"] if c.get("rid") and c.get("result")
                       and not c["result"].get("is_error")}
            out.append((look, rec, vt, results))
    return out


def planted_turn(V, case):
    t = case.get("turn") or {}
    today = date.fromisoformat(t["today"]) if t.get("today") else None
    return V.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today, names=list(t.get("names") or []),
                  sensitive_names=list(t.get("sensitive_names") or []))


PLANTED_SOURCES = ("attack", "attack_true", "audit_true", "new", "audit", "insight_v5")


def planted_data():
    return P.load()


def skeptic_inputs(V):
    """[(case tuple, form, target, results, vturn)] for the skeptic's 48 false + 20 true sentences."""
    sys.path.append(SKEP)
    import cases as K  # noqa: E402  (data: the skeptic's sentences)
    import scen as SC  # noqa: E402  (SCEN table; build() is not used: it writes under skeptic/_lib)
    from mvp.brain import tools as TL
    h = harness()
    built, out = {}, []
    for c in K.CASES + K.TRUE:
        cid, sk, where, truth, cls, sent = c[:6]
        if sk not in built:
            msg, calls, last = SC.SCEN[sk]
            lw = None
            if last:
                t0 = h.turn("what have i been into lately")
                TL.call(t0, "breakdown", {"by": "area", "window": SC.win(preset="lately"), "scope": SC.sc(),
                                          "compare": "none"})
                lw = t0.windows.get("r1")
            t = h.turn(msg, last_window=lw) if lw is not None else h.turn(msg)
            for tool, args in calls:
                TL.call(t, tool, args)
            built[sk] = (t.results, V.Turn.of(t))
        results, vt = built[sk]
        form = {"lead": sent} if where == "L" else {"lead": K.CARRIER[sk], "points": [sent]}
        tgt = ("lead", 0) if where == "L" else ("point", 0)
        out.append((c, form, tgt, results, vt))
    return out
