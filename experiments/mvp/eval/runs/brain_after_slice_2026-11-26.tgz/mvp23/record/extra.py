"""Run after report.py. Adds to table.txt: D2w per rule, true lost on the attack-true / audit-true / builder-true sets by
reason, the compact record check (defaults stripped, verdicts compared, tokens measured). Rewrites still_out.txt as one
list (each sentence once, marked by design), with report.py's per-design dump kept as an appendix."""
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import lib as L  # noqa: E402
import tally as T  # noqa: E402
import record as RC  # noqa: E402
import classmap as CM  # noqa: E402
import report as RP  # noqa: E402  (its main does not run on import)

D = RP.D
VD = RP.VD
lines = []
P = lines.append
WORDS = {"R": "record kind (rank, tie, list, the other N, new, most of, a move)", "P": "period, base or scope words",
         "T": "tool fault", "C": "cell or binding", "Y": "policy"}


def sent_ids(tab):
    """{id: (kept, reasons)} over every sentence of every set."""
    out = {}
    for r in tab["heldout"]:
        if r["form_index"] == 0:
            out[f"{r['set']}:{r['key']}:{r['where']}{r['index']}"] = (r["kept"], r["reasons"])
    for r in tab["planted"]:
        out[f"{r['set']}:{r['id']}"] = (r["kept"], r["reasons"])
    for r in tab["skeptic"]:
        out[f"skeptic:{r['id']}"] = (r["kept"], r["reasons"])
    return out


def truth_of(i):
    s, rest = i.split(":", 1)
    if s in ("look1", "look2"):
        key, wi = rest.split(":")
        m = re.match(r"(lead|point)(\d+)", wi)
        lab = L.LAB.get((s, key, 0, m.group(1), int(m.group(2))))
        return None if not lab else ("F" if lab["truth"] in T.BAD else "T" if lab["truth"] == "true" else None)
    if s == "skeptic":
        return RP.SK[rest][3]
    c = RP.CASES[rest]
    return "T" if c["expect"] == "kept" else "F"


# 1. D2w per rule, against D2 (same base, same bound)
P("")
P("D2w PER RULE (against D2 on the same base and bound; sentences D2 lets out that D2w refuses). IN SAMPLE: the")
P("period rule is today's verify._window_check switched back on (today's checker is in sample on both looks, the")
P("attack and the audit); the library rule is today's _library_window (written from look 2's I01.0); only the base")
P("rule is new, and its scope exemption was narrowed on look 1 after F05.0 p2 passed the first version.")
for base in ("d", "a"):
    for bound in ("H", "Mc"):
        a, b = sent_ids(D[f"D2_{bound}/{base}"]), sent_ids(D[f"D2w_{bound}/{base}"])
        c = defaultdict(Counter)
        names = defaultdict(list)
        for i, (ka, _ra) in a.items():
            kb, rb = b[i]
            if ka and not kb:
                t = truth_of(i)
                if t is None:
                    continue
                for rule in sorted({x for x in rb if x.startswith("d2w_")}):
                    grp = i.split(":")[0]
                    grp = "builder" if grp in ("new", "audit", "insight_v5") else grp
                    c[rule][f"{grp} {'false' if t == 'F' else 'TRUE'}"] += 1
                    if t == "T" or grp in ("look1", "look2"):
                        names[rule].append(("TRUE " if t == "T" else "false ") + i)
        P(f"  base {base}, {bound}{' (= Mc outside the looks)' if bound == 'H' else ''}:")
        for rule in ("d2w_period", "d2w_base", "d2w_library"):
            P(f"    {rule:12s} {dict(sorted(c[rule].items())) or '-'}")
            if base == "d" and bound == "H" and names[rule]:
                P(f"        named: {', '.join(names[rule])}")

# 2. true lost on the planted true sets by reason
P("")
P("TRUE LOST ON THE ATTACK-TRUE (60), AUDIT-TRUE (61) AND BUILDER-TRUE (78) SETS, BY REASON (a sentence may carry")
P("several; H rows = Mc on these sets)")
for k in RP.ORDER:
    t = D[k]
    out = []
    for grp, sets in (("attack_true", ("attack_true",)), ("audit_true", ("audit_true",)),
                      ("builder_true", ("new", "audit", "insight_v5"))):
        c = Counter()
        n = 0
        for r in t["planted"]:
            if r["set"] in sets and r["expect"] == "kept" and not r["kept"]:
                n += 1
                for x in set(r["reasons"]):
                    c["no_record" if x.startswith("no_record") else x.split(":")[0]] += 1
        out.append(f"{grp} {n}: " + ", ".join(f"{a} {b}" for a, b in c.most_common(5)))
    P(f"  {k:10s} " + " | ".join(out))

# 3. compact records
P("")
DEF = {"o": "most", "p": 1, "tie": False}


def compact(rec):
    r = {k: v for k, v in rec.items() if not (k in DEF and v == DEF[k])}
    if r.get("k") == "rest" and r.get("total") is None:
        r.pop("total", None)
    return r


same = diff = 0
chars = 0
nrec = 0
for key, recs in RP.H.items():
    look, k, w, i = key.split("|")
    cr = [compact(r) for r in recs]
    if look == "look1":
        chars += sum(len(json.dumps(r, separators=(",", ":"))) for r in cr)
        nrec += len(cr)
_inputs = {(lk, rec["key"]): results for lk, rec, _vt, results in L.heldout_inputs()}
for key, recs in RP.H.items():
    look, k, w, i = key.split("|")
    led = L.V1.Ledger(_inputs[(look, k)])
    rec = json.load(open(os.path.join(L.LOOKS[look], k + ".json")))
    form = rec["forms"][0]
    s = dict(((ww, kk), ss) for ww, kk, ss in [("lead", n, x) for n, x in enumerate(L.V1._split(form.get("lead") or ""))]
             + [("point", n, x) for n, x in enumerate(form.get("points") or [])])[(w, int(i))]
    a = RC.check_records(s, recs, led)
    b = RC.check_records(s, [compact(r) for r in recs], led)
    same += a == b
    diff += a != b
n_sent = sum(1 for kk in L.LAB if kk[0] == "look1" and kk[2] == 0)
n_withrec = sum(1 for kk, v in RP.H.items() if kk.startswith("look1|") and v)
P(f"COMPACT RECORDS (defaults o most, p 1, tie false, an empty total stripped): {same} of {same + diff} hand records")
P(f"give the same verdict as the full form. Look 1: {nrec} records, {chars} characters of JSON, plus about 8 characters")
P(f"of wrapping for each of the {n_withrec} sentences that carry one. Added output tokens, at 2.5 / 3.0 / 3.5 characters a")
P("token: per sentence (all " + str(n_sent) + " first-form sentences) " + " / ".join(
    f"{(chars + 8 * n_withrec) / c / n_sent:.1f}" for c in (2.5, 3.0, 3.5)) + "; per record " + " / ".join(
    f"{chars / nrec / c:.1f}" for c in (2.5, 3.0, 3.5)) + "; per form " + " / ".join(
    f"{(chars + 8 * n_withrec) / c / 53:.0f}" for c in (2.5, 3.0, 3.5)) + ".")
P("  Example: {\"k\":\"rank\",\"rows\":[\"r1.channels[1]\"],\"p\":2,\"by\":\"items\"}. The character-per-token rate is")
P("  assumed (the records' output tokens include thinking, so they cannot calibrate it).")
open(os.path.join(HERE, "table.txt"), "a").write("\n".join(lines) + "\n")
print("\n".join(lines))

# 4. one still-out list
HEAD = [("D2w_H/d", "D2w H d"), ("D2w_H/a", "D2w H a"), ("D2_H/d", "D2 H d"), ("D2_H/a", "D2 H a"),
        ("D1b/d", "D1b d"), ("D1b/a", "D1b a")]
items = {}
for k, lab in HEAD:
    t = D[k]
    for grp, lst in (("looks", RP.look_false(t, "look1") + RP.look_false(t, "look2")), ("attack", RP.attack_out(t)),
                     ("skeptic", RP.skeptic_out(t))):
        for cls, wid, text, why in lst:
            e = items.setdefault(wid, {"cls": cls, "text": text, "why": why, "grp": grp, "by": []})
            e["by"].append(lab)
order = {"looks": 0, "attack": 1, "skeptic": 2}
out = ["SENTENCES STILL OUT: one list, each false or wrongly based sentence once, marked by the designs that let it out.",
       "Headline: D2w with an honest record (H), base d. 'H' is the hand record on the two looks only; on the attack and",
       "the skeptic's set the H column shows the copy record (Mc), so read those marks as simulated, not hand-checked.",
       "Base d = the doubtful cell codes off; base a = on. The skeptic's set is complete (their progress file says",
       "DONE). Text with markers taken out.", ""]
for grp in ("looks", "attack", "skeptic"):
    sel = sorted(((w, e) for w, e in items.items() if e["grp"] == grp),
                 key=lambda x: (0 if "D2w H d" in x[1]["by"] else 1, x[1]["cls"], x[0]))
    out.append(f"== {grp}: {len(sel)} sentences")
    for wid, e in sel:
        out.append(f"  {wid}: \"{e['text']}\"")
        out.append(f"      class: {WORDS.get(e['cls'], e['cls'])}. Why false: {e['why']}")
        out.append(f"      out under: {', '.join(e['by'])}")
    out.append("")
old = open(os.path.join(HERE, "still_out.txt")).read()
open(os.path.join(HERE, "still_out.txt"), "w").write("\n".join(out) + "\nAPPENDIX: the per-design lists (all 16 "
                                                     "designs)\n\n" + old.split("\n", 2)[2])
print(len(items), "distinct sentences in the still-out list")
