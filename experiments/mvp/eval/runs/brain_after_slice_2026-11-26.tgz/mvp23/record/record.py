"""D2's record: a closed list of words that need a typed record, and code's exact check of a record against the rows.
WRITTEN FROM THE TASK'S LIST AND LOOK 1's FIRST FORMS ONLY; frozen (record.sha256) before any run on look 2, the attack,
the audit set or the skeptic's set. Code words nothing: it only refuses (a reason) or lets the sentence pass.

Record kinds (compact keys, as the model would write them; "k" is the kind):
  rank  {"k":"rank","rows":[row paths],"o":"most|least|first|last|list","p":place (default 1),"tie":bool,
         "by":"items|share|...|drop|gain"}         o first/last rank by date; o list = place in the list's own order
  list  {"k":"list","rows":[row paths],"c":"all|top|some"}
  rest  {"k":"rest","parts":[cell paths],"total":cell path,"says":"all|most|rest"}   all/rest: the parts sum to the
         total; most: the parts are more than half of the total
  new   {"k":"new","rows":[row paths]}              every row is a row of a 'new' list or a row marked new_in_window
  move  {"k":"move","now":cell,"before":cell,"dir":"up|down"}  or {"k":"move","change":cell,"dir":"up|down"}

Which words need which kind (WORDS below; a sentence may need several records):
  rank words (led, top, most, biggest, largest, main, highest, busiest, peak, favourite, fewest, least, smallest,
    lowest, bottom, came next, next, second, third, fourth, fifth, runner-up, ahead of, dominated) -> rank
  tie words (tied, tie, joint, level with) -> rank with tie true
  first/last words (first, last, latest, earliest, newest, oldest, most recent) -> rank (o first/last/list), unless the
    sentence cites a first_*/last_* cell (the word is that cell's own name)
  'top N', 'first N', 'top five' -> list (c top, N rows) or rank
  only, all, every, entire(ly), full, no other, none other -> list (c all) or rest (says all)
  the other, the rest, remaining, everything else, all but, except -> rest (says rest)
  most of, mostly, mainly, largely, majority -> rest (says most)
  new, newly, for the first time, first time -> new
  move words (fell, fall, dropped, drop, rose, rise, grew, slowed, gained, increased, decreased, climbed, jumped,
    declined, up from/by/N, down from/by/N) -> move (a rank word with a move word: rank by drop or gain)
Words inside the cited results' own window words, and generic time spans ('the last 7 days', 'all your history',
'last year'), are not read; 'only' next to a scope label of the cited result ('long videos only') is not read."""
import re

WORDS = [
    ("tie", r"\b(?:tied|ties|tie|joint|level with)\b"),
    ("topn", r"\b(?:top|first)\s+(?:\d+|two|three|four|five|six|seven|eight|nine|ten)\b"),
    ("rank", r"\b(?:led|leads|leading|leader|top|biggest|largest|main|highest|busiest|peak|favou?rite|topped|"
             r"number one|first place|came first|ahead of|dominat\w*|fewest|least|smallest|lowest|bottom|"
             r"came next|comes next|next|second|third|fourth|fifth|runner-up)\b"),
    ("most", r"\b(?:most of|mostly|mainly|largely|majority)\b"),
    ("rank", r"\b(?:the most|most)\b"),
    ("firstlast", r"\b(?:first|last|latest|earliest|newest|oldest|most recent)\b"),
    ("all", r"\b(?:only|all|every|entire|entirely|full|no other|none other)\b"),
    ("rest", r"\b(?:the other|the rest|remaining|everything else|all but|except)\b"),
    ("new", r"\b(?:new|newly|for the first time|first time)\b"),
    ("move", r"\b(?:fell|fall|falls|fallen|dropped(?! out)|drops(?! out)|drop(?! out)|rose|rise|rises|risen|grew|grow|grows|slowed|slows|"
             r"gained|gains|increased|increases|decreased|decreases|climbed|jumped|declined|declines)\b|"
             r"(?<!made )(?<!makes )(?<!make )\b(?:up|down)\s+(?:from|by|\d)"),
]
WORDS = [(k, re.compile(rx, re.I)) for k, rx in WORDS]
NEED = {"tie": {"rank"}, "topn": {"list", "rank"}, "rank": {"rank"}, "most": {"rest"}, "firstlast": {"rank"},
        "all": {"list", "rest"}, "rest": {"rest"}, "new": {"new"}, "move": {"move"}}
GENERIC_TIME = re.compile(
    r"\b(?:the\s+)?(?:last|past|first)\s+(?:\d+|two|three|four|five|six|seven)\s+(?:days?|weeks?|months?|years?)\b|"
    r"\b(?:last|this|next)\s+(?:year|month|week|day)\b|\b(?:in|over|across|of|from)?\s*all (?:of )?your history\b|"
    r"\bthe last day of your export\b|\bthe (?:\d+ )?weeks? before\b|\bthe (?:latest|last) day (?:I can show|of "
    r"your export|in your export)\b|\bin all\b(?! (?:your|the|of))", re.I)
ONLY_SCOPE = r"(?:youtube|instagram|long(?: videos?)?|shorts?|reels?)"
_NUMW = {"two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
DATE_KEYS = ("when", "first_watched", "last_watched", "date", "first", "last")


def _V():
    import lib
    return lib.V1


def plain_of(text, ledger):
    """The sentence with markers out and the cited results' window words blanked (they are code's or the tools')."""
    V = _V()
    raw = " ".join(str(text or "").split())
    mks, _b = V.parse(raw, ledger)
    plain = V.strip_markers(raw)
    for rid in sorted({mk.rid for mk in mks if mk.rid}):
        r = ledger.get(rid)
        if r is not None:
            plain = V._remove_phrases(plain, V._window_phrases(r))
    plain = GENERIC_TIME.sub(lambda m: " " * len(m.group(0)), plain)
    return raw, mks, plain


def needs(text, ledger):
    """[(word group, matched words, accepted kinds)] for one sentence."""
    V = _V()
    raw, mks, plain = plain_of(text, ledger)
    low = plain.lower()
    # scope labels next to 'only'
    labels = set()
    for rid in {mk.rid for mk in mks if mk.rid}:
        r = ledger.get(rid)
        for p in V.scope_parts(r):
            labels |= set(p.get("words") or [])
            if p.get("label"):
                labels.add(V._low(p["label"]))
    lab_rx = "|".join([ONLY_SCOPE] + [re.escape(x) for x in sorted(labels, key=len, reverse=True) if x])
    low = re.sub(r"\b(?:" + lab_rx + r")\s+only\b|\bonly\s+(?:" + lab_rx + r")\b",
                 lambda m: " " * len(m.group(0)), low)
    cites_first_last = any(mk.kind == "value" and re.search(r"(?:^|\.)(?:first|last)_\w+$", mk.rest or "")
                           for mk in mks)
    out, taken = [], []
    for g, rx in WORDS:
        hits = []
        for m in rx.finditer(low):
            if any(a < m.end() and m.start() < b for a, b in taken):
                continue
            if g == "firstlast" and cites_first_last and m.group(0).lower() in ("first", "last"):
                continue
            hits.append(m.group(0).lower())
            taken.append((m.start(), m.end()))
        if hits:
            out.append((g, hits, NEED[g]))
    return out


# ------------------------------------------------------------------ the row check
def _res_of(ledger, path):
    rid = path.split(".", 1)[0]
    return ledger.get(rid), path.split(".", 1)[1] if "." in path else ""


def _cell(ledger, path):
    V = _V()
    r, rest = _res_of(ledger, path)
    if r is None:
        raise KeyError(path)
    return V._resolve(r.sheet, rest)


def _num(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _list_of(ledger, row_path):
    V = _V()
    r, rest = _res_of(ledger, row_path)
    lst, i = V._list_and_index(rest)
    if r is None or lst is None:
        raise KeyError(row_path)
    rows = V._resolve(r.sheet, lst)
    if not isinstance(rows, list) or i >= len(rows):
        raise KeyError(row_path)
    return r, lst, i, rows


def _level(lst):
    return lst.split(".")[-1] if lst else ""


def _complete(r, lst, rows):
    """The list shown is every row of its kind: the result says complete, and its rows_of (when it gives that
    level) is the number of rows shown."""
    m = r.meta or {}
    if m.get("complete") is not True:
        return False
    ro = (m.get("rows_of") or {}).get(_level(lst))
    if "." in lst:   # a list inside a row or a period: its own length is all there is
        return True
    return ro is None or ro == len(rows)


def _vals(rows, by):
    if by in ("drop", "gain"):
        out = []
        for x in rows:
            if not (_num(x.get("items")) and _num(x.get("previous_items"))):
                return None
            d = x["items"] - x["previous_items"]
            out.append(-d if by == "drop" else d)
        return out
    vals = [x.get(by) for x in rows]
    if all(_num(v) for v in vals):
        return vals
    if all(isinstance(v, str) and re.match(r"\d{4}-\d\d-\d\d", v) for v in vals):
        return vals
    return None


def _when(s):
    """A sortable key of a date or 'YYYY-MM-DD h:mm am' string."""
    s = str(s or "")
    m = re.match(r"(\d{4}-\d\d-\d\d)(?:[ T](\d{1,2}):(\d\d)\s*([ap]m)?)?", s, re.I)
    if not m:
        return s
    h = int(m.group(2) or 0)
    if m.group(4):
        h = h % 12 + (12 if m.group(4).lower() == "pm" else 0)
    return f"{m.group(1)} {h:02d}:{int(m.group(3) or 0):02d}" if m.group(2) else m.group(1)


def check_rank(rec, ledger):
    rows = rec.get("rows") or []
    if not rows:
        return "bad_record"
    try:
        r, lst, i, lrows = _list_of(ledger, rows[0])
    except (KeyError, AttributeError, TypeError):
        return "bad_record"
    o = rec.get("o") or "most"
    p = int(rec.get("p") or 1)
    if o == "list":
        return None if i + 1 == p else "rank_place"
    by = rec.get("by")
    if o in ("first", "last"):
        by = by or next((k for k in DATE_KEYS if all(isinstance(x.get(k), str) for x in lrows)), None)
        if by is None:
            return "bad_record"
        order = (r.meta or {}).get("order")
        if (o == "last" and order == "newest" and i == 0 and p == 1) or \
                (o == "first" and order == "oldest" and i == 0 and p == 1):
            return None
        if not _complete(r, lst, lrows):
            return "rank_incomplete"
        vals = [_when(x.get(by)) for x in lrows]
        mine = vals[i]
        better = sum(1 for v in vals if (v < mine if o == "first" else v > mine))
        if better + 1 != p:
            return "rank_place"
        if vals.count(mine) > 1 and not rec.get("tie"):
            return "rank_tie"
        return None
    by = by or next((k for k in ("items", "share", "n", "times_opened") if _vals(lrows, k)), None)
    vals = _vals(lrows, by) if by else None
    if vals is None:
        return "bad_record"
    least_tool = o == "least" and (r.meta or {}).get("order") == "least" and (r.meta or {}).get("complete") is True \
        and "." not in lst
    if o == "least" and not least_tool and not _complete(r, lst, lrows):
        return "rank_incomplete"
    mine = vals[i]
    better = sum(1 for v in vals if (v < mine if o == "least" else v > mine))
    if better + 1 != p:
        return "rank_place"
    if p > 1 and o == "most" and not _complete(r, lst, lrows) and i >= len(lrows):
        return "rank_incomplete"
    ties = vals.count(mine) > 1
    if ties and not rec.get("tie"):
        return "rank_tie"
    if rec.get("tie") and not ties:
        return "rank_no_tie"
    return None


def check_list(rec, ledger, n_said=None):
    rows = rec.get("rows") or []
    c = rec.get("c") or "some"
    if not rows:
        return "bad_record"
    try:
        lists = [_list_of(ledger, x) for x in rows]
    except (KeyError, AttributeError, TypeError):
        return "bad_record"
    r, lst, _i, lrows = lists[0]
    if any((x[0].rid, x[1]) != (r.rid, lst) for x in lists):
        return "list_mixed"
    ix = sorted({x[2] for x in lists})
    if c == "all":
        if ix != list(range(len(lrows))) or not _complete(r, lst, lrows):
            return "list_incomplete"
        return None
    if c == "top":
        k = len(ix)
        if n_said is not None and n_said != k:
            return "list_top_n"
        if ix != list(range(k)):
            return "list_not_top"
        by = next((b for b in ("items", "share", "n", "times_opened") if _vals(lrows, b)), None)
        vals = _vals(lrows, by) if by else None
        if vals and k < len(vals) and vals[k - 1] == vals[k]:
            return "list_tie_at_cut"
        if vals and k == len(vals) and not _complete(r, lst, lrows):
            ro = ((r.meta or {}).get("rows_of") or {}).get(_level(lst))
            if ro is None or ro > k:
                return None   # the top k of a longer list cut at k: nothing below is shown, nothing to tie with
        return None
    return None


def check_rest(rec, ledger):
    says = rec.get("says") or "rest"
    try:
        parts = [_cell(ledger, x) for x in rec.get("parts") or []]
        if not rec.get("total") and says == "all" and parts and all(
                re.search(r"(?:^|_)share$", x.rsplit(".", 1)[-1]) for x in rec["parts"]):
            # 'all of them Shorts' backed by share cells: every part is 100%
            return None if all(_num(v) and v >= 0.995 for v in parts) else "rest_sum"
        total = _cell(ledger, rec.get("total"))
    except (KeyError, AttributeError, TypeError, IndexError):
        return "bad_record"
    if not parts or not all(_num(x) for x in parts) or not _num(total):
        return "bad_record"
    s = sum(parts)
    says = rec.get("says") or "rest"
    if says == "most":
        return None if s * 2 > total else "rest_not_most"
    return None if abs(s - total) < 1e-9 else "rest_sum"


def check_new(rec, ledger):
    rows = rec.get("rows") or []
    if not rows:
        return "bad_record"
    for x in rows:
        try:
            row = _cell(ledger, x)
        except (KeyError, AttributeError, TypeError, IndexError):
            return "bad_record"
        if not isinstance(row, dict):
            return "bad_record"
        if not (re.search(r"(?:^|\.)new\.", x) or row.get("new_in_window") is True or row.get("status") == "new"):
            return "new_list"
    return None


def check_move(rec, ledger):
    d = rec.get("dir")
    try:
        if rec.get("change"):
            ch = _cell(ledger, rec["change"])
            if not _num(ch):
                return "bad_record"
            delta = ch
        else:
            now, before = _cell(ledger, rec.get("now")), _cell(ledger, rec.get("before"))
            if not (_num(now) and _num(before)):
                return "bad_record"
            delta = now - before
    except (KeyError, AttributeError, TypeError, IndexError):
        return "bad_record"
    if d == "up" and not delta > 0:
        return "move_dir"
    if d == "down" and not delta < 0:
        return "move_dir"
    return None


CHECK = {"rank": check_rank, "list": check_list, "rest": check_rest, "new": check_new, "move": check_move}


def check_records(text, records, ledger):
    """[] when every listed word has a record of an accepted kind that the rows back; else the reasons."""
    nd = needs(text, ledger)
    recs = list(records or [])
    out = []
    n_said = None
    _raw, _mks, plain = plain_of(text, ledger)
    m = re.search(r"\b(?:top|first)\s+(\d+|two|three|four|five|six|seven|eight|nine|ten)\b", plain, re.I)
    if m:
        n_said = int(m.group(1)) if m.group(1).isdigit() else _NUMW[m.group(1).lower()]
    verdicts = []
    for rec in recs:
        k = rec.get("k")
        f = CHECK.get(k)
        if f is None:
            verdicts.append((k, "bad_record"))
            continue
        try:
            why = f(rec, ledger, n_said) if k == "list" else f(rec, ledger)
        except Exception as e:  # noqa: BLE001
            why = "record_error:" + type(e).__name__
        verdicts.append((k, why))
    for k, why in verdicts:
        if why:
            out.append(f"{k}:{why}")
    for g, hits, kinds in nd:
        ok = [k for k, why in verdicts if k in kinds]
        if not ok:
            out.append(f"no_record:{g}")
        elif g == "tie" and not any(rec.get("k") == "rank" and rec.get("tie") for rec in recs):
            out.append("no_record:tie")
        elif g == "all" and not any((rec.get("k") == "list" and rec.get("c") == "all") or
                                    (rec.get("k") == "rest" and (rec.get("says") or "rest") in ("all", "rest"))
                                    for rec in recs):
            out.append("no_record:all")
        elif g == "most" and not any(rec.get("k") == "rest" and rec.get("says") == "most" for rec in recs):
            out.append("no_record:most")
    return out


# ------------------------------------------------------------------ the M copy bound: records filled from the rows
_NEXT = {"next": 2, "came next": 2, "comes next": 2, "second": 2, "runner-up": 2, "third": 3, "fourth": 4, "fifth": 5}
_LEASTW = ("fewest", "least", "smallest", "lowest", "bottom")


def copy_records(text, ledger, answer_cells=()):
    """The records a model would write if it only copied the rows it cites: the word sets the kind and the order,
    the cited rows are the rows, place 1 (2 for 'next' or 'second'), no tie unless a tie word, complete 'all' for
    only/all/every; the other parts are the answer's other count cells. Where two records could back a word ('all':
    list or rest), each is tried and the sentence passes if either does (the copy bound's most lenient reading)."""
    V = _V()
    raw, mks, plain = plain_of(text, ledger)
    low = plain.lower()
    nd = needs(text, ledger)
    rowmk = []
    for mk in mks:
        own = mk.owner if mk.kind in ("row", "value") else None
        if own and re.search(r"\[\d+\]$", own) and f"{mk.rid}.{own}" not in rowmk:
            rowmk.append(f"{mk.rid}.{own}")
    cells = [mk for mk in mks if mk.kind == "value" and _num(mk.value)]

    class _C:   # a row's own count cell, for a row cited with no number
        def __init__(self, rid, owner, key, value):
            self.rid, self.owner, self.key, self.value = rid, owner, key, value
            self.rest, self.path, self.kind = f"{owner}.{key}", f"{rid}.{owner}.{key}", "value"
    for mk in mks:
        if mk.kind == "row" and isinstance(mk.value, dict) and _num(mk.value.get("items")) and \
                not any(c.owner == mk.owner and c.rid == mk.rid for c in cells):
            cells.append(_C(mk.rid, mk.owner, "items", mk.value["items"]))
    opts = []   # list of alternative record lists
    base = []
    for g, hits, kinds in nd:
        alts = []
        if g in ("rank", "tie", "firstlast") or (g == "topn" and "rank" in kinds and not rowmk[1:]):
            if rowmk:
                o = "least" if any(h in _LEASTW for h in hits) else "most"
                if g == "firstlast":
                    o = "last" if any(h in ("last", "latest", "newest", "most recent") for h in hits) else "first"
                    if re.search(r"\bfirst on the list|\bon the list\b", low):
                        o = "list"
                p = max([_NEXT.get(h, 1) for h in hits] + [1])
                by = None
                if re.search(r"\b(?:biggest|largest|most|least|smallest|top|main)\W+(?:\w+\W+){0,2}?(?:drop\w*|fell|fall\w*|"
                             r"slow\w*|declin\w*|decreas\w*|gain\w*|grew|grow\w*|rise\w*|rose|jump\w*|increas\w*)\b|"
                             r"\b(?:drop\w*|fell|fall\w*|slow\w*|declin\w*|decreas\w*|gain\w*|grew|grow\w*|rise\w*|rose|"
                             r"jump\w*|increas\w*)\W+(?:\w+\W+){0,1}?(?:the )?most\b", low):
                    by = "drop" if re.search(r"\b(?:drop\w*|fell|fall\w*|slow\w*|declin\w*|decreas\w*|down)\b", low) \
                        else "gain"
                else:
                    vk = next((mk.key for mk in cells if mk.owner and f"{mk.rid}.{mk.owner}" == rowmk[0]), None)
                    by = vk if vk in ("items", "share", "n", "times_opened") else None
                rec = {"k": "rank", "rows": [rowmk[0]], "o": o, "p": p, "tie": g == "tie"}
                if by:
                    rec["by"] = by
                alts.append([rec])
        if g == "topn" and rowmk:
            alts.append([{"k": "list", "rows": rowmk, "c": "top"}])
        if g == "all":
            groups = {}
            for x in rowmk:
                groups.setdefault(re.sub(r"\[\d+\]$", "", x), []).append(x)
            for grp in groups.values():
                alts.append([{"k": "list", "rows": grp, "c": "all"}])
            shares = [mk.path for mk in mks if mk.kind == "value" and re.search(r"(?:^|_)share$", mk.key or "")]
            if shares:
                alts.append([{"k": "rest", "parts": shares, "says": "all"}])
            for mk in cells:
                r = ledger.get(mk.rid)
                tot = ((r.sheet or {}).get("totals") or {}).get("items") if r else None
                if _num(tot) and not mk.rest.endswith("totals.items"):
                    alts.append([{"k": "rest", "parts": [mk.path], "total": f"{mk.rid}.totals.items", "says": "all"}])
                if mk.owner:   # 'all N of X were from Y': a row's count against its parent row's count
                    for mk2 in cells:
                        if mk2 is not mk:
                            alts.append([{"k": "rest", "parts": [mk.path], "total": mk2.path, "says": "all"}])
        if g == "most":
            for mk in cells:
                r = ledger.get(mk.rid)
                if r is not None and _num(((r.sheet or {}).get("totals") or {}).get("items")) and \
                        not mk.rest.endswith("totals.items"):
                    alts.append([{"k": "rest", "parts": [mk.path], "total": f"{mk.rid}.totals.items", "says": "most"}])
                for mk2 in cells:
                    if mk2 is not mk:
                        alts.append([{"k": "rest", "parts": [mk.path], "total": mk2.path, "says": "most"}])
        if g == "rest":
            for mk in cells:
                tot = f"{mk.rid}.totals.items"
                others = [c for c in answer_cells if c != mk.path and c.split(".", 1)[0] == mk.rid]
                for o2 in others or [None]:
                    alts.append([{"k": "rest", "parts": [mk.path] + ([o2] if o2 else []), "total": tot,
                                  "says": "rest"}])
        if g == "new" and rowmk:
            alts.append([{"k": "new", "rows": rowmk}])
        if g == "move":
            d = "down" if re.search(r"\b(?:drop\w*|fell|fall\w*|slow\w*|declin\w*|decreas\w*|down)\b", low) else "up"
            chg = [mk for mk in cells if re.search(r"change", mk.key or "")]
            for mk in chg:
                alts.append([{"k": "move", "change": mk.path, "dir": d}])
            for mk in cells:
                if (mk.key or "").startswith("previous_"):
                    now = mk.path.replace(".previous_", ".")
                    alts.append([{"k": "move", "now": now, "before": mk.path, "dir": d}])
            pc = [mk for mk in cells if re.search(r"periods\[\d+\]\.items$", mk.rest or "")]
            for a in pc:
                for b in pc:
                    if a is not b:
                        alts.append([{"k": "move", "now": a.path, "before": b.path, "dir": d}])
        opts.append(alts or [[]])
    # every combination of one alternative per word group (small)
    combos = [base]
    for alts in opts:
        combos = [c + a for c in combos for a in alts][:64]
    return combos


def copy_check(text, ledger, answer_cells=()):
    """[] if some copied record set passes; else the reasons of the first."""
    combos = copy_records(text, ledger, answer_cells)
    first = None
    for recs in combos:
        why = check_records(text, recs, ledger)
        if not why:
            return [], recs
        first = first or why
    return first or [], None
