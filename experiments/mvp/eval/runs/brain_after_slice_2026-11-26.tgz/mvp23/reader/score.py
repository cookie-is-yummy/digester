"""Score reader runs against units.json (rules in scoring_rules.txt). No model call.
    python3 score.py RUN [RUN2]          prints the tallies per set; with RUN2, agreement too
"""
import collections
import json
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import classes as CL  # noqa: E402


def all_units():
    u = json.load(open(os.path.join(HERE, "units.json")))
    if os.path.exists(os.path.join(HERE, "units_skeptic.json")):
        u += json.load(open(os.path.join(HERE, "units_skeptic.json")))
    return u


def load_run(name):
    out = {}
    for x in open(os.path.join(HERE, "runs", name + ".jsonl")):
        if x.strip():
            r = json.loads(x)
            if r.get("ok") or r["uid"] not in out:
                out[r["uid"]] = r
    return out


def verdicts(run):
    v = {}
    for r in run.values():
        for s in r.get("sentences") or []:
            v[s["sid"]] = s
    return v


def rows(units, run):
    vs = verdicts(run)
    out = []
    for u in units:
        if u["uid"] not in run:
            continue
        for s in u["sentences"]:
            e = vs.get(s["sid"]) or {"verdict": "missing"}
            out.append(dict(s, set=u["set"], split=u["split"], uid=u["uid"], kind=u["kind"],
                            flag=e["verdict"] == "problem", rclass=e.get("class"), reason=e.get("reason"),
                            missing=e["verdict"] == "missing", cls=CL.klass(u, s)))
    return out


def tally(rs, label=""):
    t = [r for r in rs if r["target"]]
    F = [r for r in t if r["label"] == "false"]
    Tr = [r for r in t if r["label"] == "true"]
    Fth = [r for r in F if r["cells_c1a"]]
    Tth = [r for r in Tr if r["cells_c1a"]]
    lines = []
    lines.append(f"{label}: false {len(F)} (cells-only lets {len(Fth)} through); true {len(Tr)} (cells-only keeps "
                 f"{len(Tth)})")
    caught = [r for r in Fth if r["flag"]]
    lines.append(f"  reader flags {len(caught)} of {len(Fth)} false let through")
    bycls = collections.defaultdict(lambda: [0, 0])
    for r in Fth:
        bycls[r["cls"]][1] += 1
        bycls[r["cls"]][0] += r["flag"]
    lines.append("    by class: " + ", ".join(f"{k} {a}/{b}" for k, (a, b) in sorted(bycls.items())))
    fa = [r for r in Tth if r["flag"]]
    strict = [r for r in fa if str(r.get("borderline") or "").startswith("strict")]
    lines.append(f"  reader flags {len(fa)} of {len(Tth)} true kept (of them {len(strict)} borderline 'strict:')")
    lines.append("    by reader class: " + ", ".join(f"{k} {n}" for k, n in
                                                   sorted(collections.Counter(r["rclass"] for r in fa).items())))
    # all false incl. those cells drops
    lines.append(f"  (on all false, cells or not: reader flags {sum(r['flag'] for r in F)} of {len(F)}; on all true "
                 f"{sum(r['flag'] for r in Tr)} of {len(Tr)})")
    fo = len(Fth) - len(caught)
    tl = (len(Tr) - len(Tth)) + len(fa)
    lines.append(f"  combined cells+reader: false out {fo}/{len(F)}; true lost {tl}/{len(Tr)} "
                 f"(cells {len(Tr) - len(Tth)} + reader {len(fa)}); cells only: false out {len(Fth)}/{len(F)}, "
                 f"true lost {len(Tr) - len(Tth)}/{len(Tr)}")
    Fd = [r for r in F if r.get("cells_c1d")]
    Td = [r for r in Tr if r.get("cells_c1d") is not None]
    if Fd or Td:
        lines.append(f"  C1d base: false through {len(Fd)}, reader flags {sum(r['flag'] for r in Fd)}; "
                     f"true kept {sum(1 for r in Td if r['cells_c1d'])}, reader flags "
                     f"{sum(1 for r in Td if r['cells_c1d'] and r['flag'])}")
    car = [r for r in rs if not r["target"] and r["kind"] == "planted"]
    if car:
        lines.append(f"  carrier sentences (not scored): {sum(r['flag'] for r in car)} of {len(car)} flagged")
    miss = sum(r["missing"] for r in rs)
    if miss:
        lines.append(f"  sentences with no verdict: {miss}")
    return lines


def agreement(r1, r2):
    a = {r["sid"]: r for r in r1 if r["target"]}
    b = {r["sid"]: r for r in r2 if r["target"]}
    common = [k for k in a if k in b]
    same = sum(1 for k in common if a[k]["flag"] == b[k]["flag"])
    th = [k for k in common if a[k]["cells_c1a"]]
    same_th = sum(1 for k in th if a[k]["flag"] == b[k]["flag"])
    fth = [k for k in th if a[k]["label"] == "false"]
    tth = [k for k in th if a[k]["label"] == "true"]
    return (f"  agreement run1/run2: {same}/{len(common)} scored sentences; {same_th}/{len(th)} of those cells-only "
            f"lets through (false {sum(1 for k in fth if a[k]['flag'] == b[k]['flag'])}/{len(fth)}, true "
            f"{sum(1 for k in tth if a[k]['flag'] == b[k]['flag'])}/{len(tth)})")


def calls(run_names, units):
    kind = {u["uid"]: u["kind"] for u in units}
    rs = [json.loads(x) for x in open(os.path.join(HERE, "calls.jsonl")) if x.strip()]
    rs = [r for r in rs if r["run"] in run_names]
    out = []
    for k in ("look", "planted"):
        c = [r for r in rs if kind.get(r["uid"]) == k]
        if not c:
            continue
        sec = sorted(r["seconds"] for r in c)
        p90 = sec[int(0.9 * (len(sec) - 1))]
        out.append(f"  {k} calls {len(c)}: seconds median {st.median(sec):.2f}, p90 {p90:.2f}, max {sec[-1]:.2f}; "
                   f"cost per call ${st.mean(r['cost_usd'] for r in c):.5f}; input tokens median "
                   f"{st.median(r['usage']['input_tokens'] for r in c):.0f}, output median "
                   f"{st.median(r['usage']['output_tokens'] for r in c):.0f} (max "
                   f"{max(r['usage']['output_tokens'] for r in c)}); sdk retries {sum(r['retries'] > 0 for r in c)}; "
                   f"repeat attempts {sum(r['attempt'] > 0 for r in c)}")
    return out


if __name__ == "__main__":
    units = all_units()
    names = sys.argv[1:]
    runs = [load_run(n) for n in names]
    rr = [rows(units, r) for r in runs]
    sets = sorted({(r["split"], r["set"]) for r in rr[0]})
    for sp, se in sets:
        for i, n in enumerate(names):
            for line in tally([r for r in rr[i] if r["set"] == se and r["split"] == sp], f"{sp} {se} [{n}]"):
                print(line)
        if len(rr) > 1:
            print(agreement([r for r in rr[0] if r["set"] == se], [r for r in rr[1] if r["set"] == se]))
    for i, n in enumerate(names):
        print(n)
        for line in calls({n}, units):
            print(line)
