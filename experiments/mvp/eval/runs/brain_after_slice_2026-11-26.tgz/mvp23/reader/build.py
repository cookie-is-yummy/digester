"""Build the reader's labelled units from files only. No model call. Writes units.json.

A unit is one reader request: the person's message and screen (loop.user_text), the turn's tool results as the
answering model saw them (loop.present, in call order), and every sentence of the FIRST form, numbered.
Each sentence carries: label (false | true | none), cls (our class, filled after the freeze for test sets),
cells_c1a / cells_c1d (True = cells-only keeps it; C1a is D1, C1d the range), and its ids.

Sets: dev = look 1 first forms + even-numbered attack cases (false and true);
      test = look 2 first forms + odd attack + audit true (+ skeptic, added by build_skeptic.py if complete).
    python3 build.py
"""
import importlib.util
import json
import os
import re
import sys
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
PAPER = os.path.join(S, "mvp22", "paper")
sys.path.insert(0, "/home/user/digester/experiments")
sys.path.insert(0, PAPER)
import taxonomy as T  # noqa: E402
import mvp.brain  # noqa: E402,F401
from mvp.brain import loop as BL  # noqa: E402
from mvp.brain import planted as P  # noqa: E402

spec = importlib.util.spec_from_file_location("mvp.brain.verify_c1", os.path.join(PAPER, "src", "verify_c1.py"))
V = importlib.util.module_from_spec(spec)
V.__package__ = "mvp.brain"
sys.modules["mvp.brain.verify_c1"] = V
spec.loader.exec_module(V)

LOOKS = {"look1": os.path.join(S, "mvp20/tune/heldout"), "look2": os.path.join(S, "mvp20/fix/heldout_run")}
CFG = {"C1a": (T.off_set(False), "on"), "C1d": (T.off_set(True), "off")}


def setcfg(name):
    off, ins = CFG[name]
    V.OFF.clear()
    V.OFF.update(off)
    V.INSIGHT = ins


def present(env):
    env = {k: v for k, v in env.items() if k not in ("cost_usd", "took_ms")}
    return BL.present(env)


def num(i):
    return int(re.search(r"(\d+)(_[LP])?$", i).group(1))


def heldout_units():
    sim = json.load(open(os.path.join(PAPER, "sim.json")))
    outc = json.load(open(os.path.join(PAPER, "outcomes.json")))["heldout"]
    sents = json.load(open(os.path.join(S, "mvp22/raw/sentences.json")))
    k = lambda r: (r["set"] if "set" in r else r["look"], r["key"], r["form_index"], r["where"], r["index"])  # noqa
    c1a = {k(r): r for r in sim["C1a"]["heldout"]}
    c1d = {k(r): r for r in sim["C1d"]["heldout"]}
    lab = {k(r): r for r in sents}
    units = []
    for look, d in LOOKS.items():
        for p in sorted(os.listdir(d)):
            if not p.endswith(".json") or p == "summary.json":
                continue
            rec = json.load(open(os.path.join(d, p)))
            if not rec.get("forms"):
                continue
            rows = [o for o in outc if o["set"] == look and o["key"] == rec["key"] and o["form_index"] == 0
                    and o["where"] in ("lead", "point")]
            ss = []
            for o in rows:
                kk = (look, rec["key"], 0, o["where"], o["index"])
                lb = lab.get(kk)
                truth = lb["truth"] if lb else None
                label = {"true": "true", "wrongly_based": "false", "false": "false"}.get(truth, "none")
                ss.append({"sid": f"{look}:{rec['key']}:{o['where']}{o['index']}", "where": o["where"],
                           "index": o["index"], "text": o["text"], "label": label, "truth": truth,
                           "borderline": lb.get("borderline") if lb else None,
                           "fault": lb.get("fault") if lb else None,
                           "cells_c1a": c1a[kk]["kept"], "cells_c1d": c1d[kk]["kept"],
                           "c1a_reasons": c1a[kk]["reasons"], "target": label != "none"})
            results = [present(c["result"]) for c in rec["calls"] if c.get("result")]
            units.append({"uid": f"{look}:{rec['key']}", "set": look, "split": "dev" if look == "look1" else "test",
                          "kind": "look", "user": BL.user_text(rec["message"], rec.get("screen") or {}),
                          "results": results, "sentences": ss})
    return units


def planted_units():
    data = P.load()
    led = data["ledgers"]
    units = []
    for c in data["cases"]:
        src = c.get("source")
        if src not in ("attack", "attack_true", "audit_true"):
            continue
        t = c.get("turn") or {}
        today = date.fromisoformat(t["today"]) if t.get("today") else None
        turn = V.Turn(message=t.get("message", ""), unlock=t.get("unlock"), today=today,
                      names=list(t.get("names") or []), sensitive_names=list(t.get("sensitive_names") or []))
        tgt = c.get("target") or "point:0"
        kind, _, n = tgt.partition(":")
        forms = c.get("forms") or [c["form"]]
        per = []
        for f in forms:
            res = {}
            for cfg in CFG:
                setcfg(cfg)
                v = V.check_answer(f, V.Ledger(led[c["ledger"]]), turn)
                if kind == "lead":
                    os_ = [o for o in v.outcomes if o.where == "lead"]
                    kept = bool(os_) and all(o.kept for o in os_)
                else:
                    o = next((o for o in v.outcomes if o.where == kind and o.index == int(n or 0)), None)
                    kept = bool(o and o.kept)
                if c["expect"] == "private_line":
                    kept = kept and not v.private_line
                res[cfg] = (kept, v)
            per.append((f, res))
        # the carrier shown: the first under which C1a keeps the target (what cells-only lets out), else the first
        pick = next((x for x in per if x[1]["C1a"][0]), per[0])
        f, res = pick
        v = res["C1a"][1]
        ss = []
        for o in v.outcomes:
            if o.where not in ("lead", "point") or not (o.text or "").strip():
                continue
            is_t = (o.where == kind and (kind == "lead" or o.index == int(n or 0)))
            label = ("false" if src == "attack" else "true") if is_t else "none"
            ss.append({"sid": f"{c['id']}:{o.where}{o.index}", "where": o.where, "index": o.index, "text": o.text,
                       "label": label, "truth": None, "borderline": None,
                       "fault": c.get("class") if is_t else None,
                       "cells_c1a": res["C1a"][0] if is_t else o.kept,
                       "cells_c1d": res["C1d"][0] if is_t else None,
                       "c1a_reasons": list(o.reasons), "target": is_t})
        if src == "audit_true":
            split = "test"
        else:
            split = "dev" if num(c["id"]) % 2 == 0 else "test"
        setname = {"attack": "attack", "attack_true": "attack", "audit_true": "audit"}[src]
        units.append({"uid": c["id"], "set": setname, "split": split, "kind": "planted",
                      "user": BL.user_text(t.get("message", ""), {"now": t.get("today")}),
                      "results": [present(e) for e in led[c["ledger"]]], "sentences": ss,
                      "n_carriers": len(forms), "attack_class": c.get("class")})
    return units


if __name__ == "__main__":
    units = heldout_units() + planted_units()
    json.dump(units, open(os.path.join(HERE, "units.json"), "w"), indent=0, ensure_ascii=False)
    import collections
    cnt = collections.Counter()
    for u in units:
        for s in u["sentences"]:
            if s["target"]:
                cnt[(u["split"], u["set"], s["label"], "c1a_kept" if s["cells_c1a"] else "c1a_drop")] += 1
    for k in sorted(cnt):
        print(k, cnt[k])
    print("units", collections.Counter((u["split"], u["set"]) for u in units))
