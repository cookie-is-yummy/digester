"""DIAGNOSTIC made after seeing test results (not a pre-registered test): the 48 audit units that have no lead get a
no-claim lead naming the first result's window in meta's words ("In <window_said>, here is what you asked about."),
as a real answer's lead would. Same frozen prompt and setting. Writes units_audit_lead.json. No model call."""
import json, os
HERE = os.path.dirname(os.path.abspath(__file__))
out = []
for u in json.load(open(os.path.join(HERE, "units.json"))):
    if u["set"] != "audit" or any(s["where"] == "lead" for s in u["sentences"]):
        continue
    w = json.loads(u["results"][0]).get("meta", {}).get("window_said") or "this window"
    lead = {"sid": "auditlead_" + u["uid"] + ":lead0", "where": "lead", "index": 0,
            "text": f"In {w}, here is what you asked about.", "label": "none", "truth": None, "borderline": None,
            "fault": None, "cells_c1a": True, "cells_c1d": None, "c1a_reasons": [], "target": False}
    v = dict(u, uid="auditlead_" + u["uid"], set="audit_lead",
             sentences=[lead] + [dict(s, sid="auditlead_" + s["sid"]) for s in u["sentences"]])
    out.append(v)
json.dump(out, open(os.path.join(HERE, "units_audit_lead.json"), "w"), indent=0, ensure_ascii=False)
print(len(out), out[0]["sentences"][0]["text"])
