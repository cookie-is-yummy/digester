"""The second small-model READER: one request per answer; it returns, per numbered sentence, ok or a problem with a
class and a short reason. It words nothing in the answer. Calls go through the repo's own route
(mvp.brain.provider.AnthropicProvider -> mvp.llm.ai: the key by name, the Claude cap, ai.log_batch to the ledger with
purpose "brain_reader_eval"). Only made-up data is sent.

    python3 reader.py RUN_NAME SETTING SPLIT[,SPLIT] [SET,...] [--limit N] [--uids a,b] [--units FILE]
SETTING: off (thinking disabled, the tool forced) | adaptive (adaptive thinking, effort low, tool_choice auto with a
strict tool and an instruction to call it; a forced call skips thinking on Haiku 5.5).
Writes runs/RUN_NAME.jsonl (one row per unit) and appends every request to calls.jsonl (cost, seconds, tokens).
"""
import argparse
import hashlib
import json
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, "/home/user/digester/experiments")
os.environ.setdefault("MVP_CLAUDE_CAP_USD", "25")
os.environ.setdefault("MVP_LEDGER_HOME", "/home/user/digester/data/mvp")

from mvp.brain import provider as PV  # noqa: E402

PROMPT_FILE = os.path.join(HERE, "reader_prompt_v2.md")
PROMPT_VERSION = "reader_v2"
PURPOSE = "brain_reader_eval"
TOOL_NAME = "report_sentences"
CLASSES = ["none", "period", "base", "scope", "rank_or_tie", "list_completeness", "only_or_all", "direction", "other"]
TOOL = {
    "name": TOOL_NAME,
    "description": "Your verdict on every numbered sentence of the answer: ok, or a problem with its class and a "
                   "short reason.",
    "input_schema": {
        "type": "object", "additionalProperties": False, "required": ["sentences"],
        "properties": {"sentences": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["n", "verdict", "class", "reason"],
            "properties": {"n": {"type": "integer"}, "verdict": {"type": "string", "enum": ["ok", "problem"]},
                           "class": {"type": "string", "enum": CLASSES}, "reason": {"type": "string"}}}}}},
}
MAX_TOKENS = 4000
SPEND_CAP = 3.00
LOCK = threading.Lock()


def system_text():
    return open(PROMPT_FILE, encoding="utf-8").read()


def layout(unit):
    """The user message: message and screen, the results as the answering model saw them, the numbered sentences."""
    parts = ["<person>", unit["user"], "</person>", "<results>"]
    for r in unit["results"]:
        parts += ["<result>", r, "</result>"]
    parts.append("</results>")
    parts.append("<answer>")
    for i, s in enumerate(unit["sentences"], 1):
        parts.append(f"{i}. ({'first sentence' if s['where'] == 'lead' and s['index'] == 0 else s['where']}) "
                     f"{s['text']}")
    parts.append("</answer>")
    parts.append(f"Check each of the {len(unit['sentences'])} sentences and call {TOOL_NAME} once.")
    return "\n".join(parts)


class ReaderProvider(PV.AnthropicProvider):
    """The repo's provider with tool_choice set per setting (the provider itself always sends auto)."""

    def __init__(self, setting, **kw):
        self.setting = setting
        super().__init__(thinking="disabled" if setting == "off" else "adaptive", effort="low",
                         max_tokens=MAX_TOKENS, prompt_version=PROMPT_VERSION + "+" + setting, purpose=PURPOSE,
                         strict=True, loose=(), cache=False, timeout=90.0, **kw)

    def body(self, system, tools, messages, max_tokens=None):
        b = super().body(system, tools, messages, max_tokens)
        if self.setting == "off":
            b["tool_choice"] = {"type": "tool", "name": TOOL_NAME}
        return b


def spent():
    p = os.path.join(HERE, "calls.jsonl")
    if not os.path.exists(p):
        return 0.0
    return sum(json.loads(x).get("cost_usd") or 0 for x in open(p) if x.strip())


def parse(reply):
    uses = [b for b in reply.blocks if b.get("type") == "tool_use" and b.get("name") == TOOL_NAME]
    if not uses:
        return None
    inp = uses[0].get("input") or {}
    ss = inp.get("sentences")
    if isinstance(ss, str):   # a reply that put the list in a string: parsed once, never guessed
        try:
            ss = json.loads(ss)
        except ValueError:
            return None
    if not isinstance(ss, list) or not all(isinstance(e, dict) and "n" in e and "verdict" in e for e in ss):
        return None
    return {"sentences": ss}


def read_unit(prov, unit, run):
    if spent() >= SPEND_CAP - 0.05:
        return {"uid": unit["uid"], "error": "spend cap"}
    msgs = [{"role": "user", "content": layout(unit)}]
    attempts = []
    out = None
    for attempt in range(2):
        t0 = time.time()
        try:
            r = prov.send(system_text(), [TOOL], msgs)
        except PV.ProviderError as e:
            attempts.append({"error": e.kind, "seconds": round(time.time() - t0, 2)})
            continue
        thinking = sum(1 for b in r.blocks if b.get("type") in ("thinking", "redacted_thinking"))
        row = {"run": run, "uid": unit["uid"], "attempt": attempt, "seconds": r.seconds, "cost_usd": r.cost_usd,
               "usage": r.usage, "stop": r.stop_reason, "retries": r.retries, "thinking_blocks": thinking,
               "setting": prov.setting}
        with LOCK:
            with open(os.path.join(HERE, "calls.jsonl"), "a") as f:
                f.write(json.dumps(row) + "\n")
        got = parse(r)
        attempts.append(dict(row, parsed=got is not None))
        if got is not None and r.stop_reason != "max_tokens":
            out = got
            break
    verdicts = {}
    if out:
        for e in out.get("sentences") or []:
            verdicts[int(e.get("n", 0))] = e
    sents = []
    for i, s in enumerate(unit["sentences"], 1):
        e = verdicts.get(i)
        sents.append({"sid": s["sid"], "n": i, "verdict": e["verdict"] if e else "missing",
                      "class": e["class"] if e else None, "reason": e["reason"] if e else None})
    return {"uid": unit["uid"], "run": run, "attempts": attempts, "ok": out is not None, "sentences": sents}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("setting", choices=["off", "adaptive"])
    ap.add_argument("splits")
    ap.add_argument("sets", nargs="?", default="")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--uids", default="")
    ap.add_argument("--units", default=os.path.join(HERE, "units.json"))
    ap.add_argument("--parallel", type=int, default=4)
    a = ap.parse_args(argv)
    units = json.load(open(a.units))
    sp = set(a.splits.split(","))
    units = [u for u in units if u["split"] in sp]
    if a.sets:
        units = [u for u in units if u["set"] in set(a.sets.split(","))]
    if a.uids:
        want = set(a.uids.split(","))
        units = [u for u in units if u["uid"] in want]
    if a.limit:
        units = units[:a.limit]
    os.makedirs(os.path.join(HERE, "runs"), exist_ok=True)
    outp = os.path.join(HERE, "runs", a.run + ".jsonl")
    done = set()
    if os.path.exists(outp):
        done = {json.loads(x)["uid"] for x in open(outp) if x.strip() and json.loads(x).get("ok")}
    units = [u for u in units if u["uid"] not in done]
    prov = ReaderProvider(a.setting)
    print(f"{a.run}: {len(units)} units, setting {a.setting}, spent before ${spent():.4f}", flush=True)
    t0 = time.time()
    with ThreadPoolExecutor(max_workers=a.parallel) as ex:
        for res in ex.map(lambda u: read_unit(prov, u, a.run), units):
            with LOCK:
                with open(outp, "a") as f:
                    f.write(json.dumps(res, ensure_ascii=False) + "\n")
    print(f"{a.run}: done in {time.time() - t0:.1f} s; requests {prov.requests}; this run ${prov.spent:.4f}; "
          f"total ${spent():.4f}", flush=True)


if __name__ == "__main__":
    main()
