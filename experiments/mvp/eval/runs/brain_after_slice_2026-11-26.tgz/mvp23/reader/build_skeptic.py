"""The skeptic's 48 false and 20 true sentences (S/mvp22/skeptic, complete per its progress file) as reader units,
built after the freeze with the frozen layout (same unit shape as build.py). No model call. Writes units_skeptic.json.
Cells-only marks: the skeptic's M_C1a / M_C1d rows ran C5 M (cells base + frame.py); cells-only keeps the target
when its "cells" reasons are empty (frame.py's reasons are ignored)."""
import importlib.util
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
S = os.path.dirname(os.path.dirname(HERE))
SK = os.path.join(S, "mvp22", "skeptic")
sys.path.insert(0, "/home/user/digester/experiments")
from mvp.brain import loop as BL  # noqa: E402

spec = importlib.util.spec_from_file_location("skeptic_cases", os.path.join(SK, "cases.py"))
K = importlib.util.module_from_spec(spec)
spec.loader.exec_module(K)

rows = json.load(open(os.path.join(SK, "cases_final.json")))["rows"]
scen = json.load(open(os.path.join(SK, "scen_results.json")))
NOW = {"now": "Sun 22 Nov 2026 12:00, America/New_York"}
units = []
for r in rows:
    sc = scen[r["scen"]]
    res = [BL.present(sc["results"][k]) for k in sorted(sc["results"], key=lambda x: int(x[1:]))]
    label = "false" if r["truth"] == "F" else "true"
    keep_a = not r["M_C1a"]["cells"]
    keep_d = not r["M_C1d"]["cells"]
    tgt = {"label": label, "truth": r["truth"], "borderline": None, "fault": r["recount"], "cells_c1a": keep_a,
           "cells_c1d": keep_d, "c1a_reasons": r["M_C1a"]["cells"], "target": True}
    if r["where"] == "L":
        ss = [dict(tgt, sid=f"skeptic_{r['id']}:lead0", where="lead", index=0, text=r["sentence"])]
    else:
        ss = [{"sid": f"skeptic_{r['id']}:lead0", "where": "lead", "index": 0, "text": K.CARRIER[r["scen"]],
               "label": "none", "truth": None, "borderline": None, "fault": None, "cells_c1a": True,
               "cells_c1d": None, "c1a_reasons": [], "target": False},
              dict(tgt, sid=f"skeptic_{r['id']}:point0", where="point", index=0, text=r["sentence"])]
    units.append({"uid": "skeptic_" + r["id"], "set": "skeptic", "split": "test", "kind": "planted",
                  "user": BL.user_text(sc["message"], NOW), "results": res, "sentences": ss,
                  "attack_class": r["class"], "firmness": r.get("firmness")})
json.dump(units, open(os.path.join(HERE, "units_skeptic.json"), "w"), indent=0, ensure_ascii=False)
import collections  # noqa: E402
print(len(units), collections.Counter((s["label"], s["cells_c1a"]) for u in units for s in u["sentences"]
                                      if s["target"]))
