"""Our class for each false sentence (the reader's eight classes), for the by-class tallies. Attack: by the case's
class prefix. Held-out: by hand from the recount's fault text. Written for dev first; the test entries (look 2 and
attack prefixes seen only in odd cases) are added after the prompt freeze, marked below."""

ATTACK = {
    # dev prefixes (even cases)
    "of_videos_frame": "base", "platform": "scope", "change_period": "period", "period_label": "period",
    "lead_window": "period", "move_frame": "period", "pct": "direction", "hour": "only_or_all",
    "fell_into": "rank_or_tie", "outside_theme": "other", "base_verbs": "base", "waiver": "scope",
    "scope_words": "scope", "cut_count": "list_completeness", "number_word": "other", "share_sum": "other",
    "dates": "rank_or_tie", "private": "only_or_all", "bare_clause": "other", "motive": "other", "title": "other",
    "outside": "other", "two_results": "period", "calc_rows": "other", "least": "rank_or_tie",
    "from_to": "direction", "compare_frame": "direction", "find": "base", "measure": "base",
    # added AFTER the freeze: prefixes seen only in odd attack cases
    "owner": "other",
    # added AFTER the freeze: the skeptic's classes
    "mostly": "other", "rank_verb": "rank_or_tie", "persist": "period", "new_list": "list_completeness",
    "free": "other", "time_open": "period", "coverage": "only_or_all", "direction": "direction",
    "rank_next": "rank_or_tie", "level": "rank_or_tie", "follow_up": "scope", "lead_no_comma": "period",
    "lead_opening": "period", "list_trunc": "list_completeness", "all_pred": "only_or_all",
    "list_some": "list_completeness", "anaphora": "other", "small_move": "direction", "size_word": "other",
    "base_word": "base", "median_base": "base", "inner_share": "base", "weekday": "scope",
    "weekday_rank": "rank_or_tie", "ratio_word": "other", "series": "list_completeness",
    "private_series": "only_or_all",
}

HELD = {
    # look 1 (dev), from the recount's fault text
    "look1:A06.0:point1": "rank_or_tie", "look1:B05.0:point0": "rank_or_tie", "look1:D03.2:point1": "rank_or_tie",
    "look1:F05.0:point2": "base", "look1:F11.0:point0": "list_completeness", "look1:I02.0:lead0": "other",
    "look1:I02.0:point0": "rank_or_tie", "look1:K03.0:point1": "list_completeness",
    # look 2 (test), added AFTER the freeze
    "look2:B05.0:point0": "rank_or_tie", "look2:B14.0:point0": "list_completeness",
    "look2:B14.0:point1": "only_or_all", "look2:F05.0:lead0": "period", "look2:F11.0:point0": "base",
    "look2:F15.0:point0": "scope", "look2:I01.0:point1": "period", "look2:I02.0:lead0": "other",
    "look2:K03.0:point2": "list_completeness",
}


def klass(unit, s):
    if s["label"] != "false":
        return None
    if unit["kind"] == "planted":
        pre = str(unit.get("attack_class") or "").split(":")[0]
        return ATTACK.get(pre, "unmapped:" + pre)
    return HELD.get(s["sid"], "unmapped")
