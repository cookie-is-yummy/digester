# fix progress (branch brain-slice-local, from da5530e = tip of brain-tune-local)

- 26 Nov: branch made in worktree wf_5a7a19f0-942-5. Read brief, tune_progress, interfaces, both checkers' findings.
- Commit trailer: the harness attribution lines (as the tuner: the brief's names another model; the brief is script output).
- Copied the attack harness to fix/attack (common.WT -> this worktree) and tune's live.sh, replay.py, audit_true.py,
  recount.py to fix/ (paths -> this worktree).
- Baselines (fix/m_base): planted 332/332, 78/78; audit true 49/61; attack (my replay, fix/attack) 166 false of
  which 72 kept, 60 true of which 42 kept (the attack's own report says 164/61: its counting; mine replays cases.py);
  offline replay run5 78/113 first, 95 sent (code 3); held-out 76/137 first, 93 sent (model 26, repair 10, code 17).
  The recount's 5 false sentences reproduce in the held-out replay (B03.0 C04.0 F05.0 F11.0 I02.0).
- 7dc2cc0 fix 0: attack cases in the planted set, scored apart (source attack / attack_true).
- 661abcd fix 1: the false classes by rule + code-lead recheck and template words. planted 332/332, 78/78; attack
  165/166 false dropped (R03 kept with the private line) and 41/60 true; audit 49/61. Replay run5 78 first / 95 sent
  (unchanged); held-out 71 first / 87 sent (the 5 false and F09.0 true dropped). 26 of the 27 new tests fail on da5530e.
- bee4b4e fix 2: prompt brain_v3 + two loosenings. The tree of both live runs.
- Live tune (fix/tune_run, $0.0571, 91 requests): G2 94.6/97.3, G3 92.1, G4 23.4/13.5, G5 6.40/10.06, G6 0.150 c;
  my recount of all 38: 0 false, 1 borderline (C13.0).
- Live held-out SECOND LOOK (fix/heldout_run, $0.0796, 133 requests): G2 73.1/84.6, G3 79.2 (33+9 of 53), G4
  36.7/28.1, G5 7.40/10.68, G6 0.150 c; my recount: 2 false (E04.0 back-reference point under a code lead, I02.0
  "I found no dating advice ..." lead); auditor 24 findings, 0 true. Spend total $0.137.
- Suite on bee4b4e: 5923 passed, 2 skipped. bb7a825 fix 3 (post-run, offline): back-reference points, self-talk
  limits. Suite on bb7a825: 5927 passed, 2 skipped (4 shards). Demo 10/10. Dry self-test 164/164 steps, $0.
- count_tokens (v3): prefix 13,045 (tools 6,592, system 6,464), round-2 request 16,395, one result 3,291.
- DESIGN 22 and README written.
- Closer reading (advisor): row recount of composition claims (fix/myrecount.py): I01.0 "3 saved Home cooking posts
  were not opened in 2024" is wrongly based (saves made 2026) -> G1 second look >= 3. 25a50b1 fix 5 (library cell said
  with a window). Suite on 25a50b1: 5928 passed, 2 skipped. Demo 10/10, dry self-test 164/164 at $0.
- 6f2e090 fix 6: docs corrected. Audit true drop ids identical to da5530e; attack true drops: t19 added.
- G2 moved messages: C06.0, F06.0 newly differ; K03.0 to other_plan.
