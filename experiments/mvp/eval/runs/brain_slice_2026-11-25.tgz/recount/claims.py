"""Hand recount of every SENT sentence of the 53 held-out answers, from the rows only (lib.py).

Each claim: (key, sentence, [(what, said, recounted)], verdict override or None, note).
A number check passes when said == recounted (counts) or said == round(recounted %) (shares, points).
Verdict FALSE when a check fails or when the override says so (rank across levels, wrong base, incomplete list).

Rules fixed before reading the answers closely:
- base: a share or rank said 'of what you opened' / 'led what you opened' must hold on the whole opened base of the
  window UNLESS a scope phrase governs that share or rank clause itself (a lead-in such as 'without gaming, ...',
  'Without Minecraft builds, ...', 'On Sundays, ...', or the base noun of the share: 'of your 72 long videos').
  A scope word that only qualifies a count ('with 30 long videos') or a noun elsewhere ('largest gaming theme')
  does not save the share or rank clause.
- rank words must hold at the level the sentence compares (theme vs theme, area vs area).
- a list said as complete ('your full years before 2026 were ...') must be complete.
- rounding: a share or a move in points is right when it equals the recount rounded half up to a whole number.
- the private topic (Dating advice / Heart Notes, theme key 'da') is out of every base unless the turn unlocked it
  (I02.0); a led/top claim on a base without it is held true when the private line is printed (SPEC 8.4 remedy).
"""
import glob
import json
from lib import D, by, ev, pct

H = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/tune/heldout/"


def n(*a, **k):
    return len(ev(*a, **k))


def c(win, field, name, **k):
    return dict(by(ev(win, **k), field)).get(name, 0)


def s(win, field, name, **k):
    t = n(win, **k)
    return round(100 * c(win, field, name, **k) / t + 1e-9) if t else None


def rank(win, field, i, **k):
    r = by(ev(win, **k), field)
    return r[i][0] if len(r) > i else None


NG = dict(exclude=[("area", "gaming")])
NMC = dict(exclude=[("theme", "Minecraft builds")])
G = dict(only=[("area", "gaming")])
oct30 = sorted(ev("oct30"), key=lambda e: e["dt"])
first_wc = sorted(ev("all", only=[("theme", "Watercolor painting")]), key=lambda e: e["dt"])[0]
last_sr = sorted(ev("all", only=[("theme", "Speedruns")]), key=lambda e: e["dt"])[-1]
years = {y: n((D(y, 1, 1), D(y, 12, 31))) for y in range(2021, 2026)}
pts = lambda a, b: round(a - b + 1e-9)  # noqa: E731

C = [
    ("A01.0", "gaming led what you opened, at 49% of your videos (4 weeks to 30 Oct)",
     [("top area", "gaming", rank("lately", "area", 0)), ("share", 49, s("lately", "area", "gaming"))], None, ""),
    ("A01.0", "Gaming clips had 59 videos, 56 of them from Clip Factory.",
     [("Gaming clips", 59, c("lately", "theme", "Gaming clips")), ("Clip Factory", 56, c("lately", "channel", "Clip Factory"))], None, ""),
    ("A01.1", "Gaming clips led what you opened, with 59 of 130 videos.",
     [("top theme", "Gaming clips", rank("lately", "theme", 0)), ("n", 59, c("lately", "theme", "Gaming clips")), ("base", 130, n("lately"))], None, ""),
    ("A01.1", "Digital drawing fell to 21% of what you opened, from 57%.",
     [("now", 21, s("lately", "theme", "Digital drawing")), ("before (4 weeks before, unsaid)", 57, s("prev4", "theme", "Digital drawing"))], None,
     "true; the earlier period is not named in the sentence"),
    ("A01.3", "In October 2026, Clip Factory led what you opened, with 61 of 142 videos.",
     [("top", "Clip Factory", rank("oct", "channel", 0)), ("n", 61, c("oct", "channel", "Clip Factory")), ("base", 142, n("oct"))], None, ""),
    ("A01.3", "Pan Theory came next with 32 videos, and Pixel Pencil had 29.",
     [("2nd", "Pan Theory", rank("oct", "channel", 1)), ("PT", 32, c("oct", "channel", "Pan Theory")), ("PP", 29, c("oct", "channel", "Pixel Pencil"))], None,
     "the auditor's finding (recount 142) is a false flag: a row count, not the total"),
    ("A01.4", "In October 2026 up to 30 October, without gaming, Pan Theory led with 32 of 70 videos you opened.",
     [("top", "Pan Theory", rank("oct", "channel", 0, **NG)), ("n", 32, c("oct", "channel", "Pan Theory", **NG)), ("base", 70, n("oct", **NG))], None, ""),
    ("A01.4", "Pixel Pencil came next with 29 videos.",
     [("2nd", "Pixel Pencil", rank("oct", "channel", 1, **NG)), ("n", 29, c("oct", "channel", "Pixel Pencil", **NG))], None, "auditor false flag"),
    ("A01.5", "..., without gaming and without shorts, Pan Theory led with 32 of your 66 long videos.",
     [("top", "Pan Theory", rank("oct", "channel", 0, length="long", **NG)), ("base", 66, n("oct", length="long", **NG))], None, "nit: 'shorts' lower case"),
    ("A01.5", "Among your long videos, Pixel Pencil came next with 29.",
     [("2nd", "Pixel Pencil", rank("oct", "channel", 1, length="long", **NG)), ("n", 29, c("oct", "channel", "Pixel Pencil", length="long", **NG))], None, ""),
    ("A01.5", "Among your long videos, Limit Lane had 4.",
     [("n", 4, c("oct", "channel", "Limit Lane", length="long", **NG))], None, ""),
    ("A03.0", "gaming nearly doubled to 49% of what you opened, from 27% in the 4 weeks before (5 September to 2 October 2026); art and design came next (25%).",
     [("now", 49, s("lately", "area", "gaming")), ("before", 27, s("prev4", "area", "gaming")),
      ("ratio (nearly doubled)", "~2", round(c("lately", "area", "gaming") / n("lately") / (c("prev4", "area", "gaming") / n("prev4")), 2)),
      ("2nd area", "art and design", rank("lately", "area", 1)), ("art", 25, s("lately", "area", "art and design"))], None, "1.79x read as 'nearly doubled': held"),
    ("A03.0", "Home cooking came next at 23% of what you opened, up from 4% before.",
     [("2nd theme", "Home cooking", rank("lately", "theme", 1)), ("now", 23, s("lately", "theme", "Home cooking")), ("before", 4, s("prev4", "theme", "Home cooking"))], None,
     "'came next' follows an AREA (art and design 25%); at theme level Home cooking is 2nd: held, cross-level wording"),
    ("A03.0", "Digital drawing fell to 21% of what you opened, down 36 points on the 4 weeks before.",
     [("now", 21, s("lately", "theme", "Digital drawing")),
      ("points", 36, pts(100 * 29 / 51, 100 * 27 / 130))], None, ""),
    ("A05.0", "Clip Factory led what you opened, with 61 of your 142 videos.",
     [("n", 61, c("oct", "channel", "Clip Factory")), ("base", 142, n("oct"))], None, ""),
    ("A05.0", "Pan Theory came next with 32 videos.", [("2nd", "Pan Theory", rank("oct", "channel", 1)), ("n", 32, c("oct", "channel", "Pan Theory"))], None, "auditor false flag"),
    ("A05.0", "Pixel Pencil was third with 29 videos.", [("3rd", "Pixel Pencil", rank("oct", "channel", 2)), ("n", 29, c("oct", "channel", "Pixel Pencil"))], None, "auditor false flag"),
    ("A06.0", "without gaming, Pan Theory led with 32 of your 70 videos opened.",
     [("n", 32, c("oct", "channel", "Pan Theory", **NG)), ("base", 70, n("oct", **NG))], None, ""),
    ("A06.0", "Pixel Pencil came next with 29 videos.", [("2nd", "Pixel Pencil", rank("oct", "channel", 1, **NG))], None, "auditor false flag"),
    ("A07.0", "without shorts, Pan Theory led with 32 of your 72 long videos.",
     [("top", "Pan Theory", rank("oct", "channel", 0, length="long")), ("base", 72, n("oct", length="long"))], None, ""),
    ("A07.0", "Pan Theory was 44% of your long videos you opened.", [("share", 44, s("oct", "channel", "Pan Theory", length="long"))], None, "repeats the lead"),
    ("B01.0", "gaming led what you opened, with 49% of what you opened, 64 of 130 videos.",
     [("share", 49, s("lately", "area", "gaming")), ("n", 64, c("lately", "area", "gaming")), ("base", 130, n("lately"))], None, ""),
    ("B01.0", "Gaming clips alone made 59 videos, 56 of them from Clip Factory.",
     [("n", 59, c("lately", "theme", "Gaming clips")), ("CF", 56, c("lately", "channel", "Clip Factory"))], None, "auditor false flag"),
    ("B02.0", "without gaming, art and design led with 48% of what you opened.",
     [("top", "art and design", rank("lately", "area", 0, **NG)), ("share of the rest", 48, s("lately", "area", "art and design", **NG)),
      ("share of all (if read so)", "-", s("lately", "area", "art and design"))], None,
     "scope said in the sentence: held; food and cooking is 45% (close second) and unsaid"),
    ("B02.0", "Math had 4 videos.", [("n", 4, c("lately", "area", "math", **NG))], None, ""),
    ("B03.0", "Home cooking led what you opened, with 30 long videos.",
     [("top long theme", "Home cooking", rank("lately", "theme", 0, length="long")), ("n", 30, c("lately", "theme", "Home cooking", length="long")),
      ("top theme of ALL opened", "-", rank("lately", "theme", 0)), ("Gaming clips, all opened", "-", c("lately", "theme", "Gaming clips"))], "FALSE",
     "wrongly based: 'led what you opened' is a rank on all opened, where Gaming clips led with 59 and Home cooking was 2nd with 30; "
     "'long' governs only the count. Home cooking leads only the long videos (code template lead)"),
    ("B03.0", "Art and design came next with 28 long videos.",
     [("2nd long area", "art and design", rank("lately", "area", 1, length="long")), ("n", 28, c("lately", "area", "art and design", length="long"))], None,
     "auditor false flag; cross-level (theme led, area came next) but true at area level (food and cooking 30 > art 28)"),
    ("B05.0", "In the 4 weeks up to 30 October 2026, no channel stopped, so the stopped list is empty.",
     [("channels in prev4 missing from lately", "none", sorted({e['channel'] for e in ev('prev4')} - {e['channel'] for e in ev('lately')}) or "none")], None, ""),
    ("B07.0", "In all your history, you first opened a watercolor video on 10 January 2025.",
     [("first", "2025-01-10", str(first_wc["day"]))], None, ""),
    ("B11.0", "In the last 7 days up to 30 October 2026, Clip Factory led what you opened, with 13 of 24 videos.",
     [("top", "Clip Factory", rank("last7", "channel", 0)), ("n", 13, c("last7", "channel", "Clip Factory")), ("base", 24, n("last7"))], None, ""),
    ("B11.0", "Pixel Pencil came next with 6 videos.", [("2nd", "Pixel Pencil", rank("last7", "channel", 1)), ("n", 6, c("last7", "channel", "Pixel Pencil"))], None, "auditor false flag"),
    ("B11.0", "Pan Theory had 5 videos.", [("n", 5, c("last7", "channel", "Pan Theory"))], None, ""),
    ("B14.0", "66 of the 723 videos you opened were Shorts, a share of 9% of your YouTube videos.",
     [("Shorts", 66, n("all", length="short", platform="youtube")), ("base", 723, n("all")),
      ("of YouTube", 9, round(100 * 66 / n("all", platform="youtube"))), ("of all", "-", round(100 * 66 / 723))], None,
     "two bases in one sentence (723 includes 4 Instagram reels; 9% is of 719 YouTube); both round to 9%: held"),
    ("B14.0", "651 were long videos, and Minecraft builds was the largest long theme at 163 videos.",
     [("long", 651, n("all", length="long")), ("top long theme", "Minecraft builds", rank("all", "theme", 0, length="long")),
      ("n", 163, c("all", "theme", "Minecraft builds", length="long"))], None, "auditor false flag (163 vs 723)"),
    ("C01.0", "In October 2026, Wet Paper was the channel you opened least, with 1 video of 142 you opened.",
     [("least", "Wet Paper", by(ev("oct"), "channel")[-1][0]), ("n", 1, c("oct", "channel", "Wet Paper")), ("base", 142, n("oct"))], None, "auditor false flag"),
    ("C01.0", "Limit Lane had 4 videos, and Gaming Daily had 5.",
     [("LL", 4, c("oct", "channel", "Limit Lane")), ("GD", 5, c("oct", "channel", "Gaming Daily"))], None, ""),
    ("C02.0", "without Minecraft builds, gaming led what you opened, with 47% of your 125 videos.",
     [("top", "gaming", rank("lately", "area", 0, **NMC)), ("share", 47, s("lately", "area", "gaming", **NMC)), ("base", 125, n("lately", **NMC))], None, ""),
    ("C02.0", "Without Minecraft builds, art and design fell to 26% of what you opened, down 40 points on the 4 weeks before.",
     [("now", 26, s("lately", "area", "art and design", **NMC)), ("before", "-", s("prev4", "area", "art and design", **NMC)),
      ("points", 40, pts(100 * 29 / 44, 100 * 32 / 125))], None, "auditor's two findings are false flags: it counted the unfiltered base"),
    ("C02.0", "Without Minecraft builds, food and cooking reached 24% of what you opened, up 19 points.",
     [("now", 24, s("lately", "area", "food and cooking", **NMC)), ("points", 19, pts(100 * 30 / 125, 100 * 2 / 44))], None, "19.45 points"),
    ("C04.0", "On Sundays, over all your history (...), Minecraft builds led what you opened, with 23 videos (on Sundays).",
     [("top Sunday theme", "Minecraft builds", rank("all", "theme", 0, weekday=6)), ("n", 23, c("all", "theme", "Minecraft builds", weekday=6))], None, ""),
    ("C04.0", "On Sundays, Minecraft builds was the top theme, with 23 videos, all from Brick Realm.",
     [("n", 23, c("all", "theme", "Minecraft builds", weekday=6)), ("channels", "Brick Realm only", by(ev("all", weekday=6, only=[("theme", "Minecraft builds")]), "channel"))], None, "repeats the lead"),
    ("C04.0", "art and design came next at 25% of what you opened on Sundays.",
     [("art share", 25, s("all", "area", "art and design", weekday=6)),
      ("leader said: Minecraft builds share", "-", s("all", "theme", "Minecraft builds", weekday=6)),
      ("next theme after Minecraft builds", "-", rank("all", "theme", 1, weekday=6)),
      ("top area (what art follows)", "-", rank("all", "area", 0, weekday=6))], "FALSE",
     "rank across levels: 'came next' after Minecraft builds (23 of 101 = 23%) for an area at 25%, larger than the leader; "
     "art and design is 2nd behind gaming (45 of 101 = 45%), which is never said"),
    ("C06.0", "art and design led what you opened, with 133 of your 254 videos, 52%.",
     [("top", "art and design", rank("ytd", "area", 0)), ("n", 133, c("ytd", "area", "art and design")), ("base", 254, n("ytd")), ("share", 52, s("ytd", "area", "art and design"))], None, ""),
    ("C06.0", "Gaming came second with 79 videos, 31% of what you opened.",
     [("2nd", "gaming", rank("ytd", "area", 1)), ("n", 79, c("ytd", "area", "gaming")), ("share", 31, s("ytd", "area", "gaming"))], None, "auditor false flag"),
    ("C06.0", "Digital drawing was the top theme with 92 videos, and Gaming clips had 66.",
     [("top", "Digital drawing", rank("ytd", "theme", 0)), ("DD", 92, c("ytd", "theme", "Digital drawing")), ("GC", 66, c("ytd", "theme", "Gaming clips"))], None, "auditor false flag"),
    ("C08.0", "The last speedrun video you opened was Speedrun glitch explained, on 1 May 2023.",
     [("title", "Speedrun glitch explained", last_sr["title"]), ("day", "2023-05-01", str(last_sr["day"]))], None, "title without its '#90'"),
    ("C09.0", "In all your history (...), you opened 723 videos.", [("n", 723, n("all"))], None, "private line printed"),
    ("C09.0", "Cooking soup on the 30th was opened 1 time.",
     [("times", 1, sum(1 for e in ev("all") if e["title"] == "Cooking soup on the 30th"))], None, "true but answers nothing"),
    ("D01.0", "Clip Factory led what you opened, with 61 of 142 videos.", [("n", 61, c("oct", "channel", "Clip Factory")), ("base", 142, n("oct"))], None, ""),
    ("D01.0", "Pan Theory came next with 32 videos, and Pixel Pencil had 29.", [("PT", 32, c("oct", "channel", "Pan Theory")), ("PP", 29, c("oct", "channel", "Pixel Pencil"))], None, "auditor false flag"),
    ("D01.1", "In September 2026, Pixel Pencil led what you opened, with 31 of 44 videos.",
     [("top", "Pixel Pencil", rank("sep", "channel", 0)), ("n", 31, c("sep", "channel", "Pixel Pencil")), ("base", 44, n("sep"))], None, ""),
    ("D01.1", "Brick Realm came next with 7 videos.", [("2nd", "Brick Realm", rank("sep", "channel", 1)), ("n", 7, c("sep", "channel", "Brick Realm"))], None, "auditor false flag"),
    ("D01.1", "Art and design was 70% of what you opened.", [("share", 70, s("sep", "area", "art and design"))], None, "70.45%"),
    ("D03.0", "Clip Factory led what you opened, with 61 of 142 videos.", [("n", 61, c("oct", "channel", "Clip Factory"))], None, ""),
    ("D03.0", "Pan Theory came next with 32 videos, then Pixel Pencil with 29.", [("PT", 32, c("oct", "channel", "Pan Theory")), ("3rd", "Pixel Pencil", rank("oct", "channel", 2))], None, "auditor false flag"),
    ("D03.0", "Brick Realm had 6 and Gaming Daily had 5.", [("BR", 6, c("oct", "channel", "Brick Realm")), ("GD", 5, c("oct", "channel", "Gaming Daily"))], None, ""),
    ("D03.1", "In October 2026 up to 30 October 2026, where your export ends, you opened 142 videos.", [("n", 142, n("oct"))], None, ""),
    ("D03.1", "Cooking soup on the 30th was opened on 30 October 2026.", [("day", "2026-10-30", str([e["day"] for e in oct30 if e["title"].startswith("Cooking soup")][0]))], None, "21:00 New York (01:00 UTC on the 31st)"),
    ("D03.1", "Digital art colour on the 30th was opened on 30 October 2026.", [("day", "2026-10-30", str([e["day"] for e in oct30 if e["title"].startswith("Digital art colour")][0]))], None, ""),
    ("D03.2", "In October 2026 up to 30 October, these are the gaming videos you opened, out of 72 items.", [("n", 72, n("oct", **G))], None, "'these' with one item shown"),
    ("D03.2", "Gaming clip on the 30th was opened on 30 October 2026.", [("day", "2026-10-30", str([e["day"] for e in oct30 if e["title"].startswith("Gaming clip")][0]))], None, ""),
    ("D04.0", "In 2022, gaming was 93% of what you opened, with 100 of 108 videos.",
     [("share", 93, s("2022", "area", "gaming")), ("n", 100, c("2022", "area", "gaming")), ("base", 108, n("2022"))], None, ""),
    ("D04.0", "Minecraft builds led with 59 videos, from Brick Realm.", [("top", "Minecraft builds", rank("2022", "theme", 0)), ("n", 59, c("2022", "theme", "Minecraft builds"))], None, ""),
    ("D04.0", "Speedruns came next with 41 videos, from Frame Perfect.", [("2nd", "Speedruns", rank("2022", "theme", 1)), ("n", 41, c("2022", "theme", "Speedruns"))], None, "auditor false flag"),
    ("D04.0", "Home cooking had 8 videos, from Pan Theory.", [("n", 8, c("2022", "theme", "Home cooking"))], None, ""),
    ("D04.1", "In 2022, here is what I counted (Instagram only).", [("Instagram in 2022", "nothing said", n("2022", platform="instagram"))], None, "no claim; says nothing (0 Instagram rows in 2022)"),
    ("D07.0", "On Friday 30 October 2026, the last day of your export, 4 videos; Digital drawing led with 2 of them.",
     [("n", 4, len(oct30)), ("top", "Digital drawing", rank("oct30", "theme", 0)), ("DD", 2, c("oct30", "theme", "Digital drawing")), ("weekday", "Friday", D(2026, 10, 30).strftime("%A"))], None, ""),
    ("D07.0", "Digital drawing on the 30th from Pixel Pencil was the first, on 30 October 2026.", [("first", "Digital drawing on the 30th", oct30[0]["title"])], None, "10:00 New York"),
    ("D07.0", "Cooking soup on the 30th from Pan Theory was the last, on 30 October 2026.", [("last", "Cooking soup on the 30th", oct30[-1]["title"])], None, "21:00 New York"),
    ("D07.1", "(same lead as D07.0)", [("n", 4, len(oct30))], None, "true; does not answer 'the second one, who made it'"),
    ("D08.0", "This year up to 30 October 2026, you opened 32 cooking videos, all from Pan Theory.",
     [("n", 32, n("ytd", only=[("area", "food and cooking")])), ("channels", "Pan Theory only", by(ev("ytd", only=[("area", "food and cooking")]), "channel"))], None, ""),
    ("D08.1", "In 2025, you opened 8 food and cooking videos, and Pan Theory made up 100% of them.",
     [("n", 8, n("2025", only=[("area", "food and cooking")])), ("PT", 8, c("2025", "channel", "Pan Theory", only=[("area", "food and cooking")]))], None, ""),
    ("D10.0", "gaming led what you opened, at 49% of 130 videos.", [("share", 49, s("lately", "area", "gaming"))], None, ""),
    ("D10.0", "Clip Factory alone made 56 of those videos.", [("n", 56, c("lately", "channel", "Clip Factory"))], None, ""),
    ("D10.0", "Art and design was 25% of what you opened, with Digital drawing at 21%.",
     [("art", 25, s("lately", "area", "art and design")), ("DD", 21, s("lately", "theme", "Digital drawing"))], None, ""),
    ("D10.1", "In the 4 weeks up to 30 October 2026, gaming was 49% of what you opened.", [("share", 49, s("lately", "area", "gaming"))], None, ""),
    ("D10.1", "Clip Factory made 56 of the videos you opened in those 4 weeks.", [("n", 56, c("lately", "channel", "Clip Factory"))], None, ""),
    ("E04.0", "This year up to 30 October 2026, the list of channels that stopped is empty.",
     [("2025 channels missing in 2026", "none", sorted({e['channel'] for e in ev('2025')} - {e['channel'] for e in ev('ytd')}) or "none")], None, ""),
    ("F02.0", "On Friday 30 October 2026, the last day of your export, 4 videos; Digital drawing led with 2 of them.", [("n", 4, len(oct30))], None, ""),
    ("F02.0", "Digital drawing led with 2 videos, both from Pixel Pencil.", [("DD", 2, c("oct30", "theme", "Digital drawing")), ("PP", 2, c("oct30", "channel", "Pixel Pencil"))], None, "repeats the lead"),
    ("F03.0", "Your 2019 items are not in the history I can read.", [("2019", 0, n("2019", kind=None))], None, "true; history starts 5 Jan 2021, unsaid"),
    ("F04.0", "This year up to 30 October 2026, where your export ends, you opened 0 videos (only Speedruns).",
     [("n", 0, n("ytd", only=[("theme", "Speedruns")]))], None, "true; the last one (1 May 2023) is not said"),
    ("F05.0", "In all your history (...), you opened 319 videos (only gaming).", [("n", 319, n("all", **G))], None, ""),
    ("F05.0", "In 2026, gaming clips were 84% of your 79 gaming videos, with 0 in 2024 and 0 in 2025.",
     [("share", 84, s("ytd", "theme", "Gaming clips", **G)), ("base", 79, n("ytd", **G)),
      ("2024", 0, c("2024", "theme", "Gaming clips")), ("2025", 0, c("2025", "theme", "Gaming clips"))], None, "83.5% rounds to 84"),
    ("F05.0", "Minecraft builds is still the largest gaming theme, at 51% of what you opened.",
     [("share of gaming", "-", s("all", "theme", "Minecraft builds", **G)), ("share of what you opened (said)", 51, s("all", "theme", "Minecraft builds")),
      ("largest gaming theme in 2026 ('still')", "Minecraft builds", rank("ytd", "theme", 0, **G))], "FALSE",
     "wrong base: 163 is 51% of the 319 gaming videos, 23% of the 723 opened; 'still' is wrong too: in 2026 Gaming clips 66 vs Minecraft builds 13"),
    ("F06.0", "No, the opposite: in the 4 weeks up to 30 October 2026, gaming was 49% of what you opened, up from 27%.",
     [("now", 49, s("lately", "area", "gaming")), ("before", 27, s("prev4", "area", "gaming"))], None, ""),
    ("F06.0", "Clip Factory made 56 of them.", [("n", 56, c("lately", "channel", "Clip Factory"))], None, ""),
    ("F08.0", "Brick Realm is in your history, with 163 items you opened, liked or saved.", [("n", 163, n("all", kind=None, only=[("channel", "Brick Realm")]))], None, ""),
    ("F09.0", "In all your history, Brick Realm is your only Minecraft channel on YouTube, with 163 videos you opened.",
     [("channels", "Brick Realm only", by(ev("all", only=[("theme", "Minecraft builds")]), "channel"))], None, ""),
    ("F09.0", "Minecraft builds has 1 channel in your history, so there is no other channel to rank it against.",
     [("n channels", 1, len(by(ev("all", only=[("theme", "Minecraft builds")]), "channel")))], None, ""),
    ("F10.0", "In the 4 weeks up to 30 October 2026, gaming was 49% of what you opened, out of 130 videos.", [("share", 49, s("lately", "area", "gaming")), ("base", 130, n("lately"))], None, ""),
    ("F10.0", "Clip Factory alone made 56 of those videos.", [("n", 56, c("lately", "channel", "Clip Factory"))], None, ""),
    ("F10.0", "Pan Theory came next with 30 videos.", [("2nd", "Pan Theory", rank("lately", "channel", 1)), ("n", 30, c("lately", "channel", "Pan Theory"))], None, "auditor false flag"),
    ("F11.0", "This year up to 30 October 2026, where your export ends, you opened 254 videos.", [("n", 254, n("ytd"))], None, ""),
    ("F11.0", "Your full years before 2026 were 134 in 2021, 108 in 2022 and 157 in 2023.",
     [("2021", 134, years[2021]), ("2022", 108, years[2022]), ("2023", 157, years[2023]), ("2024 (left out)", "-", years[2024]), ("2025 (left out)", "-", years[2025]),
      ("2021 starts", "full year?", "5 January 2021")], "FALSE",
     "incomplete list said as the whole: 2024 (8 shown, 58 with the private topic) and 2025 (62) are missing; and 'was October my biggest month' is not answered (Oct 2026 142, next Jul 2023 52)"),
    ("F14.0", "Across all your history, you opened 319 gaming videos.", [("n", 319, n("all", **G))], None, "true, but they asked about the channel Gaming Daily (5)"),
    ("F14.0", "Of your gaming videos, Gaming clips made 66.", [("n", 66, c("all", "theme", "Gaming clips", **G)), ("Gaming Daily (asked)", "-", c("all", "channel", "Gaming Daily"))], None, ""),
    ("F15.0", "In all your history (...), you opened 83 long videos (only Calculus lessons).",
     [("n", 83, n("all", only=[("theme", "Calculus lessons")], length="long")), ("calc all", "-", n("all", only=[("theme", "Calculus lessons")]))], None, "the 2 of unknown length are not said"),
    ("F15.0", "Integrals by parts and Calculus limits intro are also in that list, each opened once.",
     [("titles exist (long, opened once)", "yes", sorted({e["title"].split(" #")[0] for e in ev("all", only=[("theme", "Calculus lessons")], length="long")}))], None,
     "true; 'also in that list' points at a list the answer never shows"),
    ("G03.0", "In October 2026, you opened 1 Wet Paper video.", [("n", 1, c("oct", "channel", "Wet Paper"))], None, ""),
    ("G03.0", "You opened it on 21 October 2026.", [("day", "2026-10-21", str(ev("oct", only=[("channel", "Wet Paper")])[0]["day"]))], None, ""),
    ("I01.0", "In 2024, Home cooking led what you opened, with 8 videos.",
     [("top shown", "Home cooking", rank("2024", "theme", 0)), ("n", 8, c("2024", "theme", "Home cooking")), ("top with private", "-", rank("2024", "theme", 0, unlock=True))], None,
     "held: the private line is printed (SPEC 8.4)"),
    ("I01.0", "Home cooking made up 8 of them, from Pan Theory.", [("n", 8, c("2024", "channel", "Pan Theory"))], None, "repeats the lead"),
    ("I02.0", "In 2024, you opened 58 videos.", [("n (unlocked turn)", 58, n("2024", unlock=True))], None, ""),
    ("I02.0", "In 2024 you opened 58 videos, and the top theme was Home cooking with 8.",
     [("base", 58, n("2024", unlock=True)), ("top theme of the 58", "Home cooking", rank("2024", "theme", 0, unlock=True)),
      ("Dating advice", "-", c("2024", "theme", "Dating advice", unlock=True))], "FALSE",
     "superlative on the wrong base: of the 58 it names, Dating advice has 50 and Home cooking 8; the next sentence (Heart Notes 50 of 58) contradicts it"),
    ("I02.0", "Heart Notes made up 50 of those 58 videos.", [("HN", 50, c("2024", "channel", "Heart Notes", unlock=True))], None, "unlocked turn: naming allowed (evalset good line)"),
    ("I03.0", "In 2024, Home cooking led what you opened, with 8 videos.", [("n", 8, c("2024", "theme", "Home cooking"))], None, "private line printed"),
    ("I03.0", "Home cooking was the only theme, and Pan Theory the only channel, with 8 videos.",
     [("themes shown", 1, len(by(ev("2024"), "theme"))), ("themes with private", "-", len(by(ev("2024", unlock=True), "theme"))),
      ("channels with private", "-", by(ev("2024", unlock=True), "channel"))], None,
     "held on the non-private base with the private line, but 'only' contradicts the turn before (Heart Notes 50 of 58): should_fix"),
    ("K03.0", "This year up to 30 October 2026, you opened 254 items, and Digital drawing led with 36% of what you opened.",
     [("n", 254, n("ytd")), ("top", "Digital drawing", rank("ytd", "theme", 0)), ("share", 36, s("ytd", "theme", "Digital drawing"))], None, ""),
    ("K04.0", "Your opened items on calculus did not yield any checked points.", [], None, "no countable claim (system talk)"),
]


def ok(said, got):
    if said == "-":
        return True
    if isinstance(said, (int, float)) and isinstance(got, (int, float)):
        return said == got
    if said in ("~2", "full year?", "nothing said"):
        return True
    if isinstance(said, str) and isinstance(got, list):
        return len(got) == 1 or said.startswith("yes")
    if isinstance(said, str) and isinstance(got, str):
        return said.lower() == got.lower() or got.lower().startswith(said.lower()) or said in ("~2", "full year?", "nothing said")
    return said == got


out = []
for key, sent, checks, override, note in C:
    fails = [x for x in checks if not ok(x[1], x[2])]
    verdict = override or ("FALSE" if fails else "TRUE")
    out.append({"key": key, "sentence": sent, "checks": checks, "fails": fails, "verdict": verdict, "note": note})
    print(f"{verdict:5s} {key} | {sent}")
    for x in checks:
        print(f"        {x[0]}: said {x[1]!r} recount {x[2]!r}{'   <-- MISMATCH' if x in fails else ''}")
    if note:
        print("        note:", note)

keys = sorted({json.load(open(f))["key"] for f in glob.glob(H + "[A-Z]*.json")})
covered = sorted({o["key"] for o in out})
print("\nmessages:", len(keys), "covered:", len(covered), "missing:", sorted(set(keys) - set(covered)))
print("sentences recounted:", len(out), "FALSE:", sum(o["verdict"] == "FALSE" for o in out))
json.dump(out, open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/recount/claims_out.json", "w"), indent=1, default=str)
