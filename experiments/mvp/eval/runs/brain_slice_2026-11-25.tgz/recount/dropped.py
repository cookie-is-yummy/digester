"""All dropped sentences of the held-out run (from each file's `dropped`), deduplicated by message and text, then
15 picked by a stated rule: group by the FIRST reason; walk the reasons from the largest group to the smallest (ties alphabetical), round-robin, taking
the next not-yet-picked sentence (ordered by message key) from each, until 15 are picked."""
import glob
import json
import re
from collections import defaultdict

H = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/tune/heldout/"


def strip(s):
    s = s or ""
    while True:
        t = re.sub(r"\[[^\[\]]*\]", "", s)
        if t == s:
            return re.sub(r"\s+", " ", t).strip()
        s = t


seen = set()
allrows = []
for f in sorted(glob.glob(H + "[A-Z]*.json")):
    d = json.load(open(f))
    for x in d.get("dropped") or []:
        k = (d["key"], strip(x["text"]))
        if k in seen:
            continue
        seen.add(k)
        allrows.append({"key": d["key"], "where": x["where"], "text": strip(x["text"]), "raw": x["text"],
                        "reasons": x["reasons"], "details": x["details"], "cells": x.get("cells")})
print("dropped (unique by message and text):", len(allrows))
groups = defaultdict(list)
for r in allrows:
    groups[r["reasons"][0] if r["reasons"] else "?"].append(r)
picked = []
order = sorted(groups, key=lambda g: (-len(groups[g]), g))
i = 0
while len(picked) < 15 and any(groups[g] for g in order):
    g = order[i % len(order)]
    if groups[g]:
        picked.append(groups[g].pop(0))
    i += 1
for n, r in enumerate(picked, 1):
    print(f"{n:2d} {r['key']} [{r['where']}] {r['reasons']} {r['details']}\n    {r['text']}\n    cells={r['cells']}")
json.dump(picked, open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/recount/dropped_picked.json", "w"), indent=1)
print("reasons:", {g: len([r for r in allrows if (r['reasons'] or ['?'])[0] == g]) for g in order})
