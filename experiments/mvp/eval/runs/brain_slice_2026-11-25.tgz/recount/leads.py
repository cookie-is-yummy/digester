"""Who wrote each sent lead: compare the sent lead with the model's form leads (markers stripped)."""
import glob
import json
import re

H = "/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/tune/heldout/"


def strip(s):
    s = s or ""
    while True:
        t = re.sub(r"\[[^\[\]]*\]", "", s)
        if t == s:
            return re.sub(r"\s+", " ", t).strip()
        s = t


own = code = 0
rows = []
for f in sorted(glob.glob(H + "[A-Z]*.json")):
    d = json.load(open(f))
    sent = d["answer"]["lead"]
    model_leads = [strip(fm.get("lead")) for fm in d["forms"] if isinstance(fm, dict)]
    mine = "own" if sent in model_leads else "code"
    own += mine == "own"
    code += mine == "code"
    print(d["key"], d["lead_source"], "->", mine, "| sent:", sent, "| model last:", model_leads[-1:])
    for o in [o for v in d["verdicts"] for o in (v.get("outcomes") or []) if o["where"] == "lead" and not o["kept"]]:
        print("    lead dropped:", o["reasons"], o["details"])
print("own", own, "code", code)
