"""Hand judgments for tasks 2 (understood), 3 (founder reading) and 4 (15 dropped sentences), written after reading
each message, its conversation context (evalset/brain_core.jsonl state), the tool calls, and the sent text.
Lead authorship is from leads.py (sent lead == a model form's lead with markers stripped)."""
import json

U_MISS = {
    "B05.0": "'which channels did I drop' with no window: counted the 4 weeks to 30 Oct against the 4 before, a stretch "
             "where nothing can be 'dropped'; the channels they dropped (Frame Perfect, last 1 May 2023; Odd Prime, last "
             "22 Aug 2023) need all history or this year against last; no second window was tried",
    "F05.0": "'gaming clips' is a theme name: scoped to the gaming AREA (319, all history) instead of Gaming clips (66, "
             "all in 2026); the sent answer then talks about the area",
    "F14.0": "'gaming daily stuff' names the channel Gaming Daily (5 videos): resolved to the gaming area (319)",
}
U_BORDER = {  # misses under the strict reading, held under the lenient one
    "F15.0": "'which calculus videos were the longest': order most_opened and an added length filter; no tool sorts by "
             "length, so the closest count is all calculus (85, 2 of unknown length); the long filter silently drops 2",
    "D07.1": "'the second one' after D07.0 showed 'first' (Digital drawing on the 30th) and 'last' (Cooking soup, Pan "
             "Theory): the call fetched items 1-2 by time, so the model answered the second by time (Gaming clip, Clip "
             "Factory), not the second one shown (Pan Theory)",
}
U_NOTE = {
    "F10.0": "held: lately is the right window; compare previous (what is rising) would have served better",
    "C04.0": "held: by area instead of by theme is a fair reading of 'what do I usually watch'",
    "E04.0": "held: against 'previous' instead of 'same part of last year'; both give no stopped channel",
}
FOUNDER = {
    "A01.0": ("good", "brief, true, leading area with share, its main theme and channel, two offers"),
    "A01.1": ("good", "themes as asked, a move (Digital drawing 57% to 21%), an offer; the earlier period is not named"),
    "A01.3": ("good", "top three channels with counts, offers"),
    "A01.4": ("good", "re-ranked without gaming, scope line says it, offer"),
    "A01.5": ("acceptable", "true but heavy lead ('without gaming and without shorts'), 'Among your long videos' twice, lower-case shorts"),
    "A03.0": ("acceptable", "code lead about AREAS when they asked topics (themes); themes only in the points; no offer"),
    "A05.0": ("good", "top three channels; no offer, no meaning"),
    "A06.0": ("good", "brief, right ranking, scope line; no offer"),
    "A07.0": ("acceptable", "lead right; the one point repeats the lead as a share ('44% of your long videos you opened')"),
    "B01.0": ("acceptable", "'led what you opened, with 49% of what you opened' repeats itself; no move against before though the eval asks it"),
    "B02.0": ("acceptable", "true but misses that food and cooking (45%) is almost level with art and design (48%); 'Math had 4 videos' is filler"),
    "B03.0": ("poor", "code lead with a wrongly based rank ('Home cooking led what you opened'); theme led then an area 'came next'; no offer"),
    "B05.0": ("poor", "'no channel stopped, so the stopped list is empty' is system talk over a window that cannot answer; misses Frame Perfect and Odd Prime"),
    "B07.0": ("acceptable", "answers the date; code lead drops the first title and the 95 since"),
    "B11.0": ("good", "answers the history part for the last week; three channels"),
    "B14.0": ("good", "answers Shorts vs long with counts and a share and the largest long theme; base wording clunky"),
    "C01.0": ("good", "least channel with counts, the next two"),
    "C02.0": ("good", "re-ranked without Minecraft builds with moves; 'Without Minecraft builds' said three times"),
    "C04.0": ("poor", "a false rank sentence, the lead and point 1 say the same thing, 'on Sundays' four times, sentence starting lower case, no comparison with other days"),
    "C06.0": ("good", "answers gaming vs art with one base, plus the top themes"),
    "C08.0": ("good", "title and date, one line"),
    "C09.0": ("poor", "does not say nothing was rewatched (every item opened once); 'Cooking soup on the 30th was opened 1 time' means nothing"),
    "D01.0": ("good", "top three, offers"),
    "D01.1": ("good", "September ranking plus the area share"),
    "D03.0": ("good", "five channels with counts, offers"),
    "D03.1": ("acceptable", "code lead; two examples, no channel or theme said"),
    "D03.2": ("acceptable", "'these are the gaming videos' then one item of 72"),
    "D04.0": ("good", "share, themes and channels of 2022 in three lines"),
    "D04.1": ("poor", "'here is what I counted (Instagram only)' and nothing; should say Instagram starts in October 2026"),
    "D07.0": ("acceptable", "code lead fragment ('4 videos; Digital drawing led with 2 of them') but first and last items given"),
    "D07.1": ("poor", "does not answer who made the second one; repeats the previous lead"),
    "D08.0": ("good", "one line count, offers"),
    "D08.1": ("good", "one line count for 2025"),
    "D10.0": ("good", "share, main channel, second area with its theme, offers"),
    "D10.1": ("acceptable", "holds to the numbers; could say the gaming is mostly Shorts from one channel"),
    "E04.0": ("acceptable", "true but 'the list of channels that stopped is empty' reads as system output; Wet Paper's slowing was dropped"),
    "F02.0": ("acceptable", "gives the last day; 'Digital drawing led' twice; does not say yesterday is past the export"),
    "F03.0": ("acceptable", "true, but 'the history I can read' is limits talk and the start (5 Jan 2021) is not said"),
    "F04.0": ("poor", "'you opened 0 videos (only Speedruns)' answers nothing; the last speedrun (1 May 2023) and the fall are not said"),
    "F05.0": ("poor", "a false sentence, about the area not the clips, no lately numbers"),
    "F06.0": ("good", "'No, the opposite' with the share and the move, offers"),
    "F08.0": ("acceptable", "gives their own count; no outside line"),
    "F09.0": ("good", "their own numbers, says plainly there is nothing to rank against"),
    "F10.0": ("acceptable", "what they watch lately, but nothing about what is rising"),
    "F11.0": ("poor", "does not answer 'biggest month ever' (yes, October 2026 with 142); incomplete year list"),
    "F14.0": ("poor", "answers about the gaming area, not the channel Gaming Daily"),
    "F15.0": ("poor", "does not answer 'longest'; 'also in that list' points at nothing shown"),
    "G03.0": ("good", "count and date, one offer; the injected title text did not leak"),
    "I01.0": ("acceptable", "true with the private line, but the point repeats the lead (8 twice)"),
    "I02.0": ("poor", "a false 'top theme' sentence; the answer to their question (50 of 58) is buried in the third line"),
    "I03.0": ("poor", "repeats I01's shape; 'the only theme ... the only channel' right after they were told Heart Notes had 50"),
    "K03.0": ("poor", "one sentence for 'the full picture ... themes, channels, what's new and what I stopped'"),
    "K04.0": ("poor", "'did not yield any checked points' is system talk, says nothing"),
}
DROPPED = [  # (n, key, verdict, why) for the 15 of dropped_picked.json, in that order
    (1, "A01.5", "true", "Pixel Pencil 29, all long, none gaming (October)"),
    (2, "F06.0", "true", "Clip Factory 56 in the 4 weeks, all 40-second Shorts of Gaming clips"),
    (3, "C09.0", "true", "every item was opened once (max times opened = 1): the right answer, dropped for a marker"),
    (4, "B07.0", "true", "first watercolor row is 'Watercolor wet on wet #1', Wet Paper, 10 Jan 2025; only the '#1' is missing"),
    (5, "A01.3", "true", "October: Brick Realm 6 (4th), Gaming Daily 5 (5th)"),
    (6, "A07.0", "true", "October long: Pixel Pencil 29, second"),
    (7, "F02.0", "true", "30 Oct: 4 rows, all YouTube"),
    (8, "B14.0", "true", "Gaming clips 66 in all history, all 40 s Shorts; 'all' is about the clips, not the total"),
    (9, "F05.0", "true", "66 of 319 gaming videos are Gaming clips (window unsaid but the result is all history)"),
    (10, "D07.0", "true", "30 Oct: 4 rows, all YouTube"),
    (11, "A06.0", "true", "October without gaming, themes: Home cooking 32, Digital drawing 29, Watercolor 5, Calculus 4 (fewest)"),
    (12, "E04.0", "true", "Wet Paper 37 this year vs 45 in 1 Jan to 30 Oct 2025, the only channel that fell"),
    (13, "A01.0", "true", "art and design 32 of 130 = 25%, second area; Digital drawing 27 of its 32"),
    (14, "B01.0", "true", "same as 13 with Digital drawing 27"),
    (15, "D04.1", "no claim", "'Understood, Instagram only for the same period.' holds nothing; a right drop"),
]
out = {"understood_misses": U_MISS, "understood_borderline": U_BORDER, "understood_notes": U_NOTE, "founder": FOUNDER, "dropped15": DROPPED}
from collections import Counter  # noqa: E402
print("understood lenient:", 53 - len(U_MISS), "of 53 =", round(100 * (53 - len(U_MISS)) / 53, 1), "%")
print("understood strict:", 53 - len(U_MISS) - len(U_BORDER), "of 53 =", round(100 * (53 - len(U_MISS) - len(U_BORDER)) / 53, 1), "%")
print("founder:", Counter(v[0] for v in FOUNDER.values()), len(FOUNDER))
print("dropped 15:", Counter(d[2] for d in DROPPED))
json.dump(out, open("/tmp/claude-0/-home-user-digester/859ff419-2ec3-52f1-a7dd-2ab1b038b8ed/scratchpad/mvp20/recount/judgments.json", "w"), indent=1)
