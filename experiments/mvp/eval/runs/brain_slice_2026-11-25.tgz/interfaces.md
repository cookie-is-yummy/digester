## slice (brain-run-local), 26 Nov 2026: the thin live slice
- brain/provider.py: `send(system, tools, messages, max_tokens=None, timeout=None) -> Reply{blocks (JSON copy), raw
  (SDK blocks, appended unchanged), stop_reason, usage{input_tokens, output_tokens, cache_read_input_tokens,
  cache_creation_input_tokens}, seconds, cost_usd, retries}`. AnthropicProvider(model, effort, max_tokens,
  prompt_version, thinking, loose, ...) through mvp.llm.ai (the ledger home and Claude cap from MVP_LEDGER_HOME /
  MVP_CLAUDE_CAP_USD); every request logged with ai.log_batch (purpose brain_eval; in_tokens = the whole prompt:
  uncached + cache read + cache write). A timeout is logged as an over-estimate (prompt_version "+estimate").
  FakeProvider(script) replays turns; provider.tool_use(name, args), provider.text(t) build fake blocks.
- Strict: on the nine read tools only. ALL TEN strict (with give_answer) is a 400 "The compiled grammar is too large";
  give_answer strict ALONE compiles (probe), give_answer + 4 read tools strict does not. With give_answer loose, the
  model invented top-level keys in 12 of 30 repairs ("understood_note", "understood_dummy", "understood_x", ...).
- brain/loop.py: run_turn(provider, turn, message=None, screen=None, now=..., rounds=3, soft_s=6, deep_s=12, hard_s=15)
  -> record {calls[{round, id, name, args, rid, result(envelope)}], forms, verdicts (JSON), repair_message, requests,
  events, lead_source (model|model_after_repair|code|plain), answer (answer.build), code_lead, sentences{written,
  kept_first_pass, kept_sent}, seconds, tokens, cost_usd, n_requests, rounds, error}. The tool_result text is
  loop.present(env): rid, tool, meta and the SHEET'S KEYS AT THE TOP (a cell's path is rid + its JSON path); the ledger
  keeps the envelope. screen_after(rec, now_words) and last_window(turn, rec) carry a conversation.
  NOTE: past the soft deadline no read call runs (SPEC 3.4 as written): a first round that takes > 6 s gets "time is up"
  with nothing in hand.
- brain/answer.py: build(ledger, verdict=None, code=None, form=None, also=()) -> {lead, points, scope_line,
  private_line, offers, text, rid, filtered}. Scope line only when the cited result is filtered (meta.filters_said, or
  the without-Shorts filter). Private line OR'd over every verdict of the turn and the code lead.
- prompts/brain_v1.md: its examples are pinned by tests/test_brain_slice.py against tests/brain_prompt_fixture.py
  (real results of the brain library with every name renamed to names in no library).
- eval_brain: `run --half tune|heldout|all --out DIR [--limit N] [--ids ..] [--parallel N] [--max-usd X] [--loose ..]`
  (live; needs the key), `count [--out DIR]` (count_tokens, free), `audit --run DIR` (offline re-audit of a saved run).
  half_of(id): sha1 split (tune 34 plan conversations / 38 plan messages; held-out 42 / 53). call_key / compare_plans
  are G2. Harness.scratch(keep_ledger=True) keeps the caller's MVP_LEDGER_HOME.
- Found, NOT fixed (step 1 code): fallback's code_form lead on a SAVED breakdown says "mostly art and design (50% of
  what you opened), then food and cooking (50%)" (I04.0, I05.0 of run1): the base words are "opened" on a result of
  saves, and "mostly" sits on a 50/50 tie. A wrongly based sentence that went out. Likely fix: no code_form when
  meta.base is not "of what you opened" (the template says the base's verb), as the merge seam did for scoped results.
- Auditor findings on live answers that the slice's builder READ as auditor misreadings (own reading, not an
  independent recount): "<theme> came next with N videos" read as the window's total (C11, C12, D09, H01); a share "of
  what you opened in art" / "without gaming, ... of what you opened" on a scoped result read on the unscoped base
  (D06.1, K01); "[rk.channels[i].first_watched]" recounted as a number, not a date (C13). UNRESOLVED: B04, a share on a
  base of "any": the tool says 79/192 = 41%, the auditor 42.5% (79/186, the opened total?).
- eval_brain call_key: a compare's window is [a start, a end, b start, b end], b read with verify.Result.prev_window()
  (a compare's `previous` carries words, not dates). summary["decomposition"]: repairs spent on an invalid form and the
  first pass on the first form that validated. `audit --run` also recomputes G2 on the hand chain.
## tune (brain-tune-local), 25 Nov 2026
- prompt: prompts/brain_v2.md, loop.PROMPT_VERSION "brain_v2" (env MVP_BRAIN_PROMPT); v1 kept. Its new examples are
  pinned in tests/test_brain_tune.py (v1's in test_brain_slice still pass, they are kept verbatim in v2).
- loop.clean_form(form) -> (form, dropped keys): unknown TOP-LEVEL give_answer keys are dropped before the check (event
  "form_keys_dropped", rec["dropped_keys"]); a key inside a field still fails validation.
- verify: new reasons "platform_word" (a count of every platform said as YouTube's); "wrong_window" also from
  _change_period_said (a changes result's from/to/peak share needs its own period beside it). verify.scope_said(text,
  res); _waive_scope_repeats: a point dropped ONLY for filter_dropped is kept when the kept lead cites the same
  filtered result and says its scope, unless the point has a share, a move, a total or base words (Outcome.notes
  "scope_waived"). A learned point that is exactly "[rN.points[k]]" passes and answer.build renders the point's text.
- fallback: no code_form unless meta.base is "of what you opened"; the led template says the base's verb ("led what
  you saved").
- eval_brain summary G2_understood.share_gate_fields: understood + other_plan (the gate's four fields).
- Thinking disabled (MVP_BRAIN_THINKING=disabled) measured worse (run4); adaptive kept.
- Held-out once at 4ce8a5a: G2 78.8/86.5, G3 67.9, G4 44.5/32.1, G5 7.64/10.96 s, G6 0.156 c; G1 >= 3 false sent.
## fix (brain-slice-local), 26 Nov 2026
- planted: a case may carry "forms" (one per carrier lead; kept if ANY keeps it). Sources "attack"/"attack_true"
  (eval/brain_attack_cases.py; ledgers frozen by tests/test_brain_fix.py, MVP_FREEZE_ATTACK=1) are scored apart: the
  bar's "false"/"true" lines stay the builder's + the step 1 audit's. eval_brain planted(): attack_kept_false,
  attack_true_dropped.
- verify: new reasons "length_word", "scope_broadened"; "base" now also for an unscoped base phrase on a filtered
  result; _fix_rules (range words, qualifiers, comparisons, from/to, hidden "only", all-from, usually, item order,
  items.count, base, broadening, least ordinals); _bind_points_to_lead (came next, another window); _SELF_TALK limits.
- fallback: code_lead returns "marked" (template in marker form) and "list" (code_form); answer() re-checks the model's
  points under the code lead (no waived point, no back-reference point); bare "here is what I counted" -> plain.
- answer.build: offers under a code lead too (loop passes the base form); no scope line under the plain line; the
  scope line closes its bracket and says a part once.
- loop.PROMPT_VERSION default brain_v3.
- Final runs on bee4b4e: fix/tune_run, fix/heldout_run (second look). Post-run offline fix bb7a825.
