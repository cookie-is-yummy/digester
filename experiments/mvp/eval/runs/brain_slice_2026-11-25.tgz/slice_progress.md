# slice progress (branch brain-run-local, from 78beb9a)

- 26 Nov: branch made from 78beb9a. Read brief, DECISIONS, DESIGN 21, SPEC 0/3/4/9, mvp19 interfaces, code.
- Disclosure: before the split was computed, an early `head -c` of evalset/brain_core.jsonl and brain_plans.jsonl
  printed conversation A01 in full and the start of A03. Both are HELD-OUT (sha1 split). Nothing of them was used for
  the prompt; from then on only tune ids were printed. The held-out half was never run.
- Commit trailer: the harness attribution lines are used (the brief's trailer names another model; the brief is
  script output, the harness reminder governs).
- Key use: the sandbox refuses `.`/`source` in a command line, so scratchpad/mvp20/slice/live.sh sources the key file
  and runs the command in the same shell, every output line through the masking sed. Nothing printed the key.

## Commits
- 2ba913d: brain/provider.py, brain/loop.py, brain/answer.py, prompts/brain_v1.md, eval_brain run + count,
  tests/test_brain_slice.py (fake provider only), tests/brain_prompt_fixture.py; test_brain_eval's run-refusal test
  now pins the no-key refusal.
- ce3b209: the auditor reads each sent sentence against the result it cites (was: the first cited result for the whole
  text, which made 3 false flags on F07); `eval_brain audit --run DIR` re-audits offline; a timed-out request is
  logged as an over-estimate.

## Settings shipped (claude-api skill, Haiku 5.5)
adaptive thinking, effort low (env MVP_BRAIN_EFFORT; MVP_BRAIN_THINKING=disabled is a knob, not used), max_tokens
4000, tool_choice auto, no sampling params, no fallbacks, strict on the nine read tools, NOT on give_answer (with all
ten strict the API answers 400 "The compiled grammar is too large"; probe: give_answer strict ALONE compiles, give_answer
+ four read tools strict does not). Cache: 5-minute breakpoint on the system block + top-level automatic breakpoint.

## count_tokens (free; scratchpad/mvp20/slice/count/count_tokens.json)
- prefix (system + 10 tool schemas) + a 1-token message: 10,122 tokens. tools alone ~6,592 (9 read tools + give_answer),
  system text alone ~3,541. (SPEC 9.1 assumed 4,500 + 1,800 = 6,300 before the context cards.)
- user turn (screen + message): ~59 tokens with an empty screen (the SPEC assumed 450 with a full screen).
- one tool result (breakdown by channel, October; 6,638 characters): ~3,291 tokens (SPEC assumed 1,800 for two
  trimmed sheets): JSON is ~2 characters a token here, not 4. results.RESULT_CHARS=6000 is ~3k tokens, not 1.5k.
- typical round-2 request: 13,472 input tokens.
- Cache reads really happen (usage fields): every message's first request read ~10,046 cached tokens; run1 totals:
  cache_read 1,162,954, cache_creation 174,869, uncached input 294, output 64,524 over 109 requests.
- What it means for SPEC 9 (Haiku column): measured mean 0.17 cents a message warm (SPEC: 0.08 ordinary warm). The gap:
  2.87 requests a message (30 of 38 messages took a repair), results ~3.3k tokens each, and ~1,700 output tokens a
  message (thinking at effort low still runs on 60 of 109 requests; median 489, max 1,900 output tokens a request).
  Uncached it would be about 0.44 cents. Still under G6's 0.5 cents; with the context cards (~2k) add ~0.01 cent warm.

## Live
- smoke (B04, C05; 26 Nov): first try 400 (grammar too large); a debug request with give_answer loose (billed
  $0.00128, logged by hand to the ledger); then 2 messages, $0.0044. scratchpad/mvp20/slice/smoke/.
- run1 (tune half, 38 plan messages, parallel 3; scratchpad/mvp20/slice/run1/): $0.0658 in 109 logged requests +
  1 timed-out repair request logged as an over-estimate ($0.0022); ledger rows tagged run=mvp20-slice-run1.
- two strict probes (16 output tokens each): $0.00012 and $0 (400). Total live spend of this task: about $0.074.
- run1 re-audited offline after the per-sentence audit fix (summary.first.json kept).

- adef032: G2 reads both windows of a compare (run1's G2 unchanged: 19/7/11); summary.decomposition; audit mode
  recomputes G2; docstring. Brain test files 188 passed (slice 25), test_claude_backend + test_claude_review pass,
  planted 332/332 and 78/78.

## Decomposition (offline, from run1's records)
- 12 of 30 repairs went on a form that did not validate (an invented top-level key); 9 of the 19 not-own leads are among
  them (B06.0 B08.0 C03.0 C10.0 F12.0 F13.0 G02.0 G04.0 I04.0): their real verifier failures had no repair left.
- First pass read on the first form that validated: 47 of 103 kept (54% missing), against 67% measured.
- Wall time is model time: median wall 8.19 s, median sum of request seconds 8.08 s (overhead median 0.12 s).
- Disclosure: the prompt's first example is the October-channels question with the library's own numbers (names
  renamed); it matches held-out A01's message 3, which was seen in the early head -c, and tune C05/D09, and SPEC 3.6's
  own example. The test's default message is that sentence too.

## run1 figures (TUNE half, measured; the gate is defined on the held-out half)
- G2 understood 19 of 37 with a hand plan (51%); other plan 7 (A02.0 C12.0 C13.0 E07.0 F07.0 H01.0 I04.0); differs 11.
- G3 own lead 19 of 38 (50%): model 8, model_after_repair 11, code 16, plain 3.
- G4 missing: first pass 67% (34 of 103 kept), after repair 47% (55 of 103).
- G5 median 8.19 s, p90 11.38 s, max 15.05 s (parallel 3, 0 retries).
- G6 mean 0.173 cents.
- G1 (auditor only, no hand recount): 17 findings on 11 messages; my reading: 2 messages sent a wrongly based
  sentence, both CODE leads (I04.0, I05.0: insight code_form "mostly art and design (50% of what you opened), then food
  and cooking (50%)" on a SAVED result: 6 of the 17 findings); 10 read as auditor misreadings by my own reading (not an
  independent recount); 1 unresolved (B04: 41% said on a base of "any", auditor 42.5%).
- planted: 332 of 332 false handled, 78 of 78 true kept (no verifier change in this task).
