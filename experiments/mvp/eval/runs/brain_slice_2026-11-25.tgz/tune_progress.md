# tune progress (branch brain-tune-local, from adef032 = tip of brain-run-local)

- 25 Nov: branch made. Read brief, slice_progress, interfaces, DESIGN 21, the run1 records. Only TUNE ids read.
- Commit trailer: the harness attribution lines (the brief's names another model; the brief is script output).
- Baselines reproduced before any change: planted 332/332 false handled, 78/78 true kept, audit true set 42/61;
  offline replay of run1 (scratchpad/mvp20/tune/replay.py: saved forms re-checked against saved envelopes) gives
  exactly 34/103 first pass, 55/103 sent, lead sources model 8 / after repair 11 / code 16 / plain 3.
- Recount tool: scratchpad/mvp20/tune/recount.py (independent of facts.py: the rows of tests/brain_library.py, New York
  days, friend and the sensitive theme left out).

## Step 1: every dropped sentence of run1 and every not-own lead, recounted (true = the recount agrees)
| class (verifier reason) | n | true/false | example | action |
|---|---|---|---|---|
| limits talk (limits) | 11 | rule, not a fact (most true) | C07 "Your export ends on 30 October 2026, so I can't see last week." | prompt |
| "you opened" on an opened/liked/saved result (base) | 3 | FALSE (192 is any; opened 186) | B04 "you opened 192 items" | correct; prompt (how opened) |
| share "of what you opened" on YouTube-only (base) | 2 | wrongly based (true by chance: all 24 YouTube) | F01 "54% of what you opened" | correct; prompt |
| "opened, liked or saved" cut at its comma (uncited_claim) | 1 | TRUE | B04 F2 lead | verifier fixed (V1) |
| "24 YouTube videos" on YouTube-only (insight_rewrite) | 4 | TRUE | C07, F01 leads | verifier fixed (V2) |
| filter not repeated (filter_dropped) | 9 | TRUE (all 9 recounted) | K01 "Food and cooking rose to 30%, up 17 points" | (c) waiver for row counts/ranks; prompt |
| "37 of your art videos" (count_as_share) | 4 | TRUE | D06.1 Wet Paper 37 of 133 art | verifier fixed (V5) |
| "rose to 30%, up 17 points" (one_value) | 3 | TRUE | K01 | verifier fixed (V4) |
| period count with its label in words (unnamed_owner) | 4 | TRUE | F07 "6 in September 2026 and 4 in October 2026" | verifier fixed (V3) |
| theme named in other words (unnamed_owner) | 1 | TRUE | I05 "3 watercolor lessons" | prompt |
| numbers in words (uncited_number) | 10 | TRUE (9), 1 shape | B09 "three lessons", D02.1 "five examples" | prompt |
| library name with no marker (uncited_name/typed_name) | 7 | TRUE | C12 "almost all in math", D09.1 "mostly through Clip Factory" | prompt |
| capitalised non-names, title words (unknown_name) | 7 | TRUE content | F07 "All-time", B09 "Lesson", G02 "Minecraft" (an injected title) | prompt (titles with row markers) |
| two results in a sentence (two_results) | 2 | TRUE | B08 | prompt |
| claims with no marker (uncited_claim/unsupported) | 8 | TRUE by recount, unprovable | C10 "so YouTube is where you watch", C13 "2026 was your busiest year", I04 "split evenly" | correct; prompt |
| newest said of a most_opened list (tie) | 2 | TRUE by chance, unprovable | B06 "the most recent is from 21 October" | correct; prompt (order newest) |
| "none in 2024[cell]", "no math at all[cell]" (wrong_value/bad_marker) | 2 | TRUE content | C03, F07 | prompt (0[cell]) |
| learned point as its marker (wrong_name) | 4 | the SPEC's own shape failed | B10 "[r1.points[0]]" | verifier fixed (point = its marker) + answer renders the point's text |
| a theme "posts" (outside_in_history) | 1 | TRUE | I05 "Home cooking[...] posts." | verifier fixed (V6: channels only) |
| "is a channel in your history", "all on YouTube" (outside) | 3 | TRUE, outside rule | K02, G02 | correct; prompt |
| Instagram handles (link) | 3 | TRUE, banned | I04 "@crumb.lab gave 2 saves" | finding (result shape) |
| "fell into these 4 areas" (direction_unbound) | 1 | TRUE | D05.1 | verifier fixed (V7) |
| "led by Digital drawing[themes[2]]" inside an area (rank) | 1 | TRUE, unprovable by the cited row | D05.0 | correct; prompt |
| watch time | 2 | rule | F01, B10 (a caption's "12 hours") | correct |
Not-own leads (19): code 16, plain 3. Causes: 9 an invented key spent the repair; limits talk in the lead (C07 F01
F12 G04 G06 H02 I04); a wrong base (B04); numbers in words (B09 D02.1); two results (B08); C13 a timeout of the
repair; F13 no_match (nothing citable); I05 names without markers.

## SENT sentences of all 38 answers, recounted
- FALSE / wrongly based that went out: I04.0 and I05.0, both the CODE lead ("mostly art and design (50% of what you
  opened), then food and cooking (50%)" of a breakdown of SAVES). Fixed (fallback: no code_form unless the base is
  "of what you opened"; the led template now says the base's verb: "Wet Paper led what you saved, with 3 items").
- Borderline: C13 "Gaming is still the biggest area at 44%" ("still": in 2026 art and design leads, 52%); the plain
  line "I couldn't check an answer to that in time" on G04 G06 H02, where no time ran out.
- Every other sent sentence recounted true (the auditor's 15 other findings on run1 are its misreadings: "came next
  with 30 videos" read as the window's total; "69% of what you opened in art" read on the unscoped base; B04's 41% is
  79/192 on the any base, the auditor used opened's 186).
- New false-KEPT hole found while loosening V2: "you opened 142[r1.totals.items] YouTube videos" on an unscoped
  October result (4 of the 142 are Instagram) was kept. Fixed: platform_word guard.

## Commits
- 49828a3 tune 1 (see the commit message). planted 332/332 and 78/78; audit true set 49/61 (was 42/61; now kept:
  T17 T23 T54 T55 count of videos, T24 45% more, T25 a period, T49 busiest hour; T37 now drops on the handle rule).
  Offline replay of run1 forms: first pass 51/103 kept (was 34), sent 62/103 (was 55).

## Live runs (tune half; gate on held-out)
| run | prompt | settings | G2 strict / gate fields | G3 own | G4 missing first / after | G5 median / p90 | G6 mean | G1 |
|---|---|---|---|---|---|---|---|---|
| run1 (slice) | v1 | effort low | 51% / 70% | 50% | 67% / 47% | 8.19 / 11.38 s | 0.17 c | 2 false sent (code leads) |
| run2 | v2 (49828a3) | adaptive, effort low, parallel 3 | 83.8% / 86.5% | 89.5% | 36.4% / 24.6% | 7.27 / 9.70 s | 0.149 c | 2 sentences wrongly based (C13, a 2026 share said of the window; verifier hole, fixed 0c7505c) |
| run3 | v2 (0c7505c) | adaptive | 83.8% / 86.5% | 97.4% | 24.1% / 12.5% | 6.50 / 9.05 s | 0.141 c | 0 (my recount of all 38) |
| run4 | v2 (ca3fb10) | thinking DISABLED | 86.5% / 89.2% | 79.0% | 41.7% / 20.9% | 6.09 / 8.41 s | 0.130 c | 0 found in the auditor's findings (not a full recount) |
| run5 | v2 (4ce8a5a) | adaptive (final) | 94.6% / 97.3% | 92.1% | 31.0% / 15.9% | 6.89 / 9.33 s | 0.143 c | 0 (my recount of all 38); borderline D02.1 "the videos you opened most" when all were opened once |
Spend: run2 $0.0568, run3 $0.0536, run4 $0.0495, run5 $0.0544 (ledger rows matched requests each run).
Runs used up (4). Tune half NOT at the gate on G4 (15.9% > 15%, run3 12.5%) and G5 median (6.89 s > 6 s).
Thinking disabled (the skill: allowed on Haiku 5.5 at effort high or below) was faster but worse: kept adaptive.
- Commits: 0c7505c tune 2; ca3fb10 tune 3 (how opened); 4ce8a5a tune 4 (1 or 2 points). Held-out runs on 4ce8a5a.

## HELD-OUT, once (4ce8a5a, the run5 settings: brain_v2, adaptive, effort low, parallel 3; tune/heldout/)
53 plan messages, $0.0824 (138 ledger rows = requests). Nothing changed after it.
- G2 78.8% strict (41/52; 4 other_plan, 7 differ) / 86.5% on the gate's four fields: MISSED (bar 90%)
- G3 67.9% (36/53: model 26, after repair 10, code 17): MISSED (bar 85%)
- G4 missing 44.5% first pass, 32.1% after repair (93/137 sent): MISSED (bar 15%)
- G5 median 7.64 s, p90 10.96 s: MISSED both
- G6 0.156 cents mean: met
- G1: auditor 24 findings on 21 messages (17 are its known "came next with N" misreading). My PARTIAL check (the
  auditor's other findings, every sent sentence on a scoped result, every code-lead answer; not an independent full
  recount): 3 false or wrongly based sentences SENT: F05.0 "Minecraft builds is still the largest gaming theme, at 51%
  of what you opened" (51% of the gaming videos; 23% of what they opened); I02.0 "the top theme was Home cooking with
  8" of 2024 (58 videos, 50 of them the unlocked dating channel, whose theme the result's themes list leaves out);
  F11.0 "Your full years before 2026 were 134 in 2021, 108 in 2022 and 157 in 2023" (2024 and 2025 left out). MISSED.
- planted 332/332 false handled, 78/78 true kept; audit true set 49/61.
- After held-out (no code change): replayed the held-out forms under adef032's verify/fallback/answer: 16 sentences
  kept live would have been dropped by step 1's verifier; recounted by hand: 15 true, 1 FALSE (F11.0's "full years
  before 2026 were 2021, 2022, 2023", let out by the period-label change). F05.0 and I02.0's false sentences were
  kept by step 1's verifier too (pre-existing holes). Probe: "Gaming[r1.areas[0]] is huge right now" and "... has
  millions of fans" are KEPT since the theme/area exemption (before: outside_in_history): a hole this task opened,
  pinned by a test, not fixed (frozen). da5530e: tests only.
- Disclosure: held-out answers were read after the run (auditor findings, scoped sentences, code leads, replay).
  The step-1 disclosure (A01 printed by an early head -c) carries over. Tune figures are inflated: brain_v2's "which
  call" table and several of its sentences were written from the tune messages (H02, G06, F01, F12, K02, B10).
- One prompt_version "brain_v2" covers five prompt texts: run2 49828a3, run3 0c7505c, run4 ca3fb10, run5 and
  held-out 4ce8a5a.
